module fake_netlist_771_1028_n_60 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_60);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_60;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_20;
wire n_52;
wire n_36;
wire n_29;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_48;
wire n_43;
wire n_49;
wire n_56;
wire n_38;
wire n_54;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_59;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;
wire n_47;

NOR2x1_ASAP7_75t_L g20 ( 
.A(n_9),
.B(n_7),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

INVx4_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_4),
.A2(n_16),
.B(n_12),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_18),
.A2(n_5),
.B1(n_17),
.B2(n_6),
.Y(n_26)
);

INVx5_ASAP7_75t_L g27 ( 
.A(n_8),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_L g29 ( 
.A(n_21),
.B(n_3),
.Y(n_29)
);

BUFx3_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_1),
.Y(n_32)
);

OA21x2_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_25),
.B(n_22),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_20),
.B(n_26),
.C(n_25),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

BUFx3_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_36),
.B(n_34),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_32),
.B1(n_29),
.B2(n_24),
.Y(n_41)
);

INVxp67_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

OAI22xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_38),
.B1(n_37),
.B2(n_24),
.Y(n_43)
);

INVxp67_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

AOI211xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_37),
.B(n_23),
.C(n_24),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_42),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

NOR2xp33_ASAP7_75t_L g51 ( 
.A(n_45),
.B(n_16),
.Y(n_51)
);

NOR3xp33_ASAP7_75t_SL g52 ( 
.A(n_47),
.B(n_18),
.C(n_17),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_46),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_27),
.B1(n_19),
.B2(n_11),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_SL g55 ( 
.A(n_52),
.B(n_27),
.Y(n_55)
);

AND2x2_ASAP7_75t_SL g56 ( 
.A(n_51),
.B(n_19),
.Y(n_56)
);

OAI21xp5_ASAP7_75t_L g57 ( 
.A1(n_51),
.A2(n_27),
.B(n_13),
.Y(n_57)
);

AOI22xp33_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_57),
.B1(n_55),
.B2(n_49),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

AO221x1_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_14),
.B1(n_27),
.B2(n_50),
.C(n_58),
.Y(n_60)
);


endmodule