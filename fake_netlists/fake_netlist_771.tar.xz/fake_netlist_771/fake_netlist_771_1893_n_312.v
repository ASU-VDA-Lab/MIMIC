module fake_netlist_771_1893_n_312 (n_0, n_20, n_6, n_29, n_17, n_2, n_12, n_1, n_25, n_31, n_5, n_27, n_33, n_24, n_26, n_18, n_13, n_15, n_11, n_16, n_23, n_28, n_4, n_9, n_8, n_30, n_7, n_10, n_19, n_21, n_3, n_32, n_22, n_14, n_312);

input n_0;
input n_20;
input n_6;
input n_29;
input n_17;
input n_2;
input n_12;
input n_1;
input n_25;
input n_31;
input n_5;
input n_27;
input n_33;
input n_24;
input n_26;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_28;
input n_4;
input n_9;
input n_8;
input n_30;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_32;
input n_22;
input n_14;

output n_312;

wire n_36;
wire n_35;
wire n_100;
wire n_101;
wire n_232;
wire n_186;
wire n_187;
wire n_107;
wire n_222;
wire n_184;
wire n_179;
wire n_308;
wire n_297;
wire n_301;
wire n_181;
wire n_51;
wire n_255;
wire n_207;
wire n_143;
wire n_201;
wire n_216;
wire n_117;
wire n_279;
wire n_204;
wire n_128;
wire n_88;
wire n_275;
wire n_290;
wire n_155;
wire n_126;
wire n_82;
wire n_129;
wire n_150;
wire n_176;
wire n_167;
wire n_303;
wire n_234;
wire n_209;
wire n_294;
wire n_215;
wire n_56;
wire n_300;
wire n_236;
wire n_78;
wire n_161;
wire n_259;
wire n_149;
wire n_159;
wire n_240;
wire n_173;
wire n_141;
wire n_34;
wire n_211;
wire n_154;
wire n_193;
wire n_113;
wire n_256;
wire n_239;
wire n_250;
wire n_191;
wire n_87;
wire n_115;
wire n_120;
wire n_264;
wire n_242;
wire n_221;
wire n_116;
wire n_254;
wire n_140;
wire n_287;
wire n_65;
wire n_283;
wire n_278;
wire n_73;
wire n_293;
wire n_271;
wire n_68;
wire n_273;
wire n_231;
wire n_311;
wire n_127;
wire n_166;
wire n_284;
wire n_53;
wire n_74;
wire n_220;
wire n_146;
wire n_182;
wire n_178;
wire n_168;
wire n_246;
wire n_280;
wire n_102;
wire n_302;
wire n_224;
wire n_62;
wire n_270;
wire n_169;
wire n_245;
wire n_175;
wire n_148;
wire n_202;
wire n_195;
wire n_217;
wire n_267;
wire n_152;
wire n_86;
wire n_266;
wire n_177;
wire n_298;
wire n_70;
wire n_125;
wire n_262;
wire n_69;
wire n_137;
wire n_233;
wire n_212;
wire n_145;
wire n_133;
wire n_194;
wire n_109;
wire n_157;
wire n_203;
wire n_260;
wire n_111;
wire n_307;
wire n_170;
wire n_47;
wire n_200;
wire n_288;
wire n_163;
wire n_130;
wire n_160;
wire n_97;
wire n_94;
wire n_39;
wire n_309;
wire n_136;
wire n_135;
wire n_296;
wire n_114;
wire n_223;
wire n_38;
wire n_99;
wire n_192;
wire n_60;
wire n_93;
wire n_247;
wire n_131;
wire n_252;
wire n_41;
wire n_299;
wire n_37;
wire n_63;
wire n_244;
wire n_291;
wire n_119;
wire n_42;
wire n_105;
wire n_225;
wire n_219;
wire n_132;
wire n_210;
wire n_213;
wire n_59;
wire n_104;
wire n_85;
wire n_106;
wire n_241;
wire n_253;
wire n_289;
wire n_268;
wire n_185;
wire n_249;
wire n_174;
wire n_199;
wire n_229;
wire n_214;
wire n_84;
wire n_103;
wire n_164;
wire n_147;
wire n_123;
wire n_198;
wire n_64;
wire n_188;
wire n_251;
wire n_92;
wire n_285;
wire n_295;
wire n_71;
wire n_258;
wire n_49;
wire n_142;
wire n_190;
wire n_110;
wire n_272;
wire n_118;
wire n_277;
wire n_205;
wire n_261;
wire n_50;
wire n_58;
wire n_108;
wire n_66;
wire n_263;
wire n_95;
wire n_98;
wire n_57;
wire n_134;
wire n_237;
wire n_238;
wire n_72;
wire n_183;
wire n_55;
wire n_281;
wire n_153;
wire n_40;
wire n_124;
wire n_48;
wire n_43;
wire n_158;
wire n_276;
wire n_67;
wire n_54;
wire n_257;
wire n_197;
wire n_227;
wire n_79;
wire n_89;
wire n_45;
wire n_83;
wire n_75;
wire n_165;
wire n_121;
wire n_96;
wire n_235;
wire n_180;
wire n_76;
wire n_171;
wire n_230;
wire n_156;
wire n_90;
wire n_139;
wire n_286;
wire n_151;
wire n_196;
wire n_228;
wire n_189;
wire n_292;
wire n_91;
wire n_305;
wire n_265;
wire n_122;
wire n_61;
wire n_218;
wire n_112;
wire n_310;
wire n_172;
wire n_44;
wire n_52;
wire n_77;
wire n_138;
wire n_248;
wire n_206;
wire n_282;
wire n_162;
wire n_274;
wire n_243;
wire n_46;
wire n_144;
wire n_81;
wire n_269;
wire n_304;
wire n_80;
wire n_208;
wire n_306;
wire n_226;

INVx2_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_3),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_30),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_2),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_18),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_20),
.Y(n_40)
);

CKINVDCx20_ASAP7_75t_R g41 ( 
.A(n_16),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_0),
.Y(n_42)
);

INVxp67_ASAP7_75t_L g43 ( 
.A(n_22),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_32),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_7),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_26),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_15),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_33),
.Y(n_48)
);

INVxp33_ASAP7_75t_L g49 ( 
.A(n_6),
.Y(n_49)
);

BUFx3_ASAP7_75t_L g50 ( 
.A(n_0),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_4),
.Y(n_51)
);

CKINVDCx16_ASAP7_75t_R g52 ( 
.A(n_28),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_5),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_29),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

CKINVDCx5p33_ASAP7_75t_R g56 ( 
.A(n_52),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_52),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_L g58 ( 
.A(n_40),
.B(n_1),
.Y(n_58)
);

CKINVDCx5p33_ASAP7_75t_R g59 ( 
.A(n_41),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_50),
.Y(n_60)
);

CKINVDCx5p33_ASAP7_75t_R g61 ( 
.A(n_46),
.Y(n_61)
);

BUFx10_ASAP7_75t_L g62 ( 
.A(n_37),
.Y(n_62)
);

CKINVDCx5p33_ASAP7_75t_R g63 ( 
.A(n_44),
.Y(n_63)
);

CKINVDCx5p33_ASAP7_75t_R g64 ( 
.A(n_47),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_50),
.Y(n_65)
);

CKINVDCx5p33_ASAP7_75t_R g66 ( 
.A(n_45),
.Y(n_66)
);

CKINVDCx5p33_ASAP7_75t_R g67 ( 
.A(n_45),
.Y(n_67)
);

INVx3_ASAP7_75t_L g68 ( 
.A(n_51),
.Y(n_68)
);

HB1xp67_ASAP7_75t_L g69 ( 
.A(n_51),
.Y(n_69)
);

AND2x2_ASAP7_75t_L g70 ( 
.A(n_49),
.B(n_1),
.Y(n_70)
);

CKINVDCx5p33_ASAP7_75t_R g71 ( 
.A(n_43),
.Y(n_71)
);

CKINVDCx5p33_ASAP7_75t_R g72 ( 
.A(n_43),
.Y(n_72)
);

CKINVDCx5p33_ASAP7_75t_R g73 ( 
.A(n_36),
.Y(n_73)
);

NOR2xp33_ASAP7_75t_L g74 ( 
.A(n_71),
.B(n_36),
.Y(n_74)
);

INVxp67_ASAP7_75t_L g75 ( 
.A(n_66),
.Y(n_75)
);

CKINVDCx5p33_ASAP7_75t_R g76 ( 
.A(n_56),
.Y(n_76)
);

INVxp67_ASAP7_75t_L g77 ( 
.A(n_67),
.Y(n_77)
);

NAND2x1p5_ASAP7_75t_L g78 ( 
.A(n_70),
.B(n_39),
.Y(n_78)
);

INVxp67_ASAP7_75t_L g79 ( 
.A(n_70),
.Y(n_79)
);

INVx2_ASAP7_75t_L g80 ( 
.A(n_68),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_68),
.Y(n_81)
);

AO22x2_ASAP7_75t_L g82 ( 
.A1(n_70),
.A2(n_54),
.B1(n_48),
.B2(n_39),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_69),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_68),
.Y(n_84)
);

OAI21xp33_ASAP7_75t_L g85 ( 
.A1(n_55),
.A2(n_38),
.B(n_35),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_69),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_55),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_60),
.Y(n_88)
);

AND2x6_ASAP7_75t_L g89 ( 
.A(n_60),
.B(n_48),
.Y(n_89)
);

NAND2x1p5_ASAP7_75t_L g90 ( 
.A(n_68),
.B(n_54),
.Y(n_90)
);

NAND2xp5_ASAP7_75t_L g91 ( 
.A(n_72),
.B(n_34),
.Y(n_91)
);

OAI22xp5_ASAP7_75t_L g92 ( 
.A1(n_57),
.A2(n_42),
.B1(n_38),
.B2(n_35),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_65),
.Y(n_93)
);

INVx4_ASAP7_75t_L g94 ( 
.A(n_62),
.Y(n_94)
);

NAND2x1p5_ASAP7_75t_L g95 ( 
.A(n_58),
.B(n_51),
.Y(n_95)
);

AOI22xp33_ASAP7_75t_L g96 ( 
.A1(n_58),
.A2(n_53),
.B1(n_42),
.B2(n_34),
.Y(n_96)
);

AND2x6_ASAP7_75t_L g97 ( 
.A(n_65),
.B(n_34),
.Y(n_97)
);

HB1xp67_ASAP7_75t_L g98 ( 
.A(n_63),
.Y(n_98)
);

BUFx3_ASAP7_75t_L g99 ( 
.A(n_62),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_73),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_62),
.Y(n_101)
);

BUFx6f_ASAP7_75t_L g102 ( 
.A(n_62),
.Y(n_102)
);

BUFx6f_ASAP7_75t_L g103 ( 
.A(n_99),
.Y(n_103)
);

AOI22xp33_ASAP7_75t_SL g104 ( 
.A1(n_82),
.A2(n_61),
.B1(n_59),
.B2(n_64),
.Y(n_104)
);

AOI21xp5_ASAP7_75t_L g105 ( 
.A1(n_101),
.A2(n_53),
.B(n_62),
.Y(n_105)
);

BUFx6f_ASAP7_75t_L g106 ( 
.A(n_99),
.Y(n_106)
);

A2O1A1Ixp33_ASAP7_75t_L g107 ( 
.A1(n_88),
.A2(n_4),
.B(n_3),
.C(n_2),
.Y(n_107)
);

NAND2xp5_ASAP7_75t_L g108 ( 
.A(n_78),
.B(n_79),
.Y(n_108)
);

NOR2xp33_ASAP7_75t_L g109 ( 
.A(n_83),
.B(n_17),
.Y(n_109)
);

INVx3_ASAP7_75t_L g110 ( 
.A(n_90),
.Y(n_110)
);

AOI21xp5_ASAP7_75t_L g111 ( 
.A1(n_101),
.A2(n_21),
.B(n_19),
.Y(n_111)
);

INVx5_ASAP7_75t_L g112 ( 
.A(n_97),
.Y(n_112)
);

O2A1O1Ixp33_ASAP7_75t_L g113 ( 
.A1(n_86),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_113)
);

AOI21xp5_ASAP7_75t_L g114 ( 
.A1(n_91),
.A2(n_24),
.B(n_23),
.Y(n_114)
);

INVxp67_ASAP7_75t_L g115 ( 
.A(n_98),
.Y(n_115)
);

NOR2xp33_ASAP7_75t_L g116 ( 
.A(n_100),
.B(n_31),
.Y(n_116)
);

AOI22xp33_ASAP7_75t_SL g117 ( 
.A1(n_82),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_80),
.Y(n_118)
);

AOI21xp5_ASAP7_75t_L g119 ( 
.A1(n_88),
.A2(n_9),
.B(n_8),
.Y(n_119)
);

AOI21xp5_ASAP7_75t_L g120 ( 
.A1(n_93),
.A2(n_11),
.B(n_10),
.Y(n_120)
);

O2A1O1Ixp33_ASAP7_75t_L g121 ( 
.A1(n_92),
.A2(n_13),
.B(n_12),
.C(n_11),
.Y(n_121)
);

O2A1O1Ixp33_ASAP7_75t_L g122 ( 
.A1(n_78),
.A2(n_14),
.B(n_13),
.C(n_12),
.Y(n_122)
);

BUFx3_ASAP7_75t_L g123 ( 
.A(n_90),
.Y(n_123)
);

AOI21xp5_ASAP7_75t_L g124 ( 
.A1(n_93),
.A2(n_14),
.B(n_87),
.Y(n_124)
);

AND2x2_ASAP7_75t_L g125 ( 
.A(n_75),
.B(n_77),
.Y(n_125)
);

NAND2xp5_ASAP7_75t_L g126 ( 
.A(n_78),
.B(n_94),
.Y(n_126)
);

OR2x6_ASAP7_75t_L g127 ( 
.A(n_82),
.B(n_100),
.Y(n_127)
);

AOI21xp5_ASAP7_75t_L g128 ( 
.A1(n_94),
.A2(n_102),
.B(n_74),
.Y(n_128)
);

INVx2_ASAP7_75t_L g129 ( 
.A(n_80),
.Y(n_129)
);

NAND2x1p5_ASAP7_75t_L g130 ( 
.A(n_94),
.B(n_102),
.Y(n_130)
);

NAND2xp5_ASAP7_75t_L g131 ( 
.A(n_90),
.B(n_82),
.Y(n_131)
);

BUFx6f_ASAP7_75t_L g132 ( 
.A(n_102),
.Y(n_132)
);

A2O1A1Ixp33_ASAP7_75t_L g133 ( 
.A1(n_85),
.A2(n_84),
.B(n_81),
.C(n_96),
.Y(n_133)
);

AOI22xp5_ASAP7_75t_L g134 ( 
.A1(n_127),
.A2(n_131),
.B1(n_117),
.B2(n_108),
.Y(n_134)
);

INVx2_ASAP7_75t_SL g135 ( 
.A(n_123),
.Y(n_135)
);

OAI21x1_ASAP7_75t_L g136 ( 
.A1(n_111),
.A2(n_95),
.B(n_81),
.Y(n_136)
);

OR2x6_ASAP7_75t_L g137 ( 
.A(n_127),
.B(n_95),
.Y(n_137)
);

AND2x2_ASAP7_75t_L g138 ( 
.A(n_127),
.B(n_95),
.Y(n_138)
);

INVx2_ASAP7_75t_L g139 ( 
.A(n_129),
.Y(n_139)
);

INVx1_ASAP7_75t_L g140 ( 
.A(n_118),
.Y(n_140)
);

A2O1A1Ixp33_ASAP7_75t_L g141 ( 
.A1(n_122),
.A2(n_84),
.B(n_102),
.C(n_76),
.Y(n_141)
);

NAND2xp5_ASAP7_75t_L g142 ( 
.A(n_126),
.B(n_89),
.Y(n_142)
);

OAI21x1_ASAP7_75t_L g143 ( 
.A1(n_114),
.A2(n_89),
.B(n_97),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_110),
.Y(n_144)
);

INVx1_ASAP7_75t_SL g145 ( 
.A(n_126),
.Y(n_145)
);

NAND2xp5_ASAP7_75t_L g146 ( 
.A(n_110),
.B(n_89),
.Y(n_146)
);

BUFx3_ASAP7_75t_L g147 ( 
.A(n_132),
.Y(n_147)
);

OAI21x1_ASAP7_75t_L g148 ( 
.A1(n_131),
.A2(n_89),
.B(n_97),
.Y(n_148)
);

OAI21x1_ASAP7_75t_L g149 ( 
.A1(n_128),
.A2(n_124),
.B(n_130),
.Y(n_149)
);

INVx2_ASAP7_75t_L g150 ( 
.A(n_132),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_133),
.Y(n_151)
);

INVx2_ASAP7_75t_L g152 ( 
.A(n_132),
.Y(n_152)
);

OAI21x1_ASAP7_75t_L g153 ( 
.A1(n_105),
.A2(n_89),
.B(n_97),
.Y(n_153)
);

OAI21x1_ASAP7_75t_L g154 ( 
.A1(n_116),
.A2(n_89),
.B(n_97),
.Y(n_154)
);

CKINVDCx5p33_ASAP7_75t_R g155 ( 
.A(n_115),
.Y(n_155)
);

OA21x2_ASAP7_75t_L g156 ( 
.A1(n_119),
.A2(n_97),
.B(n_76),
.Y(n_156)
);

OAI21x1_ASAP7_75t_L g157 ( 
.A1(n_120),
.A2(n_109),
.B(n_113),
.Y(n_157)
);

CKINVDCx16_ASAP7_75t_R g158 ( 
.A(n_137),
.Y(n_158)
);

NAND2xp5_ASAP7_75t_L g159 ( 
.A(n_145),
.B(n_104),
.Y(n_159)
);

CKINVDCx5p33_ASAP7_75t_R g160 ( 
.A(n_155),
.Y(n_160)
);

INVx1_ASAP7_75t_L g161 ( 
.A(n_140),
.Y(n_161)
);

NAND3xp33_ASAP7_75t_L g162 ( 
.A(n_141),
.B(n_107),
.C(n_121),
.Y(n_162)
);

HB1xp67_ASAP7_75t_L g163 ( 
.A(n_155),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_140),
.Y(n_164)
);

HB1xp67_ASAP7_75t_L g165 ( 
.A(n_145),
.Y(n_165)
);

INVx1_ASAP7_75t_L g166 ( 
.A(n_139),
.Y(n_166)
);

BUFx3_ASAP7_75t_L g167 ( 
.A(n_137),
.Y(n_167)
);

INVx2_ASAP7_75t_L g168 ( 
.A(n_139),
.Y(n_168)
);

NAND2xp33_ASAP7_75t_R g169 ( 
.A(n_137),
.B(n_125),
.Y(n_169)
);

AND2x2_ASAP7_75t_L g170 ( 
.A(n_137),
.B(n_103),
.Y(n_170)
);

OR2x6_ASAP7_75t_L g171 ( 
.A(n_137),
.B(n_103),
.Y(n_171)
);

CKINVDCx8_ASAP7_75t_R g172 ( 
.A(n_137),
.Y(n_172)
);

AOI22xp33_ASAP7_75t_L g173 ( 
.A1(n_159),
.A2(n_138),
.B1(n_134),
.B2(n_156),
.Y(n_173)
);

BUFx2_ASAP7_75t_L g174 ( 
.A(n_165),
.Y(n_174)
);

OA21x2_ASAP7_75t_L g175 ( 
.A1(n_162),
.A2(n_151),
.B(n_157),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_166),
.Y(n_176)
);

A2O1A1Ixp33_ASAP7_75t_L g177 ( 
.A1(n_162),
.A2(n_157),
.B(n_134),
.C(n_141),
.Y(n_177)
);

NOR2xp33_ASAP7_75t_L g178 ( 
.A(n_163),
.B(n_138),
.Y(n_178)
);

AOI221xp5_ASAP7_75t_L g179 ( 
.A1(n_159),
.A2(n_138),
.B1(n_151),
.B2(n_144),
.C(n_135),
.Y(n_179)
);

INVx1_ASAP7_75t_L g180 ( 
.A(n_166),
.Y(n_180)
);

INVx1_ASAP7_75t_L g181 ( 
.A(n_161),
.Y(n_181)
);

INVx1_ASAP7_75t_L g182 ( 
.A(n_161),
.Y(n_182)
);

AOI21xp5_ASAP7_75t_L g183 ( 
.A1(n_168),
.A2(n_136),
.B(n_143),
.Y(n_183)
);

OAI21x1_ASAP7_75t_L g184 ( 
.A1(n_168),
.A2(n_143),
.B(n_136),
.Y(n_184)
);

INVxp67_ASAP7_75t_L g185 ( 
.A(n_174),
.Y(n_185)
);

INVx1_ASAP7_75t_L g186 ( 
.A(n_181),
.Y(n_186)
);

BUFx3_ASAP7_75t_L g187 ( 
.A(n_174),
.Y(n_187)
);

AND2x2_ASAP7_75t_L g188 ( 
.A(n_176),
.B(n_164),
.Y(n_188)
);

BUFx2_ASAP7_75t_L g189 ( 
.A(n_184),
.Y(n_189)
);

NAND2xp5_ASAP7_75t_L g190 ( 
.A(n_181),
.B(n_164),
.Y(n_190)
);

A2O1A1Ixp33_ASAP7_75t_L g191 ( 
.A1(n_179),
.A2(n_167),
.B(n_157),
.C(n_135),
.Y(n_191)
);

INVx2_ASAP7_75t_L g192 ( 
.A(n_184),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_176),
.B(n_168),
.Y(n_193)
);

AND2x2_ASAP7_75t_L g194 ( 
.A(n_180),
.B(n_158),
.Y(n_194)
);

INVx1_ASAP7_75t_L g195 ( 
.A(n_182),
.Y(n_195)
);

INVx2_ASAP7_75t_L g196 ( 
.A(n_180),
.Y(n_196)
);

INVx1_ASAP7_75t_SL g197 ( 
.A(n_182),
.Y(n_197)
);

AND2x2_ASAP7_75t_L g198 ( 
.A(n_173),
.B(n_158),
.Y(n_198)
);

NAND2xp5_ASAP7_75t_L g199 ( 
.A(n_178),
.B(n_160),
.Y(n_199)
);

INVx2_ASAP7_75t_L g200 ( 
.A(n_175),
.Y(n_200)
);

OR2x2_ASAP7_75t_L g201 ( 
.A(n_197),
.B(n_175),
.Y(n_201)
);

INVx1_ASAP7_75t_L g202 ( 
.A(n_186),
.Y(n_202)
);

INVx2_ASAP7_75t_L g203 ( 
.A(n_196),
.Y(n_203)
);

INVx2_ASAP7_75t_L g204 ( 
.A(n_196),
.Y(n_204)
);

NAND2xp5_ASAP7_75t_L g205 ( 
.A(n_188),
.B(n_175),
.Y(n_205)
);

INVx1_ASAP7_75t_L g206 ( 
.A(n_186),
.Y(n_206)
);

INVxp67_ASAP7_75t_SL g207 ( 
.A(n_187),
.Y(n_207)
);

INVx1_ASAP7_75t_L g208 ( 
.A(n_195),
.Y(n_208)
);

OR2x2_ASAP7_75t_L g209 ( 
.A(n_197),
.B(n_175),
.Y(n_209)
);

NAND2x1_ASAP7_75t_SL g210 ( 
.A(n_194),
.B(n_156),
.Y(n_210)
);

NAND2xp5_ASAP7_75t_L g211 ( 
.A(n_188),
.B(n_167),
.Y(n_211)
);

OR2x6_ASAP7_75t_L g212 ( 
.A(n_196),
.B(n_171),
.Y(n_212)
);

AND2x2_ASAP7_75t_L g213 ( 
.A(n_193),
.B(n_177),
.Y(n_213)
);

INVx1_ASAP7_75t_SL g214 ( 
.A(n_187),
.Y(n_214)
);

INVx1_ASAP7_75t_L g215 ( 
.A(n_195),
.Y(n_215)
);

OR2x2_ASAP7_75t_L g216 ( 
.A(n_187),
.B(n_167),
.Y(n_216)
);

INVxp67_ASAP7_75t_L g217 ( 
.A(n_199),
.Y(n_217)
);

INVx1_ASAP7_75t_L g218 ( 
.A(n_200),
.Y(n_218)
);

INVx1_ASAP7_75t_L g219 ( 
.A(n_200),
.Y(n_219)
);

INVx2_ASAP7_75t_L g220 ( 
.A(n_200),
.Y(n_220)
);

HB1xp67_ASAP7_75t_L g221 ( 
.A(n_185),
.Y(n_221)
);

INVx2_ASAP7_75t_L g222 ( 
.A(n_192),
.Y(n_222)
);

AND2x2_ASAP7_75t_L g223 ( 
.A(n_213),
.B(n_189),
.Y(n_223)
);

OAI31xp33_ASAP7_75t_L g224 ( 
.A1(n_217),
.A2(n_194),
.A3(n_198),
.B(n_191),
.Y(n_224)
);

NAND2xp5_ASAP7_75t_L g225 ( 
.A(n_202),
.B(n_193),
.Y(n_225)
);

NAND2xp5_ASAP7_75t_L g226 ( 
.A(n_206),
.B(n_198),
.Y(n_226)
);

OAI211xp5_ASAP7_75t_L g227 ( 
.A1(n_221),
.A2(n_172),
.B(n_190),
.C(n_189),
.Y(n_227)
);

NAND2xp5_ASAP7_75t_L g228 ( 
.A(n_208),
.B(n_190),
.Y(n_228)
);

NOR3xp33_ASAP7_75t_L g229 ( 
.A(n_215),
.B(n_135),
.C(n_170),
.Y(n_229)
);

NAND2xp5_ASAP7_75t_L g230 ( 
.A(n_215),
.B(n_183),
.Y(n_230)
);

OAI221xp5_ASAP7_75t_L g231 ( 
.A1(n_210),
.A2(n_169),
.B1(n_172),
.B2(n_144),
.C(n_171),
.Y(n_231)
);

NAND2x1_ASAP7_75t_SL g232 ( 
.A(n_203),
.B(n_192),
.Y(n_232)
);

HB1xp67_ASAP7_75t_L g233 ( 
.A(n_214),
.Y(n_233)
);

INVx2_ASAP7_75t_L g234 ( 
.A(n_220),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_203),
.Y(n_235)
);

INVxp67_ASAP7_75t_L g236 ( 
.A(n_207),
.Y(n_236)
);

NOR2xp33_ASAP7_75t_SL g237 ( 
.A(n_212),
.B(n_216),
.Y(n_237)
);

OAI21xp33_ASAP7_75t_L g238 ( 
.A1(n_210),
.A2(n_192),
.B(n_171),
.Y(n_238)
);

AND2x2_ASAP7_75t_L g239 ( 
.A(n_213),
.B(n_156),
.Y(n_239)
);

CKINVDCx14_ASAP7_75t_R g240 ( 
.A(n_216),
.Y(n_240)
);

NAND2xp5_ASAP7_75t_L g241 ( 
.A(n_211),
.B(n_170),
.Y(n_241)
);

INVx2_ASAP7_75t_L g242 ( 
.A(n_222),
.Y(n_242)
);

INVx2_ASAP7_75t_L g243 ( 
.A(n_222),
.Y(n_243)
);

INVx2_ASAP7_75t_L g244 ( 
.A(n_220),
.Y(n_244)
);

NOR2xp33_ASAP7_75t_L g245 ( 
.A(n_212),
.B(n_171),
.Y(n_245)
);

INVx2_ASAP7_75t_L g246 ( 
.A(n_218),
.Y(n_246)
);

OAI22xp5_ASAP7_75t_L g247 ( 
.A1(n_212),
.A2(n_171),
.B1(n_156),
.B2(n_139),
.Y(n_247)
);

NOR2x1_ASAP7_75t_L g248 ( 
.A(n_212),
.B(n_156),
.Y(n_248)
);

AND2x2_ASAP7_75t_L g249 ( 
.A(n_223),
.B(n_205),
.Y(n_249)
);

NAND2xp5_ASAP7_75t_SL g250 ( 
.A(n_224),
.B(n_204),
.Y(n_250)
);

NAND2xp5_ASAP7_75t_L g251 ( 
.A(n_240),
.B(n_204),
.Y(n_251)
);

INVx1_ASAP7_75t_L g252 ( 
.A(n_246),
.Y(n_252)
);

BUFx2_ASAP7_75t_L g253 ( 
.A(n_236),
.Y(n_253)
);

INVx1_ASAP7_75t_L g254 ( 
.A(n_246),
.Y(n_254)
);

NAND2xp5_ASAP7_75t_SL g255 ( 
.A(n_224),
.B(n_218),
.Y(n_255)
);

AND2x2_ASAP7_75t_L g256 ( 
.A(n_223),
.B(n_219),
.Y(n_256)
);

AND2x2_ASAP7_75t_L g257 ( 
.A(n_239),
.B(n_219),
.Y(n_257)
);

NAND3xp33_ASAP7_75t_L g258 ( 
.A(n_233),
.B(n_209),
.C(n_201),
.Y(n_258)
);

INVx1_ASAP7_75t_SL g259 ( 
.A(n_225),
.Y(n_259)
);

INVx1_ASAP7_75t_L g260 ( 
.A(n_235),
.Y(n_260)
);

OA21x2_ASAP7_75t_L g261 ( 
.A1(n_238),
.A2(n_209),
.B(n_201),
.Y(n_261)
);

NOR2xp33_ASAP7_75t_L g262 ( 
.A(n_226),
.B(n_136),
.Y(n_262)
);

AND2x2_ASAP7_75t_L g263 ( 
.A(n_239),
.B(n_149),
.Y(n_263)
);

INVx1_ASAP7_75t_L g264 ( 
.A(n_235),
.Y(n_264)
);

INVx1_ASAP7_75t_L g265 ( 
.A(n_230),
.Y(n_265)
);

NAND2xp5_ASAP7_75t_SL g266 ( 
.A(n_229),
.B(n_103),
.Y(n_266)
);

OR2x2_ASAP7_75t_L g267 ( 
.A(n_234),
.B(n_244),
.Y(n_267)
);

INVx1_ASAP7_75t_L g268 ( 
.A(n_244),
.Y(n_268)
);

INVx2_ASAP7_75t_L g269 ( 
.A(n_244),
.Y(n_269)
);

INVx1_ASAP7_75t_L g270 ( 
.A(n_234),
.Y(n_270)
);

NAND2xp5_ASAP7_75t_L g271 ( 
.A(n_228),
.B(n_241),
.Y(n_271)
);

AOI211xp5_ASAP7_75t_L g272 ( 
.A1(n_255),
.A2(n_227),
.B(n_231),
.C(n_238),
.Y(n_272)
);

AOI22xp5_ASAP7_75t_L g273 ( 
.A1(n_250),
.A2(n_237),
.B1(n_245),
.B2(n_248),
.Y(n_273)
);

AOI221x1_ASAP7_75t_L g274 ( 
.A1(n_265),
.A2(n_247),
.B1(n_243),
.B2(n_242),
.C(n_232),
.Y(n_274)
);

AOI221xp5_ASAP7_75t_L g275 ( 
.A1(n_265),
.A2(n_237),
.B1(n_243),
.B2(n_242),
.C(n_142),
.Y(n_275)
);

AOI21xp5_ASAP7_75t_L g276 ( 
.A1(n_266),
.A2(n_248),
.B(n_242),
.Y(n_276)
);

AOI221xp5_ASAP7_75t_L g277 ( 
.A1(n_259),
.A2(n_243),
.B1(n_142),
.B2(n_102),
.C(n_146),
.Y(n_277)
);

NAND4xp25_ASAP7_75t_L g278 ( 
.A(n_258),
.B(n_146),
.C(n_232),
.D(n_147),
.Y(n_278)
);

AOI21xp33_ASAP7_75t_L g279 ( 
.A1(n_253),
.A2(n_149),
.B(n_148),
.Y(n_279)
);

NAND4xp25_ASAP7_75t_L g280 ( 
.A(n_253),
.B(n_147),
.C(n_152),
.D(n_150),
.Y(n_280)
);

AOI211xp5_ASAP7_75t_L g281 ( 
.A1(n_251),
.A2(n_271),
.B(n_256),
.C(n_262),
.Y(n_281)
);

NOR4xp25_ASAP7_75t_L g282 ( 
.A(n_260),
.B(n_152),
.C(n_150),
.D(n_148),
.Y(n_282)
);

OAI21x1_ASAP7_75t_SL g283 ( 
.A1(n_261),
.A2(n_152),
.B(n_150),
.Y(n_283)
);

AOI322xp5_ASAP7_75t_L g284 ( 
.A1(n_249),
.A2(n_147),
.A3(n_106),
.B1(n_148),
.B2(n_112),
.C1(n_149),
.C2(n_143),
.Y(n_284)
);

INVx1_ASAP7_75t_L g285 ( 
.A(n_260),
.Y(n_285)
);

OAI221xp5_ASAP7_75t_L g286 ( 
.A1(n_261),
.A2(n_106),
.B1(n_147),
.B2(n_112),
.C(n_154),
.Y(n_286)
);

OAI211xp5_ASAP7_75t_L g287 ( 
.A1(n_261),
.A2(n_154),
.B(n_106),
.C(n_112),
.Y(n_287)
);

AND4x1_ASAP7_75t_L g288 ( 
.A(n_272),
.B(n_256),
.C(n_263),
.D(n_249),
.Y(n_288)
);

OR3x1_ASAP7_75t_L g289 ( 
.A(n_278),
.B(n_264),
.C(n_252),
.Y(n_289)
);

NAND3x1_ASAP7_75t_L g290 ( 
.A(n_273),
.B(n_257),
.C(n_264),
.Y(n_290)
);

OA22x2_ASAP7_75t_L g291 ( 
.A1(n_274),
.A2(n_257),
.B1(n_254),
.B2(n_252),
.Y(n_291)
);

HB1xp67_ASAP7_75t_L g292 ( 
.A(n_285),
.Y(n_292)
);

NOR3xp33_ASAP7_75t_L g293 ( 
.A(n_277),
.B(n_280),
.C(n_286),
.Y(n_293)
);

NAND2xp5_ASAP7_75t_L g294 ( 
.A(n_281),
.B(n_254),
.Y(n_294)
);

NAND2xp5_ASAP7_75t_L g295 ( 
.A(n_276),
.B(n_270),
.Y(n_295)
);

OAI221xp5_ASAP7_75t_L g296 ( 
.A1(n_275),
.A2(n_261),
.B1(n_267),
.B2(n_270),
.C(n_268),
.Y(n_296)
);

A2O1A1Ixp33_ASAP7_75t_L g297 ( 
.A1(n_287),
.A2(n_263),
.B(n_267),
.C(n_268),
.Y(n_297)
);

INVx1_ASAP7_75t_SL g298 ( 
.A(n_294),
.Y(n_298)
);

HB1xp67_ASAP7_75t_L g299 ( 
.A(n_292),
.Y(n_299)
);

INVx3_ASAP7_75t_L g300 ( 
.A(n_288),
.Y(n_300)
);

NAND4xp75_ASAP7_75t_L g301 ( 
.A(n_295),
.B(n_279),
.C(n_269),
.D(n_283),
.Y(n_301)
);

BUFx2_ASAP7_75t_L g302 ( 
.A(n_290),
.Y(n_302)
);

OAI22xp5_ASAP7_75t_L g303 ( 
.A1(n_289),
.A2(n_291),
.B1(n_297),
.B2(n_296),
.Y(n_303)
);

INVx1_ASAP7_75t_L g304 ( 
.A(n_299),
.Y(n_304)
);

INVx1_ASAP7_75t_L g305 ( 
.A(n_298),
.Y(n_305)
);

AND4x1_ASAP7_75t_L g306 ( 
.A(n_300),
.B(n_293),
.C(n_295),
.D(n_282),
.Y(n_306)
);

AOI22xp5_ASAP7_75t_L g307 ( 
.A1(n_300),
.A2(n_303),
.B1(n_302),
.B2(n_301),
.Y(n_307)
);

INVx1_ASAP7_75t_L g308 ( 
.A(n_304),
.Y(n_308)
);

OAI22xp5_ASAP7_75t_L g309 ( 
.A1(n_307),
.A2(n_286),
.B1(n_269),
.B2(n_284),
.Y(n_309)
);

BUFx2_ASAP7_75t_L g310 ( 
.A(n_308),
.Y(n_310)
);

AOI22xp33_ASAP7_75t_L g311 ( 
.A1(n_310),
.A2(n_305),
.B1(n_309),
.B2(n_306),
.Y(n_311)
);

AOI221xp5_ASAP7_75t_L g312 ( 
.A1(n_311),
.A2(n_153),
.B1(n_154),
.B2(n_310),
.C(n_308),
.Y(n_312)
);


endmodule