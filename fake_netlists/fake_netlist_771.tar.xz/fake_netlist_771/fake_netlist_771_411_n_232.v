module fake_netlist_771_411_n_232 (n_0, n_20, n_6, n_29, n_17, n_2, n_12, n_1, n_25, n_31, n_5, n_27, n_33, n_24, n_26, n_18, n_13, n_15, n_11, n_16, n_23, n_28, n_4, n_9, n_8, n_30, n_7, n_10, n_19, n_21, n_3, n_32, n_22, n_14, n_232);

input n_0;
input n_20;
input n_6;
input n_29;
input n_17;
input n_2;
input n_12;
input n_1;
input n_25;
input n_31;
input n_5;
input n_27;
input n_33;
input n_24;
input n_26;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_28;
input n_4;
input n_9;
input n_8;
input n_30;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_32;
input n_22;
input n_14;

output n_232;

wire n_37;
wire n_221;
wire n_183;
wire n_55;
wire n_36;
wire n_116;
wire n_63;
wire n_140;
wire n_153;
wire n_65;
wire n_35;
wire n_100;
wire n_40;
wire n_73;
wire n_119;
wire n_101;
wire n_42;
wire n_105;
wire n_124;
wire n_187;
wire n_186;
wire n_107;
wire n_48;
wire n_43;
wire n_158;
wire n_68;
wire n_231;
wire n_67;
wire n_225;
wire n_222;
wire n_184;
wire n_54;
wire n_179;
wire n_127;
wire n_219;
wire n_132;
wire n_166;
wire n_210;
wire n_213;
wire n_197;
wire n_59;
wire n_53;
wire n_227;
wire n_79;
wire n_181;
wire n_74;
wire n_146;
wire n_104;
wire n_85;
wire n_51;
wire n_89;
wire n_106;
wire n_168;
wire n_182;
wire n_178;
wire n_102;
wire n_143;
wire n_207;
wire n_45;
wire n_224;
wire n_83;
wire n_201;
wire n_220;
wire n_62;
wire n_75;
wire n_165;
wire n_216;
wire n_117;
wire n_121;
wire n_96;
wire n_169;
wire n_180;
wire n_185;
wire n_76;
wire n_174;
wire n_199;
wire n_204;
wire n_148;
wire n_175;
wire n_128;
wire n_202;
wire n_229;
wire n_88;
wire n_171;
wire n_214;
wire n_84;
wire n_195;
wire n_155;
wire n_217;
wire n_230;
wire n_156;
wire n_152;
wire n_90;
wire n_103;
wire n_126;
wire n_139;
wire n_151;
wire n_147;
wire n_164;
wire n_82;
wire n_86;
wire n_129;
wire n_123;
wire n_196;
wire n_150;
wire n_198;
wire n_177;
wire n_176;
wire n_64;
wire n_228;
wire n_188;
wire n_167;
wire n_92;
wire n_189;
wire n_91;
wire n_70;
wire n_125;
wire n_69;
wire n_137;
wire n_71;
wire n_209;
wire n_212;
wire n_215;
wire n_145;
wire n_133;
wire n_49;
wire n_194;
wire n_142;
wire n_109;
wire n_122;
wire n_56;
wire n_61;
wire n_78;
wire n_218;
wire n_112;
wire n_161;
wire n_157;
wire n_190;
wire n_110;
wire n_203;
wire n_118;
wire n_111;
wire n_149;
wire n_170;
wire n_47;
wire n_200;
wire n_205;
wire n_163;
wire n_172;
wire n_159;
wire n_44;
wire n_52;
wire n_77;
wire n_138;
wire n_130;
wire n_160;
wire n_206;
wire n_58;
wire n_50;
wire n_108;
wire n_162;
wire n_97;
wire n_66;
wire n_173;
wire n_94;
wire n_141;
wire n_34;
wire n_39;
wire n_211;
wire n_46;
wire n_154;
wire n_136;
wire n_193;
wire n_135;
wire n_144;
wire n_113;
wire n_114;
wire n_81;
wire n_95;
wire n_98;
wire n_223;
wire n_38;
wire n_80;
wire n_99;
wire n_191;
wire n_87;
wire n_192;
wire n_60;
wire n_115;
wire n_57;
wire n_120;
wire n_208;
wire n_134;
wire n_93;
wire n_131;
wire n_226;
wire n_41;
wire n_72;

INVx1_ASAP7_75t_L g34 ( 
.A(n_15),
.Y(n_34)
);

INVxp67_ASAP7_75t_SL g35 ( 
.A(n_24),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_30),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_8),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_18),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_2),
.Y(n_40)
);

CKINVDCx20_ASAP7_75t_R g41 ( 
.A(n_8),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_7),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_29),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_13),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_9),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_3),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_19),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_7),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_6),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_34),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_34),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_SL g52 ( 
.A(n_36),
.B(n_47),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_36),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_47),
.Y(n_54)
);

INVx3_ASAP7_75t_L g55 ( 
.A(n_45),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_38),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_39),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_45),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_40),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_59)
);

NOR2xp67_ASAP7_75t_L g60 ( 
.A(n_55),
.B(n_40),
.Y(n_60)
);

OR2x6_ASAP7_75t_L g61 ( 
.A(n_59),
.B(n_55),
.Y(n_61)
);

AND2x2_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_43),
.Y(n_62)
);

INVx2_ASAP7_75t_L g63 ( 
.A(n_55),
.Y(n_63)
);

AND2x4_ASAP7_75t_L g64 ( 
.A(n_50),
.B(n_37),
.Y(n_64)
);

NAND2xp5_ASAP7_75t_SL g65 ( 
.A(n_50),
.B(n_43),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_53),
.Y(n_66)
);

AO22x2_ASAP7_75t_L g67 ( 
.A1(n_51),
.A2(n_46),
.B1(n_44),
.B2(n_42),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_53),
.Y(n_68)
);

OAI21xp33_ASAP7_75t_L g69 ( 
.A1(n_51),
.A2(n_49),
.B(n_35),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_58),
.Y(n_70)
);

AND2x2_ASAP7_75t_L g71 ( 
.A(n_62),
.B(n_54),
.Y(n_71)
);

AND2x2_ASAP7_75t_L g72 ( 
.A(n_62),
.B(n_54),
.Y(n_72)
);

NOR2xp67_ASAP7_75t_L g73 ( 
.A(n_66),
.B(n_63),
.Y(n_73)
);

CKINVDCx5p33_ASAP7_75t_R g74 ( 
.A(n_61),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_63),
.Y(n_75)
);

AND3x1_ASAP7_75t_SL g76 ( 
.A(n_61),
.B(n_48),
.C(n_41),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_66),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_70),
.Y(n_78)
);

AND2x2_ASAP7_75t_L g79 ( 
.A(n_64),
.B(n_56),
.Y(n_79)
);

NAND2xp5_ASAP7_75t_SL g80 ( 
.A(n_60),
.B(n_56),
.Y(n_80)
);

OAI221xp5_ASAP7_75t_L g81 ( 
.A1(n_61),
.A2(n_57),
.B1(n_52),
.B2(n_0),
.C(n_1),
.Y(n_81)
);

OAI22xp5_ASAP7_75t_L g82 ( 
.A1(n_61),
.A2(n_57),
.B1(n_4),
.B2(n_3),
.Y(n_82)
);

HB1xp67_ASAP7_75t_L g83 ( 
.A(n_67),
.Y(n_83)
);

BUFx6f_ASAP7_75t_L g84 ( 
.A(n_68),
.Y(n_84)
);

BUFx3_ASAP7_75t_L g85 ( 
.A(n_83),
.Y(n_85)
);

HB1xp67_ASAP7_75t_L g86 ( 
.A(n_83),
.Y(n_86)
);

HB1xp67_ASAP7_75t_L g87 ( 
.A(n_71),
.Y(n_87)
);

NOR2x2_ASAP7_75t_L g88 ( 
.A(n_76),
.B(n_61),
.Y(n_88)
);

AND2x2_ASAP7_75t_L g89 ( 
.A(n_72),
.B(n_64),
.Y(n_89)
);

AND2x2_ASAP7_75t_L g90 ( 
.A(n_72),
.B(n_64),
.Y(n_90)
);

NAND2xp5_ASAP7_75t_L g91 ( 
.A(n_71),
.B(n_78),
.Y(n_91)
);

INVx2_ASAP7_75t_SL g92 ( 
.A(n_78),
.Y(n_92)
);

OA21x2_ASAP7_75t_L g93 ( 
.A1(n_77),
.A2(n_70),
.B(n_68),
.Y(n_93)
);

NAND2xp5_ASAP7_75t_L g94 ( 
.A(n_79),
.B(n_64),
.Y(n_94)
);

OR2x2_ASAP7_75t_L g95 ( 
.A(n_74),
.B(n_65),
.Y(n_95)
);

NAND2xp5_ASAP7_75t_L g96 ( 
.A(n_79),
.B(n_67),
.Y(n_96)
);

NAND2xp5_ASAP7_75t_L g97 ( 
.A(n_77),
.B(n_75),
.Y(n_97)
);

BUFx6f_ASAP7_75t_L g98 ( 
.A(n_84),
.Y(n_98)
);

HB1xp67_ASAP7_75t_L g99 ( 
.A(n_87),
.Y(n_99)
);

INVxp67_ASAP7_75t_L g100 ( 
.A(n_91),
.Y(n_100)
);

OA21x2_ASAP7_75t_L g101 ( 
.A1(n_97),
.A2(n_80),
.B(n_81),
.Y(n_101)
);

OR2x2_ASAP7_75t_L g102 ( 
.A(n_91),
.B(n_82),
.Y(n_102)
);

OR2x2_ASAP7_75t_L g103 ( 
.A(n_89),
.B(n_82),
.Y(n_103)
);

O2A1O1Ixp33_ASAP7_75t_L g104 ( 
.A1(n_96),
.A2(n_81),
.B(n_69),
.C(n_75),
.Y(n_104)
);

OR2x6_ASAP7_75t_L g105 ( 
.A(n_85),
.B(n_67),
.Y(n_105)
);

AND2x2_ASAP7_75t_L g106 ( 
.A(n_89),
.B(n_67),
.Y(n_106)
);

AND2x2_ASAP7_75t_L g107 ( 
.A(n_90),
.B(n_73),
.Y(n_107)
);

AOI221xp5_ASAP7_75t_L g108 ( 
.A1(n_90),
.A2(n_76),
.B1(n_84),
.B2(n_73),
.C(n_4),
.Y(n_108)
);

NOR2x1_ASAP7_75t_SL g109 ( 
.A(n_92),
.B(n_84),
.Y(n_109)
);

OA21x2_ASAP7_75t_L g110 ( 
.A1(n_97),
.A2(n_84),
.B(n_14),
.Y(n_110)
);

OAI21x1_ASAP7_75t_L g111 ( 
.A1(n_110),
.A2(n_93),
.B(n_96),
.Y(n_111)
);

NOR2xp33_ASAP7_75t_L g112 ( 
.A(n_100),
.B(n_95),
.Y(n_112)
);

AOI21xp5_ASAP7_75t_L g113 ( 
.A1(n_102),
.A2(n_92),
.B(n_93),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_107),
.Y(n_114)
);

OR2x2_ASAP7_75t_L g115 ( 
.A(n_103),
.B(n_93),
.Y(n_115)
);

A2O1A1Ixp33_ASAP7_75t_L g116 ( 
.A1(n_108),
.A2(n_92),
.B(n_85),
.C(n_94),
.Y(n_116)
);

INVx1_ASAP7_75t_SL g117 ( 
.A(n_105),
.Y(n_117)
);

INVx2_ASAP7_75t_L g118 ( 
.A(n_109),
.Y(n_118)
);

INVx2_ASAP7_75t_L g119 ( 
.A(n_109),
.Y(n_119)
);

NAND2xp5_ASAP7_75t_L g120 ( 
.A(n_106),
.B(n_94),
.Y(n_120)
);

INVx3_ASAP7_75t_L g121 ( 
.A(n_118),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_115),
.Y(n_122)
);

INVx2_ASAP7_75t_L g123 ( 
.A(n_111),
.Y(n_123)
);

INVx1_ASAP7_75t_L g124 ( 
.A(n_115),
.Y(n_124)
);

AND2x4_ASAP7_75t_L g125 ( 
.A(n_118),
.B(n_105),
.Y(n_125)
);

AOI21xp33_ASAP7_75t_SL g126 ( 
.A1(n_119),
.A2(n_105),
.B(n_102),
.Y(n_126)
);

INVx2_ASAP7_75t_L g127 ( 
.A(n_111),
.Y(n_127)
);

INVx5_ASAP7_75t_L g128 ( 
.A(n_119),
.Y(n_128)
);

INVx1_ASAP7_75t_L g129 ( 
.A(n_114),
.Y(n_129)
);

NAND2xp5_ASAP7_75t_L g130 ( 
.A(n_129),
.B(n_112),
.Y(n_130)
);

AOI22xp33_ASAP7_75t_L g131 ( 
.A1(n_125),
.A2(n_108),
.B1(n_117),
.B2(n_103),
.Y(n_131)
);

OR2x2_ASAP7_75t_L g132 ( 
.A(n_122),
.B(n_117),
.Y(n_132)
);

OR2x2_ASAP7_75t_L g133 ( 
.A(n_122),
.B(n_114),
.Y(n_133)
);

AND2x2_ASAP7_75t_L g134 ( 
.A(n_124),
.B(n_93),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_129),
.Y(n_135)
);

AND2x4_ASAP7_75t_L g136 ( 
.A(n_124),
.B(n_121),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_123),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_123),
.Y(n_138)
);

AO21x2_ASAP7_75t_L g139 ( 
.A1(n_126),
.A2(n_127),
.B(n_123),
.Y(n_139)
);

AND2x2_ASAP7_75t_L g140 ( 
.A(n_121),
.B(n_93),
.Y(n_140)
);

INVx1_ASAP7_75t_SL g141 ( 
.A(n_128),
.Y(n_141)
);

INVx1_ASAP7_75t_SL g142 ( 
.A(n_128),
.Y(n_142)
);

INVx2_ASAP7_75t_L g143 ( 
.A(n_137),
.Y(n_143)
);

AND2x2_ASAP7_75t_L g144 ( 
.A(n_136),
.B(n_127),
.Y(n_144)
);

INVx3_ASAP7_75t_L g145 ( 
.A(n_139),
.Y(n_145)
);

NAND2xp5_ASAP7_75t_L g146 ( 
.A(n_130),
.B(n_128),
.Y(n_146)
);

NOR2xp33_ASAP7_75t_L g147 ( 
.A(n_133),
.B(n_99),
.Y(n_147)
);

AND2x2_ASAP7_75t_L g148 ( 
.A(n_136),
.B(n_127),
.Y(n_148)
);

CKINVDCx5p33_ASAP7_75t_R g149 ( 
.A(n_142),
.Y(n_149)
);

AND2x4_ASAP7_75t_L g150 ( 
.A(n_136),
.B(n_121),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_135),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_135),
.Y(n_152)
);

NAND2xp5_ASAP7_75t_L g153 ( 
.A(n_133),
.B(n_134),
.Y(n_153)
);

AOI22x1_ASAP7_75t_L g154 ( 
.A1(n_142),
.A2(n_121),
.B1(n_125),
.B2(n_113),
.Y(n_154)
);

NAND2xp5_ASAP7_75t_L g155 ( 
.A(n_134),
.B(n_128),
.Y(n_155)
);

NAND2xp5_ASAP7_75t_L g156 ( 
.A(n_132),
.B(n_128),
.Y(n_156)
);

NOR2xp33_ASAP7_75t_L g157 ( 
.A(n_132),
.B(n_95),
.Y(n_157)
);

AND2x2_ASAP7_75t_L g158 ( 
.A(n_136),
.B(n_125),
.Y(n_158)
);

NOR2xp33_ASAP7_75t_L g159 ( 
.A(n_141),
.B(n_5),
.Y(n_159)
);

NAND2xp5_ASAP7_75t_L g160 ( 
.A(n_140),
.B(n_126),
.Y(n_160)
);

AND2x4_ASAP7_75t_SL g161 ( 
.A(n_140),
.B(n_125),
.Y(n_161)
);

AOI21xp5_ASAP7_75t_L g162 ( 
.A1(n_155),
.A2(n_116),
.B(n_131),
.Y(n_162)
);

AND2x2_ASAP7_75t_L g163 ( 
.A(n_144),
.B(n_139),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_151),
.Y(n_164)
);

BUFx2_ASAP7_75t_L g165 ( 
.A(n_149),
.Y(n_165)
);

OR2x2_ASAP7_75t_L g166 ( 
.A(n_153),
.B(n_137),
.Y(n_166)
);

AND2x2_ASAP7_75t_L g167 ( 
.A(n_144),
.B(n_148),
.Y(n_167)
);

INVx1_ASAP7_75t_L g168 ( 
.A(n_151),
.Y(n_168)
);

NOR2x1p5_ASAP7_75t_L g169 ( 
.A(n_160),
.B(n_125),
.Y(n_169)
);

INVx1_ASAP7_75t_SL g170 ( 
.A(n_161),
.Y(n_170)
);

NOR2xp33_ASAP7_75t_L g171 ( 
.A(n_147),
.B(n_146),
.Y(n_171)
);

NAND2xp5_ASAP7_75t_L g172 ( 
.A(n_152),
.B(n_138),
.Y(n_172)
);

NAND2xp5_ASAP7_75t_L g173 ( 
.A(n_152),
.B(n_138),
.Y(n_173)
);

AOI22xp5_ASAP7_75t_L g174 ( 
.A1(n_157),
.A2(n_105),
.B1(n_106),
.B2(n_128),
.Y(n_174)
);

OAI22xp33_ASAP7_75t_L g175 ( 
.A1(n_160),
.A2(n_128),
.B1(n_105),
.B2(n_110),
.Y(n_175)
);

NAND2xp5_ASAP7_75t_L g176 ( 
.A(n_158),
.B(n_139),
.Y(n_176)
);

NAND2xp5_ASAP7_75t_SL g177 ( 
.A(n_154),
.B(n_143),
.Y(n_177)
);

OA21x2_ASAP7_75t_L g178 ( 
.A1(n_154),
.A2(n_120),
.B(n_110),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_143),
.Y(n_179)
);

NAND2xp5_ASAP7_75t_L g180 ( 
.A(n_158),
.B(n_5),
.Y(n_180)
);

INVx1_ASAP7_75t_L g181 ( 
.A(n_143),
.Y(n_181)
);

NAND2xp5_ASAP7_75t_L g182 ( 
.A(n_148),
.B(n_6),
.Y(n_182)
);

OR2x2_ASAP7_75t_L g183 ( 
.A(n_156),
.B(n_9),
.Y(n_183)
);

AOI211xp5_ASAP7_75t_L g184 ( 
.A1(n_170),
.A2(n_159),
.B(n_150),
.C(n_145),
.Y(n_184)
);

NAND2xp5_ASAP7_75t_L g185 ( 
.A(n_171),
.B(n_150),
.Y(n_185)
);

AND2x2_ASAP7_75t_L g186 ( 
.A(n_167),
.B(n_161),
.Y(n_186)
);

NAND2xp5_ASAP7_75t_L g187 ( 
.A(n_171),
.B(n_150),
.Y(n_187)
);

HB1xp67_ASAP7_75t_L g188 ( 
.A(n_163),
.Y(n_188)
);

NAND3xp33_ASAP7_75t_L g189 ( 
.A(n_180),
.B(n_145),
.C(n_150),
.Y(n_189)
);

NAND2xp5_ASAP7_75t_L g190 ( 
.A(n_166),
.B(n_161),
.Y(n_190)
);

NOR2x1_ASAP7_75t_L g191 ( 
.A(n_165),
.B(n_145),
.Y(n_191)
);

INVx1_ASAP7_75t_L g192 ( 
.A(n_164),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_168),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_172),
.Y(n_194)
);

INVx1_ASAP7_75t_L g195 ( 
.A(n_173),
.Y(n_195)
);

XNOR2xp5_ASAP7_75t_L g196 ( 
.A(n_169),
.B(n_88),
.Y(n_196)
);

NAND2xp5_ASAP7_75t_L g197 ( 
.A(n_162),
.B(n_145),
.Y(n_197)
);

NAND2xp5_ASAP7_75t_L g198 ( 
.A(n_167),
.B(n_10),
.Y(n_198)
);

NAND2xp5_ASAP7_75t_L g199 ( 
.A(n_163),
.B(n_179),
.Y(n_199)
);

NOR3xp33_ASAP7_75t_L g200 ( 
.A(n_182),
.B(n_104),
.C(n_107),
.Y(n_200)
);

AND2x2_ASAP7_75t_L g201 ( 
.A(n_176),
.B(n_110),
.Y(n_201)
);

NOR2x1_ASAP7_75t_L g202 ( 
.A(n_183),
.B(n_85),
.Y(n_202)
);

INVx1_ASAP7_75t_L g203 ( 
.A(n_181),
.Y(n_203)
);

NOR3xp33_ASAP7_75t_SL g204 ( 
.A(n_198),
.B(n_175),
.C(n_177),
.Y(n_204)
);

AOI22xp5_ASAP7_75t_L g205 ( 
.A1(n_196),
.A2(n_185),
.B1(n_187),
.B2(n_200),
.Y(n_205)
);

AOI21xp5_ASAP7_75t_L g206 ( 
.A1(n_184),
.A2(n_177),
.B(n_175),
.Y(n_206)
);

OAI21xp33_ASAP7_75t_L g207 ( 
.A1(n_197),
.A2(n_174),
.B(n_86),
.Y(n_207)
);

AOI211xp5_ASAP7_75t_L g208 ( 
.A1(n_189),
.A2(n_12),
.B(n_11),
.C(n_10),
.Y(n_208)
);

AOI221xp5_ASAP7_75t_L g209 ( 
.A1(n_188),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.C(n_84),
.Y(n_209)
);

OAI221xp5_ASAP7_75t_L g210 ( 
.A1(n_196),
.A2(n_178),
.B1(n_101),
.B2(n_84),
.C(n_98),
.Y(n_210)
);

NAND2xp5_ASAP7_75t_L g211 ( 
.A(n_194),
.B(n_178),
.Y(n_211)
);

AOI221xp5_ASAP7_75t_L g212 ( 
.A1(n_188),
.A2(n_178),
.B1(n_98),
.B2(n_101),
.C(n_16),
.Y(n_212)
);

NAND2x1p5_ASAP7_75t_L g213 ( 
.A(n_202),
.B(n_101),
.Y(n_213)
);

NAND2xp5_ASAP7_75t_L g214 ( 
.A(n_195),
.B(n_101),
.Y(n_214)
);

NAND4xp25_ASAP7_75t_L g215 ( 
.A(n_191),
.B(n_21),
.C(n_20),
.D(n_17),
.Y(n_215)
);

OAI211xp5_ASAP7_75t_SL g216 ( 
.A1(n_190),
.A2(n_25),
.B(n_23),
.C(n_22),
.Y(n_216)
);

INVx1_ASAP7_75t_L g217 ( 
.A(n_211),
.Y(n_217)
);

NAND2x1p5_ASAP7_75t_L g218 ( 
.A(n_206),
.B(n_186),
.Y(n_218)
);

OR5x1_ASAP7_75t_L g219 ( 
.A(n_215),
.B(n_204),
.C(n_216),
.D(n_205),
.E(n_207),
.Y(n_219)
);

NAND2x1p5_ASAP7_75t_L g220 ( 
.A(n_208),
.B(n_186),
.Y(n_220)
);

INVx1_ASAP7_75t_L g221 ( 
.A(n_214),
.Y(n_221)
);

AOI21xp33_ASAP7_75t_L g222 ( 
.A1(n_209),
.A2(n_193),
.B(n_192),
.Y(n_222)
);

AND2x2_ASAP7_75t_L g223 ( 
.A(n_213),
.B(n_199),
.Y(n_223)
);

BUFx2_ASAP7_75t_L g224 ( 
.A(n_212),
.Y(n_224)
);

AOI31xp33_ASAP7_75t_SL g225 ( 
.A1(n_219),
.A2(n_210),
.A3(n_201),
.B(n_203),
.Y(n_225)
);

OAI22xp5_ASAP7_75t_L g226 ( 
.A1(n_218),
.A2(n_201),
.B1(n_98),
.B2(n_26),
.Y(n_226)
);

OAI22xp5_ASAP7_75t_L g227 ( 
.A1(n_218),
.A2(n_98),
.B1(n_31),
.B2(n_27),
.Y(n_227)
);

AOI22xp33_ASAP7_75t_L g228 ( 
.A1(n_224),
.A2(n_98),
.B1(n_33),
.B2(n_32),
.Y(n_228)
);

XNOR2xp5_ASAP7_75t_L g229 ( 
.A(n_226),
.B(n_220),
.Y(n_229)
);

OAI322xp33_ASAP7_75t_L g230 ( 
.A1(n_227),
.A2(n_220),
.A3(n_217),
.B1(n_221),
.B2(n_225),
.C1(n_223),
.C2(n_222),
.Y(n_230)
);

INVx1_ASAP7_75t_L g231 ( 
.A(n_229),
.Y(n_231)
);

AOI221xp5_ASAP7_75t_L g232 ( 
.A1(n_231),
.A2(n_230),
.B1(n_222),
.B2(n_228),
.C(n_98),
.Y(n_232)
);


endmodule