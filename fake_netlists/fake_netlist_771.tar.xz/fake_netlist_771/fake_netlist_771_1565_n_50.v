module fake_netlist_771_1565_n_50 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_50);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_50;

wire n_37;
wire n_45;
wire n_44;
wire n_47;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_49;
wire n_43;
wire n_48;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_41;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_12),
.Y(n_23)
);

OA21x2_ASAP7_75t_L g24 ( 
.A1(n_1),
.A2(n_7),
.B(n_22),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_11),
.B(n_10),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_13),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_2),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_4),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_19),
.B1(n_3),
.B2(n_0),
.Y(n_33)
);

BUFx8_ASAP7_75t_SL g34 ( 
.A(n_26),
.Y(n_34)
);

OR2x6_ASAP7_75t_L g35 ( 
.A(n_25),
.B(n_5),
.Y(n_35)
);

A2O1A1Ixp33_ASAP7_75t_L g36 ( 
.A1(n_29),
.A2(n_32),
.B(n_30),
.C(n_28),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_25),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_23),
.B1(n_27),
.B2(n_24),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_33),
.B1(n_24),
.B2(n_34),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_8),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_9),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_14),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_40),
.Y(n_43)
);

INVx1_ASAP7_75t_SL g44 ( 
.A(n_41),
.Y(n_44)
);

OAI221xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_17),
.B1(n_16),
.B2(n_18),
.C(n_21),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

OR2x2_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_48),
.Y(n_50)
);


endmodule