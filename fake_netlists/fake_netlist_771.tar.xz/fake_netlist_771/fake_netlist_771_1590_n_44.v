module fake_netlist_771_1590_n_44 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_44);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_44;

wire n_37;
wire n_20;
wire n_36;
wire n_29;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_43;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_41;
wire n_32;
wire n_22;

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_19),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_5),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_19),
.Y(n_23)
);

AND2x6_ASAP7_75t_L g24 ( 
.A(n_15),
.B(n_18),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_17),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_22),
.A2(n_18),
.B1(n_16),
.B2(n_0),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_27),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_28),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_28),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_31),
.B(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_29),
.B(n_21),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_26),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_36),
.B(n_24),
.Y(n_39)
);

AOI322xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_16),
.A3(n_24),
.B1(n_4),
.B2(n_6),
.C1(n_1),
.C2(n_2),
.Y(n_40)
);

NAND3xp33_ASAP7_75t_SL g41 ( 
.A(n_40),
.B(n_24),
.C(n_7),
.Y(n_41)
);

BUFx6f_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI22x1_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_43),
.A2(n_41),
.B1(n_13),
.B2(n_12),
.Y(n_44)
);


endmodule