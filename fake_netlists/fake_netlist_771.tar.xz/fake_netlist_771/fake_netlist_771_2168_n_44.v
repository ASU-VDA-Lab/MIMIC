module fake_netlist_771_2168_n_44 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_44);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_44;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_43;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_41;
wire n_32;
wire n_22;

NOR2xp67_ASAP7_75t_L g20 ( 
.A(n_1),
.B(n_12),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_10),
.B(n_5),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_7),
.B(n_6),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_4),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_15),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_22),
.B(n_16),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_SL g31 ( 
.A(n_23),
.B(n_18),
.C(n_16),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_20),
.Y(n_32)
);

OAI21xp5_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_21),
.B(n_25),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_31),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_27),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_32),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_27),
.Y(n_37)
);

NAND3xp33_ASAP7_75t_SL g38 ( 
.A(n_37),
.B(n_28),
.C(n_24),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_30),
.C(n_18),
.Y(n_39)
);

BUFx6f_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

O2A1O1Ixp33_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_19),
.B(n_2),
.C(n_0),
.Y(n_41)
);

INVxp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

OAI22x1_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_19),
.B1(n_13),
.B2(n_8),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_43),
.A2(n_17),
.B1(n_41),
.B2(n_42),
.Y(n_44)
);


endmodule