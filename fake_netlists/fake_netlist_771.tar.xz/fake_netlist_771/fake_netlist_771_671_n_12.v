module fake_netlist_771_671_n_12 (n_1, n_2, n_3, n_0, n_12);

input n_1;
input n_2;
input n_3;
input n_0;

output n_12;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_9;
wire n_4;
wire n_8;

INVx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

CKINVDCx6p67_ASAP7_75t_R g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

NOR2x1_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_3),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.Y(n_9)
);

AOI21xp33_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_2),
.B(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_6),
.B1(n_8),
.B2(n_1),
.Y(n_12)
);


endmodule