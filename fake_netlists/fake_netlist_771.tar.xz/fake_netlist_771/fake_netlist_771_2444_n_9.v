module fake_netlist_771_2444_n_9 (n_1, n_2, n_3, n_0, n_9);

input n_1;
input n_2;
input n_3;
input n_0;

output n_9;

wire n_7;
wire n_5;
wire n_6;
wire n_4;
wire n_8;

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_3),
.Y(n_4)
);

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_0),
.A2(n_3),
.B1(n_1),
.B2(n_2),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

OAI32xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.A3(n_5),
.B1(n_0),
.B2(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AOI222xp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C1(n_6),
.C2(n_7),
.Y(n_9)
);


endmodule