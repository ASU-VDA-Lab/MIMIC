module fake_netlist_771_1571_n_50 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_50);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_50;

wire n_37;
wire n_45;
wire n_44;
wire n_47;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_48;
wire n_43;
wire n_49;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_41;
wire n_32;
wire n_22;

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_6),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_0),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_3),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_12),
.B(n_7),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_26),
.A2(n_17),
.B1(n_16),
.B2(n_2),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_22),
.B(n_26),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_22),
.B(n_26),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_29),
.B1(n_28),
.B2(n_27),
.Y(n_35)
);

NOR2x1_ASAP7_75t_SL g36 ( 
.A(n_33),
.B(n_27),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_31),
.B1(n_34),
.B2(n_28),
.C(n_25),
.Y(n_37)
);

OAI321xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_30),
.A3(n_23),
.B1(n_22),
.B2(n_29),
.C(n_2),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_29),
.B1(n_21),
.B2(n_22),
.Y(n_39)
);

NAND2xp33_ASAP7_75t_R g40 ( 
.A(n_38),
.B(n_29),
.Y(n_40)
);

AOI211xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_38),
.B(n_23),
.C(n_30),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_30),
.B1(n_24),
.B2(n_36),
.C(n_16),
.Y(n_43)
);

OAI322xp33_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_18),
.A3(n_17),
.B1(n_19),
.B2(n_20),
.C1(n_5),
.C2(n_8),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_14),
.B(n_11),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_45),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_47),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_44),
.B1(n_19),
.B2(n_18),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_48),
.A2(n_20),
.B1(n_46),
.B2(n_49),
.Y(n_50)
);


endmodule