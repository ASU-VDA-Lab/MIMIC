module fake_netlist_771_1220_n_45 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_45);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_45;

wire n_37;
wire n_44;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_43;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_41;
wire n_32;
wire n_22;

AOI21x1_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_5),
.B(n_15),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_8),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_17),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_19),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_0),
.Y(n_27)
);

INVxp67_ASAP7_75t_SL g28 ( 
.A(n_2),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_R g29 ( 
.A(n_20),
.B(n_11),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_18),
.C(n_16),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_28),
.B1(n_29),
.B2(n_22),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_32),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_30),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_34),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

OAI21xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_23),
.B(n_21),
.Y(n_38)
);

AOI211xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_27),
.B(n_23),
.C(n_24),
.Y(n_39)
);

OAI21xp33_ASAP7_75t_SL g40 ( 
.A1(n_37),
.A2(n_38),
.B(n_1),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_4),
.B1(n_3),
.B2(n_6),
.C(n_7),
.Y(n_41)
);

BUFx6f_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_9),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_13),
.B1(n_14),
.B2(n_44),
.Y(n_45)
);


endmodule