module fake_netlist_744_1574_n_32 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_32);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_32;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_16;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_29;

INVxp67_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_10),
.B(n_7),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_SL g20 ( 
.A1(n_0),
.A2(n_3),
.B1(n_15),
.B2(n_11),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_9),
.B(n_1),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_16),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_21),
.B1(n_26),
.B2(n_20),
.C(n_19),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_17),
.B(n_12),
.Y(n_30)
);

AO22x2_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_17),
.B1(n_5),
.B2(n_4),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_7),
.B1(n_14),
.B2(n_13),
.Y(n_32)
);


endmodule