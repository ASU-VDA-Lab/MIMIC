module fake_netlist_744_3272_n_27 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_27);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_27;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_24;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_15;

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_9),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_3),
.B(n_12),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_2),
.A2(n_4),
.B1(n_0),
.B2(n_10),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_5),
.B(n_8),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_1),
.B(n_6),
.Y(n_19)
);

AO32x2_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_6),
.A3(n_7),
.B1(n_16),
.B2(n_17),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_13),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_20),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_15),
.Y(n_27)
);


endmodule