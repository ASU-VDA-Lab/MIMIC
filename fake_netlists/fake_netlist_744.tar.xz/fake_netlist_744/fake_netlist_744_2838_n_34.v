module fake_netlist_744_2838_n_34 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_8, n_34);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_34;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_9;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_12;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_1),
.B(n_2),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_7),
.B(n_6),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.Y(n_16)
);

AOI21x1_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_6),
.B(n_0),
.Y(n_17)
);

INVx4_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_11),
.B1(n_10),
.B2(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_11),
.C(n_10),
.D(n_15),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_20),
.B1(n_12),
.B2(n_1),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_24),
.B1(n_22),
.B2(n_4),
.C(n_5),
.Y(n_27)
);

OAI21xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_8),
.B(n_4),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

XOR2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_8),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.B1(n_29),
.B2(n_32),
.Y(n_34)
);


endmodule