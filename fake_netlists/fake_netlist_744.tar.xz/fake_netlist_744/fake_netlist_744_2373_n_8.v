module fake_netlist_744_2373_n_8 (n_0, n_2, n_1, n_8);

input n_0;
input n_2;
input n_1;

output n_8;

wire n_3;
wire n_4;
wire n_5;
wire n_7;
wire n_6;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

NOR3xp33_ASAP7_75t_SL g4 ( 
.A(n_1),
.B(n_2),
.C(n_0),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

AOI22xp5_ASAP7_75t_SL g8 ( 
.A1(n_7),
.A2(n_2),
.B1(n_4),
.B2(n_6),
.Y(n_8)
);


endmodule