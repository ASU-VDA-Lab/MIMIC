module fake_netlist_744_301_n_26 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_26);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_24;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

NAND3xp33_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_13),
.C(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_0),
.B(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx5_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

AO31x2_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_7),
.A3(n_6),
.B(n_1),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_4),
.B(n_3),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_20),
.C(n_14),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_16),
.C(n_19),
.D(n_7),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_18),
.B1(n_9),
.B2(n_8),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_18),
.Y(n_26)
);


endmodule