module fake_netlist_744_2655_n_12 (n_0, n_2, n_1, n_12);

input n_0;
input n_2;
input n_1;

output n_12;

wire n_3;
wire n_11;
wire n_9;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

NAND3xp33_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.C(n_0),
.Y(n_3)
);

INVx4_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.Y(n_8)
);

NAND4xp25_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_3),
.C(n_4),
.D(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);


endmodule