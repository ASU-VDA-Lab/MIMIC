module fake_netlist_744_159_n_23 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_23);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_23;

wire n_20;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;

INVx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

CKINVDCx16_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_10),
.B(n_9),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.Y(n_18)
);

OAI322xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.A3(n_4),
.B1(n_2),
.B2(n_0),
.C1(n_6),
.C2(n_5),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_13),
.B1(n_15),
.B2(n_4),
.C(n_5),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_7),
.B1(n_15),
.B2(n_18),
.Y(n_23)
);


endmodule