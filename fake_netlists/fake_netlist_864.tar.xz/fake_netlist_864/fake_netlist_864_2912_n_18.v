module fake_netlist_864_2912_n_18 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_18);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_18;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_5),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_SL g13 ( 
.A1(n_10),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_10),
.B1(n_12),
.B2(n_11),
.C(n_4),
.Y(n_16)
);

AOI31xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_7),
.A3(n_6),
.B(n_0),
.Y(n_17)
);

AOI21xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_3),
.B(n_2),
.Y(n_18)
);


endmodule