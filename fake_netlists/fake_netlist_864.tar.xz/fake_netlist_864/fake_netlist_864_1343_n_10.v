module fake_netlist_864_1343_n_10 (n_2, n_0, n_1, n_10);

input n_2;
input n_0;
input n_1;

output n_10;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_8;

BUFx4f_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

AOI22xp33_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

NAND3xp33_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_4),
.C(n_3),
.Y(n_8)
);

NAND2xp33_ASAP7_75t_SL g9 ( 
.A(n_8),
.B(n_1),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_0),
.B1(n_2),
.B2(n_7),
.Y(n_10)
);


endmodule