module fake_netlist_864_2047_n_19 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_19);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx5_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_1),
.A2(n_2),
.B1(n_6),
.B2(n_5),
.Y(n_12)
);

OAI22x1_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_7),
.B1(n_5),
.B2(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OR3x1_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.C(n_4),
.Y(n_17)
);

OA22x2_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_7),
.B1(n_10),
.B2(n_8),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_10),
.B(n_16),
.Y(n_19)
);


endmodule