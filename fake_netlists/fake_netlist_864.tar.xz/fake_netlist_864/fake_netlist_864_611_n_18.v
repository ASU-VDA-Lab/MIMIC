module fake_netlist_864_611_n_18 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_18);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_18;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;
wire n_9;

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_2),
.B(n_7),
.Y(n_10)
);

AND2x6_ASAP7_75t_L g11 ( 
.A(n_4),
.B(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVxp67_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI32xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.A3(n_9),
.B1(n_11),
.B2(n_4),
.Y(n_15)
);

AO22x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_6),
.B2(n_11),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI31xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_16),
.A3(n_8),
.B(n_1),
.Y(n_18)
);


endmodule