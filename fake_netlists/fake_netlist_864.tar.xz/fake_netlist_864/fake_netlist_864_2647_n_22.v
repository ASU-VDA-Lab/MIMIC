module fake_netlist_864_2647_n_22 (n_2, n_0, n_3, n_1, n_22);

input n_2;
input n_0;
input n_3;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_4;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

CKINVDCx16_ASAP7_75t_R g8 ( 
.A(n_6),
.Y(n_8)
);

AOI21x1_ASAP7_75t_SL g9 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_7),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

AOI21xp33_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_5),
.B(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

NOR3x1_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_3),
.C(n_2),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_14),
.Y(n_18)
);

NAND4xp75_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_10),
.C(n_5),
.D(n_2),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_9),
.B1(n_3),
.B2(n_2),
.Y(n_20)
);

XNOR2xp5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_9),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B(n_20),
.Y(n_22)
);


endmodule