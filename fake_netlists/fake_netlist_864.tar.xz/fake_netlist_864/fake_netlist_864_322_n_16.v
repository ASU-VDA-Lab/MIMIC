module fake_netlist_864_322_n_16 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_16);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_15;
wire n_13;
wire n_14;
wire n_12;
wire n_10;
wire n_11;
wire n_9;
wire n_8;

INVx1_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_7),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_1),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_9),
.B1(n_11),
.B2(n_7),
.C(n_0),
.Y(n_14)
);

NAND2x1p5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_2),
.B1(n_3),
.B2(n_9),
.C(n_14),
.Y(n_16)
);


endmodule