module fake_netlist_864_1212_n_19 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_19);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

INVxp67_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

BUFx8_ASAP7_75t_SL g12 ( 
.A(n_9),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_3),
.B(n_4),
.Y(n_13)
);

AO21x2_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_5),
.B(n_1),
.Y(n_14)
);

OAI33xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.A3(n_11),
.B1(n_13),
.B2(n_12),
.B3(n_1),
.Y(n_15)
);

AOI32xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.A3(n_13),
.B1(n_10),
.B2(n_14),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B1(n_7),
.B2(n_5),
.C1(n_6),
.C2(n_0),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);


endmodule