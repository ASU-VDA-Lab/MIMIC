module fake_netlist_864_2639_n_22 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_22);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;

OAI21xp33_ASAP7_75t_L g12 ( 
.A1(n_3),
.A2(n_11),
.B(n_10),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_0),
.A2(n_1),
.B1(n_6),
.B2(n_9),
.Y(n_13)
);

AND2x6_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_7),
.Y(n_14)
);

AND2x2_ASAP7_75t_SL g15 ( 
.A(n_5),
.B(n_2),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_4),
.B(n_2),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_14),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_13),
.B1(n_16),
.B2(n_14),
.Y(n_19)
);

OAI22x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_18),
.B1(n_5),
.B2(n_4),
.Y(n_20)
);

NAND2x1p5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_14),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_7),
.B(n_6),
.Y(n_22)
);


endmodule