module fake_netlist_838_49_n_39 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_39);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_39;

wire n_25;
wire n_36;
wire n_22;
wire n_34;
wire n_23;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_18),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_14),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_R g27 ( 
.A(n_5),
.B(n_11),
.Y(n_27)
);

INVx3_ASAP7_75t_SL g28 ( 
.A(n_25),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_22),
.A2(n_16),
.B(n_9),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_29),
.B(n_27),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_31),
.B(n_27),
.C(n_21),
.Y(n_32)
);

OAI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_30),
.B1(n_26),
.B2(n_23),
.Y(n_33)
);

OAI21xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_24),
.B(n_10),
.Y(n_34)
);

OAI21xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_10),
.B(n_20),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_20),
.B1(n_15),
.B2(n_8),
.C(n_17),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_19),
.B1(n_7),
.B2(n_4),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_38),
.B1(n_3),
.B2(n_0),
.Y(n_39)
);


endmodule