module fake_netlist_838_1737_n_17 (n_2, n_0, n_3, n_1, n_17);

input n_2;
input n_0;
input n_3;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_0),
.B(n_2),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_4),
.B(n_5),
.Y(n_8)
);

OAI33xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_4),
.A3(n_5),
.B1(n_6),
.B2(n_0),
.B3(n_3),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI21xp33_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_4),
.B(n_0),
.Y(n_11)
);

AOI211xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_6),
.B(n_7),
.C(n_3),
.Y(n_12)
);

OAI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_6),
.B1(n_2),
.B2(n_3),
.C(n_1),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_SL g14 ( 
.A(n_11),
.B(n_2),
.C(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx5_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B1(n_15),
.B2(n_5),
.C1(n_4),
.C2(n_9),
.Y(n_17)
);


endmodule