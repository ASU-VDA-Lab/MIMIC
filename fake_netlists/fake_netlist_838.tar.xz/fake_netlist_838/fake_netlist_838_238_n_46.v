module fake_netlist_838_238_n_46 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_46);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_46;

wire n_25;
wire n_36;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_43;
wire n_45;

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

OAI22xp33_ASAP7_75t_L g25 ( 
.A1(n_3),
.A2(n_8),
.B1(n_9),
.B2(n_14),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_10),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_22),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_15),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_0),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_24),
.B(n_22),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_24),
.B(n_21),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_30),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_32),
.Y(n_37)
);

OAI21xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_34),
.B(n_35),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_36),
.B(n_35),
.C(n_29),
.Y(n_39)
);

AOI322xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_23),
.A3(n_28),
.B1(n_37),
.B2(n_25),
.C1(n_35),
.C2(n_27),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_11),
.B1(n_17),
.B2(n_18),
.C(n_16),
.Y(n_41)
);

NOR2xp67_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_20),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_11),
.B1(n_13),
.B2(n_12),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_2),
.B1(n_7),
.B2(n_5),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_44),
.B1(n_1),
.B2(n_19),
.Y(n_46)
);


endmodule