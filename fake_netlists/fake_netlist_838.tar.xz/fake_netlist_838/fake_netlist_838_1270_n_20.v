module fake_netlist_838_1270_n_20 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_20);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_11;

BUFx2_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

INVx5_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_5),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_1),
.B(n_10),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_2),
.B(n_0),
.Y(n_15)
);

OAI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND5xp2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_2),
.C(n_0),
.D(n_12),
.E(n_8),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.B1(n_7),
.B2(n_9),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_4),
.B(n_6),
.Y(n_20)
);


endmodule