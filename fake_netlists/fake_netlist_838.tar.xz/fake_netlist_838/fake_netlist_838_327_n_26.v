module fake_netlist_838_327_n_26 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_26);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;
wire n_11;

AND2x4_ASAP7_75t_L g11 ( 
.A(n_3),
.B(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_4),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_16),
.B(n_13),
.Y(n_17)
);

OAI22x1_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_18)
);

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_14),
.B(n_11),
.Y(n_19)
);

AO31x2_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_11),
.A3(n_14),
.B(n_2),
.Y(n_20)
);

INVx2_ASAP7_75t_SL g21 ( 
.A(n_17),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AO21x1_ASAP7_75t_SL g23 ( 
.A1(n_20),
.A2(n_11),
.B(n_19),
.Y(n_23)
);

OAI21xp33_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_20),
.B(n_17),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_23),
.B1(n_14),
.B2(n_20),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_14),
.B1(n_1),
.B2(n_23),
.C1(n_9),
.C2(n_6),
.Y(n_26)
);


endmodule