module fake_netlist_838_189_n_16 (n_2, n_0, n_3, n_1, n_16);

input n_2;
input n_0;
input n_3;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

BUFx2_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B1(n_3),
.B2(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_4),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

NOR4xp25_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.C(n_2),
.D(n_3),
.Y(n_10)
);

AOI322xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_3),
.C1(n_6),
.C2(n_4),
.Y(n_11)
);

AOI21xp33_ASAP7_75t_SL g12 ( 
.A1(n_10),
.A2(n_0),
.B(n_1),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_0),
.B(n_1),
.C(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_11),
.B(n_1),
.Y(n_15)
);

XNOR2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);


endmodule