module fake_netlist_838_352_n_43 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_43);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_43;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_15),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_8),
.B(n_3),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_1),
.B(n_13),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_10),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_8),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_6),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_16),
.Y(n_28)
);

A2O1A1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_19),
.A2(n_18),
.B(n_16),
.C(n_17),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_19),
.B(n_18),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

NOR2x1_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_19),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_29),
.B1(n_21),
.B2(n_20),
.Y(n_35)
);

OAI222xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_22),
.B1(n_27),
.B2(n_25),
.C1(n_23),
.C2(n_17),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_19),
.B1(n_23),
.B2(n_9),
.Y(n_37)
);

OAI22xp33_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_11),
.B1(n_5),
.B2(n_7),
.Y(n_38)
);

NOR2x1_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_14),
.Y(n_39)
);

NOR2x1_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_4),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_39),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_2),
.B1(n_42),
.B2(n_40),
.Y(n_43)
);


endmodule