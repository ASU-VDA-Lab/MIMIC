module fake_netlist_838_728_n_30 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_30);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_18;
wire n_21;
wire n_27;

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_5),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_1),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_21),
.B(n_20),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_17),
.B1(n_15),
.B2(n_8),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_17),
.B1(n_15),
.B2(n_8),
.C1(n_16),
.C2(n_13),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_23),
.B1(n_16),
.B2(n_10),
.C(n_14),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_2),
.B1(n_6),
.B2(n_0),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_3),
.B1(n_7),
.B2(n_12),
.Y(n_30)
);


endmodule