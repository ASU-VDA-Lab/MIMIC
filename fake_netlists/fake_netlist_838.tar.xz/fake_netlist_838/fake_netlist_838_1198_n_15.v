module fake_netlist_838_1198_n_15 (n_2, n_0, n_1, n_15);

input n_2;
input n_0;
input n_1;

output n_15;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

HB1xp67_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

AND2x2_ASAP7_75t_SL g4 ( 
.A(n_0),
.B(n_1),
.Y(n_4)
);

OA21x2_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_0),
.B(n_1),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_0),
.B(n_1),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

INVxp67_ASAP7_75t_SL g8 ( 
.A(n_5),
.Y(n_8)
);

OAI322xp33_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_4),
.A3(n_6),
.B1(n_0),
.B2(n_1),
.C1(n_2),
.C2(n_5),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_5),
.Y(n_10)
);

AOI211xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_7),
.B(n_8),
.C(n_5),
.Y(n_11)
);

AOI322xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_0),
.A3(n_2),
.B1(n_5),
.B2(n_7),
.C1(n_8),
.C2(n_4),
.Y(n_12)
);

AO221x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_0),
.B1(n_2),
.B2(n_7),
.C(n_11),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_2),
.B1(n_7),
.B2(n_10),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_7),
.B(n_13),
.Y(n_15)
);


endmodule