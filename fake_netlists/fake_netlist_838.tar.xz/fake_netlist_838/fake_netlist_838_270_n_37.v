module fake_netlist_838_270_n_37 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_37);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_37;

wire n_25;
wire n_20;
wire n_36;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_27;

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_15),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_9),
.B(n_1),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

AND2x6_ASAP7_75t_L g20 ( 
.A(n_3),
.B(n_11),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_14),
.Y(n_23)
);

BUFx12f_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_7),
.B1(n_13),
.B2(n_12),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_19),
.B(n_7),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_22),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_27),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_25),
.C(n_21),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_31),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

NAND3x1_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_20),
.C(n_18),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_6),
.Y(n_35)
);

NAND2x1_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_10),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_2),
.B1(n_5),
.B2(n_16),
.Y(n_37)
);


endmodule