module fake_netlist_838_1505_n_49 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_49);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_49;

wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_41;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_11),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_4),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_18),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_15),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_3),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_23),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_29),
.A2(n_16),
.B(n_17),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_10),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_26),
.B(n_24),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_36),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_34),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_32),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

A2O1A1Ixp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_28),
.B(n_27),
.C(n_33),
.Y(n_41)
);

OAI32xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_30),
.A3(n_25),
.B1(n_13),
.B2(n_9),
.Y(n_42)
);

O2A1O1Ixp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_21),
.B(n_20),
.C(n_7),
.Y(n_43)
);

NAND3xp33_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_1),
.C(n_5),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_44),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_43),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_19),
.Y(n_47)
);

OAI21xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_6),
.B(n_8),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_47),
.B1(n_0),
.B2(n_2),
.Y(n_49)
);


endmodule