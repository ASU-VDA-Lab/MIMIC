module fake_netlist_838_1635_n_36 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_36);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_36;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_16),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_10),
.Y(n_23)
);

OAI21xp33_ASAP7_75t_L g24 ( 
.A1(n_18),
.A2(n_15),
.B(n_14),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_16),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_18),
.A2(n_19),
.B(n_21),
.C(n_17),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_SL g27 ( 
.A1(n_24),
.A2(n_20),
.B(n_7),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_14),
.Y(n_28)
);

OR2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_27),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_26),
.Y(n_30)
);

OAI222xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_30),
.B1(n_22),
.B2(n_23),
.C1(n_15),
.C2(n_7),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_30),
.B(n_13),
.C(n_8),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_32),
.Y(n_34)
);

OAI22x1_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_9),
.B1(n_4),
.B2(n_3),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_34),
.B1(n_1),
.B2(n_12),
.Y(n_36)
);


endmodule