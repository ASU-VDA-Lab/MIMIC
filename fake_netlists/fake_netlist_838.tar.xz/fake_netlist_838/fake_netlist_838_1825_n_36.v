module fake_netlist_838_1825_n_36 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_36);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_36;

wire n_25;
wire n_20;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_9),
.B(n_7),
.Y(n_24)
);

BUFx10_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_18),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_14),
.B(n_11),
.Y(n_27)
);

BUFx10_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

OR2x2_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_20),
.Y(n_29)
);

NAND4xp25_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_22),
.C(n_24),
.D(n_25),
.Y(n_30)
);

AOI211xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_19),
.B(n_28),
.C(n_25),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_17),
.B(n_16),
.C(n_8),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_2),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_33),
.B1(n_10),
.B2(n_13),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_1),
.B1(n_6),
.B2(n_5),
.Y(n_36)
);


endmodule