module fake_netlist_808_1568_n_17 (n_4, n_2, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

AND2x2_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

CKINVDCx8_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

CKINVDCx6p67_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_1),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_5),
.C(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_8),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_12)
);

OAI221xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_8),
.B1(n_9),
.B2(n_1),
.C(n_2),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_9),
.B1(n_1),
.B2(n_3),
.C(n_4),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OAI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_11),
.B2(n_14),
.Y(n_17)
);


endmodule