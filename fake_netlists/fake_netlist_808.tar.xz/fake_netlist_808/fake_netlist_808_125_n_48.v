module fake_netlist_808_125_n_48 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_48);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_48;

wire n_25;
wire n_36;
wire n_47;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

OA21x2_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_18),
.B(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_7),
.B(n_0),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_11),
.Y(n_27)
);

NAND2x1_ASAP7_75t_L g28 ( 
.A(n_16),
.B(n_5),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_13),
.Y(n_29)
);

AND2x4_ASAP7_75t_SL g30 ( 
.A(n_26),
.B(n_1),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_19),
.B1(n_4),
.B2(n_3),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_25),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

AOI21xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_29),
.B(n_27),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

NAND2xp33_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_31),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_30),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_21),
.B1(n_28),
.B2(n_24),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_21),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_6),
.A3(n_8),
.B1(n_12),
.B2(n_14),
.C1(n_17),
.C2(n_47),
.Y(n_48)
);


endmodule