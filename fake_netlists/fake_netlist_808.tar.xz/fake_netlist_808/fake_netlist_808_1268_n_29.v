module fake_netlist_808_1268_n_29 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_29);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_29;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

INVxp67_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_5),
.B(n_1),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_3),
.B(n_10),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_5),
.B(n_13),
.Y(n_18)
);

AOI21x1_ASAP7_75t_L g19 ( 
.A1(n_9),
.A2(n_7),
.B(n_2),
.Y(n_19)
);

AOI21x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_8),
.B(n_6),
.Y(n_20)
);

AOI21xp33_ASAP7_75t_L g21 ( 
.A1(n_15),
.A2(n_11),
.B(n_1),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_14),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_16),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_22),
.Y(n_24)
);

NOR4xp25_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_16),
.C(n_17),
.D(n_18),
.Y(n_25)
);

O2A1O1Ixp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_23),
.B(n_20),
.C(n_19),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_23),
.B1(n_12),
.B2(n_4),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.B1(n_26),
.B2(n_12),
.Y(n_29)
);


endmodule