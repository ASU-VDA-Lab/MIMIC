module fake_netlist_808_1643_n_24 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_24);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_24;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

BUFx2_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

BUFx10_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_L g15 ( 
.A1(n_4),
.A2(n_2),
.B1(n_6),
.B2(n_10),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

NOR2x1p5_ASAP7_75t_L g17 ( 
.A(n_7),
.B(n_12),
.Y(n_17)
);

NOR2x1_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_7),
.Y(n_18)
);

OR2x6_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_0),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_13),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_15),
.B1(n_14),
.B2(n_18),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_11),
.B1(n_5),
.B2(n_1),
.Y(n_24)
);


endmodule