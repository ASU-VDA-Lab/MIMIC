module fake_netlist_808_901_n_17 (n_4, n_2, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

AND2x2_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_4),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

AND2x6_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_2),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OAI22xp33_ASAP7_75t_L g10 ( 
.A1(n_5),
.A2(n_2),
.B1(n_4),
.B2(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NOR3xp33_ASAP7_75t_SL g12 ( 
.A(n_10),
.B(n_5),
.C(n_3),
.Y(n_12)
);

NAND2x1p5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_6),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_11),
.B2(n_6),
.Y(n_14)
);

NOR2x1_ASAP7_75t_SL g15 ( 
.A(n_13),
.B(n_8),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B1(n_14),
.B2(n_13),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_R g17 ( 
.A1(n_16),
.A2(n_8),
.B1(n_12),
.B2(n_14),
.Y(n_17)
);


endmodule