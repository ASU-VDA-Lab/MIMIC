module fake_netlist_808_1025_n_59 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_59);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_59;

wire n_49;
wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_26;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_30;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_15),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_9),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_4),
.B(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_1),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_L g30 ( 
.A(n_19),
.B(n_23),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_SL g31 ( 
.A(n_2),
.B(n_12),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_0),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_8),
.B(n_20),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_21),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_6),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_16),
.Y(n_38)
);

BUFx3_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_26),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_37),
.A2(n_30),
.B(n_33),
.Y(n_42)
);

OAI22xp33_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_27),
.B1(n_31),
.B2(n_25),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_39),
.B1(n_40),
.B2(n_27),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_32),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_42),
.Y(n_47)
);

AOI21xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_36),
.B(n_29),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

AOI31xp33_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_28),
.A3(n_17),
.B(n_16),
.Y(n_50)
);

BUFx6f_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

CKINVDCx20_ASAP7_75t_R g52 ( 
.A(n_48),
.Y(n_52)
);

OAI222xp33_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_24),
.B1(n_18),
.B2(n_7),
.C1(n_5),
.C2(n_3),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

AO22x2_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_24),
.B1(n_18),
.B2(n_10),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_56),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

AOI322xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_13),
.A3(n_14),
.B1(n_51),
.B2(n_52),
.C1(n_55),
.C2(n_58),
.Y(n_59)
);


endmodule