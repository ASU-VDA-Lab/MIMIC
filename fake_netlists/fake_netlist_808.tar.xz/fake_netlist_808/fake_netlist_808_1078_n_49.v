module fake_netlist_808_1078_n_49 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_49);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_49;

wire n_48;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_10),
.B(n_12),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_20),
.B(n_0),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_SL g31 ( 
.A(n_28),
.B(n_22),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_21),
.B1(n_26),
.B2(n_25),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_19),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_21),
.B1(n_30),
.B2(n_29),
.Y(n_34)
);

AO21x2_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_18),
.B(n_3),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_31),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_21),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

O2A1O1Ixp33_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_35),
.B(n_18),
.C(n_30),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

O2A1O1Ixp5_ASAP7_75t_SL g42 ( 
.A1(n_38),
.A2(n_30),
.B(n_9),
.C(n_8),
.Y(n_42)
);

OAI22xp33_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_16),
.B1(n_15),
.B2(n_1),
.Y(n_43)
);

NAND3xp33_ASAP7_75t_SL g44 ( 
.A(n_41),
.B(n_40),
.C(n_1),
.Y(n_44)
);

NAND4xp25_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_17),
.C(n_16),
.D(n_15),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_17),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_47),
.B1(n_46),
.B2(n_11),
.Y(n_49)
);


endmodule