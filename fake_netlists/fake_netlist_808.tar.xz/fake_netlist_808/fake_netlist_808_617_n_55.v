module fake_netlist_808_617_n_55 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_55);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_55;

wire n_48;
wire n_49;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_26;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_5),
.B(n_2),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_12),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_21),
.B(n_4),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_3),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_22),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_16),
.A2(n_19),
.B1(n_11),
.B2(n_23),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_8),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

XOR2xp5_ASAP7_75t_L g36 ( 
.A(n_30),
.B(n_25),
.Y(n_36)
);

INVx8_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_30),
.Y(n_38)
);

BUFx8_ASAP7_75t_L g39 ( 
.A(n_32),
.Y(n_39)
);

OAI211xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_35),
.B(n_26),
.C(n_34),
.Y(n_40)
);

OAI22xp33_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_28),
.B1(n_33),
.B2(n_29),
.Y(n_41)
);

OAI22xp33_ASAP7_75t_L g42 ( 
.A1(n_37),
.A2(n_27),
.B1(n_25),
.B2(n_0),
.Y(n_42)
);

INVx4_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_41),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_40),
.Y(n_45)
);

NAND2xp33_ASAP7_75t_SL g46 ( 
.A(n_44),
.B(n_39),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_36),
.B(n_1),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_7),
.B(n_6),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_10),
.B(n_9),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_50),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_SL g55 ( 
.A1(n_53),
.A2(n_18),
.B1(n_20),
.B2(n_54),
.Y(n_55)
);


endmodule