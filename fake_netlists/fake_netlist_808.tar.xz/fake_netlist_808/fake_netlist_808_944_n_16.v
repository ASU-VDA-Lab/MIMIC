module fake_netlist_808_944_n_16 (n_4, n_2, n_5, n_3, n_0, n_1, n_16);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_9;
wire n_14;
wire n_11;
wire n_12;
wire n_8;

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_2),
.A2(n_5),
.B1(n_0),
.B2(n_1),
.Y(n_6)
);

CKINVDCx14_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_3),
.A2(n_2),
.B(n_5),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_6),
.Y(n_14)
);

NAND4xp75_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_9),
.C(n_1),
.D(n_4),
.Y(n_15)
);

AOI31xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_9),
.A3(n_11),
.B(n_15),
.Y(n_16)
);


endmodule