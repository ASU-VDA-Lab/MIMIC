module fake_netlist_808_1041_n_50 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_50);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_50;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_19),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_7),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_5),
.B(n_6),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_2),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_1),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_24),
.B(n_18),
.C(n_16),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_25),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_29),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_35),
.B1(n_32),
.B2(n_29),
.Y(n_38)
);

AOI31xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_22),
.A3(n_26),
.B(n_23),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

NAND2xp33_ASAP7_75t_SL g41 ( 
.A(n_39),
.B(n_31),
.Y(n_41)
);

INVxp67_ASAP7_75t_SL g42 ( 
.A(n_40),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_30),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI221x1_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_26),
.B1(n_28),
.B2(n_34),
.C(n_27),
.Y(n_45)
);

NAND4xp25_ASAP7_75t_SL g46 ( 
.A(n_45),
.B(n_18),
.C(n_16),
.D(n_0),
.Y(n_46)
);

OAI322xp33_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_37),
.A3(n_33),
.B1(n_9),
.B2(n_10),
.C1(n_4),
.C2(n_8),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

NOR3xp33_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_12),
.C(n_11),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_48),
.A2(n_49),
.B1(n_15),
.B2(n_13),
.Y(n_50)
);


endmodule