module fake_netlist_808_3_n_4 (n_0, n_4);

input n_0;

output n_4;

wire n_2;
wire n_3;
wire n_1;

BUFx3_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

AND2x2_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

AOI21xp33_ASAP7_75t_L g3 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);


endmodule