module fake_netlist_808_1148_n_12 (n_2, n_0, n_3, n_1, n_12);

input n_2;
input n_0;
input n_3;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_9;
wire n_11;
wire n_8;

AOI22xp33_ASAP7_75t_L g4 ( 
.A1(n_1),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_3),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_SL g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_6),
.B1(n_7),
.B2(n_4),
.Y(n_9)
);

O2A1O1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_3),
.C(n_2),
.Y(n_10)
);

INVx4_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_2),
.B(n_10),
.Y(n_12)
);


endmodule