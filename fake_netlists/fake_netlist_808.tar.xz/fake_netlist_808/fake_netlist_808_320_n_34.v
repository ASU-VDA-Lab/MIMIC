module fake_netlist_808_320_n_34 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_34);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_15),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_2),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_7),
.B(n_11),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_4),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_19),
.B1(n_17),
.B2(n_20),
.C(n_18),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI322xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_26),
.A3(n_23),
.B1(n_20),
.B2(n_17),
.C1(n_4),
.C2(n_5),
.Y(n_30)
);

OAI22xp33_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_20),
.B1(n_6),
.B2(n_5),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_30),
.B(n_16),
.C(n_0),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_16),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.A3(n_10),
.B1(n_9),
.B2(n_1),
.C1(n_14),
.C2(n_12),
.Y(n_34)
);


endmodule