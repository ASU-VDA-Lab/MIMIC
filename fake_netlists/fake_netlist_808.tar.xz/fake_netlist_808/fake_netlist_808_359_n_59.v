module fake_netlist_808_359_n_59 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_59);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_59;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_44;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_30;
wire n_18;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

BUFx3_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_7),
.B(n_16),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_1),
.A2(n_15),
.B1(n_14),
.B2(n_10),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_16),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_0),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

BUFx12f_ASAP7_75t_SL g33 ( 
.A(n_25),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_23),
.Y(n_34)
);

BUFx12f_ASAP7_75t_L g35 ( 
.A(n_25),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_25),
.Y(n_37)
);

AO21x2_ASAP7_75t_L g38 ( 
.A1(n_31),
.A2(n_22),
.B(n_24),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_18),
.Y(n_39)
);

AOI21xp5_ASAP7_75t_L g40 ( 
.A1(n_29),
.A2(n_26),
.B(n_20),
.Y(n_40)
);

AOI21x1_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_30),
.B(n_33),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

AOI321xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_27),
.A3(n_20),
.B1(n_35),
.B2(n_5),
.C(n_0),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_R g44 ( 
.A(n_36),
.B(n_34),
.Y(n_44)
);

INVx3_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_38),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

NOR2x1_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_39),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

OAI33xp33_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_36),
.A3(n_33),
.B1(n_27),
.B2(n_29),
.B3(n_17),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_46),
.Y(n_51)
);

OAI311xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_45),
.A3(n_48),
.B1(n_17),
.C1(n_29),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

BUFx2_ASAP7_75t_L g54 ( 
.A(n_49),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

BUFx6f_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

NOR4xp25_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_49),
.C(n_29),
.D(n_3),
.Y(n_57)
);

OAI221xp5_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_11),
.B1(n_12),
.B2(n_13),
.C(n_55),
.Y(n_58)
);

AOI22xp33_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_56),
.B1(n_50),
.B2(n_51),
.Y(n_59)
);


endmodule