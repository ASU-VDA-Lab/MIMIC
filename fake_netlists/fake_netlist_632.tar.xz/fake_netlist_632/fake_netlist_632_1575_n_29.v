module fake_netlist_632_1575_n_29 (n_5, n_0, n_1, n_4, n_3, n_2, n_6, n_29);

input n_5;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;
input n_6;

output n_29;

wire n_18;
wire n_13;
wire n_7;
wire n_25;
wire n_10;
wire n_20;
wire n_22;
wire n_11;
wire n_9;
wire n_15;
wire n_23;
wire n_8;
wire n_12;
wire n_14;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

INVx2_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_4),
.B(n_1),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_SL g14 ( 
.A(n_10),
.B(n_4),
.Y(n_14)
);

A2O1A1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_7),
.B(n_9),
.C(n_8),
.Y(n_15)
);

BUFx10_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_7),
.B1(n_9),
.B2(n_6),
.Y(n_17)
);

INVx4_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_17),
.B1(n_15),
.B2(n_13),
.C1(n_12),
.C2(n_18),
.Y(n_21)
);

NAND4xp25_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_6),
.C(n_2),
.D(n_0),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_16),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_16),
.B1(n_6),
.B2(n_2),
.C(n_3),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_16),
.B1(n_5),
.B2(n_3),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

OAI22xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_5),
.B1(n_26),
.B2(n_28),
.Y(n_29)
);


endmodule