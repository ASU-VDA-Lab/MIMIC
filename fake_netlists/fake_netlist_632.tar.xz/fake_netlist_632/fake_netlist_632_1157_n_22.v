module fake_netlist_632_1157_n_22 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_11, n_22);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_11;

output n_22;

wire n_18;
wire n_13;
wire n_20;
wire n_15;
wire n_14;
wire n_21;
wire n_17;
wire n_16;
wire n_19;

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_6),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_SL g17 ( 
.A1(n_13),
.A2(n_5),
.B(n_4),
.C(n_1),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.B1(n_16),
.B2(n_14),
.C(n_1),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_14),
.B1(n_5),
.B2(n_4),
.Y(n_20)
);

OAI21xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_7),
.B(n_0),
.Y(n_21)
);

OAI321xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_3),
.A3(n_2),
.B1(n_8),
.B2(n_11),
.C(n_10),
.Y(n_22)
);


endmodule