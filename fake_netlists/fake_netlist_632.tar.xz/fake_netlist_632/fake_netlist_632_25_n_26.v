module fake_netlist_632_25_n_26 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_13, n_11, n_26);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_13;
input n_11;

output n_26;

wire n_18;
wire n_25;
wire n_22;
wire n_20;
wire n_15;
wire n_23;
wire n_14;
wire n_21;
wire n_17;
wire n_16;
wire n_19;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_3),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_1),
.B(n_0),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_6),
.B(n_4),
.Y(n_20)
);

OR2x6_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_18),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_14),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_14),
.B(n_16),
.C(n_19),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.C(n_6),
.D(n_4),
.Y(n_24)
);

OAI22x1_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_10),
.B1(n_9),
.B2(n_2),
.Y(n_25)
);

OAI21x1_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_13),
.B(n_12),
.Y(n_26)
);


endmodule