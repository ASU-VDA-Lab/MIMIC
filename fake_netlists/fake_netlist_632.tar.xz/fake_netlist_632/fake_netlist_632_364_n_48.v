module fake_netlist_632_364_n_48 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_23, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_24, n_48);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_23;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;
input n_24;

output n_48;

wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_38;
wire n_45;
wire n_36;
wire n_47;
wire n_42;
wire n_29;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI21x1_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_21),
.B(n_1),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_4),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_17),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_15),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_14),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_18),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_25),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_32),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_SL g37 ( 
.A1(n_33),
.A2(n_29),
.B(n_27),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_35),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_34),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_32),
.B1(n_30),
.B2(n_28),
.C(n_18),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_SL g41 ( 
.A(n_38),
.B(n_0),
.Y(n_41)
);

NOR3xp33_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_3),
.C(n_2),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_6),
.C(n_5),
.Y(n_43)
);

INVx1_ASAP7_75t_SL g44 ( 
.A(n_42),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_7),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_11),
.B1(n_10),
.B2(n_8),
.Y(n_46)
);

OAI221xp5_ASAP7_75t_R g47 ( 
.A1(n_45),
.A2(n_13),
.B1(n_12),
.B2(n_16),
.C(n_19),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_20),
.B1(n_22),
.B2(n_46),
.Y(n_48)
);


endmodule