module fake_netlist_632_1780_n_19 (n_5, n_0, n_1, n_4, n_3, n_2, n_19);

input n_5;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_19;

wire n_18;
wire n_13;
wire n_7;
wire n_10;
wire n_11;
wire n_9;
wire n_15;
wire n_8;
wire n_12;
wire n_14;
wire n_6;
wire n_17;
wire n_16;

OAI22xp33_ASAP7_75t_L g6 ( 
.A1(n_1),
.A2(n_4),
.B1(n_2),
.B2(n_0),
.Y(n_6)
);

AOI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_3),
.B(n_2),
.Y(n_7)
);

BUFx10_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVxp67_ASAP7_75t_SL g12 ( 
.A(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

A2O1A1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_10),
.B(n_12),
.C(n_11),
.Y(n_15)
);

AOI211xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_12),
.B(n_11),
.C(n_7),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_11),
.B(n_15),
.Y(n_19)
);


endmodule