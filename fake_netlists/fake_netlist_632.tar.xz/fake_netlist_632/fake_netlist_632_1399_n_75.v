module fake_netlist_632_1399_n_75 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_75);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_75;

wire n_69;
wire n_53;
wire n_62;
wire n_63;
wire n_71;
wire n_34;
wire n_49;
wire n_39;
wire n_51;
wire n_73;
wire n_54;
wire n_74;
wire n_25;
wire n_30;
wire n_32;
wire n_68;
wire n_65;
wire n_67;
wire n_33;
wire n_44;
wire n_41;
wire n_31;
wire n_38;
wire n_45;
wire n_57;
wire n_36;
wire n_55;
wire n_58;
wire n_72;
wire n_60;
wire n_47;
wire n_23;
wire n_42;
wire n_52;
wire n_66;
wire n_29;
wire n_48;
wire n_56;
wire n_70;
wire n_64;
wire n_37;
wire n_43;
wire n_59;
wire n_27;
wire n_35;
wire n_61;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_24;
wire n_50;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_6),
.B(n_14),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_3),
.B(n_9),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_7),
.Y(n_27)
);

OA21x2_ASAP7_75t_L g28 ( 
.A1(n_10),
.A2(n_21),
.B(n_0),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_8),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_11),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_5),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_1),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_4),
.Y(n_34)
);

OA21x2_ASAP7_75t_L g35 ( 
.A1(n_17),
.A2(n_13),
.B(n_16),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_22),
.B(n_19),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_24),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_29),
.B(n_16),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

OR2x6_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_18),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_30),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_27),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_SL g44 ( 
.A(n_36),
.B(n_33),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_37),
.B(n_33),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_42),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_23),
.Y(n_47)
);

INVx2_ASAP7_75t_SL g48 ( 
.A(n_41),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_38),
.B(n_33),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

AOI211xp5_ASAP7_75t_SL g51 ( 
.A1(n_47),
.A2(n_39),
.B(n_40),
.C(n_25),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_45),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_46),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_48),
.Y(n_54)
);

OR2x2_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_50),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

INVxp67_ASAP7_75t_L g57 ( 
.A(n_51),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

NAND2x1_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_35),
.Y(n_59)
);

AND2x2_ASAP7_75t_L g60 ( 
.A(n_57),
.B(n_48),
.Y(n_60)
);

AOI31xp33_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_46),
.A3(n_25),
.B(n_32),
.Y(n_61)
);

NOR2xp33_ASAP7_75t_L g62 ( 
.A(n_61),
.B(n_60),
.Y(n_62)
);

AOI221xp5_ASAP7_75t_SL g63 ( 
.A1(n_60),
.A2(n_55),
.B1(n_43),
.B2(n_41),
.C(n_31),
.Y(n_63)
);

OAI21xp5_ASAP7_75t_SL g64 ( 
.A1(n_58),
.A2(n_19),
.B(n_18),
.Y(n_64)
);

CKINVDCx5p33_ASAP7_75t_R g65 ( 
.A(n_59),
.Y(n_65)
);

XNOR2xp5_ASAP7_75t_L g66 ( 
.A(n_60),
.B(n_35),
.Y(n_66)
);

XNOR2xp5_ASAP7_75t_L g67 ( 
.A(n_66),
.B(n_28),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_65),
.Y(n_68)
);

NOR2x1p5_ASAP7_75t_L g69 ( 
.A(n_62),
.B(n_26),
.Y(n_69)
);

HB1xp67_ASAP7_75t_L g70 ( 
.A(n_63),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_64),
.Y(n_71)
);

OAI22xp5_ASAP7_75t_L g72 ( 
.A1(n_67),
.A2(n_71),
.B1(n_69),
.B2(n_68),
.Y(n_72)
);

CKINVDCx20_ASAP7_75t_R g73 ( 
.A(n_70),
.Y(n_73)
);

AND3x1_ASAP7_75t_L g74 ( 
.A(n_70),
.B(n_26),
.C(n_28),
.Y(n_74)
);

AOI22xp33_ASAP7_75t_L g75 ( 
.A1(n_73),
.A2(n_72),
.B1(n_74),
.B2(n_12),
.Y(n_75)
);


endmodule