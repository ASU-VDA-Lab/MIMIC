module fake_netlist_632_2458_n_24 (n_5, n_7, n_0, n_1, n_4, n_3, n_2, n_6, n_24);

input n_5;
input n_7;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;
input n_6;

output n_24;

wire n_18;
wire n_13;
wire n_10;
wire n_20;
wire n_22;
wire n_11;
wire n_9;
wire n_15;
wire n_23;
wire n_8;
wire n_12;
wire n_14;
wire n_21;
wire n_17;
wire n_16;
wire n_19;

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

BUFx10_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

INVxp67_ASAP7_75t_SL g12 ( 
.A(n_4),
.Y(n_12)
);

INVx2_ASAP7_75t_SL g13 ( 
.A(n_3),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_9),
.B(n_10),
.Y(n_14)
);

OA21x2_ASAP7_75t_L g15 ( 
.A1(n_8),
.A2(n_11),
.B(n_12),
.Y(n_15)
);

CKINVDCx11_ASAP7_75t_R g16 ( 
.A(n_9),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_16),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_15),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_20),
.B1(n_13),
.B2(n_11),
.C(n_10),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_9),
.C(n_15),
.Y(n_22)
);

XNOR2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_5),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_7),
.B(n_6),
.Y(n_24)
);


endmodule