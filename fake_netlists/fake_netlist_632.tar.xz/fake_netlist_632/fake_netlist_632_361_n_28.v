module fake_netlist_632_361_n_28 (n_5, n_0, n_1, n_4, n_3, n_2, n_28);

input n_5;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_28;

wire n_18;
wire n_13;
wire n_7;
wire n_25;
wire n_10;
wire n_20;
wire n_22;
wire n_11;
wire n_9;
wire n_15;
wire n_23;
wire n_8;
wire n_12;
wire n_14;
wire n_6;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_24;

XNOR2xp5_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_5),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_1),
.B(n_3),
.Y(n_9)
);

AOI21x1_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_9),
.B(n_6),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_1),
.C(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_7),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_12),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

A2O1A1O1Ixp25_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_13),
.B(n_11),
.C(n_6),
.D(n_14),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_8),
.B1(n_4),
.B2(n_2),
.Y(n_22)
);

NOR2x1_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_19),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

NAND5xp2_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_4),
.C(n_5),
.D(n_8),
.E(n_22),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_24),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_26),
.Y(n_28)
);


endmodule