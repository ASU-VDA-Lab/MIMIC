module fake_netlist_632_2233_n_24 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_6, n_24);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_6;

output n_24;

wire n_18;
wire n_13;
wire n_10;
wire n_20;
wire n_22;
wire n_11;
wire n_15;
wire n_23;
wire n_12;
wire n_14;
wire n_21;
wire n_17;
wire n_16;
wire n_19;

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_2),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_3),
.Y(n_15)
);

NAND2x1p5_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_0),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_16),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B1(n_6),
.B2(n_1),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_21),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_24)
);


endmodule