module fake_netlist_632_2544_n_47 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_47);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_47;

wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_38;
wire n_45;
wire n_36;
wire n_23;
wire n_42;
wire n_29;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_11),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_6),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_13),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_15),
.B(n_8),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_14),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_3),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_17),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_24),
.A2(n_2),
.B(n_1),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_31),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_23),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_25),
.Y(n_38)
);

OAI22xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_23),
.B1(n_29),
.B2(n_26),
.Y(n_39)
);

AOI21xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_30),
.B(n_16),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_28),
.B1(n_33),
.B2(n_18),
.C(n_19),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_19),
.B1(n_7),
.B2(n_4),
.C(n_5),
.Y(n_42)
);

XNOR2x1_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_9),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_20),
.B1(n_12),
.B2(n_10),
.Y(n_45)
);

INVx3_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_22),
.B1(n_43),
.B2(n_45),
.Y(n_47)
);


endmodule