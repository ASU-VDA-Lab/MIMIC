module fake_netlist_632_1335_n_28 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_10, n_6, n_11, n_28);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_10;
input n_6;
input n_11;

output n_28;

wire n_18;
wire n_13;
wire n_25;
wire n_22;
wire n_20;
wire n_15;
wire n_23;
wire n_12;
wire n_14;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_24;

INVx4_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_3),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_8),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_2),
.B(n_7),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_11),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_18),
.B1(n_17),
.B2(n_15),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_R g21 ( 
.A(n_19),
.B(n_16),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI211xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_14),
.B(n_21),
.C(n_8),
.Y(n_24)
);

NOR4xp25_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_11),
.C(n_9),
.D(n_12),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_1),
.Y(n_27)
);

OA22x2_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_28)
);


endmodule