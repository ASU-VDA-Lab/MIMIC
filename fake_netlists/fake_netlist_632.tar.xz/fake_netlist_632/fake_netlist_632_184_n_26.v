module fake_netlist_632_184_n_26 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_13, n_11, n_26);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_13;
input n_11;

output n_26;

wire n_18;
wire n_25;
wire n_22;
wire n_20;
wire n_15;
wire n_23;
wire n_14;
wire n_21;
wire n_17;
wire n_16;
wire n_19;
wire n_24;

INVx1_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_2),
.B(n_3),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

BUFx10_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_10),
.C(n_8),
.Y(n_19)
);

INVxp67_ASAP7_75t_SL g20 ( 
.A(n_18),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_17),
.Y(n_22)
);

OAI222xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_17),
.B1(n_12),
.B2(n_11),
.C1(n_15),
.C2(n_0),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

XNOR2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_1),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_13),
.B1(n_5),
.B2(n_4),
.Y(n_26)
);


endmodule