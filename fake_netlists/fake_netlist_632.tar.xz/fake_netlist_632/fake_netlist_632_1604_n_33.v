module fake_netlist_632_1604_n_33 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_17, n_16, n_33);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_17;
input n_16;

output n_33;

wire n_25;
wire n_30;
wire n_32;
wire n_31;
wire n_20;
wire n_22;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_6),
.B(n_11),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_7),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_SL g25 ( 
.A(n_22),
.B(n_16),
.C(n_0),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_19),
.Y(n_28)
);

OAI222xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_20),
.B1(n_25),
.B2(n_24),
.C1(n_21),
.C2(n_16),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_23),
.B1(n_5),
.B2(n_3),
.C(n_4),
.Y(n_30)
);

OAI211xp5_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_12),
.B(n_9),
.C(n_8),
.Y(n_31)
);

NOR2x1p5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_13),
.Y(n_32)
);

OAI31xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_18),
.A3(n_15),
.B(n_14),
.Y(n_33)
);


endmodule