module fake_netlist_632_2355_n_20 (n_5, n_0, n_1, n_4, n_3, n_2, n_20);

input n_5;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_20;

wire n_18;
wire n_13;
wire n_7;
wire n_10;
wire n_11;
wire n_9;
wire n_15;
wire n_8;
wire n_12;
wire n_14;
wire n_6;
wire n_17;
wire n_16;
wire n_19;

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_0),
.B(n_1),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

BUFx3_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

AO32x2_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.A3(n_4),
.B1(n_0),
.B2(n_2),
.Y(n_9)
);

BUFx4f_ASAP7_75t_SL g10 ( 
.A(n_8),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B1(n_7),
.B2(n_0),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

O2A1O1Ixp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_9),
.B(n_7),
.C(n_4),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_SL g16 ( 
.A1(n_13),
.A2(n_5),
.B(n_4),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_7),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_7),
.Y(n_18)
);

OAI31xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_18),
.A3(n_9),
.B(n_5),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_3),
.B1(n_13),
.B2(n_17),
.Y(n_20)
);


endmodule