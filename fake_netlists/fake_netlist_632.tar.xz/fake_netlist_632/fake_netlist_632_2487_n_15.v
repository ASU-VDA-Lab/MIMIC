module fake_netlist_632_2487_n_15 (n_2, n_3, n_0, n_1, n_15);

input n_2;
input n_3;
input n_0;
input n_1;

output n_15;

wire n_5;
wire n_7;
wire n_9;
wire n_4;
wire n_8;
wire n_12;
wire n_14;
wire n_10;
wire n_6;
wire n_13;
wire n_11;

INVx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

A2O1A1Ixp33_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_6),
.B(n_4),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

AOI322xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.A3(n_1),
.B1(n_2),
.B2(n_0),
.C1(n_3),
.C2(n_10),
.Y(n_12)
);

NAND4xp25_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_9),
.C(n_0),
.D(n_3),
.Y(n_13)
);

AND3x4_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_3),
.C(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);


endmodule