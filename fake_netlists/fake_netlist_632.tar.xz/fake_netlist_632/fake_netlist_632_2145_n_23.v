module fake_netlist_632_2145_n_23 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_11, n_23);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_11;

output n_23;

wire n_18;
wire n_13;
wire n_22;
wire n_20;
wire n_15;
wire n_14;
wire n_21;
wire n_17;
wire n_16;
wire n_19;

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_1),
.B(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_2),
.B(n_4),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.C(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

OAI21xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_18),
.B(n_13),
.Y(n_20)
);

NAND5xp2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_7),
.C(n_6),
.D(n_0),
.E(n_3),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_6),
.Y(n_22)
);

AOI222xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_7),
.B1(n_11),
.B2(n_5),
.C1(n_12),
.C2(n_8),
.Y(n_23)
);


endmodule