module fake_netlist_632_1909_n_67 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_10, n_6, n_13, n_11, n_67);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_10;
input n_6;
input n_13;
input n_11;

output n_67;

wire n_18;
wire n_53;
wire n_62;
wire n_63;
wire n_34;
wire n_49;
wire n_39;
wire n_51;
wire n_54;
wire n_25;
wire n_30;
wire n_32;
wire n_65;
wire n_44;
wire n_33;
wire n_31;
wire n_41;
wire n_22;
wire n_20;
wire n_38;
wire n_45;
wire n_57;
wire n_36;
wire n_55;
wire n_58;
wire n_60;
wire n_47;
wire n_23;
wire n_42;
wire n_52;
wire n_66;
wire n_29;
wire n_48;
wire n_56;
wire n_64;
wire n_37;
wire n_21;
wire n_43;
wire n_59;
wire n_27;
wire n_35;
wire n_61;
wire n_26;
wire n_16;
wire n_17;
wire n_19;
wire n_28;
wire n_40;
wire n_46;
wire n_24;
wire n_50;

NOR2xp33_ASAP7_75t_SL g16 ( 
.A(n_9),
.B(n_7),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_15),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_9),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_8),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_0),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_16),
.B(n_27),
.Y(n_29)
);

BUFx3_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

INVx2_ASAP7_75t_SL g31 ( 
.A(n_27),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_18),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_18),
.B(n_0),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_19),
.Y(n_34)
);

AND3x2_ASAP7_75t_SL g35 ( 
.A(n_23),
.B(n_16),
.C(n_19),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_23),
.B(n_1),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_23),
.B(n_1),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_31),
.B(n_24),
.Y(n_38)
);

O2A1O1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_31),
.A2(n_34),
.B(n_28),
.C(n_29),
.Y(n_39)
);

AND2x2_ASAP7_75t_SL g40 ( 
.A(n_37),
.B(n_26),
.Y(n_40)
);

AOI211xp5_ASAP7_75t_L g41 ( 
.A1(n_29),
.A2(n_25),
.B(n_24),
.C(n_17),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_31),
.A2(n_22),
.B1(n_21),
.B2(n_25),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_34),
.B(n_20),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_28),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_30),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_37),
.A2(n_5),
.B1(n_3),
.B2(n_2),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_38),
.B(n_43),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_39),
.B1(n_46),
.B2(n_42),
.C(n_41),
.Y(n_48)
);

NAND2xp33_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_38),
.Y(n_49)
);

OR2x2_ASAP7_75t_L g50 ( 
.A(n_42),
.B(n_33),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_SL g51 ( 
.A1(n_44),
.A2(n_35),
.B1(n_37),
.B2(n_36),
.Y(n_51)
);

CKINVDCx16_ASAP7_75t_R g52 ( 
.A(n_50),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_47),
.B(n_33),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_40),
.Y(n_54)
);

OAI22xp5_ASAP7_75t_L g55 ( 
.A1(n_48),
.A2(n_40),
.B1(n_36),
.B2(n_37),
.Y(n_55)
);

AOI221xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_48),
.B1(n_37),
.B2(n_30),
.C(n_51),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_32),
.Y(n_57)
);

INVx5_ASAP7_75t_L g58 ( 
.A(n_52),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_54),
.B1(n_35),
.B2(n_32),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

AND2x4_ASAP7_75t_SL g62 ( 
.A(n_61),
.B(n_58),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_59),
.Y(n_63)
);

AOI22xp5_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_13),
.B1(n_52),
.B2(n_48),
.Y(n_64)
);

CKINVDCx16_ASAP7_75t_R g65 ( 
.A(n_64),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_63),
.Y(n_66)
);

AOI22xp5_ASAP7_75t_SL g67 ( 
.A1(n_65),
.A2(n_62),
.B1(n_63),
.B2(n_66),
.Y(n_67)
);


endmodule