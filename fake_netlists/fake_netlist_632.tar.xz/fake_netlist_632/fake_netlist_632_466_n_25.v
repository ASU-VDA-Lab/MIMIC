module fake_netlist_632_466_n_25 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_11, n_25);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_11;

output n_25;

wire n_18;
wire n_13;
wire n_22;
wire n_20;
wire n_15;
wire n_23;
wire n_14;
wire n_21;
wire n_17;
wire n_16;
wire n_19;
wire n_24;

INVx2_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_5),
.B(n_2),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_6),
.B(n_4),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_0),
.B(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

OAI21xp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_5),
.B(n_4),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_15),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_13),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_18),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_14),
.Y(n_22)
);

NOR4xp75_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_16),
.C(n_7),
.D(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI222xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_7),
.B1(n_10),
.B2(n_3),
.C1(n_11),
.C2(n_9),
.Y(n_25)
);


endmodule