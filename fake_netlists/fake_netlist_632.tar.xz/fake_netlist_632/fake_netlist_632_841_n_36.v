module fake_netlist_632_841_n_36 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_16, n_10, n_17, n_6, n_13, n_11, n_36);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_16;
input n_10;
input n_17;
input n_6;
input n_13;
input n_11;

output n_36;

wire n_18;
wire n_34;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_20;
wire n_22;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_19;
wire n_24;

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_8),
.B(n_1),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_2),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

AND3x2_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_3),
.C(n_4),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_11),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_11),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_26),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_21),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_19),
.Y(n_31)
);

OAI31xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_30),
.A3(n_24),
.B(n_18),
.Y(n_32)
);

AOI21xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_22),
.B(n_0),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_35)
);

OAI221xp5_ASAP7_75t_R g36 ( 
.A1(n_35),
.A2(n_10),
.B1(n_9),
.B2(n_14),
.C(n_16),
.Y(n_36)
);


endmodule