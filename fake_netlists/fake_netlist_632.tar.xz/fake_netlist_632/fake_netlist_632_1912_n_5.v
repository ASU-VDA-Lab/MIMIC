module fake_netlist_632_1912_n_5 (n_2, n_3, n_0, n_1, n_5);

input n_2;
input n_3;
input n_0;
input n_1;

output n_5;

wire n_4;

AND2x2_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_1),
.Y(n_4)
);

OAI21xp5_ASAP7_75t_SL g5 ( 
.A1(n_4),
.A2(n_3),
.B(n_2),
.Y(n_5)
);


endmodule