module fake_netlist_632_1614_n_37 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_16, n_10, n_6, n_13, n_11, n_37);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_16;
input n_10;
input n_6;
input n_13;
input n_11;

output n_37;

wire n_18;
wire n_34;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_20;
wire n_22;
wire n_36;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_35;
wire n_26;
wire n_17;
wire n_28;
wire n_19;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_6),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_16),
.A2(n_15),
.B1(n_5),
.B2(n_12),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_18),
.A2(n_23),
.B(n_20),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_14),
.B(n_3),
.C(n_0),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_20),
.A2(n_14),
.B1(n_3),
.B2(n_0),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_25),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_21),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_26),
.C(n_29),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_28),
.B(n_22),
.C(n_17),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_19),
.B1(n_16),
.B2(n_15),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

CKINVDCx6p67_ASAP7_75t_R g35 ( 
.A(n_32),
.Y(n_35)
);

XNOR2x1_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_19),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_9),
.B2(n_4),
.Y(n_37)
);


endmodule