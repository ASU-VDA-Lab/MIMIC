module fake_netlist_632_193_n_44 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_23, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_44);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_23;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_44;

wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_41;
wire n_38;
wire n_36;
wire n_42;
wire n_29;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_24;

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_4),
.B(n_13),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_2),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_3),
.B(n_20),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_22),
.B(n_9),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_16),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_26),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_27),
.B(n_6),
.Y(n_34)
);

CKINVDCx12_ASAP7_75t_R g35 ( 
.A(n_33),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_31),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_32),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_25),
.B1(n_29),
.B2(n_35),
.Y(n_38)
);

AOI321xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_28),
.A3(n_24),
.B1(n_11),
.B2(n_8),
.C(n_7),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_12),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_40),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_41),
.B1(n_15),
.B2(n_14),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_23),
.B1(n_18),
.B2(n_17),
.Y(n_44)
);


endmodule