module fake_netlist_632_1638_n_9 (n_2, n_0, n_1, n_9);

input n_2;
input n_0;
input n_1;

output n_9;

wire n_5;
wire n_7;
wire n_4;
wire n_3;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx2_ASAP7_75t_SL g5 ( 
.A(n_4),
.Y(n_5)
);

NOR3xp33_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_3),
.C(n_0),
.Y(n_6)
);

O2A1O1Ixp5_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_5),
.B(n_1),
.C(n_0),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

AOI31xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_2),
.A3(n_3),
.B(n_5),
.Y(n_9)
);


endmodule