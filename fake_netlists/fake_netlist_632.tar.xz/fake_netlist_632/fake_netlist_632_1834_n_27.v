module fake_netlist_632_1834_n_27 (n_0, n_1, n_4, n_3, n_2, n_27);

input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_27;

wire n_18;
wire n_13;
wire n_7;
wire n_25;
wire n_10;
wire n_22;
wire n_20;
wire n_11;
wire n_9;
wire n_15;
wire n_23;
wire n_8;
wire n_12;
wire n_14;
wire n_6;
wire n_5;
wire n_21;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_24;

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_0),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_3),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_5),
.B(n_6),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_0),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_7),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AO21x2_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_8),
.B(n_5),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_10),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_12),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_5),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_14),
.Y(n_20)
);

OAI21xp33_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_11),
.B(n_7),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_16),
.B1(n_9),
.B2(n_8),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_19),
.B1(n_8),
.B2(n_7),
.C(n_16),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_SL g25 ( 
.A1(n_20),
.A2(n_9),
.B1(n_16),
.B2(n_1),
.C(n_2),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_3),
.B1(n_4),
.B2(n_23),
.Y(n_26)
);

AOI321xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_4),
.A3(n_25),
.B1(n_24),
.B2(n_11),
.C(n_5),
.Y(n_27)
);


endmodule