module fake_netlist_632_414_n_41 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_17, n_16, n_19, n_41);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_17;
input n_16;
input n_19;

output n_41;

wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_22;
wire n_20;
wire n_38;
wire n_36;
wire n_23;
wire n_29;
wire n_21;
wire n_37;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_24;

INVx2_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_16),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_14),
.B(n_16),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_5),
.B(n_15),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

O2A1O1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_22),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_23),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_34),
.B1(n_21),
.B2(n_30),
.C(n_24),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_20),
.B1(n_26),
.B2(n_25),
.C(n_4),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

NAND4xp25_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_25),
.C(n_10),
.D(n_8),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_39),
.B1(n_12),
.B2(n_11),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_18),
.B1(n_17),
.B2(n_13),
.Y(n_41)
);


endmodule