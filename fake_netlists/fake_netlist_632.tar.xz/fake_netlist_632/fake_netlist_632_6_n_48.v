module fake_netlist_632_6_n_48 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_23, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_48);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_23;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_48;

wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_38;
wire n_45;
wire n_36;
wire n_47;
wire n_42;
wire n_29;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_24;

INVx2_ASAP7_75t_SL g24 ( 
.A(n_1),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_15),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_3),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_18),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_4),
.Y(n_29)
);

INVxp33_ASAP7_75t_SL g30 ( 
.A(n_10),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_11),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_R g32 ( 
.A(n_7),
.B(n_17),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

BUFx12f_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_24),
.B(n_19),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_37),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_36),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_30),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_SL g41 ( 
.A1(n_38),
.A2(n_28),
.B1(n_26),
.B2(n_32),
.Y(n_41)
);

AOI321xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_27),
.A3(n_19),
.B1(n_32),
.B2(n_29),
.C(n_0),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_6),
.B1(n_5),
.B2(n_2),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_8),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NAND4xp75_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_13),
.C(n_12),
.D(n_9),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_21),
.B1(n_20),
.B2(n_14),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_22),
.B1(n_23),
.B2(n_46),
.Y(n_48)
);


endmodule