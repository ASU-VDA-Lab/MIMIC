module fake_netlist_823_1847_n_41 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_41);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_41;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_11;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_15),
.B(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_SL g24 ( 
.A(n_11),
.B(n_5),
.C(n_4),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_12),
.Y(n_25)
);

AO21x2_ASAP7_75t_L g26 ( 
.A1(n_19),
.A2(n_17),
.B(n_11),
.Y(n_26)
);

NOR2x1_ASAP7_75t_SL g27 ( 
.A(n_19),
.B(n_14),
.Y(n_27)
);

AO31x2_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_14),
.A3(n_16),
.B(n_7),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_20),
.Y(n_29)
);

NOR2x1_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_21),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_21),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_20),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_SL g33 ( 
.A(n_29),
.B(n_17),
.C(n_24),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_30),
.Y(n_34)
);

NOR2xp67_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_20),
.Y(n_35)
);

AOI322xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_23),
.A3(n_33),
.B1(n_14),
.B2(n_7),
.C1(n_28),
.C2(n_0),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_35),
.Y(n_37)
);

AOI221x1_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_14),
.B1(n_28),
.B2(n_27),
.C(n_1),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_R g39 ( 
.A(n_37),
.B(n_2),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_14),
.B1(n_36),
.B2(n_38),
.Y(n_41)
);


endmodule