module fake_netlist_823_2502_n_22 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_22);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_21;
wire n_16;
wire n_11;

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_5),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

INVx4_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

OR2x6_ASAP7_75t_L g14 ( 
.A(n_6),
.B(n_5),
.Y(n_14)
);

NOR2xp67_ASAP7_75t_SL g15 ( 
.A(n_13),
.B(n_1),
.Y(n_15)
);

AOI21x1_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_4),
.B(n_1),
.Y(n_16)
);

AO21x2_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B(n_13),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_11),
.B1(n_17),
.B2(n_14),
.C(n_6),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_16),
.B(n_14),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_7),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_7),
.B1(n_8),
.B2(n_0),
.C1(n_10),
.C2(n_3),
.Y(n_22)
);


endmodule