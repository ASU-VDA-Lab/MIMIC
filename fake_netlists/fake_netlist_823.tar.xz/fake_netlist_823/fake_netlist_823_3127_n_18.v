module fake_netlist_823_3127_n_18 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_18);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_18;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;
wire n_9;

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_6),
.B(n_5),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_SL g12 ( 
.A1(n_9),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND5xp2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.C(n_10),
.D(n_0),
.E(n_2),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B1(n_6),
.B2(n_3),
.C(n_4),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_7),
.B(n_3),
.C(n_8),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_7),
.Y(n_17)
);

XNOR2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);


endmodule