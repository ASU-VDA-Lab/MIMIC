module fake_netlist_823_2553_n_26 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_26);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

INVx1_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_7),
.B(n_4),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_3),
.B(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_15),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_10),
.Y(n_18)
);

OAI21xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_13),
.B(n_16),
.Y(n_19)
);

NOR4xp75_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_6),
.C(n_5),
.D(n_12),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_17),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OAI22xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_14),
.B1(n_10),
.B2(n_6),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

OAI22x1_ASAP7_75t_SL g25 ( 
.A1(n_22),
.A2(n_14),
.B1(n_8),
.B2(n_2),
.Y(n_25)
);

OA22x2_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_9),
.B1(n_25),
.B2(n_23),
.Y(n_26)
);


endmodule