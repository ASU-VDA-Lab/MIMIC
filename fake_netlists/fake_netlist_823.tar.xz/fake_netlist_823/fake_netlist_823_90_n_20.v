module fake_netlist_823_90_n_20 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_20);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_3),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

INVx5_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_12),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_10),
.B(n_11),
.Y(n_17)
);

NOR4xp75_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_7),
.C(n_6),
.D(n_12),
.Y(n_18)
);

XNOR2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_0),
.Y(n_19)
);

OAI222xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_15),
.B1(n_7),
.B2(n_9),
.C1(n_8),
.C2(n_4),
.Y(n_20)
);


endmodule