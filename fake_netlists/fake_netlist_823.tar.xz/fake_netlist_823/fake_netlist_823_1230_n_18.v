module fake_netlist_823_1230_n_18 (n_2, n_0, n_3, n_1, n_18);

input n_2;
input n_0;
input n_3;
input n_1;

output n_18;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_13;
wire n_7;
wire n_5;
wire n_16;
wire n_17;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_3),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

OA21x2_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_6),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_4),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_5),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_8),
.Y(n_12)
);

NOR3xp33_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_2),
.C(n_0),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_13),
.B1(n_3),
.B2(n_2),
.C(n_1),
.Y(n_14)
);

AOI211xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_6),
.B(n_3),
.C(n_7),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B(n_14),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AO21x1_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_7),
.B(n_17),
.Y(n_18)
);


endmodule