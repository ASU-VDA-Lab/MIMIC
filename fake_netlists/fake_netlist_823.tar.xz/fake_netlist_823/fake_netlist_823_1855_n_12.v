module fake_netlist_823_1855_n_12 (n_0, n_1, n_12);

input n_0;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_8;

BUFx4f_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVx2_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

AOI21x1_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

OR2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_4),
.Y(n_8)
);

NOR3xp33_ASAP7_75t_SL g9 ( 
.A(n_8),
.B(n_6),
.C(n_0),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AOI21xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_8),
.B(n_11),
.Y(n_12)
);


endmodule