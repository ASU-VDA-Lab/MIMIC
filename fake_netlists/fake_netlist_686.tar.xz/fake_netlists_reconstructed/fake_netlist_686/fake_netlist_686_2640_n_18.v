module fake_netlist_686_2640_n_18 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_18);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_9;
wire n_17;
wire n_7;
wire n_14;
wire n_15;
wire n_11;
wire n_16;
wire n_8;
wire n_13;
wire n_10;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

CKINVDCx16_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_6),
.B(n_1),
.Y(n_10)
);

CKINVDCx6p67_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

CKINVDCx16_ASAP7_75t_R g12 ( 
.A(n_11),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_7),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_7),
.B(n_10),
.C(n_12),
.Y(n_14)
);

NAND4xp25_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_13),
.C(n_9),
.D(n_1),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_6),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_4),
.B1(n_2),
.B2(n_0),
.Y(n_18)
);


endmodule