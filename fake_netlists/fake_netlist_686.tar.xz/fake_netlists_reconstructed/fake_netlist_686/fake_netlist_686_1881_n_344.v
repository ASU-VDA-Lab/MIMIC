module fake_netlist_686_1881_n_344 (n_24, n_2, n_38, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_35, n_34, n_16, n_26, n_1, n_5, n_37, n_7, n_23, n_31, n_29, n_33, n_8, n_0, n_36, n_4, n_32, n_28, n_3, n_11, n_19, n_30, n_25, n_10, n_13, n_39, n_14, n_12, n_344);

input n_24;
input n_2;
input n_38;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_35;
input n_34;
input n_16;
input n_26;
input n_1;
input n_5;
input n_37;
input n_7;
input n_23;
input n_31;
input n_29;
input n_33;
input n_8;
input n_0;
input n_36;
input n_4;
input n_32;
input n_28;
input n_3;
input n_11;
input n_19;
input n_30;
input n_25;
input n_10;
input n_13;
input n_39;
input n_14;
input n_12;

output n_344;

wire n_110;
wire n_148;
wire n_278;
wire n_339;
wire n_309;
wire n_175;
wire n_243;
wire n_157;
wire n_308;
wire n_261;
wire n_329;
wire n_314;
wire n_319;
wire n_181;
wire n_341;
wire n_59;
wire n_246;
wire n_318;
wire n_229;
wire n_131;
wire n_45;
wire n_158;
wire n_130;
wire n_146;
wire n_136;
wire n_313;
wire n_76;
wire n_184;
wire n_109;
wire n_173;
wire n_74;
wire n_160;
wire n_285;
wire n_295;
wire n_94;
wire n_75;
wire n_54;
wire n_291;
wire n_44;
wire n_248;
wire n_203;
wire n_167;
wire n_42;
wire n_236;
wire n_106;
wire n_307;
wire n_100;
wire n_321;
wire n_43;
wire n_84;
wire n_240;
wire n_68;
wire n_140;
wire n_169;
wire n_82;
wire n_172;
wire n_193;
wire n_186;
wire n_337;
wire n_135;
wire n_122;
wire n_237;
wire n_242;
wire n_133;
wire n_120;
wire n_217;
wire n_205;
wire n_80;
wire n_132;
wire n_138;
wire n_342;
wire n_153;
wire n_126;
wire n_253;
wire n_223;
wire n_221;
wire n_206;
wire n_57;
wire n_49;
wire n_239;
wire n_86;
wire n_40;
wire n_66;
wire n_259;
wire n_213;
wire n_71;
wire n_234;
wire n_179;
wire n_121;
wire n_182;
wire n_60;
wire n_89;
wire n_194;
wire n_262;
wire n_48;
wire n_67;
wire n_113;
wire n_204;
wire n_190;
wire n_62;
wire n_334;
wire n_265;
wire n_70;
wire n_168;
wire n_226;
wire n_296;
wire n_144;
wire n_244;
wire n_170;
wire n_55;
wire n_192;
wire n_335;
wire n_78;
wire n_303;
wire n_116;
wire n_225;
wire n_263;
wire n_247;
wire n_328;
wire n_195;
wire n_143;
wire n_276;
wire n_117;
wire n_152;
wire n_180;
wire n_202;
wire n_331;
wire n_214;
wire n_95;
wire n_282;
wire n_306;
wire n_178;
wire n_327;
wire n_320;
wire n_297;
wire n_274;
wire n_137;
wire n_257;
wire n_87;
wire n_255;
wire n_290;
wire n_72;
wire n_273;
wire n_232;
wire n_227;
wire n_268;
wire n_151;
wire n_299;
wire n_269;
wire n_300;
wire n_198;
wire n_61;
wire n_99;
wire n_210;
wire n_115;
wire n_301;
wire n_147;
wire n_230;
wire n_102;
wire n_47;
wire n_196;
wire n_260;
wire n_52;
wire n_220;
wire n_189;
wire n_305;
wire n_212;
wire n_256;
wire n_271;
wire n_50;
wire n_156;
wire n_298;
wire n_85;
wire n_288;
wire n_200;
wire n_323;
wire n_333;
wire n_63;
wire n_325;
wire n_231;
wire n_250;
wire n_188;
wire n_176;
wire n_209;
wire n_187;
wire n_208;
wire n_164;
wire n_270;
wire n_281;
wire n_111;
wire n_91;
wire n_127;
wire n_258;
wire n_51;
wire n_316;
wire n_191;
wire n_241;
wire n_289;
wire n_251;
wire n_90;
wire n_336;
wire n_228;
wire n_128;
wire n_118;
wire n_280;
wire n_343;
wire n_103;
wire n_293;
wire n_222;
wire n_79;
wire n_338;
wire n_332;
wire n_105;
wire n_215;
wire n_139;
wire n_56;
wire n_107;
wire n_201;
wire n_96;
wire n_233;
wire n_264;
wire n_219;
wire n_171;
wire n_165;
wire n_235;
wire n_267;
wire n_88;
wire n_315;
wire n_119;
wire n_162;
wire n_150;
wire n_252;
wire n_284;
wire n_114;
wire n_211;
wire n_292;
wire n_112;
wire n_197;
wire n_312;
wire n_83;
wire n_124;
wire n_163;
wire n_272;
wire n_64;
wire n_277;
wire n_218;
wire n_58;
wire n_224;
wire n_101;
wire n_69;
wire n_141;
wire n_123;
wire n_249;
wire n_53;
wire n_275;
wire n_304;
wire n_324;
wire n_149;
wire n_81;
wire n_161;
wire n_310;
wire n_245;
wire n_207;
wire n_326;
wire n_317;
wire n_174;
wire n_199;
wire n_238;
wire n_266;
wire n_145;
wire n_287;
wire n_177;
wire n_92;
wire n_129;
wire n_77;
wire n_134;
wire n_93;
wire n_97;
wire n_311;
wire n_216;
wire n_98;
wire n_340;
wire n_279;
wire n_125;
wire n_154;
wire n_104;
wire n_294;
wire n_283;
wire n_302;
wire n_183;
wire n_155;
wire n_254;
wire n_46;
wire n_73;
wire n_41;
wire n_185;
wire n_159;
wire n_65;
wire n_142;
wire n_322;
wire n_330;
wire n_166;
wire n_286;
wire n_108;

INVx1_ASAP7_75t_L g40 ( 
.A(n_17),
.Y(n_40)
);

BUFx3_ASAP7_75t_L g41 ( 
.A(n_17),
.Y(n_41)
);

INVxp67_ASAP7_75t_SL g42 ( 
.A(n_12),
.Y(n_42)
);

INVxp33_ASAP7_75t_SL g43 ( 
.A(n_6),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_0),
.Y(n_44)
);

INVxp33_ASAP7_75t_L g45 ( 
.A(n_31),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_28),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_8),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_33),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_9),
.Y(n_49)
);

NOR2xp67_ASAP7_75t_L g50 ( 
.A(n_21),
.B(n_16),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_23),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_11),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_9),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_29),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_41),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_41),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_41),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_45),
.B(n_0),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_46),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_54),
.Y(n_61)
);

NOR2xp33_ASAP7_75t_L g62 ( 
.A(n_45),
.B(n_43),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_46),
.Y(n_63)
);

BUFx6f_ASAP7_75t_L g64 ( 
.A(n_54),
.Y(n_64)
);

AND2x4_ASAP7_75t_L g65 ( 
.A(n_58),
.B(n_40),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_60),
.B(n_51),
.Y(n_66)
);

OR2x2_ASAP7_75t_L g67 ( 
.A(n_59),
.B(n_42),
.Y(n_67)
);

BUFx3_ASAP7_75t_L g68 ( 
.A(n_55),
.Y(n_68)
);

AOI22xp33_ASAP7_75t_L g69 ( 
.A1(n_60),
.A2(n_47),
.B1(n_44),
.B2(n_40),
.Y(n_69)
);

NOR2xp33_ASAP7_75t_L g70 ( 
.A(n_62),
.B(n_51),
.Y(n_70)
);

AND2x4_ASAP7_75t_L g71 ( 
.A(n_63),
.B(n_44),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_57),
.Y(n_72)
);

BUFx6f_ASAP7_75t_L g73 ( 
.A(n_64),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_L g74 ( 
.A(n_63),
.B(n_47),
.Y(n_74)
);

NAND2xp33_ASAP7_75t_L g75 ( 
.A(n_55),
.B(n_49),
.Y(n_75)
);

INVx4_ASAP7_75t_L g76 ( 
.A(n_64),
.Y(n_76)
);

NAND2xp5_ASAP7_75t_L g77 ( 
.A(n_56),
.B(n_49),
.Y(n_77)
);

AND2x4_ASAP7_75t_L g78 ( 
.A(n_56),
.B(n_52),
.Y(n_78)
);

AOI22xp33_ASAP7_75t_L g79 ( 
.A1(n_57),
.A2(n_53),
.B1(n_52),
.B2(n_42),
.Y(n_79)
);

NOR2xp33_ASAP7_75t_L g80 ( 
.A(n_61),
.B(n_53),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_57),
.Y(n_81)
);

BUFx2_ASAP7_75t_L g82 ( 
.A(n_61),
.Y(n_82)
);

BUFx2_ASAP7_75t_L g83 ( 
.A(n_64),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_64),
.Y(n_84)
);

NAND2xp5_ASAP7_75t_L g85 ( 
.A(n_71),
.B(n_64),
.Y(n_85)
);

NOR3xp33_ASAP7_75t_SL g86 ( 
.A(n_70),
.B(n_48),
.C(n_50),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_72),
.Y(n_87)
);

NAND2xp5_ASAP7_75t_SL g88 ( 
.A(n_65),
.B(n_50),
.Y(n_88)
);

OR2x4_ASAP7_75t_L g89 ( 
.A(n_67),
.B(n_48),
.Y(n_89)
);

NAND2xp5_ASAP7_75t_L g90 ( 
.A(n_71),
.B(n_18),
.Y(n_90)
);

NAND2xp5_ASAP7_75t_L g91 ( 
.A(n_71),
.B(n_19),
.Y(n_91)
);

INVx2_ASAP7_75t_L g92 ( 
.A(n_73),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_72),
.Y(n_93)
);

AND2x2_ASAP7_75t_L g94 ( 
.A(n_67),
.B(n_1),
.Y(n_94)
);

NAND2xp5_ASAP7_75t_L g95 ( 
.A(n_71),
.B(n_20),
.Y(n_95)
);

INVx1_ASAP7_75t_L g96 ( 
.A(n_81),
.Y(n_96)
);

NOR2xp33_ASAP7_75t_R g97 ( 
.A(n_75),
.B(n_22),
.Y(n_97)
);

NOR2xp33_ASAP7_75t_L g98 ( 
.A(n_67),
.B(n_65),
.Y(n_98)
);

HB1xp67_ASAP7_75t_L g99 ( 
.A(n_65),
.Y(n_99)
);

INVx1_ASAP7_75t_L g100 ( 
.A(n_81),
.Y(n_100)
);

INVx3_ASAP7_75t_L g101 ( 
.A(n_71),
.Y(n_101)
);

AND2x2_ASAP7_75t_L g102 ( 
.A(n_65),
.B(n_1),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_68),
.Y(n_103)
);

NAND2xp5_ASAP7_75t_L g104 ( 
.A(n_65),
.B(n_24),
.Y(n_104)
);

NOR2xp33_ASAP7_75t_L g105 ( 
.A(n_82),
.B(n_25),
.Y(n_105)
);

INVx2_ASAP7_75t_L g106 ( 
.A(n_73),
.Y(n_106)
);

INVx3_ASAP7_75t_L g107 ( 
.A(n_101),
.Y(n_107)
);

AOI221xp5_ASAP7_75t_L g108 ( 
.A1(n_98),
.A2(n_69),
.B1(n_79),
.B2(n_74),
.C(n_80),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_87),
.Y(n_109)
);

INVx4_ASAP7_75t_L g110 ( 
.A(n_101),
.Y(n_110)
);

INVx2_ASAP7_75t_L g111 ( 
.A(n_87),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_93),
.Y(n_112)
);

NAND2xp5_ASAP7_75t_L g113 ( 
.A(n_99),
.B(n_66),
.Y(n_113)
);

INVx2_ASAP7_75t_L g114 ( 
.A(n_93),
.Y(n_114)
);

NAND3xp33_ASAP7_75t_L g115 ( 
.A(n_88),
.B(n_79),
.C(n_69),
.Y(n_115)
);

INVx3_ASAP7_75t_L g116 ( 
.A(n_101),
.Y(n_116)
);

INVx1_ASAP7_75t_SL g117 ( 
.A(n_99),
.Y(n_117)
);

AND2x4_ASAP7_75t_L g118 ( 
.A(n_102),
.B(n_78),
.Y(n_118)
);

NAND2x1p5_ASAP7_75t_L g119 ( 
.A(n_101),
.B(n_78),
.Y(n_119)
);

AOI21xp5_ASAP7_75t_L g120 ( 
.A1(n_85),
.A2(n_66),
.B(n_74),
.Y(n_120)
);

NAND2xp5_ASAP7_75t_L g121 ( 
.A(n_94),
.B(n_82),
.Y(n_121)
);

NOR2xp33_ASAP7_75t_L g122 ( 
.A(n_89),
.B(n_78),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_96),
.Y(n_123)
);

CKINVDCx20_ASAP7_75t_R g124 ( 
.A(n_117),
.Y(n_124)
);

OAI22xp5_ASAP7_75t_L g125 ( 
.A1(n_121),
.A2(n_102),
.B1(n_94),
.B2(n_104),
.Y(n_125)
);

OR2x6_ASAP7_75t_L g126 ( 
.A(n_118),
.B(n_102),
.Y(n_126)
);

OAI22xp33_ASAP7_75t_L g127 ( 
.A1(n_121),
.A2(n_89),
.B1(n_94),
.B2(n_104),
.Y(n_127)
);

AND2x4_ASAP7_75t_L g128 ( 
.A(n_118),
.B(n_96),
.Y(n_128)
);

AOI22xp33_ASAP7_75t_SL g129 ( 
.A1(n_118),
.A2(n_89),
.B1(n_97),
.B2(n_100),
.Y(n_129)
);

HB1xp67_ASAP7_75t_L g130 ( 
.A(n_117),
.Y(n_130)
);

BUFx3_ASAP7_75t_L g131 ( 
.A(n_111),
.Y(n_131)
);

NOR3xp33_ASAP7_75t_L g132 ( 
.A(n_122),
.B(n_80),
.C(n_105),
.Y(n_132)
);

AOI22xp5_ASAP7_75t_L g133 ( 
.A1(n_118),
.A2(n_89),
.B1(n_86),
.B2(n_100),
.Y(n_133)
);

OAI221xp5_ASAP7_75t_L g134 ( 
.A1(n_122),
.A2(n_86),
.B1(n_77),
.B2(n_90),
.C(n_91),
.Y(n_134)
);

INVx2_ASAP7_75t_L g135 ( 
.A(n_131),
.Y(n_135)
);

INVx1_ASAP7_75t_L g136 ( 
.A(n_128),
.Y(n_136)
);

OR2x2_ASAP7_75t_L g137 ( 
.A(n_126),
.B(n_111),
.Y(n_137)
);

OAI21xp5_ASAP7_75t_L g138 ( 
.A1(n_125),
.A2(n_120),
.B(n_115),
.Y(n_138)
);

OAI22xp33_ASAP7_75t_L g139 ( 
.A1(n_126),
.A2(n_113),
.B1(n_114),
.B2(n_111),
.Y(n_139)
);

AOI22xp33_ASAP7_75t_L g140 ( 
.A1(n_132),
.A2(n_118),
.B1(n_115),
.B2(n_109),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_128),
.Y(n_141)
);

AOI22xp33_ASAP7_75t_L g142 ( 
.A1(n_124),
.A2(n_108),
.B1(n_110),
.B2(n_109),
.Y(n_142)
);

OAI22xp33_ASAP7_75t_L g143 ( 
.A1(n_126),
.A2(n_127),
.B1(n_133),
.B2(n_130),
.Y(n_143)
);

INVx4_ASAP7_75t_L g144 ( 
.A(n_129),
.Y(n_144)
);

OAI211xp5_ASAP7_75t_L g145 ( 
.A1(n_129),
.A2(n_108),
.B(n_113),
.C(n_120),
.Y(n_145)
);

INVx3_ASAP7_75t_L g146 ( 
.A(n_134),
.Y(n_146)
);

INVxp67_ASAP7_75t_SL g147 ( 
.A(n_139),
.Y(n_147)
);

OR2x2_ASAP7_75t_L g148 ( 
.A(n_137),
.B(n_114),
.Y(n_148)
);

OAI22xp5_ASAP7_75t_L g149 ( 
.A1(n_139),
.A2(n_114),
.B1(n_123),
.B2(n_112),
.Y(n_149)
);

NAND2xp33_ASAP7_75t_R g150 ( 
.A(n_146),
.B(n_2),
.Y(n_150)
);

NAND2xp33_ASAP7_75t_R g151 ( 
.A(n_146),
.B(n_2),
.Y(n_151)
);

INVx2_ASAP7_75t_L g152 ( 
.A(n_135),
.Y(n_152)
);

OAI21xp33_ASAP7_75t_L g153 ( 
.A1(n_146),
.A2(n_132),
.B(n_112),
.Y(n_153)
);

OR2x2_ASAP7_75t_L g154 ( 
.A(n_137),
.B(n_144),
.Y(n_154)
);

AOI22xp33_ASAP7_75t_L g155 ( 
.A1(n_144),
.A2(n_123),
.B1(n_78),
.B2(n_110),
.Y(n_155)
);

NOR2xp33_ASAP7_75t_R g156 ( 
.A(n_144),
.B(n_146),
.Y(n_156)
);

HB1xp67_ASAP7_75t_L g157 ( 
.A(n_135),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_135),
.Y(n_158)
);

AND2x2_ASAP7_75t_L g159 ( 
.A(n_144),
.B(n_78),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_138),
.Y(n_160)
);

AND2x2_ASAP7_75t_L g161 ( 
.A(n_140),
.B(n_85),
.Y(n_161)
);

BUFx2_ASAP7_75t_L g162 ( 
.A(n_138),
.Y(n_162)
);

HB1xp67_ASAP7_75t_L g163 ( 
.A(n_136),
.Y(n_163)
);

OA21x2_ASAP7_75t_L g164 ( 
.A1(n_140),
.A2(n_91),
.B(n_90),
.Y(n_164)
);

AOI222xp33_ASAP7_75t_L g165 ( 
.A1(n_143),
.A2(n_77),
.B1(n_95),
.B2(n_110),
.C1(n_116),
.C2(n_107),
.Y(n_165)
);

NOR4xp25_ASAP7_75t_SL g166 ( 
.A(n_143),
.B(n_83),
.C(n_84),
.D(n_3),
.Y(n_166)
);

AOI221xp5_ASAP7_75t_L g167 ( 
.A1(n_153),
.A2(n_142),
.B1(n_145),
.B2(n_136),
.C(n_141),
.Y(n_167)
);

OR2x2_ASAP7_75t_L g168 ( 
.A(n_154),
.B(n_145),
.Y(n_168)
);

OR2x2_ASAP7_75t_L g169 ( 
.A(n_154),
.B(n_141),
.Y(n_169)
);

INVx2_ASAP7_75t_L g170 ( 
.A(n_152),
.Y(n_170)
);

AND2x2_ASAP7_75t_L g171 ( 
.A(n_162),
.B(n_3),
.Y(n_171)
);

OAI21xp33_ASAP7_75t_L g172 ( 
.A1(n_156),
.A2(n_153),
.B(n_165),
.Y(n_172)
);

NOR2xp33_ASAP7_75t_L g173 ( 
.A(n_159),
.B(n_4),
.Y(n_173)
);

OAI22xp5_ASAP7_75t_L g174 ( 
.A1(n_149),
.A2(n_119),
.B1(n_95),
.B2(n_110),
.Y(n_174)
);

OAI31xp33_ASAP7_75t_L g175 ( 
.A1(n_149),
.A2(n_119),
.A3(n_116),
.B(n_107),
.Y(n_175)
);

NOR2x1_ASAP7_75t_L g176 ( 
.A(n_158),
.B(n_83),
.Y(n_176)
);

OR2x2_ASAP7_75t_L g177 ( 
.A(n_162),
.B(n_4),
.Y(n_177)
);

OR2x2_ASAP7_75t_L g178 ( 
.A(n_157),
.B(n_5),
.Y(n_178)
);

AND2x2_ASAP7_75t_L g179 ( 
.A(n_158),
.B(n_5),
.Y(n_179)
);

OR2x2_ASAP7_75t_L g180 ( 
.A(n_157),
.B(n_6),
.Y(n_180)
);

AND2x2_ASAP7_75t_L g181 ( 
.A(n_152),
.B(n_7),
.Y(n_181)
);

NOR2xp33_ASAP7_75t_L g182 ( 
.A(n_159),
.B(n_7),
.Y(n_182)
);

NAND3xp33_ASAP7_75t_L g183 ( 
.A(n_150),
.B(n_151),
.C(n_165),
.Y(n_183)
);

NAND2xp67_ASAP7_75t_L g184 ( 
.A(n_159),
.B(n_8),
.Y(n_184)
);

AND2x2_ASAP7_75t_L g185 ( 
.A(n_152),
.B(n_10),
.Y(n_185)
);

INVx2_ASAP7_75t_L g186 ( 
.A(n_160),
.Y(n_186)
);

AND2x2_ASAP7_75t_L g187 ( 
.A(n_160),
.B(n_10),
.Y(n_187)
);

HB1xp67_ASAP7_75t_L g188 ( 
.A(n_148),
.Y(n_188)
);

INVx1_ASAP7_75t_L g189 ( 
.A(n_163),
.Y(n_189)
);

INVx1_ASAP7_75t_L g190 ( 
.A(n_163),
.Y(n_190)
);

INVx2_ASAP7_75t_SL g191 ( 
.A(n_148),
.Y(n_191)
);

INVx2_ASAP7_75t_L g192 ( 
.A(n_164),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_147),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_161),
.Y(n_194)
);

INVx1_ASAP7_75t_L g195 ( 
.A(n_161),
.Y(n_195)
);

INVx1_ASAP7_75t_SL g196 ( 
.A(n_161),
.Y(n_196)
);

AOI22xp33_ASAP7_75t_L g197 ( 
.A1(n_147),
.A2(n_110),
.B1(n_116),
.B2(n_107),
.Y(n_197)
);

OR2x2_ASAP7_75t_L g198 ( 
.A(n_155),
.B(n_11),
.Y(n_198)
);

OR2x2_ASAP7_75t_L g199 ( 
.A(n_164),
.B(n_12),
.Y(n_199)
);

INVx1_ASAP7_75t_L g200 ( 
.A(n_186),
.Y(n_200)
);

INVx2_ASAP7_75t_L g201 ( 
.A(n_170),
.Y(n_201)
);

AND2x4_ASAP7_75t_L g202 ( 
.A(n_186),
.B(n_26),
.Y(n_202)
);

AOI21xp5_ASAP7_75t_L g203 ( 
.A1(n_175),
.A2(n_164),
.B(n_166),
.Y(n_203)
);

OAI22xp5_ASAP7_75t_L g204 ( 
.A1(n_183),
.A2(n_166),
.B1(n_164),
.B2(n_119),
.Y(n_204)
);

OR2x2_ASAP7_75t_L g205 ( 
.A(n_196),
.B(n_164),
.Y(n_205)
);

INVxp67_ASAP7_75t_SL g206 ( 
.A(n_188),
.Y(n_206)
);

AND2x2_ASAP7_75t_L g207 ( 
.A(n_194),
.B(n_13),
.Y(n_207)
);

INVx1_ASAP7_75t_L g208 ( 
.A(n_170),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_178),
.Y(n_209)
);

NAND2xp5_ASAP7_75t_L g210 ( 
.A(n_191),
.B(n_13),
.Y(n_210)
);

INVx1_ASAP7_75t_L g211 ( 
.A(n_178),
.Y(n_211)
);

AND2x2_ASAP7_75t_L g212 ( 
.A(n_195),
.B(n_14),
.Y(n_212)
);

BUFx2_ASAP7_75t_L g213 ( 
.A(n_191),
.Y(n_213)
);

AND2x2_ASAP7_75t_L g214 ( 
.A(n_168),
.B(n_14),
.Y(n_214)
);

INVxp67_ASAP7_75t_L g215 ( 
.A(n_180),
.Y(n_215)
);

NAND2xp5_ASAP7_75t_L g216 ( 
.A(n_171),
.B(n_15),
.Y(n_216)
);

AND2x4_ASAP7_75t_L g217 ( 
.A(n_168),
.B(n_27),
.Y(n_217)
);

AND2x2_ASAP7_75t_L g218 ( 
.A(n_193),
.B(n_15),
.Y(n_218)
);

OR2x2_ASAP7_75t_L g219 ( 
.A(n_189),
.B(n_16),
.Y(n_219)
);

INVx2_ASAP7_75t_SL g220 ( 
.A(n_180),
.Y(n_220)
);

NAND2xp5_ASAP7_75t_L g221 ( 
.A(n_171),
.B(n_76),
.Y(n_221)
);

NAND2x1p5_ASAP7_75t_L g222 ( 
.A(n_199),
.B(n_107),
.Y(n_222)
);

HB1xp67_ASAP7_75t_L g223 ( 
.A(n_185),
.Y(n_223)
);

AND2x2_ASAP7_75t_L g224 ( 
.A(n_193),
.B(n_76),
.Y(n_224)
);

AND2x4_ASAP7_75t_L g225 ( 
.A(n_189),
.B(n_30),
.Y(n_225)
);

OA21x2_ASAP7_75t_L g226 ( 
.A1(n_192),
.A2(n_84),
.B(n_92),
.Y(n_226)
);

OR2x2_ASAP7_75t_L g227 ( 
.A(n_190),
.B(n_76),
.Y(n_227)
);

INVx1_ASAP7_75t_SL g228 ( 
.A(n_185),
.Y(n_228)
);

NAND2xp5_ASAP7_75t_L g229 ( 
.A(n_179),
.B(n_76),
.Y(n_229)
);

INVx2_ASAP7_75t_L g230 ( 
.A(n_190),
.Y(n_230)
);

OAI21xp5_ASAP7_75t_L g231 ( 
.A1(n_173),
.A2(n_76),
.B(n_119),
.Y(n_231)
);

OR2x2_ASAP7_75t_L g232 ( 
.A(n_169),
.B(n_73),
.Y(n_232)
);

NAND2xp5_ASAP7_75t_L g233 ( 
.A(n_179),
.B(n_116),
.Y(n_233)
);

INVx1_ASAP7_75t_L g234 ( 
.A(n_181),
.Y(n_234)
);

BUFx2_ASAP7_75t_L g235 ( 
.A(n_199),
.Y(n_235)
);

NAND2xp33_ASAP7_75t_SL g236 ( 
.A(n_177),
.B(n_73),
.Y(n_236)
);

INVxp67_ASAP7_75t_L g237 ( 
.A(n_182),
.Y(n_237)
);

AND2x2_ASAP7_75t_L g238 ( 
.A(n_192),
.B(n_73),
.Y(n_238)
);

NAND3xp33_ASAP7_75t_L g239 ( 
.A(n_177),
.B(n_167),
.C(n_172),
.Y(n_239)
);

NOR2x1p5_ASAP7_75t_SL g240 ( 
.A(n_198),
.B(n_92),
.Y(n_240)
);

INVx4_ASAP7_75t_L g241 ( 
.A(n_181),
.Y(n_241)
);

INVx1_ASAP7_75t_SL g242 ( 
.A(n_213),
.Y(n_242)
);

INVx1_ASAP7_75t_L g243 ( 
.A(n_230),
.Y(n_243)
);

INVx2_ASAP7_75t_L g244 ( 
.A(n_201),
.Y(n_244)
);

INVx1_ASAP7_75t_L g245 ( 
.A(n_230),
.Y(n_245)
);

NAND2xp5_ASAP7_75t_L g246 ( 
.A(n_206),
.B(n_187),
.Y(n_246)
);

NAND2xp5_ASAP7_75t_L g247 ( 
.A(n_215),
.B(n_187),
.Y(n_247)
);

AOI222xp33_ASAP7_75t_L g248 ( 
.A1(n_239),
.A2(n_174),
.B1(n_176),
.B2(n_197),
.C1(n_184),
.C2(n_198),
.Y(n_248)
);

AOI32xp33_ASAP7_75t_L g249 ( 
.A1(n_236),
.A2(n_169),
.A3(n_184),
.B1(n_68),
.B2(n_103),
.Y(n_249)
);

INVx1_ASAP7_75t_L g250 ( 
.A(n_213),
.Y(n_250)
);

INVxp67_ASAP7_75t_L g251 ( 
.A(n_236),
.Y(n_251)
);

AOI22xp33_ASAP7_75t_SL g252 ( 
.A1(n_241),
.A2(n_73),
.B1(n_68),
.B2(n_32),
.Y(n_252)
);

NAND3xp33_ASAP7_75t_L g253 ( 
.A(n_237),
.B(n_73),
.C(n_103),
.Y(n_253)
);

AOI22xp5_ASAP7_75t_L g254 ( 
.A1(n_217),
.A2(n_106),
.B1(n_92),
.B2(n_34),
.Y(n_254)
);

NAND2xp5_ASAP7_75t_L g255 ( 
.A(n_209),
.B(n_35),
.Y(n_255)
);

NAND2xp5_ASAP7_75t_L g256 ( 
.A(n_211),
.B(n_36),
.Y(n_256)
);

OR2x2_ASAP7_75t_L g257 ( 
.A(n_223),
.B(n_37),
.Y(n_257)
);

NAND2xp5_ASAP7_75t_L g258 ( 
.A(n_220),
.B(n_38),
.Y(n_258)
);

OAI22xp5_ASAP7_75t_L g259 ( 
.A1(n_241),
.A2(n_39),
.B1(n_106),
.B2(n_217),
.Y(n_259)
);

INVx1_ASAP7_75t_L g260 ( 
.A(n_219),
.Y(n_260)
);

INVx2_ASAP7_75t_L g261 ( 
.A(n_201),
.Y(n_261)
);

INVx1_ASAP7_75t_L g262 ( 
.A(n_219),
.Y(n_262)
);

AOI22xp33_ASAP7_75t_L g263 ( 
.A1(n_204),
.A2(n_106),
.B1(n_214),
.B2(n_216),
.Y(n_263)
);

NAND2xp5_ASAP7_75t_L g264 ( 
.A(n_220),
.B(n_214),
.Y(n_264)
);

OR2x2_ASAP7_75t_L g265 ( 
.A(n_228),
.B(n_241),
.Y(n_265)
);

OAI21xp5_ASAP7_75t_L g266 ( 
.A1(n_217),
.A2(n_203),
.B(n_218),
.Y(n_266)
);

INVx1_ASAP7_75t_L g267 ( 
.A(n_200),
.Y(n_267)
);

NAND2xp5_ASAP7_75t_L g268 ( 
.A(n_218),
.B(n_207),
.Y(n_268)
);

AND2x2_ASAP7_75t_L g269 ( 
.A(n_234),
.B(n_235),
.Y(n_269)
);

OAI32xp33_ASAP7_75t_L g270 ( 
.A1(n_222),
.A2(n_205),
.A3(n_210),
.B1(n_212),
.B2(n_207),
.Y(n_270)
);

NAND2xp5_ASAP7_75t_SL g271 ( 
.A(n_202),
.B(n_225),
.Y(n_271)
);

INVxp67_ASAP7_75t_L g272 ( 
.A(n_235),
.Y(n_272)
);

INVx1_ASAP7_75t_L g273 ( 
.A(n_200),
.Y(n_273)
);

INVx3_ASAP7_75t_L g274 ( 
.A(n_202),
.Y(n_274)
);

INVxp67_ASAP7_75t_SL g275 ( 
.A(n_226),
.Y(n_275)
);

AND2x4_ASAP7_75t_L g276 ( 
.A(n_208),
.B(n_205),
.Y(n_276)
);

INVx1_ASAP7_75t_L g277 ( 
.A(n_208),
.Y(n_277)
);

INVx1_ASAP7_75t_L g278 ( 
.A(n_225),
.Y(n_278)
);

OAI32xp33_ASAP7_75t_L g279 ( 
.A1(n_222),
.A2(n_212),
.A3(n_231),
.B1(n_232),
.B2(n_221),
.Y(n_279)
);

NAND2xp5_ASAP7_75t_L g280 ( 
.A(n_222),
.B(n_225),
.Y(n_280)
);

AND2x2_ASAP7_75t_L g281 ( 
.A(n_224),
.B(n_238),
.Y(n_281)
);

INVx1_ASAP7_75t_L g282 ( 
.A(n_227),
.Y(n_282)
);

O2A1O1Ixp5_ASAP7_75t_SL g283 ( 
.A1(n_251),
.A2(n_229),
.B(n_233),
.C(n_240),
.Y(n_283)
);

AOI21xp33_ASAP7_75t_L g284 ( 
.A1(n_248),
.A2(n_227),
.B(n_232),
.Y(n_284)
);

AOI22xp5_ASAP7_75t_L g285 ( 
.A1(n_271),
.A2(n_202),
.B1(n_224),
.B2(n_226),
.Y(n_285)
);

HB1xp67_ASAP7_75t_L g286 ( 
.A(n_242),
.Y(n_286)
);

AND2x2_ASAP7_75t_L g287 ( 
.A(n_276),
.B(n_238),
.Y(n_287)
);

CKINVDCx5p33_ASAP7_75t_R g288 ( 
.A(n_264),
.Y(n_288)
);

INVx2_ASAP7_75t_L g289 ( 
.A(n_244),
.Y(n_289)
);

XNOR2xp5_ASAP7_75t_L g290 ( 
.A(n_268),
.B(n_226),
.Y(n_290)
);

NAND2xp5_ASAP7_75t_L g291 ( 
.A(n_269),
.B(n_240),
.Y(n_291)
);

INVx1_ASAP7_75t_L g292 ( 
.A(n_243),
.Y(n_292)
);

NAND2xp5_ASAP7_75t_L g293 ( 
.A(n_260),
.B(n_262),
.Y(n_293)
);

INVxp67_ASAP7_75t_SL g294 ( 
.A(n_275),
.Y(n_294)
);

AOI22xp5_ASAP7_75t_L g295 ( 
.A1(n_271),
.A2(n_251),
.B1(n_263),
.B2(n_252),
.Y(n_295)
);

INVx1_ASAP7_75t_L g296 ( 
.A(n_245),
.Y(n_296)
);

OAI31xp33_ASAP7_75t_L g297 ( 
.A1(n_259),
.A2(n_265),
.A3(n_272),
.B(n_247),
.Y(n_297)
);

NAND2xp5_ASAP7_75t_SL g298 ( 
.A(n_252),
.B(n_266),
.Y(n_298)
);

INVx2_ASAP7_75t_SL g299 ( 
.A(n_276),
.Y(n_299)
);

INVx1_ASAP7_75t_L g300 ( 
.A(n_277),
.Y(n_300)
);

BUFx2_ASAP7_75t_L g301 ( 
.A(n_275),
.Y(n_301)
);

HB1xp67_ASAP7_75t_L g302 ( 
.A(n_272),
.Y(n_302)
);

INVxp67_ASAP7_75t_L g303 ( 
.A(n_250),
.Y(n_303)
);

INVx1_ASAP7_75t_L g304 ( 
.A(n_267),
.Y(n_304)
);

AND2x2_ASAP7_75t_L g305 ( 
.A(n_281),
.B(n_244),
.Y(n_305)
);

AOI22xp5_ASAP7_75t_L g306 ( 
.A1(n_263),
.A2(n_278),
.B1(n_282),
.B2(n_246),
.Y(n_306)
);

AND2x2_ASAP7_75t_L g307 ( 
.A(n_261),
.B(n_273),
.Y(n_307)
);

HB1xp67_ASAP7_75t_L g308 ( 
.A(n_261),
.Y(n_308)
);

NAND2xp5_ASAP7_75t_L g309 ( 
.A(n_270),
.B(n_274),
.Y(n_309)
);

AND2x2_ASAP7_75t_L g310 ( 
.A(n_274),
.B(n_280),
.Y(n_310)
);

AND2x2_ASAP7_75t_L g311 ( 
.A(n_299),
.B(n_279),
.Y(n_311)
);

INVxp67_ASAP7_75t_L g312 ( 
.A(n_286),
.Y(n_312)
);

INVx1_ASAP7_75t_L g313 ( 
.A(n_302),
.Y(n_313)
);

INVx1_ASAP7_75t_L g314 ( 
.A(n_300),
.Y(n_314)
);

XNOR2xp5_ASAP7_75t_L g315 ( 
.A(n_288),
.B(n_290),
.Y(n_315)
);

NOR2xp67_ASAP7_75t_L g316 ( 
.A(n_298),
.B(n_253),
.Y(n_316)
);

AOI22xp5_ASAP7_75t_L g317 ( 
.A1(n_295),
.A2(n_258),
.B1(n_255),
.B2(n_256),
.Y(n_317)
);

INVx1_ASAP7_75t_L g318 ( 
.A(n_300),
.Y(n_318)
);

INVx2_ASAP7_75t_L g319 ( 
.A(n_301),
.Y(n_319)
);

NAND2xp5_ASAP7_75t_L g320 ( 
.A(n_290),
.B(n_257),
.Y(n_320)
);

NAND2xp5_ASAP7_75t_L g321 ( 
.A(n_303),
.B(n_249),
.Y(n_321)
);

BUFx12f_ASAP7_75t_L g322 ( 
.A(n_288),
.Y(n_322)
);

INVx1_ASAP7_75t_L g323 ( 
.A(n_304),
.Y(n_323)
);

INVxp67_ASAP7_75t_L g324 ( 
.A(n_301),
.Y(n_324)
);

NAND3xp33_ASAP7_75t_L g325 ( 
.A(n_297),
.B(n_254),
.C(n_295),
.Y(n_325)
);

AOI332xp33_ASAP7_75t_L g326 ( 
.A1(n_313),
.A2(n_306),
.A3(n_293),
.B1(n_309),
.B2(n_304),
.B3(n_296),
.C1(n_292),
.C2(n_305),
.Y(n_326)
);

O2A1O1Ixp33_ASAP7_75t_L g327 ( 
.A1(n_325),
.A2(n_284),
.B(n_294),
.C(n_291),
.Y(n_327)
);

INVx1_ASAP7_75t_L g328 ( 
.A(n_314),
.Y(n_328)
);

INVx1_ASAP7_75t_SL g329 ( 
.A(n_322),
.Y(n_329)
);

OAI211xp5_ASAP7_75t_SL g330 ( 
.A1(n_321),
.A2(n_285),
.B(n_299),
.C(n_292),
.Y(n_330)
);

NOR2x1_ASAP7_75t_L g331 ( 
.A(n_316),
.B(n_296),
.Y(n_331)
);

AOI222xp33_ASAP7_75t_L g332 ( 
.A1(n_312),
.A2(n_310),
.B1(n_305),
.B2(n_287),
.C1(n_307),
.C2(n_308),
.Y(n_332)
);

NAND4xp25_ASAP7_75t_L g333 ( 
.A(n_317),
.B(n_285),
.C(n_310),
.D(n_287),
.Y(n_333)
);

AOI221xp5_ASAP7_75t_L g334 ( 
.A1(n_327),
.A2(n_312),
.B1(n_324),
.B2(n_315),
.C(n_311),
.Y(n_334)
);

AOI22xp5_ASAP7_75t_L g335 ( 
.A1(n_333),
.A2(n_320),
.B1(n_322),
.B2(n_324),
.Y(n_335)
);

NAND5xp2_ASAP7_75t_L g336 ( 
.A(n_326),
.B(n_283),
.C(n_323),
.D(n_318),
.E(n_307),
.Y(n_336)
);

OAI32xp33_ASAP7_75t_L g337 ( 
.A1(n_330),
.A2(n_283),
.A3(n_289),
.B1(n_319),
.B2(n_329),
.Y(n_337)
);

INVxp67_ASAP7_75t_L g338 ( 
.A(n_335),
.Y(n_338)
);

INVx1_ASAP7_75t_SL g339 ( 
.A(n_334),
.Y(n_339)
);

AOI221xp5_ASAP7_75t_L g340 ( 
.A1(n_339),
.A2(n_336),
.B1(n_337),
.B2(n_319),
.C(n_328),
.Y(n_340)
);

AND2x4_ASAP7_75t_L g341 ( 
.A(n_340),
.B(n_338),
.Y(n_341)
);

INVx1_ASAP7_75t_L g342 ( 
.A(n_341),
.Y(n_342)
);

AOI22xp5_ASAP7_75t_L g343 ( 
.A1(n_342),
.A2(n_341),
.B1(n_331),
.B2(n_332),
.Y(n_343)
);

AOI21xp5_ASAP7_75t_L g344 ( 
.A1(n_343),
.A2(n_328),
.B(n_289),
.Y(n_344)
);


endmodule