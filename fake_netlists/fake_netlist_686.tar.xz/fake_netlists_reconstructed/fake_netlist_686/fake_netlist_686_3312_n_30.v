module fake_netlist_686_3312_n_30 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_30);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_30;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_7;
wire n_23;
wire n_29;
wire n_8;
wire n_28;
wire n_11;
wire n_19;
wire n_25;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

NAND2xp33_ASAP7_75t_L g8 ( 
.A(n_4),
.B(n_5),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_1),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_4),
.B(n_2),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_5),
.B(n_2),
.Y(n_14)
);

AOI221x1_ASAP7_75t_L g15 ( 
.A1(n_10),
.A2(n_6),
.B1(n_7),
.B2(n_11),
.C(n_9),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_10),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_10),
.Y(n_18)
);

AOI211xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_8),
.B(n_14),
.C(n_13),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_SL g21 ( 
.A1(n_17),
.A2(n_15),
.B(n_10),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_8),
.B1(n_16),
.B2(n_14),
.C1(n_13),
.C2(n_15),
.Y(n_22)
);

NOR4xp25_ASAP7_75t_SL g23 ( 
.A(n_19),
.B(n_13),
.C(n_6),
.D(n_16),
.Y(n_23)
);

O2A1O1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_16),
.B(n_19),
.C(n_8),
.Y(n_24)
);

BUFx12f_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_21),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_22),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_26),
.B(n_25),
.Y(n_28)
);

OAI22x1_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_26),
.B1(n_25),
.B2(n_8),
.Y(n_29)
);

OAI222xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_25),
.B1(n_26),
.B2(n_27),
.C1(n_29),
.C2(n_24),
.Y(n_30)
);


endmodule