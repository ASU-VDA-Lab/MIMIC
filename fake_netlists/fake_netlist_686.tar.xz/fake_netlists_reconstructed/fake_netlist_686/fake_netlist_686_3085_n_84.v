module fake_netlist_686_3085_n_84 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_84);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_84;

wire n_61;
wire n_27;
wire n_40;
wire n_66;
wire n_47;
wire n_35;
wire n_52;
wire n_71;
wire n_60;
wire n_33;
wire n_30;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_83;
wire n_45;
wire n_64;
wire n_58;
wire n_62;
wire n_76;
wire n_63;
wire n_70;
wire n_69;
wire n_53;
wire n_74;
wire n_28;
wire n_75;
wire n_81;
wire n_55;
wire n_54;
wire n_78;
wire n_44;
wire n_38;
wire n_42;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_68;
wire n_32;
wire n_77;
wire n_82;
wire n_79;
wire n_46;
wire n_31;
wire n_73;
wire n_41;
wire n_29;
wire n_56;
wire n_72;
wire n_65;
wire n_80;
wire n_36;
wire n_25;
wire n_49;
wire n_57;

INVx1_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

INVx4_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_4),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_7),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_2),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_12),
.Y(n_31)
);

INVx5_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_3),
.Y(n_33)
);

INVx5_ASAP7_75t_L g34 ( 
.A(n_20),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_16),
.Y(n_36)
);

INVx4_ASAP7_75t_L g37 ( 
.A(n_10),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_6),
.B(n_0),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_8),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_13),
.B(n_17),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_23),
.B(n_17),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_15),
.B(n_14),
.Y(n_42)
);

CKINVDCx20_ASAP7_75t_R g43 ( 
.A(n_18),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_25),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_30),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_28),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_28),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_29),
.Y(n_48)
);

AND2x4_ASAP7_75t_L g49 ( 
.A(n_26),
.B(n_36),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_27),
.Y(n_50)
);

NOR2xp33_ASAP7_75t_R g51 ( 
.A(n_33),
.B(n_1),
.Y(n_51)
);

BUFx2_ASAP7_75t_L g52 ( 
.A(n_41),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_30),
.Y(n_53)
);

INVx2_ASAP7_75t_SL g54 ( 
.A(n_32),
.Y(n_54)
);

INVxp33_ASAP7_75t_L g55 ( 
.A(n_35),
.Y(n_55)
);

CKINVDCx5p33_ASAP7_75t_R g56 ( 
.A(n_43),
.Y(n_56)
);

AOI22xp33_ASAP7_75t_L g57 ( 
.A1(n_52),
.A2(n_36),
.B1(n_26),
.B2(n_41),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_42),
.B1(n_38),
.B2(n_31),
.Y(n_58)
);

INVx3_ASAP7_75t_L g59 ( 
.A(n_50),
.Y(n_59)
);

INVx1_ASAP7_75t_SL g60 ( 
.A(n_56),
.Y(n_60)
);

OAI21x1_ASAP7_75t_L g61 ( 
.A1(n_50),
.A2(n_39),
.B(n_40),
.Y(n_61)
);

OAI21x1_ASAP7_75t_L g62 ( 
.A1(n_44),
.A2(n_38),
.B(n_27),
.Y(n_62)
);

INVx2_ASAP7_75t_L g63 ( 
.A(n_59),
.Y(n_63)
);

OR2x2_ASAP7_75t_L g64 ( 
.A(n_60),
.B(n_49),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_59),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_59),
.Y(n_66)
);

INVx3_ASAP7_75t_L g67 ( 
.A(n_63),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_63),
.Y(n_68)
);

NAND2xp5_ASAP7_75t_L g69 ( 
.A(n_64),
.B(n_58),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_65),
.Y(n_70)
);

OAI21xp33_ASAP7_75t_L g71 ( 
.A1(n_69),
.A2(n_64),
.B(n_57),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_68),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_70),
.Y(n_73)
);

AOI211xp5_ASAP7_75t_L g74 ( 
.A1(n_71),
.A2(n_49),
.B(n_53),
.C(n_45),
.Y(n_74)
);

AOI21xp33_ASAP7_75t_SL g75 ( 
.A1(n_73),
.A2(n_20),
.B(n_19),
.Y(n_75)
);

AOI221xp5_ASAP7_75t_L g76 ( 
.A1(n_72),
.A2(n_48),
.B1(n_47),
.B2(n_46),
.C(n_66),
.Y(n_76)
);

NAND2xp5_ASAP7_75t_L g77 ( 
.A(n_74),
.B(n_61),
.Y(n_77)
);

AOI22xp5_ASAP7_75t_SL g78 ( 
.A1(n_75),
.A2(n_37),
.B1(n_21),
.B2(n_19),
.Y(n_78)
);

AND3x4_ASAP7_75t_L g79 ( 
.A(n_76),
.B(n_24),
.C(n_34),
.Y(n_79)
);

OAI22xp5_ASAP7_75t_L g80 ( 
.A1(n_79),
.A2(n_34),
.B1(n_67),
.B2(n_54),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_78),
.Y(n_81)
);

HB1xp67_ASAP7_75t_L g82 ( 
.A(n_77),
.Y(n_82)
);

OAI221xp5_ASAP7_75t_L g83 ( 
.A1(n_81),
.A2(n_67),
.B1(n_62),
.B2(n_51),
.C(n_9),
.Y(n_83)
);

AOI22xp33_ASAP7_75t_SL g84 ( 
.A1(n_83),
.A2(n_82),
.B1(n_80),
.B2(n_81),
.Y(n_84)
);


endmodule