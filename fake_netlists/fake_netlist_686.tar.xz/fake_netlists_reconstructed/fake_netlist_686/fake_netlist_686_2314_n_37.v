module fake_netlist_686_2314_n_37 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_37);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_37;

wire n_24;
wire n_21;
wire n_27;
wire n_22;
wire n_35;
wire n_34;
wire n_26;
wire n_31;
wire n_23;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;

BUFx2_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_R g23 ( 
.A(n_4),
.B(n_8),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_6),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

O2A1O1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_22),
.A2(n_17),
.B(n_1),
.C(n_0),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_21),
.B(n_24),
.Y(n_28)
);

AO32x1_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_17),
.A3(n_7),
.B1(n_2),
.B2(n_3),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_25),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_31),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_29),
.B1(n_23),
.B2(n_10),
.C(n_11),
.Y(n_34)
);

CKINVDCx16_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_20),
.B1(n_19),
.B2(n_16),
.Y(n_37)
);


endmodule