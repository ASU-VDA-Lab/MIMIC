module fake_netlist_686_2735_n_52 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_52);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_52;

wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_48;
wire n_49;
wire n_39;

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_0),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_18),
.Y(n_30)
);

NOR2xp67_ASAP7_75t_L g31 ( 
.A(n_1),
.B(n_9),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_13),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_5),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_24),
.A2(n_8),
.B1(n_11),
.B2(n_26),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_22),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_28),
.B(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_SL g39 ( 
.A(n_35),
.B(n_25),
.C(n_24),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_R g40 ( 
.A(n_38),
.B(n_36),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

NOR2xp67_ASAP7_75t_SL g44 ( 
.A(n_43),
.B(n_30),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_37),
.B1(n_32),
.B2(n_29),
.Y(n_45)
);

AOI322xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_39),
.A3(n_42),
.B1(n_33),
.B2(n_26),
.C1(n_27),
.C2(n_31),
.Y(n_46)
);

OAI221xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_3),
.B1(n_2),
.B2(n_4),
.C(n_6),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_SL g48 ( 
.A1(n_47),
.A2(n_12),
.B1(n_10),
.B2(n_7),
.Y(n_48)
);

INVx1_ASAP7_75t_SL g49 ( 
.A(n_46),
.Y(n_49)
);

OAI22xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.Y(n_50)
);

OAI22xp5_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_20),
.B1(n_19),
.B2(n_17),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_SL g52 ( 
.A1(n_51),
.A2(n_21),
.B1(n_23),
.B2(n_50),
.Y(n_52)
);


endmodule