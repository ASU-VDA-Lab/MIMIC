module fake_netlist_686_2626_n_32 (n_9, n_4, n_2, n_7, n_14, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_32);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_32;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

INVx1_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_13),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_12),
.B(n_14),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_5),
.B(n_6),
.Y(n_18)
);

INVx2_ASAP7_75t_SL g19 ( 
.A(n_11),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_1),
.B(n_0),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_7),
.B1(n_3),
.B2(n_2),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_23),
.B(n_15),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_20),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

OAI211xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_20),
.B(n_25),
.C(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

OAI22x1_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_16),
.B1(n_7),
.B2(n_18),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_29),
.B1(n_17),
.B2(n_8),
.C(n_9),
.Y(n_32)
);


endmodule