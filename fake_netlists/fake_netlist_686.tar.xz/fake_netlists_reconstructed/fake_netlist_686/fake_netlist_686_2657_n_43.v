module fake_netlist_686_2657_n_43 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_43);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_43;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;

INVx2_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_13),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_8),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_12),
.B(n_7),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_0),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_0),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_2),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_2),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_26),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_20),
.B1(n_28),
.B2(n_25),
.Y(n_31)
);

OAI33xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_22),
.A3(n_23),
.B1(n_5),
.B2(n_4),
.B3(n_3),
.Y(n_32)
);

AOI21xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_21),
.B(n_5),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_11),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_16),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_17),
.B1(n_10),
.B2(n_6),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

OR3x2_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_14),
.C(n_38),
.Y(n_40)
);

BUFx4f_ASAP7_75t_SL g41 ( 
.A(n_37),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_40),
.B1(n_39),
.B2(n_41),
.Y(n_43)
);


endmodule