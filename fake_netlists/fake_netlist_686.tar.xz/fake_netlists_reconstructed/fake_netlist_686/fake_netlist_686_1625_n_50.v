module fake_netlist_686_1625_n_50 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_50);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_50;

wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_48;
wire n_49;
wire n_39;

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_10),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_15),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_11),
.B(n_8),
.C(n_25),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_12),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_0),
.B(n_21),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_18),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_3),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

O2A1O1Ixp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_25),
.B(n_24),
.C(n_16),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_27),
.A2(n_16),
.B1(n_2),
.B2(n_1),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_26),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVxp67_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_31),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_27),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_33),
.B1(n_29),
.B2(n_32),
.Y(n_43)
);

AOI311xp33_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_36),
.A3(n_30),
.B(n_28),
.C(n_4),
.Y(n_44)
);

AOI211xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

BUFx6f_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

OAI31xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_14),
.A3(n_13),
.B(n_9),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_22),
.B1(n_19),
.B2(n_17),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_49),
.A2(n_23),
.B1(n_47),
.B2(n_48),
.Y(n_50)
);


endmodule