module fake_netlist_686_2916_n_23 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_23);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_23;

wire n_21;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_13;
wire n_8;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_11),
.Y(n_12)
);

NOR2xp67_ASAP7_75t_SL g13 ( 
.A(n_8),
.B(n_0),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_12),
.B(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_5),
.B(n_1),
.Y(n_16)
);

AOI21xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_5),
.B(n_1),
.Y(n_17)
);

NOR2x1_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_8),
.Y(n_18)
);

NAND5xp2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_7),
.C(n_6),
.D(n_8),
.E(n_3),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AO22x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_19),
.B1(n_7),
.B2(n_8),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_13),
.B(n_21),
.Y(n_23)
);


endmodule