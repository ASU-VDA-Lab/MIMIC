module fake_netlist_686_1213_n_75 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_75);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_75;

wire n_54;
wire n_24;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_66;
wire n_47;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_71;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_70;
wire n_31;
wire n_23;
wire n_46;
wire n_41;
wire n_69;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_68;
wire n_72;
wire n_33;
wire n_65;
wire n_73;
wire n_74;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_67;
wire n_39;
wire n_55;

INVx3_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_13),
.A2(n_8),
.B1(n_17),
.B2(n_9),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_4),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_21),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_14),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_6),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_2),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_7),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_25),
.A2(n_16),
.B1(n_11),
.B2(n_3),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_23),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_23),
.B(n_3),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_25),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_23),
.B(n_11),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_SL g41 ( 
.A(n_23),
.B(n_16),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_35),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_L g43 ( 
.A1(n_36),
.A2(n_29),
.B1(n_30),
.B2(n_24),
.Y(n_43)
);

OAI21x1_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_26),
.B(n_34),
.Y(n_44)
);

INVx3_ASAP7_75t_L g45 ( 
.A(n_37),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_39),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_37),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_44),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_45),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_43),
.Y(n_52)
);

AND2x4_ASAP7_75t_L g53 ( 
.A(n_47),
.B(n_41),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_43),
.Y(n_54)
);

OAI21xp33_ASAP7_75t_L g55 ( 
.A1(n_50),
.A2(n_49),
.B(n_38),
.Y(n_55)
);

OAI221xp5_ASAP7_75t_L g56 ( 
.A1(n_51),
.A2(n_47),
.B1(n_41),
.B2(n_30),
.C(n_45),
.Y(n_56)
);

AOI222xp33_ASAP7_75t_L g57 ( 
.A1(n_51),
.A2(n_27),
.B1(n_28),
.B2(n_26),
.C1(n_34),
.C2(n_33),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

A2O1A1Ixp33_ASAP7_75t_L g59 ( 
.A1(n_55),
.A2(n_53),
.B(n_26),
.C(n_28),
.Y(n_59)
);

AOI211xp5_ASAP7_75t_L g60 ( 
.A1(n_54),
.A2(n_53),
.B(n_27),
.C(n_26),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

OAI21xp33_ASAP7_75t_SL g62 ( 
.A1(n_57),
.A2(n_18),
.B(n_17),
.Y(n_62)
);

NOR3xp33_ASAP7_75t_L g63 ( 
.A(n_56),
.B(n_20),
.C(n_18),
.Y(n_63)
);

NOR2x1_ASAP7_75t_L g64 ( 
.A(n_59),
.B(n_58),
.Y(n_64)
);

OAI22xp5_ASAP7_75t_L g65 ( 
.A1(n_60),
.A2(n_33),
.B1(n_32),
.B2(n_20),
.Y(n_65)
);

NAND4xp75_ASAP7_75t_L g66 ( 
.A(n_62),
.B(n_22),
.C(n_5),
.D(n_0),
.Y(n_66)
);

XNOR2x1_ASAP7_75t_L g67 ( 
.A(n_61),
.B(n_22),
.Y(n_67)
);

NOR2xp33_ASAP7_75t_L g68 ( 
.A(n_63),
.B(n_33),
.Y(n_68)
);

AOI31xp33_ASAP7_75t_L g69 ( 
.A1(n_67),
.A2(n_12),
.A3(n_32),
.B(n_33),
.Y(n_69)
);

AOI21xp5_ASAP7_75t_L g70 ( 
.A1(n_64),
.A2(n_32),
.B(n_33),
.Y(n_70)
);

OR3x1_ASAP7_75t_L g71 ( 
.A(n_68),
.B(n_32),
.C(n_66),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_65),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_72),
.Y(n_73)
);

OAI22xp5_ASAP7_75t_SL g74 ( 
.A1(n_71),
.A2(n_32),
.B1(n_69),
.B2(n_70),
.Y(n_74)
);

AOI22xp33_ASAP7_75t_L g75 ( 
.A1(n_74),
.A2(n_32),
.B1(n_69),
.B2(n_73),
.Y(n_75)
);


endmodule