module fake_netlist_686_3119_n_22 (n_4, n_2, n_3, n_1, n_5, n_0, n_22);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_22;

wire n_21;
wire n_17;
wire n_6;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_7;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

O2A1O1Ixp5_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_4),
.B(n_3),
.C(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_3),
.B(n_0),
.Y(n_12)
);

OA21x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

NOR2x1_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_13),
.C(n_10),
.Y(n_18)
);

NOR3x1_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_5),
.C(n_4),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_13),
.B(n_14),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_13),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_17),
.B(n_20),
.Y(n_22)
);


endmodule