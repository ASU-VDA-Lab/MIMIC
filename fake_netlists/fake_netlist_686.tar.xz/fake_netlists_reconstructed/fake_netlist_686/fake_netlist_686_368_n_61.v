module fake_netlist_686_368_n_61 (n_2, n_21, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_61);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_61;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_58;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

BUFx2_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

NOR2x1_ASAP7_75t_L g25 ( 
.A(n_0),
.B(n_2),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_5),
.B(n_12),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_23),
.B(n_2),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_11),
.B1(n_10),
.B2(n_3),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_23),
.B(n_3),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_22),
.B(n_10),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_30),
.B1(n_29),
.B2(n_25),
.Y(n_37)
);

O2A1O1Ixp33_ASAP7_75t_SL g38 ( 
.A1(n_31),
.A2(n_28),
.B(n_26),
.C(n_6),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

OA21x2_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_28),
.B(n_33),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_35),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_35),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_34),
.B1(n_35),
.B2(n_39),
.C(n_32),
.Y(n_45)
);

INVxp67_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_39),
.B(n_40),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_43),
.B(n_40),
.Y(n_48)
);

AOI21xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_40),
.B(n_38),
.Y(n_49)
);

OA22x2_ASAP7_75t_SL g50 ( 
.A1(n_46),
.A2(n_40),
.B1(n_17),
.B2(n_16),
.Y(n_50)
);

AND3x4_ASAP7_75t_L g51 ( 
.A(n_50),
.B(n_33),
.C(n_18),
.Y(n_51)
);

NOR3xp33_ASAP7_75t_SL g52 ( 
.A(n_49),
.B(n_40),
.C(n_19),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_SL g53 ( 
.A(n_48),
.B(n_19),
.Y(n_53)
);

NOR3x2_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_21),
.C(n_20),
.Y(n_54)
);

XNOR2xp5_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_21),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

AOI22x1_ASAP7_75t_L g57 ( 
.A1(n_52),
.A2(n_13),
.B1(n_9),
.B2(n_8),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

INVxp67_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_L g60 ( 
.A1(n_55),
.A2(n_14),
.B1(n_57),
.B2(n_58),
.Y(n_60)
);

AOI21xp5_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_57),
.B(n_59),
.Y(n_61)
);


endmodule