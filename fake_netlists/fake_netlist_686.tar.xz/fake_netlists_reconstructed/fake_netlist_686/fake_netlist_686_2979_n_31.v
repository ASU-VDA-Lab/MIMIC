module fake_netlist_686_2979_n_31 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_31);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_31;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_7;
wire n_23;
wire n_29;
wire n_8;
wire n_28;
wire n_11;
wire n_19;
wire n_30;
wire n_25;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx5_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_1),
.B(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_6),
.Y(n_11)
);

NOR2x1p5_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_1),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_4),
.Y(n_14)
);

BUFx8_ASAP7_75t_SL g15 ( 
.A(n_11),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_7),
.B(n_4),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_6),
.B(n_0),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_12),
.B1(n_8),
.B2(n_7),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_12),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_18),
.B(n_14),
.Y(n_24)
);

AOI211xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_18),
.B(n_21),
.C(n_15),
.Y(n_25)
);

XOR2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_21),
.Y(n_26)
);

AOI221x1_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_21),
.B1(n_24),
.B2(n_22),
.C(n_19),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_21),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_22),
.C(n_15),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_27),
.B(n_6),
.Y(n_30)
);

OAI21xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B(n_3),
.Y(n_31)
);


endmodule