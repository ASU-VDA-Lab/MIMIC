module fake_netlist_686_778_n_57 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_57);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_57;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_16;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_56;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_19;
wire n_25;
wire n_48;
wire n_49;
wire n_13;
wire n_39;
wire n_14;
wire n_55;
wire n_12;

BUFx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

AOI21x1_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_3),
.B(n_9),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx16_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_1),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

AND2x6_ASAP7_75t_SL g21 ( 
.A(n_16),
.B(n_1),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_11),
.B(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_11),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_17),
.A2(n_5),
.B(n_4),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_11),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.C1(n_2),
.C2(n_0),
.Y(n_26)
);

NOR2xp67_ASAP7_75t_L g27 ( 
.A(n_17),
.B(n_7),
.Y(n_27)
);

O2A1O1Ixp33_ASAP7_75t_SL g28 ( 
.A1(n_18),
.A2(n_7),
.B(n_9),
.C(n_2),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_22),
.A2(n_18),
.B1(n_17),
.B2(n_14),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_R g31 ( 
.A(n_24),
.B(n_20),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_L g32 ( 
.A(n_25),
.B(n_17),
.C(n_13),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_23),
.B(n_16),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_13),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_27),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_26),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_34),
.B(n_24),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_35),
.B(n_33),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_35),
.Y(n_42)
);

OAI32xp33_ASAP7_75t_L g43 ( 
.A1(n_38),
.A2(n_39),
.A3(n_36),
.B1(n_24),
.B2(n_34),
.Y(n_43)
);

AOI21xp33_ASAP7_75t_L g44 ( 
.A1(n_37),
.A2(n_31),
.B(n_29),
.Y(n_44)
);

AOI222xp33_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_37),
.B1(n_19),
.B2(n_15),
.C1(n_13),
.C2(n_38),
.Y(n_45)
);

OAI21xp5_ASAP7_75t_L g46 ( 
.A1(n_40),
.A2(n_36),
.B(n_37),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_19),
.B1(n_15),
.B2(n_28),
.C(n_36),
.Y(n_47)
);

AOI211xp5_ASAP7_75t_L g48 ( 
.A1(n_42),
.A2(n_21),
.B(n_12),
.C(n_10),
.Y(n_48)
);

OAI221xp5_ASAP7_75t_L g49 ( 
.A1(n_42),
.A2(n_10),
.B1(n_12),
.B2(n_21),
.C(n_40),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_46),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_43),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_48),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_SL g53 ( 
.A(n_45),
.B(n_12),
.C(n_43),
.Y(n_53)
);

NOR2x1_ASAP7_75t_L g54 ( 
.A(n_53),
.B(n_48),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_47),
.B(n_50),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_SL g57 ( 
.A1(n_56),
.A2(n_50),
.B1(n_55),
.B2(n_54),
.Y(n_57)
);


endmodule