module fake_netlist_686_3302_n_7 (n_0, n_1, n_7);

input n_0;
input n_1;

output n_7;

wire n_4;
wire n_2;
wire n_3;
wire n_5;
wire n_6;

BUFx3_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

AND3x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_1),
.C(n_0),
.Y(n_4)
);

NAND3xp33_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.C(n_0),
.Y(n_5)
);

OAI22x1_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_6)
);

AOI21xp33_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_1),
.B(n_5),
.Y(n_7)
);


endmodule