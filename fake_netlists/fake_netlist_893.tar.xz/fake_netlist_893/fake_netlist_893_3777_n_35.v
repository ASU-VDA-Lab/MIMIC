module fake_netlist_893_3777_n_35 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_35);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_35;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_32;
wire n_26;
wire n_29;

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_0),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_14),
.Y(n_18)
);

BUFx12f_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_12),
.B(n_4),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_17),
.B1(n_15),
.B2(n_14),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_15),
.B1(n_20),
.B2(n_12),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_4),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_19),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_24),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_12),
.B1(n_16),
.B2(n_6),
.C(n_7),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_7),
.Y(n_31)
);

OR4x1_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_12),
.C(n_8),
.D(n_1),
.Y(n_32)
);

XNOR2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_9),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_32),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_10),
.B1(n_28),
.B2(n_33),
.Y(n_35)
);


endmodule