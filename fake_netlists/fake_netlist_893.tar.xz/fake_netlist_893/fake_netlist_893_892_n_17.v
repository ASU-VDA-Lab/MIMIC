module fake_netlist_893_892_n_17 (n_0, n_1, n_2, n_17);

input n_0;
input n_1;
input n_2;

output n_17;

wire n_5;
wire n_3;
wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

AND2x2_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B(n_0),
.Y(n_6)
);

AO31x2_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_7)
);

AO32x2_ASAP7_75t_L g8 ( 
.A1(n_3),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_4),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_4),
.Y(n_9)
);

NOR2x1_ASAP7_75t_R g10 ( 
.A(n_8),
.B(n_3),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

OAI21xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_11),
.B(n_8),
.Y(n_13)
);

NOR4xp25_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_8),
.C(n_7),
.D(n_2),
.Y(n_14)
);

NOR4xp75_ASAP7_75t_SL g15 ( 
.A(n_13),
.B(n_7),
.C(n_8),
.D(n_14),
.Y(n_15)
);

AOI22x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_12),
.B2(n_10),
.Y(n_16)
);

XOR2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_15),
.Y(n_17)
);


endmodule