module fake_netlist_893_3965_n_28 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_28);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_28;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_6),
.A2(n_5),
.B1(n_0),
.B2(n_9),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_5),
.B(n_7),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_1),
.B2(n_2),
.Y(n_17)
);

OR2x6_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_4),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_15),
.Y(n_19)
);

OR2x6_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_12),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_13),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_20),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

XOR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_19),
.Y(n_24)
);

OAI311xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_16),
.A3(n_15),
.B1(n_19),
.C1(n_3),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_11),
.B(n_8),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_26),
.Y(n_28)
);


endmodule