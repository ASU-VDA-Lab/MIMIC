module fake_netlist_893_2929_n_55 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_55);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_55;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_19;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_22;
wire n_25;
wire n_35;
wire n_32;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_10),
.B(n_11),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_4),
.B(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_2),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_16),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

BUFx3_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_20),
.B(n_0),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_0),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_23),
.B(n_1),
.Y(n_35)
);

OAI221xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_28),
.B1(n_27),
.B2(n_25),
.C(n_29),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_21),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_30),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_28),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_33),
.B1(n_35),
.B2(n_32),
.C1(n_30),
.C2(n_26),
.Y(n_41)
);

NOR2x1p5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_21),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_32),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_35),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

OAI21xp5_ASAP7_75t_SL g46 ( 
.A1(n_43),
.A2(n_41),
.B(n_32),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_35),
.Y(n_47)
);

NAND4xp25_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_35),
.C(n_32),
.D(n_31),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_42),
.B1(n_31),
.B2(n_19),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_50),
.Y(n_51)
);

OAI211xp5_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_24),
.B(n_15),
.C(n_1),
.Y(n_52)
);

AOI211xp5_ASAP7_75t_L g53 ( 
.A1(n_48),
.A2(n_18),
.B(n_17),
.C(n_3),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_51),
.Y(n_54)
);

AOI322xp5_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_53),
.A3(n_18),
.B1(n_17),
.B2(n_52),
.C1(n_5),
.C2(n_12),
.Y(n_55)
);


endmodule