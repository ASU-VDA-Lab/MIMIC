module fake_netlist_893_1418_n_20 (n_0, n_1, n_3, n_2, n_20);

input n_0;
input n_1;
input n_3;
input n_2;

output n_20;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_4;
wire n_19;
wire n_12;
wire n_5;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

INVx3_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

A2O1A1Ixp33_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_0),
.B(n_2),
.C(n_6),
.Y(n_8)
);

AO31x2_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_2),
.A3(n_4),
.B(n_5),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

NOR2xp67_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_4),
.Y(n_13)
);

O2A1O1Ixp33_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_8),
.B(n_4),
.C(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_5),
.Y(n_16)
);

NOR2xp67_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_13),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_9),
.B(n_19),
.Y(n_20)
);


endmodule