module fake_netlist_893_3939_n_31 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_31);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_31;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;
wire n_29;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_0),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_1),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_3),
.B(n_5),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_11),
.B(n_8),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_9),
.B(n_10),
.C(n_8),
.Y(n_14)
);

OR2x6_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_1),
.Y(n_15)
);

BUFx4_ASAP7_75t_SL g16 ( 
.A(n_7),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_10),
.B(n_9),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_11),
.Y(n_18)
);

AND2x4_ASAP7_75t_SL g19 ( 
.A(n_15),
.B(n_11),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_17),
.B1(n_11),
.B2(n_12),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_14),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_19),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_7),
.Y(n_24)
);

NAND4xp75_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_16),
.C(n_20),
.D(n_12),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_21),
.B1(n_5),
.B2(n_1),
.C(n_4),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_25),
.A2(n_6),
.B1(n_4),
.B2(n_2),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AOI322xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_2),
.A3(n_3),
.B1(n_6),
.B2(n_28),
.C1(n_29),
.C2(n_9),
.Y(n_31)
);


endmodule