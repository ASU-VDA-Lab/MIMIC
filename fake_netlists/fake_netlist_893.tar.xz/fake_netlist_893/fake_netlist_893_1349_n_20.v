module fake_netlist_893_1349_n_20 (n_0, n_2, n_5, n_3, n_4, n_1, n_20);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_20;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_19;
wire n_12;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_1),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

AND2x2_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_4),
.B(n_3),
.C(n_2),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_13),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_13),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_14),
.Y(n_17)
);

NAND2x1p5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_6),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_16),
.B1(n_18),
.B2(n_15),
.Y(n_20)
);


endmodule