module fake_netlist_893_4501_n_34 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_34);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_34;

wire n_33;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_26;
wire n_29;

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_6),
.A2(n_12),
.B(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_10),
.B(n_14),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_1),
.B(n_0),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_17),
.B(n_15),
.C(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_17),
.Y(n_25)
);

NAND4xp25_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_18),
.C(n_21),
.D(n_15),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_20),
.Y(n_28)
);

OAI311xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_16),
.A3(n_20),
.B1(n_3),
.C1(n_5),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_28),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_16),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.B1(n_9),
.B2(n_7),
.Y(n_34)
);


endmodule