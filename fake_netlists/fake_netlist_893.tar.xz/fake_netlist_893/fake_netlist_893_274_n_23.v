module fake_netlist_893_274_n_23 (n_0, n_2, n_5, n_3, n_4, n_1, n_23);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_23;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

AO21x2_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_7),
.A2(n_5),
.B(n_8),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_14),
.B(n_12),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_16),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_14),
.B(n_10),
.C(n_13),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_12),
.C(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_22),
.B(n_6),
.Y(n_23)
);


endmodule