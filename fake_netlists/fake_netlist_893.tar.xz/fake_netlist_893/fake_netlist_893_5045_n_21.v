module fake_netlist_893_5045_n_21 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_21;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_14;
wire n_10;

INVx8_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_1),
.B(n_6),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

OR2x6_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_4),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B1(n_10),
.B2(n_12),
.Y(n_15)
);

INVxp67_ASAP7_75t_SL g16 ( 
.A(n_15),
.Y(n_16)
);

AOI21xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_10),
.B(n_4),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_16),
.B1(n_7),
.B2(n_5),
.C1(n_6),
.C2(n_2),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_9),
.B1(n_8),
.B2(n_3),
.Y(n_21)
);


endmodule