module fake_netlist_893_4568_n_40 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_40);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_40;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_32;
wire n_35;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_9),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_4),
.B(n_7),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_20)
);

INVx6_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_SL g22 ( 
.A(n_13),
.B(n_3),
.C(n_2),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_19),
.B(n_3),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_15),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_17),
.Y(n_25)
);

OR2x6_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_21),
.Y(n_26)
);

OR2x6_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_12),
.Y(n_27)
);

AND2x4_ASAP7_75t_SL g28 ( 
.A(n_22),
.B(n_14),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_24),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_SL g34 ( 
.A1(n_32),
.A2(n_30),
.B1(n_18),
.B2(n_14),
.C(n_28),
.Y(n_34)
);

OAI211xp5_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_30),
.B(n_23),
.C(n_18),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_34),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_34),
.Y(n_38)
);

AO211x2_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_10),
.B(n_21),
.C(n_16),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.B1(n_36),
.B2(n_10),
.Y(n_40)
);


endmodule