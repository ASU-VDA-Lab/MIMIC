module fake_netlist_893_1563_n_44 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_44);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_44;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_13;
wire n_32;
wire n_22;
wire n_25;
wire n_21;
wire n_35;
wire n_14;
wire n_42;
wire n_41;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

INVx1_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_8),
.B(n_7),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_5),
.B(n_0),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_7),
.Y(n_18)
);

AO21x2_ASAP7_75t_L g19 ( 
.A1(n_1),
.A2(n_11),
.B(n_3),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_12),
.A2(n_10),
.B(n_1),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_12),
.A2(n_6),
.B(n_4),
.Y(n_21)
);

OR2x6_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_4),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_13),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_15),
.B(n_17),
.Y(n_25)
);

INVx8_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_27),
.B(n_23),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_26),
.B1(n_27),
.B2(n_29),
.C(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

NAND4xp25_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_32),
.C(n_21),
.D(n_29),
.Y(n_36)
);

NAND3xp33_ASAP7_75t_SL g37 ( 
.A(n_35),
.B(n_14),
.C(n_26),
.Y(n_37)
);

AOI21xp33_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_26),
.B(n_27),
.Y(n_38)
);

CKINVDCx16_ASAP7_75t_R g39 ( 
.A(n_37),
.Y(n_39)
);

INVxp67_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

CKINVDCx14_ASAP7_75t_R g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_39),
.A2(n_27),
.B1(n_26),
.B2(n_19),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_42),
.A2(n_19),
.B1(n_41),
.B2(n_43),
.Y(n_44)
);


endmodule