module fake_netlist_893_1957_n_16 (n_0, n_1, n_2, n_16);

input n_0;
input n_1;
input n_2;

output n_16;

wire n_5;
wire n_3;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

AND2x2_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_1),
.Y(n_4)
);

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

AND2x4_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_5),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI31xp33_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_2),
.A3(n_5),
.B(n_7),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_6),
.B1(n_5),
.B2(n_7),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B(n_8),
.C(n_6),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_9),
.B(n_7),
.C(n_2),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_6),
.B1(n_10),
.B2(n_13),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_6),
.B(n_15),
.Y(n_16)
);


endmodule