module fake_netlist_893_4032_n_14 (n_0, n_1, n_3, n_2, n_14);

input n_0;
input n_1;
input n_3;
input n_2;

output n_14;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

BUFx2_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

OAI21x1_ASAP7_75t_SL g6 ( 
.A1(n_4),
.A2(n_5),
.B(n_0),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_0),
.Y(n_7)
);

AO21x2_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

A2O1A1Ixp33_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_9),
.B(n_8),
.C(n_3),
.Y(n_11)
);

OAI222xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C1(n_8),
.C2(n_9),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_8),
.B1(n_3),
.B2(n_1),
.Y(n_13)
);

AO221x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_11),
.B2(n_3),
.C(n_2),
.Y(n_14)
);


endmodule