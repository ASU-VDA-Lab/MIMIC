module fake_netlist_848_2055_n_57 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_57);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_57;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_47;
wire n_17;
wire n_14;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_12;
wire n_56;
wire n_29;
wire n_30;
wire n_18;
wire n_55;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_1),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_4),
.B(n_2),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_4),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_11),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_3),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_8),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_14),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_12),
.A2(n_2),
.B(n_0),
.Y(n_23)
);

O2A1O1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_12),
.A2(n_4),
.B(n_3),
.C(n_0),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_SL g25 ( 
.A(n_14),
.B(n_19),
.C(n_17),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_17),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_20),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_13),
.A2(n_6),
.B(n_5),
.Y(n_28)
);

A2O1A1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_20),
.A2(n_8),
.B(n_7),
.C(n_5),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_15),
.A2(n_8),
.B1(n_7),
.B2(n_5),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_18),
.A2(n_11),
.B1(n_10),
.B2(n_7),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_22),
.A2(n_21),
.B1(n_16),
.B2(n_10),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_23),
.A2(n_16),
.B(n_10),
.Y(n_33)
);

AND2x6_ASAP7_75t_SL g34 ( 
.A(n_27),
.B(n_11),
.Y(n_34)
);

O2A1O1Ixp33_ASAP7_75t_L g35 ( 
.A1(n_29),
.A2(n_22),
.B(n_31),
.C(n_24),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_28),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_27),
.B(n_9),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_31),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_26),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_37),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_26),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_25),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_36),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_SL g44 ( 
.A1(n_39),
.A2(n_38),
.B1(n_37),
.B2(n_34),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_36),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_38),
.B1(n_35),
.B2(n_32),
.C(n_30),
.Y(n_46)
);

A2O1A1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_41),
.A2(n_33),
.B(n_35),
.C(n_32),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_42),
.B1(n_32),
.B2(n_40),
.C(n_41),
.Y(n_48)
);

AOI222xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_9),
.B1(n_33),
.B2(n_34),
.C1(n_43),
.C2(n_45),
.Y(n_49)
);

AND5x1_ASAP7_75t_L g50 ( 
.A(n_44),
.B(n_33),
.C(n_43),
.D(n_46),
.E(n_47),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_33),
.B1(n_26),
.B2(n_44),
.Y(n_51)
);

OAI211xp5_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_48),
.B(n_51),
.C(n_50),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

BUFx2_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

INVx5_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_52),
.B1(n_54),
.B2(n_55),
.Y(n_57)
);


endmodule