module fake_netlist_848_765_n_54 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_54);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_54;

wire n_49;
wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

AND2x2_ASAP7_75t_L g21 ( 
.A(n_2),
.B(n_14),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_5),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_8),
.B(n_19),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_4),
.B(n_12),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_17),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_13),
.B(n_10),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_11),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_18),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

INVxp67_ASAP7_75t_SL g33 ( 
.A(n_25),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_18),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

OA21x2_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_27),
.B(n_22),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_27),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_37),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_37),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_34),
.C(n_31),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_36),
.B1(n_23),
.B2(n_21),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_SL g45 ( 
.A1(n_43),
.A2(n_24),
.B(n_30),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_44),
.Y(n_46)
);

INVx1_ASAP7_75t_SL g47 ( 
.A(n_42),
.Y(n_47)
);

NAND4xp25_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_6),
.C(n_1),
.D(n_0),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

NAND3xp33_ASAP7_75t_SL g50 ( 
.A(n_46),
.B(n_9),
.C(n_7),
.Y(n_50)
);

INVx2_ASAP7_75t_SL g51 ( 
.A(n_49),
.Y(n_51)
);

BUFx3_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_15),
.B1(n_50),
.B2(n_51),
.Y(n_53)
);

NAND2x2_ASAP7_75t_L g54 ( 
.A(n_53),
.B(n_52),
.Y(n_54)
);


endmodule