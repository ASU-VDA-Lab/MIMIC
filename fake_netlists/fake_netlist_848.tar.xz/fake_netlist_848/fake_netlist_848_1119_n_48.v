module fake_netlist_848_1119_n_48 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_48);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_48;

wire n_25;
wire n_36;
wire n_47;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_6),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_14),
.B(n_9),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_19),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_18),
.Y(n_31)
);

BUFx4f_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_0),
.Y(n_34)
);

NOR2x1_ASAP7_75t_SL g35 ( 
.A(n_34),
.B(n_26),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_23),
.Y(n_36)
);

AOI33xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_27),
.A3(n_32),
.B1(n_29),
.B2(n_25),
.B3(n_28),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_1),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_3),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_4),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

CKINVDCx20_ASAP7_75t_R g43 ( 
.A(n_41),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_R g44 ( 
.A(n_42),
.B(n_10),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_46),
.B1(n_21),
.B2(n_20),
.Y(n_48)
);


endmodule