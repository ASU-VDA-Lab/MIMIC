module fake_netlist_848_1270_n_51 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_51);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_51;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_17;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

AND2x6_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_0),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_6),
.B(n_10),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_6),
.B(n_15),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_16),
.Y(n_26)
);

INVxp67_ASAP7_75t_SL g27 ( 
.A(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_17),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

NOR2x1p5_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_20),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_26),
.A2(n_19),
.B1(n_22),
.B2(n_25),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_26),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_27),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_31),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

XOR2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_36),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_28),
.Y(n_42)
);

NOR3x1_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_30),
.C(n_29),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_32),
.B1(n_19),
.B2(n_25),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_18),
.B1(n_5),
.B2(n_2),
.Y(n_45)
);

INVx1_ASAP7_75t_SL g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

NOR3x1_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_9),
.C(n_7),
.Y(n_49)
);

XOR2xp5_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_11),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_12),
.B1(n_48),
.B2(n_49),
.Y(n_51)
);


endmodule