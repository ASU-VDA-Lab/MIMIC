module fake_netlist_848_1611_n_16 (n_2, n_0, n_3, n_1, n_16);

input n_2;
input n_0;
input n_3;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

NAND2x1p5_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_1),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_SL g10 ( 
.A1(n_8),
.A2(n_6),
.B(n_0),
.Y(n_10)
);

OAI22xp33_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_2),
.B1(n_3),
.B2(n_9),
.Y(n_11)
);

XNOR2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

NAND4xp75_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_9),
.C(n_8),
.D(n_2),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_3),
.B1(n_8),
.B2(n_9),
.C(n_13),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_8),
.B1(n_9),
.B2(n_10),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_8),
.B1(n_9),
.B2(n_10),
.C1(n_12),
.C2(n_15),
.Y(n_16)
);


endmodule