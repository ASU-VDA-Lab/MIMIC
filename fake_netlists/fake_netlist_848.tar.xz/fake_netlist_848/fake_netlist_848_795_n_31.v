module fake_netlist_848_795_n_31 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_31);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_31;

wire n_25;
wire n_20;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_27;

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_10),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_3),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_9),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_5),
.B(n_2),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_16),
.B1(n_15),
.B2(n_0),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_6),
.B(n_1),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_SL g25 ( 
.A(n_23),
.B(n_20),
.C(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NAND4xp75_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_24),
.C(n_22),
.D(n_15),
.Y(n_28)
);

NOR4xp25_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_16),
.C(n_21),
.D(n_7),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_12),
.B1(n_11),
.B2(n_8),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_17),
.B1(n_14),
.B2(n_13),
.Y(n_31)
);


endmodule