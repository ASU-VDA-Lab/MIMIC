module fake_netlist_848_1203_n_16 (n_4, n_2, n_5, n_3, n_0, n_1, n_16);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_7),
.Y(n_11)
);

INVxp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_10),
.C(n_4),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_5),
.B1(n_3),
.B2(n_2),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_9),
.B(n_14),
.Y(n_16)
);


endmodule