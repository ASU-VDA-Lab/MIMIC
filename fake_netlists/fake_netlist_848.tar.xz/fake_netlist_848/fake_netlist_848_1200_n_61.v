module fake_netlist_848_1200_n_61 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_61);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_61;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_60;
wire n_31;
wire n_32;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

NOR2xp67_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_10),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_9),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_16),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_2),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_15),
.B(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_8),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_29),
.B(n_1),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

AO22x1_ASAP7_75t_L g34 ( 
.A1(n_26),
.A2(n_13),
.B1(n_2),
.B2(n_1),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_23),
.Y(n_35)
);

AND2x6_ASAP7_75t_L g36 ( 
.A(n_26),
.B(n_0),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_25),
.B(n_24),
.Y(n_37)
);

AOI21xp33_ASAP7_75t_L g38 ( 
.A1(n_31),
.A2(n_26),
.B(n_20),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_32),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_39),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_22),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_27),
.B1(n_34),
.B2(n_23),
.C(n_21),
.Y(n_43)
);

INVx2_ASAP7_75t_SL g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NAND2x1_ASAP7_75t_SL g46 ( 
.A(n_43),
.B(n_19),
.Y(n_46)
);

AOI322xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_43),
.A3(n_21),
.B1(n_28),
.B2(n_38),
.C1(n_30),
.C2(n_24),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_37),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_SL g49 ( 
.A1(n_44),
.A2(n_28),
.B1(n_36),
.B2(n_46),
.Y(n_49)
);

OAI221xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_46),
.B1(n_30),
.B2(n_25),
.C(n_29),
.Y(n_50)
);

OAI22xp5_ASAP7_75t_SL g51 ( 
.A1(n_49),
.A2(n_30),
.B1(n_29),
.B2(n_13),
.Y(n_51)
);

AOI221xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_30),
.B1(n_29),
.B2(n_33),
.C(n_36),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);

AOI222xp33_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_30),
.B1(n_36),
.B2(n_37),
.C1(n_33),
.C2(n_14),
.Y(n_55)
);

NOR3xp33_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_17),
.C(n_14),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

AOI21xp5_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_33),
.B(n_36),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_SL g60 ( 
.A1(n_59),
.A2(n_55),
.B1(n_56),
.B2(n_18),
.Y(n_60)
);

AOI22xp33_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_58),
.B1(n_12),
.B2(n_7),
.Y(n_61)
);


endmodule