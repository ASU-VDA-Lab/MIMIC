module fake_netlist_848_1631_n_42 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_42);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_42;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

BUFx3_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_19),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

NAND2xp33_ASAP7_75t_R g26 ( 
.A(n_7),
.B(n_5),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_21),
.A2(n_18),
.B1(n_2),
.B2(n_0),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_28),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_24),
.B(n_28),
.Y(n_32)
);

OAI221xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_30),
.B1(n_22),
.B2(n_27),
.C(n_26),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

INVxp67_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AND3x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_26),
.C(n_31),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_20),
.B1(n_23),
.B2(n_4),
.C(n_6),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

AOI211xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_20),
.B(n_10),
.C(n_8),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_SL g40 ( 
.A(n_37),
.B(n_13),
.C(n_11),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_14),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_SL g42 ( 
.A1(n_41),
.A2(n_40),
.B1(n_17),
.B2(n_16),
.Y(n_42)
);


endmodule