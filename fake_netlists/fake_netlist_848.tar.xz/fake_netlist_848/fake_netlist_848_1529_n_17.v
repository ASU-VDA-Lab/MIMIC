module fake_netlist_848_1529_n_17 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_17);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_2),
.Y(n_7)
);

NAND2xp33_ASAP7_75t_SL g8 ( 
.A(n_2),
.B(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.B(n_3),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

INVxp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_8),
.C(n_12),
.Y(n_14)
);

AND3x4_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_4),
.C(n_3),
.Y(n_15)
);

AO22x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_5),
.B1(n_6),
.B2(n_12),
.Y(n_16)
);

AOI21x1_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_6),
.B(n_5),
.Y(n_17)
);


endmodule