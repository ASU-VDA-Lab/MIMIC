module fake_netlist_848_1965_n_61 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_61);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_61;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_44;
wire n_34;
wire n_28;
wire n_39;
wire n_40;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx2_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

BUFx12f_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_8),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_1),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_15),
.B(n_5),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_19),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_19),
.B(n_14),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_10),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_20),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_3),
.Y(n_32)
);

BUFx12f_ASAP7_75t_SL g33 ( 
.A(n_26),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_R g34 ( 
.A(n_24),
.B(n_4),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_23),
.B(n_16),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_27),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_21),
.B(n_16),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_29),
.B1(n_31),
.B2(n_26),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_35),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_25),
.B1(n_22),
.B2(n_29),
.Y(n_42)
);

INVx3_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_SL g44 ( 
.A1(n_36),
.A2(n_32),
.B1(n_30),
.B2(n_17),
.Y(n_44)
);

NAND5xp2_ASAP7_75t_SL g45 ( 
.A(n_42),
.B(n_33),
.C(n_36),
.D(n_17),
.E(n_37),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_35),
.B1(n_34),
.B2(n_30),
.C(n_32),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_43),
.Y(n_52)
);

AOI221xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_45),
.B1(n_40),
.B2(n_35),
.C(n_34),
.Y(n_53)
);

BUFx2_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

NOR3xp33_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_9),
.C(n_6),
.Y(n_55)
);

OAI21xp33_ASAP7_75t_SL g56 ( 
.A1(n_53),
.A2(n_12),
.B(n_11),
.Y(n_56)
);

AND2x4_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_13),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

CKINVDCx20_ASAP7_75t_R g59 ( 
.A(n_58),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_L g61 ( 
.A1(n_59),
.A2(n_56),
.B1(n_57),
.B2(n_60),
.Y(n_61)
);


endmodule