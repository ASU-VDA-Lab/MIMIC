module fake_netlist_848_1187_n_18 (n_2, n_0, n_3, n_1, n_18);

input n_2;
input n_0;
input n_3;
input n_1;

output n_18;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_17;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_SL g12 ( 
.A1(n_9),
.A2(n_5),
.B(n_1),
.C(n_0),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_SL g13 ( 
.A1(n_11),
.A2(n_12),
.B(n_10),
.C(n_1),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_SL g14 ( 
.A1(n_11),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C(n_9),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_2),
.Y(n_15)
);

OAI22xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_16)
);

OAI22x1_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_13),
.B1(n_3),
.B2(n_2),
.Y(n_17)
);

AO21x2_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_16),
.B(n_15),
.Y(n_18)
);


endmodule