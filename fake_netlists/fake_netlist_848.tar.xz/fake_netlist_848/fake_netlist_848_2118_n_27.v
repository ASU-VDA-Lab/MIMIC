module fake_netlist_848_2118_n_27 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_27);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_21;
wire n_16;

BUFx4f_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_2),
.B(n_0),
.Y(n_20)
);

OA21x2_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_5),
.B(n_4),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_16),
.Y(n_23)
);

OAI321xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_20),
.A3(n_18),
.B1(n_15),
.B2(n_7),
.C(n_6),
.Y(n_24)
);

NAND4xp25_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_12),
.C(n_11),
.D(n_8),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

NOR2xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_14),
.Y(n_27)
);


endmodule