module fake_netlist_848_2135_n_9 (n_0, n_1, n_9);

input n_0;
input n_1;

output n_9;

wire n_6;
wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_3;
wire n_8;

NAND2xp5_ASAP7_75t_SL g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

NOR2xp33_ASAP7_75t_R g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

OA21x2_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_0),
.Y(n_8)
);

AOI222xp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_0),
.B1(n_1),
.B2(n_7),
.C1(n_3),
.C2(n_2),
.Y(n_9)
);


endmodule