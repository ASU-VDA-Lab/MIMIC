module fake_netlist_668_1551_n_30 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_30);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_30;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_11;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_26;
wire n_13;

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_12),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_0),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_16),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_18),
.Y(n_22)
);

AOI222xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.B1(n_20),
.B2(n_15),
.C1(n_11),
.C2(n_14),
.Y(n_23)
);

OAI32xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_20),
.A3(n_11),
.B1(n_1),
.B2(n_3),
.Y(n_24)
);

NOR4xp75_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_5),
.C(n_4),
.D(n_1),
.Y(n_25)
);

NAND4xp25_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_6),
.C(n_5),
.D(n_4),
.Y(n_26)
);

XOR2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_6),
.Y(n_27)
);

NOR4xp75_ASAP7_75t_SL g28 ( 
.A(n_25),
.B(n_7),
.C(n_11),
.D(n_8),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_28),
.B1(n_11),
.B2(n_7),
.Y(n_30)
);


endmodule