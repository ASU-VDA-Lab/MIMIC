module fake_netlist_668_1403_n_17 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_17);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_17;

wire n_14;
wire n_10;
wire n_15;
wire n_9;
wire n_11;
wire n_13;
wire n_8;
wire n_16;
wire n_12;

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

INVxp67_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.Y(n_11)
);

NOR4xp25_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_7),
.C(n_10),
.D(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_9),
.B(n_7),
.C(n_1),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

XNOR2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_3),
.Y(n_16)
);

NAND2x1p5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_6),
.Y(n_17)
);


endmodule