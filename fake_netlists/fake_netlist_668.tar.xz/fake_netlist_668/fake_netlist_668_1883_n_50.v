module fake_netlist_668_1883_n_50 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_50);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_50;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_8),
.Y(n_24)
);

AND2x2_ASAP7_75t_SL g25 ( 
.A(n_11),
.B(n_20),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_3),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_15),
.B(n_0),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_14),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_18),
.B(n_6),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_22),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_7),
.Y(n_32)
);

OR2x4_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_16),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_SL g35 ( 
.A(n_24),
.B(n_18),
.C(n_16),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_32),
.B(n_28),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_25),
.B1(n_26),
.B2(n_30),
.Y(n_37)
);

AOI21xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_26),
.B(n_31),
.Y(n_38)
);

INVx5_ASAP7_75t_SL g39 ( 
.A(n_36),
.Y(n_39)
);

OAI21xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_37),
.B(n_35),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_34),
.Y(n_41)
);

INVxp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND2x1p5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_19),
.Y(n_43)
);

NAND4xp75_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_30),
.C(n_27),
.D(n_19),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_45),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_44),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_2),
.B1(n_1),
.B2(n_4),
.C(n_5),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

AOI222xp33_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_9),
.B1(n_10),
.B2(n_13),
.C1(n_17),
.C2(n_48),
.Y(n_50)
);


endmodule