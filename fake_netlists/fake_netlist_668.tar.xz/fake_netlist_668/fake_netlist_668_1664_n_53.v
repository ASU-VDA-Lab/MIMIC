module fake_netlist_668_1664_n_53 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_53);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_53;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx2_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_3),
.B(n_2),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_4),
.Y(n_27)
);

OA21x2_ASAP7_75t_L g28 ( 
.A1(n_11),
.A2(n_5),
.B(n_1),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_12),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_15),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_8),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_0),
.A2(n_20),
.B1(n_9),
.B2(n_24),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_13),
.B(n_22),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_27),
.B(n_6),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_30),
.B(n_31),
.Y(n_36)
);

BUFx12f_ASAP7_75t_L g37 ( 
.A(n_29),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_25),
.B(n_16),
.Y(n_38)
);

INVx4_ASAP7_75t_SL g39 ( 
.A(n_38),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_38),
.B1(n_33),
.B2(n_37),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_40),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_32),
.B1(n_35),
.B2(n_28),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_SL g43 ( 
.A(n_41),
.B(n_32),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

AOI21xp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_34),
.B(n_26),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_28),
.B(n_16),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_18),
.Y(n_48)
);

CKINVDCx20_ASAP7_75t_R g49 ( 
.A(n_48),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_50),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_14),
.B1(n_10),
.B2(n_7),
.Y(n_52)
);

AOI222xp33_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_17),
.B1(n_19),
.B2(n_21),
.C1(n_23),
.C2(n_52),
.Y(n_53)
);


endmodule