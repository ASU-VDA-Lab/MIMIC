module fake_netlist_668_2065_n_48 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_48);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_48;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

BUFx10_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_1),
.B(n_11),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_2),
.A2(n_17),
.B1(n_22),
.B2(n_5),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_8),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_7),
.B(n_3),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_26),
.A2(n_10),
.B(n_9),
.Y(n_35)
);

AO31x2_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_28),
.A3(n_30),
.B(n_29),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_27),
.B1(n_25),
.B2(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

NAND2x1p5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_25),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_38),
.Y(n_40)
);

AOI21xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_35),
.B(n_18),
.Y(n_41)
);

OAI21xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_39),
.B(n_12),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_24),
.B1(n_15),
.B2(n_13),
.C(n_14),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_24),
.B1(n_20),
.B2(n_19),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_SL g48 ( 
.A1(n_47),
.A2(n_21),
.B1(n_23),
.B2(n_46),
.Y(n_48)
);


endmodule