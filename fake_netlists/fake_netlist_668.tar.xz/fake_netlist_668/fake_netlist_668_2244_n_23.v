module fake_netlist_668_2244_n_23 (n_4, n_1, n_2, n_0, n_5, n_3, n_23);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_23;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx4_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx4_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OA21x2_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_3),
.B(n_0),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

INVxp67_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OR2x6_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_8),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_11),
.B(n_8),
.C(n_12),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_9),
.B(n_10),
.Y(n_17)
);

AND2x2_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

XOR2x2_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_15),
.Y(n_20)
);

AO22x2_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_4),
.B1(n_5),
.B2(n_20),
.Y(n_21)
);

AOI22x1_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_5),
.B1(n_20),
.B2(n_19),
.Y(n_22)
);

OAI21x1_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B(n_21),
.Y(n_23)
);


endmodule