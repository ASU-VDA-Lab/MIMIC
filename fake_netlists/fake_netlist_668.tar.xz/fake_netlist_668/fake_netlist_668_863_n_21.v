module fake_netlist_668_863_n_21 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_21);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

OAI21xp33_ASAP7_75t_SL g12 ( 
.A1(n_0),
.A2(n_6),
.B(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

AOI21x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B(n_8),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_10),
.A2(n_5),
.B(n_4),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_11),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_12),
.B(n_15),
.C(n_5),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_12),
.B(n_14),
.Y(n_20)
);

AOI22x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_6),
.B1(n_7),
.B2(n_18),
.Y(n_21)
);


endmodule