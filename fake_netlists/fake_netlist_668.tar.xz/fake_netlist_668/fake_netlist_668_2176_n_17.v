module fake_netlist_668_2176_n_17 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_17);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_17;

wire n_7;
wire n_14;
wire n_13;
wire n_12;
wire n_11;
wire n_10;
wire n_16;
wire n_8;
wire n_15;
wire n_9;

INVx2_ASAP7_75t_SL g7 ( 
.A(n_2),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

AOI21xp33_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_5),
.B(n_0),
.Y(n_10)
);

AO31x2_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_1),
.A3(n_6),
.B(n_8),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

INVx2_ASAP7_75t_SL g13 ( 
.A(n_12),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B1(n_8),
.B2(n_1),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_6),
.Y(n_17)
);


endmodule