module fake_netlist_668_327_n_44 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_44);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_44;

wire n_36;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_12),
.B(n_19),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_13),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_1),
.A2(n_17),
.B(n_6),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_3),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_SL g30 ( 
.A(n_29),
.B(n_20),
.Y(n_30)
);

INVx5_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_28),
.B1(n_26),
.B2(n_20),
.C(n_24),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_23),
.B1(n_21),
.B2(n_25),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_31),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_18),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_34),
.A2(n_25),
.B1(n_18),
.B2(n_0),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_2),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_4),
.Y(n_40)
);

NOR4xp25_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_8),
.C(n_7),
.D(n_5),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AOI322xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_9),
.A3(n_11),
.B1(n_15),
.B2(n_16),
.C1(n_39),
.C2(n_42),
.Y(n_44)
);


endmodule