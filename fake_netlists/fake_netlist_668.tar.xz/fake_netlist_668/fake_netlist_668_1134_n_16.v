module fake_netlist_668_1134_n_16 (n_4, n_1, n_2, n_0, n_5, n_3, n_16);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_16;

wire n_7;
wire n_14;
wire n_13;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_15;
wire n_6;
wire n_9;

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

AND2x6_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_2),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_8),
.Y(n_11)
);

OAI33xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.A3(n_8),
.B1(n_2),
.B2(n_1),
.B3(n_0),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B(n_10),
.C(n_7),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B(n_11),
.C(n_7),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_3),
.B1(n_5),
.B2(n_9),
.C1(n_12),
.C2(n_7),
.Y(n_16)
);


endmodule