module fake_netlist_668_564_n_44 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_44);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_44;

wire n_36;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_15),
.B(n_0),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_17),
.B(n_8),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_14),
.B(n_1),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_19),
.B(n_9),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_3),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_24),
.B(n_4),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_SL g32 ( 
.A1(n_29),
.A2(n_25),
.B1(n_23),
.B2(n_20),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_22),
.B1(n_26),
.B2(n_28),
.C(n_23),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_28),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_34),
.Y(n_37)
);

NOR3xp33_ASAP7_75t_SL g38 ( 
.A(n_35),
.B(n_25),
.C(n_16),
.Y(n_38)
);

AOI221xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_35),
.B1(n_36),
.B2(n_26),
.C(n_16),
.Y(n_39)
);

OAI21xp5_ASAP7_75t_SL g40 ( 
.A1(n_38),
.A2(n_26),
.B(n_17),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_19),
.B1(n_18),
.B2(n_5),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_18),
.Y(n_42)
);

OR3x2_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_7),
.C(n_6),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_R g44 ( 
.A1(n_43),
.A2(n_41),
.B1(n_12),
.B2(n_11),
.Y(n_44)
);


endmodule