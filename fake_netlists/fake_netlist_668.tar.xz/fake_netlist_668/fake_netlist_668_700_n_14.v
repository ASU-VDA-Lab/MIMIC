module fake_netlist_668_700_n_14 (n_3, n_1, n_2, n_0, n_14);

input n_3;
input n_1;
input n_2;
input n_0;

output n_14;

wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;
wire n_9;

INVx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx2_ASAP7_75t_SL g5 ( 
.A(n_2),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_0),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI221xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_5),
.B1(n_4),
.B2(n_0),
.C(n_1),
.Y(n_9)
);

INVxp67_ASAP7_75t_SL g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2x1p5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_9),
.C(n_4),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_3),
.B2(n_2),
.Y(n_14)
);


endmodule