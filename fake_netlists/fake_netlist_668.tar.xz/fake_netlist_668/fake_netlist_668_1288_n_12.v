module fake_netlist_668_1288_n_12 (n_4, n_1, n_2, n_0, n_3, n_12);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_12;

wire n_9;
wire n_7;
wire n_5;
wire n_10;
wire n_11;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AOI21xp33_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

NOR4xp75_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_4),
.C(n_2),
.D(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_4),
.B(n_2),
.Y(n_12)
);


endmodule