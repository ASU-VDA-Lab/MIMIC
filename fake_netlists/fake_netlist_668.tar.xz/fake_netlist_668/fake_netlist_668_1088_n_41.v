module fake_netlist_668_1088_n_41 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_41);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_41;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

BUFx3_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_4),
.B(n_3),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_5),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_25),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_26),
.B1(n_25),
.B2(n_18),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_20),
.B1(n_26),
.B2(n_19),
.Y(n_31)
);

NAND4xp25_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_29),
.C(n_31),
.D(n_27),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_19),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_15),
.Y(n_35)
);

A2O1A1Ixp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_18),
.B(n_22),
.C(n_21),
.Y(n_36)
);

AOI211xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_24),
.B(n_17),
.C(n_1),
.Y(n_37)
);

BUFx12f_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

INVx1_ASAP7_75t_SL g39 ( 
.A(n_36),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_SL g40 ( 
.A1(n_38),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_39),
.B1(n_13),
.B2(n_11),
.Y(n_41)
);


endmodule