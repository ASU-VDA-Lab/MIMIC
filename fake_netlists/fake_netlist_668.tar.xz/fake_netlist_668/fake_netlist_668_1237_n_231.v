module fake_netlist_668_1237_n_231 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_28, n_11, n_15, n_7, n_30, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_27, n_2, n_29, n_31, n_26, n_33, n_9, n_32, n_13, n_8, n_6, n_231);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_28;
input n_11;
input n_15;
input n_7;
input n_30;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_27;
input n_2;
input n_29;
input n_31;
input n_26;
input n_33;
input n_9;
input n_32;
input n_13;
input n_8;
input n_6;

output n_231;

wire n_168;
wire n_99;
wire n_62;
wire n_70;
wire n_90;
wire n_101;
wire n_38;
wire n_58;
wire n_144;
wire n_155;
wire n_166;
wire n_139;
wire n_57;
wire n_84;
wire n_214;
wire n_35;
wire n_89;
wire n_209;
wire n_152;
wire n_116;
wire n_96;
wire n_172;
wire n_45;
wire n_107;
wire n_220;
wire n_218;
wire n_78;
wire n_191;
wire n_66;
wire n_154;
wire n_164;
wire n_118;
wire n_60;
wire n_137;
wire n_39;
wire n_189;
wire n_197;
wire n_173;
wire n_183;
wire n_63;
wire n_190;
wire n_211;
wire n_206;
wire n_177;
wire n_192;
wire n_194;
wire n_184;
wire n_187;
wire n_81;
wire n_37;
wire n_71;
wire n_124;
wire n_163;
wire n_91;
wire n_165;
wire n_121;
wire n_157;
wire n_201;
wire n_105;
wire n_92;
wire n_125;
wire n_117;
wire n_230;
wire n_136;
wire n_40;
wire n_217;
wire n_223;
wire n_110;
wire n_170;
wire n_49;
wire n_207;
wire n_151;
wire n_53;
wire n_161;
wire n_77;
wire n_75;
wire n_48;
wire n_180;
wire n_142;
wire n_93;
wire n_199;
wire n_203;
wire n_181;
wire n_41;
wire n_143;
wire n_213;
wire n_65;
wire n_109;
wire n_208;
wire n_122;
wire n_219;
wire n_119;
wire n_149;
wire n_43;
wire n_182;
wire n_227;
wire n_82;
wire n_204;
wire n_120;
wire n_85;
wire n_61;
wire n_176;
wire n_72;
wire n_229;
wire n_51;
wire n_160;
wire n_226;
wire n_54;
wire n_86;
wire n_156;
wire n_68;
wire n_198;
wire n_130;
wire n_210;
wire n_140;
wire n_174;
wire n_202;
wire n_167;
wire n_175;
wire n_195;
wire n_67;
wire n_112;
wire n_179;
wire n_52;
wire n_50;
wire n_113;
wire n_169;
wire n_103;
wire n_104;
wire n_127;
wire n_162;
wire n_100;
wire n_150;
wire n_129;
wire n_146;
wire n_83;
wire n_134;
wire n_76;
wire n_196;
wire n_200;
wire n_106;
wire n_133;
wire n_225;
wire n_36;
wire n_59;
wire n_97;
wire n_34;
wire n_131;
wire n_64;
wire n_148;
wire n_44;
wire n_159;
wire n_228;
wire n_123;
wire n_141;
wire n_87;
wire n_115;
wire n_145;
wire n_79;
wire n_215;
wire n_128;
wire n_205;
wire n_108;
wire n_126;
wire n_185;
wire n_73;
wire n_132;
wire n_56;
wire n_98;
wire n_69;
wire n_224;
wire n_147;
wire n_171;
wire n_94;
wire n_212;
wire n_221;
wire n_222;
wire n_193;
wire n_138;
wire n_46;
wire n_153;
wire n_42;
wire n_158;
wire n_216;
wire n_55;
wire n_102;
wire n_135;
wire n_95;
wire n_178;
wire n_74;
wire n_186;
wire n_47;
wire n_188;
wire n_80;
wire n_88;
wire n_114;
wire n_111;

INVxp67_ASAP7_75t_L g34 ( 
.A(n_4),
.Y(n_34)
);

INVxp67_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

INVxp67_ASAP7_75t_L g36 ( 
.A(n_15),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_18),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_25),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_17),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_2),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_0),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_32),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_27),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_4),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_30),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_20),
.Y(n_46)
);

INVxp67_ASAP7_75t_L g47 ( 
.A(n_12),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_19),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_11),
.Y(n_49)
);

INVx3_ASAP7_75t_L g50 ( 
.A(n_39),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_42),
.Y(n_51)
);

CKINVDCx20_ASAP7_75t_R g52 ( 
.A(n_37),
.Y(n_52)
);

AND2x4_ASAP7_75t_L g53 ( 
.A(n_40),
.B(n_0),
.Y(n_53)
);

CKINVDCx5p33_ASAP7_75t_R g54 ( 
.A(n_38),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_39),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_43),
.Y(n_56)
);

CKINVDCx20_ASAP7_75t_R g57 ( 
.A(n_34),
.Y(n_57)
);

CKINVDCx20_ASAP7_75t_R g58 ( 
.A(n_36),
.Y(n_58)
);

CKINVDCx5p33_ASAP7_75t_R g59 ( 
.A(n_35),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_59),
.B(n_45),
.Y(n_60)
);

OR2x6_ASAP7_75t_SL g61 ( 
.A(n_51),
.B(n_40),
.Y(n_61)
);

AOI22xp5_ASAP7_75t_L g62 ( 
.A1(n_53),
.A2(n_47),
.B1(n_44),
.B2(n_41),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_50),
.Y(n_63)
);

AOI22xp33_ASAP7_75t_L g64 ( 
.A1(n_53),
.A2(n_56),
.B1(n_55),
.B2(n_50),
.Y(n_64)
);

AO22x2_ASAP7_75t_L g65 ( 
.A1(n_53),
.A2(n_48),
.B1(n_46),
.B2(n_43),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_50),
.Y(n_66)
);

AND2x2_ASAP7_75t_L g67 ( 
.A(n_55),
.B(n_41),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_50),
.Y(n_68)
);

HB1xp67_ASAP7_75t_L g69 ( 
.A(n_54),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_50),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_66),
.Y(n_71)
);

AOI21xp5_ASAP7_75t_L g72 ( 
.A1(n_64),
.A2(n_53),
.B(n_56),
.Y(n_72)
);

AOI22xp5_ASAP7_75t_L g73 ( 
.A1(n_65),
.A2(n_53),
.B1(n_57),
.B2(n_44),
.Y(n_73)
);

CKINVDCx16_ASAP7_75t_R g74 ( 
.A(n_69),
.Y(n_74)
);

BUFx3_ASAP7_75t_L g75 ( 
.A(n_65),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_66),
.Y(n_76)
);

NAND2xp5_ASAP7_75t_L g77 ( 
.A(n_63),
.B(n_46),
.Y(n_77)
);

BUFx2_ASAP7_75t_L g78 ( 
.A(n_65),
.Y(n_78)
);

BUFx6f_ASAP7_75t_L g79 ( 
.A(n_63),
.Y(n_79)
);

O2A1O1Ixp33_ASAP7_75t_L g80 ( 
.A1(n_67),
.A2(n_49),
.B(n_48),
.C(n_57),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_68),
.Y(n_81)
);

BUFx8_ASAP7_75t_SL g82 ( 
.A(n_60),
.Y(n_82)
);

AOI21x1_ASAP7_75t_L g83 ( 
.A1(n_68),
.A2(n_49),
.B(n_21),
.Y(n_83)
);

OAI21xp33_ASAP7_75t_SL g84 ( 
.A1(n_62),
.A2(n_67),
.B(n_70),
.Y(n_84)
);

INVxp67_ASAP7_75t_SL g85 ( 
.A(n_65),
.Y(n_85)
);

CKINVDCx16_ASAP7_75t_R g86 ( 
.A(n_74),
.Y(n_86)
);

AOI22xp33_ASAP7_75t_SL g87 ( 
.A1(n_75),
.A2(n_52),
.B1(n_61),
.B2(n_58),
.Y(n_87)
);

OAI21x1_ASAP7_75t_L g88 ( 
.A1(n_83),
.A2(n_70),
.B(n_62),
.Y(n_88)
);

INVx2_ASAP7_75t_L g89 ( 
.A(n_71),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_71),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_81),
.Y(n_91)
);

OAI21xp5_ASAP7_75t_L g92 ( 
.A1(n_72),
.A2(n_61),
.B(n_22),
.Y(n_92)
);

HB1xp67_ASAP7_75t_L g93 ( 
.A(n_75),
.Y(n_93)
);

OAI21x1_ASAP7_75t_L g94 ( 
.A1(n_83),
.A2(n_72),
.B(n_77),
.Y(n_94)
);

OR2x2_ASAP7_75t_L g95 ( 
.A(n_74),
.B(n_1),
.Y(n_95)
);

AND2x2_ASAP7_75t_L g96 ( 
.A(n_75),
.B(n_1),
.Y(n_96)
);

INVx2_ASAP7_75t_L g97 ( 
.A(n_71),
.Y(n_97)
);

OAI21x1_ASAP7_75t_L g98 ( 
.A1(n_77),
.A2(n_24),
.B(n_23),
.Y(n_98)
);

INVx1_ASAP7_75t_SL g99 ( 
.A(n_78),
.Y(n_99)
);

CKINVDCx5p33_ASAP7_75t_R g100 ( 
.A(n_86),
.Y(n_100)
);

AND2x2_ASAP7_75t_L g101 ( 
.A(n_96),
.B(n_85),
.Y(n_101)
);

CKINVDCx16_ASAP7_75t_R g102 ( 
.A(n_95),
.Y(n_102)
);

NAND2xp33_ASAP7_75t_R g103 ( 
.A(n_96),
.B(n_85),
.Y(n_103)
);

NAND2xp33_ASAP7_75t_R g104 ( 
.A(n_96),
.B(n_82),
.Y(n_104)
);

CKINVDCx5p33_ASAP7_75t_R g105 ( 
.A(n_87),
.Y(n_105)
);

NAND2xp5_ASAP7_75t_L g106 ( 
.A(n_91),
.B(n_84),
.Y(n_106)
);

CKINVDCx16_ASAP7_75t_R g107 ( 
.A(n_95),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_91),
.Y(n_108)
);

NAND2xp5_ASAP7_75t_L g109 ( 
.A(n_91),
.B(n_84),
.Y(n_109)
);

AND2x4_ASAP7_75t_L g110 ( 
.A(n_93),
.B(n_73),
.Y(n_110)
);

BUFx3_ASAP7_75t_L g111 ( 
.A(n_101),
.Y(n_111)
);

INVx2_ASAP7_75t_SL g112 ( 
.A(n_101),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_108),
.Y(n_113)
);

INVxp67_ASAP7_75t_SL g114 ( 
.A(n_103),
.Y(n_114)
);

OAI21xp5_ASAP7_75t_L g115 ( 
.A1(n_106),
.A2(n_94),
.B(n_88),
.Y(n_115)
);

OAI21xp5_ASAP7_75t_SL g116 ( 
.A1(n_110),
.A2(n_92),
.B(n_73),
.Y(n_116)
);

BUFx3_ASAP7_75t_L g117 ( 
.A(n_110),
.Y(n_117)
);

INVx2_ASAP7_75t_L g118 ( 
.A(n_108),
.Y(n_118)
);

AO31x2_ASAP7_75t_L g119 ( 
.A1(n_106),
.A2(n_97),
.A3(n_90),
.B(n_89),
.Y(n_119)
);

INVx1_ASAP7_75t_L g120 ( 
.A(n_109),
.Y(n_120)
);

INVx1_ASAP7_75t_L g121 ( 
.A(n_113),
.Y(n_121)
);

NAND2xp5_ASAP7_75t_L g122 ( 
.A(n_120),
.B(n_109),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_113),
.Y(n_123)
);

INVx4_ASAP7_75t_L g124 ( 
.A(n_111),
.Y(n_124)
);

AND2x2_ASAP7_75t_L g125 ( 
.A(n_111),
.B(n_110),
.Y(n_125)
);

INVx1_ASAP7_75t_L g126 ( 
.A(n_113),
.Y(n_126)
);

AND2x2_ASAP7_75t_L g127 ( 
.A(n_111),
.B(n_118),
.Y(n_127)
);

AND2x2_ASAP7_75t_L g128 ( 
.A(n_111),
.B(n_110),
.Y(n_128)
);

OR2x2_ASAP7_75t_L g129 ( 
.A(n_120),
.B(n_102),
.Y(n_129)
);

INVxp67_ASAP7_75t_L g130 ( 
.A(n_118),
.Y(n_130)
);

AO21x2_ASAP7_75t_L g131 ( 
.A1(n_121),
.A2(n_115),
.B(n_116),
.Y(n_131)
);

NAND2xp5_ASAP7_75t_L g132 ( 
.A(n_122),
.B(n_120),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_121),
.Y(n_133)
);

NAND2xp5_ASAP7_75t_L g134 ( 
.A(n_122),
.B(n_119),
.Y(n_134)
);

OR2x2_ASAP7_75t_L g135 ( 
.A(n_130),
.B(n_119),
.Y(n_135)
);

NAND2xp5_ASAP7_75t_L g136 ( 
.A(n_123),
.B(n_119),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_123),
.Y(n_137)
);

INVx2_ASAP7_75t_L g138 ( 
.A(n_130),
.Y(n_138)
);

INVx4_ASAP7_75t_L g139 ( 
.A(n_124),
.Y(n_139)
);

INVx4_ASAP7_75t_L g140 ( 
.A(n_124),
.Y(n_140)
);

AND2x2_ASAP7_75t_L g141 ( 
.A(n_127),
.B(n_119),
.Y(n_141)
);

AND2x2_ASAP7_75t_L g142 ( 
.A(n_127),
.B(n_119),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_126),
.Y(n_143)
);

O2A1O1Ixp5_ASAP7_75t_L g144 ( 
.A1(n_139),
.A2(n_92),
.B(n_124),
.C(n_114),
.Y(n_144)
);

OAI21xp5_ASAP7_75t_L g145 ( 
.A1(n_136),
.A2(n_87),
.B(n_80),
.Y(n_145)
);

NOR2xp33_ASAP7_75t_L g146 ( 
.A(n_132),
.B(n_105),
.Y(n_146)
);

NAND2xp5_ASAP7_75t_SL g147 ( 
.A(n_139),
.B(n_124),
.Y(n_147)
);

AOI222xp33_ASAP7_75t_L g148 ( 
.A1(n_134),
.A2(n_116),
.B1(n_114),
.B2(n_126),
.C1(n_128),
.C2(n_125),
.Y(n_148)
);

INVx1_ASAP7_75t_SL g149 ( 
.A(n_139),
.Y(n_149)
);

NAND2xp5_ASAP7_75t_L g150 ( 
.A(n_141),
.B(n_116),
.Y(n_150)
);

NAND2xp5_ASAP7_75t_L g151 ( 
.A(n_141),
.B(n_128),
.Y(n_151)
);

OAI21xp33_ASAP7_75t_L g152 ( 
.A1(n_136),
.A2(n_95),
.B(n_80),
.Y(n_152)
);

OAI33xp33_ASAP7_75t_L g153 ( 
.A1(n_133),
.A2(n_129),
.A3(n_100),
.B1(n_118),
.B2(n_3),
.B3(n_2),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_133),
.Y(n_154)
);

OAI21xp33_ASAP7_75t_L g155 ( 
.A1(n_134),
.A2(n_135),
.B(n_141),
.Y(n_155)
);

NAND3xp33_ASAP7_75t_L g156 ( 
.A(n_137),
.B(n_104),
.C(n_115),
.Y(n_156)
);

OAI221xp5_ASAP7_75t_L g157 ( 
.A1(n_139),
.A2(n_115),
.B1(n_103),
.B2(n_112),
.C(n_117),
.Y(n_157)
);

OAI21xp5_ASAP7_75t_SL g158 ( 
.A1(n_142),
.A2(n_112),
.B(n_99),
.Y(n_158)
);

NOR2xp33_ASAP7_75t_L g159 ( 
.A(n_132),
.B(n_102),
.Y(n_159)
);

AOI22xp5_ASAP7_75t_L g160 ( 
.A1(n_140),
.A2(n_107),
.B1(n_112),
.B2(n_117),
.Y(n_160)
);

INVx1_ASAP7_75t_L g161 ( 
.A(n_137),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_143),
.Y(n_162)
);

INVxp67_ASAP7_75t_L g163 ( 
.A(n_147),
.Y(n_163)
);

AOI21xp5_ASAP7_75t_L g164 ( 
.A1(n_158),
.A2(n_140),
.B(n_135),
.Y(n_164)
);

OAI21xp33_ASAP7_75t_SL g165 ( 
.A1(n_149),
.A2(n_140),
.B(n_142),
.Y(n_165)
);

OR2x2_ASAP7_75t_L g166 ( 
.A(n_151),
.B(n_142),
.Y(n_166)
);

NOR2xp33_ASAP7_75t_L g167 ( 
.A(n_146),
.B(n_156),
.Y(n_167)
);

INVx1_ASAP7_75t_L g168 ( 
.A(n_154),
.Y(n_168)
);

AND2x4_ASAP7_75t_L g169 ( 
.A(n_161),
.B(n_140),
.Y(n_169)
);

OR2x2_ASAP7_75t_L g170 ( 
.A(n_155),
.B(n_138),
.Y(n_170)
);

OAI21xp5_ASAP7_75t_SL g171 ( 
.A1(n_148),
.A2(n_143),
.B(n_138),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_162),
.Y(n_172)
);

INVx2_ASAP7_75t_SL g173 ( 
.A(n_159),
.Y(n_173)
);

AOI22xp5_ASAP7_75t_L g174 ( 
.A1(n_152),
.A2(n_107),
.B1(n_131),
.B2(n_117),
.Y(n_174)
);

OR2x2_ASAP7_75t_L g175 ( 
.A(n_150),
.B(n_138),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_160),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_159),
.Y(n_177)
);

NOR2xp33_ASAP7_75t_L g178 ( 
.A(n_146),
.B(n_3),
.Y(n_178)
);

NAND2xp5_ASAP7_75t_L g179 ( 
.A(n_145),
.B(n_131),
.Y(n_179)
);

NAND2xp5_ASAP7_75t_L g180 ( 
.A(n_157),
.B(n_131),
.Y(n_180)
);

OAI221xp5_ASAP7_75t_SL g181 ( 
.A1(n_153),
.A2(n_117),
.B1(n_112),
.B2(n_118),
.C(n_99),
.Y(n_181)
);

NAND2xp5_ASAP7_75t_L g182 ( 
.A(n_144),
.B(n_119),
.Y(n_182)
);

NAND2xp5_ASAP7_75t_L g183 ( 
.A(n_155),
.B(n_119),
.Y(n_183)
);

INVx1_ASAP7_75t_L g184 ( 
.A(n_154),
.Y(n_184)
);

NAND2xp5_ASAP7_75t_L g185 ( 
.A(n_171),
.B(n_119),
.Y(n_185)
);

AOI21xp33_ASAP7_75t_L g186 ( 
.A1(n_167),
.A2(n_6),
.B(n_5),
.Y(n_186)
);

OAI211xp5_ASAP7_75t_L g187 ( 
.A1(n_165),
.A2(n_98),
.B(n_93),
.C(n_88),
.Y(n_187)
);

NOR3xp33_ASAP7_75t_L g188 ( 
.A(n_181),
.B(n_98),
.C(n_88),
.Y(n_188)
);

NAND2xp5_ASAP7_75t_L g189 ( 
.A(n_177),
.B(n_119),
.Y(n_189)
);

AOI222xp33_ASAP7_75t_L g190 ( 
.A1(n_179),
.A2(n_98),
.B1(n_94),
.B2(n_7),
.C1(n_6),
.C2(n_5),
.Y(n_190)
);

AOI31xp33_ASAP7_75t_L g191 ( 
.A1(n_164),
.A2(n_9),
.A3(n_8),
.B(n_7),
.Y(n_191)
);

NOR2x1_ASAP7_75t_L g192 ( 
.A(n_169),
.B(n_89),
.Y(n_192)
);

INVx2_ASAP7_75t_L g193 ( 
.A(n_169),
.Y(n_193)
);

OAI21xp5_ASAP7_75t_L g194 ( 
.A1(n_178),
.A2(n_94),
.B(n_89),
.Y(n_194)
);

AOI221xp5_ASAP7_75t_L g195 ( 
.A1(n_176),
.A2(n_12),
.B1(n_10),
.B2(n_13),
.C(n_14),
.Y(n_195)
);

OAI22xp5_ASAP7_75t_L g196 ( 
.A1(n_163),
.A2(n_97),
.B1(n_90),
.B2(n_89),
.Y(n_196)
);

OAI211xp5_ASAP7_75t_L g197 ( 
.A1(n_174),
.A2(n_97),
.B(n_90),
.C(n_13),
.Y(n_197)
);

AOI21xp5_ASAP7_75t_L g198 ( 
.A1(n_180),
.A2(n_97),
.B(n_90),
.Y(n_198)
);

NAND2xp5_ASAP7_75t_L g199 ( 
.A(n_166),
.B(n_119),
.Y(n_199)
);

OAI221xp5_ASAP7_75t_L g200 ( 
.A1(n_180),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.C(n_81),
.Y(n_200)
);

OAI221xp5_ASAP7_75t_L g201 ( 
.A1(n_173),
.A2(n_76),
.B1(n_79),
.B2(n_28),
.C(n_29),
.Y(n_201)
);

AOI221xp5_ASAP7_75t_L g202 ( 
.A1(n_183),
.A2(n_31),
.B1(n_33),
.B2(n_79),
.C(n_182),
.Y(n_202)
);

HB1xp67_ASAP7_75t_L g203 ( 
.A(n_192),
.Y(n_203)
);

NAND2xp5_ASAP7_75t_L g204 ( 
.A(n_185),
.B(n_170),
.Y(n_204)
);

O2A1O1Ixp33_ASAP7_75t_L g205 ( 
.A1(n_191),
.A2(n_183),
.B(n_172),
.C(n_168),
.Y(n_205)
);

NAND2xp5_ASAP7_75t_L g206 ( 
.A(n_199),
.B(n_175),
.Y(n_206)
);

AOI22xp5_ASAP7_75t_L g207 ( 
.A1(n_189),
.A2(n_79),
.B1(n_184),
.B2(n_188),
.Y(n_207)
);

INVx1_ASAP7_75t_L g208 ( 
.A(n_193),
.Y(n_208)
);

HB1xp67_ASAP7_75t_L g209 ( 
.A(n_196),
.Y(n_209)
);

INVx1_ASAP7_75t_SL g210 ( 
.A(n_186),
.Y(n_210)
);

AND2x2_ASAP7_75t_L g211 ( 
.A(n_194),
.B(n_79),
.Y(n_211)
);

INVx1_ASAP7_75t_L g212 ( 
.A(n_198),
.Y(n_212)
);

OAI211xp5_ASAP7_75t_L g213 ( 
.A1(n_200),
.A2(n_79),
.B(n_190),
.C(n_197),
.Y(n_213)
);

NAND3x1_ASAP7_75t_L g214 ( 
.A(n_202),
.B(n_79),
.C(n_195),
.Y(n_214)
);

HB1xp67_ASAP7_75t_L g215 ( 
.A(n_203),
.Y(n_215)
);

INVx2_ASAP7_75t_SL g216 ( 
.A(n_208),
.Y(n_216)
);

AND2x4_ASAP7_75t_L g217 ( 
.A(n_212),
.B(n_187),
.Y(n_217)
);

BUFx2_ASAP7_75t_L g218 ( 
.A(n_208),
.Y(n_218)
);

NOR2x1p5_ASAP7_75t_L g219 ( 
.A(n_204),
.B(n_202),
.Y(n_219)
);

XNOR2xp5_ASAP7_75t_L g220 ( 
.A(n_210),
.B(n_214),
.Y(n_220)
);

AND2x4_ASAP7_75t_L g221 ( 
.A(n_209),
.B(n_201),
.Y(n_221)
);

INVx1_ASAP7_75t_L g222 ( 
.A(n_206),
.Y(n_222)
);

NAND2xp5_ASAP7_75t_L g223 ( 
.A(n_219),
.B(n_205),
.Y(n_223)
);

AND2x2_ASAP7_75t_L g224 ( 
.A(n_215),
.B(n_207),
.Y(n_224)
);

OAI321xp33_ASAP7_75t_L g225 ( 
.A1(n_222),
.A2(n_213),
.A3(n_218),
.B1(n_216),
.B2(n_220),
.C(n_211),
.Y(n_225)
);

INVxp67_ASAP7_75t_L g226 ( 
.A(n_220),
.Y(n_226)
);

INVx1_ASAP7_75t_L g227 ( 
.A(n_224),
.Y(n_227)
);

AOI22xp5_ASAP7_75t_L g228 ( 
.A1(n_226),
.A2(n_221),
.B1(n_217),
.B2(n_222),
.Y(n_228)
);

OAI22xp5_ASAP7_75t_L g229 ( 
.A1(n_228),
.A2(n_223),
.B1(n_221),
.B2(n_224),
.Y(n_229)
);

AOI222xp33_ASAP7_75t_L g230 ( 
.A1(n_229),
.A2(n_227),
.B1(n_225),
.B2(n_221),
.C1(n_217),
.C2(n_218),
.Y(n_230)
);

A2O1A1Ixp33_ASAP7_75t_L g231 ( 
.A1(n_230),
.A2(n_217),
.B(n_216),
.C(n_214),
.Y(n_231)
);


endmodule