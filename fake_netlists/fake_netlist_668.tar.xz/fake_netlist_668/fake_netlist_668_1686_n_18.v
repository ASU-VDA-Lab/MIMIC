module fake_netlist_668_1686_n_18 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_18);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_18;

wire n_17;
wire n_14;
wire n_10;
wire n_11;
wire n_15;
wire n_13;
wire n_16;
wire n_12;

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_3),
.Y(n_10)
);

INVx4_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_7),
.Y(n_12)
);

CKINVDCx16_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B1(n_12),
.B2(n_6),
.C(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_4),
.B1(n_1),
.B2(n_5),
.C1(n_9),
.C2(n_8),
.Y(n_18)
);


endmodule