module fake_netlist_668_1420_n_3 (n_0, n_3);

input n_0;

output n_3;

wire n_1;
wire n_2;

INVx8_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

INVx2_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVx3_ASAP7_75t_SL g3 ( 
.A(n_2),
.Y(n_3)
);


endmodule