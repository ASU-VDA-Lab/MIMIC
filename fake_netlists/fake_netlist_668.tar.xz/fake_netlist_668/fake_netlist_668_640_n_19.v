module fake_netlist_668_640_n_19 (n_4, n_1, n_2, n_0, n_5, n_3, n_19);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_19;

wire n_18;
wire n_10;
wire n_15;
wire n_11;
wire n_7;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx8_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_R g7 ( 
.A(n_2),
.B(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_6),
.B1(n_1),
.B2(n_0),
.C(n_2),
.Y(n_10)
);

OAI31xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_6),
.A3(n_1),
.B(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND4xp25_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_1),
.C(n_3),
.D(n_0),
.Y(n_14)
);

NOR4xp75_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.C(n_4),
.D(n_3),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_5),
.B1(n_15),
.B2(n_17),
.Y(n_19)
);


endmodule