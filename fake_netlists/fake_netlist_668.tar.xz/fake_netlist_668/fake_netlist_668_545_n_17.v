module fake_netlist_668_545_n_17 (n_3, n_1, n_2, n_0, n_17);

input n_3;
input n_1;
input n_2;
input n_0;

output n_17;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_6;
wire n_16;
wire n_8;
wire n_15;
wire n_11;

INVx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

BUFx3_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_0),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

INVx5_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_7),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_11),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_6),
.C(n_13),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_1),
.B1(n_9),
.B2(n_11),
.C1(n_4),
.C2(n_8),
.Y(n_17)
);


endmodule