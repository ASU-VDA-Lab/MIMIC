module fake_netlist_668_1485_n_56 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_56);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_56;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_23;
wire n_48;
wire n_16;
wire n_22;
wire n_39;
wire n_17;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_0),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_8),
.B(n_7),
.Y(n_18)
);

AND2x2_ASAP7_75t_SL g19 ( 
.A(n_2),
.B(n_13),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_1),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

BUFx8_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_0),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

AND2x6_ASAP7_75t_SL g29 ( 
.A(n_17),
.B(n_2),
.Y(n_29)
);

NOR2xp67_ASAP7_75t_SL g30 ( 
.A(n_27),
.B(n_22),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_21),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_17),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_25),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_33),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_31),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_30),
.B1(n_19),
.B2(n_20),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_22),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_36),
.Y(n_42)
);

O2A1O1Ixp33_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_28),
.B(n_21),
.C(n_29),
.Y(n_43)
);

NOR4xp25_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_41),
.C(n_42),
.D(n_40),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_19),
.B1(n_20),
.B2(n_16),
.Y(n_45)
);

OAI21xp33_ASAP7_75t_SL g46 ( 
.A1(n_40),
.A2(n_19),
.B(n_18),
.Y(n_46)
);

NAND2xp33_ASAP7_75t_SL g47 ( 
.A(n_40),
.B(n_16),
.Y(n_47)
);

NOR4xp75_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_43),
.C(n_47),
.D(n_3),
.Y(n_48)
);

NAND3xp33_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_16),
.C(n_23),
.Y(n_49)
);

AND3x4_ASAP7_75t_L g50 ( 
.A(n_44),
.B(n_12),
.C(n_3),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_16),
.B1(n_23),
.B2(n_12),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

AOI22xp33_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_16),
.B1(n_23),
.B2(n_14),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_SL g54 ( 
.A1(n_51),
.A2(n_52),
.B1(n_49),
.B2(n_48),
.Y(n_54)
);

OAI22xp5_ASAP7_75t_SL g55 ( 
.A1(n_53),
.A2(n_23),
.B1(n_15),
.B2(n_4),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_53),
.B1(n_54),
.B2(n_6),
.Y(n_56)
);


endmodule