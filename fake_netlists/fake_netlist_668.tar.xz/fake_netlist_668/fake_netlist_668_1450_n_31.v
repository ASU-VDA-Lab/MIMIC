module fake_netlist_668_1450_n_31 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_31);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_31;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_29;
wire n_26;

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_2),
.B(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_0),
.Y(n_21)
);

NOR2x1p5_ASAP7_75t_SL g22 ( 
.A(n_19),
.B(n_1),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_15),
.B(n_4),
.C(n_3),
.Y(n_23)
);

INVxp33_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_17),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_20),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_21),
.B1(n_16),
.B2(n_22),
.Y(n_28)
);

OAI222xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_15),
.B1(n_7),
.B2(n_5),
.C1(n_11),
.C2(n_6),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

XNOR2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_14),
.Y(n_31)
);


endmodule