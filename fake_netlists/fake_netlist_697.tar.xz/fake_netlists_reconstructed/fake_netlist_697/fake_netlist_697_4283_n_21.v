module fake_netlist_697_4283_n_21 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_21);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_21;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

OR2x4_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_1),
.Y(n_12)
);

BUFx12f_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_2),
.B2(n_1),
.Y(n_14)
);

OAI221xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_12),
.B1(n_4),
.B2(n_2),
.C(n_3),
.Y(n_15)
);

OAI31xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.A3(n_5),
.B(n_4),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_5),
.B(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);


endmodule