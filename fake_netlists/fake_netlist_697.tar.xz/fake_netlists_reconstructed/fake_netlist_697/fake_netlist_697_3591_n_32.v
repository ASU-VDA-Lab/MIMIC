module fake_netlist_697_3591_n_32 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_32);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_32;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_12;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_11),
.B(n_14),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_R g19 ( 
.A(n_18),
.B(n_13),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_15),
.B(n_13),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_15),
.B1(n_16),
.B2(n_17),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_20),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_0),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

NAND4xp25_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_2),
.C(n_1),
.D(n_0),
.Y(n_27)
);

NOR2x1_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_1),
.Y(n_28)
);

NOR2x1_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_3),
.Y(n_29)
);

CKINVDCx16_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AOI322xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_30),
.A3(n_7),
.B1(n_10),
.B2(n_4),
.C1(n_6),
.C2(n_9),
.Y(n_32)
);


endmodule