module fake_netlist_697_2909_n_34 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_34);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_34;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_12;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_4),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

INVxp67_ASAP7_75t_SL g18 ( 
.A(n_15),
.Y(n_18)
);

OA22x2_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_6),
.B1(n_5),
.B2(n_0),
.Y(n_19)
);

OR2x2_ASAP7_75t_SL g20 ( 
.A(n_16),
.B(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B1(n_15),
.B2(n_14),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_14),
.B1(n_13),
.B2(n_17),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_21),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_21),
.B(n_22),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_22),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_22),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_27),
.B(n_12),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_14),
.B1(n_20),
.B2(n_6),
.C(n_7),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.A3(n_8),
.B1(n_3),
.B2(n_2),
.C1(n_11),
.C2(n_9),
.Y(n_34)
);


endmodule