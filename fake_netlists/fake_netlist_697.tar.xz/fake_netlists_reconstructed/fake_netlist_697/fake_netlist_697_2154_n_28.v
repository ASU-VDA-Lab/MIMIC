module fake_netlist_697_2154_n_28 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_28);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_28;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_13;
wire n_25;
wire n_19;
wire n_14;
wire n_12;

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

AOI21x1_ASAP7_75t_L g13 ( 
.A1(n_2),
.A2(n_0),
.B(n_11),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_8),
.Y(n_14)
);

CKINVDCx16_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_4),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_17),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_16),
.Y(n_21)
);

AOI21xp33_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_18),
.B(n_14),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

OAI21xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_22),
.B(n_15),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_13),
.B(n_12),
.Y(n_25)
);

CKINVDCx16_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

XOR2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_5),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_10),
.B1(n_9),
.B2(n_7),
.Y(n_28)
);


endmodule