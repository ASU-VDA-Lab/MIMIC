module fake_netlist_697_452_n_12 (n_0, n_2, n_1, n_12);

input n_0;
input n_2;
input n_1;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_3;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OR2x2_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_2),
.Y(n_6)
);

NAND2x1_ASAP7_75t_SL g7 ( 
.A(n_5),
.B(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NOR3xp33_ASAP7_75t_SL g9 ( 
.A(n_8),
.B(n_4),
.C(n_0),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_2),
.B(n_0),
.Y(n_10)
);

XNOR2x1_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_0),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B1(n_7),
.B2(n_1),
.Y(n_12)
);


endmodule