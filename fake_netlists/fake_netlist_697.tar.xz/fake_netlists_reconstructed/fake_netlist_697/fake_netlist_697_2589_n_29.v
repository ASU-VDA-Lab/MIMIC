module fake_netlist_697_2589_n_29 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_29);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_29;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_12;
wire n_28;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_6),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_5),
.Y(n_15)
);

NAND2x1p5_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_5),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_9),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_15),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_11),
.B(n_7),
.C(n_6),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_11),
.B1(n_14),
.B2(n_0),
.C(n_1),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_23),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_24),
.Y(n_26)
);

XNOR2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_2),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_3),
.B1(n_25),
.B2(n_27),
.Y(n_29)
);


endmodule