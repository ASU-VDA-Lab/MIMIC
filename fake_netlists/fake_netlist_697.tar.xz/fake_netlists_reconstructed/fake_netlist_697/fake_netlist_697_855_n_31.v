module fake_netlist_697_855_n_31 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_31);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_31;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_29;
wire n_28;
wire n_11;
wire n_19;
wire n_30;
wire n_25;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_2),
.Y(n_12)
);

INVx6_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx16_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_3),
.Y(n_16)
);

INVxp33_ASAP7_75t_SL g17 ( 
.A(n_14),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND4xp25_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.C(n_18),
.D(n_11),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_15),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_13),
.B1(n_10),
.B2(n_5),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_25),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_6),
.Y(n_27)
);

NOR4xp25_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_10),
.C(n_1),
.D(n_0),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_28),
.B2(n_9),
.Y(n_31)
);


endmodule