module fake_netlist_644_2070_n_13 (n_4, n_1, n_2, n_0, n_3, n_13);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_13;

wire n_7;
wire n_5;
wire n_10;
wire n_6;
wire n_11;
wire n_12;
wire n_8;
wire n_9;

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NOR4xp25_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.C(n_7),
.D(n_0),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_6),
.C(n_2),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_3),
.B(n_2),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_4),
.Y(n_13)
);


endmodule