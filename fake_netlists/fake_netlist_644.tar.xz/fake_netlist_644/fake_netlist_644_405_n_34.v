module fake_netlist_644_405_n_34 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_34);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_34;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_2),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_4),
.B(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_0),
.B(n_8),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

NOR2x1p5_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_16),
.B(n_2),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_16),
.B1(n_13),
.B2(n_17),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_16),
.Y(n_22)
);

AOI33xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_14),
.A3(n_19),
.B1(n_12),
.B2(n_13),
.B3(n_20),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_14),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

XNOR2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_23),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_26),
.B(n_25),
.Y(n_28)
);

OAI221xp5_ASAP7_75t_R g29 ( 
.A1(n_27),
.A2(n_4),
.B1(n_3),
.B2(n_5),
.C(n_6),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_R g30 ( 
.A(n_28),
.B(n_25),
.Y(n_30)
);

NAND4xp25_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_24),
.C(n_26),
.D(n_3),
.Y(n_31)
);

NAND5xp2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_7),
.C(n_11),
.D(n_17),
.E(n_29),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_R g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_11),
.B2(n_7),
.C(n_17),
.Y(n_34)
);


endmodule