module fake_netlist_644_2055_n_41 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_41);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_41;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_16),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

AO22x2_ASAP7_75t_L g22 ( 
.A1(n_8),
.A2(n_15),
.B1(n_14),
.B2(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_7),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_9),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_22),
.A2(n_11),
.B(n_4),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_0),
.Y(n_28)
);

O2A1O1Ixp5_ASAP7_75t_L g29 ( 
.A1(n_21),
.A2(n_24),
.B(n_26),
.C(n_22),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_19),
.Y(n_30)
);

OAI21xp33_ASAP7_75t_SL g31 ( 
.A1(n_27),
.A2(n_22),
.B(n_26),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

O2A1O1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_29),
.B(n_30),
.C(n_23),
.Y(n_33)
);

NAND3xp33_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_19),
.C(n_20),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_20),
.C(n_0),
.Y(n_35)
);

OA21x2_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_13),
.B(n_1),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

NOR2x1_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_1),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_37),
.A2(n_38),
.B1(n_3),
.B2(n_2),
.Y(n_39)
);

OAI22x1_ASAP7_75t_SL g40 ( 
.A1(n_37),
.A2(n_16),
.B1(n_5),
.B2(n_2),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_5),
.B1(n_18),
.B2(n_40),
.Y(n_41)
);


endmodule