module fake_netlist_644_528_n_5 (n_3, n_1, n_2, n_0, n_5);

input n_3;
input n_1;
input n_2;
input n_0;

output n_5;

wire n_4;

BUFx2_ASAP7_75t_SL g4 ( 
.A(n_2),
.Y(n_4)
);

NOR4xp25_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_3),
.C(n_1),
.D(n_0),
.Y(n_5)
);


endmodule