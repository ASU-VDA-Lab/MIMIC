module fake_netlist_644_520_n_32 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_32);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_32;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

INVx5_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_7),
.Y(n_21)
);

AND3x2_ASAP7_75t_L g22 ( 
.A(n_4),
.B(n_16),
.C(n_3),
.Y(n_22)
);

INVx4_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_18),
.B(n_15),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_R g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_17),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_21),
.B1(n_15),
.B2(n_19),
.C(n_20),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

AO22x2_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_30)
);

OAI22x1_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_11),
.B1(n_9),
.B2(n_5),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_31),
.B1(n_14),
.B2(n_12),
.Y(n_32)
);


endmodule