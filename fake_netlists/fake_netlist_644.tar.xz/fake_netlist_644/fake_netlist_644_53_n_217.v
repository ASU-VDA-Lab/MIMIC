module fake_netlist_644_53_n_217 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_217);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_217;

wire n_168;
wire n_99;
wire n_62;
wire n_70;
wire n_90;
wire n_101;
wire n_38;
wire n_58;
wire n_144;
wire n_166;
wire n_155;
wire n_139;
wire n_57;
wire n_84;
wire n_214;
wire n_35;
wire n_89;
wire n_209;
wire n_152;
wire n_116;
wire n_96;
wire n_172;
wire n_45;
wire n_107;
wire n_78;
wire n_191;
wire n_66;
wire n_164;
wire n_154;
wire n_118;
wire n_60;
wire n_137;
wire n_39;
wire n_197;
wire n_189;
wire n_173;
wire n_183;
wire n_63;
wire n_190;
wire n_211;
wire n_206;
wire n_192;
wire n_177;
wire n_31;
wire n_194;
wire n_184;
wire n_187;
wire n_81;
wire n_37;
wire n_71;
wire n_124;
wire n_163;
wire n_91;
wire n_165;
wire n_121;
wire n_157;
wire n_201;
wire n_105;
wire n_92;
wire n_125;
wire n_117;
wire n_136;
wire n_40;
wire n_110;
wire n_28;
wire n_170;
wire n_49;
wire n_207;
wire n_151;
wire n_53;
wire n_161;
wire n_77;
wire n_75;
wire n_48;
wire n_180;
wire n_142;
wire n_93;
wire n_199;
wire n_203;
wire n_181;
wire n_41;
wire n_143;
wire n_213;
wire n_65;
wire n_109;
wire n_33;
wire n_208;
wire n_122;
wire n_119;
wire n_149;
wire n_43;
wire n_182;
wire n_82;
wire n_204;
wire n_120;
wire n_85;
wire n_61;
wire n_176;
wire n_72;
wire n_51;
wire n_160;
wire n_25;
wire n_54;
wire n_86;
wire n_156;
wire n_68;
wire n_198;
wire n_130;
wire n_210;
wire n_140;
wire n_174;
wire n_202;
wire n_167;
wire n_175;
wire n_195;
wire n_27;
wire n_112;
wire n_67;
wire n_29;
wire n_179;
wire n_52;
wire n_50;
wire n_113;
wire n_169;
wire n_103;
wire n_104;
wire n_26;
wire n_127;
wire n_162;
wire n_100;
wire n_150;
wire n_129;
wire n_146;
wire n_76;
wire n_83;
wire n_134;
wire n_196;
wire n_200;
wire n_106;
wire n_133;
wire n_36;
wire n_59;
wire n_97;
wire n_34;
wire n_131;
wire n_64;
wire n_148;
wire n_44;
wire n_159;
wire n_123;
wire n_141;
wire n_87;
wire n_115;
wire n_145;
wire n_79;
wire n_215;
wire n_30;
wire n_128;
wire n_205;
wire n_108;
wire n_126;
wire n_185;
wire n_73;
wire n_132;
wire n_56;
wire n_98;
wire n_69;
wire n_147;
wire n_171;
wire n_94;
wire n_212;
wire n_193;
wire n_138;
wire n_46;
wire n_153;
wire n_42;
wire n_158;
wire n_216;
wire n_55;
wire n_102;
wire n_135;
wire n_95;
wire n_178;
wire n_74;
wire n_32;
wire n_186;
wire n_47;
wire n_188;
wire n_80;
wire n_88;
wire n_114;
wire n_111;

INVx2_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_8),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_4),
.Y(n_27)
);

INVxp67_ASAP7_75t_SL g28 ( 
.A(n_7),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_5),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_16),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_9),
.Y(n_33)
);

INVxp67_ASAP7_75t_SL g34 ( 
.A(n_22),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_19),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_0),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_5),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_16),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_25),
.B(n_0),
.Y(n_40)
);

AND2x2_ASAP7_75t_SL g41 ( 
.A(n_25),
.B(n_3),
.Y(n_41)
);

INVx3_ASAP7_75t_L g42 ( 
.A(n_25),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_27),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_27),
.B(n_1),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_29),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_SL g46 ( 
.A(n_26),
.B(n_1),
.Y(n_46)
);

INVx2_ASAP7_75t_SL g47 ( 
.A(n_29),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_30),
.Y(n_48)
);

BUFx6f_ASAP7_75t_L g49 ( 
.A(n_30),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_31),
.Y(n_50)
);

OAI22xp33_ASAP7_75t_L g51 ( 
.A1(n_28),
.A2(n_6),
.B1(n_4),
.B2(n_2),
.Y(n_51)
);

NOR2xp33_ASAP7_75t_R g52 ( 
.A(n_31),
.B(n_2),
.Y(n_52)
);

INVxp67_ASAP7_75t_L g53 ( 
.A(n_47),
.Y(n_53)
);

AND2x4_ASAP7_75t_L g54 ( 
.A(n_43),
.B(n_32),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_49),
.Y(n_55)
);

INVxp67_ASAP7_75t_L g56 ( 
.A(n_47),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_49),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_49),
.Y(n_58)
);

A2O1A1Ixp33_ASAP7_75t_L g59 ( 
.A1(n_40),
.A2(n_28),
.B(n_33),
.C(n_32),
.Y(n_59)
);

AOI22xp33_ASAP7_75t_L g60 ( 
.A1(n_40),
.A2(n_41),
.B1(n_50),
.B2(n_44),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_49),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_50),
.B(n_33),
.Y(n_62)
);

AND2x4_ASAP7_75t_L g63 ( 
.A(n_43),
.B(n_35),
.Y(n_63)
);

AND2x2_ASAP7_75t_L g64 ( 
.A(n_43),
.B(n_35),
.Y(n_64)
);

INVx4_ASAP7_75t_L g65 ( 
.A(n_49),
.Y(n_65)
);

AND2x6_ASAP7_75t_SL g66 ( 
.A(n_44),
.B(n_36),
.Y(n_66)
);

AND2x6_ASAP7_75t_L g67 ( 
.A(n_42),
.B(n_49),
.Y(n_67)
);

INVx2_ASAP7_75t_SL g68 ( 
.A(n_41),
.Y(n_68)
);

AOI22xp33_ASAP7_75t_L g69 ( 
.A1(n_41),
.A2(n_38),
.B1(n_37),
.B2(n_36),
.Y(n_69)
);

AO32x2_ASAP7_75t_L g70 ( 
.A1(n_68),
.A2(n_47),
.A3(n_41),
.B1(n_51),
.B2(n_52),
.Y(n_70)
);

O2A1O1Ixp33_ASAP7_75t_SL g71 ( 
.A1(n_68),
.A2(n_46),
.B(n_50),
.C(n_51),
.Y(n_71)
);

AND2x4_ASAP7_75t_L g72 ( 
.A(n_59),
.B(n_43),
.Y(n_72)
);

NOR2xp67_ASAP7_75t_SL g73 ( 
.A(n_68),
.B(n_49),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_L g74 ( 
.A(n_68),
.B(n_49),
.Y(n_74)
);

AOI21xp33_ASAP7_75t_L g75 ( 
.A1(n_69),
.A2(n_46),
.B(n_34),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_SL g76 ( 
.A(n_69),
.B(n_52),
.Y(n_76)
);

OAI21x1_ASAP7_75t_L g77 ( 
.A1(n_60),
.A2(n_48),
.B(n_45),
.Y(n_77)
);

AOI21xp5_ASAP7_75t_L g78 ( 
.A1(n_60),
.A2(n_48),
.B(n_45),
.Y(n_78)
);

NOR3xp33_ASAP7_75t_L g79 ( 
.A(n_59),
.B(n_38),
.C(n_37),
.Y(n_79)
);

CKINVDCx6p67_ASAP7_75t_R g80 ( 
.A(n_63),
.Y(n_80)
);

AOI21xp5_ASAP7_75t_SL g81 ( 
.A1(n_65),
.A2(n_49),
.B(n_39),
.Y(n_81)
);

AOI21xp5_ASAP7_75t_L g82 ( 
.A1(n_55),
.A2(n_48),
.B(n_45),
.Y(n_82)
);

OAI22xp5_ASAP7_75t_L g83 ( 
.A1(n_53),
.A2(n_39),
.B1(n_48),
.B2(n_45),
.Y(n_83)
);

OAI21x1_ASAP7_75t_L g84 ( 
.A1(n_55),
.A2(n_42),
.B(n_11),
.Y(n_84)
);

INVx2_ASAP7_75t_SL g85 ( 
.A(n_64),
.Y(n_85)
);

OAI21x1_ASAP7_75t_L g86 ( 
.A1(n_55),
.A2(n_42),
.B(n_6),
.Y(n_86)
);

OAI21x1_ASAP7_75t_L g87 ( 
.A1(n_57),
.A2(n_42),
.B(n_7),
.Y(n_87)
);

OAI21x1_ASAP7_75t_L g88 ( 
.A1(n_57),
.A2(n_42),
.B(n_8),
.Y(n_88)
);

AOI21xp33_ASAP7_75t_L g89 ( 
.A1(n_64),
.A2(n_54),
.B(n_63),
.Y(n_89)
);

AOI21x1_ASAP7_75t_SL g90 ( 
.A1(n_72),
.A2(n_54),
.B(n_63),
.Y(n_90)
);

AND2x2_ASAP7_75t_L g91 ( 
.A(n_85),
.B(n_53),
.Y(n_91)
);

NAND2xp5_ASAP7_75t_L g92 ( 
.A(n_85),
.B(n_56),
.Y(n_92)
);

O2A1O1Ixp33_ASAP7_75t_L g93 ( 
.A1(n_75),
.A2(n_89),
.B(n_76),
.C(n_79),
.Y(n_93)
);

O2A1O1Ixp5_ASAP7_75t_L g94 ( 
.A1(n_78),
.A2(n_73),
.B(n_89),
.C(n_72),
.Y(n_94)
);

NAND2xp5_ASAP7_75t_L g95 ( 
.A(n_74),
.B(n_56),
.Y(n_95)
);

OAI22xp5_ASAP7_75t_L g96 ( 
.A1(n_72),
.A2(n_62),
.B1(n_54),
.B2(n_63),
.Y(n_96)
);

NAND2xp5_ASAP7_75t_L g97 ( 
.A(n_72),
.B(n_65),
.Y(n_97)
);

OA21x2_ASAP7_75t_L g98 ( 
.A1(n_86),
.A2(n_61),
.B(n_57),
.Y(n_98)
);

BUFx6f_ASAP7_75t_L g99 ( 
.A(n_87),
.Y(n_99)
);

NOR2xp33_ASAP7_75t_R g100 ( 
.A(n_80),
.B(n_66),
.Y(n_100)
);

OAI22xp5_ASAP7_75t_L g101 ( 
.A1(n_83),
.A2(n_62),
.B1(n_54),
.B2(n_63),
.Y(n_101)
);

NAND2xp5_ASAP7_75t_L g102 ( 
.A(n_77),
.B(n_65),
.Y(n_102)
);

OR2x2_ASAP7_75t_L g103 ( 
.A(n_80),
.B(n_83),
.Y(n_103)
);

AND2x4_ASAP7_75t_L g104 ( 
.A(n_77),
.B(n_64),
.Y(n_104)
);

AND2x2_ASAP7_75t_L g105 ( 
.A(n_70),
.B(n_54),
.Y(n_105)
);

BUFx6f_ASAP7_75t_L g106 ( 
.A(n_87),
.Y(n_106)
);

NOR2xp33_ASAP7_75t_L g107 ( 
.A(n_92),
.B(n_71),
.Y(n_107)
);

AND2x2_ASAP7_75t_L g108 ( 
.A(n_105),
.B(n_91),
.Y(n_108)
);

OR2x2_ASAP7_75t_SL g109 ( 
.A(n_103),
.B(n_70),
.Y(n_109)
);

INVx2_ASAP7_75t_SL g110 ( 
.A(n_104),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_104),
.Y(n_111)
);

OR2x2_ASAP7_75t_L g112 ( 
.A(n_92),
.B(n_54),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_104),
.Y(n_113)
);

AOI221xp5_ASAP7_75t_L g114 ( 
.A1(n_93),
.A2(n_101),
.B1(n_96),
.B2(n_105),
.C(n_63),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_104),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_104),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_97),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_111),
.Y(n_118)
);

AND2x6_ASAP7_75t_L g119 ( 
.A(n_111),
.B(n_105),
.Y(n_119)
);

INVx1_ASAP7_75t_L g120 ( 
.A(n_113),
.Y(n_120)
);

NOR2x1p5_ASAP7_75t_L g121 ( 
.A(n_108),
.B(n_103),
.Y(n_121)
);

INVx2_ASAP7_75t_L g122 ( 
.A(n_113),
.Y(n_122)
);

NOR3xp33_ASAP7_75t_SL g123 ( 
.A(n_107),
.B(n_101),
.C(n_96),
.Y(n_123)
);

INVx1_ASAP7_75t_L g124 ( 
.A(n_115),
.Y(n_124)
);

BUFx2_ASAP7_75t_L g125 ( 
.A(n_115),
.Y(n_125)
);

INVx3_ASAP7_75t_SL g126 ( 
.A(n_110),
.Y(n_126)
);

OR2x2_ASAP7_75t_L g127 ( 
.A(n_121),
.B(n_109),
.Y(n_127)
);

OR2x2_ASAP7_75t_L g128 ( 
.A(n_121),
.B(n_109),
.Y(n_128)
);

NAND3xp33_ASAP7_75t_SL g129 ( 
.A(n_123),
.B(n_100),
.C(n_93),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_118),
.Y(n_130)
);

INVx1_ASAP7_75t_L g131 ( 
.A(n_118),
.Y(n_131)
);

INVx1_ASAP7_75t_L g132 ( 
.A(n_120),
.Y(n_132)
);

OR2x2_ASAP7_75t_L g133 ( 
.A(n_122),
.B(n_108),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_120),
.Y(n_134)
);

OR2x2_ASAP7_75t_L g135 ( 
.A(n_122),
.B(n_112),
.Y(n_135)
);

OR2x2_ASAP7_75t_L g136 ( 
.A(n_124),
.B(n_112),
.Y(n_136)
);

INVx2_ASAP7_75t_L g137 ( 
.A(n_134),
.Y(n_137)
);

AND2x2_ASAP7_75t_L g138 ( 
.A(n_134),
.B(n_124),
.Y(n_138)
);

OAI21xp33_ASAP7_75t_L g139 ( 
.A1(n_129),
.A2(n_114),
.B(n_100),
.Y(n_139)
);

AND2x2_ASAP7_75t_L g140 ( 
.A(n_127),
.B(n_125),
.Y(n_140)
);

OAI21xp5_ASAP7_75t_L g141 ( 
.A1(n_136),
.A2(n_94),
.B(n_114),
.Y(n_141)
);

AOI22xp5_ASAP7_75t_L g142 ( 
.A1(n_128),
.A2(n_119),
.B1(n_103),
.B2(n_125),
.Y(n_142)
);

NAND2xp5_ASAP7_75t_L g143 ( 
.A(n_133),
.B(n_117),
.Y(n_143)
);

NAND2xp5_ASAP7_75t_L g144 ( 
.A(n_135),
.B(n_117),
.Y(n_144)
);

INVx2_ASAP7_75t_L g145 ( 
.A(n_130),
.Y(n_145)
);

NOR2xp33_ASAP7_75t_L g146 ( 
.A(n_131),
.B(n_66),
.Y(n_146)
);

OAI321xp33_ASAP7_75t_L g147 ( 
.A1(n_132),
.A2(n_70),
.A3(n_116),
.B1(n_95),
.B2(n_91),
.C(n_110),
.Y(n_147)
);

NAND2xp5_ASAP7_75t_L g148 ( 
.A(n_133),
.B(n_117),
.Y(n_148)
);

NOR2xp67_ASAP7_75t_L g149 ( 
.A(n_129),
.B(n_116),
.Y(n_149)
);

AND2x2_ASAP7_75t_SL g150 ( 
.A(n_127),
.B(n_99),
.Y(n_150)
);

NOR4xp25_ASAP7_75t_L g151 ( 
.A(n_139),
.B(n_146),
.C(n_147),
.D(n_141),
.Y(n_151)
);

NAND2xp5_ASAP7_75t_L g152 ( 
.A(n_144),
.B(n_119),
.Y(n_152)
);

NAND4xp75_ASAP7_75t_L g153 ( 
.A(n_149),
.B(n_70),
.C(n_110),
.D(n_91),
.Y(n_153)
);

OAI211xp5_ASAP7_75t_SL g154 ( 
.A1(n_139),
.A2(n_42),
.B(n_82),
.C(n_81),
.Y(n_154)
);

NAND4xp25_ASAP7_75t_L g155 ( 
.A(n_149),
.B(n_70),
.C(n_94),
.D(n_81),
.Y(n_155)
);

OAI21xp33_ASAP7_75t_L g156 ( 
.A1(n_142),
.A2(n_95),
.B(n_86),
.Y(n_156)
);

NOR2xp33_ASAP7_75t_L g157 ( 
.A(n_140),
.B(n_126),
.Y(n_157)
);

AOI21xp5_ASAP7_75t_L g158 ( 
.A1(n_147),
.A2(n_106),
.B(n_99),
.Y(n_158)
);

AOI21xp33_ASAP7_75t_L g159 ( 
.A1(n_148),
.A2(n_102),
.B(n_84),
.Y(n_159)
);

AOI211xp5_ASAP7_75t_SL g160 ( 
.A1(n_142),
.A2(n_61),
.B(n_102),
.C(n_97),
.Y(n_160)
);

AOI21xp5_ASAP7_75t_L g161 ( 
.A1(n_143),
.A2(n_106),
.B(n_99),
.Y(n_161)
);

AOI22xp33_ASAP7_75t_L g162 ( 
.A1(n_140),
.A2(n_119),
.B1(n_126),
.B2(n_88),
.Y(n_162)
);

OAI211xp5_ASAP7_75t_L g163 ( 
.A1(n_138),
.A2(n_88),
.B(n_84),
.C(n_98),
.Y(n_163)
);

AOI21xp5_ASAP7_75t_L g164 ( 
.A1(n_150),
.A2(n_106),
.B(n_99),
.Y(n_164)
);

NOR4xp25_ASAP7_75t_L g165 ( 
.A(n_145),
.B(n_13),
.C(n_12),
.D(n_10),
.Y(n_165)
);

AOI21xp5_ASAP7_75t_L g166 ( 
.A1(n_150),
.A2(n_106),
.B(n_99),
.Y(n_166)
);

AOI21xp5_ASAP7_75t_L g167 ( 
.A1(n_150),
.A2(n_106),
.B(n_99),
.Y(n_167)
);

OAI221xp5_ASAP7_75t_SL g168 ( 
.A1(n_145),
.A2(n_137),
.B1(n_138),
.B2(n_10),
.C(n_12),
.Y(n_168)
);

OAI21xp5_ASAP7_75t_L g169 ( 
.A1(n_151),
.A2(n_137),
.B(n_119),
.Y(n_169)
);

INVx1_ASAP7_75t_L g170 ( 
.A(n_161),
.Y(n_170)
);

INVxp33_ASAP7_75t_L g171 ( 
.A(n_157),
.Y(n_171)
);

CKINVDCx5p33_ASAP7_75t_R g172 ( 
.A(n_157),
.Y(n_172)
);

OAI221xp5_ASAP7_75t_L g173 ( 
.A1(n_168),
.A2(n_126),
.B1(n_61),
.B2(n_58),
.C(n_13),
.Y(n_173)
);

HB1xp67_ASAP7_75t_L g174 ( 
.A(n_152),
.Y(n_174)
);

AND2x4_ASAP7_75t_L g175 ( 
.A(n_164),
.B(n_166),
.Y(n_175)
);

OR2x2_ASAP7_75t_L g176 ( 
.A(n_165),
.B(n_156),
.Y(n_176)
);

NOR2x1_ASAP7_75t_L g177 ( 
.A(n_153),
.B(n_58),
.Y(n_177)
);

NOR2x1_ASAP7_75t_L g178 ( 
.A(n_155),
.B(n_58),
.Y(n_178)
);

OAI21xp5_ASAP7_75t_L g179 ( 
.A1(n_160),
.A2(n_119),
.B(n_58),
.Y(n_179)
);

OR2x2_ASAP7_75t_L g180 ( 
.A(n_162),
.B(n_98),
.Y(n_180)
);

NAND2xp5_ASAP7_75t_L g181 ( 
.A(n_162),
.B(n_119),
.Y(n_181)
);

INVx1_ASAP7_75t_L g182 ( 
.A(n_158),
.Y(n_182)
);

OR2x2_ASAP7_75t_L g183 ( 
.A(n_167),
.B(n_98),
.Y(n_183)
);

NAND2xp5_ASAP7_75t_L g184 ( 
.A(n_159),
.B(n_119),
.Y(n_184)
);

AND2x2_ASAP7_75t_L g185 ( 
.A(n_163),
.B(n_98),
.Y(n_185)
);

INVx3_ASAP7_75t_L g186 ( 
.A(n_175),
.Y(n_186)
);

NAND2xp5_ASAP7_75t_L g187 ( 
.A(n_174),
.B(n_119),
.Y(n_187)
);

NAND2xp5_ASAP7_75t_L g188 ( 
.A(n_171),
.B(n_14),
.Y(n_188)
);

INVx1_ASAP7_75t_L g189 ( 
.A(n_182),
.Y(n_189)
);

OAI211xp5_ASAP7_75t_SL g190 ( 
.A1(n_176),
.A2(n_17),
.B(n_15),
.C(n_14),
.Y(n_190)
);

INVx2_ASAP7_75t_L g191 ( 
.A(n_170),
.Y(n_191)
);

INVxp67_ASAP7_75t_SL g192 ( 
.A(n_170),
.Y(n_192)
);

AND4x1_ASAP7_75t_L g193 ( 
.A(n_169),
.B(n_19),
.C(n_18),
.D(n_17),
.Y(n_193)
);

NAND4xp25_ASAP7_75t_L g194 ( 
.A(n_176),
.B(n_154),
.C(n_20),
.D(n_18),
.Y(n_194)
);

OR2x2_ASAP7_75t_L g195 ( 
.A(n_182),
.B(n_20),
.Y(n_195)
);

AOI22xp5_ASAP7_75t_L g196 ( 
.A1(n_173),
.A2(n_98),
.B1(n_106),
.B2(n_99),
.Y(n_196)
);

AND2x2_ASAP7_75t_L g197 ( 
.A(n_175),
.B(n_21),
.Y(n_197)
);

INVx1_ASAP7_75t_SL g198 ( 
.A(n_172),
.Y(n_198)
);

AOI322xp5_ASAP7_75t_L g199 ( 
.A1(n_196),
.A2(n_197),
.A3(n_188),
.B1(n_192),
.B2(n_198),
.C1(n_194),
.C2(n_189),
.Y(n_199)
);

OAI222xp33_ASAP7_75t_L g200 ( 
.A1(n_195),
.A2(n_172),
.B1(n_181),
.B2(n_180),
.C1(n_178),
.C2(n_184),
.Y(n_200)
);

AND2x2_ASAP7_75t_L g201 ( 
.A(n_186),
.B(n_197),
.Y(n_201)
);

OAI221xp5_ASAP7_75t_L g202 ( 
.A1(n_190),
.A2(n_193),
.B1(n_195),
.B2(n_186),
.C(n_187),
.Y(n_202)
);

AOI322xp5_ASAP7_75t_L g203 ( 
.A1(n_189),
.A2(n_193),
.A3(n_191),
.B1(n_185),
.B2(n_186),
.C1(n_177),
.C2(n_175),
.Y(n_203)
);

OAI32xp33_ASAP7_75t_L g204 ( 
.A1(n_191),
.A2(n_180),
.A3(n_183),
.B1(n_185),
.B2(n_179),
.Y(n_204)
);

AOI32xp33_ASAP7_75t_L g205 ( 
.A1(n_190),
.A2(n_183),
.A3(n_24),
.B1(n_22),
.B2(n_23),
.Y(n_205)
);

AOI221xp5_ASAP7_75t_L g206 ( 
.A1(n_190),
.A2(n_23),
.B1(n_106),
.B2(n_73),
.C(n_65),
.Y(n_206)
);

AOI21xp33_ASAP7_75t_L g207 ( 
.A1(n_202),
.A2(n_65),
.B(n_90),
.Y(n_207)
);

OA21x2_ASAP7_75t_L g208 ( 
.A1(n_200),
.A2(n_90),
.B(n_67),
.Y(n_208)
);

OAI21xp5_ASAP7_75t_SL g209 ( 
.A1(n_205),
.A2(n_67),
.B(n_65),
.Y(n_209)
);

CKINVDCx14_ASAP7_75t_R g210 ( 
.A(n_201),
.Y(n_210)
);

OAI22x1_ASAP7_75t_L g211 ( 
.A1(n_199),
.A2(n_67),
.B1(n_203),
.B2(n_200),
.Y(n_211)
);

INVx1_ASAP7_75t_L g212 ( 
.A(n_211),
.Y(n_212)
);

OAI21x1_ASAP7_75t_L g213 ( 
.A1(n_208),
.A2(n_210),
.B(n_209),
.Y(n_213)
);

OAI22x1_ASAP7_75t_SL g214 ( 
.A1(n_208),
.A2(n_206),
.B1(n_204),
.B2(n_67),
.Y(n_214)
);

OAI21xp5_ASAP7_75t_L g215 ( 
.A1(n_212),
.A2(n_207),
.B(n_67),
.Y(n_215)
);

OAI21x1_ASAP7_75t_SL g216 ( 
.A1(n_212),
.A2(n_67),
.B(n_213),
.Y(n_216)
);

AOI31xp33_ASAP7_75t_L g217 ( 
.A1(n_215),
.A2(n_216),
.A3(n_214),
.B(n_213),
.Y(n_217)
);


endmodule