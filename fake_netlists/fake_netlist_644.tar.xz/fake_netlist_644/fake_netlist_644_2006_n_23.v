module fake_netlist_644_2006_n_23 (n_4, n_1, n_2, n_0, n_3, n_23);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_23;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

AND2x4_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_4),
.Y(n_5)
);

INVxp33_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_1),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_SL g14 ( 
.A(n_10),
.B(n_6),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_6),
.Y(n_15)
);

CKINVDCx16_ASAP7_75t_R g16 ( 
.A(n_14),
.Y(n_16)
);

AOI211xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_12),
.B(n_16),
.C(n_13),
.Y(n_17)
);

NOR2x1_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_9),
.Y(n_18)
);

NOR4xp75_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_4),
.C(n_2),
.D(n_3),
.Y(n_19)
);

OR3x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_2),
.C(n_3),
.Y(n_20)
);

AND2x2_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NOR2xp67_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_21),
.Y(n_23)
);


endmodule