module fake_netlist_644_625_n_18 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_18);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_18;

wire n_17;
wire n_14;
wire n_10;
wire n_11;
wire n_9;
wire n_15;
wire n_13;
wire n_8;
wire n_16;
wire n_12;

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_0),
.A2(n_6),
.B1(n_4),
.B2(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_6),
.Y(n_11)
);

AO32x2_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_3),
.A3(n_5),
.B1(n_7),
.B2(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

AOI21xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_8),
.B(n_5),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_9),
.Y(n_18)
);


endmodule