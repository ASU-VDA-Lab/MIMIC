module fake_netlist_644_353_n_23 (n_4, n_1, n_2, n_0, n_5, n_3, n_23);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_23;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVx4_ASAP7_75t_SL g7 ( 
.A(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_4),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

BUFx2_ASAP7_75t_SL g10 ( 
.A(n_9),
.Y(n_10)
);

NOR2x1_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_7),
.Y(n_14)
);

AND3x1_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_6),
.C(n_8),
.Y(n_15)
);

OAI22xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_9),
.B1(n_7),
.B2(n_0),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_7),
.B1(n_1),
.B2(n_3),
.C1(n_2),
.C2(n_10),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_SL g19 ( 
.A(n_18),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_14),
.B1(n_15),
.B2(n_13),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_16),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_17),
.B2(n_20),
.C(n_15),
.Y(n_23)
);


endmodule