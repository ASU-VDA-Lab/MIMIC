module fake_netlist_644_116_n_7 (n_4, n_1, n_2, n_0, n_3, n_7);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_7;

wire n_5;
wire n_6;

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

NAND4xp25_ASAP7_75t_SL g7 ( 
.A(n_6),
.B(n_0),
.C(n_3),
.D(n_5),
.Y(n_7)
);


endmodule