module fake_netlist_644_2182_n_22 (n_4, n_1, n_2, n_0, n_5, n_3, n_22);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_22;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

BUFx6f_ASAP7_75t_SL g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_0),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_9),
.B1(n_13),
.B2(n_7),
.Y(n_16)
);

AOI322xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_11),
.A3(n_13),
.B1(n_7),
.B2(n_3),
.C1(n_2),
.C2(n_4),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_15),
.B(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_3),
.B2(n_2),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_18),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_SL g22 ( 
.A1(n_20),
.A2(n_4),
.B1(n_5),
.B2(n_21),
.Y(n_22)
);


endmodule