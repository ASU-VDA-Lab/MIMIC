module fake_netlist_644_2029_n_35 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_35);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_35;

wire n_18;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

AOI21x1_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_11),
.B(n_5),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

INVx8_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_8),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_4),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_21),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

O2A1O1Ixp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_18),
.B(n_26),
.C(n_20),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_24),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_20),
.B1(n_19),
.B2(n_28),
.Y(n_31)
);

A2O1A1Ixp33_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_10),
.B(n_9),
.C(n_7),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_35)
);


endmodule