module fake_netlist_644_184_n_21 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_21);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_1),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

BUFx10_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_10),
.Y(n_17)
);

NAND4xp25_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_8),
.C(n_12),
.D(n_11),
.Y(n_18)
);

CKINVDCx6p67_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_21)
);


endmodule