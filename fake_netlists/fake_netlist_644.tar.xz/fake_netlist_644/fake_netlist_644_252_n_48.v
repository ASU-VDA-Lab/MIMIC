module fake_netlist_644_252_n_48 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_48);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_48;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_8),
.B(n_12),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_5),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

XNOR2x2_ASAP7_75t_L g28 ( 
.A(n_14),
.B(n_11),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_13),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_17),
.B(n_16),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_29),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_30),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_33),
.Y(n_37)
);

OAI31xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_28),
.A3(n_23),
.B(n_22),
.Y(n_38)
);

CKINVDCx16_ASAP7_75t_R g39 ( 
.A(n_36),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_25),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

OAI21xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_19),
.B(n_1),
.Y(n_42)
);

XNOR2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_19),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_43),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_4),
.B1(n_3),
.B2(n_7),
.C(n_9),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_10),
.Y(n_47)
);

OAI22xp33_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_15),
.B1(n_20),
.B2(n_46),
.Y(n_48)
);


endmodule