module fake_netlist_644_1034_n_28 (n_4, n_1, n_2, n_0, n_5, n_3, n_28);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_28;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_26;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_2),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_4),
.B(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_1),
.B(n_2),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_0),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

NOR4xp25_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_7),
.C(n_2),
.D(n_1),
.Y(n_14)
);

AO22x2_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_15)
);

NOR2x1_ASAP7_75t_SL g16 ( 
.A(n_12),
.B(n_3),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_15),
.B1(n_10),
.B2(n_14),
.C(n_16),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_15),
.B1(n_19),
.B2(n_17),
.Y(n_21)
);

NAND4xp25_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_15),
.C(n_4),
.D(n_3),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_15),
.B1(n_11),
.B2(n_3),
.Y(n_24)
);

NAND3x1_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_15),
.C(n_5),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_25),
.B1(n_24),
.B2(n_15),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_15),
.B(n_11),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_5),
.B(n_26),
.Y(n_28)
);


endmodule