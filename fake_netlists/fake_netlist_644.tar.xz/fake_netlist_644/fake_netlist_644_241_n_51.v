module fake_netlist_644_241_n_51 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_51);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_51;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_16;
wire n_22;
wire n_17;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_1),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_7),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

AND3x2_ASAP7_75t_SL g29 ( 
.A(n_22),
.B(n_1),
.C(n_0),
.Y(n_29)
);

OAI22xp33_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_23),
.B1(n_24),
.B2(n_16),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_20),
.B(n_19),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_20),
.Y(n_32)
);

AOI33xp33_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_26),
.A3(n_27),
.B1(n_29),
.B2(n_25),
.B3(n_2),
.Y(n_33)
);

AO21x2_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_19),
.B(n_32),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_2),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_3),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_33),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_33),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_36),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_SL g42 ( 
.A(n_41),
.B(n_17),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_40),
.Y(n_43)
);

NAND2xp33_ASAP7_75t_SL g44 ( 
.A(n_39),
.B(n_29),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_39),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_5),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_R g47 ( 
.A1(n_44),
.A2(n_15),
.B1(n_9),
.B2(n_6),
.Y(n_47)
);

NOR3xp33_ASAP7_75t_SL g48 ( 
.A(n_44),
.B(n_42),
.C(n_45),
.Y(n_48)
);

CKINVDCx20_ASAP7_75t_R g49 ( 
.A(n_46),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

AOI322xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_8),
.A3(n_9),
.B1(n_11),
.B2(n_14),
.C1(n_48),
.C2(n_49),
.Y(n_51)
);


endmodule