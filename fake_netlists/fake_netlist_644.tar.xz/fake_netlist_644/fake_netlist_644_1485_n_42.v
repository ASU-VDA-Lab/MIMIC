module fake_netlist_644_1485_n_42 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_42);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_42;

wire n_36;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_2),
.B(n_0),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_16),
.B(n_19),
.Y(n_25)
);

NOR2x1p5_ASAP7_75t_L g26 ( 
.A(n_3),
.B(n_2),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

NOR2xp67_ASAP7_75t_L g28 ( 
.A(n_18),
.B(n_7),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_16),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_17),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_26),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_SL g33 ( 
.A(n_31),
.B(n_25),
.C(n_24),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_23),
.Y(n_34)
);

AOI31xp33_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_30),
.A3(n_33),
.B(n_26),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_22),
.B1(n_21),
.B2(n_20),
.C(n_28),
.Y(n_36)
);

AOI321xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_21),
.A3(n_20),
.B1(n_22),
.B2(n_5),
.C(n_1),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

CKINVDCx16_ASAP7_75t_R g39 ( 
.A(n_37),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_8),
.B1(n_6),
.B2(n_9),
.C(n_10),
.Y(n_40)
);

XNOR2x1_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_11),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_41),
.A2(n_13),
.B1(n_14),
.B2(n_40),
.Y(n_42)
);


endmodule