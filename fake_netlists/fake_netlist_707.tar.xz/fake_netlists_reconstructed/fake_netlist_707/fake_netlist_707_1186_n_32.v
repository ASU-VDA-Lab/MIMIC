module fake_netlist_707_1186_n_32 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_32);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_32;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_13;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_11),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_R g14 ( 
.A(n_10),
.B(n_4),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_12),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_18),
.B(n_14),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_20),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_20),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

AOI211xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_17),
.B(n_16),
.C(n_13),
.Y(n_27)
);

OAI221xp5_ASAP7_75t_SL g28 ( 
.A1(n_26),
.A2(n_17),
.B1(n_4),
.B2(n_0),
.C(n_1),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_3),
.B1(n_9),
.B2(n_30),
.Y(n_32)
);


endmodule