module fake_netlist_707_1637_n_53 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_53);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_53;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_16;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_12;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_19;
wire n_39;
wire n_14;
wire n_13;

INVx5_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_15),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_15),
.A2(n_4),
.B1(n_2),
.B2(n_0),
.Y(n_23)
);

OAI22xp33_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_5),
.B1(n_4),
.B2(n_0),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_SL g25 ( 
.A(n_20),
.B(n_6),
.C(n_5),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_14),
.A2(n_7),
.B(n_6),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_14),
.B(n_18),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_22),
.B(n_19),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

OR2x6_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_19),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_27),
.B(n_16),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_23),
.B1(n_25),
.B2(n_24),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_31),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_30),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

OAI21xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_30),
.B(n_33),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_29),
.Y(n_41)
);

OAI221xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_38),
.B1(n_29),
.B2(n_18),
.C(n_13),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_16),
.Y(n_44)
);

XNOR2x1_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_13),
.Y(n_45)
);

NOR2x1_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_12),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

OAI22xp5_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_12),
.B1(n_47),
.B2(n_42),
.Y(n_50)
);

AOI21xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_12),
.B(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_12),
.B1(n_48),
.B2(n_51),
.Y(n_53)
);


endmodule