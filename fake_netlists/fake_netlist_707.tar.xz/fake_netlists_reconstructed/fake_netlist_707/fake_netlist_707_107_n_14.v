module fake_netlist_707_107_n_14 (n_4, n_2, n_3, n_1, n_0, n_14);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_14;

wire n_9;
wire n_7;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_2),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

BUFx12f_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AO221x1_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.C(n_0),
.Y(n_10)
);

OAI31xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.A3(n_1),
.B(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND3x1_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.C(n_2),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B(n_3),
.Y(n_14)
);


endmodule