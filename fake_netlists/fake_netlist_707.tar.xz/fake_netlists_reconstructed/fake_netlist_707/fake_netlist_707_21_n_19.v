module fake_netlist_707_21_n_19 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_19);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_19;

wire n_17;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_13;
wire n_14;
wire n_12;

AND2x4_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_10),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_5),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_8),
.Y(n_13)
);

OA21x2_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_2),
.B(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI32xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.A3(n_11),
.B1(n_12),
.B2(n_7),
.Y(n_16)
);

AO22x2_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_9),
.B1(n_4),
.B2(n_3),
.Y(n_17)
);

INVxp67_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);


endmodule