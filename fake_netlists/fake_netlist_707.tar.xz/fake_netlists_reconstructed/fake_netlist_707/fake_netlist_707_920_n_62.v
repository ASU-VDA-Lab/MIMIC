module fake_netlist_707_920_n_62 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_62);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_62;

wire n_54;
wire n_24;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_15;
wire n_20;
wire n_58;
wire n_35;
wire n_34;
wire n_52;
wire n_16;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_19;
wire n_39;
wire n_14;
wire n_55;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

CKINVDCx16_ASAP7_75t_R g16 ( 
.A(n_13),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_7),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_10),
.B(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_18),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_16),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_17),
.B(n_0),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_17),
.B(n_0),
.Y(n_31)
);

OAI21x1_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_21),
.B(n_20),
.Y(n_32)
);

NAND2x1p5_ASAP7_75t_L g33 ( 
.A(n_28),
.B(n_22),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_SL g35 ( 
.A1(n_27),
.A2(n_22),
.B1(n_23),
.B2(n_19),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_33),
.B(n_29),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_33),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_33),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_36),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_35),
.B1(n_36),
.B2(n_31),
.Y(n_43)
);

NOR2x1_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_37),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_40),
.B(n_37),
.Y(n_46)
);

OAI22xp33_ASAP7_75t_SL g47 ( 
.A1(n_46),
.A2(n_41),
.B1(n_14),
.B2(n_30),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

OR2x6_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_26),
.Y(n_49)
);

OAI22xp33_ASAP7_75t_L g50 ( 
.A1(n_43),
.A2(n_38),
.B1(n_26),
.B2(n_14),
.Y(n_50)
);

AOI21xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_38),
.B(n_32),
.Y(n_51)
);

OAI221xp5_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_38),
.B1(n_15),
.B2(n_25),
.C(n_34),
.Y(n_52)
);

BUFx6f_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

OAI211xp5_ASAP7_75t_L g54 ( 
.A1(n_47),
.A2(n_15),
.B(n_25),
.C(n_38),
.Y(n_54)
);

AOI22xp5_ASAP7_75t_L g55 ( 
.A1(n_49),
.A2(n_15),
.B1(n_25),
.B2(n_34),
.Y(n_55)
);

OAI221xp5_ASAP7_75t_SL g56 ( 
.A1(n_54),
.A2(n_15),
.B1(n_6),
.B2(n_1),
.C(n_5),
.Y(n_56)
);

O2A1O1Ixp5_ASAP7_75t_SL g57 ( 
.A1(n_51),
.A2(n_25),
.B(n_3),
.C(n_2),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_58),
.Y(n_59)
);

OAI21xp5_ASAP7_75t_L g60 ( 
.A1(n_56),
.A2(n_55),
.B(n_52),
.Y(n_60)
);

OAI22xp5_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_57),
.B1(n_6),
.B2(n_8),
.Y(n_61)
);

AOI22xp33_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_59),
.B1(n_60),
.B2(n_15),
.Y(n_62)
);


endmodule