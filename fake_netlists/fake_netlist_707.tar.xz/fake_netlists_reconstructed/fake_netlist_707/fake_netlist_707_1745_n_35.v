module fake_netlist_707_1745_n_35 (n_4, n_2, n_3, n_1, n_5, n_0, n_35);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_35;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_6;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_34;
wire n_16;
wire n_26;
wire n_7;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_8;
wire n_32;
wire n_28;
wire n_11;
wire n_19;
wire n_30;
wire n_25;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_3),
.B(n_4),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_5),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_0),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_0),
.B(n_3),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.Y(n_15)
);

INVx4_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_SL g17 ( 
.A(n_14),
.B(n_9),
.C(n_7),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

NAND2x1p5_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_12),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_9),
.Y(n_20)
);

NAND2xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_15),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_10),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_18),
.B1(n_20),
.B2(n_17),
.C(n_19),
.Y(n_24)
);

NOR2xp67_ASAP7_75t_SL g25 ( 
.A(n_21),
.B(n_10),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_8),
.C(n_17),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_19),
.B(n_23),
.Y(n_27)
);

O2A1O1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_19),
.B(n_21),
.C(n_25),
.Y(n_28)
);

AOI211xp5_ASAP7_75t_L g29 ( 
.A1(n_25),
.A2(n_19),
.B(n_3),
.C(n_1),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_27),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_28),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_30),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_4),
.B1(n_5),
.B2(n_32),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_R g35 ( 
.A1(n_33),
.A2(n_4),
.B1(n_5),
.B2(n_32),
.C(n_34),
.Y(n_35)
);


endmodule