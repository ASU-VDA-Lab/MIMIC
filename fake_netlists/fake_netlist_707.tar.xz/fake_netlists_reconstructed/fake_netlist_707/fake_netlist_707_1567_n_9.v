module fake_netlist_707_1567_n_9 (n_0, n_1, n_9);

input n_0;
input n_1;

output n_9;

wire n_4;
wire n_2;
wire n_7;
wire n_3;
wire n_8;
wire n_5;
wire n_6;

INVx1_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVxp67_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_5),
.B(n_2),
.Y(n_6)
);

AOI221xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.C(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_9)
);


endmodule