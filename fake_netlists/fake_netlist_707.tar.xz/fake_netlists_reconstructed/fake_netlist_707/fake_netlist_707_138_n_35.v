module fake_netlist_707_138_n_35 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_35);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_35;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_34;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_12;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_0),
.B(n_2),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

NOR2xp67_ASAP7_75t_L g16 ( 
.A(n_8),
.B(n_6),
.Y(n_16)
);

OR2x6_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_16),
.Y(n_17)
);

BUFx2_ASAP7_75t_SL g18 ( 
.A(n_13),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_4),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_9),
.B(n_3),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_11),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_14),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_18),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_22),
.Y(n_28)
);

O2A1O1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_17),
.B(n_23),
.C(n_21),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_24),
.B1(n_20),
.B2(n_12),
.C(n_7),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_29),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_27),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_20),
.C(n_24),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_24),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_R g35 ( 
.A1(n_34),
.A2(n_33),
.B1(n_7),
.B2(n_24),
.Y(n_35)
);


endmodule