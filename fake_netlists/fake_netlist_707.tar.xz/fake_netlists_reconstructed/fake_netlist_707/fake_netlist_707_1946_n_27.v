module fake_netlist_707_1946_n_27 (n_9, n_4, n_2, n_7, n_14, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_25;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_3),
.B(n_9),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

BUFx10_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

BUFx4f_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx2_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_19),
.Y(n_23)
);

AOI222xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_19),
.B1(n_18),
.B2(n_15),
.C1(n_16),
.C2(n_13),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OAI22x1_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_14),
.B1(n_1),
.B2(n_0),
.Y(n_26)
);

OAI321xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_6),
.A3(n_4),
.B1(n_10),
.B2(n_12),
.C(n_11),
.Y(n_27)
);


endmodule