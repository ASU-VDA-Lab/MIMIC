module fake_netlist_707_790_n_14 (n_4, n_2, n_3, n_1, n_0, n_14);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_14;

wire n_9;
wire n_7;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_1),
.Y(n_6)
);

NOR4xp25_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_2),
.C(n_1),
.D(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_0),
.Y(n_9)
);

AOI21xp33_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_3),
.Y(n_10)
);

NOR2x1_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx4_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OR2x6_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_4),
.Y(n_14)
);


endmodule