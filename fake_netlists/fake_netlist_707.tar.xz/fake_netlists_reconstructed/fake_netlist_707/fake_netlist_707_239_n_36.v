module fake_netlist_707_239_n_36 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_36);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_36;

wire n_24;
wire n_21;
wire n_27;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_31;
wire n_23;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_8),
.B(n_1),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_7),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_11),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_3),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_16),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_21),
.A2(n_16),
.B1(n_2),
.B2(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

O2A1O1Ixp33_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_25),
.B(n_18),
.C(n_24),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_19),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_27),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_29),
.Y(n_32)
);

OAI211xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_23),
.B(n_22),
.C(n_4),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_R g34 ( 
.A(n_33),
.B(n_9),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_14),
.B1(n_13),
.B2(n_10),
.Y(n_35)
);

NAND2x1p5_ASAP7_75t_SL g36 ( 
.A(n_35),
.B(n_15),
.Y(n_36)
);


endmodule