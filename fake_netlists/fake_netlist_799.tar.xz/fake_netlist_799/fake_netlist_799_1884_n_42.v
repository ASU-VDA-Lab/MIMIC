module fake_netlist_799_1884_n_42 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_3, n_14, n_42);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_3;
input n_14;

output n_42;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_26;
wire n_24;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_41;
wire n_32;
wire n_22;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_9),
.B(n_5),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_1),
.B(n_7),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

XOR2xp5_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_4),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_19),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_21),
.B1(n_22),
.B2(n_20),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_26),
.A2(n_22),
.B1(n_20),
.B2(n_19),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AOI32xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_28),
.A3(n_27),
.B1(n_25),
.B2(n_18),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_9),
.B1(n_12),
.B2(n_17),
.Y(n_36)
);

XNOR2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_35),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_11),
.Y(n_38)
);

CKINVDCx20_ASAP7_75t_R g39 ( 
.A(n_38),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_8),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AOI322xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_40),
.A3(n_6),
.B1(n_16),
.B2(n_3),
.C1(n_2),
.C2(n_0),
.Y(n_42)
);


endmodule