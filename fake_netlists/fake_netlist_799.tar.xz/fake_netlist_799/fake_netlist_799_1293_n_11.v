module fake_netlist_799_1293_n_11 (n_1, n_2, n_3, n_0, n_11);

input n_1;
input n_2;
input n_3;
input n_0;

output n_11;

wire n_7;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_4;
wire n_8;

BUFx3_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_4),
.B(n_5),
.C(n_3),
.Y(n_9)
);

OAI22x1_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_R g11 ( 
.A1(n_10),
.A2(n_0),
.B1(n_1),
.B2(n_5),
.Y(n_11)
);


endmodule