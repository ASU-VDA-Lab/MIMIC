module fake_netlist_799_522_n_28 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_4, n_8, n_28);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_4;
input n_8;

output n_28;

wire n_20;
wire n_17;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_16),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_12),
.B(n_11),
.Y(n_20)
);

NAND3xp33_ASAP7_75t_SL g21 ( 
.A(n_19),
.B(n_16),
.C(n_18),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_15),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_15),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_21),
.B1(n_22),
.B2(n_14),
.Y(n_24)
);

NOR4xp25_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.C(n_17),
.D(n_2),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_3),
.C(n_5),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_3),
.B1(n_5),
.B2(n_0),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_7),
.B1(n_9),
.B2(n_10),
.Y(n_28)
);


endmodule