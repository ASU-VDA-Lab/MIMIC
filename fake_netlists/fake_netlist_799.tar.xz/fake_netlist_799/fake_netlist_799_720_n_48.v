module fake_netlist_799_720_n_48 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_14, n_48);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_14;

output n_48;

wire n_37;
wire n_45;
wire n_44;
wire n_47;
wire n_36;
wire n_29;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_43;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_41;
wire n_32;
wire n_22;

AND2x2_ASAP7_75t_L g22 ( 
.A(n_4),
.B(n_11),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_6),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_L g24 ( 
.A(n_3),
.B(n_5),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_12),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_11),
.B(n_1),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_15),
.B(n_10),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_14),
.B(n_20),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_19),
.Y(n_30)
);

OAI21xp5_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_19),
.B(n_17),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_25),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_30),
.C(n_22),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_23),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_32),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_26),
.Y(n_37)
);

INVx4_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_35),
.B(n_36),
.C(n_23),
.Y(n_39)
);

OAI322xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_36),
.A3(n_22),
.B1(n_26),
.B2(n_29),
.C1(n_28),
.C2(n_35),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_35),
.B1(n_23),
.B2(n_24),
.C(n_21),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_35),
.B1(n_24),
.B2(n_20),
.C(n_18),
.Y(n_42)
);

AOI211xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_35),
.B(n_18),
.C(n_9),
.Y(n_43)
);

BUFx3_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AO22x2_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_35),
.B1(n_8),
.B2(n_0),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_13),
.B1(n_16),
.B2(n_2),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_7),
.B1(n_45),
.B2(n_44),
.Y(n_48)
);


endmodule