module fake_netlist_799_1411_n_7 (n_1, n_2, n_0, n_7);

input n_1;
input n_2;
input n_0;

output n_7;

wire n_5;
wire n_6;
wire n_3;
wire n_4;

NOR2xp33_ASAP7_75t_R g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

OR2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

OAI211xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B(n_1),
.C(n_2),
.Y(n_5)
);

NOR2xp67_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_0),
.Y(n_6)
);

AOI21xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B(n_2),
.Y(n_7)
);


endmodule