module fake_netlist_799_2469_n_49 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_49);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_49;

wire n_37;
wire n_45;
wire n_44;
wire n_20;
wire n_47;
wire n_29;
wire n_36;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_18;
wire n_48;
wire n_43;
wire n_16;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_41;
wire n_32;
wire n_22;

INVxp67_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_4),
.B(n_1),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_8),
.Y(n_19)
);

OA21x2_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_7),
.B(n_6),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_24),
.B(n_15),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_13),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_18),
.B(n_7),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_27),
.A2(n_22),
.B1(n_23),
.B2(n_20),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_16),
.Y(n_32)
);

OAI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_27),
.B1(n_29),
.B2(n_23),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_26),
.Y(n_34)
);

NOR4xp25_ASAP7_75t_SL g35 ( 
.A(n_30),
.B(n_19),
.C(n_25),
.D(n_20),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_31),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

NAND2xp33_ASAP7_75t_R g38 ( 
.A(n_35),
.B(n_20),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_33),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_15),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_39),
.B(n_17),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_40),
.C(n_18),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_39),
.B(n_35),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_20),
.B(n_38),
.Y(n_45)
);

NAND3xp33_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_18),
.C(n_11),
.Y(n_46)
);

INVx1_ASAP7_75t_SL g47 ( 
.A(n_44),
.Y(n_47)
);

NOR3xp33_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_18),
.C(n_12),
.Y(n_48)
);

AOI322xp5_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_47),
.A3(n_12),
.B1(n_45),
.B2(n_10),
.C1(n_3),
.C2(n_9),
.Y(n_49)
);


endmodule