module fake_netlist_799_1864_n_33 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_33);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_33;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_25;
wire n_31;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_10;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_8),
.Y(n_14)
);

INVx5_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_1),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_15),
.A2(n_11),
.B1(n_13),
.B2(n_10),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_SL g19 ( 
.A1(n_17),
.A2(n_11),
.B(n_10),
.C(n_13),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_19),
.B(n_15),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_15),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AND2x4_ASAP7_75t_SL g23 ( 
.A(n_20),
.B(n_16),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_13),
.B(n_15),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_25),
.B1(n_13),
.B2(n_23),
.C(n_14),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_SL g27 ( 
.A1(n_24),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.C(n_2),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_26),
.Y(n_29)
);

INVxp67_ASAP7_75t_SL g30 ( 
.A(n_27),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_29),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_R g32 ( 
.A1(n_28),
.A2(n_3),
.B1(n_0),
.B2(n_2),
.Y(n_32)
);

AOI322xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_5),
.A3(n_6),
.B1(n_13),
.B2(n_28),
.C1(n_30),
.C2(n_32),
.Y(n_33)
);


endmodule