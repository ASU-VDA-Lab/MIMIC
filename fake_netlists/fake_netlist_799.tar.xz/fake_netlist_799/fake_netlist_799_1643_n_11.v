module fake_netlist_799_1643_n_11 (n_1, n_2, n_0, n_11);

input n_1;
input n_2;
input n_0;

output n_11;

wire n_7;
wire n_10;
wire n_5;
wire n_6;
wire n_3;
wire n_9;
wire n_4;
wire n_8;

BUFx10_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx5_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AND2x4_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

NAND4xp25_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.C(n_5),
.D(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI22xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_5),
.B1(n_6),
.B2(n_2),
.Y(n_11)
);


endmodule