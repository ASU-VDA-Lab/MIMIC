module fake_netlist_799_42_n_29 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_29);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_29;

wire n_20;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_28;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_7),
.B(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_6),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_2),
.B(n_1),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_5),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_5),
.Y(n_15)
);

AND2x6_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_11),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_SL g17 ( 
.A1(n_14),
.A2(n_10),
.B1(n_13),
.B2(n_4),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_16),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_20),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_18),
.B1(n_15),
.B2(n_17),
.C(n_2),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_10),
.B1(n_4),
.B2(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_R g28 ( 
.A(n_25),
.B(n_10),
.Y(n_28)
);

AOI222xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_0),
.B1(n_3),
.B2(n_9),
.C1(n_28),
.C2(n_24),
.Y(n_29)
);


endmodule