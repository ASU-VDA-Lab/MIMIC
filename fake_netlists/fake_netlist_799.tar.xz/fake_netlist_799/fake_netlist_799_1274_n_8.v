module fake_netlist_799_1274_n_8 (n_1, n_2, n_0, n_8);

input n_1;
input n_2;
input n_0;

output n_8;

wire n_7;
wire n_5;
wire n_6;
wire n_3;
wire n_4;

NOR2x1p5_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

AOI22xp33_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);


endmodule