module fake_netlist_799_1650_n_28 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_4, n_8, n_28);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_4;
input n_8;

output n_28;

wire n_20;
wire n_17;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_1),
.B(n_4),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_15),
.B(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_18),
.Y(n_20)
);

INVxp33_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NAND4xp25_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_13),
.C(n_14),
.D(n_16),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_24),
.B(n_20),
.Y(n_25)
);

OAI221xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_21),
.B1(n_17),
.B2(n_0),
.C(n_11),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI322xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_8),
.A3(n_10),
.B1(n_2),
.B2(n_7),
.C1(n_3),
.C2(n_9),
.Y(n_28)
);


endmodule