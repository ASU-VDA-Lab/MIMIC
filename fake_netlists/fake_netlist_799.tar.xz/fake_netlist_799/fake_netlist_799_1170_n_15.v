module fake_netlist_799_1170_n_15 (n_1, n_2, n_3, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_0;

output n_15;

wire n_7;
wire n_10;
wire n_13;
wire n_11;
wire n_5;
wire n_6;
wire n_8;
wire n_12;
wire n_14;
wire n_4;
wire n_9;

BUFx4f_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AOI21xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AO21x2_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_7),
.B(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_1),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_8),
.B(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NOR3xp33_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_1),
.C(n_0),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_0),
.B1(n_3),
.B2(n_8),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);


endmodule