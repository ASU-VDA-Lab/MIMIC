module fake_netlist_799_586_n_13 (n_1, n_2, n_3, n_0, n_13);

input n_1;
input n_2;
input n_3;
input n_0;

output n_13;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_8;
wire n_12;
wire n_4;
wire n_9;

BUFx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

BUFx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

NAND5xp2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.C(n_2),
.D(n_0),
.E(n_1),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_8),
.C(n_4),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

OR2x6_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_2),
.Y(n_13)
);


endmodule