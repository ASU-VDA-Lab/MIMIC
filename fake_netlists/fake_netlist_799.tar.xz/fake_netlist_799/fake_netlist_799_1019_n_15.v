module fake_netlist_799_1019_n_15 (n_1, n_2, n_3, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_0;

output n_15;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_14;
wire n_9;
wire n_12;
wire n_13;
wire n_4;
wire n_8;

INVx4_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_2),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVxp67_ASAP7_75t_SL g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_5),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_5),
.B1(n_1),
.B2(n_3),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_1),
.Y(n_13)
);

XNOR2xp5_ASAP7_75t_SL g14 ( 
.A(n_12),
.B(n_13),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);


endmodule