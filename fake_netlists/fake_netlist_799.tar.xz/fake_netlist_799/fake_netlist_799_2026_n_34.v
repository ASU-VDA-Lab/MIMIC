module fake_netlist_799_2026_n_34 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_34);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_34;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_31;
wire n_27;
wire n_33;
wire n_26;
wire n_24;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

INVx4_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_13),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_21),
.B1(n_16),
.B2(n_14),
.C(n_17),
.Y(n_25)
);

INVx2_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_24),
.Y(n_28)
);

AOI211xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_24),
.B(n_19),
.C(n_12),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_9),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_5),
.B(n_4),
.C(n_2),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_1),
.B2(n_11),
.Y(n_34)
);


endmodule