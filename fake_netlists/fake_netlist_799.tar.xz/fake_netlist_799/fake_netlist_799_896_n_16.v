module fake_netlist_799_896_n_16 (n_1, n_0, n_3, n_2, n_4, n_16);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_16;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_5;
wire n_6;
wire n_14;
wire n_9;
wire n_12;
wire n_13;
wire n_8;

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx4_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

OA21x2_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_6),
.B(n_3),
.Y(n_7)
);

OA21x2_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_3),
.Y(n_8)
);

OAI33xp33_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_6),
.A3(n_8),
.B1(n_4),
.B2(n_3),
.B3(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B(n_8),
.C(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_4),
.B(n_2),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_2),
.B(n_3),
.C(n_0),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_12),
.B1(n_2),
.B2(n_0),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_0),
.B1(n_1),
.B2(n_14),
.C1(n_5),
.C2(n_9),
.Y(n_16)
);


endmodule