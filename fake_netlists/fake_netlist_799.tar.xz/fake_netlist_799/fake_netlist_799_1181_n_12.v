module fake_netlist_799_1181_n_12 (n_1, n_2, n_3, n_0, n_12);

input n_1;
input n_2;
input n_3;
input n_0;

output n_12;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_9;
wire n_4;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

OAI22xp33_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_2),
.Y(n_8)
);

OAI211xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B(n_5),
.C(n_2),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_0),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_0),
.Y(n_11)
);

OR2x6_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_3),
.Y(n_12)
);


endmodule