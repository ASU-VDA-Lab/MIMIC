module fake_netlist_799_1873_n_50 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_50);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_50;

wire n_37;
wire n_45;
wire n_44;
wire n_47;
wire n_36;
wire n_29;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_49;
wire n_43;
wire n_48;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_41;
wire n_32;

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_17),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_18),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_4),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_6),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_7),
.B(n_22),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_23),
.A2(n_11),
.B1(n_20),
.B2(n_21),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_23),
.B1(n_27),
.B2(n_35),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_31),
.B(n_25),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_35),
.Y(n_38)
);

AOI221xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_24),
.B1(n_30),
.B2(n_27),
.C(n_32),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_30),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND4xp75_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_29),
.C(n_11),
.D(n_27),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_35),
.Y(n_44)
);

OAI222xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_28),
.B1(n_35),
.B2(n_37),
.C1(n_14),
.C2(n_13),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_44),
.Y(n_46)
);

OAI211xp5_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_19),
.B(n_8),
.C(n_5),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_1),
.Y(n_49)
);

AOI322xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_0),
.A3(n_2),
.B1(n_3),
.B2(n_9),
.C1(n_10),
.C2(n_48),
.Y(n_50)
);


endmodule