module fake_netlist_790_108_n_68 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_68);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_68;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_64;
wire n_52;
wire n_29;
wire n_36;
wire n_63;
wire n_62;
wire n_65;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_66;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_48;
wire n_43;
wire n_49;
wire n_56;
wire n_67;
wire n_38;
wire n_54;
wire n_61;
wire n_60;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_59;
wire n_53;
wire n_41;
wire n_51;
wire n_32;
wire n_47;

AND2x2_ASAP7_75t_SL g23 ( 
.A(n_0),
.B(n_21),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_15),
.A2(n_1),
.B1(n_13),
.B2(n_21),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_11),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_9),
.B(n_7),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_16),
.A2(n_18),
.B1(n_22),
.B2(n_20),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_17),
.B(n_6),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_17),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_SL g34 ( 
.A(n_26),
.B(n_13),
.C(n_12),
.Y(n_34)
);

CKINVDCx11_ASAP7_75t_R g35 ( 
.A(n_33),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_30),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_25),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_29),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_25),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

OAI21x1_ASAP7_75t_L g44 ( 
.A1(n_38),
.A2(n_32),
.B(n_24),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

OR2x6_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_36),
.Y(n_47)
);

AO21x2_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_34),
.B(n_28),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_41),
.Y(n_49)
);

OR2x2_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_35),
.Y(n_50)
);

AOI21xp33_ASAP7_75t_SL g51 ( 
.A1(n_48),
.A2(n_23),
.B(n_31),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

OAI31xp33_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_46),
.A3(n_33),
.B(n_47),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_47),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_47),
.Y(n_55)
);

AOI21xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_48),
.B(n_40),
.Y(n_56)
);

AOI221x1_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_25),
.B1(n_35),
.B2(n_12),
.C(n_14),
.Y(n_57)
);

O2A1O1Ixp33_ASAP7_75t_L g58 ( 
.A1(n_53),
.A2(n_25),
.B(n_27),
.C(n_14),
.Y(n_58)
);

AOI21xp5_ASAP7_75t_L g59 ( 
.A1(n_54),
.A2(n_52),
.B(n_53),
.Y(n_59)
);

HB1xp67_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

HB1xp67_ASAP7_75t_L g61 ( 
.A(n_59),
.Y(n_61)
);

NOR3x1_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_52),
.C(n_15),
.Y(n_62)
);

AND2x4_ASAP7_75t_L g63 ( 
.A(n_56),
.B(n_25),
.Y(n_63)
);

XOR2xp5_ASAP7_75t_L g64 ( 
.A(n_60),
.B(n_2),
.Y(n_64)
);

NAND2xp5_ASAP7_75t_L g65 ( 
.A(n_62),
.B(n_3),
.Y(n_65)
);

OR3x1_ASAP7_75t_L g66 ( 
.A(n_61),
.B(n_5),
.C(n_4),
.Y(n_66)
);

OAI22x1_ASAP7_75t_L g67 ( 
.A1(n_64),
.A2(n_63),
.B1(n_10),
.B2(n_8),
.Y(n_67)
);

AOI22xp33_ASAP7_75t_L g68 ( 
.A1(n_67),
.A2(n_66),
.B1(n_64),
.B2(n_65),
.Y(n_68)
);


endmodule