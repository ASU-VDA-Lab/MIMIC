module fake_netlist_790_2755_n_10 (n_1, n_0, n_3, n_2, n_4, n_10);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_10;

wire n_7;
wire n_5;
wire n_6;
wire n_9;
wire n_8;

OAI22xp5_ASAP7_75t_L g5 ( 
.A1(n_1),
.A2(n_4),
.B1(n_0),
.B2(n_3),
.Y(n_5)
);

NOR2x1_ASAP7_75t_SL g6 ( 
.A(n_0),
.B(n_4),
.Y(n_6)
);

O2A1O1Ixp33_ASAP7_75t_L g7 ( 
.A1(n_2),
.A2(n_3),
.B(n_4),
.C(n_1),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_5),
.B1(n_6),
.B2(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule