module fake_netlist_790_903_n_52 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_52);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_52;

wire n_37;
wire n_45;
wire n_44;
wire n_20;
wire n_47;
wire n_29;
wire n_36;
wire n_17;
wire n_50;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_18;
wire n_48;
wire n_43;
wire n_49;
wire n_15;
wire n_16;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;

INVx1_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_7),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_7),
.B(n_6),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_13),
.B(n_8),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_0),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_21),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_4),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

OR2x6_ASAP7_75t_SL g30 ( 
.A(n_27),
.B(n_23),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

A2O1A1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_19),
.B(n_15),
.C(n_16),
.Y(n_32)
);

OAI22xp33_ASAP7_75t_L g33 ( 
.A1(n_26),
.A2(n_17),
.B1(n_15),
.B2(n_20),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_25),
.C(n_29),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_25),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_29),
.Y(n_39)
);

XNOR2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_33),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_34),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_24),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_39),
.Y(n_43)
);

NOR3xp33_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_17),
.C(n_18),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_R g45 ( 
.A(n_42),
.B(n_30),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_41),
.A2(n_24),
.B1(n_16),
.B2(n_5),
.C(n_2),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_45),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

AOI322xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_5),
.A3(n_11),
.B1(n_46),
.B2(n_48),
.C1(n_49),
.C2(n_51),
.Y(n_52)
);


endmodule