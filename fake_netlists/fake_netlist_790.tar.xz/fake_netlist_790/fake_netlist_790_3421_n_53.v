module fake_netlist_790_3421_n_53 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_53);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_53;

wire n_37;
wire n_45;
wire n_44;
wire n_20;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_17;
wire n_50;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_42;
wire n_26;
wire n_18;
wire n_49;
wire n_43;
wire n_48;
wire n_16;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_41;
wire n_21;
wire n_51;
wire n_32;
wire n_22;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_15),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_3),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_14),
.C(n_7),
.Y(n_26)
);

AO21x1_ASAP7_75t_L g27 ( 
.A1(n_20),
.A2(n_1),
.B(n_0),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_0),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_17),
.Y(n_31)
);

CKINVDCx8_ASAP7_75t_R g32 ( 
.A(n_17),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_16),
.B(n_4),
.Y(n_33)
);

OR2x2_ASAP7_75t_SL g34 ( 
.A(n_32),
.B(n_20),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_19),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_33),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_28),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_34),
.B(n_28),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_35),
.Y(n_42)
);

AOI21xp33_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_37),
.B(n_38),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_34),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_38),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_SL g46 ( 
.A(n_42),
.B(n_26),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_35),
.B(n_30),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_18),
.B(n_22),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_43),
.B(n_25),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

NAND4xp25_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_44),
.C(n_21),
.D(n_48),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_SL g52 ( 
.A1(n_50),
.A2(n_23),
.B1(n_8),
.B2(n_6),
.Y(n_52)
);

AOI22xp33_ASAP7_75t_SL g53 ( 
.A1(n_52),
.A2(n_51),
.B1(n_10),
.B2(n_9),
.Y(n_53)
);


endmodule