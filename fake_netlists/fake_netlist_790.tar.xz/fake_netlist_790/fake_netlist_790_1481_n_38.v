module fake_netlist_790_1481_n_38 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_17, n_9, n_2, n_12, n_13, n_4, n_8, n_38);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_17;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_38;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_26;
wire n_24;
wire n_18;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_2),
.B(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_1),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_4),
.A2(n_1),
.B1(n_0),
.B2(n_13),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_3),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

O2A1O1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_19),
.A2(n_5),
.B(n_3),
.C(n_0),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_19),
.A2(n_11),
.B1(n_10),
.B2(n_5),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_8),
.B(n_7),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_21),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_SL g29 ( 
.A1(n_26),
.A2(n_22),
.B1(n_24),
.B2(n_20),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_18),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_R g31 ( 
.A1(n_30),
.A2(n_21),
.B(n_28),
.C(n_25),
.Y(n_31)
);

NOR4xp25_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_30),
.C(n_18),
.D(n_29),
.Y(n_32)
);

OAI211xp5_ASAP7_75t_SL g33 ( 
.A1(n_31),
.A2(n_16),
.B(n_11),
.C(n_10),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_32),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_17),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI22x1_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_17),
.B1(n_12),
.B2(n_9),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_14),
.B1(n_15),
.B2(n_37),
.Y(n_38)
);


endmodule