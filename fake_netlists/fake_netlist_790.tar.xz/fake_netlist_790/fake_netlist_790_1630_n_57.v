module fake_netlist_790_1630_n_57 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_57);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_57;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_20;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_17;
wire n_50;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_18;
wire n_48;
wire n_43;
wire n_49;
wire n_15;
wire n_56;
wire n_16;
wire n_38;
wire n_54;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

OA22x2_ASAP7_75t_SL g16 ( 
.A1(n_6),
.A2(n_13),
.B1(n_4),
.B2(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_12),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_4),
.B(n_5),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_0),
.B(n_1),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

O2A1O1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_13),
.B(n_0),
.C(n_3),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

BUFx8_ASAP7_75t_SL g28 ( 
.A(n_18),
.Y(n_28)
);

INVxp67_ASAP7_75t_SL g29 ( 
.A(n_22),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

CKINVDCx12_ASAP7_75t_R g32 ( 
.A(n_28),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_23),
.B(n_22),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_23),
.B(n_19),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_25),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_25),
.B1(n_26),
.B2(n_30),
.Y(n_37)
);

OAI31xp33_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_24),
.A3(n_21),
.B(n_23),
.Y(n_38)
);

OA21x2_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_26),
.B(n_30),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_33),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_35),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_36),
.Y(n_43)
);

INVx2_ASAP7_75t_SL g44 ( 
.A(n_40),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_39),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_38),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_40),
.Y(n_47)
);

AOI222xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_18),
.B1(n_34),
.B2(n_42),
.C1(n_27),
.C2(n_23),
.Y(n_48)
);

NOR2x1_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_42),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_50),
.B(n_47),
.Y(n_51)
);

OAI221xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_16),
.B1(n_30),
.B2(n_27),
.C(n_44),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_27),
.B1(n_20),
.B2(n_44),
.Y(n_55)
);

HB1xp67_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

AOI322xp5_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_8),
.A3(n_10),
.B1(n_27),
.B2(n_32),
.C1(n_55),
.C2(n_56),
.Y(n_57)
);


endmodule