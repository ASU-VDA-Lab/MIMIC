module fake_netlist_790_3519_n_22 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_22);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_22;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_19;
wire n_21;
wire n_14;

NAND2xp33_ASAP7_75t_R g11 ( 
.A(n_5),
.B(n_10),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_1),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_2),
.B(n_0),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_3),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_11),
.B(n_7),
.C(n_6),
.Y(n_20)
);

INVx2_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_8),
.Y(n_22)
);


endmodule