module fake_netlist_790_306_n_56 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_25, n_5, n_24, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_56);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_25;
input n_5;
input n_24;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_56;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_50;
wire n_35;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_42;
wire n_26;
wire n_33;
wire n_48;
wire n_43;
wire n_49;
wire n_38;
wire n_54;
wire n_28;
wire n_30;
wire n_53;
wire n_41;
wire n_51;
wire n_32;

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_3),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_23),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_24),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_13),
.Y(n_31)
);

CKINVDCx16_ASAP7_75t_R g32 ( 
.A(n_22),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_7),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_14),
.Y(n_34)
);

NAND2xp33_ASAP7_75t_SL g35 ( 
.A(n_19),
.B(n_25),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_25),
.Y(n_36)
);

BUFx4f_ASAP7_75t_SL g37 ( 
.A(n_27),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_29),
.B(n_4),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

INVx2_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_28),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_38),
.B1(n_35),
.B2(n_30),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

NAND4xp25_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_42),
.C(n_26),
.D(n_27),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_33),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_34),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

OAI221xp5_ASAP7_75t_R g49 ( 
.A1(n_48),
.A2(n_6),
.B1(n_5),
.B2(n_8),
.C(n_9),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_15),
.B1(n_12),
.B2(n_10),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_50),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_SL g53 ( 
.A(n_51),
.B(n_20),
.C(n_17),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

BUFx2_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

AOI22xp33_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_21),
.B1(n_49),
.B2(n_55),
.Y(n_56)
);


endmodule