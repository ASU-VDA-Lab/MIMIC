module fake_netlist_790_3357_n_26 (n_1, n_0, n_5, n_3, n_2, n_4, n_26);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_26;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_25;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_3),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_10),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_6),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_9),
.B1(n_7),
.B2(n_1),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

OAI22xp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_18)
);

AND2x4_ASAP7_75t_SL g19 ( 
.A(n_16),
.B(n_9),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_20)
);

INVx2_ASAP7_75t_SL g21 ( 
.A(n_19),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_13),
.B1(n_11),
.B2(n_0),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_2),
.B1(n_19),
.B2(n_20),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_2),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_23),
.B(n_24),
.Y(n_26)
);


endmodule