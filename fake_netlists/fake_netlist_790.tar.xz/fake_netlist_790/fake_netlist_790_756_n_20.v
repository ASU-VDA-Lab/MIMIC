module fake_netlist_790_756_n_20 (n_1, n_0, n_5, n_3, n_2, n_4, n_20);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_20;

wire n_6;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_14;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_5),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_4),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_6),
.B1(n_7),
.B2(n_0),
.C(n_1),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_3),
.C(n_2),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_3),
.B1(n_2),
.B2(n_4),
.C(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

O2A1O1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_9),
.B(n_4),
.C(n_2),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_5),
.B1(n_9),
.B2(n_10),
.C(n_12),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_14),
.B1(n_18),
.B2(n_15),
.Y(n_20)
);


endmodule