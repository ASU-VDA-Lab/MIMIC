module fake_netlist_790_2168_n_40 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_14, n_40);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_14;

output n_40;

wire n_37;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_24;
wire n_26;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_32;
wire n_22;

BUFx8_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_5),
.Y(n_23)
);

AND2x2_ASAP7_75t_SL g24 ( 
.A(n_10),
.B(n_16),
.Y(n_24)
);

CKINVDCx8_ASAP7_75t_R g25 ( 
.A(n_6),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

NOR2x1_ASAP7_75t_L g28 ( 
.A(n_18),
.B(n_20),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_19),
.Y(n_29)
);

OAI21x1_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_23),
.B(n_28),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_24),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_27),
.B(n_25),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

A2O1A1Ixp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_22),
.B(n_2),
.C(n_0),
.Y(n_35)
);

NAND4xp75_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_7),
.C(n_4),
.D(n_3),
.Y(n_36)
);

NAND4xp25_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_12),
.C(n_11),
.D(n_8),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

OR2x6_ASAP7_75t_SL g40 ( 
.A(n_39),
.B(n_36),
.Y(n_40)
);


endmodule