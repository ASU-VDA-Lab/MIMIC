module fake_netlist_790_3335_n_97 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_97);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_97;

wire n_37;
wire n_55;
wire n_36;
wire n_63;
wire n_65;
wire n_35;
wire n_25;
wire n_40;
wire n_73;
wire n_42;
wire n_24;
wire n_48;
wire n_43;
wire n_68;
wire n_67;
wire n_54;
wire n_30;
wire n_19;
wire n_59;
wire n_53;
wire n_79;
wire n_74;
wire n_85;
wire n_51;
wire n_89;
wire n_22;
wire n_45;
wire n_83;
wire n_62;
wire n_75;
wire n_31;
wire n_96;
wire n_76;
wire n_15;
wire n_16;
wire n_88;
wire n_84;
wire n_28;
wire n_21;
wire n_90;
wire n_82;
wire n_86;
wire n_64;
wire n_29;
wire n_92;
wire n_91;
wire n_70;
wire n_69;
wire n_71;
wire n_26;
wire n_18;
wire n_49;
wire n_56;
wire n_61;
wire n_78;
wire n_23;
wire n_32;
wire n_47;
wire n_44;
wire n_20;
wire n_52;
wire n_77;
wire n_17;
wire n_50;
wire n_58;
wire n_66;
wire n_94;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_81;
wire n_95;
wire n_38;
wire n_80;
wire n_87;
wire n_60;
wire n_57;
wire n_93;
wire n_41;
wire n_72;

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

BUFx10_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVxp33_ASAP7_75t_SL g19 ( 
.A(n_6),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_5),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_7),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_19),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_19),
.B(n_1),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

OAI21xp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_16),
.B(n_17),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

NOR2xp67_ASAP7_75t_L g34 ( 
.A(n_23),
.B(n_9),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_23),
.B(n_22),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_SL g38 ( 
.A1(n_35),
.A2(n_20),
.B1(n_25),
.B2(n_26),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_34),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_31),
.B(n_24),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_37),
.Y(n_43)
);

NOR4xp25_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_33),
.C(n_30),
.D(n_29),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_38),
.B(n_3),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_39),
.Y(n_46)
);

AOI21xp5_ASAP7_75t_L g47 ( 
.A1(n_40),
.A2(n_32),
.B(n_29),
.Y(n_47)
);

INVx3_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_39),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_43),
.Y(n_51)
);

OAI21x1_ASAP7_75t_L g52 ( 
.A1(n_47),
.A2(n_41),
.B(n_42),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_45),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

AO21x2_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_44),
.B(n_52),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_53),
.Y(n_59)
);

OAI21xp33_ASAP7_75t_L g60 ( 
.A1(n_54),
.A2(n_48),
.B(n_41),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_57),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_56),
.B(n_52),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_59),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_59),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_60),
.B(n_4),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_62),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_63),
.B(n_8),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_64),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_65),
.Y(n_70)
);

AND2x2_ASAP7_75t_L g71 ( 
.A(n_66),
.B(n_10),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_61),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_72),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_67),
.Y(n_74)
);

INVxp67_ASAP7_75t_L g75 ( 
.A(n_68),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_69),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_69),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_70),
.Y(n_78)
);

NOR2xp33_ASAP7_75t_L g79 ( 
.A(n_75),
.B(n_71),
.Y(n_79)
);

NAND2xp5_ASAP7_75t_L g80 ( 
.A(n_73),
.B(n_74),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_76),
.B(n_77),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_78),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_81),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_80),
.Y(n_84)
);

INVxp67_ASAP7_75t_L g85 ( 
.A(n_79),
.Y(n_85)
);

INVxp67_ASAP7_75t_L g86 ( 
.A(n_82),
.Y(n_86)
);

HB1xp67_ASAP7_75t_L g87 ( 
.A(n_86),
.Y(n_87)
);

BUFx2_ASAP7_75t_L g88 ( 
.A(n_86),
.Y(n_88)
);

INVx2_ASAP7_75t_L g89 ( 
.A(n_83),
.Y(n_89)
);

OA21x2_ASAP7_75t_L g90 ( 
.A1(n_88),
.A2(n_85),
.B(n_84),
.Y(n_90)
);

INVx2_ASAP7_75t_SL g91 ( 
.A(n_89),
.Y(n_91)
);

HB1xp67_ASAP7_75t_L g92 ( 
.A(n_87),
.Y(n_92)
);

AND2x4_ASAP7_75t_L g93 ( 
.A(n_92),
.B(n_88),
.Y(n_93)
);

INVx1_ASAP7_75t_L g94 ( 
.A(n_93),
.Y(n_94)
);

AOI21xp5_ASAP7_75t_L g95 ( 
.A1(n_94),
.A2(n_93),
.B(n_92),
.Y(n_95)
);

INVx1_ASAP7_75t_L g96 ( 
.A(n_95),
.Y(n_96)
);

AOI21xp5_ASAP7_75t_L g97 ( 
.A1(n_96),
.A2(n_90),
.B(n_91),
.Y(n_97)
);


endmodule