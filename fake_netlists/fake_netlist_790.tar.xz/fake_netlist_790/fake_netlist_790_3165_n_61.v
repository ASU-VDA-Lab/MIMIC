module fake_netlist_790_3165_n_61 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_25, n_5, n_24, n_26, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_61);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_25;
input n_5;
input n_24;
input n_26;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_61;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_50;
wire n_58;
wire n_35;
wire n_40;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_42;
wire n_33;
wire n_49;
wire n_48;
wire n_43;
wire n_56;
wire n_38;
wire n_54;
wire n_60;
wire n_57;
wire n_28;
wire n_30;
wire n_59;
wire n_53;
wire n_41;
wire n_51;
wire n_32;

INVx3_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_12),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_15),
.B(n_24),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_5),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_3),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_14),
.B(n_8),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_17),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_20),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_25),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_0),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_SL g39 ( 
.A1(n_37),
.A2(n_26),
.B1(n_25),
.B2(n_24),
.Y(n_39)
);

BUFx4f_ASAP7_75t_L g40 ( 
.A(n_27),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_27),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_29),
.A2(n_26),
.B1(n_2),
.B2(n_1),
.Y(n_42)
);

AOI211x1_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_36),
.B(n_35),
.C(n_29),
.Y(n_43)
);

OAI21x1_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_32),
.B(n_31),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_SL g45 ( 
.A1(n_41),
.A2(n_33),
.B1(n_38),
.B2(n_28),
.C(n_31),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_41),
.Y(n_46)
);

INVx3_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_45),
.Y(n_48)
);

BUFx2_ASAP7_75t_SL g49 ( 
.A(n_46),
.Y(n_49)
);

OAI31xp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_43),
.A3(n_32),
.B(n_34),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_39),
.Y(n_51)
);

NOR3xp33_ASAP7_75t_SL g52 ( 
.A(n_50),
.B(n_30),
.C(n_34),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_51),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_51),
.Y(n_54)
);

AOI211xp5_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_55)
);

XNOR2x1_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_49),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_9),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_10),
.Y(n_58)
);

CKINVDCx20_ASAP7_75t_R g59 ( 
.A(n_57),
.Y(n_59)
);

CKINVDCx20_ASAP7_75t_R g60 ( 
.A(n_59),
.Y(n_60)
);

AOI322xp5_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_58),
.A3(n_55),
.B1(n_18),
.B2(n_19),
.C1(n_11),
.C2(n_13),
.Y(n_61)
);


endmodule