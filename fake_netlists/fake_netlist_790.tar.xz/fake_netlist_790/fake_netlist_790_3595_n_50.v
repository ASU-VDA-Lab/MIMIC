module fake_netlist_790_3595_n_50 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_50);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_50;

wire n_37;
wire n_45;
wire n_44;
wire n_47;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_48;
wire n_43;
wire n_49;
wire n_38;
wire n_28;
wire n_30;
wire n_41;
wire n_32;

INVx2_ASAP7_75t_L g24 ( 
.A(n_3),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_1),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_8),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_22),
.B(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_13),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_20),
.B(n_6),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_0),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_32),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

INVx6_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_33),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_31),
.B1(n_30),
.B2(n_27),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_31),
.B1(n_28),
.B2(n_25),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_19),
.Y(n_40)
);

NAND2x1_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_4),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_19),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

AOI211xp5_ASAP7_75t_SL g45 ( 
.A1(n_43),
.A2(n_9),
.B(n_7),
.C(n_5),
.Y(n_45)
);

NOR2xp67_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_10),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_15),
.B1(n_14),
.B2(n_11),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

OR2x6_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_16),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_17),
.B1(n_18),
.B2(n_49),
.Y(n_50)
);


endmodule