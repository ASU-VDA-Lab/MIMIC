module fake_netlist_790_302_n_13 (n_1, n_2, n_3, n_0, n_13);

input n_1;
input n_2;
input n_3;
input n_0;

output n_13;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_9;
wire n_12;
wire n_4;
wire n_8;

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

BUFx6f_ASAP7_75t_SL g5 ( 
.A(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_1),
.B(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_5),
.B1(n_2),
.B2(n_1),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_7),
.B(n_3),
.C(n_2),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);


endmodule