module fake_netlist_690_2831_n_21 (n_4, n_2, n_3, n_1, n_0, n_21);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_21;

wire n_17;
wire n_6;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_5;
wire n_7;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

XOR2xp5_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_4),
.B(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_1),
.B(n_3),
.Y(n_8)
);

AO21x2_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

AO31x2_ASAP7_75t_L g10 ( 
.A1(n_5),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_2),
.B(n_6),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_5),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_11),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_9),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_14),
.C(n_15),
.Y(n_18)
);

NAND4xp75_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_11),
.C(n_16),
.D(n_9),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_9),
.B(n_10),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_10),
.B1(n_13),
.B2(n_14),
.Y(n_21)
);


endmodule