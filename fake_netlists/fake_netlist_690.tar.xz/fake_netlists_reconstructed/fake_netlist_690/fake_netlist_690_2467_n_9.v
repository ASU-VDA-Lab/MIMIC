module fake_netlist_690_2467_n_9 (n_0, n_1, n_9);

input n_0;
input n_1;

output n_9;

wire n_4;
wire n_2;
wire n_7;
wire n_3;
wire n_8;
wire n_5;
wire n_6;

NAND2xp5_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

NOR2xp33_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_1),
.Y(n_5)
);

OAI21xp33_ASAP7_75t_SL g6 ( 
.A1(n_4),
.A2(n_5),
.B(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_SL g7 ( 
.A(n_6),
.Y(n_7)
);

INVx5_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B(n_7),
.Y(n_9)
);


endmodule