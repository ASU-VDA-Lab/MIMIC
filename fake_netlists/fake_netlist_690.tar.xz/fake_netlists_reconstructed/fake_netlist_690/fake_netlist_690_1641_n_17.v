module fake_netlist_690_1641_n_17 (n_4, n_2, n_3, n_1, n_5, n_0, n_17);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_17;

wire n_9;
wire n_7;
wire n_15;
wire n_11;
wire n_13;
wire n_16;
wire n_8;
wire n_10;
wire n_14;
wire n_6;
wire n_12;

INVxp67_ASAP7_75t_SL g6 ( 
.A(n_3),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

CKINVDCx20_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AO22x1_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_6),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_8),
.B2(n_0),
.C(n_1),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_2),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_5),
.B2(n_15),
.C1(n_14),
.C2(n_10),
.Y(n_17)
);


endmodule