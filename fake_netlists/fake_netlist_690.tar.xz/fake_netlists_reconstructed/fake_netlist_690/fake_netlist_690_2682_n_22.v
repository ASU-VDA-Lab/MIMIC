module fake_netlist_690_2682_n_22 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_22);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_22;

wire n_21;
wire n_17;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_11;
wire n_19;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_6),
.B(n_4),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_4),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_SL g16 ( 
.A(n_11),
.B(n_6),
.C(n_5),
.Y(n_16)
);

OAI221xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_16),
.B1(n_12),
.B2(n_13),
.C(n_14),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.C(n_5),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_14),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_3),
.B2(n_1),
.C(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_9),
.B(n_8),
.Y(n_22)
);


endmodule