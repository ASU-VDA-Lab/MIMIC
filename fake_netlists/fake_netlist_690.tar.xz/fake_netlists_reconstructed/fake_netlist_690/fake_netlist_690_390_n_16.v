module fake_netlist_690_390_n_16 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_16);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_16;

wire n_8;
wire n_9;
wire n_15;
wire n_11;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_0),
.B(n_6),
.Y(n_8)
);

NOR3xp33_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_4),
.C(n_2),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_SL g10 ( 
.A(n_3),
.B(n_6),
.C(n_7),
.Y(n_10)
);

CKINVDCx8_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2x1_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_10),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_1),
.B1(n_7),
.B2(n_13),
.C(n_12),
.Y(n_16)
);


endmodule