module fake_netlist_690_1237_n_17 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_17);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_17;

wire n_9;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

AND2x6_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_6),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_1),
.B1(n_7),
.B2(n_3),
.Y(n_11)
);

AOI221x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_4),
.B1(n_1),
.B2(n_5),
.C(n_7),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.C(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_2),
.B1(n_4),
.B2(n_9),
.C(n_13),
.Y(n_17)
);


endmodule