module fake_netlist_690_177_n_20 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_20);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_20;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_13;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

NAND3xp33_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_7),
.C(n_5),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_4),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_4),
.A2(n_8),
.B1(n_1),
.B2(n_7),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_7),
.B(n_6),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_6),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

NAND5xp2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_15),
.C(n_12),
.D(n_6),
.E(n_1),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_17),
.Y(n_19)
);

OAI221xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_18),
.B1(n_5),
.B2(n_2),
.C(n_3),
.Y(n_20)
);


endmodule