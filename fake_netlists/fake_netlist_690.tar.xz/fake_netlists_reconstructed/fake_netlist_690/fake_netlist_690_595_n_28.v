module fake_netlist_690_595_n_28 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_28);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_28;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_12;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

BUFx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_4),
.B(n_1),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

O2A1O1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_16)
);

NAND2xp33_ASAP7_75t_R g17 ( 
.A(n_15),
.B(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_16),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_10),
.Y(n_19)
);

OAI221xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_18),
.B1(n_14),
.B2(n_17),
.C(n_11),
.Y(n_20)
);

AOI31xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_12),
.A3(n_13),
.B(n_14),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OAI31xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_12),
.A3(n_4),
.B(n_0),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

BUFx8_ASAP7_75t_SL g25 ( 
.A(n_23),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_21),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_3),
.B1(n_6),
.B2(n_5),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_7),
.B1(n_25),
.B2(n_26),
.Y(n_28)
);


endmodule