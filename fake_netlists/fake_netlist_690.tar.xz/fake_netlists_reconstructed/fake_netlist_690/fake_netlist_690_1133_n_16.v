module fake_netlist_690_1133_n_16 (n_4, n_2, n_3, n_1, n_5, n_0, n_16);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_16;

wire n_9;
wire n_7;
wire n_15;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_14;
wire n_6;
wire n_12;

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_0),
.Y(n_7)
);

CKINVDCx11_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

O2A1O1Ixp33_ASAP7_75t_SL g10 ( 
.A1(n_7),
.A2(n_4),
.B(n_3),
.C(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.B(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_8),
.Y(n_14)
);

INVxp33_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_5),
.Y(n_16)
);


endmodule