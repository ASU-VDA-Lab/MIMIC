module fake_netlist_690_1999_n_35 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_35);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_35;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_34;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_12;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

OR2x2_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_10),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_4),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_1),
.B(n_5),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_2),
.A2(n_7),
.B(n_3),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

AND2x6_ASAP7_75t_SL g18 ( 
.A(n_14),
.B(n_15),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

AO31x2_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_14),
.A3(n_16),
.B(n_11),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AOI211xp5_ASAP7_75t_SL g22 ( 
.A1(n_20),
.A2(n_17),
.B(n_18),
.C(n_16),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.B(n_13),
.C(n_16),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_20),
.Y(n_25)
);

INVxp67_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

XNOR2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_21),
.Y(n_27)
);

NOR4xp25_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_24),
.C(n_16),
.D(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_24),
.B(n_27),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_28),
.Y(n_31)
);

OA22x2_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_27),
.B1(n_24),
.B2(n_0),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_24),
.B1(n_20),
.B2(n_2),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_20),
.B1(n_4),
.B2(n_3),
.Y(n_34)
);

AOI322xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_6),
.A3(n_7),
.B1(n_8),
.B2(n_9),
.C1(n_30),
.C2(n_33),
.Y(n_35)
);


endmodule