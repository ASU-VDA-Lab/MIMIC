module fake_netlist_690_2542_n_11 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_11);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_11;

wire n_9;
wire n_7;
wire n_8;
wire n_10;

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_0),
.A2(n_4),
.B1(n_2),
.B2(n_6),
.Y(n_7)
);

NAND2x1p5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_3),
.B(n_1),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B1(n_8),
.B2(n_9),
.Y(n_11)
);


endmodule