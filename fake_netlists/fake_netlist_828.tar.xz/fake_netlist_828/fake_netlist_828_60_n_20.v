module fake_netlist_828_60_n_20 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_20);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

INVx1_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_6),
.Y(n_11)
);

AND2x6_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_SL g14 ( 
.A(n_13),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_1),
.Y(n_15)
);

NOR2x1_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_2),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_5),
.C(n_4),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_7),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.C(n_8),
.Y(n_20)
);


endmodule