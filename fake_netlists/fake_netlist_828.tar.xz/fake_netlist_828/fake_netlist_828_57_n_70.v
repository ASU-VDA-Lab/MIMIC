module fake_netlist_828_57_n_70 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_70);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_70;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_68;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_69;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_67;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_9),
.B(n_13),
.Y(n_23)
);

AOI22x1_ASAP7_75t_SL g24 ( 
.A1(n_19),
.A2(n_20),
.B1(n_7),
.B2(n_8),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_5),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_14),
.B(n_10),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_16),
.B(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_1),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_15),
.Y(n_32)
);

OAI21xp5_ASAP7_75t_L g33 ( 
.A1(n_22),
.A2(n_2),
.B(n_0),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_30),
.A2(n_17),
.B1(n_15),
.B2(n_3),
.Y(n_35)
);

AND2x6_ASAP7_75t_SL g36 ( 
.A(n_25),
.B(n_3),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_L g37 ( 
.A1(n_22),
.A2(n_31),
.B(n_23),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_29),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_31),
.B(n_28),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

NAND2x1p5_ASAP7_75t_L g41 ( 
.A(n_35),
.B(n_30),
.Y(n_41)
);

A2O1A1Ixp33_ASAP7_75t_L g42 ( 
.A1(n_34),
.A2(n_30),
.B(n_23),
.C(n_29),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_39),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_41),
.A2(n_30),
.B1(n_38),
.B2(n_29),
.Y(n_46)
);

A2O1A1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_42),
.B(n_33),
.C(n_38),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_42),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_25),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_43),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_32),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_32),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_36),
.Y(n_53)
);

OAI21xp5_ASAP7_75t_L g54 ( 
.A1(n_47),
.A2(n_23),
.B(n_27),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_50),
.B(n_23),
.Y(n_55)
);

NOR2x1_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_50),
.Y(n_56)
);

OR2x2_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_26),
.Y(n_57)
);

INVxp67_ASAP7_75t_SL g58 ( 
.A(n_51),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_51),
.B(n_26),
.Y(n_59)
);

NOR2xp33_ASAP7_75t_SL g60 ( 
.A(n_58),
.B(n_27),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_59),
.B(n_26),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_57),
.Y(n_62)
);

AO22x2_ASAP7_75t_L g63 ( 
.A1(n_55),
.A2(n_24),
.B1(n_28),
.B2(n_17),
.Y(n_63)
);

OR2x2_ASAP7_75t_L g64 ( 
.A(n_55),
.B(n_18),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_62),
.Y(n_65)
);

OAI22xp5_ASAP7_75t_L g66 ( 
.A1(n_64),
.A2(n_56),
.B1(n_24),
.B2(n_20),
.Y(n_66)
);

OAI22x1_ASAP7_75t_L g67 ( 
.A1(n_63),
.A2(n_11),
.B1(n_6),
.B2(n_4),
.Y(n_67)
);

AOI22xp5_ASAP7_75t_L g68 ( 
.A1(n_66),
.A2(n_60),
.B1(n_61),
.B2(n_67),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_65),
.Y(n_69)
);

OR2x4_ASAP7_75t_L g70 ( 
.A(n_69),
.B(n_68),
.Y(n_70)
);


endmodule