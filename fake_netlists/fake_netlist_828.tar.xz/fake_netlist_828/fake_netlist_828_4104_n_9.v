module fake_netlist_828_4104_n_9 (n_2, n_0, n_1, n_9);

input n_2;
input n_0;
input n_1;

output n_9;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_8;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_2),
.B(n_0),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_2),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

INVxp33_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_1),
.B1(n_6),
.B2(n_7),
.Y(n_9)
);


endmodule