module fake_netlist_828_2241_n_17 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_17);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_17;

wire n_15;
wire n_13;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;
wire n_9;

INVx4_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_2),
.A2(n_1),
.B1(n_6),
.B2(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B(n_5),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_12),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_10),
.B2(n_4),
.C(n_7),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_9),
.C(n_4),
.Y(n_15)
);

XOR2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_7),
.Y(n_16)
);

NAND2x1p5_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_12),
.Y(n_17)
);


endmodule