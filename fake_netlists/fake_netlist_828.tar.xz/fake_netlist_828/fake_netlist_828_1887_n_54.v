module fake_netlist_828_1887_n_54 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_54);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_54;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_34;
wire n_53;
wire n_31;
wire n_32;
wire n_26;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_3),
.B(n_10),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_7),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_20),
.A2(n_4),
.B1(n_15),
.B2(n_14),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_23),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_1),
.A2(n_16),
.B1(n_17),
.B2(n_20),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_17),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_18),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_18),
.B(n_21),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_SL g34 ( 
.A(n_32),
.B(n_21),
.C(n_16),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_SL g35 ( 
.A(n_31),
.B(n_23),
.C(n_22),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_25),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_33),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_33),
.B1(n_30),
.B2(n_29),
.C(n_28),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_38),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_37),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_40),
.Y(n_44)
);

INVxp67_ASAP7_75t_SL g45 ( 
.A(n_43),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_41),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_43),
.B(n_44),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_44),
.B1(n_42),
.B2(n_34),
.C(n_35),
.Y(n_48)
);

AOI22x1_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_26),
.B1(n_24),
.B2(n_22),
.Y(n_49)
);

NOR4xp75_ASAP7_75t_SL g50 ( 
.A(n_48),
.B(n_24),
.C(n_2),
.D(n_0),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_26),
.B1(n_6),
.B2(n_5),
.Y(n_51)
);

AOI222xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_11),
.B1(n_9),
.B2(n_12),
.C1(n_19),
.C2(n_13),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_49),
.B1(n_52),
.B2(n_46),
.Y(n_54)
);


endmodule