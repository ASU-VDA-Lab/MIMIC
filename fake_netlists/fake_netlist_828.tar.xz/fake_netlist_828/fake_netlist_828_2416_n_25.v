module fake_netlist_828_2416_n_25 (n_4, n_2, n_3, n_0, n_1, n_25);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_25;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_24;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_1),
.B(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_4),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_7),
.B(n_6),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

AO21x2_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_5),
.B(n_1),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

AOI322xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_10),
.A3(n_11),
.B1(n_2),
.B2(n_3),
.C1(n_13),
.C2(n_12),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_10),
.B(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.Y(n_21)
);

AOI21x1_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_12),
.B(n_13),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_21),
.B1(n_15),
.B2(n_13),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_15),
.B1(n_18),
.B2(n_20),
.Y(n_24)
);

AOI31xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_15),
.A3(n_22),
.B(n_23),
.Y(n_25)
);


endmodule