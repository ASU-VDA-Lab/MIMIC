module fake_netlist_828_977_n_50 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_50);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_50;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_41;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

INVx1_ASAP7_75t_L g24 ( 
.A(n_3),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_4),
.Y(n_25)
);

NAND2xp33_ASAP7_75t_L g26 ( 
.A(n_7),
.B(n_17),
.Y(n_26)
);

XNOR2x2_ASAP7_75t_R g27 ( 
.A(n_16),
.B(n_15),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_21),
.B(n_2),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_1),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_12),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_24),
.B(n_16),
.Y(n_32)
);

OR2x6_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_17),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_18),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_26),
.B1(n_28),
.B2(n_30),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_25),
.B(n_31),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_32),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_36),
.B(n_31),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_18),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_31),
.B1(n_20),
.B2(n_19),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_19),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_31),
.B(n_40),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_42),
.B(n_41),
.Y(n_44)
);

OR5x1_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_22),
.C(n_21),
.D(n_20),
.E(n_0),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_22),
.B1(n_6),
.B2(n_5),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_8),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

AOI222xp33_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_9),
.B1(n_10),
.B2(n_13),
.C1(n_14),
.C2(n_47),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);


endmodule