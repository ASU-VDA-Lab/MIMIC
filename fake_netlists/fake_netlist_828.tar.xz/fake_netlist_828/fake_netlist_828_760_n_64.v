module fake_netlist_828_760_n_64 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_64);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_64;

wire n_48;
wire n_49;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_60;
wire n_31;
wire n_32;
wire n_58;
wire n_43;
wire n_37;
wire n_54;
wire n_42;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_55;
wire n_35;
wire n_52;
wire n_38;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_L g29 ( 
.A(n_18),
.B(n_1),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

OAI21x1_ASAP7_75t_L g31 ( 
.A1(n_15),
.A2(n_11),
.B(n_24),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_3),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_0),
.B(n_17),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_8),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_12),
.Y(n_36)
);

OR2x6_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_24),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_35),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

CKINVDCx6p67_ASAP7_75t_R g41 ( 
.A(n_37),
.Y(n_41)
);

BUFx3_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

BUFx3_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_39),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_38),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_42),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_37),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_43),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

OAI332xp33_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_33),
.A3(n_25),
.B1(n_26),
.B2(n_29),
.B3(n_31),
.C1(n_32),
.C2(n_30),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

AOI21xp33_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_28),
.B(n_30),
.Y(n_53)
);

AO21x1_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_32),
.B(n_30),
.Y(n_54)
);

AOI22xp5_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_32),
.B1(n_25),
.B2(n_4),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_SL g57 ( 
.A1(n_55),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_R g58 ( 
.A(n_53),
.B(n_9),
.Y(n_58)
);

OAI22x1_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_14),
.B1(n_13),
.B2(n_10),
.Y(n_59)
);

HB1xp67_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

AND2x4_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_16),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_60),
.Y(n_62)
);

AOI31xp67_ASAP7_75t_L g63 ( 
.A1(n_61),
.A2(n_23),
.A3(n_21),
.B(n_19),
.Y(n_63)
);

OAI21xp5_ASAP7_75t_L g64 ( 
.A1(n_63),
.A2(n_59),
.B(n_62),
.Y(n_64)
);


endmodule