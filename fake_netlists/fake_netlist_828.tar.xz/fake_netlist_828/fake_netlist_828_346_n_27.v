module fake_netlist_828_346_n_27 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_27);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

INVx5_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_4),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_13),
.B1(n_17),
.B2(n_15),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_14),
.B(n_15),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

INVx3_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

AOI221x1_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_21),
.B1(n_7),
.B2(n_4),
.C(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.C(n_3),
.Y(n_26)
);

OAI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_9),
.B1(n_8),
.B2(n_5),
.Y(n_27)
);


endmodule