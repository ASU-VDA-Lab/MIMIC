module fake_netlist_828_3824_n_43 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_43);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_43;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_12),
.B(n_4),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

INVx5_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_22),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_24),
.B(n_20),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_29),
.B1(n_27),
.B2(n_19),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_1),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_5),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_6),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_7),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_9),
.C(n_8),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_15),
.B1(n_14),
.B2(n_10),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_16),
.B1(n_18),
.B2(n_41),
.Y(n_43)
);


endmodule