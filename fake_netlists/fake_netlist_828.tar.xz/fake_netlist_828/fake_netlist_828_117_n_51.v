module fake_netlist_828_117_n_51 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_51);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_51;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_21),
.B(n_8),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_13),
.Y(n_28)
);

OAI22xp33_ASAP7_75t_L g29 ( 
.A1(n_5),
.A2(n_12),
.B1(n_11),
.B2(n_1),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_7),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_18),
.A2(n_16),
.B1(n_9),
.B2(n_15),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_27),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_16),
.Y(n_33)
);

AND2x2_ASAP7_75t_SL g34 ( 
.A(n_24),
.B(n_0),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_25),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_35),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_30),
.B(n_31),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVxp67_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OAI33xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_29),
.A3(n_37),
.B1(n_32),
.B2(n_34),
.B3(n_33),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_38),
.B1(n_28),
.B2(n_34),
.Y(n_43)
);

AOI322xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_29),
.A3(n_33),
.B1(n_32),
.B2(n_23),
.C1(n_17),
.C2(n_18),
.Y(n_44)
);

AOI322xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_23),
.A3(n_21),
.B1(n_22),
.B2(n_19),
.C1(n_20),
.C2(n_26),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_23),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_23),
.B1(n_26),
.B2(n_19),
.C(n_20),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AOI211xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_22),
.B(n_6),
.C(n_4),
.Y(n_49)
);

OAI21x1_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_14),
.B(n_10),
.Y(n_50)
);

OA21x2_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_49),
.B(n_48),
.Y(n_51)
);


endmodule