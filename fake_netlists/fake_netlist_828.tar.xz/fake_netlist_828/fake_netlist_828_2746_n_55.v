module fake_netlist_828_2746_n_55 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_55);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_55;

wire n_48;
wire n_49;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx2_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_1),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_10),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_3),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_24),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_12),
.B(n_16),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_8),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_21),
.B(n_20),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

NOR3xp33_ASAP7_75t_SL g37 ( 
.A(n_32),
.B(n_2),
.C(n_0),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_30),
.Y(n_38)
);

NOR3xp33_ASAP7_75t_SL g39 ( 
.A(n_34),
.B(n_5),
.C(n_4),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_36),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_31),
.B1(n_28),
.B2(n_27),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_37),
.A2(n_29),
.B1(n_33),
.B2(n_35),
.C(n_6),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

INVx1_ASAP7_75t_SL g47 ( 
.A(n_45),
.Y(n_47)
);

INVx1_ASAP7_75t_SL g48 ( 
.A(n_46),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_41),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_R g50 ( 
.A(n_48),
.B(n_7),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_39),
.B1(n_11),
.B2(n_9),
.Y(n_51)
);

OR3x2_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_14),
.C(n_13),
.Y(n_52)
);

NOR3xp33_ASAP7_75t_SL g53 ( 
.A(n_51),
.B(n_17),
.C(n_15),
.Y(n_53)
);

INVx3_ASAP7_75t_SL g54 ( 
.A(n_52),
.Y(n_54)
);

AOI222xp33_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_53),
.B1(n_25),
.B2(n_22),
.C1(n_26),
.C2(n_23),
.Y(n_55)
);


endmodule