module fake_netlist_828_1093_n_387 (n_25, n_20, n_15, n_13, n_2, n_36, n_17, n_14, n_22, n_41, n_4, n_7, n_23, n_34, n_40, n_28, n_39, n_9, n_31, n_32, n_26, n_24, n_37, n_19, n_42, n_3, n_33, n_12, n_0, n_29, n_6, n_30, n_18, n_10, n_16, n_21, n_5, n_35, n_38, n_11, n_27, n_1, n_8, n_387);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_36;
input n_17;
input n_14;
input n_22;
input n_41;
input n_4;
input n_7;
input n_23;
input n_34;
input n_40;
input n_28;
input n_39;
input n_9;
input n_31;
input n_32;
input n_26;
input n_24;
input n_37;
input n_19;
input n_42;
input n_3;
input n_33;
input n_12;
input n_0;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_35;
input n_38;
input n_11;
input n_27;
input n_1;
input n_8;

output n_387;

wire n_298;
wire n_364;
wire n_114;
wire n_261;
wire n_316;
wire n_166;
wire n_240;
wire n_326;
wire n_154;
wire n_340;
wire n_153;
wire n_195;
wire n_210;
wire n_87;
wire n_95;
wire n_325;
wire n_232;
wire n_63;
wire n_110;
wire n_265;
wire n_61;
wire n_108;
wire n_48;
wire n_163;
wire n_209;
wire n_196;
wire n_353;
wire n_47;
wire n_294;
wire n_202;
wire n_90;
wire n_76;
wire n_299;
wire n_272;
wire n_160;
wire n_338;
wire n_329;
wire n_99;
wire n_366;
wire n_349;
wire n_155;
wire n_361;
wire n_314;
wire n_357;
wire n_52;
wire n_379;
wire n_229;
wire n_51;
wire n_382;
wire n_119;
wire n_312;
wire n_152;
wire n_131;
wire n_133;
wire n_274;
wire n_323;
wire n_223;
wire n_279;
wire n_84;
wire n_303;
wire n_270;
wire n_188;
wire n_343;
wire n_205;
wire n_65;
wire n_247;
wire n_300;
wire n_309;
wire n_378;
wire n_281;
wire n_359;
wire n_365;
wire n_129;
wire n_198;
wire n_201;
wire n_169;
wire n_180;
wire n_220;
wire n_267;
wire n_370;
wire n_208;
wire n_82;
wire n_234;
wire n_165;
wire n_374;
wire n_141;
wire n_305;
wire n_280;
wire n_331;
wire n_221;
wire n_311;
wire n_293;
wire n_156;
wire n_347;
wire n_126;
wire n_296;
wire n_78;
wire n_187;
wire n_96;
wire n_94;
wire n_162;
wire n_135;
wire n_324;
wire n_275;
wire n_362;
wire n_369;
wire n_107;
wire n_301;
wire n_288;
wire n_384;
wire n_178;
wire n_121;
wire n_73;
wire n_211;
wire n_235;
wire n_371;
wire n_246;
wire n_344;
wire n_175;
wire n_185;
wire n_161;
wire n_224;
wire n_179;
wire n_137;
wire n_57;
wire n_226;
wire n_284;
wire n_116;
wire n_128;
wire n_139;
wire n_115;
wire n_339;
wire n_144;
wire n_328;
wire n_283;
wire n_183;
wire n_367;
wire n_345;
wire n_106;
wire n_149;
wire n_237;
wire n_373;
wire n_159;
wire n_91;
wire n_233;
wire n_333;
wire n_204;
wire n_191;
wire n_317;
wire n_181;
wire n_60;
wire n_356;
wire n_260;
wire n_372;
wire n_291;
wire n_186;
wire n_218;
wire n_69;
wire n_212;
wire n_241;
wire n_256;
wire n_134;
wire n_254;
wire n_148;
wire n_245;
wire n_376;
wire n_193;
wire n_49;
wire n_132;
wire n_194;
wire n_219;
wire n_250;
wire n_81;
wire n_273;
wire n_80;
wire n_123;
wire n_290;
wire n_319;
wire n_167;
wire n_122;
wire n_289;
wire n_56;
wire n_59;
wire n_74;
wire n_341;
wire n_79;
wire n_177;
wire n_43;
wire n_244;
wire n_158;
wire n_171;
wire n_259;
wire n_214;
wire n_127;
wire n_295;
wire n_213;
wire n_257;
wire n_72;
wire n_266;
wire n_320;
wire n_249;
wire n_120;
wire n_327;
wire n_145;
wire n_307;
wire n_200;
wire n_377;
wire n_170;
wire n_77;
wire n_383;
wire n_138;
wire n_217;
wire n_253;
wire n_238;
wire n_381;
wire n_322;
wire n_332;
wire n_62;
wire n_44;
wire n_117;
wire n_351;
wire n_104;
wire n_354;
wire n_168;
wire n_360;
wire n_350;
wire n_285;
wire n_310;
wire n_176;
wire n_271;
wire n_330;
wire n_101;
wire n_336;
wire n_242;
wire n_313;
wire n_157;
wire n_83;
wire n_375;
wire n_348;
wire n_334;
wire n_346;
wire n_216;
wire n_150;
wire n_71;
wire n_92;
wire n_100;
wire n_124;
wire n_236;
wire n_206;
wire n_147;
wire n_363;
wire n_268;
wire n_380;
wire n_97;
wire n_182;
wire n_335;
wire n_130;
wire n_239;
wire n_173;
wire n_287;
wire n_318;
wire n_222;
wire n_277;
wire n_263;
wire n_269;
wire n_54;
wire n_304;
wire n_64;
wire n_278;
wire n_264;
wire n_292;
wire n_297;
wire n_184;
wire n_86;
wire n_45;
wire n_192;
wire n_230;
wire n_118;
wire n_189;
wire n_125;
wire n_255;
wire n_151;
wire n_302;
wire n_258;
wire n_207;
wire n_385;
wire n_103;
wire n_227;
wire n_215;
wire n_199;
wire n_143;
wire n_190;
wire n_251;
wire n_352;
wire n_136;
wire n_102;
wire n_89;
wire n_262;
wire n_70;
wire n_172;
wire n_142;
wire n_337;
wire n_109;
wire n_53;
wire n_315;
wire n_58;
wire n_68;
wire n_146;
wire n_248;
wire n_105;
wire n_306;
wire n_355;
wire n_321;
wire n_225;
wire n_358;
wire n_85;
wire n_55;
wire n_164;
wire n_252;
wire n_75;
wire n_140;
wire n_342;
wire n_67;
wire n_66;
wire n_98;
wire n_386;
wire n_286;
wire n_203;
wire n_50;
wire n_112;
wire n_228;
wire n_111;
wire n_93;
wire n_174;
wire n_197;
wire n_88;
wire n_243;
wire n_276;
wire n_113;
wire n_282;
wire n_231;
wire n_368;
wire n_308;
wire n_46;

INVx1_ASAP7_75t_L g43 ( 
.A(n_4),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_3),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_5),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_22),
.Y(n_46)
);

BUFx3_ASAP7_75t_L g47 ( 
.A(n_36),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_41),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_40),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_42),
.Y(n_50)
);

INVxp33_ASAP7_75t_SL g51 ( 
.A(n_33),
.Y(n_51)
);

INVxp33_ASAP7_75t_L g52 ( 
.A(n_0),
.Y(n_52)
);

CKINVDCx20_ASAP7_75t_R g53 ( 
.A(n_4),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_20),
.Y(n_54)
);

NOR2xp67_ASAP7_75t_L g55 ( 
.A(n_39),
.B(n_27),
.Y(n_55)
);

BUFx3_ASAP7_75t_L g56 ( 
.A(n_12),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_1),
.Y(n_57)
);

BUFx6f_ASAP7_75t_L g58 ( 
.A(n_31),
.Y(n_58)
);

INVxp67_ASAP7_75t_SL g59 ( 
.A(n_23),
.Y(n_59)
);

NOR2xp67_ASAP7_75t_L g60 ( 
.A(n_8),
.B(n_30),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_49),
.Y(n_61)
);

CKINVDCx20_ASAP7_75t_R g62 ( 
.A(n_53),
.Y(n_62)
);

NOR2xp67_ASAP7_75t_L g63 ( 
.A(n_46),
.B(n_0),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_56),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_49),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_56),
.Y(n_66)
);

NAND2xp5_ASAP7_75t_L g67 ( 
.A(n_52),
.B(n_46),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_SL g68 ( 
.A(n_58),
.B(n_1),
.Y(n_68)
);

NOR2xp33_ASAP7_75t_L g69 ( 
.A(n_52),
.B(n_2),
.Y(n_69)
);

CKINVDCx20_ASAP7_75t_R g70 ( 
.A(n_53),
.Y(n_70)
);

CKINVDCx20_ASAP7_75t_R g71 ( 
.A(n_48),
.Y(n_71)
);

HB1xp67_ASAP7_75t_L g72 ( 
.A(n_67),
.Y(n_72)
);

INVx5_ASAP7_75t_L g73 ( 
.A(n_61),
.Y(n_73)
);

AND2x4_ASAP7_75t_L g74 ( 
.A(n_63),
.B(n_56),
.Y(n_74)
);

INVx3_ASAP7_75t_L g75 ( 
.A(n_61),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_64),
.B(n_47),
.Y(n_76)
);

NAND2xp5_ASAP7_75t_L g77 ( 
.A(n_64),
.B(n_47),
.Y(n_77)
);

AND2x2_ASAP7_75t_L g78 ( 
.A(n_66),
.B(n_56),
.Y(n_78)
);

INVx2_ASAP7_75t_L g79 ( 
.A(n_61),
.Y(n_79)
);

INVx2_ASAP7_75t_SL g80 ( 
.A(n_66),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_65),
.Y(n_81)
);

INVx4_ASAP7_75t_L g82 ( 
.A(n_65),
.Y(n_82)
);

AOI22xp5_ASAP7_75t_L g83 ( 
.A1(n_69),
.A2(n_48),
.B1(n_51),
.B2(n_43),
.Y(n_83)
);

AOI22xp5_ASAP7_75t_L g84 ( 
.A1(n_63),
.A2(n_51),
.B1(n_44),
.B2(n_43),
.Y(n_84)
);

HB1xp67_ASAP7_75t_L g85 ( 
.A(n_65),
.Y(n_85)
);

INVx3_ASAP7_75t_L g86 ( 
.A(n_68),
.Y(n_86)
);

INVx2_ASAP7_75t_L g87 ( 
.A(n_71),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_62),
.Y(n_88)
);

AND2x2_ASAP7_75t_L g89 ( 
.A(n_70),
.B(n_44),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_61),
.Y(n_90)
);

CKINVDCx5p33_ASAP7_75t_R g91 ( 
.A(n_71),
.Y(n_91)
);

BUFx4f_ASAP7_75t_SL g92 ( 
.A(n_87),
.Y(n_92)
);

NAND2xp5_ASAP7_75t_L g93 ( 
.A(n_72),
.B(n_85),
.Y(n_93)
);

A2O1A1Ixp33_ASAP7_75t_L g94 ( 
.A1(n_79),
.A2(n_54),
.B(n_57),
.C(n_45),
.Y(n_94)
);

INVx4_ASAP7_75t_L g95 ( 
.A(n_82),
.Y(n_95)
);

INVx2_ASAP7_75t_L g96 ( 
.A(n_79),
.Y(n_96)
);

INVx2_ASAP7_75t_SL g97 ( 
.A(n_85),
.Y(n_97)
);

NOR3xp33_ASAP7_75t_SL g98 ( 
.A(n_91),
.B(n_50),
.C(n_59),
.Y(n_98)
);

AND3x2_ASAP7_75t_SL g99 ( 
.A(n_79),
.B(n_49),
.C(n_59),
.Y(n_99)
);

BUFx6f_ASAP7_75t_L g100 ( 
.A(n_73),
.Y(n_100)
);

INVx3_ASAP7_75t_L g101 ( 
.A(n_82),
.Y(n_101)
);

AND2x4_ASAP7_75t_L g102 ( 
.A(n_72),
.B(n_45),
.Y(n_102)
);

BUFx6f_ASAP7_75t_L g103 ( 
.A(n_73),
.Y(n_103)
);

NAND2xp5_ASAP7_75t_L g104 ( 
.A(n_82),
.B(n_50),
.Y(n_104)
);

HB1xp67_ASAP7_75t_L g105 ( 
.A(n_82),
.Y(n_105)
);

BUFx3_ASAP7_75t_L g106 ( 
.A(n_86),
.Y(n_106)
);

AOI22xp5_ASAP7_75t_L g107 ( 
.A1(n_84),
.A2(n_57),
.B1(n_54),
.B2(n_60),
.Y(n_107)
);

INVx3_ASAP7_75t_L g108 ( 
.A(n_82),
.Y(n_108)
);

BUFx2_ASAP7_75t_L g109 ( 
.A(n_89),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_90),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_90),
.Y(n_111)
);

NAND2xp5_ASAP7_75t_L g112 ( 
.A(n_86),
.B(n_49),
.Y(n_112)
);

BUFx6f_ASAP7_75t_L g113 ( 
.A(n_73),
.Y(n_113)
);

AOI21xp5_ASAP7_75t_L g114 ( 
.A1(n_96),
.A2(n_80),
.B(n_76),
.Y(n_114)
);

OAI21xp5_ASAP7_75t_L g115 ( 
.A1(n_96),
.A2(n_80),
.B(n_84),
.Y(n_115)
);

AOI222xp33_ASAP7_75t_L g116 ( 
.A1(n_109),
.A2(n_89),
.B1(n_88),
.B2(n_87),
.C1(n_78),
.C2(n_74),
.Y(n_116)
);

INVxp67_ASAP7_75t_L g117 ( 
.A(n_93),
.Y(n_117)
);

HB1xp67_ASAP7_75t_L g118 ( 
.A(n_97),
.Y(n_118)
);

INVx2_ASAP7_75t_L g119 ( 
.A(n_96),
.Y(n_119)
);

OR2x2_ASAP7_75t_L g120 ( 
.A(n_93),
.B(n_109),
.Y(n_120)
);

BUFx3_ASAP7_75t_L g121 ( 
.A(n_95),
.Y(n_121)
);

OR2x2_ASAP7_75t_L g122 ( 
.A(n_97),
.B(n_89),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_110),
.Y(n_123)
);

BUFx12f_ASAP7_75t_L g124 ( 
.A(n_95),
.Y(n_124)
);

INVx2_ASAP7_75t_L g125 ( 
.A(n_101),
.Y(n_125)
);

OAI22xp33_ASAP7_75t_L g126 ( 
.A1(n_97),
.A2(n_83),
.B1(n_86),
.B2(n_79),
.Y(n_126)
);

A2O1A1Ixp33_ASAP7_75t_L g127 ( 
.A1(n_110),
.A2(n_81),
.B(n_75),
.C(n_78),
.Y(n_127)
);

CKINVDCx5p33_ASAP7_75t_R g128 ( 
.A(n_98),
.Y(n_128)
);

AND2x2_ASAP7_75t_L g129 ( 
.A(n_102),
.B(n_83),
.Y(n_129)
);

CKINVDCx20_ASAP7_75t_R g130 ( 
.A(n_92),
.Y(n_130)
);

INVx2_ASAP7_75t_L g131 ( 
.A(n_119),
.Y(n_131)
);

HB1xp67_ASAP7_75t_L g132 ( 
.A(n_117),
.Y(n_132)
);

CKINVDCx6p67_ASAP7_75t_R g133 ( 
.A(n_124),
.Y(n_133)
);

INVx2_ASAP7_75t_L g134 ( 
.A(n_119),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_123),
.Y(n_135)
);

NAND2xp5_ASAP7_75t_L g136 ( 
.A(n_117),
.B(n_102),
.Y(n_136)
);

OAI21x1_ASAP7_75t_L g137 ( 
.A1(n_114),
.A2(n_112),
.B(n_77),
.Y(n_137)
);

OAI221xp5_ASAP7_75t_L g138 ( 
.A1(n_122),
.A2(n_107),
.B1(n_98),
.B2(n_94),
.C(n_112),
.Y(n_138)
);

AOI22xp33_ASAP7_75t_L g139 ( 
.A1(n_129),
.A2(n_102),
.B1(n_92),
.B2(n_87),
.Y(n_139)
);

INVx1_ASAP7_75t_SL g140 ( 
.A(n_124),
.Y(n_140)
);

OAI22xp5_ASAP7_75t_L g141 ( 
.A1(n_118),
.A2(n_111),
.B1(n_107),
.B2(n_102),
.Y(n_141)
);

BUFx6f_ASAP7_75t_L g142 ( 
.A(n_124),
.Y(n_142)
);

INVxp67_ASAP7_75t_L g143 ( 
.A(n_132),
.Y(n_143)
);

AOI22xp33_ASAP7_75t_L g144 ( 
.A1(n_141),
.A2(n_129),
.B1(n_126),
.B2(n_87),
.Y(n_144)
);

OAI21x1_ASAP7_75t_L g145 ( 
.A1(n_137),
.A2(n_114),
.B(n_123),
.Y(n_145)
);

AND2x2_ASAP7_75t_L g146 ( 
.A(n_136),
.B(n_129),
.Y(n_146)
);

AOI22xp33_ASAP7_75t_SL g147 ( 
.A1(n_141),
.A2(n_130),
.B1(n_122),
.B2(n_120),
.Y(n_147)
);

OAI22xp5_ASAP7_75t_L g148 ( 
.A1(n_136),
.A2(n_120),
.B1(n_118),
.B2(n_126),
.Y(n_148)
);

OAI22xp5_ASAP7_75t_L g149 ( 
.A1(n_135),
.A2(n_120),
.B1(n_122),
.B2(n_127),
.Y(n_149)
);

INVx4_ASAP7_75t_SL g150 ( 
.A(n_142),
.Y(n_150)
);

AOI22xp33_ASAP7_75t_L g151 ( 
.A1(n_138),
.A2(n_116),
.B1(n_88),
.B2(n_128),
.Y(n_151)
);

BUFx3_ASAP7_75t_L g152 ( 
.A(n_142),
.Y(n_152)
);

AOI211xp5_ASAP7_75t_L g153 ( 
.A1(n_138),
.A2(n_115),
.B(n_102),
.C(n_60),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_135),
.Y(n_154)
);

OAI22xp33_ASAP7_75t_L g155 ( 
.A1(n_133),
.A2(n_130),
.B1(n_115),
.B2(n_121),
.Y(n_155)
);

HB1xp67_ASAP7_75t_L g156 ( 
.A(n_143),
.Y(n_156)
);

CKINVDCx5p33_ASAP7_75t_R g157 ( 
.A(n_150),
.Y(n_157)
);

AOI221xp5_ASAP7_75t_L g158 ( 
.A1(n_151),
.A2(n_139),
.B1(n_74),
.B2(n_127),
.C(n_140),
.Y(n_158)
);

AOI22xp33_ASAP7_75t_L g159 ( 
.A1(n_147),
.A2(n_116),
.B1(n_142),
.B2(n_133),
.Y(n_159)
);

NAND2xp5_ASAP7_75t_L g160 ( 
.A(n_146),
.B(n_140),
.Y(n_160)
);

INVx8_ASAP7_75t_L g161 ( 
.A(n_150),
.Y(n_161)
);

NAND2xp5_ASAP7_75t_L g162 ( 
.A(n_146),
.B(n_133),
.Y(n_162)
);

OAI211xp5_ASAP7_75t_L g163 ( 
.A1(n_153),
.A2(n_144),
.B(n_154),
.C(n_55),
.Y(n_163)
);

AOI21xp5_ASAP7_75t_L g164 ( 
.A1(n_148),
.A2(n_134),
.B(n_131),
.Y(n_164)
);

OAI21xp33_ASAP7_75t_L g165 ( 
.A1(n_153),
.A2(n_149),
.B(n_155),
.Y(n_165)
);

AOI221xp5_ASAP7_75t_L g166 ( 
.A1(n_149),
.A2(n_74),
.B1(n_106),
.B2(n_86),
.C(n_111),
.Y(n_166)
);

AOI21xp33_ASAP7_75t_L g167 ( 
.A1(n_154),
.A2(n_74),
.B(n_142),
.Y(n_167)
);

OAI22xp5_ASAP7_75t_L g168 ( 
.A1(n_152),
.A2(n_134),
.B1(n_131),
.B2(n_142),
.Y(n_168)
);

INVx1_ASAP7_75t_L g169 ( 
.A(n_145),
.Y(n_169)
);

NOR4xp25_ASAP7_75t_SL g170 ( 
.A(n_150),
.B(n_99),
.C(n_142),
.D(n_55),
.Y(n_170)
);

HB1xp67_ASAP7_75t_L g171 ( 
.A(n_152),
.Y(n_171)
);

INVx2_ASAP7_75t_L g172 ( 
.A(n_145),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_150),
.Y(n_173)
);

AND2x4_ASAP7_75t_L g174 ( 
.A(n_150),
.B(n_131),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_154),
.Y(n_175)
);

OA21x2_ASAP7_75t_L g176 ( 
.A1(n_145),
.A2(n_137),
.B(n_134),
.Y(n_176)
);

INVx2_ASAP7_75t_L g177 ( 
.A(n_145),
.Y(n_177)
);

NAND2xp5_ASAP7_75t_L g178 ( 
.A(n_175),
.B(n_78),
.Y(n_178)
);

AND2x4_ASAP7_75t_L g179 ( 
.A(n_169),
.B(n_137),
.Y(n_179)
);

OAI31xp33_ASAP7_75t_L g180 ( 
.A1(n_163),
.A2(n_121),
.A3(n_74),
.B(n_47),
.Y(n_180)
);

INVx1_ASAP7_75t_SL g181 ( 
.A(n_174),
.Y(n_181)
);

AND2x2_ASAP7_75t_L g182 ( 
.A(n_176),
.B(n_58),
.Y(n_182)
);

AOI221xp5_ASAP7_75t_SL g183 ( 
.A1(n_165),
.A2(n_58),
.B1(n_99),
.B2(n_104),
.C(n_76),
.Y(n_183)
);

HB1xp67_ASAP7_75t_L g184 ( 
.A(n_176),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_175),
.Y(n_185)
);

NAND2xp5_ASAP7_75t_L g186 ( 
.A(n_165),
.B(n_81),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_176),
.Y(n_187)
);

INVx2_ASAP7_75t_L g188 ( 
.A(n_176),
.Y(n_188)
);

INVx1_ASAP7_75t_L g189 ( 
.A(n_169),
.Y(n_189)
);

AOI221xp5_ASAP7_75t_L g190 ( 
.A1(n_159),
.A2(n_106),
.B1(n_47),
.B2(n_75),
.C(n_104),
.Y(n_190)
);

AND2x2_ASAP7_75t_L g191 ( 
.A(n_172),
.B(n_58),
.Y(n_191)
);

INVx1_ASAP7_75t_L g192 ( 
.A(n_172),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_172),
.B(n_58),
.Y(n_193)
);

AND2x2_ASAP7_75t_L g194 ( 
.A(n_177),
.B(n_58),
.Y(n_194)
);

AO21x2_ASAP7_75t_L g195 ( 
.A1(n_164),
.A2(n_77),
.B(n_119),
.Y(n_195)
);

INVx1_ASAP7_75t_L g196 ( 
.A(n_177),
.Y(n_196)
);

NAND2xp5_ASAP7_75t_L g197 ( 
.A(n_171),
.B(n_81),
.Y(n_197)
);

AND2x2_ASAP7_75t_L g198 ( 
.A(n_177),
.B(n_58),
.Y(n_198)
);

INVx4_ASAP7_75t_L g199 ( 
.A(n_161),
.Y(n_199)
);

INVx1_ASAP7_75t_L g200 ( 
.A(n_173),
.Y(n_200)
);

INVxp67_ASAP7_75t_SL g201 ( 
.A(n_168),
.Y(n_201)
);

AND2x2_ASAP7_75t_L g202 ( 
.A(n_174),
.B(n_58),
.Y(n_202)
);

INVx2_ASAP7_75t_L g203 ( 
.A(n_174),
.Y(n_203)
);

NAND2xp5_ASAP7_75t_L g204 ( 
.A(n_173),
.B(n_81),
.Y(n_204)
);

BUFx2_ASAP7_75t_L g205 ( 
.A(n_174),
.Y(n_205)
);

INVxp67_ASAP7_75t_SL g206 ( 
.A(n_168),
.Y(n_206)
);

INVx1_ASAP7_75t_L g207 ( 
.A(n_161),
.Y(n_207)
);

AND2x2_ASAP7_75t_SL g208 ( 
.A(n_158),
.B(n_99),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_161),
.Y(n_209)
);

AND2x2_ASAP7_75t_L g210 ( 
.A(n_170),
.B(n_75),
.Y(n_210)
);

AND2x2_ASAP7_75t_L g211 ( 
.A(n_170),
.B(n_75),
.Y(n_211)
);

INVx1_ASAP7_75t_SL g212 ( 
.A(n_157),
.Y(n_212)
);

NAND2x1p5_ASAP7_75t_L g213 ( 
.A(n_161),
.B(n_121),
.Y(n_213)
);

AOI33xp33_ASAP7_75t_L g214 ( 
.A1(n_166),
.A2(n_99),
.A3(n_5),
.B1(n_2),
.B2(n_6),
.B3(n_3),
.Y(n_214)
);

OAI31xp33_ASAP7_75t_L g215 ( 
.A1(n_180),
.A2(n_162),
.A3(n_156),
.B(n_160),
.Y(n_215)
);

OR2x2_ASAP7_75t_L g216 ( 
.A(n_185),
.B(n_161),
.Y(n_216)
);

OR2x2_ASAP7_75t_L g217 ( 
.A(n_185),
.B(n_182),
.Y(n_217)
);

OAI21xp33_ASAP7_75t_L g218 ( 
.A1(n_202),
.A2(n_167),
.B(n_75),
.Y(n_218)
);

NAND2xp5_ASAP7_75t_L g219 ( 
.A(n_202),
.B(n_6),
.Y(n_219)
);

NOR3xp33_ASAP7_75t_L g220 ( 
.A(n_202),
.B(n_86),
.C(n_106),
.Y(n_220)
);

NAND2xp5_ASAP7_75t_L g221 ( 
.A(n_200),
.B(n_7),
.Y(n_221)
);

AND2x2_ASAP7_75t_L g222 ( 
.A(n_182),
.B(n_7),
.Y(n_222)
);

INVx1_ASAP7_75t_L g223 ( 
.A(n_189),
.Y(n_223)
);

OAI33xp33_ASAP7_75t_L g224 ( 
.A1(n_200),
.A2(n_9),
.A3(n_8),
.B1(n_10),
.B2(n_12),
.B3(n_11),
.Y(n_224)
);

NAND2xp5_ASAP7_75t_L g225 ( 
.A(n_197),
.B(n_9),
.Y(n_225)
);

NAND2xp5_ASAP7_75t_L g226 ( 
.A(n_197),
.B(n_10),
.Y(n_226)
);

INVx1_ASAP7_75t_L g227 ( 
.A(n_189),
.Y(n_227)
);

INVx1_ASAP7_75t_L g228 ( 
.A(n_187),
.Y(n_228)
);

AND2x4_ASAP7_75t_L g229 ( 
.A(n_203),
.B(n_19),
.Y(n_229)
);

AND2x2_ASAP7_75t_L g230 ( 
.A(n_182),
.B(n_11),
.Y(n_230)
);

NAND2xp5_ASAP7_75t_L g231 ( 
.A(n_208),
.B(n_13),
.Y(n_231)
);

INVx1_ASAP7_75t_L g232 ( 
.A(n_187),
.Y(n_232)
);

OR2x2_ASAP7_75t_L g233 ( 
.A(n_205),
.B(n_13),
.Y(n_233)
);

INVx1_ASAP7_75t_L g234 ( 
.A(n_194),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_194),
.Y(n_235)
);

INVx1_ASAP7_75t_L g236 ( 
.A(n_194),
.Y(n_236)
);

AND2x2_ASAP7_75t_L g237 ( 
.A(n_198),
.B(n_14),
.Y(n_237)
);

NAND3xp33_ASAP7_75t_L g238 ( 
.A(n_180),
.B(n_73),
.C(n_100),
.Y(n_238)
);

INVx1_ASAP7_75t_L g239 ( 
.A(n_198),
.Y(n_239)
);

NAND2xp5_ASAP7_75t_L g240 ( 
.A(n_208),
.B(n_14),
.Y(n_240)
);

AND2x2_ASAP7_75t_L g241 ( 
.A(n_198),
.B(n_193),
.Y(n_241)
);

OAI21xp5_ASAP7_75t_L g242 ( 
.A1(n_183),
.A2(n_73),
.B(n_125),
.Y(n_242)
);

INVx2_ASAP7_75t_L g243 ( 
.A(n_188),
.Y(n_243)
);

NOR3xp33_ASAP7_75t_L g244 ( 
.A(n_214),
.B(n_95),
.C(n_101),
.Y(n_244)
);

AND2x2_ASAP7_75t_L g245 ( 
.A(n_193),
.B(n_15),
.Y(n_245)
);

AND2x2_ASAP7_75t_L g246 ( 
.A(n_193),
.B(n_15),
.Y(n_246)
);

OR2x2_ASAP7_75t_L g247 ( 
.A(n_205),
.B(n_191),
.Y(n_247)
);

OR2x2_ASAP7_75t_L g248 ( 
.A(n_191),
.B(n_181),
.Y(n_248)
);

AND2x2_ASAP7_75t_L g249 ( 
.A(n_191),
.B(n_16),
.Y(n_249)
);

INVx2_ASAP7_75t_L g250 ( 
.A(n_188),
.Y(n_250)
);

INVxp67_ASAP7_75t_SL g251 ( 
.A(n_184),
.Y(n_251)
);

AND2x2_ASAP7_75t_L g252 ( 
.A(n_179),
.B(n_16),
.Y(n_252)
);

AND2x2_ASAP7_75t_L g253 ( 
.A(n_179),
.B(n_17),
.Y(n_253)
);

AND2x2_ASAP7_75t_L g254 ( 
.A(n_179),
.B(n_17),
.Y(n_254)
);

NAND2xp5_ASAP7_75t_L g255 ( 
.A(n_208),
.B(n_18),
.Y(n_255)
);

INVx1_ASAP7_75t_L g256 ( 
.A(n_204),
.Y(n_256)
);

AND2x4_ASAP7_75t_L g257 ( 
.A(n_203),
.B(n_21),
.Y(n_257)
);

INVx1_ASAP7_75t_L g258 ( 
.A(n_204),
.Y(n_258)
);

AND2x2_ASAP7_75t_L g259 ( 
.A(n_179),
.B(n_18),
.Y(n_259)
);

AND2x2_ASAP7_75t_L g260 ( 
.A(n_179),
.B(n_73),
.Y(n_260)
);

INVx1_ASAP7_75t_SL g261 ( 
.A(n_212),
.Y(n_261)
);

OR2x2_ASAP7_75t_L g262 ( 
.A(n_181),
.B(n_125),
.Y(n_262)
);

NAND2xp5_ASAP7_75t_L g263 ( 
.A(n_212),
.B(n_73),
.Y(n_263)
);

INVx2_ASAP7_75t_SL g264 ( 
.A(n_199),
.Y(n_264)
);

INVx1_ASAP7_75t_SL g265 ( 
.A(n_213),
.Y(n_265)
);

INVx1_ASAP7_75t_L g266 ( 
.A(n_223),
.Y(n_266)
);

AOI21xp5_ASAP7_75t_L g267 ( 
.A1(n_218),
.A2(n_210),
.B(n_211),
.Y(n_267)
);

NAND2xp5_ASAP7_75t_L g268 ( 
.A(n_253),
.B(n_184),
.Y(n_268)
);

NAND2xp5_ASAP7_75t_L g269 ( 
.A(n_253),
.B(n_254),
.Y(n_269)
);

INVx1_ASAP7_75t_L g270 ( 
.A(n_223),
.Y(n_270)
);

OR2x2_ASAP7_75t_L g271 ( 
.A(n_247),
.B(n_203),
.Y(n_271)
);

INVxp67_ASAP7_75t_L g272 ( 
.A(n_259),
.Y(n_272)
);

AOI221xp5_ASAP7_75t_L g273 ( 
.A1(n_224),
.A2(n_190),
.B1(n_206),
.B2(n_201),
.C(n_178),
.Y(n_273)
);

NAND3xp33_ASAP7_75t_SL g274 ( 
.A(n_215),
.B(n_261),
.C(n_233),
.Y(n_274)
);

OAI32xp33_ASAP7_75t_L g275 ( 
.A1(n_233),
.A2(n_216),
.A3(n_255),
.B1(n_240),
.B2(n_231),
.Y(n_275)
);

OR2x2_ASAP7_75t_L g276 ( 
.A(n_247),
.B(n_188),
.Y(n_276)
);

NOR2xp33_ASAP7_75t_L g277 ( 
.A(n_219),
.B(n_207),
.Y(n_277)
);

AND2x2_ASAP7_75t_L g278 ( 
.A(n_241),
.B(n_259),
.Y(n_278)
);

AOI221x1_ASAP7_75t_L g279 ( 
.A1(n_221),
.A2(n_186),
.B1(n_209),
.B2(n_207),
.C(n_211),
.Y(n_279)
);

OAI21xp33_ASAP7_75t_L g280 ( 
.A1(n_254),
.A2(n_206),
.B(n_201),
.Y(n_280)
);

OAI21xp33_ASAP7_75t_SL g281 ( 
.A1(n_264),
.A2(n_199),
.B(n_209),
.Y(n_281)
);

OAI22xp5_ASAP7_75t_L g282 ( 
.A1(n_264),
.A2(n_199),
.B1(n_190),
.B2(n_213),
.Y(n_282)
);

AND2x2_ASAP7_75t_L g283 ( 
.A(n_241),
.B(n_199),
.Y(n_283)
);

NOR2xp33_ASAP7_75t_L g284 ( 
.A(n_263),
.B(n_199),
.Y(n_284)
);

OAI22xp5_ASAP7_75t_L g285 ( 
.A1(n_216),
.A2(n_213),
.B1(n_178),
.B2(n_211),
.Y(n_285)
);

INVx2_ASAP7_75t_L g286 ( 
.A(n_243),
.Y(n_286)
);

AOI222xp33_ASAP7_75t_L g287 ( 
.A1(n_222),
.A2(n_186),
.B1(n_196),
.B2(n_192),
.C1(n_210),
.C2(n_183),
.Y(n_287)
);

INVx2_ASAP7_75t_SL g288 ( 
.A(n_265),
.Y(n_288)
);

AOI22xp5_ASAP7_75t_L g289 ( 
.A1(n_220),
.A2(n_210),
.B1(n_213),
.B2(n_192),
.Y(n_289)
);

AOI222xp33_ASAP7_75t_L g290 ( 
.A1(n_222),
.A2(n_230),
.B1(n_237),
.B2(n_249),
.C1(n_246),
.C2(n_245),
.Y(n_290)
);

OR2x2_ASAP7_75t_L g291 ( 
.A(n_217),
.B(n_248),
.Y(n_291)
);

NAND2xp5_ASAP7_75t_L g292 ( 
.A(n_252),
.B(n_196),
.Y(n_292)
);

OR2x6_ASAP7_75t_L g293 ( 
.A(n_252),
.B(n_195),
.Y(n_293)
);

AOI221xp5_ASAP7_75t_L g294 ( 
.A1(n_225),
.A2(n_195),
.B1(n_73),
.B2(n_80),
.C(n_95),
.Y(n_294)
);

OAI322xp33_ASAP7_75t_L g295 ( 
.A1(n_217),
.A2(n_95),
.A3(n_195),
.B1(n_125),
.B2(n_101),
.C1(n_108),
.C2(n_105),
.Y(n_295)
);

OAI22xp33_ASAP7_75t_L g296 ( 
.A1(n_238),
.A2(n_195),
.B1(n_73),
.B2(n_101),
.Y(n_296)
);

AOI221xp5_ASAP7_75t_L g297 ( 
.A1(n_226),
.A2(n_101),
.B1(n_108),
.B2(n_105),
.C(n_100),
.Y(n_297)
);

NAND2xp5_ASAP7_75t_L g298 ( 
.A(n_230),
.B(n_24),
.Y(n_298)
);

AOI32xp33_ASAP7_75t_L g299 ( 
.A1(n_237),
.A2(n_108),
.A3(n_28),
.B1(n_25),
.B2(n_26),
.Y(n_299)
);

INVx1_ASAP7_75t_L g300 ( 
.A(n_227),
.Y(n_300)
);

INVx1_ASAP7_75t_L g301 ( 
.A(n_227),
.Y(n_301)
);

INVxp67_ASAP7_75t_L g302 ( 
.A(n_245),
.Y(n_302)
);

OAI22xp5_ASAP7_75t_L g303 ( 
.A1(n_246),
.A2(n_108),
.B1(n_103),
.B2(n_100),
.Y(n_303)
);

OAI22xp5_ASAP7_75t_L g304 ( 
.A1(n_249),
.A2(n_113),
.B1(n_103),
.B2(n_100),
.Y(n_304)
);

A2O1A1Ixp33_ASAP7_75t_L g305 ( 
.A1(n_244),
.A2(n_113),
.B(n_103),
.C(n_100),
.Y(n_305)
);

OAI211xp5_ASAP7_75t_L g306 ( 
.A1(n_251),
.A2(n_113),
.B(n_103),
.C(n_100),
.Y(n_306)
);

AOI21xp33_ASAP7_75t_L g307 ( 
.A1(n_256),
.A2(n_32),
.B(n_29),
.Y(n_307)
);

NAND2xp5_ASAP7_75t_L g308 ( 
.A(n_258),
.B(n_34),
.Y(n_308)
);

OAI211xp5_ASAP7_75t_L g309 ( 
.A1(n_260),
.A2(n_113),
.B(n_103),
.C(n_100),
.Y(n_309)
);

INVx2_ASAP7_75t_L g310 ( 
.A(n_243),
.Y(n_310)
);

INVx1_ASAP7_75t_L g311 ( 
.A(n_228),
.Y(n_311)
);

AND2x2_ASAP7_75t_L g312 ( 
.A(n_260),
.B(n_35),
.Y(n_312)
);

INVx2_ASAP7_75t_L g313 ( 
.A(n_250),
.Y(n_313)
);

OR2x2_ASAP7_75t_L g314 ( 
.A(n_291),
.B(n_248),
.Y(n_314)
);

HB1xp67_ASAP7_75t_L g315 ( 
.A(n_281),
.Y(n_315)
);

NAND2xp5_ASAP7_75t_L g316 ( 
.A(n_278),
.B(n_302),
.Y(n_316)
);

NAND2xp5_ASAP7_75t_L g317 ( 
.A(n_290),
.B(n_228),
.Y(n_317)
);

XOR2xp5_ASAP7_75t_L g318 ( 
.A(n_274),
.B(n_234),
.Y(n_318)
);

INVx1_ASAP7_75t_L g319 ( 
.A(n_311),
.Y(n_319)
);

INVx1_ASAP7_75t_L g320 ( 
.A(n_266),
.Y(n_320)
);

AND2x2_ASAP7_75t_L g321 ( 
.A(n_293),
.B(n_232),
.Y(n_321)
);

NAND2xp5_ASAP7_75t_L g322 ( 
.A(n_290),
.B(n_232),
.Y(n_322)
);

AND2x2_ASAP7_75t_L g323 ( 
.A(n_293),
.B(n_250),
.Y(n_323)
);

NAND2xp5_ASAP7_75t_L g324 ( 
.A(n_270),
.B(n_300),
.Y(n_324)
);

INVx1_ASAP7_75t_L g325 ( 
.A(n_301),
.Y(n_325)
);

NOR2x1_ASAP7_75t_SL g326 ( 
.A(n_282),
.B(n_235),
.Y(n_326)
);

INVx1_ASAP7_75t_L g327 ( 
.A(n_271),
.Y(n_327)
);

INVx1_ASAP7_75t_L g328 ( 
.A(n_276),
.Y(n_328)
);

INVx1_ASAP7_75t_L g329 ( 
.A(n_292),
.Y(n_329)
);

INVx1_ASAP7_75t_L g330 ( 
.A(n_268),
.Y(n_330)
);

INVx1_ASAP7_75t_L g331 ( 
.A(n_286),
.Y(n_331)
);

INVx1_ASAP7_75t_L g332 ( 
.A(n_310),
.Y(n_332)
);

AOI21xp33_ASAP7_75t_SL g333 ( 
.A1(n_282),
.A2(n_257),
.B(n_229),
.Y(n_333)
);

NAND2xp5_ASAP7_75t_L g334 ( 
.A(n_272),
.B(n_236),
.Y(n_334)
);

XNOR2xp5_ASAP7_75t_L g335 ( 
.A(n_283),
.B(n_269),
.Y(n_335)
);

INVx2_ASAP7_75t_L g336 ( 
.A(n_313),
.Y(n_336)
);

INVx1_ASAP7_75t_L g337 ( 
.A(n_288),
.Y(n_337)
);

INVx1_ASAP7_75t_L g338 ( 
.A(n_295),
.Y(n_338)
);

NAND2xp5_ASAP7_75t_L g339 ( 
.A(n_273),
.B(n_239),
.Y(n_339)
);

INVx2_ASAP7_75t_L g340 ( 
.A(n_293),
.Y(n_340)
);

AOI22xp5_ASAP7_75t_L g341 ( 
.A1(n_280),
.A2(n_257),
.B1(n_229),
.B2(n_262),
.Y(n_341)
);

AOI21xp5_ASAP7_75t_L g342 ( 
.A1(n_306),
.A2(n_257),
.B(n_229),
.Y(n_342)
);

INVx1_ASAP7_75t_L g343 ( 
.A(n_295),
.Y(n_343)
);

NOR2xp33_ASAP7_75t_L g344 ( 
.A(n_275),
.B(n_262),
.Y(n_344)
);

NOR2xp33_ASAP7_75t_L g345 ( 
.A(n_277),
.B(n_242),
.Y(n_345)
);

NAND3xp33_ASAP7_75t_L g346 ( 
.A(n_315),
.B(n_287),
.C(n_279),
.Y(n_346)
);

NAND2xp5_ASAP7_75t_L g347 ( 
.A(n_317),
.B(n_322),
.Y(n_347)
);

INVx2_ASAP7_75t_L g348 ( 
.A(n_336),
.Y(n_348)
);

INVx1_ASAP7_75t_L g349 ( 
.A(n_324),
.Y(n_349)
);

OAI22xp33_ASAP7_75t_SL g350 ( 
.A1(n_339),
.A2(n_285),
.B1(n_289),
.B2(n_284),
.Y(n_350)
);

OAI22xp5_ASAP7_75t_L g351 ( 
.A1(n_318),
.A2(n_305),
.B1(n_267),
.B2(n_299),
.Y(n_351)
);

OR2x2_ASAP7_75t_L g352 ( 
.A(n_314),
.B(n_304),
.Y(n_352)
);

INVx1_ASAP7_75t_L g353 ( 
.A(n_314),
.Y(n_353)
);

HB1xp67_ASAP7_75t_L g354 ( 
.A(n_328),
.Y(n_354)
);

XNOR2x1_ASAP7_75t_L g355 ( 
.A(n_335),
.B(n_312),
.Y(n_355)
);

NAND2xp5_ASAP7_75t_L g356 ( 
.A(n_330),
.B(n_344),
.Y(n_356)
);

XNOR2xp5_ASAP7_75t_L g357 ( 
.A(n_335),
.B(n_298),
.Y(n_357)
);

OAI22xp5_ASAP7_75t_L g358 ( 
.A1(n_318),
.A2(n_309),
.B1(n_303),
.B2(n_296),
.Y(n_358)
);

XOR2x2_ASAP7_75t_L g359 ( 
.A(n_316),
.B(n_297),
.Y(n_359)
);

AND2x2_ASAP7_75t_SL g360 ( 
.A(n_344),
.B(n_294),
.Y(n_360)
);

NAND2xp5_ASAP7_75t_L g361 ( 
.A(n_329),
.B(n_287),
.Y(n_361)
);

INVxp67_ASAP7_75t_L g362 ( 
.A(n_337),
.Y(n_362)
);

NAND4xp25_ASAP7_75t_SL g363 ( 
.A(n_333),
.B(n_307),
.C(n_308),
.D(n_37),
.Y(n_363)
);

O2A1O1Ixp33_ASAP7_75t_L g364 ( 
.A1(n_350),
.A2(n_347),
.B(n_361),
.C(n_346),
.Y(n_364)
);

NOR2x1_ASAP7_75t_L g365 ( 
.A(n_363),
.B(n_338),
.Y(n_365)
);

INVxp33_ASAP7_75t_L g366 ( 
.A(n_351),
.Y(n_366)
);

OAI21xp5_ASAP7_75t_L g367 ( 
.A1(n_351),
.A2(n_342),
.B(n_343),
.Y(n_367)
);

INVx1_ASAP7_75t_L g368 ( 
.A(n_354),
.Y(n_368)
);

AOI21xp33_ASAP7_75t_L g369 ( 
.A1(n_360),
.A2(n_345),
.B(n_340),
.Y(n_369)
);

XOR2xp5_ASAP7_75t_L g370 ( 
.A(n_355),
.B(n_326),
.Y(n_370)
);

AOI22xp5_ASAP7_75t_L g371 ( 
.A1(n_361),
.A2(n_345),
.B1(n_321),
.B2(n_340),
.Y(n_371)
);

OAI21xp5_ASAP7_75t_SL g372 ( 
.A1(n_358),
.A2(n_341),
.B(n_321),
.Y(n_372)
);

AOI22x1_ASAP7_75t_L g373 ( 
.A1(n_357),
.A2(n_326),
.B1(n_323),
.B2(n_327),
.Y(n_373)
);

INVx1_ASAP7_75t_L g374 ( 
.A(n_368),
.Y(n_374)
);

OAI311xp33_ASAP7_75t_L g375 ( 
.A1(n_367),
.A2(n_356),
.A3(n_362),
.B1(n_352),
.C1(n_359),
.Y(n_375)
);

OAI21xp33_ASAP7_75t_SL g376 ( 
.A1(n_370),
.A2(n_353),
.B(n_358),
.Y(n_376)
);

OAI22xp33_ASAP7_75t_L g377 ( 
.A1(n_373),
.A2(n_334),
.B1(n_349),
.B2(n_348),
.Y(n_377)
);

AOI221xp5_ASAP7_75t_L g378 ( 
.A1(n_366),
.A2(n_325),
.B1(n_320),
.B2(n_319),
.C(n_323),
.Y(n_378)
);

OAI211xp5_ASAP7_75t_SL g379 ( 
.A1(n_376),
.A2(n_364),
.B(n_365),
.C(n_372),
.Y(n_379)
);

OAI22xp5_ASAP7_75t_SL g380 ( 
.A1(n_375),
.A2(n_366),
.B1(n_371),
.B2(n_369),
.Y(n_380)
);

AOI22xp5_ASAP7_75t_L g381 ( 
.A1(n_377),
.A2(n_332),
.B1(n_331),
.B2(n_336),
.Y(n_381)
);

OAI22xp5_ASAP7_75t_L g382 ( 
.A1(n_380),
.A2(n_378),
.B1(n_374),
.B2(n_103),
.Y(n_382)
);

HB1xp67_ASAP7_75t_L g383 ( 
.A(n_381),
.Y(n_383)
);

HB1xp67_ASAP7_75t_L g384 ( 
.A(n_383),
.Y(n_384)
);

NAND2xp5_ASAP7_75t_L g385 ( 
.A(n_384),
.B(n_382),
.Y(n_385)
);

AOI22xp5_ASAP7_75t_L g386 ( 
.A1(n_385),
.A2(n_379),
.B1(n_113),
.B2(n_103),
.Y(n_386)
);

AOI21xp5_ASAP7_75t_L g387 ( 
.A1(n_386),
.A2(n_113),
.B(n_38),
.Y(n_387)
);


endmodule