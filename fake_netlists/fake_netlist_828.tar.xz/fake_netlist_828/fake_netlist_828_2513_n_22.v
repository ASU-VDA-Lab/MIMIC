module fake_netlist_828_2513_n_22 (n_4, n_2, n_3, n_0, n_1, n_22);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

BUFx3_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_4),
.Y(n_6)
);

NOR3xp33_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_0),
.C(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

AND2x4_ASAP7_75t_SL g9 ( 
.A(n_0),
.B(n_1),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_0),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_3),
.B(n_2),
.Y(n_11)
);

NAND2x1p5_ASAP7_75t_L g12 ( 
.A(n_5),
.B(n_2),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_4),
.C(n_3),
.Y(n_13)
);

INVx5_ASAP7_75t_SL g14 ( 
.A(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_16),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_14),
.A2(n_6),
.B1(n_9),
.B2(n_13),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_7),
.B1(n_5),
.B2(n_9),
.Y(n_19)
);

OAI221xp5_ASAP7_75t_R g20 ( 
.A1(n_18),
.A2(n_7),
.B1(n_14),
.B2(n_6),
.C(n_9),
.Y(n_20)
);

NAND4xp75_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_14),
.C(n_9),
.D(n_3),
.Y(n_21)
);

AOI221x1_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_19),
.B1(n_8),
.B2(n_13),
.C(n_17),
.Y(n_22)
);


endmodule