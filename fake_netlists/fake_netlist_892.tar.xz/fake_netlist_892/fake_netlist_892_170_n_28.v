module fake_netlist_892_170_n_28 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_28);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_28;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_1),
.B(n_2),
.Y(n_16)
);

CKINVDCx8_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

BUFx2_ASAP7_75t_R g18 ( 
.A(n_11),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_4),
.B1(n_3),
.B2(n_0),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_12),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_16),
.B1(n_15),
.B2(n_12),
.Y(n_21)
);

INVxp67_ASAP7_75t_SL g22 ( 
.A(n_20),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_17),
.Y(n_23)
);

OAI322xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_15),
.A3(n_14),
.B1(n_13),
.B2(n_23),
.C1(n_18),
.C2(n_21),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_24),
.B(n_18),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_4),
.B1(n_3),
.B2(n_5),
.C(n_6),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_10),
.B1(n_8),
.B2(n_7),
.Y(n_28)
);


endmodule