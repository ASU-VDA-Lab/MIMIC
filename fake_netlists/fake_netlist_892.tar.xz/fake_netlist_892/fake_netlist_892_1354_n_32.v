module fake_netlist_892_1354_n_32 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_32);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_32;

wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_25;
wire n_22;
wire n_26;
wire n_29;

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_4),
.A2(n_2),
.B(n_7),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_11),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_13),
.B(n_0),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_18),
.B(n_5),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_23),
.B(n_17),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_20),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B1(n_22),
.B2(n_16),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI211xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_19),
.B(n_15),
.C(n_1),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_14),
.B1(n_12),
.B2(n_3),
.Y(n_32)
);


endmodule