module fake_netlist_892_1897_n_21 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_21;

wire n_15;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_14;

INVx1_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

AND2x6_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_1),
.Y(n_13)
);

INVx5_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_15),
.B(n_14),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B1(n_4),
.B2(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B(n_5),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_10),
.Y(n_21)
);


endmodule