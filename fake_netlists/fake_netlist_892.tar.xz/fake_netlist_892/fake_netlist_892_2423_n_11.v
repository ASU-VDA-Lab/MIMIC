module fake_netlist_892_2423_n_11 (n_0, n_1, n_2, n_11);

input n_0;
input n_1;
input n_2;

output n_11;

wire n_5;
wire n_3;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

INVx1_ASAP7_75t_SL g3 ( 
.A(n_0),
.Y(n_3)
);

INVxp33_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);

INVxp33_ASAP7_75t_SL g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);


endmodule