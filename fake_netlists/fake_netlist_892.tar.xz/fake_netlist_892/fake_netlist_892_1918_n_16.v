module fake_netlist_892_1918_n_16 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_16);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_16;

wire n_15;
wire n_11;
wire n_9;
wire n_13;
wire n_14;
wire n_10;
wire n_8;
wire n_12;

AND2x4_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_0),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_2),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

BUFx12f_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

OAI221xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B1(n_9),
.B2(n_6),
.C(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OA211x2_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B(n_6),
.C(n_11),
.Y(n_14)
);

XNOR2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_8),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_9),
.B1(n_5),
.B2(n_1),
.C(n_4),
.Y(n_16)
);


endmodule