module fake_netlist_892_1969_n_32 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_32);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_32;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;
wire n_29;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_6),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

BUFx3_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AO21x2_ASAP7_75t_L g15 ( 
.A1(n_10),
.A2(n_1),
.B(n_5),
.Y(n_15)
);

OAI21xp33_ASAP7_75t_SL g16 ( 
.A1(n_12),
.A2(n_6),
.B(n_5),
.Y(n_16)
);

AOI21xp33_ASAP7_75t_L g17 ( 
.A1(n_8),
.A2(n_7),
.B(n_9),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

BUFx10_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_13),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_16),
.B1(n_17),
.B2(n_11),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_11),
.Y(n_24)
);

OAI211xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_16),
.B(n_19),
.C(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_26),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_19),
.B1(n_29),
.B2(n_30),
.Y(n_32)
);


endmodule