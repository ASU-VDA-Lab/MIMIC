module fake_netlist_892_1138_n_12 (n_0, n_1, n_2, n_12);

input n_0;
input n_1;
input n_2;

output n_12;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

INVx4_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_2),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AO22x2_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_3),
.B1(n_8),
.B2(n_1),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B1(n_2),
.B2(n_1),
.Y(n_12)
);


endmodule