module fake_netlist_892_1136_n_14 (n_0, n_1, n_3, n_2, n_14);

input n_0;
input n_1;
input n_3;
input n_2;

output n_14;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

AND2x2_ASAP7_75t_SL g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

AOI21xp33_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_5),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_6),
.Y(n_9)
);

OA21x2_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_7),
.B(n_4),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

OAI311xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_4),
.A3(n_9),
.B1(n_1),
.C1(n_0),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_2),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_10),
.B1(n_5),
.B2(n_12),
.C1(n_6),
.C2(n_8),
.Y(n_14)
);


endmodule