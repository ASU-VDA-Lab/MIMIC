module fake_netlist_892_1933_n_17 (n_0, n_2, n_3, n_4, n_1, n_17);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_17;

wire n_5;
wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

INVx4_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_3),
.B(n_2),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B1(n_8),
.B2(n_7),
.C(n_0),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.B(n_1),
.C(n_0),
.Y(n_12)
);

NOR4xp25_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_9),
.C(n_2),
.D(n_1),
.Y(n_13)
);

AOI221x1_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_7),
.B1(n_3),
.B2(n_1),
.C(n_2),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_7),
.B1(n_14),
.B2(n_4),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_15),
.B2(n_13),
.Y(n_17)
);


endmodule