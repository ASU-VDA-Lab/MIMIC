module fake_netlist_892_1409_n_20 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_20);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_20;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_17;
wire n_18;
wire n_13;
wire n_14;
wire n_10;

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_4),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_4),
.B1(n_0),
.B2(n_6),
.Y(n_12)
);

INVxp33_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_14),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_15),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B1(n_12),
.B2(n_10),
.C(n_11),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.C(n_5),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_6),
.B1(n_5),
.B2(n_2),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_9),
.B(n_3),
.Y(n_20)
);


endmodule