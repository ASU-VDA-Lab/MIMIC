module fake_netlist_892_2341_n_39 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_39);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_39;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_31;
wire n_13;
wire n_21;
wire n_25;
wire n_14;
wire n_22;
wire n_32;
wire n_35;
wire n_26;
wire n_10;
wire n_29;
wire n_36;
wire n_8;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_0),
.Y(n_8)
);

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_0),
.Y(n_10)
);

AND3x2_ASAP7_75t_L g11 ( 
.A(n_3),
.B(n_6),
.C(n_7),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

A2O1A1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_4),
.B(n_2),
.C(n_1),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

NAND2x1p5_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_1),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_5),
.B(n_4),
.C(n_2),
.Y(n_18)
);

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_11),
.A2(n_5),
.B(n_2),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_8),
.A2(n_12),
.B(n_10),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_16),
.B(n_14),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_11),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_17),
.B(n_14),
.C(n_9),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_20),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_17),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_16),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_22),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_23),
.B1(n_9),
.B2(n_18),
.C(n_15),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_18),
.B1(n_7),
.B2(n_5),
.C(n_6),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_27),
.B(n_22),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_22),
.C(n_6),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_SL g33 ( 
.A(n_30),
.B(n_3),
.C(n_29),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_31),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

OAI22x1_ASAP7_75t_SL g38 ( 
.A1(n_34),
.A2(n_9),
.B1(n_14),
.B2(n_8),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_37),
.A2(n_35),
.B1(n_36),
.B2(n_38),
.Y(n_39)
);


endmodule