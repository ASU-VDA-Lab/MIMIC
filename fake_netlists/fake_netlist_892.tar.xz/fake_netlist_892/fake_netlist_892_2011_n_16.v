module fake_netlist_892_2011_n_16 (n_0, n_1, n_3, n_2, n_16);

input n_0;
input n_1;
input n_3;
input n_2;

output n_16;

wire n_5;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_1),
.B(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_0),
.Y(n_7)
);

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_5),
.Y(n_12)
);

NAND4xp75_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_8),
.C(n_10),
.D(n_3),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_2),
.B1(n_13),
.B2(n_8),
.C1(n_5),
.C2(n_12),
.Y(n_16)
);


endmodule