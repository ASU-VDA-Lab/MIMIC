module fake_netlist_860_1915_n_18 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_18);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_18;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_9),
.Y(n_10)
);

AND2x2_ASAP7_75t_SL g11 ( 
.A(n_4),
.B(n_6),
.Y(n_11)
);

OR2x6_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_7),
.Y(n_12)
);

OAI221xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_12),
.B1(n_11),
.B2(n_5),
.C(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_7),
.B2(n_5),
.C1(n_1),
.C2(n_0),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_2),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_8),
.B(n_15),
.Y(n_18)
);


endmodule