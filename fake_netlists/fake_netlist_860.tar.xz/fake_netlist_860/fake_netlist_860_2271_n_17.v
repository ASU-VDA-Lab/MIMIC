module fake_netlist_860_2271_n_17 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_17);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_16;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

OR2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_6),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_6),
.B(n_1),
.Y(n_11)
);

AOI22x1_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_6),
.B1(n_1),
.B2(n_0),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_7),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_8),
.B2(n_9),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_9),
.B1(n_12),
.B2(n_1),
.C(n_0),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_9),
.B(n_5),
.Y(n_17)
);


endmodule