module fake_netlist_860_982_n_13 (n_2, n_0, n_1, n_13);

input n_2;
input n_0;
input n_1;

output n_13;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

INVx6_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

OAI21xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_4),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_7),
.Y(n_9)
);

OAI211xp5_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_8),
.B(n_2),
.C(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

BUFx8_ASAP7_75t_SL g12 ( 
.A(n_10),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_4),
.B1(n_8),
.B2(n_12),
.Y(n_13)
);


endmodule