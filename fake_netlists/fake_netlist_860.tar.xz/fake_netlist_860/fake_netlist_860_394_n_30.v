module fake_netlist_860_394_n_30 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_30);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_7),
.B1(n_12),
.B2(n_11),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_7),
.C(n_1),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_SL g21 ( 
.A(n_15),
.B(n_5),
.C(n_4),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_14),
.C(n_17),
.D(n_16),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx3_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_R g30 ( 
.A1(n_29),
.A2(n_26),
.B1(n_18),
.B2(n_6),
.C(n_9),
.Y(n_30)
);


endmodule