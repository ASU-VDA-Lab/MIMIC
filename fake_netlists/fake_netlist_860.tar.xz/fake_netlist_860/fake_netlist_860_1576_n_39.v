module fake_netlist_860_1576_n_39 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_39);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_39;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

AND2x4_ASAP7_75t_SL g22 ( 
.A(n_14),
.B(n_4),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_14),
.B1(n_18),
.B2(n_12),
.Y(n_24)
);

AO31x2_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_12),
.A3(n_6),
.B(n_5),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_19),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_21),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_25),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_19),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_6),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AOI221xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_12),
.B1(n_19),
.B2(n_0),
.C(n_1),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_3),
.Y(n_34)
);

CKINVDCx12_ASAP7_75t_R g35 ( 
.A(n_33),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_32),
.Y(n_36)
);

NAND2x1p5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_8),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_37),
.B1(n_35),
.B2(n_10),
.Y(n_39)
);


endmodule