module fake_netlist_860_1390_n_17 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_17);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_16;
wire n_9;
wire n_14;
wire n_11;
wire n_12;
wire n_8;

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_4),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_2),
.B(n_5),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

BUFx6f_ASAP7_75t_SL g11 ( 
.A(n_6),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_8),
.B(n_9),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_1),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.C(n_12),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_3),
.Y(n_16)
);

XNOR2x1_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.Y(n_17)
);


endmodule