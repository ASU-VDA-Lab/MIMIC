module fake_netlist_860_2143_n_35 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_35);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_35;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_3),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_4),
.B(n_7),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_1),
.B(n_0),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_4),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

HAxp5_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_5),
.CON(n_25),
.SN(n_25)
);

BUFx8_ASAP7_75t_SL g26 ( 
.A(n_20),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_20),
.B(n_5),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_22),
.B1(n_15),
.B2(n_16),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_24),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_26),
.Y(n_30)
);

NOR2xp67_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_24),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_25),
.B1(n_27),
.B2(n_24),
.C(n_17),
.Y(n_32)
);

XNOR2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_13),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

AOI222xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_33),
.B1(n_18),
.B2(n_11),
.C1(n_10),
.C2(n_9),
.Y(n_35)
);


endmodule