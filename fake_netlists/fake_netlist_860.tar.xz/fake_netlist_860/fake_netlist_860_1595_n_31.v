module fake_netlist_860_1595_n_31 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_31);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_31;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_9),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_6),
.B(n_12),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_7),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

INVx5_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_15),
.B1(n_19),
.B2(n_14),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_23),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_25),
.B1(n_23),
.B2(n_16),
.C(n_18),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_20),
.B1(n_5),
.B2(n_3),
.C(n_4),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OR3x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_6),
.C(n_0),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_11),
.B2(n_10),
.Y(n_31)
);


endmodule