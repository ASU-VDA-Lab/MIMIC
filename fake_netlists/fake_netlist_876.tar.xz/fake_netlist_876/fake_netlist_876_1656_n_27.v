module fake_netlist_876_1656_n_27 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_27);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_27;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_11),
.B(n_2),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

BUFx10_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_0),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_15),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_7),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_20),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_17),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_14),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_12),
.B1(n_9),
.B2(n_8),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_1),
.B1(n_6),
.B2(n_3),
.Y(n_27)
);


endmodule