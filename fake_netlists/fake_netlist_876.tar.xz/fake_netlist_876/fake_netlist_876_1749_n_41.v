module fake_netlist_876_1749_n_41 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_41);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_41;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

INVx2_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_4),
.B(n_2),
.Y(n_22)
);

AND3x2_ASAP7_75t_L g23 ( 
.A(n_10),
.B(n_12),
.C(n_7),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_14),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_19),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_22),
.A2(n_21),
.B(n_25),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_26),
.A2(n_27),
.B(n_23),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_28),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_33),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_SL g35 ( 
.A(n_34),
.B(n_31),
.C(n_30),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_18),
.B1(n_11),
.B2(n_8),
.Y(n_36)
);

NOR2xp67_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_17),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI22x1_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_37),
.B1(n_15),
.B2(n_5),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_39),
.B1(n_6),
.B2(n_13),
.Y(n_41)
);


endmodule