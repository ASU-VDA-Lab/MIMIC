module fake_netlist_876_445_n_31 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_31);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_31;

wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_21;
wire n_25;
wire n_22;
wire n_26;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_17),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_4),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_SL g22 ( 
.A(n_8),
.B(n_14),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_9),
.B1(n_12),
.B2(n_13),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_22),
.B(n_9),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_21),
.B1(n_19),
.B2(n_20),
.Y(n_25)
);

NOR4xp75_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.C(n_11),
.D(n_10),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_15),
.Y(n_27)
);

OAI21xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_2),
.B(n_5),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_7),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_1),
.B1(n_3),
.B2(n_16),
.Y(n_31)
);


endmodule