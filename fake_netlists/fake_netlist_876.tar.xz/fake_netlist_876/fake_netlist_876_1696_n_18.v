module fake_netlist_876_1696_n_18 (n_0, n_1, n_3, n_2, n_18);

input n_0;
input n_1;
input n_3;
input n_2;

output n_18;

wire n_5;
wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_17;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

OAI21xp33_ASAP7_75t_SL g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_0),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_6),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_6),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_4),
.B(n_7),
.C(n_13),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AOI22x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B1(n_12),
.B2(n_6),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_13),
.B1(n_12),
.B2(n_6),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_4),
.B1(n_1),
.B2(n_12),
.C1(n_3),
.C2(n_16),
.Y(n_18)
);


endmodule