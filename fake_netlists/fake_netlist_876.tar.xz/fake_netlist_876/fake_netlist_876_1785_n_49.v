module fake_netlist_876_1785_n_49 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_49);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_49;

wire n_33;
wire n_34;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_5),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_16),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_14),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_7),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_9),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_17),
.B(n_4),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_2),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_23),
.B1(n_12),
.B2(n_24),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_26),
.B(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_34),
.A2(n_26),
.B1(n_31),
.B2(n_27),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_25),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_36),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_28),
.Y(n_40)
);

INVxp67_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

OAI32xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_32),
.A3(n_29),
.B1(n_12),
.B2(n_23),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_22),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_SL g44 ( 
.A1(n_42),
.A2(n_18),
.B1(n_13),
.B2(n_15),
.C(n_11),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_19),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_20),
.Y(n_46)
);

NAND3xp33_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_44),
.C(n_6),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_SL g48 ( 
.A1(n_45),
.A2(n_1),
.B1(n_8),
.B2(n_3),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_0),
.B1(n_10),
.B2(n_47),
.Y(n_49)
);


endmodule