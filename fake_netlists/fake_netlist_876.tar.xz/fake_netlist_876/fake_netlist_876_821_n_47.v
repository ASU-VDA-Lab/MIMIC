module fake_netlist_876_821_n_47 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_47);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_47;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_35;
wire n_25;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_45;
wire n_44;
wire n_38;

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_4),
.B(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_0),
.B(n_12),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_2),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_22),
.B(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

AOI21xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_22),
.B(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx5_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_28),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_24),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_36),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_26),
.B1(n_23),
.B2(n_25),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_3),
.Y(n_39)
);

NAND4xp25_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_2),
.C(n_1),
.D(n_17),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

OA22x2_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_19),
.B1(n_11),
.B2(n_13),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_5),
.Y(n_44)
);

NOR3xp33_ASAP7_75t_SL g45 ( 
.A(n_42),
.B(n_7),
.C(n_19),
.Y(n_45)
);

NAND4xp75_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_19),
.C(n_43),
.D(n_44),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);


endmodule