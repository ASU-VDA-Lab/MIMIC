module fake_netlist_876_656_n_24 (n_0, n_2, n_3, n_4, n_1, n_24);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_24;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_5;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

INVx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_0),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

AO31x2_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_5),
.A3(n_6),
.B(n_8),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_8),
.B1(n_7),
.B2(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_14),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_10),
.B1(n_8),
.B2(n_16),
.C(n_14),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_16),
.B1(n_12),
.B2(n_1),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_1),
.Y(n_20)
);

NAND4xp25_ASAP7_75t_SL g21 ( 
.A(n_17),
.B(n_1),
.C(n_3),
.D(n_4),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_2),
.B(n_3),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_19),
.B(n_23),
.Y(n_24)
);


endmodule