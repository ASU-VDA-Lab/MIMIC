module fake_netlist_876_1429_n_13 (n_0, n_1, n_3, n_2, n_13);

input n_0;
input n_1;
input n_3;
input n_2;

output n_13;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

INVx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

OR2x6_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

AOI21xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_0),
.B(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

NOR3xp33_ASAP7_75t_SL g9 ( 
.A(n_8),
.B(n_6),
.C(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_9),
.Y(n_10)
);

OAI22x1_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_4),
.B1(n_5),
.B2(n_3),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_5),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_SL g13 ( 
.A1(n_11),
.A2(n_12),
.B(n_2),
.Y(n_13)
);


endmodule