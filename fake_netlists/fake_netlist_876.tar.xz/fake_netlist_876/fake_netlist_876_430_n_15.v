module fake_netlist_876_430_n_15 (n_0, n_2, n_3, n_4, n_1, n_15);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_15;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx5_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

AO21x2_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_2),
.B(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_6),
.B(n_4),
.Y(n_15)
);


endmodule