module fake_netlist_876_102_n_53 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_53);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_53;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_45;
wire n_44;
wire n_48;
wire n_38;

INVx2_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_4),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_8),
.B(n_12),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_13),
.B(n_8),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_15),
.B(n_10),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_5),
.B(n_1),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_11),
.B(n_3),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_SL g28 ( 
.A(n_21),
.B(n_19),
.C(n_25),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_19),
.A2(n_20),
.B(n_22),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_18),
.B(n_12),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_20),
.B(n_17),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_20),
.C(n_18),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_30),
.A2(n_32),
.B(n_31),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_29),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_32),
.B1(n_20),
.B2(n_23),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_32),
.B1(n_24),
.B2(n_28),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_33),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_32),
.Y(n_42)
);

INVx1_ASAP7_75t_SL g43 ( 
.A(n_40),
.Y(n_43)
);

AOI311xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_33),
.A3(n_38),
.B(n_39),
.C(n_14),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_43),
.B(n_14),
.Y(n_45)
);

XNOR2xp5_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_0),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

NAND4xp25_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_9),
.C(n_16),
.D(n_10),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_9),
.B1(n_16),
.B2(n_6),
.C(n_7),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

BUFx6f_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_SL g53 ( 
.A1(n_52),
.A2(n_51),
.B1(n_46),
.B2(n_47),
.Y(n_53)
);


endmodule