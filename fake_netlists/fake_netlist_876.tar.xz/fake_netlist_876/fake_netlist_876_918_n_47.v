module fake_netlist_876_918_n_47 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_47);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_47;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_42;
wire n_41;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_38;

INVx2_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_1),
.B(n_2),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_6),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_17),
.B1(n_19),
.B2(n_25),
.C(n_16),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_SL g28 ( 
.A1(n_23),
.A2(n_17),
.B1(n_20),
.B2(n_15),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_25),
.A2(n_22),
.B1(n_0),
.B2(n_6),
.Y(n_29)
);

OAI31xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_26),
.A3(n_24),
.B(n_27),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

O2A1O1Ixp33_ASAP7_75t_SL g37 ( 
.A1(n_34),
.A2(n_26),
.B(n_24),
.C(n_30),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

AO21x2_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_35),
.B(n_32),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_31),
.B1(n_30),
.B2(n_26),
.C(n_1),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_26),
.B1(n_7),
.B2(n_0),
.Y(n_41)
);

XNOR2x1_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_4),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

OAI211xp5_ASAP7_75t_SL g44 ( 
.A1(n_39),
.A2(n_4),
.B(n_7),
.C(n_3),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_41),
.B1(n_43),
.B2(n_44),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AOI322xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_3),
.A3(n_5),
.B1(n_10),
.B2(n_11),
.C1(n_13),
.C2(n_45),
.Y(n_47)
);


endmodule