module fake_netlist_876_481_n_23 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_23);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_23;

wire n_15;
wire n_16;
wire n_19;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_5),
.B1(n_10),
.B2(n_1),
.Y(n_13)
);

BUFx3_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

NAND3x1_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_0),
.C(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_14),
.B(n_13),
.Y(n_17)
);

AO21x2_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_15),
.B(n_4),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_18),
.Y(n_19)
);

OAI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_2),
.B1(n_3),
.B2(n_0),
.Y(n_20)
);

NOR4xp75_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_3),
.C(n_2),
.D(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_6),
.Y(n_23)
);


endmodule