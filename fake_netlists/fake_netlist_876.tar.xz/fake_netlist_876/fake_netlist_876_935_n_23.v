module fake_netlist_876_935_n_23 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_23);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_23;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_10;

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_8),
.B(n_5),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

INVx8_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

AND3x2_ASAP7_75t_L g12 ( 
.A(n_5),
.B(n_6),
.C(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_10),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_SL g14 ( 
.A1(n_9),
.A2(n_2),
.B(n_4),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_10),
.B1(n_11),
.B2(n_12),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

OAI32xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.A3(n_14),
.B1(n_10),
.B2(n_11),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.C(n_3),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_3),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

XNOR2x1_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_1),
.B1(n_4),
.B2(n_22),
.Y(n_23)
);


endmodule