module fake_netlist_622_3559_n_25 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_25);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_25;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_3),
.A2(n_6),
.B1(n_8),
.B2(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

OAI21x1_ASAP7_75t_SL g18 ( 
.A1(n_14),
.A2(n_6),
.B(n_4),
.Y(n_18)
);

NAND3x1_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_7),
.C(n_0),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_17),
.B1(n_15),
.B2(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

O2A1O1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_17),
.B(n_15),
.C(n_19),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_5),
.B(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_12),
.B(n_10),
.Y(n_25)
);


endmodule