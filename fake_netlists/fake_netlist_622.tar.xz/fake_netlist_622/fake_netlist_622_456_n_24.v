module fake_netlist_622_456_n_24 (n_7, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_24);

input n_7;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_24;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_9;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_0),
.A2(n_2),
.B1(n_8),
.B2(n_5),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_SL g12 ( 
.A(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_12),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_9),
.B(n_10),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_3),
.B(n_1),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_1),
.Y(n_20)
);

BUFx12f_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_6),
.B1(n_7),
.B2(n_21),
.Y(n_24)
);


endmodule