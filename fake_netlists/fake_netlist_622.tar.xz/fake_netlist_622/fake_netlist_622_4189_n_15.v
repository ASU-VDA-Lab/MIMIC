module fake_netlist_622_4189_n_15 (n_1, n_2, n_3, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_0;

output n_15;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;

INVx3_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_2),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

BUFx4f_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI22xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_4),
.B1(n_8),
.B2(n_6),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_4),
.B1(n_3),
.B2(n_0),
.C(n_1),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_12),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);


endmodule