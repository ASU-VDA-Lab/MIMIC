module fake_netlist_622_3146_n_15 (n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_15);

input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_15;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_14;
wire n_10;
wire n_13;
wire n_12;

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_6),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_4),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

AOI222xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B1(n_8),
.B2(n_2),
.C1(n_1),
.C2(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND4xp75_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_9),
.C(n_4),
.D(n_2),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_5),
.Y(n_14)
);

AOI21xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_6),
.B(n_5),
.Y(n_15)
);


endmodule