module fake_netlist_622_1046_n_34 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_34);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_34;

wire n_11;
wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;
wire n_14;
wire n_13;
wire n_12;

BUFx3_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

BUFx8_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_4),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_9),
.B(n_7),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_11),
.B(n_10),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_3),
.B(n_2),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_0),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_4),
.B(n_1),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_18),
.B(n_15),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_13),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_20),
.Y(n_25)
);

NOR2xp67_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_17),
.Y(n_26)
);

OAI322xp33_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_5),
.A3(n_6),
.B1(n_7),
.B2(n_11),
.C1(n_14),
.C2(n_25),
.Y(n_27)
);

INVx2_ASAP7_75t_SL g28 ( 
.A(n_24),
.Y(n_28)
);

AOI222xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_5),
.B1(n_11),
.B2(n_26),
.C1(n_16),
.C2(n_22),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_22),
.B1(n_23),
.B2(n_24),
.C(n_16),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_31),
.B1(n_32),
.B2(n_28),
.Y(n_34)
);


endmodule