module fake_netlist_622_2960_n_10 (n_0, n_4, n_1, n_2, n_3, n_10);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_10;

wire n_7;
wire n_9;
wire n_8;
wire n_5;
wire n_6;

NAND2xp33_ASAP7_75t_SL g5 ( 
.A(n_0),
.B(n_4),
.Y(n_5)
);

NAND3xp33_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_0),
.C(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

XOR2x1_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_5),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_1),
.B(n_8),
.Y(n_10)
);


endmodule