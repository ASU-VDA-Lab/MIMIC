module fake_netlist_622_1551_n_20 (n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_20);

input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_20;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_7;
wire n_19;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

AND2x6_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_3),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_1),
.Y(n_11)
);

NAND2xp33_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_1),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_6),
.B(n_0),
.Y(n_13)
);

AND2x4_ASAP7_75t_SL g14 ( 
.A(n_11),
.B(n_10),
.Y(n_14)
);

OAI222xp33_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_9),
.B1(n_10),
.B2(n_6),
.C1(n_2),
.C2(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_10),
.Y(n_17)
);

AOI211xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_15),
.B(n_13),
.C(n_14),
.Y(n_18)
);

OAI22x1_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B1(n_17),
.B2(n_3),
.Y(n_19)
);

OAI22xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_5),
.B1(n_13),
.B2(n_16),
.Y(n_20)
);


endmodule