module fake_netlist_622_410_n_15 (n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_15);

input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_15;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_14;
wire n_10;
wire n_13;
wire n_12;

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_1),
.Y(n_7)
);

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_0),
.A2(n_4),
.B1(n_6),
.B2(n_5),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI22xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_4),
.B2(n_1),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B1(n_6),
.B2(n_4),
.C(n_5),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_0),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_6),
.B1(n_5),
.B2(n_2),
.Y(n_14)
);

AOI21x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_3),
.B(n_2),
.Y(n_15)
);


endmodule