module fake_netlist_622_851_n_29 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_29);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_29;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_9;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

NAND2x1_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_0),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_R g9 ( 
.A(n_1),
.B(n_6),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

AND3x2_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_6),
.C(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_4),
.B(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_10),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_8),
.A2(n_4),
.B(n_0),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_15),
.Y(n_19)
);

INVx3_ASAP7_75t_R g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_19),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_13),
.B1(n_16),
.B2(n_10),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_18),
.B(n_9),
.C(n_4),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_21),
.B(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_23),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_26)
);

INVxp67_ASAP7_75t_SL g27 ( 
.A(n_25),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_3),
.B1(n_2),
.B2(n_7),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_27),
.A2(n_7),
.B1(n_26),
.B2(n_28),
.Y(n_29)
);


endmodule