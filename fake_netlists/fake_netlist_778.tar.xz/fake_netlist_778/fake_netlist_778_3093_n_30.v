module fake_netlist_778_3093_n_30 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_30);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_30;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_26;
wire n_24;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_28;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_1),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_2),
.B(n_3),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

NOR2xp67_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_1),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_1),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_5),
.B(n_0),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_0),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_8),
.A2(n_6),
.B(n_5),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_14),
.B(n_12),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_16),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_21),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_22),
.Y(n_25)
);

OAI211xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_13),
.B(n_19),
.C(n_15),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

NAND4xp25_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_24),
.C(n_18),
.D(n_15),
.Y(n_29)
);

AO221x2_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_12),
.B1(n_28),
.B2(n_11),
.C(n_1),
.Y(n_30)
);


endmodule