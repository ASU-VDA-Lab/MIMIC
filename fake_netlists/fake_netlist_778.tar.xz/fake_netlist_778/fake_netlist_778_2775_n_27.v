module fake_netlist_778_2775_n_27 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_27);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_27;

wire n_20;
wire n_17;
wire n_12;
wire n_25;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_8;
wire n_9;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_4),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

CKINVDCx14_ASAP7_75t_R g15 ( 
.A(n_13),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_9),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_17)
);

NOR2x1_ASAP7_75t_SL g18 ( 
.A(n_14),
.B(n_9),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_11),
.A2(n_12),
.B(n_8),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_13),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_20),
.B(n_17),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_19),
.B1(n_12),
.B2(n_18),
.C(n_15),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_22),
.C(n_18),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_SL g26 ( 
.A(n_25),
.B(n_8),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_10),
.B1(n_23),
.B2(n_25),
.Y(n_27)
);


endmodule