module fake_netlist_778_2349_n_8 (n_1, n_0, n_8);

input n_1;
input n_0;

output n_8;

wire n_7;
wire n_5;
wire n_6;
wire n_3;
wire n_2;
wire n_4;

HB1xp67_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

INVx3_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_0),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

XNOR2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_1),
.Y(n_8)
);


endmodule