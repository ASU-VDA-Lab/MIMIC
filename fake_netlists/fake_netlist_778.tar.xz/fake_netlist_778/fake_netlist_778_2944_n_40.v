module fake_netlist_778_2944_n_40 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_40);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_40;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_12;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_26;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_0),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_3),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_14),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_13),
.C(n_15),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_13),
.B(n_4),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_15),
.A2(n_7),
.B1(n_4),
.B2(n_0),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_R g23 ( 
.A(n_18),
.B(n_11),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

OAI21xp33_ASAP7_75t_L g26 ( 
.A1(n_20),
.A2(n_15),
.B(n_12),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_19),
.Y(n_27)
);

AND2x2_ASAP7_75t_SL g28 ( 
.A(n_25),
.B(n_7),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_17),
.Y(n_29)
);

AOI31xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_23),
.A3(n_26),
.B(n_17),
.Y(n_30)
);

AOI221xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_24),
.B1(n_5),
.B2(n_2),
.C(n_3),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_27),
.B(n_28),
.C(n_2),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_28),
.B(n_8),
.C(n_5),
.Y(n_33)
);

AOI211xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_28),
.B(n_9),
.C(n_8),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_32),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_10),
.B1(n_37),
.B2(n_35),
.Y(n_38)
);

OAI21xp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_35),
.B(n_37),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_SL g40 ( 
.A1(n_38),
.A2(n_10),
.B1(n_35),
.B2(n_39),
.Y(n_40)
);


endmodule