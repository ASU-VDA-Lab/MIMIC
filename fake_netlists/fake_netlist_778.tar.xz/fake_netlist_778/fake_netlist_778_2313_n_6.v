module fake_netlist_778_2313_n_6 (n_1, n_0, n_6);

input n_1;
input n_0;

output n_6;

wire n_5;
wire n_3;
wire n_2;
wire n_4;

NAND2xp5_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

A2O1A1Ixp33_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_5)
);

NOR3xp33_ASAP7_75t_SL g6 ( 
.A(n_5),
.B(n_0),
.C(n_1),
.Y(n_6)
);


endmodule