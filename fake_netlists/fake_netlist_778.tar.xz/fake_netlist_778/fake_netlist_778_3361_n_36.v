module fake_netlist_778_3361_n_36 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_36);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_36;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_28;
wire n_9;
wire n_30;
wire n_10;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

BUFx10_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_8),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_1),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_6),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_3),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_9),
.A2(n_4),
.B1(n_3),
.B2(n_0),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_10),
.B(n_4),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_10),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_R g21 ( 
.A(n_17),
.B(n_7),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_SL g22 ( 
.A(n_18),
.B(n_13),
.C(n_11),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_16),
.B(n_15),
.C(n_14),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_22),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_23),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_17),
.B1(n_19),
.B2(n_20),
.Y(n_28)
);

AOI211xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_25),
.B(n_8),
.C(n_7),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_29),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVxp33_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_34),
.B1(n_33),
.B2(n_32),
.Y(n_36)
);


endmodule