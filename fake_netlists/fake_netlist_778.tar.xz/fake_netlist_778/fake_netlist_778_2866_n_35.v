module fake_netlist_778_2866_n_35 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_35);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_35;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

AND2x4_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_2),
.Y(n_15)
);

AND2x2_ASAP7_75t_SL g16 ( 
.A(n_0),
.B(n_12),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_4),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_4),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_16),
.A2(n_7),
.B1(n_6),
.B2(n_1),
.Y(n_23)
);

AOI21xp33_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_16),
.B(n_15),
.Y(n_24)
);

OR2x6_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_18),
.Y(n_25)
);

INVx4_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_24),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_17),
.B1(n_20),
.B2(n_23),
.C(n_22),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

OAI211xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_20),
.B(n_15),
.C(n_3),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_29),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_29),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_20),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AOI222xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_33),
.B1(n_9),
.B2(n_5),
.C1(n_10),
.C2(n_8),
.Y(n_35)
);


endmodule