module fake_netlist_778_3630_n_12 (n_1, n_2, n_0, n_12);

input n_1;
input n_2;
input n_0;

output n_12;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_3;
wire n_9;
wire n_4;
wire n_8;

OR2x2_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_1),
.Y(n_4)
);

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x4_ASAP7_75t_SL g7 ( 
.A(n_5),
.B(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_5),
.C(n_7),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

AOI322xp5_ASAP7_75t_R g12 ( 
.A1(n_11),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_10),
.C1(n_7),
.C2(n_5),
.Y(n_12)
);


endmodule