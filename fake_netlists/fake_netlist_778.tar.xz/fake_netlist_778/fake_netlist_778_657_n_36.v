module fake_netlist_778_657_n_36 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_36);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_36;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_26;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_7),
.B(n_2),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_6),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_4),
.B(n_10),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_3),
.B(n_0),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_1),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_16),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_22),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_18),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_26),
.B(n_25),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_25),
.B1(n_23),
.B2(n_24),
.Y(n_29)
);

O2A1O1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_27),
.B(n_24),
.C(n_25),
.Y(n_30)
);

OAI221xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_23),
.B1(n_24),
.B2(n_18),
.C(n_25),
.Y(n_31)
);

NAND2xp33_ASAP7_75t_SL g32 ( 
.A(n_30),
.B(n_12),
.Y(n_32)
);

CKINVDCx16_ASAP7_75t_R g33 ( 
.A(n_31),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_24),
.B2(n_11),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_24),
.B1(n_14),
.B2(n_12),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_5),
.B1(n_6),
.B2(n_35),
.Y(n_36)
);


endmodule