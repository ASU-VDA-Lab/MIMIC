module fake_netlist_778_2896_n_13 (n_1, n_0, n_5, n_3, n_2, n_4, n_13);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_13;

wire n_7;
wire n_10;
wire n_11;
wire n_6;
wire n_8;
wire n_12;
wire n_9;

OR2x2_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_2),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_5),
.Y(n_7)
);

O2A1O1Ixp33_ASAP7_75t_L g8 ( 
.A1(n_2),
.A2(n_0),
.B(n_5),
.C(n_1),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_1),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI222xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_3),
.B1(n_4),
.B2(n_8),
.C1(n_7),
.C2(n_10),
.Y(n_11)
);

NAND4xp25_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.C(n_10),
.D(n_3),
.Y(n_12)
);

OAI21x1_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_4),
.Y(n_13)
);


endmodule