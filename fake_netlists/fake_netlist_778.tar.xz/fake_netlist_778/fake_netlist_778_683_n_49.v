module fake_netlist_778_683_n_49 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_49);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_49;

wire n_37;
wire n_45;
wire n_44;
wire n_20;
wire n_47;
wire n_29;
wire n_36;
wire n_17;
wire n_12;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_13;
wire n_18;
wire n_48;
wire n_43;
wire n_15;
wire n_11;
wire n_16;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_10;
wire n_19;
wire n_21;
wire n_41;
wire n_32;
wire n_22;
wire n_14;

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_8),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

NAND2x1_ASAP7_75t_L g14 ( 
.A(n_4),
.B(n_5),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_6),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_1),
.B(n_7),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_0),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_11),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

AND2x6_ASAP7_75t_SL g23 ( 
.A(n_10),
.B(n_3),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_17),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_19),
.B(n_17),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_11),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_22),
.A2(n_14),
.B1(n_16),
.B2(n_4),
.C(n_7),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_24),
.B(n_14),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_28),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_25),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_29),
.A2(n_26),
.B1(n_30),
.B2(n_20),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

NOR2xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_20),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

AOI21xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_32),
.B(n_31),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

BUFx3_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_36),
.Y(n_41)
);

NOR2x1_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_30),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_38),
.A2(n_32),
.B1(n_24),
.B2(n_23),
.C(n_9),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_41),
.Y(n_44)
);

NOR2x1_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_40),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_39),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_47),
.A2(n_40),
.B1(n_45),
.B2(n_48),
.Y(n_49)
);


endmodule