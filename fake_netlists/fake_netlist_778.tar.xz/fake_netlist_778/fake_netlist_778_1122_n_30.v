module fake_netlist_778_1122_n_30 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_30);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_30;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_28;
wire n_9;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_2),
.B(n_3),
.Y(n_12)
);

NOR2x1p5_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_8),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_6),
.B(n_2),
.Y(n_14)
);

CKINVDCx11_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_9),
.A2(n_10),
.B(n_14),
.C(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_3),
.B(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AO21x2_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_14),
.B(n_1),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_17),
.B1(n_15),
.B2(n_16),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_SL g23 ( 
.A(n_19),
.B(n_16),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_19),
.B(n_21),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_20),
.C(n_21),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_SL g26 ( 
.A1(n_24),
.A2(n_22),
.B1(n_21),
.B2(n_18),
.C(n_4),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

A2O1A1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_29)
);

AO21x2_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_7),
.B(n_29),
.Y(n_30)
);


endmodule