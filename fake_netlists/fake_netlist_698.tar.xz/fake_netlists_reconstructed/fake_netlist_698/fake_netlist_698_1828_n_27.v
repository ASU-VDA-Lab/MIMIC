module fake_netlist_698_1828_n_27 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_12),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_5),
.B(n_7),
.Y(n_17)
);

AND3x1_ASAP7_75t_SL g18 ( 
.A(n_15),
.B(n_5),
.C(n_4),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_14),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_16),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_13),
.B1(n_18),
.B2(n_17),
.Y(n_22)
);

OAI31xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_17),
.A3(n_18),
.B(n_4),
.Y(n_23)
);

XNOR2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_6),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

NAND4xp75_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.C(n_1),
.D(n_0),
.Y(n_26)
);

AOI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_3),
.B1(n_2),
.B2(n_8),
.C1(n_11),
.C2(n_9),
.Y(n_27)
);


endmodule