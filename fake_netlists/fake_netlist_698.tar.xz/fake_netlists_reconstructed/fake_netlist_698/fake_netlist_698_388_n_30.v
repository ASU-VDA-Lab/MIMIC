module fake_netlist_698_388_n_30 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_30);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_30;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_29;
wire n_28;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_3),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

OAI21xp33_ASAP7_75t_SL g21 ( 
.A1(n_19),
.A2(n_16),
.B(n_15),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_18),
.B1(n_17),
.B2(n_7),
.Y(n_22)
);

CKINVDCx10_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_21),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_7),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_1),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI322xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_28),
.A3(n_8),
.B1(n_6),
.B2(n_5),
.C1(n_12),
.C2(n_11),
.Y(n_30)
);


endmodule