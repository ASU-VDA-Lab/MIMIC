module fake_netlist_698_51_n_28 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_28);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_28;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_12;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_6),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_11),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_13),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NAND5xp2_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_12),
.C(n_6),
.D(n_4),
.E(n_5),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

OR2x4_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_17),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_10),
.Y(n_21)
);

INVxp67_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_7),
.C(n_4),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_24),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);


endmodule