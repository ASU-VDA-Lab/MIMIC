module fake_netlist_698_2050_n_35 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_35);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_35;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_34;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_10),
.B(n_11),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

INVx5_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_15),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

OAI21x1_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.B(n_15),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_R g24 ( 
.A(n_22),
.B(n_13),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

NOR3xp33_ASAP7_75t_SL g26 ( 
.A(n_24),
.B(n_17),
.C(n_19),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_23),
.B(n_20),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_23),
.B(n_20),
.Y(n_28)
);

NAND4xp25_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_24),
.C(n_13),
.D(n_0),
.Y(n_29)
);

AOI211x1_ASAP7_75t_SL g30 ( 
.A1(n_27),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_14),
.B1(n_20),
.B2(n_3),
.Y(n_33)
);

AO22x2_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_8),
.B1(n_11),
.B2(n_33),
.Y(n_35)
);


endmodule