module fake_netlist_698_3004_n_15 (n_3, n_0, n_2, n_1, n_15);

input n_3;
input n_0;
input n_2;
input n_1;

output n_15;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

AOI222xp33_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_3),
.C2(n_4),
.Y(n_7)
);

BUFx3_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OR2x6_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_1),
.Y(n_10)
);

AOI21xp33_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_2),
.B(n_1),
.Y(n_11)
);

AOI211xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B(n_9),
.C(n_2),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AOI31xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_9),
.A3(n_3),
.B(n_8),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_9),
.B1(n_13),
.B2(n_10),
.C1(n_8),
.C2(n_6),
.Y(n_15)
);


endmodule