module fake_netlist_698_2969_n_27 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_13;
wire n_25;
wire n_19;
wire n_14;
wire n_12;

BUFx3_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_3),
.B(n_0),
.Y(n_14)
);

BUFx10_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_7),
.B1(n_5),
.B2(n_2),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_19),
.B1(n_17),
.B2(n_12),
.C(n_15),
.Y(n_23)
);

XNOR2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

AOI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_25),
.B1(n_14),
.B2(n_16),
.C1(n_9),
.C2(n_6),
.Y(n_27)
);


endmodule