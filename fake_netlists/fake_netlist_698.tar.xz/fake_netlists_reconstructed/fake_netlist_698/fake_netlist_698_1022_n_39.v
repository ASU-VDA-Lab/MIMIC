module fake_netlist_698_1022_n_39 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_39);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_39;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_19;
wire n_25;
wire n_13;
wire n_14;

OAI22xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_10),
.B1(n_9),
.B2(n_6),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_4),
.B(n_7),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_8),
.B(n_6),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

OAI21xp33_ASAP7_75t_SL g21 ( 
.A1(n_13),
.A2(n_1),
.B(n_0),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_13),
.A2(n_2),
.B(n_1),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_2),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_18),
.Y(n_24)
);

NOR2x1p5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_17),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_14),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_23),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

OAI21xp33_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_29),
.B(n_27),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_21),
.B(n_26),
.C(n_22),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_26),
.B(n_23),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_19),
.B1(n_14),
.B2(n_25),
.C(n_3),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_31),
.B(n_4),
.Y(n_35)
);

AO22x2_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_25),
.B1(n_19),
.B2(n_5),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_7),
.B(n_5),
.Y(n_37)
);

INVxp67_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_11),
.B1(n_38),
.B2(n_37),
.Y(n_39)
);


endmodule