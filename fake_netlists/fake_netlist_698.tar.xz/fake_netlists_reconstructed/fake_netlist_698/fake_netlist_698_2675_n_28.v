module fake_netlist_698_2675_n_28 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_28);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_28;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_25;
wire n_19;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_2),
.A2(n_13),
.B1(n_3),
.B2(n_12),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVxp67_ASAP7_75t_SL g18 ( 
.A(n_6),
.Y(n_18)
);

INVx2_ASAP7_75t_SL g19 ( 
.A(n_17),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_17),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_16),
.B1(n_19),
.B2(n_14),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_15),
.C(n_7),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_19),
.B1(n_7),
.B2(n_0),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

OAI222xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_8),
.B1(n_1),
.B2(n_9),
.C1(n_11),
.C2(n_10),
.Y(n_28)
);


endmodule