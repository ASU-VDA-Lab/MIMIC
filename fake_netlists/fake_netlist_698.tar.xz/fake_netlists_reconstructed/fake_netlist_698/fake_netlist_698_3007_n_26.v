module fake_netlist_698_3007_n_26 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_26);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_26;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_25;
wire n_19;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_12),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_13),
.Y(n_17)
);

OAI21xp33_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_1),
.B(n_0),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_18),
.B(n_16),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_15),
.Y(n_21)
);

OAI21xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B(n_17),
.Y(n_22)
);

AOI21xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_6),
.B(n_4),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

OAI22x1_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_7),
.B1(n_3),
.B2(n_2),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_26)
);


endmodule