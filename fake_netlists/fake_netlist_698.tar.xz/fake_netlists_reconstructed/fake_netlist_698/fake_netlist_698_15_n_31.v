module fake_netlist_698_15_n_31 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_31);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_31;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_29;
wire n_13;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_0),
.B(n_11),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_10),
.B(n_2),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_SL g19 ( 
.A(n_16),
.B(n_6),
.C(n_4),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_9),
.B(n_3),
.Y(n_20)
);

OAI22x1_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_7),
.B1(n_4),
.B2(n_12),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

NOR2x1_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_18),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.C(n_22),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

AOI22x1_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_20),
.B1(n_15),
.B2(n_13),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_18),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_16),
.B2(n_14),
.Y(n_31)
);


endmodule