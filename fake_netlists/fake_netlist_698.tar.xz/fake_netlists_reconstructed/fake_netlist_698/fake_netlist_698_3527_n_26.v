module fake_netlist_698_3527_n_26 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_26);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_26;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_4),
.B(n_8),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_1),
.A2(n_10),
.B1(n_6),
.B2(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_7),
.B(n_6),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_20),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_19),
.C(n_14),
.D(n_13),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_5),
.Y(n_24)
);

OAI31xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_15),
.A3(n_16),
.B(n_14),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_18),
.B1(n_7),
.B2(n_5),
.C1(n_12),
.C2(n_3),
.Y(n_26)
);


endmodule