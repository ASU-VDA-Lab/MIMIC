module fake_netlist_698_2552_n_11 (n_0, n_2, n_1, n_11);

input n_0;
input n_2;
input n_1;

output n_11;

wire n_9;
wire n_7;
wire n_4;
wire n_3;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

INVx3_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

AND2x4_ASAP7_75t_SL g4 ( 
.A(n_1),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AO21x2_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVxp67_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_9),
.Y(n_10)
);

AOI322xp5_ASAP7_75t_R g11 ( 
.A1(n_10),
.A2(n_2),
.A3(n_4),
.B1(n_6),
.B2(n_7),
.C1(n_3),
.C2(n_9),
.Y(n_11)
);


endmodule