module fake_netlist_698_2393_n_13 (n_0, n_2, n_1, n_13);

input n_0;
input n_2;
input n_1;

output n_13;

wire n_9;
wire n_4;
wire n_7;
wire n_3;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

HB1xp67_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

NAND3xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_2),
.C(n_1),
.Y(n_5)
);

OR2x2_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_2),
.Y(n_6)
);

BUFx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

O2A1O1Ixp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.B(n_2),
.C(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_8),
.Y(n_11)
);

XNOR2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);


endmodule