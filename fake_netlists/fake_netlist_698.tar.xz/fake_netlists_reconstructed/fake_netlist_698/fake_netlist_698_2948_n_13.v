module fake_netlist_698_2948_n_13 (n_3, n_0, n_2, n_1, n_13);

input n_3;
input n_0;
input n_2;
input n_1;

output n_13;

wire n_9;
wire n_4;
wire n_7;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx4_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVxp67_ASAP7_75t_SL g9 ( 
.A(n_7),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_4),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B1(n_4),
.B2(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_3),
.C2(n_5),
.Y(n_13)
);


endmodule