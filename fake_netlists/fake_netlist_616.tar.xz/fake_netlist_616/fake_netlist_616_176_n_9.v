module fake_netlist_616_176_n_9 (n_1, n_2, n_0, n_9);

input n_1;
input n_2;
input n_0;

output n_9;

wire n_7;
wire n_8;
wire n_5;
wire n_6;
wire n_4;
wire n_3;

NOR2xp33_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

OAI21xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND4xp75_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_3),
.C(n_4),
.D(n_0),
.Y(n_7)
);

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_0),
.B1(n_2),
.B2(n_6),
.Y(n_9)
);


endmodule