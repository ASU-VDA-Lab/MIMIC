module fake_netlist_616_1580_n_26 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_26);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_26;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_25;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_16),
.B(n_13),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_18),
.A2(n_15),
.B1(n_14),
.B2(n_17),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

INVx1_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

AO22x2_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.C(n_9),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_23),
.B1(n_6),
.B2(n_5),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_26)
);


endmodule