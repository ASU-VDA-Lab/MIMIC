module fake_netlist_616_705_n_14 (n_1, n_2, n_3, n_0, n_14);

input n_1;
input n_2;
input n_3;
input n_0;

output n_14;

wire n_7;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;
wire n_9;

HB1xp67_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVxp67_ASAP7_75t_SL g5 ( 
.A(n_1),
.Y(n_5)
);

CKINVDCx16_ASAP7_75t_R g6 ( 
.A(n_4),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NOR4xp25_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.C(n_1),
.D(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_1),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_2),
.B1(n_3),
.B2(n_13),
.C1(n_5),
.C2(n_8),
.Y(n_14)
);


endmodule