module fake_netlist_616_3173_n_31 (n_7, n_9, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_31);

input n_7;
input n_9;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_31;

wire n_11;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

INVx4_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_2),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_0),
.B(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_SL g17 ( 
.A1(n_14),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_17)
);

AO31x2_ASAP7_75t_L g18 ( 
.A1(n_11),
.A2(n_5),
.A3(n_4),
.B(n_3),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_4),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_SL g20 ( 
.A1(n_13),
.A2(n_8),
.B(n_6),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_11),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_11),
.Y(n_22)
);

AND2x2_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_15),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_21),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_17),
.B1(n_16),
.B2(n_14),
.C(n_20),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_16),
.B1(n_12),
.B2(n_13),
.C(n_18),
.Y(n_26)
);

NOR2x1_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_23),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_18),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_18),
.B1(n_7),
.B2(n_6),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_18),
.B(n_29),
.Y(n_31)
);


endmodule