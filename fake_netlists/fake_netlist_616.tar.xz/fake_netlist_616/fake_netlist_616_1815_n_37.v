module fake_netlist_616_1815_n_37 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_37);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_37;

wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;
wire n_14;
wire n_13;
wire n_12;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_1),
.Y(n_12)
);

XNOR2xp5_ASAP7_75t_L g13 ( 
.A(n_6),
.B(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

INVx5_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

BUFx4f_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

O2A1O1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_12),
.B(n_16),
.C(n_14),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_13),
.B1(n_17),
.B2(n_15),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_R g25 ( 
.A(n_24),
.B(n_4),
.Y(n_25)
);

NOR3xp33_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_15),
.C(n_18),
.Y(n_26)
);

BUFx4f_ASAP7_75t_SL g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_23),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_27),
.Y(n_29)
);

NOR2x1_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_17),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_18),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_5),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_29),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_19),
.B1(n_7),
.B2(n_5),
.C(n_8),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

AOI322xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_7),
.A3(n_10),
.B1(n_11),
.B2(n_32),
.C1(n_34),
.C2(n_35),
.Y(n_37)
);


endmodule