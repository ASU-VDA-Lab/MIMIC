module fake_netlist_616_1782_n_27 (n_7, n_9, n_11, n_8, n_5, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_27);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_27;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;

INVx1_ASAP7_75t_SL g14 ( 
.A(n_11),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

AND2x6_ASAP7_75t_L g16 ( 
.A(n_0),
.B(n_13),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_10),
.B1(n_5),
.B2(n_9),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

BUFx10_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_14),
.A2(n_3),
.B(n_6),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_SL g22 ( 
.A(n_20),
.B(n_17),
.C(n_15),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

INVxp67_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.C(n_16),
.Y(n_25)
);

NAND5xp2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_7),
.C(n_16),
.D(n_18),
.E(n_20),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_18),
.Y(n_27)
);


endmodule