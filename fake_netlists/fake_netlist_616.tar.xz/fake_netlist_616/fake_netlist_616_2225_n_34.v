module fake_netlist_616_2225_n_34 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_34);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_34;

wire n_11;
wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;
wire n_14;
wire n_13;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_3),
.B(n_5),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx4_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

OAI21x1_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_12),
.B(n_11),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_12),
.B(n_14),
.C(n_11),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B1(n_17),
.B2(n_11),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_19),
.B1(n_17),
.B2(n_11),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_17),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_SL g25 ( 
.A(n_23),
.B(n_19),
.C(n_1),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

NAND3x1_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_4),
.C(n_1),
.Y(n_28)
);

NAND4xp75_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_6),
.C(n_5),
.D(n_4),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_27),
.B1(n_20),
.B2(n_0),
.Y(n_33)
);

NAND3xp33_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_9),
.C(n_33),
.Y(n_34)
);


endmodule