module fake_netlist_616_304_n_26 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_26);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_26;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_25;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

INVx1_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

NOR2x1_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_4),
.Y(n_9)
);

NAND2xp33_ASAP7_75t_R g10 ( 
.A(n_6),
.B(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

AND2x6_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_1),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_0),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_1),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_13),
.B2(n_9),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_12),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_13),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);

AOI31xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_10),
.A3(n_12),
.B(n_2),
.Y(n_21)
);

NOR2xp67_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_2),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);


endmodule