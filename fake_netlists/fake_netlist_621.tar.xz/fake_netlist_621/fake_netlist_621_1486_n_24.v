module fake_netlist_621_1486_n_24 (n_5, n_0, n_4, n_1, n_2, n_3, n_24);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_24;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_7;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

NOR2x1p5_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_3),
.Y(n_6)
);

INVx6_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_4),
.B(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_3),
.B(n_2),
.Y(n_10)
);

AOI21xp33_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

OA21x2_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_0),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_1),
.B(n_2),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_12),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_8),
.B1(n_10),
.B2(n_6),
.C(n_7),
.Y(n_16)
);

OAI221xp5_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_7),
.B1(n_10),
.B2(n_1),
.C(n_3),
.Y(n_17)
);

NOR2x1_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.Y(n_18)
);

NAND2x1_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_12),
.Y(n_19)
);

AOI211xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_16),
.B(n_13),
.C(n_14),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_15),
.B(n_14),
.Y(n_21)
);

XOR2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

AOI222xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_5),
.B1(n_7),
.B2(n_16),
.C1(n_17),
.C2(n_23),
.Y(n_24)
);


endmodule