module fake_netlist_621_2214_n_17 (n_7, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_17);

input n_7;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_17;

wire n_11;
wire n_15;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

INVx1_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVxp67_ASAP7_75t_SL g11 ( 
.A(n_1),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_SL g12 ( 
.A1(n_9),
.A2(n_7),
.B1(n_2),
.B2(n_0),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

INVxp67_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.C(n_7),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_8),
.B1(n_6),
.B2(n_5),
.Y(n_17)
);


endmodule