module fake_netlist_621_2365_n_12 (n_1, n_0, n_12);

input n_1;
input n_0;

output n_12;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_2;
wire n_3;

OR2x2_ASAP7_75t_L g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

AND2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_1),
.Y(n_4)
);

NAND2x1p5_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_0),
.Y(n_5)
);

OR2x2_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_2),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_1),
.Y(n_7)
);

OAI322xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_0),
.A3(n_1),
.B1(n_5),
.B2(n_3),
.C1(n_2),
.C2(n_6),
.Y(n_8)
);

AOI21xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_5),
.Y(n_10)
);

OAI22x1_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_0),
.B1(n_1),
.B2(n_9),
.Y(n_11)
);

AO221x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_0),
.B1(n_1),
.B2(n_10),
.C(n_3),
.Y(n_12)
);


endmodule