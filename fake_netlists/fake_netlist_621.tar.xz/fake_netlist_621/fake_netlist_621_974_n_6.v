module fake_netlist_621_974_n_6 (n_1, n_2, n_0, n_6);

input n_1;
input n_2;
input n_0;

output n_6;

wire n_5;
wire n_4;
wire n_3;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

OR2x2_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI22xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_6)
);


endmodule