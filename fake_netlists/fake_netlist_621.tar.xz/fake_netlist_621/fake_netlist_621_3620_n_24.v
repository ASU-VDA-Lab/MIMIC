module fake_netlist_621_3620_n_24 (n_7, n_9, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_24);

input n_7;
input n_9;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_24;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_3),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_7),
.C(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_17),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_14),
.B1(n_15),
.B2(n_7),
.C1(n_16),
.C2(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_10),
.B1(n_8),
.B2(n_6),
.Y(n_24)
);


endmodule