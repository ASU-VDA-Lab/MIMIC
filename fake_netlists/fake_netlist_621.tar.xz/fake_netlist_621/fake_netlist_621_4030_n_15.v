module fake_netlist_621_4030_n_15 (n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_15);

input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_15;

wire n_7;
wire n_11;
wire n_8;
wire n_14;
wire n_10;
wire n_13;
wire n_12;
wire n_9;

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI221x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B1(n_10),
.B2(n_8),
.C(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_1),
.B1(n_3),
.B2(n_6),
.C1(n_12),
.C2(n_11),
.Y(n_15)
);


endmodule