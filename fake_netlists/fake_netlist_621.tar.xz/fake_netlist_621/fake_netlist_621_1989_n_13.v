module fake_netlist_621_1989_n_13 (n_5, n_0, n_4, n_1, n_2, n_3, n_13);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_13;

wire n_7;
wire n_11;
wire n_8;
wire n_10;
wire n_6;
wire n_12;
wire n_9;

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_2),
.B(n_0),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

OAI221xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B1(n_1),
.B2(n_0),
.C(n_2),
.Y(n_9)
);

OAI21xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_0),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_1),
.C(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_SL g12 ( 
.A(n_11),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_3),
.B1(n_4),
.B2(n_5),
.C1(n_7),
.C2(n_0),
.Y(n_13)
);


endmodule