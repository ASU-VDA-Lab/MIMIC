module fake_netlist_621_4275_n_7 (n_1, n_2, n_0, n_7);

input n_1;
input n_2;
input n_0;

output n_7;

wire n_5;
wire n_6;
wire n_4;
wire n_3;

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

BUFx2_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

AOI22x1_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_0),
.B1(n_1),
.B2(n_4),
.Y(n_7)
);


endmodule