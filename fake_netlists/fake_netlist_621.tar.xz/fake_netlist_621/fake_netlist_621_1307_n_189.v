module fake_netlist_621_1307_n_189 (n_11, n_8, n_31, n_15, n_37, n_39, n_3, n_40, n_21, n_30, n_44, n_18, n_36, n_22, n_29, n_34, n_27, n_28, n_17, n_4, n_1, n_24, n_35, n_7, n_25, n_26, n_19, n_38, n_10, n_43, n_20, n_32, n_23, n_16, n_42, n_5, n_33, n_14, n_41, n_13, n_6, n_0, n_12, n_2, n_9, n_189);

input n_11;
input n_8;
input n_31;
input n_15;
input n_37;
input n_39;
input n_3;
input n_40;
input n_21;
input n_30;
input n_44;
input n_18;
input n_36;
input n_22;
input n_29;
input n_34;
input n_27;
input n_28;
input n_17;
input n_4;
input n_1;
input n_24;
input n_35;
input n_7;
input n_25;
input n_26;
input n_19;
input n_38;
input n_10;
input n_43;
input n_20;
input n_32;
input n_23;
input n_16;
input n_42;
input n_5;
input n_33;
input n_14;
input n_41;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_189;

wire n_137;
wire n_133;
wire n_170;
wire n_75;
wire n_109;
wire n_121;
wire n_119;
wire n_54;
wire n_179;
wire n_168;
wire n_120;
wire n_123;
wire n_164;
wire n_181;
wire n_87;
wire n_125;
wire n_185;
wire n_65;
wire n_106;
wire n_83;
wire n_63;
wire n_88;
wire n_126;
wire n_116;
wire n_47;
wire n_57;
wire n_135;
wire n_82;
wire n_55;
wire n_76;
wire n_64;
wire n_157;
wire n_160;
wire n_68;
wire n_146;
wire n_177;
wire n_161;
wire n_81;
wire n_97;
wire n_53;
wire n_182;
wire n_122;
wire n_188;
wire n_77;
wire n_163;
wire n_101;
wire n_184;
wire n_80;
wire n_112;
wire n_172;
wire n_69;
wire n_176;
wire n_99;
wire n_86;
wire n_110;
wire n_78;
wire n_114;
wire n_141;
wire n_71;
wire n_167;
wire n_149;
wire n_132;
wire n_155;
wire n_96;
wire n_84;
wire n_107;
wire n_115;
wire n_148;
wire n_150;
wire n_158;
wire n_117;
wire n_130;
wire n_171;
wire n_94;
wire n_129;
wire n_169;
wire n_59;
wire n_102;
wire n_134;
wire n_50;
wire n_143;
wire n_58;
wire n_142;
wire n_52;
wire n_95;
wire n_51;
wire n_49;
wire n_145;
wire n_45;
wire n_73;
wire n_159;
wire n_104;
wire n_108;
wire n_56;
wire n_85;
wire n_66;
wire n_92;
wire n_105;
wire n_153;
wire n_147;
wire n_166;
wire n_103;
wire n_144;
wire n_79;
wire n_139;
wire n_186;
wire n_180;
wire n_162;
wire n_111;
wire n_187;
wire n_61;
wire n_70;
wire n_62;
wire n_90;
wire n_67;
wire n_89;
wire n_152;
wire n_48;
wire n_91;
wire n_128;
wire n_138;
wire n_140;
wire n_183;
wire n_165;
wire n_60;
wire n_178;
wire n_46;
wire n_175;
wire n_156;
wire n_151;
wire n_131;
wire n_136;
wire n_154;
wire n_74;
wire n_173;
wire n_113;
wire n_118;
wire n_93;
wire n_72;
wire n_100;
wire n_98;
wire n_127;
wire n_174;
wire n_124;

INVxp67_ASAP7_75t_SL g45 ( 
.A(n_7),
.Y(n_45)
);

INVxp33_ASAP7_75t_SL g46 ( 
.A(n_19),
.Y(n_46)
);

BUFx6f_ASAP7_75t_L g47 ( 
.A(n_1),
.Y(n_47)
);

BUFx3_ASAP7_75t_L g48 ( 
.A(n_18),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_29),
.Y(n_49)
);

BUFx3_ASAP7_75t_L g50 ( 
.A(n_15),
.Y(n_50)
);

BUFx3_ASAP7_75t_L g51 ( 
.A(n_24),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_28),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_30),
.Y(n_53)
);

INVxp67_ASAP7_75t_SL g54 ( 
.A(n_6),
.Y(n_54)
);

CKINVDCx5p33_ASAP7_75t_R g55 ( 
.A(n_23),
.Y(n_55)
);

CKINVDCx5p33_ASAP7_75t_R g56 ( 
.A(n_37),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_43),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_8),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_10),
.Y(n_59)
);

BUFx5_ASAP7_75t_L g60 ( 
.A(n_17),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_41),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_9),
.Y(n_62)
);

BUFx3_ASAP7_75t_L g63 ( 
.A(n_44),
.Y(n_63)
);

CKINVDCx5p33_ASAP7_75t_R g64 ( 
.A(n_34),
.Y(n_64)
);

BUFx6f_ASAP7_75t_L g65 ( 
.A(n_36),
.Y(n_65)
);

BUFx3_ASAP7_75t_L g66 ( 
.A(n_14),
.Y(n_66)
);

INVxp33_ASAP7_75t_SL g67 ( 
.A(n_38),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_27),
.Y(n_68)
);

BUFx3_ASAP7_75t_L g69 ( 
.A(n_42),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_47),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_60),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_60),
.Y(n_72)
);

INVx3_ASAP7_75t_L g73 ( 
.A(n_65),
.Y(n_73)
);

BUFx6f_ASAP7_75t_L g74 ( 
.A(n_65),
.Y(n_74)
);

BUFx3_ASAP7_75t_L g75 ( 
.A(n_48),
.Y(n_75)
);

AND2x4_ASAP7_75t_L g76 ( 
.A(n_48),
.B(n_16),
.Y(n_76)
);

AND2x2_ASAP7_75t_L g77 ( 
.A(n_50),
.B(n_0),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_47),
.Y(n_78)
);

BUFx6f_ASAP7_75t_L g79 ( 
.A(n_65),
.Y(n_79)
);

CKINVDCx5p33_ASAP7_75t_R g80 ( 
.A(n_55),
.Y(n_80)
);

CKINVDCx5p33_ASAP7_75t_R g81 ( 
.A(n_56),
.Y(n_81)
);

INVx2_ASAP7_75t_L g82 ( 
.A(n_60),
.Y(n_82)
);

INVx2_ASAP7_75t_L g83 ( 
.A(n_60),
.Y(n_83)
);

BUFx6f_ASAP7_75t_L g84 ( 
.A(n_65),
.Y(n_84)
);

BUFx6f_ASAP7_75t_L g85 ( 
.A(n_74),
.Y(n_85)
);

CKINVDCx5p33_ASAP7_75t_R g86 ( 
.A(n_80),
.Y(n_86)
);

AND2x4_ASAP7_75t_L g87 ( 
.A(n_76),
.B(n_51),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_70),
.Y(n_88)
);

NOR2xp33_ASAP7_75t_L g89 ( 
.A(n_81),
.B(n_46),
.Y(n_89)
);

INVx3_ASAP7_75t_L g90 ( 
.A(n_74),
.Y(n_90)
);

BUFx2_ASAP7_75t_L g91 ( 
.A(n_75),
.Y(n_91)
);

AND2x6_ASAP7_75t_L g92 ( 
.A(n_76),
.B(n_49),
.Y(n_92)
);

AND2x4_ASAP7_75t_L g93 ( 
.A(n_77),
.B(n_63),
.Y(n_93)
);

BUFx3_ASAP7_75t_L g94 ( 
.A(n_78),
.Y(n_94)
);

INVx4_ASAP7_75t_L g95 ( 
.A(n_74),
.Y(n_95)
);

INVxp67_ASAP7_75t_SL g96 ( 
.A(n_73),
.Y(n_96)
);

INVx2_ASAP7_75t_L g97 ( 
.A(n_94),
.Y(n_97)
);

INVx1_ASAP7_75t_L g98 ( 
.A(n_96),
.Y(n_98)
);

BUFx4f_ASAP7_75t_L g99 ( 
.A(n_91),
.Y(n_99)
);

BUFx12f_ASAP7_75t_L g100 ( 
.A(n_86),
.Y(n_100)
);

INVx2_ASAP7_75t_L g101 ( 
.A(n_90),
.Y(n_101)
);

NAND2xp5_ASAP7_75t_SL g102 ( 
.A(n_87),
.B(n_52),
.Y(n_102)
);

NOR3xp33_ASAP7_75t_L g103 ( 
.A(n_89),
.B(n_54),
.C(n_45),
.Y(n_103)
);

BUFx3_ASAP7_75t_L g104 ( 
.A(n_93),
.Y(n_104)
);

AND2x4_ASAP7_75t_L g105 ( 
.A(n_88),
.B(n_63),
.Y(n_105)
);

BUFx4f_ASAP7_75t_L g106 ( 
.A(n_92),
.Y(n_106)
);

INVx3_ASAP7_75t_L g107 ( 
.A(n_85),
.Y(n_107)
);

BUFx6f_ASAP7_75t_L g108 ( 
.A(n_85),
.Y(n_108)
);

NAND2xp5_ASAP7_75t_L g109 ( 
.A(n_90),
.B(n_79),
.Y(n_109)
);

OR2x6_ASAP7_75t_L g110 ( 
.A(n_95),
.B(n_66),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_95),
.B(n_79),
.Y(n_111)
);

NAND2xp5_ASAP7_75t_L g112 ( 
.A(n_85),
.B(n_79),
.Y(n_112)
);

BUFx12f_ASAP7_75t_L g113 ( 
.A(n_100),
.Y(n_113)
);

O2A1O1Ixp5_ASAP7_75t_L g114 ( 
.A1(n_102),
.A2(n_68),
.B(n_61),
.C(n_53),
.Y(n_114)
);

NAND2xp5_ASAP7_75t_SL g115 ( 
.A(n_99),
.B(n_67),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_97),
.Y(n_116)
);

NOR2xp33_ASAP7_75t_R g117 ( 
.A(n_99),
.B(n_64),
.Y(n_117)
);

AOI21xp5_ASAP7_75t_L g118 ( 
.A1(n_111),
.A2(n_106),
.B(n_98),
.Y(n_118)
);

AND2x4_ASAP7_75t_L g119 ( 
.A(n_105),
.B(n_69),
.Y(n_119)
);

BUFx6f_ASAP7_75t_L g120 ( 
.A(n_105),
.Y(n_120)
);

BUFx6f_ASAP7_75t_L g121 ( 
.A(n_110),
.Y(n_121)
);

BUFx6f_ASAP7_75t_L g122 ( 
.A(n_108),
.Y(n_122)
);

AO22x1_ASAP7_75t_L g123 ( 
.A1(n_103),
.A2(n_62),
.B1(n_59),
.B2(n_58),
.Y(n_123)
);

INVx5_ASAP7_75t_L g124 ( 
.A(n_108),
.Y(n_124)
);

AOI21x1_ASAP7_75t_L g125 ( 
.A1(n_112),
.A2(n_109),
.B(n_101),
.Y(n_125)
);

INVx4_ASAP7_75t_L g126 ( 
.A(n_107),
.Y(n_126)
);

BUFx6f_ASAP7_75t_L g127 ( 
.A(n_104),
.Y(n_127)
);

OAI21x1_ASAP7_75t_L g128 ( 
.A1(n_125),
.A2(n_72),
.B(n_71),
.Y(n_128)
);

AOI21xp5_ASAP7_75t_L g129 ( 
.A1(n_118),
.A2(n_84),
.B(n_57),
.Y(n_129)
);

INVx3_ASAP7_75t_L g130 ( 
.A(n_126),
.Y(n_130)
);

BUFx12f_ASAP7_75t_L g131 ( 
.A(n_113),
.Y(n_131)
);

BUFx6f_ASAP7_75t_L g132 ( 
.A(n_120),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_116),
.Y(n_133)
);

OA21x2_ASAP7_75t_L g134 ( 
.A1(n_114),
.A2(n_83),
.B(n_82),
.Y(n_134)
);

CKINVDCx5p33_ASAP7_75t_R g135 ( 
.A(n_117),
.Y(n_135)
);

AO221x2_ASAP7_75t_L g136 ( 
.A1(n_123),
.A2(n_3),
.B1(n_2),
.B2(n_4),
.C(n_5),
.Y(n_136)
);

INVx6_ASAP7_75t_L g137 ( 
.A(n_127),
.Y(n_137)
);

OAI21x1_ASAP7_75t_L g138 ( 
.A1(n_115),
.A2(n_21),
.B(n_20),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_119),
.Y(n_139)
);

INVx4_ASAP7_75t_L g140 ( 
.A(n_122),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_121),
.Y(n_141)
);

OA21x2_ASAP7_75t_L g142 ( 
.A1(n_128),
.A2(n_124),
.B(n_22),
.Y(n_142)
);

BUFx4f_ASAP7_75t_L g143 ( 
.A(n_131),
.Y(n_143)
);

AOI21xp5_ASAP7_75t_L g144 ( 
.A1(n_130),
.A2(n_26),
.B(n_25),
.Y(n_144)
);

BUFx6f_ASAP7_75t_L g145 ( 
.A(n_132),
.Y(n_145)
);

AND2x4_ASAP7_75t_L g146 ( 
.A(n_141),
.B(n_31),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_133),
.Y(n_147)
);

AOI22xp33_ASAP7_75t_SL g148 ( 
.A1(n_136),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_148)
);

OA21x2_ASAP7_75t_L g149 ( 
.A1(n_129),
.A2(n_33),
.B(n_32),
.Y(n_149)
);

BUFx12f_ASAP7_75t_L g150 ( 
.A(n_135),
.Y(n_150)
);

AND2x4_ASAP7_75t_L g151 ( 
.A(n_139),
.B(n_35),
.Y(n_151)
);

BUFx6f_ASAP7_75t_L g152 ( 
.A(n_137),
.Y(n_152)
);

AOI21xp5_ASAP7_75t_L g153 ( 
.A1(n_140),
.A2(n_40),
.B(n_39),
.Y(n_153)
);

INVx1_ASAP7_75t_SL g154 ( 
.A(n_137),
.Y(n_154)
);

INVx1_ASAP7_75t_L g155 ( 
.A(n_147),
.Y(n_155)
);

AND2x4_ASAP7_75t_L g156 ( 
.A(n_151),
.B(n_138),
.Y(n_156)
);

INVx2_ASAP7_75t_L g157 ( 
.A(n_149),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_146),
.Y(n_158)
);

INVx4_ASAP7_75t_L g159 ( 
.A(n_145),
.Y(n_159)
);

INVx2_ASAP7_75t_L g160 ( 
.A(n_142),
.Y(n_160)
);

HB1xp67_ASAP7_75t_L g161 ( 
.A(n_154),
.Y(n_161)
);

BUFx2_ASAP7_75t_L g162 ( 
.A(n_152),
.Y(n_162)
);

AND2x2_ASAP7_75t_L g163 ( 
.A(n_148),
.B(n_134),
.Y(n_163)
);

BUFx2_ASAP7_75t_L g164 ( 
.A(n_150),
.Y(n_164)
);

INVx3_ASAP7_75t_L g165 ( 
.A(n_143),
.Y(n_165)
);

AND2x4_ASAP7_75t_L g166 ( 
.A(n_162),
.B(n_144),
.Y(n_166)
);

INVx1_ASAP7_75t_L g167 ( 
.A(n_155),
.Y(n_167)
);

AND2x4_ASAP7_75t_L g168 ( 
.A(n_158),
.B(n_153),
.Y(n_168)
);

AND2x4_ASAP7_75t_SL g169 ( 
.A(n_165),
.B(n_161),
.Y(n_169)
);

INVx3_ASAP7_75t_L g170 ( 
.A(n_159),
.Y(n_170)
);

AND2x2_ASAP7_75t_L g171 ( 
.A(n_163),
.B(n_164),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_156),
.Y(n_172)
);

AND2x2_ASAP7_75t_L g173 ( 
.A(n_171),
.B(n_157),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_167),
.Y(n_174)
);

AND2x4_ASAP7_75t_L g175 ( 
.A(n_169),
.B(n_160),
.Y(n_175)
);

INVx2_ASAP7_75t_L g176 ( 
.A(n_174),
.Y(n_176)
);

AND2x2_ASAP7_75t_L g177 ( 
.A(n_173),
.B(n_172),
.Y(n_177)
);

INVx1_ASAP7_75t_L g178 ( 
.A(n_176),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_178),
.Y(n_179)
);

INVx1_ASAP7_75t_L g180 ( 
.A(n_179),
.Y(n_180)
);

INVx1_ASAP7_75t_L g181 ( 
.A(n_180),
.Y(n_181)
);

AND2x4_ASAP7_75t_L g182 ( 
.A(n_181),
.B(n_177),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_182),
.Y(n_183)
);

INVx2_ASAP7_75t_L g184 ( 
.A(n_183),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_184),
.Y(n_185)
);

INVx1_ASAP7_75t_L g186 ( 
.A(n_185),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_186),
.Y(n_187)
);

NOR2xp33_ASAP7_75t_L g188 ( 
.A(n_187),
.B(n_175),
.Y(n_188)
);

AOI22xp5_ASAP7_75t_L g189 ( 
.A1(n_188),
.A2(n_166),
.B1(n_168),
.B2(n_170),
.Y(n_189)
);


endmodule