module fake_netlist_621_2513_n_9 (n_1, n_0, n_9);

input n_1;
input n_0;

output n_9;

wire n_7;
wire n_8;
wire n_5;
wire n_6;
wire n_4;
wire n_2;
wire n_3;

NAND2xp5_ASAP7_75t_SL g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

AOI22xp33_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.Y(n_4)
);

INVx2_ASAP7_75t_SL g5 ( 
.A(n_4),
.Y(n_5)
);

AOI221xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_4),
.C(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);


endmodule