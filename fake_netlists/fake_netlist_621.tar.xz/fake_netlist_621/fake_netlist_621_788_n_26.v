module fake_netlist_621_788_n_26 (n_7, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_26);

input n_7;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_26;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_25;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

INVx5_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

OA22x2_ASAP7_75t_L g14 ( 
.A1(n_5),
.A2(n_7),
.B1(n_3),
.B2(n_6),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_6),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_7),
.B1(n_1),
.B2(n_0),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_SL g17 ( 
.A(n_10),
.B(n_7),
.C(n_0),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_11),
.A2(n_8),
.B(n_4),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_9),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_21)
);

OAI32xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_12),
.A3(n_13),
.B1(n_14),
.B2(n_16),
.Y(n_22)
);

AOI211xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B(n_20),
.C(n_19),
.Y(n_23)
);

NAND2x1_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_19),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_24),
.B(n_9),
.Y(n_26)
);


endmodule