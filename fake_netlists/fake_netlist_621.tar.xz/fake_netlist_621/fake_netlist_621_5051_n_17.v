module fake_netlist_621_5051_n_17 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_17);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_17;

wire n_11;
wire n_8;
wire n_15;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

NAND2xp33_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_1),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_2),
.B(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

INVxp67_ASAP7_75t_SL g12 ( 
.A(n_11),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_10),
.B1(n_6),
.B2(n_4),
.C(n_8),
.Y(n_14)
);

NOR2x1p5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_9),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_6),
.C(n_4),
.Y(n_16)
);

AOI21xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_5),
.B(n_3),
.Y(n_17)
);


endmodule