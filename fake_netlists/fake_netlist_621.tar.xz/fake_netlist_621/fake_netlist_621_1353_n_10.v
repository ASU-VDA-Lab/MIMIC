module fake_netlist_621_1353_n_10 (n_1, n_0, n_10);

input n_1;
input n_0;

output n_10;

wire n_7;
wire n_9;
wire n_8;
wire n_5;
wire n_6;
wire n_4;
wire n_2;
wire n_3;

INVx1_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

OR2x6_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

O2A1O1Ixp33_ASAP7_75t_SL g4 ( 
.A1(n_2),
.A2(n_0),
.B(n_1),
.C(n_3),
.Y(n_4)
);

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_5)
);

AO21x2_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_3),
.B(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

NOR3xp33_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_5),
.C(n_6),
.Y(n_8)
);

AO21x2_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B(n_1),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule