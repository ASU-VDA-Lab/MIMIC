module fake_netlist_802_2675_n_32 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_8),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_9),
.A2(n_2),
.B(n_0),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_5),
.B(n_13),
.Y(n_17)
);

NAND2xp33_ASAP7_75t_SL g18 ( 
.A(n_6),
.B(n_11),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

OAI221xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_18),
.B1(n_17),
.B2(n_15),
.C(n_16),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_16),
.Y(n_23)
);

OAI211xp5_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_21),
.B(n_6),
.C(n_4),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_4),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_26),
.B(n_7),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_7),
.Y(n_28)
);

CKINVDCx16_ASAP7_75t_R g29 ( 
.A(n_27),
.Y(n_29)
);

XNOR2x1_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_16),
.Y(n_30)
);

NOR2x1_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_3),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_29),
.B1(n_12),
.B2(n_10),
.Y(n_32)
);


endmodule