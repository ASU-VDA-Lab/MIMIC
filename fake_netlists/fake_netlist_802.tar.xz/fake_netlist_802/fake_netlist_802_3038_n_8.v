module fake_netlist_802_3038_n_8 (n_2, n_0, n_3, n_1, n_8);

input n_2;
input n_0;
input n_3;
input n_1;

output n_8;

wire n_6;
wire n_4;
wire n_7;
wire n_5;

A2O1A1Ixp33_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_0),
.B(n_2),
.C(n_1),
.Y(n_4)
);

AOI21xp5_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_1),
.B(n_3),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

OAI221xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_5),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_7)
);

XNOR2x1_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);


endmodule