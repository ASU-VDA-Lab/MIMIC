module fake_netlist_802_2145_n_74 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_74);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_74;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_70;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_23;
wire n_34;
wire n_44;
wire n_28;
wire n_39;
wire n_40;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_68;
wire n_26;
wire n_72;
wire n_24;
wire n_71;
wire n_73;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_69;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_21;
wire n_35;
wire n_52;
wire n_38;
wire n_61;
wire n_27;
wire n_67;
wire n_45;
wire n_46;
wire n_51;

INVx2_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

OA21x2_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_3),
.B(n_4),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_13),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_8),
.A2(n_1),
.B1(n_6),
.B2(n_3),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

AND2x6_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_15),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_10),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_12),
.B(n_9),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_11),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_18),
.Y(n_31)
);

OR2x6_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_0),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_27),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_33)
);

NAND2xp33_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_24),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

OR2x6_ASAP7_75t_L g36 ( 
.A(n_25),
.B(n_2),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_23),
.B(n_17),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_23),
.B(n_17),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_37),
.B(n_24),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_35),
.B(n_20),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

AO21x2_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_29),
.B(n_20),
.Y(n_43)
);

OAI22xp33_ASAP7_75t_L g44 ( 
.A1(n_32),
.A2(n_22),
.B1(n_21),
.B2(n_30),
.Y(n_44)
);

AO21x2_ASAP7_75t_L g45 ( 
.A1(n_34),
.A2(n_27),
.B(n_21),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_36),
.Y(n_46)
);

INVx4_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_41),
.B(n_32),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_42),
.Y(n_49)
);

OR2x2_ASAP7_75t_L g50 ( 
.A(n_44),
.B(n_36),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

OAI21xp5_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_42),
.B(n_40),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_36),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_48),
.B(n_45),
.Y(n_54)
);

NOR3xp33_ASAP7_75t_SL g55 ( 
.A(n_52),
.B(n_22),
.C(n_30),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_SL g56 ( 
.A(n_53),
.B(n_46),
.Y(n_56)
);

OA22x2_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_50),
.B1(n_47),
.B2(n_45),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_54),
.B(n_43),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_51),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

O2A1O1Ixp33_ASAP7_75t_L g61 ( 
.A1(n_55),
.A2(n_51),
.B(n_33),
.C(n_43),
.Y(n_61)
);

AOI31xp33_ASAP7_75t_L g62 ( 
.A1(n_57),
.A2(n_19),
.A3(n_27),
.B(n_21),
.Y(n_62)
);

OAI21xp5_ASAP7_75t_L g63 ( 
.A1(n_58),
.A2(n_27),
.B(n_43),
.Y(n_63)
);

NAND2xp33_ASAP7_75t_SL g64 ( 
.A(n_60),
.B(n_23),
.Y(n_64)
);

NOR3xp33_ASAP7_75t_L g65 ( 
.A(n_62),
.B(n_27),
.C(n_23),
.Y(n_65)
);

OAI211xp5_ASAP7_75t_SL g66 ( 
.A1(n_61),
.A2(n_5),
.B(n_60),
.C(n_63),
.Y(n_66)
);

INVx3_ASAP7_75t_SL g67 ( 
.A(n_59),
.Y(n_67)
);

XNOR2xp5_ASAP7_75t_L g68 ( 
.A(n_59),
.B(n_62),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_68),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_67),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_64),
.Y(n_71)
);

NAND2xp5_ASAP7_75t_SL g72 ( 
.A(n_71),
.B(n_70),
.Y(n_72)
);

INVx4_ASAP7_75t_L g73 ( 
.A(n_71),
.Y(n_73)
);

OAI221xp5_ASAP7_75t_R g74 ( 
.A1(n_72),
.A2(n_65),
.B1(n_66),
.B2(n_69),
.C(n_73),
.Y(n_74)
);


endmodule