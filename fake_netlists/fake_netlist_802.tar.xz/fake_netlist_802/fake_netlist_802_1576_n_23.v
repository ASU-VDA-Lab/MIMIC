module fake_netlist_802_1576_n_23 (n_4, n_2, n_3, n_0, n_1, n_23);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_4),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_0),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_7),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_11),
.B(n_5),
.Y(n_16)
);

AOI31xp33_ASAP7_75t_SL g17 ( 
.A1(n_13),
.A2(n_5),
.A3(n_3),
.B(n_2),
.Y(n_17)
);

NAND4xp75_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_12),
.C(n_3),
.D(n_2),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_12),
.B1(n_14),
.B2(n_0),
.Y(n_19)
);

NOR2x1_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_12),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_15),
.B1(n_14),
.B2(n_1),
.Y(n_21)
);

OAI221xp5_ASAP7_75t_SL g22 ( 
.A1(n_19),
.A2(n_2),
.B1(n_4),
.B2(n_14),
.C(n_18),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_14),
.B(n_22),
.Y(n_23)
);


endmodule