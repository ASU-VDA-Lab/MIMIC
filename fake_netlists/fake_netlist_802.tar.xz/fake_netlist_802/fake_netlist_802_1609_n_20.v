module fake_netlist_802_1609_n_20 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_20);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

OR2x6_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_6),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_7),
.B(n_4),
.Y(n_13)
);

AO22x2_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_12),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B(n_15),
.C(n_11),
.Y(n_17)
);

NAND5xp2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.C(n_10),
.D(n_1),
.E(n_2),
.Y(n_18)
);

OAI332xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.A3(n_10),
.B1(n_6),
.B2(n_7),
.B3(n_5),
.C1(n_4),
.C2(n_3),
.Y(n_19)
);

OR2x6_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_8),
.Y(n_20)
);


endmodule