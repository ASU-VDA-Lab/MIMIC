module fake_netlist_802_3728_n_20 (n_4, n_2, n_3, n_0, n_1, n_20);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_5;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_7),
.Y(n_9)
);

NAND2x1p5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_1),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_6),
.Y(n_14)
);

AOI21xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_14),
.B(n_12),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_11),
.B1(n_5),
.B2(n_6),
.C(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_16),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_17),
.B1(n_3),
.B2(n_2),
.Y(n_20)
);


endmodule