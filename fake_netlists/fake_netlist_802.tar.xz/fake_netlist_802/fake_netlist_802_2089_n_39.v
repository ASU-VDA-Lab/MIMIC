module fake_netlist_802_2089_n_39 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_39);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_39;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_34;
wire n_23;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_4),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_SL g14 ( 
.A(n_9),
.B(n_4),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_12),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_18),
.B(n_5),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

OAI21x1_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_13),
.B(n_0),
.Y(n_24)
);

INVx4_ASAP7_75t_SL g25 ( 
.A(n_20),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

AND2x2_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_20),
.Y(n_27)
);

OAI31xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_14),
.A3(n_20),
.B(n_21),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

OAI31xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_22),
.A3(n_23),
.B(n_13),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_R g31 ( 
.A(n_30),
.B(n_24),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_27),
.Y(n_32)
);

XNOR2xp5_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_17),
.Y(n_33)
);

NAND2xp33_ASAP7_75t_SL g34 ( 
.A(n_33),
.B(n_32),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_27),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_25),
.Y(n_37)
);

INVxp67_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI322xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_6),
.A3(n_37),
.B1(n_25),
.B2(n_7),
.C1(n_3),
.C2(n_8),
.Y(n_39)
);


endmodule