module fake_netlist_802_1431_n_18 (n_4, n_2, n_5, n_3, n_0, n_1, n_18);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_18;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_16;
wire n_17;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

OR2x2_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_5),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_1),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_9),
.B(n_6),
.Y(n_10)
);

OA21x2_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.B(n_0),
.Y(n_11)
);

OAI21x1_ASAP7_75t_SL g12 ( 
.A1(n_7),
.A2(n_4),
.B(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_SL g15 ( 
.A1(n_13),
.A2(n_12),
.B1(n_11),
.B2(n_2),
.Y(n_15)
);

AOI322xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_2),
.A3(n_3),
.B1(n_11),
.B2(n_12),
.C1(n_14),
.C2(n_7),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NOR2x1p5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_11),
.Y(n_18)
);


endmodule