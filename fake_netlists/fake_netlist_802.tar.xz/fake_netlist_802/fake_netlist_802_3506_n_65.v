module fake_netlist_802_3506_n_65 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_65);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_65;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_34;
wire n_23;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_18;
wire n_64;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_11),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_12),
.B(n_9),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_8),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_15),
.B(n_16),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_5),
.Y(n_28)
);

CKINVDCx8_ASAP7_75t_R g29 ( 
.A(n_18),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

BUFx12f_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_SL g32 ( 
.A(n_19),
.B(n_14),
.C(n_13),
.Y(n_32)
);

AND2x6_ASAP7_75t_L g33 ( 
.A(n_21),
.B(n_1),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_18),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_29),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_33),
.A2(n_22),
.B1(n_24),
.B2(n_23),
.Y(n_37)
);

NAND3xp33_ASAP7_75t_SL g38 ( 
.A(n_34),
.B(n_28),
.C(n_24),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_23),
.Y(n_39)
);

OAI33xp33_ASAP7_75t_L g40 ( 
.A1(n_35),
.A2(n_28),
.A3(n_20),
.B1(n_32),
.B2(n_31),
.B3(n_33),
.Y(n_40)
);

CKINVDCx16_ASAP7_75t_R g41 ( 
.A(n_38),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_R g42 ( 
.A(n_37),
.B(n_33),
.Y(n_42)
);

INVxp67_ASAP7_75t_SL g43 ( 
.A(n_39),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_33),
.Y(n_45)
);

NAND3xp33_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_19),
.C(n_25),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_25),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_SL g49 ( 
.A1(n_44),
.A2(n_27),
.B1(n_25),
.B2(n_40),
.C(n_21),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_21),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_47),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_50),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

AOI221xp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_46),
.B1(n_27),
.B2(n_25),
.C(n_45),
.Y(n_54)
);

AOI21xp33_ASAP7_75t_L g55 ( 
.A1(n_49),
.A2(n_27),
.B(n_14),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

NAND4xp25_ASAP7_75t_SL g57 ( 
.A(n_54),
.B(n_27),
.C(n_3),
.D(n_2),
.Y(n_57)
);

AND3x4_ASAP7_75t_L g58 ( 
.A(n_52),
.B(n_27),
.C(n_4),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_51),
.B(n_7),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_55),
.Y(n_60)
);

INVx2_ASAP7_75t_SL g61 ( 
.A(n_58),
.Y(n_61)
);

NOR3x2_ASAP7_75t_L g62 ( 
.A(n_57),
.B(n_59),
.C(n_56),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_60),
.Y(n_63)
);

INVx2_ASAP7_75t_SL g64 ( 
.A(n_57),
.Y(n_64)
);

AOI222xp33_ASAP7_75t_L g65 ( 
.A1(n_64),
.A2(n_10),
.B1(n_62),
.B2(n_63),
.C1(n_61),
.C2(n_23),
.Y(n_65)
);


endmodule