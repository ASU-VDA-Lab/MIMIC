module fake_netlist_802_1079_n_43 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_43);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_43;

wire n_25;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_13),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_18),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_20),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_8),
.B(n_4),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_17),
.A2(n_16),
.B1(n_18),
.B2(n_15),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_17),
.Y(n_30)
);

AND2x6_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_29),
.Y(n_31)
);

A2O1A1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_25),
.A2(n_23),
.B(n_26),
.C(n_27),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_22),
.B1(n_24),
.B2(n_31),
.C(n_0),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_31),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_1),
.Y(n_37)
);

XNOR2xp5_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_2),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_3),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_7),
.C(n_6),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_SL g41 ( 
.A1(n_39),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_41),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_40),
.B1(n_14),
.B2(n_12),
.Y(n_43)
);


endmodule