module fake_netlist_802_959_n_31 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_31);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_31;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

INVx1_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_11),
.B2(n_10),
.Y(n_14)
);

NOR2xp67_ASAP7_75t_SL g15 ( 
.A(n_9),
.B(n_12),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_7),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_7),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

BUFx10_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_16),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

NAND5xp2_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_19),
.C(n_2),
.D(n_0),
.E(n_1),
.Y(n_23)
);

OAI32xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_20),
.A3(n_3),
.B1(n_0),
.B2(n_2),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_19),
.C(n_22),
.Y(n_25)
);

NAND4xp25_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_6),
.C(n_4),
.D(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_25),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_20),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_20),
.B1(n_6),
.B2(n_4),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_8),
.B1(n_27),
.B2(n_29),
.Y(n_31)
);


endmodule