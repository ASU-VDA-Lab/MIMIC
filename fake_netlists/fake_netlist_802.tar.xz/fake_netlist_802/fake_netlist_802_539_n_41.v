module fake_netlist_802_539_n_41 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_41);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_41;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

CKINVDCx6p67_ASAP7_75t_R g13 ( 
.A(n_9),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_10),
.B(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_2),
.B(n_0),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_SL g20 ( 
.A(n_18),
.B(n_3),
.C(n_0),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_15),
.B(n_3),
.Y(n_23)
);

AO31x2_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_17),
.A3(n_15),
.B(n_13),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

NOR3xp33_ASAP7_75t_SL g26 ( 
.A(n_19),
.B(n_12),
.C(n_14),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_R g27 ( 
.A(n_20),
.B(n_4),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_13),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_24),
.Y(n_31)
);

OA21x2_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_26),
.B(n_22),
.Y(n_32)
);

O2A1O1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_29),
.B(n_21),
.C(n_27),
.Y(n_33)
);

AOI211xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_29),
.B(n_16),
.C(n_21),
.Y(n_34)
);

NAND4xp25_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_29),
.C(n_21),
.D(n_24),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_35),
.Y(n_36)
);

OAI211xp5_ASAP7_75t_SL g37 ( 
.A1(n_34),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_33),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_16),
.B1(n_7),
.B2(n_6),
.Y(n_39)
);

CKINVDCx20_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_SL g41 ( 
.A1(n_39),
.A2(n_16),
.B1(n_40),
.B2(n_36),
.Y(n_41)
);


endmodule