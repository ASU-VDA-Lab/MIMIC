module fake_netlist_802_2359_n_51 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_51);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_51;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_17;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;
wire n_43;
wire n_45;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_8),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_3),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

INVx4_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

O2A1O1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_18),
.A2(n_7),
.B(n_5),
.C(n_4),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_SL g28 ( 
.A(n_16),
.B(n_5),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

BUFx3_ASAP7_75t_L g30 ( 
.A(n_17),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

INVx4_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_28),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_24),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_19),
.B1(n_26),
.B2(n_17),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_19),
.B1(n_26),
.B2(n_23),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_27),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_33),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_27),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_32),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_23),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

AOI22x1_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_39),
.B1(n_1),
.B2(n_0),
.Y(n_45)
);

OAI21xp5_ASAP7_75t_L g46 ( 
.A1(n_41),
.A2(n_10),
.B(n_9),
.Y(n_46)
);

NOR2xp67_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_11),
.Y(n_47)
);

CKINVDCx12_ASAP7_75t_R g48 ( 
.A(n_46),
.Y(n_48)
);

OAI211xp5_ASAP7_75t_SL g49 ( 
.A1(n_46),
.A2(n_14),
.B(n_15),
.C(n_45),
.Y(n_49)
);

INVx8_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_49),
.B1(n_48),
.B2(n_47),
.Y(n_51)
);


endmodule