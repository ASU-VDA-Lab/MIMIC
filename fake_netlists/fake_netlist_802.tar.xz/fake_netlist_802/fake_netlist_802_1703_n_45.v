module fake_netlist_802_1703_n_45 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_45);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_45;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_44;
wire n_28;
wire n_39;
wire n_40;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

INVx1_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_6),
.B(n_15),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_2),
.A2(n_0),
.B1(n_19),
.B2(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

BUFx12f_ASAP7_75t_SL g29 ( 
.A(n_21),
.Y(n_29)
);

A2O1A1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_22),
.A2(n_17),
.B(n_16),
.C(n_1),
.Y(n_30)
);

NOR2x1_ASAP7_75t_R g31 ( 
.A(n_24),
.B(n_18),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_22),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_28),
.B1(n_27),
.B2(n_26),
.Y(n_33)
);

AO21x2_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_30),
.B(n_20),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_33),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_25),
.Y(n_36)
);

AOI33xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_23),
.A3(n_21),
.B1(n_31),
.B2(n_4),
.B3(n_3),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_35),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

XNOR2x1_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_7),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_8),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

AOI322xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_40),
.A3(n_42),
.B1(n_11),
.B2(n_13),
.C1(n_9),
.C2(n_10),
.Y(n_45)
);


endmodule