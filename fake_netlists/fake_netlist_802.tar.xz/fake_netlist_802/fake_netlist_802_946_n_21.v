module fake_netlist_802_946_n_21 (n_2, n_0, n_3, n_1, n_21);

input n_2;
input n_0;
input n_3;
input n_1;

output n_21;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_4;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_5;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_6),
.Y(n_12)
);

AOI211xp5_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_4),
.B(n_5),
.C(n_0),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_13),
.B1(n_11),
.B2(n_9),
.C(n_2),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_8),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_9),
.B(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_15),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_12),
.B(n_13),
.Y(n_18)
);

INVx2_ASAP7_75t_SL g19 ( 
.A(n_17),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_14),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_3),
.B1(n_9),
.B2(n_19),
.Y(n_21)
);


endmodule