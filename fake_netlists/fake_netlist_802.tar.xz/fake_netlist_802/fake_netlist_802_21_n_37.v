module fake_netlist_802_21_n_37 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_37);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_37;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_35;
wire n_11;
wire n_27;

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_9),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_2),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

INVx4_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

O2A1O1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_SL g17 ( 
.A1(n_12),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_SL g18 ( 
.A(n_11),
.B(n_6),
.C(n_5),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_8),
.B(n_7),
.C(n_6),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_15),
.Y(n_20)
);

INVx2_ASAP7_75t_SL g21 ( 
.A(n_13),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_17),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_13),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_13),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_19),
.Y(n_28)
);

NAND5xp2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_16),
.C(n_22),
.D(n_18),
.E(n_15),
.Y(n_29)
);

AOI31xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_22),
.A3(n_14),
.B(n_25),
.Y(n_30)
);

NOR2x1_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_10),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_17),
.B1(n_28),
.B2(n_27),
.C1(n_26),
.C2(n_14),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_31),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_31),
.Y(n_35)
);

AOI21xp33_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_30),
.B(n_7),
.Y(n_36)
);

AOI222xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_24),
.B1(n_33),
.B2(n_34),
.C1(n_17),
.C2(n_31),
.Y(n_37)
);


endmodule