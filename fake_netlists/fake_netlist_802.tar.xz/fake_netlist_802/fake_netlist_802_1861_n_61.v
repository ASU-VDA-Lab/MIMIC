module fake_netlist_802_1861_n_61 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_61);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_61;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_44;
wire n_40;
wire n_39;
wire n_28;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_18;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx2_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_4),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_13),
.Y(n_20)
);

XNOR2xp5_ASAP7_75t_L g21 ( 
.A(n_9),
.B(n_6),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_8),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_14),
.B(n_1),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_17),
.B(n_11),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_7),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_24),
.B(n_0),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_20),
.B(n_12),
.Y(n_30)
);

OA21x2_ASAP7_75t_L g31 ( 
.A1(n_18),
.A2(n_1),
.B(n_0),
.Y(n_31)
);

NAND2x1p5_ASAP7_75t_L g32 ( 
.A(n_27),
.B(n_24),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_23),
.A2(n_5),
.B(n_3),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_18),
.B(n_3),
.Y(n_34)
);

A2O1A1Ixp33_ASAP7_75t_L g35 ( 
.A1(n_27),
.A2(n_9),
.B(n_8),
.C(n_5),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_23),
.Y(n_36)
);

OR2x6_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_27),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_36),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_32),
.A2(n_19),
.B1(n_26),
.B2(n_22),
.Y(n_39)
);

CKINVDCx16_ASAP7_75t_R g40 ( 
.A(n_30),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_29),
.B(n_36),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_29),
.B(n_26),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

NOR2x1_ASAP7_75t_L g44 ( 
.A(n_37),
.B(n_35),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_37),
.B(n_31),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_38),
.Y(n_46)
);

AOI33xp33_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_39),
.A3(n_23),
.B1(n_18),
.B2(n_42),
.B3(n_34),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_44),
.A2(n_21),
.B1(n_31),
.B2(n_40),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_40),
.Y(n_50)
);

OAI221xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_46),
.B1(n_21),
.B2(n_45),
.C(n_33),
.Y(n_51)
);

AOI211xp5_ASAP7_75t_SL g52 ( 
.A1(n_49),
.A2(n_45),
.B(n_33),
.C(n_25),
.Y(n_52)
);

OAI221xp5_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_31),
.B1(n_28),
.B2(n_10),
.C(n_11),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_48),
.A2(n_31),
.B1(n_16),
.B2(n_10),
.Y(n_54)
);

HB1xp67_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

CKINVDCx5p33_ASAP7_75t_R g56 ( 
.A(n_54),
.Y(n_56)
);

INVxp67_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

OR2x6_ASAP7_75t_L g58 ( 
.A(n_52),
.B(n_48),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_47),
.B1(n_17),
.B2(n_16),
.Y(n_59)
);

NOR2xp33_ASAP7_75t_L g60 ( 
.A(n_57),
.B(n_58),
.Y(n_60)
);

AOI22xp33_ASAP7_75t_L g61 ( 
.A1(n_59),
.A2(n_58),
.B1(n_55),
.B2(n_60),
.Y(n_61)
);


endmodule