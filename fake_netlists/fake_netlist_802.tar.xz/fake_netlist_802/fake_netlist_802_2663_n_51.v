module fake_netlist_802_2663_n_51 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_51);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_51;

wire n_49;
wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_4),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_11),
.B(n_9),
.Y(n_28)
);

INVxp67_ASAP7_75t_SL g29 ( 
.A(n_17),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_6),
.B(n_22),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_0),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_15),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_25),
.B(n_16),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_17),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_23),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_24),
.A2(n_19),
.B1(n_18),
.B2(n_1),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_SL g38 ( 
.A1(n_35),
.A2(n_29),
.B1(n_24),
.B2(n_23),
.Y(n_38)
);

AOI211x1_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_33),
.B(n_31),
.C(n_28),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_18),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_27),
.Y(n_42)
);

NOR2x1_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_30),
.Y(n_43)
);

NAND4xp25_ASAP7_75t_SL g44 ( 
.A(n_42),
.B(n_36),
.C(n_32),
.D(n_27),
.Y(n_44)
);

NAND4xp25_ASAP7_75t_SL g45 ( 
.A(n_43),
.B(n_42),
.C(n_32),
.D(n_2),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_3),
.Y(n_47)
);

NOR4xp25_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_10),
.C(n_8),
.D(n_5),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

AOI322xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_12),
.A3(n_13),
.B1(n_14),
.B2(n_20),
.C1(n_48),
.C2(n_50),
.Y(n_51)
);


endmodule