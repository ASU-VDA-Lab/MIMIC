module fake_netlist_620_183_n_14 (n_1, n_2, n_3, n_0, n_14);

input n_1;
input n_2;
input n_3;
input n_0;

output n_14;

wire n_7;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;
wire n_9;

INVx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx4_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AOI211xp5_ASAP7_75t_SL g10 ( 
.A1(n_8),
.A2(n_6),
.B(n_1),
.C(n_0),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_8),
.B(n_9),
.C(n_1),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_9),
.C(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

OAI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_3),
.B1(n_9),
.B2(n_12),
.Y(n_14)
);


endmodule