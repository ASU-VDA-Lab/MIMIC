module fake_netlist_620_1402_n_32 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_17, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_32);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_17;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_32;

wire n_31;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_9),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_5),
.Y(n_22)
);

NOR2xp67_ASAP7_75t_L g23 ( 
.A(n_7),
.B(n_17),
.Y(n_23)
);

INVx5_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

O2A1O1Ixp33_ASAP7_75t_SL g25 ( 
.A1(n_22),
.A2(n_6),
.B(n_3),
.C(n_1),
.Y(n_25)
);

INVxp33_ASAP7_75t_SL g26 ( 
.A(n_24),
.Y(n_26)
);

OR2x6_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_23),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_25),
.B1(n_19),
.B2(n_18),
.C(n_20),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_SL g30 ( 
.A(n_29),
.B(n_8),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.Y(n_32)
);


endmodule