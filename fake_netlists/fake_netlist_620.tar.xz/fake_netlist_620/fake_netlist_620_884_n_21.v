module fake_netlist_620_884_n_21 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_21);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_21;

wire n_15;
wire n_18;
wire n_17;
wire n_19;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

INVx2_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_10),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

NAND2x1p5_ASAP7_75t_L g15 ( 
.A(n_0),
.B(n_3),
.Y(n_15)
);

BUFx5_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.B(n_2),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_5),
.B1(n_4),
.B2(n_6),
.C1(n_9),
.C2(n_7),
.Y(n_21)
);


endmodule