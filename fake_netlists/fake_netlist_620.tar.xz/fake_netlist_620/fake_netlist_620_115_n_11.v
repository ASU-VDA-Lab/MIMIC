module fake_netlist_620_115_n_11 (n_1, n_2, n_0, n_11);

input n_1;
input n_2;
input n_0;

output n_11;

wire n_7;
wire n_9;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_3;

BUFx6f_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

BUFx10_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

NAND2x1p5_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

O2A1O1Ixp5_ASAP7_75t_R g7 ( 
.A1(n_6),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_7)
);

A2O1A1Ixp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_6),
.B(n_3),
.C(n_4),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI222xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C1(n_4),
.C2(n_7),
.Y(n_11)
);


endmodule