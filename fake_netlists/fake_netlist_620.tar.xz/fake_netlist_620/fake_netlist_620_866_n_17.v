module fake_netlist_620_866_n_17 (n_5, n_0, n_4, n_1, n_2, n_3, n_17);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_17;

wire n_7;
wire n_11;
wire n_16;
wire n_8;
wire n_15;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

INVxp67_ASAP7_75t_SL g6 ( 
.A(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_4),
.B(n_5),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_7),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_8),
.B1(n_13),
.B2(n_11),
.Y(n_14)
);

AOI211xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B(n_9),
.C(n_1),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_9),
.B1(n_4),
.B2(n_3),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_R g17 ( 
.A1(n_16),
.A2(n_9),
.B1(n_10),
.B2(n_7),
.Y(n_17)
);


endmodule