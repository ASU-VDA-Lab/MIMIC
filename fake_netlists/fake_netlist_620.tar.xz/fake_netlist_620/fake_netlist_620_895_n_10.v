module fake_netlist_620_895_n_10 (n_1, n_2, n_0, n_10);

input n_1;
input n_2;
input n_0;

output n_10;

wire n_7;
wire n_9;
wire n_8;
wire n_5;
wire n_6;
wire n_4;
wire n_3;

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_1),
.Y(n_4)
);

AO21x2_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_5)
);

OR2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_4),
.B1(n_5),
.B2(n_3),
.Y(n_7)
);

OAI211xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI222xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_4),
.C2(n_8),
.Y(n_10)
);


endmodule