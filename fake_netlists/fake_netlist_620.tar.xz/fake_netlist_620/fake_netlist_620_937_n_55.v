module fake_netlist_620_937_n_55 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_55);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_55;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_50;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_3),
.B(n_11),
.Y(n_17)
);

OA21x2_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_5),
.B(n_16),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_SL g19 ( 
.A(n_9),
.B(n_0),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_10),
.A2(n_1),
.B1(n_5),
.B2(n_3),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_7),
.Y(n_21)
);

AOI22x1_ASAP7_75t_R g22 ( 
.A1(n_15),
.A2(n_8),
.B1(n_11),
.B2(n_4),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_0),
.B(n_16),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_1),
.B(n_2),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_23),
.B(n_2),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_6),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_21),
.B(n_6),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_23),
.B(n_12),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_13),
.Y(n_30)
);

NAND2x1_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_18),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

OAI22xp33_ASAP7_75t_L g33 ( 
.A1(n_26),
.A2(n_19),
.B1(n_24),
.B2(n_20),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_23),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_25),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_20),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_23),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_35),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_35),
.Y(n_39)
);

INVx3_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_40),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

A2O1A1Ixp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_35),
.B(n_30),
.C(n_34),
.Y(n_43)
);

OAI221xp5_ASAP7_75t_SL g44 ( 
.A1(n_38),
.A2(n_33),
.B1(n_24),
.B2(n_22),
.C(n_35),
.Y(n_44)
);

NOR4xp75_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_17),
.C(n_29),
.D(n_19),
.Y(n_45)
);

INVxp67_ASAP7_75t_SL g46 ( 
.A(n_41),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_34),
.Y(n_47)
);

NOR4xp25_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_23),
.C(n_18),
.D(n_34),
.Y(n_48)
);

XNOR2x1_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_42),
.Y(n_49)
);

BUFx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

AND2x4_ASAP7_75t_L g51 ( 
.A(n_45),
.B(n_34),
.Y(n_51)
);

OAI22x1_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_47),
.B1(n_18),
.B2(n_48),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_18),
.B1(n_34),
.B2(n_51),
.Y(n_53)
);

OA22x2_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_51),
.B1(n_49),
.B2(n_34),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_52),
.B(n_51),
.Y(n_55)
);


endmodule