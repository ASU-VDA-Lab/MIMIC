module fake_netlist_620_936_n_31 (n_7, n_9, n_11, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_31);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_31;

wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_9),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_19),
.B(n_4),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_16),
.B(n_6),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

OAI222xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_24),
.B1(n_21),
.B2(n_16),
.C1(n_17),
.C2(n_18),
.Y(n_26)
);

AOI321xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_15),
.A3(n_6),
.B1(n_20),
.B2(n_1),
.C(n_0),
.Y(n_27)
);

NOR2x1_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_2),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_27),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_15),
.B1(n_11),
.B2(n_10),
.Y(n_30)
);

OAI221xp5_ASAP7_75t_R g31 ( 
.A1(n_30),
.A2(n_28),
.B1(n_14),
.B2(n_12),
.C(n_13),
.Y(n_31)
);


endmodule