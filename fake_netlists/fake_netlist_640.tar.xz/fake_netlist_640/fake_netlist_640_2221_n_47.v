module fake_netlist_640_2221_n_47 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_47);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_47;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_R g25 ( 
.A(n_8),
.B(n_23),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_19),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_18),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_22),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_13),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_10),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_3),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_24),
.A2(n_26),
.B1(n_27),
.B2(n_29),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

A2O1A1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_12),
.B(n_14),
.C(n_11),
.Y(n_34)
);

CKINVDCx16_ASAP7_75t_R g35 ( 
.A(n_32),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_33),
.A2(n_28),
.B1(n_12),
.B2(n_25),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_34),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_38),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_7),
.Y(n_41)
);

AOI211xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_20),
.B(n_17),
.C(n_6),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_41),
.Y(n_43)
);

XOR2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_40),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_15),
.B(n_5),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_16),
.B1(n_2),
.B2(n_4),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_0),
.B1(n_1),
.B2(n_45),
.Y(n_47)
);


endmodule