module fake_netlist_640_106_n_15 (n_4, n_1, n_2, n_0, n_5, n_3, n_15);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_15;

wire n_9;
wire n_7;
wire n_14;
wire n_13;
wire n_12;
wire n_10;
wire n_11;
wire n_8;
wire n_6;

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B1(n_5),
.B2(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_2),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_1),
.B(n_2),
.Y(n_10)
);

OAI22xp33_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_1),
.B1(n_0),
.B2(n_4),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_7),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_7),
.B(n_3),
.Y(n_15)
);


endmodule