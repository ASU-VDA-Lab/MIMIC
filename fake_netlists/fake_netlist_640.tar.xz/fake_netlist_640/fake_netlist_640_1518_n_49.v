module fake_netlist_640_1518_n_49 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_49);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_49;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_22),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_24),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_2),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_R g30 ( 
.A(n_6),
.B(n_17),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_21),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_15),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

OAI22x1_ASAP7_75t_L g35 ( 
.A1(n_26),
.A2(n_12),
.B1(n_13),
.B2(n_14),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_28),
.B(n_29),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_SL g37 ( 
.A(n_35),
.B(n_30),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_33),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_25),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_36),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_32),
.Y(n_41)
);

AOI21xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_16),
.B(n_9),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_23),
.B(n_19),
.C(n_7),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_8),
.B(n_5),
.Y(n_44)
);

CKINVDCx16_ASAP7_75t_R g45 ( 
.A(n_43),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_3),
.B1(n_11),
.B2(n_4),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_0),
.B1(n_1),
.B2(n_47),
.Y(n_49)
);


endmodule