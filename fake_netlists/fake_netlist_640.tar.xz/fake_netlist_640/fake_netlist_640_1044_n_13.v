module fake_netlist_640_1044_n_13 (n_3, n_1, n_2, n_0, n_13);

input n_3;
input n_1;
input n_2;
input n_0;

output n_13;

wire n_4;
wire n_7;
wire n_10;
wire n_5;
wire n_12;
wire n_11;
wire n_8;
wire n_6;
wire n_9;

BUFx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVxp67_ASAP7_75t_SL g5 ( 
.A(n_0),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

HB1xp67_ASAP7_75t_SL g7 ( 
.A(n_4),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_7),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_6),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_5),
.B1(n_9),
.B2(n_0),
.C(n_3),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_5),
.B(n_2),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.Y(n_13)
);


endmodule