module fake_netlist_640_1997_n_34 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_34);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_34;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

NAND2xp33_ASAP7_75t_R g18 ( 
.A(n_5),
.B(n_2),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_10),
.B(n_15),
.Y(n_23)
);

AOI22x1_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_16),
.B1(n_8),
.B2(n_17),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_22),
.B1(n_19),
.B2(n_20),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B1(n_23),
.B2(n_19),
.C(n_18),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_18),
.B1(n_8),
.B2(n_11),
.C1(n_9),
.C2(n_12),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_30),
.B(n_13),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_6),
.B1(n_14),
.B2(n_7),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.B1(n_4),
.B2(n_1),
.Y(n_34)
);


endmodule