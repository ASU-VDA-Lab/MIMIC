module fake_netlist_640_2091_n_46 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_46);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_46;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_45;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_39;
wire n_27;
wire n_21;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

BUFx2_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_6),
.B(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

O2A1O1Ixp5_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_11),
.B(n_9),
.C(n_10),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_12),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_15),
.B(n_12),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_15),
.B(n_13),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_16),
.B(n_9),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_22),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

INVx8_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_25),
.B(n_28),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_20),
.Y(n_35)
);

O2A1O1Ixp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_32),
.B(n_31),
.C(n_29),
.Y(n_36)
);

AOI21xp33_ASAP7_75t_SL g37 ( 
.A1(n_33),
.A2(n_21),
.B(n_19),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_32),
.Y(n_38)
);

AOI211xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_20),
.B(n_17),
.C(n_19),
.Y(n_39)
);

AOI322xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_23),
.A3(n_33),
.B1(n_18),
.B2(n_11),
.C1(n_1),
.C2(n_3),
.Y(n_40)
);

OAI221xp5_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_37),
.B1(n_18),
.B2(n_23),
.C(n_3),
.Y(n_41)
);

NOR4xp25_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_39),
.C(n_8),
.D(n_2),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AO22x1_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_5),
.B1(n_8),
.B2(n_2),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_14),
.B1(n_23),
.B2(n_45),
.Y(n_46)
);


endmodule