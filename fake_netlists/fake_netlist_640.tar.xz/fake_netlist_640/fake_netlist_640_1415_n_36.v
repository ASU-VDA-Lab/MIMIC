module fake_netlist_640_1415_n_36 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_36);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_36;

wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

INVx3_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

BUFx8_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_15),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_9),
.C(n_19),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_9),
.B1(n_17),
.B2(n_14),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_SL g29 ( 
.A(n_27),
.B(n_24),
.C(n_26),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_29),
.B(n_21),
.Y(n_32)
);

AOI222xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_22),
.B1(n_25),
.B2(n_8),
.C1(n_7),
.C2(n_10),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

OAI22x1_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_13),
.B1(n_11),
.B2(n_4),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.Y(n_36)
);


endmodule