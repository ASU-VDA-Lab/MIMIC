module fake_netlist_640_2106_n_19 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_19);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_19;

wire n_18;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_1),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_2),
.C(n_6),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AOI211x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B(n_7),
.C(n_14),
.Y(n_16)
);

NAND2x1p5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_15),
.Y(n_17)
);

AOI22x1_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_4),
.B2(n_5),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.B1(n_4),
.B2(n_0),
.Y(n_19)
);


endmodule