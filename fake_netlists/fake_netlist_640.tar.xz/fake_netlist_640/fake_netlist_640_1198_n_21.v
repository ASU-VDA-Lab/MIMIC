module fake_netlist_640_1198_n_21 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_21);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

AND2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_SL g13 ( 
.A(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_L g15 ( 
.A(n_6),
.B(n_10),
.C(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI21xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_12),
.B(n_13),
.Y(n_17)
);

OAI21xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_15),
.B(n_0),
.Y(n_18)
);

AND3x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_0),
.C(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_R g21 ( 
.A1(n_20),
.A2(n_2),
.B1(n_3),
.B2(n_9),
.Y(n_21)
);


endmodule