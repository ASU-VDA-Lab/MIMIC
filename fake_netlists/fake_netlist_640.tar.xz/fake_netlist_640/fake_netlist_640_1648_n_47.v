module fake_netlist_640_1648_n_47 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_47);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_47;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_1),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_4),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_0),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_18),
.B(n_15),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_9),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_12),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_28),
.A2(n_16),
.B(n_13),
.Y(n_34)
);

OR2x6_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_29),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_31),
.Y(n_36)
);

OA21x2_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_34),
.B(n_25),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_27),
.Y(n_38)
);

OAI32xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_30),
.A3(n_26),
.B1(n_24),
.B2(n_35),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_17),
.Y(n_40)
);

OAI31xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_37),
.A3(n_12),
.B(n_23),
.Y(n_41)
);

AOI211xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_23),
.B(n_20),
.C(n_22),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_42),
.Y(n_43)
);

OAI211xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_11),
.B(n_10),
.C(n_7),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OAI22x1_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_14),
.B1(n_5),
.B2(n_6),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_46),
.B1(n_2),
.B2(n_3),
.Y(n_47)
);


endmodule