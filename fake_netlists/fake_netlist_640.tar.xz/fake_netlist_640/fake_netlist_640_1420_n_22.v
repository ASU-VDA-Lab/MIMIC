module fake_netlist_640_1420_n_22 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_22);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_22;

wire n_18;
wire n_19;
wire n_15;
wire n_11;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

INVxp67_ASAP7_75t_SL g11 ( 
.A(n_2),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_8),
.B(n_6),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B1(n_12),
.B2(n_1),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_0),
.C(n_15),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_12),
.C(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_5),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_3),
.B(n_4),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_R g22 ( 
.A(n_21),
.B(n_10),
.Y(n_22)
);


endmodule