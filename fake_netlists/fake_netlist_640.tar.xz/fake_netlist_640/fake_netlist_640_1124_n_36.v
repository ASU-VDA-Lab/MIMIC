module fake_netlist_640_1124_n_36 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_36);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_36;

wire n_18;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_17;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_9),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_6),
.B(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_15),
.B(n_13),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_18),
.A2(n_5),
.B(n_4),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

INVx5_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_24),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_26),
.Y(n_30)
);

AOI321xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_20),
.A3(n_23),
.B1(n_19),
.B2(n_26),
.C(n_15),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_22),
.B(n_17),
.C(n_14),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_17),
.B1(n_22),
.B2(n_8),
.Y(n_34)
);

AOI22x1_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.Y(n_35)
);

OAI321xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_2),
.A3(n_8),
.B1(n_10),
.B2(n_16),
.C(n_35),
.Y(n_36)
);


endmodule