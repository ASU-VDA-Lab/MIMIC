module fake_netlist_640_1634_n_79 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_79);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_79;

wire n_62;
wire n_70;
wire n_38;
wire n_58;
wire n_57;
wire n_35;
wire n_45;
wire n_78;
wire n_66;
wire n_60;
wire n_39;
wire n_63;
wire n_31;
wire n_37;
wire n_71;
wire n_40;
wire n_28;
wire n_49;
wire n_53;
wire n_77;
wire n_75;
wire n_48;
wire n_41;
wire n_65;
wire n_33;
wire n_43;
wire n_61;
wire n_72;
wire n_51;
wire n_54;
wire n_68;
wire n_27;
wire n_67;
wire n_29;
wire n_52;
wire n_50;
wire n_26;
wire n_76;
wire n_36;
wire n_59;
wire n_34;
wire n_64;
wire n_44;
wire n_30;
wire n_73;
wire n_56;
wire n_69;
wire n_46;
wire n_42;
wire n_55;
wire n_74;
wire n_32;
wire n_47;

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_3),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_1),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_23),
.B(n_9),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_8),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_14),
.A2(n_7),
.B1(n_22),
.B2(n_0),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_10),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_11),
.B(n_25),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_23),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_4),
.B(n_21),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_35),
.B(n_24),
.Y(n_39)
);

AND3x1_ASAP7_75t_SL g40 ( 
.A(n_30),
.B(n_24),
.C(n_13),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_28),
.A2(n_18),
.B(n_16),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_34),
.Y(n_42)
);

BUFx6f_ASAP7_75t_L g43 ( 
.A(n_26),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_28),
.B(n_27),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_27),
.B(n_25),
.Y(n_45)
);

OA21x2_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_29),
.B(n_32),
.Y(n_46)
);

INVxp67_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

CKINVDCx6p67_ASAP7_75t_R g48 ( 
.A(n_42),
.Y(n_48)
);

OAI21x1_ASAP7_75t_L g49 ( 
.A1(n_41),
.A2(n_38),
.B(n_29),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_39),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_46),
.B(n_43),
.Y(n_53)
);

INVx2_ASAP7_75t_SL g54 ( 
.A(n_52),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_47),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_48),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_37),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

INVx1_ASAP7_75t_SL g60 ( 
.A(n_56),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_53),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_61),
.B(n_55),
.Y(n_62)
);

OAI21xp5_ASAP7_75t_L g63 ( 
.A1(n_61),
.A2(n_55),
.B(n_49),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_58),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_59),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_60),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_62),
.Y(n_67)
);

AOI221xp5_ASAP7_75t_SL g68 ( 
.A1(n_66),
.A2(n_33),
.B1(n_31),
.B2(n_34),
.C(n_36),
.Y(n_68)
);

NOR3xp33_ASAP7_75t_L g69 ( 
.A(n_63),
.B(n_40),
.C(n_26),
.Y(n_69)
);

NAND3xp33_ASAP7_75t_L g70 ( 
.A(n_64),
.B(n_26),
.C(n_43),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_65),
.Y(n_71)
);

INVx1_ASAP7_75t_SL g72 ( 
.A(n_71),
.Y(n_72)
);

XNOR2x1_ASAP7_75t_L g73 ( 
.A(n_67),
.B(n_26),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_L g74 ( 
.A(n_67),
.B(n_69),
.Y(n_74)
);

INVx2_ASAP7_75t_L g75 ( 
.A(n_70),
.Y(n_75)
);

OAI221xp5_ASAP7_75t_L g76 ( 
.A1(n_73),
.A2(n_68),
.B1(n_63),
.B2(n_43),
.C(n_15),
.Y(n_76)
);

OAI22xp33_ASAP7_75t_L g77 ( 
.A1(n_74),
.A2(n_72),
.B1(n_75),
.B2(n_12),
.Y(n_77)
);

AOI22x1_ASAP7_75t_L g78 ( 
.A1(n_72),
.A2(n_6),
.B1(n_20),
.B2(n_2),
.Y(n_78)
);

AOI22xp33_ASAP7_75t_SL g79 ( 
.A1(n_76),
.A2(n_5),
.B1(n_78),
.B2(n_77),
.Y(n_79)
);


endmodule