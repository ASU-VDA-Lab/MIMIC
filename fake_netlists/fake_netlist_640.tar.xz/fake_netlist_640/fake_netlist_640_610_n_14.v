module fake_netlist_640_610_n_14 (n_3, n_1, n_2, n_0, n_14);

input n_3;
input n_1;
input n_2;
input n_0;

output n_14;

wire n_9;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_5),
.B(n_2),
.Y(n_6)
);

A2O1A1Ixp33_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_2),
.B(n_3),
.C(n_0),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.Y(n_9)
);

OAI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B1(n_8),
.B2(n_3),
.C(n_0),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AOI221x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_8),
.B1(n_9),
.B2(n_2),
.C(n_1),
.Y(n_13)
);

AOI22x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_1),
.B1(n_11),
.B2(n_12),
.Y(n_14)
);


endmodule