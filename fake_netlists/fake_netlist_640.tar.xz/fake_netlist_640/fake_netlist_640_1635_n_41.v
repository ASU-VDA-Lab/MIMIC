module fake_netlist_640_1635_n_41 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_41);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_41;

wire n_36;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

INVx2_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_1),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

NOR2xp67_ASAP7_75t_L g26 ( 
.A(n_8),
.B(n_3),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_15),
.Y(n_28)
);

OA22x2_ASAP7_75t_L g29 ( 
.A1(n_22),
.A2(n_27),
.B1(n_28),
.B2(n_23),
.Y(n_29)
);

A2O1A1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_10),
.B(n_12),
.C(n_13),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_24),
.A2(n_10),
.B1(n_20),
.B2(n_18),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_26),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NOR2xp67_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_31),
.Y(n_34)
);

O2A1O1Ixp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_32),
.B(n_24),
.C(n_14),
.Y(n_35)
);

AOI321xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_16),
.A3(n_9),
.B1(n_11),
.B2(n_7),
.C(n_19),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_35),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_37),
.Y(n_38)
);

INVxp33_ASAP7_75t_SL g39 ( 
.A(n_36),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_38),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_2),
.B1(n_6),
.B2(n_0),
.Y(n_41)
);


endmodule