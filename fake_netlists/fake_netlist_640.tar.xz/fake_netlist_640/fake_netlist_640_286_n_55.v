module fake_netlist_640_286_n_55 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_55);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_55;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_17;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

AND2x6_ASAP7_75t_L g17 ( 
.A(n_8),
.B(n_13),
.Y(n_17)
);

CKINVDCx16_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_4),
.B(n_2),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_16),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_14),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

NOR2x1_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_14),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_18),
.B(n_10),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_16),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_21),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_12),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_23),
.B1(n_21),
.B2(n_20),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_25),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_27),
.A2(n_17),
.B1(n_19),
.B2(n_20),
.Y(n_35)
);

NOR2x1_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_27),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_17),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

CKINVDCx16_ASAP7_75t_R g41 ( 
.A(n_38),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_34),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_41),
.B1(n_40),
.B2(n_17),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_28),
.Y(n_44)
);

OAI22xp33_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_20),
.B1(n_24),
.B2(n_17),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

NOR3x1_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_12),
.C(n_13),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

OAI211xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_24),
.B(n_15),
.C(n_9),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_24),
.B1(n_15),
.B2(n_3),
.Y(n_50)
);

OAI21xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_24),
.B(n_1),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_51),
.B1(n_46),
.B2(n_44),
.Y(n_54)
);

NAND3xp33_ASAP7_75t_L g55 ( 
.A(n_54),
.B(n_53),
.C(n_52),
.Y(n_55)
);


endmodule