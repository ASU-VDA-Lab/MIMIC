module fake_netlist_640_1472_n_47 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_47);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_47;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_23;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_12),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND2x1p5_ASAP7_75t_L g25 ( 
.A(n_5),
.B(n_11),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_1),
.A2(n_13),
.B1(n_21),
.B2(n_4),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_22),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_18),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_7),
.B(n_3),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_8),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_9),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

AOI22x1_ASAP7_75t_SL g34 ( 
.A1(n_27),
.A2(n_10),
.B1(n_14),
.B2(n_2),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_10),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_24),
.B1(n_26),
.B2(n_28),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_25),
.B1(n_30),
.B2(n_31),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_33),
.Y(n_38)
);

OAI221xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_25),
.B1(n_23),
.B2(n_29),
.C(n_34),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_17),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_34),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_R g44 ( 
.A(n_43),
.B(n_42),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_19),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_SL g47 ( 
.A1(n_46),
.A2(n_0),
.B1(n_6),
.B2(n_16),
.Y(n_47)
);


endmodule