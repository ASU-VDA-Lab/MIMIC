module fake_netlist_640_346_n_18 (n_4, n_1, n_2, n_0, n_5, n_3, n_18);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_18;

wire n_9;
wire n_7;
wire n_17;
wire n_14;
wire n_13;
wire n_10;
wire n_12;
wire n_16;
wire n_11;
wire n_8;
wire n_15;
wire n_6;

INVx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_0),
.Y(n_9)
);

OAI21xp33_ASAP7_75t_SL g10 ( 
.A1(n_6),
.A2(n_1),
.B(n_4),
.Y(n_10)
);

NOR2xp67_ASAP7_75t_SL g11 ( 
.A(n_6),
.B(n_3),
.Y(n_11)
);

NOR3xp33_ASAP7_75t_SL g12 ( 
.A(n_10),
.B(n_7),
.C(n_9),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);

NOR4xp75_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_11),
.C(n_3),
.D(n_0),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_8),
.B1(n_2),
.B2(n_5),
.Y(n_18)
);


endmodule