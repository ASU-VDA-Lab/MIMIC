module fake_netlist_779_2139_n_21 (n_1, n_0, n_5, n_3, n_2, n_4, n_21);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_21;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_14;

INVx3_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_0),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_6),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_15),
.B(n_7),
.Y(n_16)
);

NOR2x1_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_8),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_R g21 ( 
.A1(n_20),
.A2(n_18),
.B1(n_5),
.B2(n_1),
.C(n_3),
.Y(n_21)
);


endmodule