module fake_netlist_779_826_n_26 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_4, n_8, n_26);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_4;
input n_8;

output n_26;

wire n_20;
wire n_17;
wire n_25;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_SL g13 ( 
.A(n_0),
.Y(n_13)
);

AND2x2_ASAP7_75t_SL g14 ( 
.A(n_12),
.B(n_11),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_2),
.B(n_7),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_8),
.B(n_1),
.Y(n_19)
);

AO31x2_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_7),
.A3(n_6),
.B(n_9),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_15),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_20),
.Y(n_22)
);

AOI211xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B(n_17),
.C(n_16),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_23),
.B(n_14),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_20),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_10),
.Y(n_26)
);


endmodule