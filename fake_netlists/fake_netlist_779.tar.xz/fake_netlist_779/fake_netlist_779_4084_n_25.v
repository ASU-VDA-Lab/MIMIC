module fake_netlist_779_4084_n_25 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_25);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_25;

wire n_20;
wire n_17;
wire n_12;
wire n_24;
wire n_18;
wire n_13;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_3),
.B(n_5),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_4),
.Y(n_17)
);

INVxp67_ASAP7_75t_SL g18 ( 
.A(n_16),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.Y(n_22)
);

OAI322xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_17),
.A3(n_14),
.B1(n_12),
.B2(n_6),
.C1(n_4),
.C2(n_7),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI322xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_13),
.A3(n_7),
.B1(n_6),
.B2(n_1),
.C1(n_0),
.C2(n_2),
.Y(n_25)
);


endmodule