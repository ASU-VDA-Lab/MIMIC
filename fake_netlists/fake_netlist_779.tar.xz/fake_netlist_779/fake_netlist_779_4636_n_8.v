module fake_netlist_779_4636_n_8 (n_1, n_2, n_0, n_8);

input n_1;
input n_2;
input n_0;

output n_8;

wire n_7;
wire n_5;
wire n_6;
wire n_3;
wire n_4;

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_1),
.B(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AOI221xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.C(n_0),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

AOI22x1_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_2),
.B1(n_5),
.B2(n_3),
.Y(n_8)
);


endmodule