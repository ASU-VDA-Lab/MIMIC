module fake_netlist_779_298_n_29 (n_1, n_0, n_5, n_3, n_2, n_4, n_29);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_29;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_16;
wire n_11;
wire n_23;
wire n_28;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

NAND2xp33_ASAP7_75t_SL g9 ( 
.A(n_5),
.B(n_1),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_2),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_0),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_3),
.Y(n_15)
);

NAND3x1_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_4),
.C(n_3),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_10),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_19),
.B1(n_16),
.B2(n_11),
.Y(n_23)
);

AOI21xp33_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_20),
.B(n_16),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_9),
.Y(n_25)
);

NOR2xp67_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_22),
.Y(n_26)
);

AND3x1_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_23),
.C(n_21),
.Y(n_27)
);

AO22x2_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_5),
.B1(n_23),
.B2(n_27),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_28),
.B(n_5),
.Y(n_29)
);


endmodule