module fake_netlist_779_2458_n_18 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_18);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_18;

wire n_15;
wire n_16;
wire n_11;
wire n_14;
wire n_17;
wire n_12;
wire n_13;

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_1),
.Y(n_11)
);

NAND2x1p5_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_7),
.Y(n_12)
);

AO22x1_ASAP7_75t_L g13 ( 
.A1(n_4),
.A2(n_3),
.B1(n_10),
.B2(n_5),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

AND3x1_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.C(n_7),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_11),
.B1(n_8),
.B2(n_2),
.Y(n_18)
);


endmodule