module fake_netlist_779_4325_n_29 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_29);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_29;

wire n_20;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_28;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx3_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_8),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_14),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_17),
.B1(n_14),
.B2(n_11),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_12),
.B(n_7),
.Y(n_21)
);

NOR2x1_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_7),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OAI211xp5_ASAP7_75t_SL g24 ( 
.A1(n_21),
.A2(n_19),
.B(n_7),
.C(n_0),
.Y(n_24)
);

NOR2x1_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_0),
.Y(n_25)
);

CKINVDCx16_ASAP7_75t_R g26 ( 
.A(n_24),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.C(n_4),
.Y(n_27)
);

OAI322xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_2),
.A3(n_1),
.B1(n_6),
.B2(n_9),
.C1(n_3),
.C2(n_5),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_SL g29 ( 
.A1(n_27),
.A2(n_5),
.B1(n_9),
.B2(n_28),
.Y(n_29)
);


endmodule