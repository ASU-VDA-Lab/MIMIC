module fake_netlist_779_4376_n_22 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_22);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_22;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_21;
wire n_14;

INVx3_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_16)
);

O2A1O1Ixp5_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_8),
.B(n_5),
.C(n_3),
.Y(n_17)
);

NAND4xp25_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_14),
.C(n_13),
.D(n_15),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_11),
.B1(n_13),
.B2(n_4),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_7),
.B1(n_10),
.B2(n_16),
.C1(n_17),
.C2(n_11),
.Y(n_22)
);


endmodule