module fake_netlist_779_210_n_33 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_33);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_33;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_31;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

NAND2xp33_ASAP7_75t_R g16 ( 
.A(n_14),
.B(n_11),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_9),
.B(n_3),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_19),
.Y(n_21)
);

NOR2xp67_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_7),
.Y(n_22)
);

NAND2x1_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_20),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_21),
.Y(n_24)
);

OR2x6_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_18),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_24),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI211xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_18),
.B(n_16),
.C(n_7),
.Y(n_28)
);

AOI31xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_4),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_30),
.B1(n_8),
.B2(n_6),
.Y(n_33)
);


endmodule