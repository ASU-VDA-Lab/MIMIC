module fake_netlist_779_424_n_13 (n_1, n_2, n_0, n_13);

input n_1;
input n_2;
input n_0;

output n_13;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_3;
wire n_8;
wire n_12;
wire n_4;
wire n_9;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_6),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

NOR3xp33_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_1),
.C(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NAND4xp25_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_8),
.C(n_1),
.D(n_0),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_2),
.B1(n_8),
.B2(n_12),
.Y(n_13)
);


endmodule