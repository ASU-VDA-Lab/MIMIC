module fake_netlist_779_2179_n_27 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_27);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_27;

wire n_20;
wire n_17;
wire n_12;
wire n_25;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_9;
wire n_8;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

BUFx8_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_3),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_11),
.B(n_2),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_SL g16 ( 
.A(n_13),
.B(n_3),
.C(n_2),
.Y(n_16)
);

BUFx3_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_13),
.Y(n_18)
);

OAI221xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_10),
.B1(n_12),
.B2(n_9),
.C(n_4),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AO21x2_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_14),
.B(n_15),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_15),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);


endmodule