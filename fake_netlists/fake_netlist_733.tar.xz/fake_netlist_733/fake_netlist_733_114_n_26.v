module fake_netlist_733_114_n_26 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_8, n_26);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_24;
wire n_10;
wire n_9;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_12;

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_8),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_6),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_14),
.Y(n_16)
);

BUFx3_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI21xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

BUFx12f_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

BUFx12f_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_9),
.B1(n_12),
.B2(n_10),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_21),
.B1(n_13),
.B2(n_4),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_4),
.B1(n_5),
.B2(n_7),
.C1(n_23),
.C2(n_25),
.Y(n_26)
);


endmodule