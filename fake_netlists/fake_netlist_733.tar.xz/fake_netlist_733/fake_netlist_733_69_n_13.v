module fake_netlist_733_69_n_13 (n_0, n_2, n_1, n_3, n_13);

input n_0;
input n_2;
input n_1;
input n_3;

output n_13;

wire n_12;
wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

AND2x4_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);

INVx8_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

OR2x6_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

NOR3xp33_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_5),
.C(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_5),
.B2(n_4),
.C(n_7),
.Y(n_11)
);

AO22x2_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_4),
.B1(n_5),
.B2(n_3),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_13)
);


endmodule