module fake_netlist_733_1628_n_77 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_77);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_77;

wire n_71;
wire n_62;
wire n_36;
wire n_68;
wire n_73;
wire n_60;
wire n_53;
wire n_57;
wire n_41;
wire n_55;
wire n_46;
wire n_64;
wire n_76;
wire n_72;
wire n_51;
wire n_75;
wire n_42;
wire n_33;
wire n_70;
wire n_63;
wire n_25;
wire n_69;
wire n_56;
wire n_52;
wire n_61;
wire n_45;
wire n_28;
wire n_65;
wire n_50;
wire n_35;
wire n_43;
wire n_58;
wire n_74;
wire n_44;
wire n_66;
wire n_34;
wire n_39;
wire n_48;
wire n_49;
wire n_27;
wire n_37;
wire n_59;
wire n_26;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_67;
wire n_47;
wire n_29;
wire n_54;
wire n_32;

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_8),
.B(n_4),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_10),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_0),
.B(n_5),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_9),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_15),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_18),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_16),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_7),
.B(n_18),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_3),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_6),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_31),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_27),
.B(n_16),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_31),
.B(n_36),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_L g42 ( 
.A(n_36),
.B(n_24),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_34),
.B(n_24),
.C(n_1),
.Y(n_43)
);

INVx4_ASAP7_75t_L g44 ( 
.A(n_28),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_44),
.B(n_42),
.Y(n_45)
);

OAI21x1_ASAP7_75t_L g46 ( 
.A1(n_38),
.A2(n_26),
.B(n_25),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

BUFx6f_ASAP7_75t_L g48 ( 
.A(n_39),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_41),
.Y(n_49)
);

BUFx2_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

INVx4_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_46),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_45),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_33),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_50),
.Y(n_55)
);

AOI21xp5_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_32),
.B(n_43),
.Y(n_56)
);

INVxp67_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_51),
.Y(n_58)
);

OAI21xp33_ASAP7_75t_L g59 ( 
.A1(n_55),
.A2(n_35),
.B(n_32),
.Y(n_59)
);

INVx1_ASAP7_75t_SL g60 ( 
.A(n_56),
.Y(n_60)
);

OR2x2_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_51),
.Y(n_61)
);

INVx1_ASAP7_75t_SL g62 ( 
.A(n_58),
.Y(n_62)
);

OAI21xp5_ASAP7_75t_L g63 ( 
.A1(n_60),
.A2(n_30),
.B(n_29),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_59),
.Y(n_64)
);

INVxp67_ASAP7_75t_L g65 ( 
.A(n_57),
.Y(n_65)
);

NAND3xp33_ASAP7_75t_L g66 ( 
.A(n_64),
.B(n_29),
.C(n_2),
.Y(n_66)
);

INVx1_ASAP7_75t_SL g67 ( 
.A(n_62),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_65),
.B(n_29),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_61),
.Y(n_69)
);

NAND4xp75_ASAP7_75t_L g70 ( 
.A(n_63),
.B(n_14),
.C(n_13),
.D(n_12),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_69),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_67),
.Y(n_72)
);

BUFx3_ASAP7_75t_L g73 ( 
.A(n_68),
.Y(n_73)
);

NAND2xp33_ASAP7_75t_R g74 ( 
.A(n_70),
.B(n_61),
.Y(n_74)
);

AOI21xp33_ASAP7_75t_L g75 ( 
.A1(n_74),
.A2(n_66),
.B(n_17),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_71),
.Y(n_76)
);

AOI322xp5_ASAP7_75t_L g77 ( 
.A1(n_76),
.A2(n_19),
.A3(n_22),
.B1(n_72),
.B2(n_73),
.C1(n_74),
.C2(n_75),
.Y(n_77)
);


endmodule