module fake_netlist_733_234_n_23 (n_1, n_2, n_3, n_4, n_0, n_23);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_23;

wire n_20;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

OAI22xp5_ASAP7_75t_L g5 ( 
.A1(n_1),
.A2(n_2),
.B1(n_0),
.B2(n_4),
.Y(n_5)
);

AND2x6_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

AND3x4_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_1),
.C(n_0),
.Y(n_9)
);

INVx6_ASAP7_75t_SL g10 ( 
.A(n_6),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_2),
.B(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_12),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B1(n_14),
.B2(n_10),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_13),
.B(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_6),
.Y(n_20)
);

OAI211xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_4),
.B(n_14),
.C(n_11),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AO21x2_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B(n_19),
.Y(n_23)
);


endmodule