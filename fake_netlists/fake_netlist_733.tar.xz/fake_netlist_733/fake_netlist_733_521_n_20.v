module fake_netlist_733_521_n_20 (n_1, n_2, n_3, n_4, n_5, n_0, n_20);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_20;

wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

BUFx8_ASAP7_75t_SL g6 ( 
.A(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_1),
.Y(n_9)
);

NOR2xp67_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_1),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_3),
.B(n_2),
.Y(n_11)
);

AND2x4_ASAP7_75t_SL g12 ( 
.A(n_9),
.B(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_12),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_10),
.B(n_12),
.C(n_11),
.Y(n_16)
);

NAND4xp25_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_6),
.C(n_4),
.D(n_2),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_5),
.C(n_15),
.Y(n_18)
);

XNOR2xp5_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_5),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);


endmodule