module fake_netlist_733_1386_n_33 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_33);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_33;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

NOR2xp67_ASAP7_75t_L g13 ( 
.A(n_5),
.B(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_4),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_SL g18 ( 
.A(n_14),
.B(n_5),
.C(n_4),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_6),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_12),
.B(n_11),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

OAI22xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_21),
.B1(n_22),
.B2(n_12),
.Y(n_26)
);

OAI21xp33_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_21),
.B(n_22),
.Y(n_27)
);

NOR2xp67_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_22),
.Y(n_28)
);

NOR3xp33_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_22),
.C(n_16),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_3),
.B2(n_1),
.Y(n_33)
);


endmodule