module fake_netlist_733_1742_n_39 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_39);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_39;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_15;
wire n_29;
wire n_32;

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_2),
.B(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_5),
.B(n_7),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_L g22 ( 
.A(n_0),
.B(n_4),
.C(n_7),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

AOI31xp67_ASAP7_75t_L g24 ( 
.A1(n_19),
.A2(n_9),
.A3(n_1),
.B(n_0),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_15),
.A2(n_3),
.B(n_1),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_14),
.A2(n_6),
.B(n_3),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_15),
.A2(n_19),
.B(n_17),
.Y(n_27)
);

OAI22xp33_ASAP7_75t_SL g28 ( 
.A1(n_26),
.A2(n_13),
.B1(n_20),
.B2(n_16),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_26),
.A2(n_18),
.B1(n_21),
.B2(n_13),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_23),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_27),
.B(n_28),
.Y(n_33)
);

OAI211xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_22),
.B(n_18),
.C(n_21),
.Y(n_34)
);

AND3x4_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_31),
.C(n_24),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_27),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

XOR2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_25),
.Y(n_38)
);

AO21x1_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_15),
.B(n_38),
.Y(n_39)
);


endmodule