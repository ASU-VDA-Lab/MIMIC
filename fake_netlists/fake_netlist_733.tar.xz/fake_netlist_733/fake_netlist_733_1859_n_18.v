module fake_netlist_733_1859_n_18 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_18);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_18;

wire n_12;
wire n_15;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_7;
wire n_13;
wire n_16;
wire n_17;
wire n_8;

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_5),
.B1(n_2),
.B2(n_1),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

OAI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B1(n_7),
.B2(n_8),
.C(n_9),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_7),
.B(n_10),
.C(n_8),
.Y(n_14)
);

OAI21xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_12),
.B(n_11),
.Y(n_15)
);

AOI211xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B(n_11),
.C(n_2),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_4),
.B1(n_2),
.B2(n_5),
.C1(n_6),
.C2(n_3),
.Y(n_18)
);


endmodule