module fake_netlist_733_2076_n_44 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_44);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_44;

wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_19),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_15),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_4),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_6),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_21),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_8),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_21),
.B1(n_1),
.B2(n_0),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_7),
.B1(n_5),
.B2(n_3),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_SL g32 ( 
.A1(n_29),
.A2(n_26),
.B(n_25),
.C(n_22),
.Y(n_32)
);

AO31x2_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_27),
.A3(n_24),
.B(n_29),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_10),
.B(n_9),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OAI22xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_20),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_40),
.Y(n_42)
);

XNOR2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_42),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);


endmodule