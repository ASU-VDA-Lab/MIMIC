module fake_netlist_733_1936_n_17 (n_1, n_2, n_3, n_4, n_5, n_0, n_17);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_17;

wire n_12;
wire n_15;
wire n_14;
wire n_8;
wire n_9;
wire n_10;
wire n_13;
wire n_7;
wire n_16;
wire n_6;
wire n_11;

INVx2_ASAP7_75t_SL g6 ( 
.A(n_1),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

CKINVDCx12_ASAP7_75t_R g8 ( 
.A(n_0),
.Y(n_8)
);

OR2x6_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

O2A1O1Ixp33_ASAP7_75t_SL g10 ( 
.A1(n_7),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

OAI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.B1(n_10),
.B2(n_8),
.C(n_2),
.Y(n_13)
);

BUFx12f_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_14),
.B2(n_15),
.Y(n_17)
);


endmodule