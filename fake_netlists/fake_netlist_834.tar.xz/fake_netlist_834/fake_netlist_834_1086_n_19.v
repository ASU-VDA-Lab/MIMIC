module fake_netlist_834_1086_n_19 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_19);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_18;
wire n_16;
wire n_11;

OR2x2_ASAP7_75t_L g11 ( 
.A(n_2),
.B(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI32xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.A3(n_11),
.B1(n_13),
.B2(n_4),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_11),
.B1(n_7),
.B2(n_5),
.C(n_6),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_13),
.B1(n_6),
.B2(n_5),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_7),
.B1(n_8),
.B2(n_0),
.C1(n_10),
.C2(n_3),
.Y(n_19)
);


endmodule