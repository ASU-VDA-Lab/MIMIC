module fake_netlist_834_897_n_43 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_43);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_43;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_9),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_19),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_1),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_17),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_3),
.Y(n_27)
);

AOI21xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_17),
.B(n_15),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_27),
.B(n_15),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_22),
.B(n_20),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_R g31 ( 
.A(n_28),
.B(n_21),
.Y(n_31)
);

OAI21x1_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_22),
.B(n_23),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_29),
.Y(n_33)
);

AND2x4_ASAP7_75t_SL g34 ( 
.A(n_31),
.B(n_22),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_25),
.B1(n_24),
.B2(n_32),
.C(n_18),
.Y(n_37)
);

NAND3xp33_ASAP7_75t_SL g38 ( 
.A(n_35),
.B(n_18),
.C(n_0),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_SL g41 ( 
.A1(n_39),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_41)
);

XNOR2x1_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_10),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_41),
.B1(n_12),
.B2(n_11),
.Y(n_43)
);


endmodule