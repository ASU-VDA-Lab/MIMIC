module fake_netlist_834_64_n_14 (n_4, n_2, n_3, n_0, n_1, n_14);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_1),
.A2(n_2),
.B1(n_0),
.B2(n_4),
.Y(n_5)
);

BUFx10_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

AO31x2_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.A3(n_3),
.B(n_0),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

NOR4xp25_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_5),
.C(n_6),
.D(n_8),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B1(n_5),
.B2(n_8),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_4),
.B(n_3),
.Y(n_14)
);


endmodule