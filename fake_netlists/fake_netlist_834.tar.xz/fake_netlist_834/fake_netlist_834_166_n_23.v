module fake_netlist_834_166_n_23 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_23);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_19;
wire n_18;
wire n_21;
wire n_16;

OAI22xp33_ASAP7_75t_L g13 ( 
.A1(n_3),
.A2(n_6),
.B1(n_7),
.B2(n_2),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_9),
.Y(n_15)
);

INVxp67_ASAP7_75t_SL g16 ( 
.A(n_8),
.Y(n_16)
);

NAND3x1_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_1),
.C(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_14),
.Y(n_20)
);

NAND2x1p5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_4),
.Y(n_21)
);

XOR2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_10),
.Y(n_22)
);

AO22x2_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_16),
.B1(n_15),
.B2(n_11),
.Y(n_23)
);


endmodule