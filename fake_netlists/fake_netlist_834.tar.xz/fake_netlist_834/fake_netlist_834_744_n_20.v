module fake_netlist_834_744_n_20 (n_4, n_2, n_3, n_0, n_1, n_20);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_5;
wire n_11;
wire n_8;

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_6),
.B(n_7),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

INVxp67_ASAP7_75t_SL g10 ( 
.A(n_9),
.Y(n_10)
);

OR2x6_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_0),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_1),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_SL g13 ( 
.A(n_11),
.B(n_1),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_11),
.B1(n_4),
.B2(n_2),
.C(n_3),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_11),
.B1(n_3),
.B2(n_2),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_12),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_13),
.B(n_11),
.C(n_2),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

OAI21xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_11),
.B(n_4),
.Y(n_19)
);

OAI21x1_ASAP7_75t_SL g20 ( 
.A1(n_18),
.A2(n_19),
.B(n_4),
.Y(n_20)
);


endmodule