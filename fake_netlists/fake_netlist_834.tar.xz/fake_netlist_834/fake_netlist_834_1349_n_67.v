module fake_netlist_834_1349_n_67 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_67);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_67;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_17;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_44;
wire n_53;
wire n_60;
wire n_32;
wire n_31;
wire n_39;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_18;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

AND2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_6),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_5),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_11),
.B(n_10),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_5),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

INVx5_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_1),
.B(n_3),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_1),
.A2(n_9),
.B1(n_4),
.B2(n_2),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_19),
.B(n_25),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_22),
.B(n_0),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_21),
.B(n_0),
.Y(n_35)
);

NAND2x1p5_ASAP7_75t_L g36 ( 
.A(n_26),
.B(n_2),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_20),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_28),
.Y(n_38)
);

BUFx3_ASAP7_75t_L g39 ( 
.A(n_26),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_27),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_18),
.Y(n_41)
);

NAND2x1p5_ASAP7_75t_L g42 ( 
.A(n_34),
.B(n_17),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_32),
.A2(n_23),
.B(n_26),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_24),
.Y(n_44)
);

OAI21x1_ASAP7_75t_L g45 ( 
.A1(n_36),
.A2(n_26),
.B(n_29),
.Y(n_45)
);

OA21x2_ASAP7_75t_L g46 ( 
.A1(n_34),
.A2(n_24),
.B(n_26),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_34),
.B(n_20),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_41),
.B(n_44),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_44),
.A2(n_35),
.B1(n_36),
.B2(n_42),
.Y(n_49)
);

INVx3_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_42),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_42),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

INVx1_ASAP7_75t_SL g55 ( 
.A(n_48),
.Y(n_55)
);

OAI221xp5_ASAP7_75t_SL g56 ( 
.A1(n_55),
.A2(n_48),
.B1(n_49),
.B2(n_47),
.C(n_38),
.Y(n_56)
);

AOI21xp5_ASAP7_75t_SL g57 ( 
.A1(n_54),
.A2(n_52),
.B(n_46),
.Y(n_57)
);

A2O1A1Ixp33_ASAP7_75t_L g58 ( 
.A1(n_54),
.A2(n_45),
.B(n_43),
.C(n_50),
.Y(n_58)
);

INVx1_ASAP7_75t_SL g59 ( 
.A(n_56),
.Y(n_59)
);

AOI332xp33_ASAP7_75t_L g60 ( 
.A1(n_58),
.A2(n_30),
.A3(n_31),
.B1(n_33),
.B2(n_38),
.B3(n_47),
.C1(n_45),
.C2(n_3),
.Y(n_60)
);

AO22x1_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_45),
.B1(n_30),
.B2(n_37),
.Y(n_61)
);

AND3x4_ASAP7_75t_L g62 ( 
.A(n_59),
.B(n_30),
.C(n_53),
.Y(n_62)
);

NAND4xp25_ASAP7_75t_L g63 ( 
.A(n_60),
.B(n_4),
.C(n_50),
.D(n_39),
.Y(n_63)
);

INVx3_ASAP7_75t_L g64 ( 
.A(n_63),
.Y(n_64)
);

OAI22x1_ASAP7_75t_L g65 ( 
.A1(n_62),
.A2(n_61),
.B1(n_46),
.B2(n_39),
.Y(n_65)
);

INVxp67_ASAP7_75t_L g66 ( 
.A(n_64),
.Y(n_66)
);

AOI22x1_ASAP7_75t_L g67 ( 
.A1(n_66),
.A2(n_64),
.B1(n_65),
.B2(n_61),
.Y(n_67)
);


endmodule