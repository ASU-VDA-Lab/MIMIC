module fake_netlist_834_940_n_36 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_36);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_36;

wire n_25;
wire n_20;
wire n_22;
wire n_34;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_18),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

BUFx8_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_11),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_8),
.Y(n_25)
);

OAI22x1_ASAP7_75t_L g26 ( 
.A1(n_21),
.A2(n_18),
.B1(n_17),
.B2(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_20),
.A2(n_17),
.B1(n_2),
.B2(n_1),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

XNOR2x2_ASAP7_75t_SL g30 ( 
.A(n_26),
.B(n_28),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_24),
.C(n_19),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_29),
.B(n_23),
.C(n_25),
.Y(n_32)
);

AOI221xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_23),
.B1(n_6),
.B2(n_4),
.C(n_5),
.Y(n_33)
);

BUFx8_ASAP7_75t_SL g34 ( 
.A(n_33),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_13),
.B1(n_9),
.B2(n_7),
.Y(n_35)
);

OA21x2_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_15),
.B(n_14),
.Y(n_36)
);


endmodule