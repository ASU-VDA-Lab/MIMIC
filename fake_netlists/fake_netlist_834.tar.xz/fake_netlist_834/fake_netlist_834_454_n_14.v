module fake_netlist_834_454_n_14 (n_2, n_0, n_1, n_14);

input n_2;
input n_0;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

BUFx10_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

OAI21xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_5)
);

AOI21xp33_ASAP7_75t_SL g6 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

OAI22xp5_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_8)
);

NAND2x1_ASAP7_75t_SL g9 ( 
.A(n_7),
.B(n_4),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_8),
.C(n_7),
.Y(n_11)
);

OAI21x1_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_4),
.B(n_1),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_SL g13 ( 
.A1(n_10),
.A2(n_4),
.B1(n_1),
.B2(n_2),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_1),
.B1(n_2),
.B2(n_12),
.Y(n_14)
);


endmodule