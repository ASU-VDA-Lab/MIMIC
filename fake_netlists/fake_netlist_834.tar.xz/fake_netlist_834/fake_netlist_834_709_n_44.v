module fake_netlist_834_709_n_44 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_44);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_44;

wire n_25;
wire n_36;
wire n_41;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_6),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_10),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_3),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_9),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_24),
.Y(n_31)
);

BUFx3_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

O2A1O1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_25),
.A2(n_18),
.B(n_17),
.C(n_16),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_32),
.Y(n_36)
);

OAI32xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_25),
.A3(n_30),
.B1(n_27),
.B2(n_34),
.Y(n_37)
);

NAND3xp33_ASAP7_75t_SL g38 ( 
.A(n_37),
.B(n_33),
.C(n_26),
.Y(n_38)
);

AOI321xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_27),
.A3(n_18),
.B1(n_16),
.B2(n_23),
.C(n_17),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_28),
.Y(n_40)
);

OAI322xp33_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_1),
.A3(n_0),
.B1(n_5),
.B2(n_7),
.C1(n_2),
.C2(n_4),
.Y(n_41)
);

OAI22x1_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_13),
.B1(n_12),
.B2(n_8),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_19),
.B1(n_15),
.B2(n_14),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_42),
.A2(n_43),
.B1(n_22),
.B2(n_21),
.Y(n_44)
);


endmodule