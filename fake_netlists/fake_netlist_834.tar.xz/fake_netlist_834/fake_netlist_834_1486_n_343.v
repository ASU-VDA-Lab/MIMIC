module fake_netlist_834_1486_n_343 (n_25, n_20, n_15, n_13, n_2, n_36, n_17, n_14, n_22, n_4, n_7, n_23, n_34, n_40, n_28, n_39, n_9, n_31, n_32, n_26, n_24, n_37, n_19, n_3, n_33, n_12, n_0, n_29, n_6, n_30, n_18, n_10, n_16, n_21, n_5, n_35, n_38, n_11, n_27, n_1, n_8, n_343);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_36;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_34;
input n_40;
input n_28;
input n_39;
input n_9;
input n_31;
input n_32;
input n_26;
input n_24;
input n_37;
input n_19;
input n_3;
input n_33;
input n_12;
input n_0;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_35;
input n_38;
input n_11;
input n_27;
input n_1;
input n_8;

output n_343;

wire n_298;
wire n_114;
wire n_261;
wire n_316;
wire n_166;
wire n_240;
wire n_326;
wire n_154;
wire n_340;
wire n_153;
wire n_195;
wire n_210;
wire n_87;
wire n_95;
wire n_325;
wire n_232;
wire n_63;
wire n_110;
wire n_265;
wire n_61;
wire n_108;
wire n_48;
wire n_163;
wire n_209;
wire n_196;
wire n_47;
wire n_294;
wire n_202;
wire n_90;
wire n_76;
wire n_299;
wire n_272;
wire n_160;
wire n_338;
wire n_329;
wire n_99;
wire n_42;
wire n_155;
wire n_314;
wire n_52;
wire n_229;
wire n_51;
wire n_119;
wire n_312;
wire n_152;
wire n_131;
wire n_133;
wire n_274;
wire n_323;
wire n_223;
wire n_279;
wire n_84;
wire n_303;
wire n_270;
wire n_188;
wire n_205;
wire n_65;
wire n_247;
wire n_300;
wire n_309;
wire n_281;
wire n_129;
wire n_198;
wire n_201;
wire n_169;
wire n_180;
wire n_220;
wire n_267;
wire n_208;
wire n_82;
wire n_234;
wire n_165;
wire n_141;
wire n_305;
wire n_280;
wire n_331;
wire n_221;
wire n_311;
wire n_293;
wire n_156;
wire n_126;
wire n_296;
wire n_78;
wire n_187;
wire n_96;
wire n_94;
wire n_162;
wire n_135;
wire n_324;
wire n_275;
wire n_107;
wire n_301;
wire n_288;
wire n_178;
wire n_121;
wire n_73;
wire n_235;
wire n_211;
wire n_246;
wire n_175;
wire n_185;
wire n_161;
wire n_224;
wire n_179;
wire n_137;
wire n_57;
wire n_226;
wire n_284;
wire n_116;
wire n_128;
wire n_139;
wire n_115;
wire n_339;
wire n_144;
wire n_328;
wire n_283;
wire n_183;
wire n_106;
wire n_149;
wire n_237;
wire n_159;
wire n_91;
wire n_233;
wire n_333;
wire n_204;
wire n_191;
wire n_317;
wire n_181;
wire n_60;
wire n_260;
wire n_291;
wire n_186;
wire n_218;
wire n_69;
wire n_212;
wire n_241;
wire n_256;
wire n_134;
wire n_254;
wire n_148;
wire n_245;
wire n_193;
wire n_49;
wire n_132;
wire n_194;
wire n_219;
wire n_250;
wire n_81;
wire n_273;
wire n_80;
wire n_123;
wire n_290;
wire n_319;
wire n_167;
wire n_122;
wire n_289;
wire n_56;
wire n_59;
wire n_74;
wire n_341;
wire n_79;
wire n_177;
wire n_43;
wire n_244;
wire n_158;
wire n_171;
wire n_259;
wire n_214;
wire n_127;
wire n_295;
wire n_213;
wire n_257;
wire n_72;
wire n_266;
wire n_320;
wire n_249;
wire n_120;
wire n_327;
wire n_145;
wire n_307;
wire n_200;
wire n_170;
wire n_77;
wire n_138;
wire n_217;
wire n_253;
wire n_238;
wire n_322;
wire n_332;
wire n_62;
wire n_44;
wire n_117;
wire n_104;
wire n_168;
wire n_285;
wire n_310;
wire n_176;
wire n_271;
wire n_330;
wire n_101;
wire n_336;
wire n_242;
wire n_313;
wire n_157;
wire n_83;
wire n_334;
wire n_216;
wire n_150;
wire n_71;
wire n_92;
wire n_100;
wire n_124;
wire n_236;
wire n_206;
wire n_147;
wire n_268;
wire n_97;
wire n_182;
wire n_335;
wire n_130;
wire n_239;
wire n_173;
wire n_318;
wire n_287;
wire n_222;
wire n_277;
wire n_263;
wire n_269;
wire n_54;
wire n_304;
wire n_64;
wire n_278;
wire n_264;
wire n_297;
wire n_292;
wire n_184;
wire n_86;
wire n_45;
wire n_192;
wire n_230;
wire n_118;
wire n_189;
wire n_125;
wire n_255;
wire n_151;
wire n_302;
wire n_258;
wire n_207;
wire n_103;
wire n_227;
wire n_215;
wire n_199;
wire n_143;
wire n_190;
wire n_251;
wire n_136;
wire n_102;
wire n_89;
wire n_262;
wire n_70;
wire n_172;
wire n_142;
wire n_337;
wire n_109;
wire n_41;
wire n_53;
wire n_315;
wire n_58;
wire n_68;
wire n_146;
wire n_248;
wire n_105;
wire n_306;
wire n_321;
wire n_225;
wire n_85;
wire n_55;
wire n_164;
wire n_252;
wire n_75;
wire n_140;
wire n_342;
wire n_67;
wire n_66;
wire n_98;
wire n_286;
wire n_203;
wire n_50;
wire n_112;
wire n_228;
wire n_111;
wire n_93;
wire n_174;
wire n_197;
wire n_88;
wire n_243;
wire n_276;
wire n_113;
wire n_282;
wire n_231;
wire n_308;
wire n_46;

CKINVDCx20_ASAP7_75t_R g41 ( 
.A(n_20),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_15),
.Y(n_42)
);

INVxp33_ASAP7_75t_SL g43 ( 
.A(n_37),
.Y(n_43)
);

INVxp67_ASAP7_75t_SL g44 ( 
.A(n_26),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_21),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_39),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_30),
.Y(n_47)
);

CKINVDCx14_ASAP7_75t_R g48 ( 
.A(n_8),
.Y(n_48)
);

INVxp33_ASAP7_75t_L g49 ( 
.A(n_17),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_16),
.Y(n_50)
);

INVx3_ASAP7_75t_L g51 ( 
.A(n_11),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_13),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_15),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_34),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_5),
.Y(n_55)
);

CKINVDCx5p33_ASAP7_75t_R g56 ( 
.A(n_4),
.Y(n_56)
);

BUFx6f_ASAP7_75t_L g57 ( 
.A(n_45),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_51),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_51),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_51),
.Y(n_60)
);

HB1xp67_ASAP7_75t_L g61 ( 
.A(n_56),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_51),
.Y(n_62)
);

BUFx6f_ASAP7_75t_L g63 ( 
.A(n_45),
.Y(n_63)
);

CKINVDCx20_ASAP7_75t_R g64 ( 
.A(n_48),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_51),
.Y(n_65)
);

INVx4_ASAP7_75t_L g66 ( 
.A(n_57),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_58),
.Y(n_67)
);

AND2x4_ASAP7_75t_L g68 ( 
.A(n_58),
.B(n_59),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_59),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_62),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_62),
.Y(n_71)
);

BUFx6f_ASAP7_75t_L g72 ( 
.A(n_57),
.Y(n_72)
);

NAND3xp33_ASAP7_75t_L g73 ( 
.A(n_57),
.B(n_48),
.C(n_53),
.Y(n_73)
);

INVxp33_ASAP7_75t_L g74 ( 
.A(n_61),
.Y(n_74)
);

AND2x2_ASAP7_75t_L g75 ( 
.A(n_60),
.B(n_53),
.Y(n_75)
);

INVx2_ASAP7_75t_L g76 ( 
.A(n_60),
.Y(n_76)
);

INVx2_ASAP7_75t_L g77 ( 
.A(n_65),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_57),
.Y(n_78)
);

BUFx3_ASAP7_75t_L g79 ( 
.A(n_57),
.Y(n_79)
);

BUFx3_ASAP7_75t_L g80 ( 
.A(n_63),
.Y(n_80)
);

INVx3_ASAP7_75t_L g81 ( 
.A(n_63),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_63),
.Y(n_82)
);

INVx3_ASAP7_75t_SL g83 ( 
.A(n_68),
.Y(n_83)
);

BUFx12f_ASAP7_75t_L g84 ( 
.A(n_68),
.Y(n_84)
);

BUFx2_ASAP7_75t_L g85 ( 
.A(n_68),
.Y(n_85)
);

NAND2xp5_ASAP7_75t_L g86 ( 
.A(n_67),
.B(n_63),
.Y(n_86)
);

NAND2xp5_ASAP7_75t_L g87 ( 
.A(n_67),
.B(n_63),
.Y(n_87)
);

AOI22xp33_ASAP7_75t_L g88 ( 
.A1(n_68),
.A2(n_53),
.B1(n_52),
.B2(n_42),
.Y(n_88)
);

BUFx6f_ASAP7_75t_L g89 ( 
.A(n_72),
.Y(n_89)
);

NOR2xp33_ASAP7_75t_L g90 ( 
.A(n_74),
.B(n_64),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_67),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_69),
.Y(n_92)
);

CKINVDCx5p33_ASAP7_75t_R g93 ( 
.A(n_75),
.Y(n_93)
);

INVx3_ASAP7_75t_L g94 ( 
.A(n_76),
.Y(n_94)
);

INVx5_ASAP7_75t_L g95 ( 
.A(n_72),
.Y(n_95)
);

INVx1_ASAP7_75t_SL g96 ( 
.A(n_74),
.Y(n_96)
);

NAND2xp5_ASAP7_75t_L g97 ( 
.A(n_76),
.B(n_46),
.Y(n_97)
);

NOR2xp33_ASAP7_75t_R g98 ( 
.A(n_81),
.B(n_41),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_76),
.B(n_46),
.Y(n_99)
);

NOR3xp33_ASAP7_75t_SL g100 ( 
.A(n_73),
.B(n_52),
.C(n_42),
.Y(n_100)
);

INVx5_ASAP7_75t_L g101 ( 
.A(n_72),
.Y(n_101)
);

INVxp67_ASAP7_75t_SL g102 ( 
.A(n_76),
.Y(n_102)
);

INVx2_ASAP7_75t_L g103 ( 
.A(n_70),
.Y(n_103)
);

INVx2_ASAP7_75t_L g104 ( 
.A(n_70),
.Y(n_104)
);

INVx3_ASAP7_75t_L g105 ( 
.A(n_72),
.Y(n_105)
);

AOI22xp33_ASAP7_75t_L g106 ( 
.A1(n_85),
.A2(n_88),
.B1(n_102),
.B2(n_84),
.Y(n_106)
);

NOR4xp25_ASAP7_75t_L g107 ( 
.A(n_88),
.B(n_55),
.C(n_69),
.D(n_73),
.Y(n_107)
);

INVx3_ASAP7_75t_SL g108 ( 
.A(n_83),
.Y(n_108)
);

OAI21xp33_ASAP7_75t_L g109 ( 
.A1(n_93),
.A2(n_55),
.B(n_68),
.Y(n_109)
);

BUFx6f_ASAP7_75t_L g110 ( 
.A(n_83),
.Y(n_110)
);

A2O1A1Ixp33_ASAP7_75t_SL g111 ( 
.A1(n_105),
.A2(n_81),
.B(n_77),
.C(n_82),
.Y(n_111)
);

CKINVDCx8_ASAP7_75t_R g112 ( 
.A(n_90),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_91),
.Y(n_113)
);

OR2x2_ASAP7_75t_L g114 ( 
.A(n_96),
.B(n_68),
.Y(n_114)
);

AND2x2_ASAP7_75t_L g115 ( 
.A(n_85),
.B(n_75),
.Y(n_115)
);

BUFx2_ASAP7_75t_L g116 ( 
.A(n_96),
.Y(n_116)
);

OR2x6_ASAP7_75t_L g117 ( 
.A(n_84),
.B(n_75),
.Y(n_117)
);

AOI22xp5_ASAP7_75t_L g118 ( 
.A1(n_85),
.A2(n_84),
.B1(n_83),
.B2(n_102),
.Y(n_118)
);

AOI22xp33_ASAP7_75t_L g119 ( 
.A1(n_94),
.A2(n_50),
.B1(n_80),
.B2(n_79),
.Y(n_119)
);

O2A1O1Ixp33_ASAP7_75t_SL g120 ( 
.A1(n_91),
.A2(n_50),
.B(n_54),
.C(n_47),
.Y(n_120)
);

HB1xp67_ASAP7_75t_L g121 ( 
.A(n_98),
.Y(n_121)
);

AOI21xp5_ASAP7_75t_L g122 ( 
.A1(n_86),
.A2(n_82),
.B(n_78),
.Y(n_122)
);

INVx4_ASAP7_75t_L g123 ( 
.A(n_83),
.Y(n_123)
);

AND2x2_ASAP7_75t_L g124 ( 
.A(n_92),
.B(n_77),
.Y(n_124)
);

BUFx6f_ASAP7_75t_L g125 ( 
.A(n_110),
.Y(n_125)
);

AND2x2_ASAP7_75t_L g126 ( 
.A(n_115),
.B(n_90),
.Y(n_126)
);

INVx2_ASAP7_75t_L g127 ( 
.A(n_124),
.Y(n_127)
);

OR2x2_ASAP7_75t_L g128 ( 
.A(n_116),
.B(n_92),
.Y(n_128)
);

BUFx4f_ASAP7_75t_SL g129 ( 
.A(n_116),
.Y(n_129)
);

OAI211xp5_ASAP7_75t_L g130 ( 
.A1(n_109),
.A2(n_98),
.B(n_100),
.C(n_99),
.Y(n_130)
);

BUFx4f_ASAP7_75t_L g131 ( 
.A(n_110),
.Y(n_131)
);

INVx4_ASAP7_75t_L g132 ( 
.A(n_110),
.Y(n_132)
);

INVx4_ASAP7_75t_L g133 ( 
.A(n_110),
.Y(n_133)
);

AOI21xp5_ASAP7_75t_L g134 ( 
.A1(n_111),
.A2(n_105),
.B(n_87),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_113),
.Y(n_135)
);

BUFx2_ASAP7_75t_L g136 ( 
.A(n_117),
.Y(n_136)
);

AO21x2_ASAP7_75t_L g137 ( 
.A1(n_134),
.A2(n_113),
.B(n_107),
.Y(n_137)
);

AND2x2_ASAP7_75t_L g138 ( 
.A(n_126),
.B(n_115),
.Y(n_138)
);

OAI221xp5_ASAP7_75t_L g139 ( 
.A1(n_128),
.A2(n_112),
.B1(n_114),
.B2(n_106),
.C(n_118),
.Y(n_139)
);

AOI22xp33_ASAP7_75t_L g140 ( 
.A1(n_126),
.A2(n_114),
.B1(n_117),
.B2(n_121),
.Y(n_140)
);

NAND3xp33_ASAP7_75t_L g141 ( 
.A(n_130),
.B(n_100),
.C(n_112),
.Y(n_141)
);

AOI22xp33_ASAP7_75t_L g142 ( 
.A1(n_127),
.A2(n_117),
.B1(n_49),
.B2(n_119),
.Y(n_142)
);

AOI21xp5_ASAP7_75t_L g143 ( 
.A1(n_131),
.A2(n_123),
.B(n_110),
.Y(n_143)
);

AOI22xp33_ASAP7_75t_L g144 ( 
.A1(n_127),
.A2(n_117),
.B1(n_49),
.B2(n_43),
.Y(n_144)
);

HB1xp67_ASAP7_75t_L g145 ( 
.A(n_129),
.Y(n_145)
);

OAI22xp5_ASAP7_75t_L g146 ( 
.A1(n_135),
.A2(n_124),
.B1(n_123),
.B2(n_99),
.Y(n_146)
);

BUFx3_ASAP7_75t_L g147 ( 
.A(n_136),
.Y(n_147)
);

INVx2_ASAP7_75t_L g148 ( 
.A(n_137),
.Y(n_148)
);

OA21x2_ASAP7_75t_L g149 ( 
.A1(n_146),
.A2(n_134),
.B(n_135),
.Y(n_149)
);

OR2x2_ASAP7_75t_L g150 ( 
.A(n_138),
.B(n_147),
.Y(n_150)
);

OA222x2_ASAP7_75t_L g151 ( 
.A1(n_141),
.A2(n_130),
.B1(n_128),
.B2(n_120),
.C1(n_127),
.C2(n_47),
.Y(n_151)
);

AND2x2_ASAP7_75t_L g152 ( 
.A(n_138),
.B(n_140),
.Y(n_152)
);

NAND4xp25_ASAP7_75t_SL g153 ( 
.A(n_141),
.B(n_41),
.C(n_54),
.D(n_0),
.Y(n_153)
);

OAI211xp5_ASAP7_75t_L g154 ( 
.A1(n_144),
.A2(n_44),
.B(n_136),
.C(n_97),
.Y(n_154)
);

AOI222xp33_ASAP7_75t_L g155 ( 
.A1(n_139),
.A2(n_129),
.B1(n_44),
.B2(n_43),
.C1(n_77),
.C2(n_97),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_137),
.Y(n_156)
);

INVx2_ASAP7_75t_L g157 ( 
.A(n_137),
.Y(n_157)
);

AOI22xp33_ASAP7_75t_L g158 ( 
.A1(n_147),
.A2(n_142),
.B1(n_145),
.B2(n_146),
.Y(n_158)
);

HB1xp67_ASAP7_75t_L g159 ( 
.A(n_147),
.Y(n_159)
);

INVx2_ASAP7_75t_L g160 ( 
.A(n_143),
.Y(n_160)
);

AND2x4_ASAP7_75t_L g161 ( 
.A(n_147),
.B(n_132),
.Y(n_161)
);

NAND2xp33_ASAP7_75t_R g162 ( 
.A(n_138),
.B(n_105),
.Y(n_162)
);

AOI22xp33_ASAP7_75t_SL g163 ( 
.A1(n_141),
.A2(n_125),
.B1(n_131),
.B2(n_132),
.Y(n_163)
);

AOI22xp33_ASAP7_75t_SL g164 ( 
.A1(n_154),
.A2(n_131),
.B1(n_125),
.B2(n_132),
.Y(n_164)
);

NAND4xp25_ASAP7_75t_SL g165 ( 
.A(n_155),
.B(n_2),
.C(n_1),
.D(n_0),
.Y(n_165)
);

INVx1_ASAP7_75t_L g166 ( 
.A(n_150),
.Y(n_166)
);

INVx2_ASAP7_75t_L g167 ( 
.A(n_148),
.Y(n_167)
);

AND2x2_ASAP7_75t_L g168 ( 
.A(n_152),
.B(n_77),
.Y(n_168)
);

AOI221x1_ASAP7_75t_SL g169 ( 
.A1(n_153),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.C(n_4),
.Y(n_169)
);

INVx2_ASAP7_75t_L g170 ( 
.A(n_148),
.Y(n_170)
);

OR2x6_ASAP7_75t_L g171 ( 
.A(n_159),
.B(n_125),
.Y(n_171)
);

NAND2xp5_ASAP7_75t_L g172 ( 
.A(n_152),
.B(n_86),
.Y(n_172)
);

AND2x2_ASAP7_75t_L g173 ( 
.A(n_150),
.B(n_78),
.Y(n_173)
);

OAI31xp33_ASAP7_75t_L g174 ( 
.A1(n_153),
.A2(n_87),
.A3(n_122),
.B(n_82),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_159),
.Y(n_175)
);

OR2x6_ASAP7_75t_L g176 ( 
.A(n_161),
.B(n_160),
.Y(n_176)
);

AO31x2_ASAP7_75t_L g177 ( 
.A1(n_156),
.A2(n_133),
.A3(n_132),
.B(n_66),
.Y(n_177)
);

INVx2_ASAP7_75t_L g178 ( 
.A(n_148),
.Y(n_178)
);

OAI33xp33_ASAP7_75t_L g179 ( 
.A1(n_156),
.A2(n_71),
.A3(n_70),
.B1(n_103),
.B2(n_104),
.B3(n_3),
.Y(n_179)
);

INVx2_ASAP7_75t_SL g180 ( 
.A(n_161),
.Y(n_180)
);

BUFx2_ASAP7_75t_L g181 ( 
.A(n_161),
.Y(n_181)
);

OR2x2_ASAP7_75t_L g182 ( 
.A(n_157),
.B(n_94),
.Y(n_182)
);

INVx4_ASAP7_75t_L g183 ( 
.A(n_161),
.Y(n_183)
);

OR2x6_ASAP7_75t_L g184 ( 
.A(n_160),
.B(n_125),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_157),
.Y(n_185)
);

AND2x2_ASAP7_75t_L g186 ( 
.A(n_151),
.B(n_81),
.Y(n_186)
);

OR2x6_ASAP7_75t_L g187 ( 
.A(n_160),
.B(n_125),
.Y(n_187)
);

INVx1_ASAP7_75t_L g188 ( 
.A(n_157),
.Y(n_188)
);

INVxp67_ASAP7_75t_L g189 ( 
.A(n_162),
.Y(n_189)
);

INVx1_ASAP7_75t_L g190 ( 
.A(n_158),
.Y(n_190)
);

NAND4xp25_ASAP7_75t_L g191 ( 
.A(n_155),
.B(n_81),
.C(n_80),
.D(n_79),
.Y(n_191)
);

NAND2xp5_ASAP7_75t_L g192 ( 
.A(n_190),
.B(n_154),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_175),
.B(n_149),
.Y(n_193)
);

NOR4xp25_ASAP7_75t_SL g194 ( 
.A(n_169),
.B(n_151),
.C(n_165),
.D(n_185),
.Y(n_194)
);

INVx2_ASAP7_75t_L g195 ( 
.A(n_167),
.Y(n_195)
);

NAND2xp5_ASAP7_75t_L g196 ( 
.A(n_166),
.B(n_163),
.Y(n_196)
);

NOR2xp33_ASAP7_75t_R g197 ( 
.A(n_180),
.B(n_181),
.Y(n_197)
);

INVxp67_ASAP7_75t_L g198 ( 
.A(n_173),
.Y(n_198)
);

INVx1_ASAP7_75t_L g199 ( 
.A(n_188),
.Y(n_199)
);

NOR2x1_ASAP7_75t_L g200 ( 
.A(n_168),
.B(n_81),
.Y(n_200)
);

AND2x2_ASAP7_75t_L g201 ( 
.A(n_186),
.B(n_149),
.Y(n_201)
);

NAND2xp5_ASAP7_75t_L g202 ( 
.A(n_173),
.B(n_163),
.Y(n_202)
);

OR2x2_ASAP7_75t_L g203 ( 
.A(n_167),
.B(n_149),
.Y(n_203)
);

INVx1_ASAP7_75t_L g204 ( 
.A(n_170),
.Y(n_204)
);

NAND2xp5_ASAP7_75t_L g205 ( 
.A(n_168),
.B(n_149),
.Y(n_205)
);

NAND2xp33_ASAP7_75t_R g206 ( 
.A(n_186),
.B(n_149),
.Y(n_206)
);

NAND2xp5_ASAP7_75t_L g207 ( 
.A(n_172),
.B(n_94),
.Y(n_207)
);

OR2x2_ASAP7_75t_L g208 ( 
.A(n_170),
.B(n_178),
.Y(n_208)
);

INVx2_ASAP7_75t_L g209 ( 
.A(n_178),
.Y(n_209)
);

NOR2x1_ASAP7_75t_L g210 ( 
.A(n_183),
.B(n_133),
.Y(n_210)
);

NOR2xp33_ASAP7_75t_R g211 ( 
.A(n_180),
.B(n_125),
.Y(n_211)
);

OR2x2_ASAP7_75t_L g212 ( 
.A(n_176),
.B(n_70),
.Y(n_212)
);

NAND2xp5_ASAP7_75t_L g213 ( 
.A(n_189),
.B(n_94),
.Y(n_213)
);

INVx2_ASAP7_75t_L g214 ( 
.A(n_182),
.Y(n_214)
);

NOR3xp33_ASAP7_75t_L g215 ( 
.A(n_191),
.B(n_133),
.C(n_94),
.Y(n_215)
);

AND2x2_ASAP7_75t_L g216 ( 
.A(n_176),
.B(n_5),
.Y(n_216)
);

INVx1_ASAP7_75t_L g217 ( 
.A(n_182),
.Y(n_217)
);

OR2x2_ASAP7_75t_L g218 ( 
.A(n_176),
.B(n_177),
.Y(n_218)
);

NAND2xp5_ASAP7_75t_L g219 ( 
.A(n_183),
.B(n_164),
.Y(n_219)
);

OR2x2_ASAP7_75t_L g220 ( 
.A(n_176),
.B(n_71),
.Y(n_220)
);

OR2x2_ASAP7_75t_L g221 ( 
.A(n_177),
.B(n_71),
.Y(n_221)
);

AND2x2_ASAP7_75t_L g222 ( 
.A(n_177),
.B(n_6),
.Y(n_222)
);

INVx2_ASAP7_75t_L g223 ( 
.A(n_177),
.Y(n_223)
);

CKINVDCx5p33_ASAP7_75t_R g224 ( 
.A(n_171),
.Y(n_224)
);

NAND2xp5_ASAP7_75t_L g225 ( 
.A(n_183),
.B(n_174),
.Y(n_225)
);

INVx2_ASAP7_75t_L g226 ( 
.A(n_184),
.Y(n_226)
);

INVx1_ASAP7_75t_L g227 ( 
.A(n_171),
.Y(n_227)
);

BUFx3_ASAP7_75t_L g228 ( 
.A(n_171),
.Y(n_228)
);

NAND4xp25_ASAP7_75t_L g229 ( 
.A(n_179),
.B(n_80),
.C(n_79),
.D(n_6),
.Y(n_229)
);

OAI21xp33_ASAP7_75t_L g230 ( 
.A1(n_222),
.A2(n_171),
.B(n_184),
.Y(n_230)
);

NAND3xp33_ASAP7_75t_L g231 ( 
.A(n_194),
.B(n_187),
.C(n_184),
.Y(n_231)
);

NOR2xp33_ASAP7_75t_L g232 ( 
.A(n_225),
.B(n_187),
.Y(n_232)
);

AOI222xp33_ASAP7_75t_L g233 ( 
.A1(n_192),
.A2(n_8),
.B1(n_7),
.B2(n_9),
.C1(n_11),
.C2(n_10),
.Y(n_233)
);

INVx1_ASAP7_75t_L g234 ( 
.A(n_199),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_199),
.Y(n_235)
);

INVx1_ASAP7_75t_L g236 ( 
.A(n_217),
.Y(n_236)
);

A2O1A1Ixp33_ASAP7_75t_L g237 ( 
.A1(n_215),
.A2(n_131),
.B(n_9),
.C(n_7),
.Y(n_237)
);

NAND2xp5_ASAP7_75t_L g238 ( 
.A(n_198),
.B(n_184),
.Y(n_238)
);

AOI22xp33_ASAP7_75t_L g239 ( 
.A1(n_229),
.A2(n_187),
.B1(n_80),
.B2(n_79),
.Y(n_239)
);

AOI22xp5_ASAP7_75t_L g240 ( 
.A1(n_216),
.A2(n_187),
.B1(n_133),
.B2(n_71),
.Y(n_240)
);

INVx2_ASAP7_75t_L g241 ( 
.A(n_208),
.Y(n_241)
);

AOI322xp5_ASAP7_75t_L g242 ( 
.A1(n_201),
.A2(n_12),
.A3(n_10),
.B1(n_13),
.B2(n_14),
.C1(n_103),
.C2(n_104),
.Y(n_242)
);

INVx2_ASAP7_75t_L g243 ( 
.A(n_208),
.Y(n_243)
);

NAND3xp33_ASAP7_75t_SL g244 ( 
.A(n_222),
.B(n_14),
.C(n_12),
.Y(n_244)
);

NAND2xp5_ASAP7_75t_L g245 ( 
.A(n_214),
.B(n_72),
.Y(n_245)
);

AOI21xp5_ASAP7_75t_L g246 ( 
.A1(n_223),
.A2(n_123),
.B(n_89),
.Y(n_246)
);

INVx1_ASAP7_75t_L g247 ( 
.A(n_204),
.Y(n_247)
);

INVx2_ASAP7_75t_L g248 ( 
.A(n_195),
.Y(n_248)
);

INVx1_ASAP7_75t_L g249 ( 
.A(n_195),
.Y(n_249)
);

INVx1_ASAP7_75t_L g250 ( 
.A(n_209),
.Y(n_250)
);

OAI32xp33_ASAP7_75t_L g251 ( 
.A1(n_206),
.A2(n_66),
.A3(n_105),
.B1(n_103),
.B2(n_104),
.Y(n_251)
);

INVx1_ASAP7_75t_L g252 ( 
.A(n_209),
.Y(n_252)
);

INVx1_ASAP7_75t_L g253 ( 
.A(n_214),
.Y(n_253)
);

INVx3_ASAP7_75t_L g254 ( 
.A(n_228),
.Y(n_254)
);

INVx1_ASAP7_75t_L g255 ( 
.A(n_196),
.Y(n_255)
);

OAI221xp5_ASAP7_75t_L g256 ( 
.A1(n_200),
.A2(n_66),
.B1(n_72),
.B2(n_105),
.C(n_108),
.Y(n_256)
);

OR2x2_ASAP7_75t_L g257 ( 
.A(n_202),
.B(n_72),
.Y(n_257)
);

OR2x2_ASAP7_75t_L g258 ( 
.A(n_205),
.B(n_72),
.Y(n_258)
);

AOI22xp33_ASAP7_75t_L g259 ( 
.A1(n_216),
.A2(n_66),
.B1(n_89),
.B2(n_108),
.Y(n_259)
);

OAI32xp33_ASAP7_75t_L g260 ( 
.A1(n_201),
.A2(n_66),
.A3(n_22),
.B1(n_18),
.B2(n_19),
.Y(n_260)
);

OAI22xp5_ASAP7_75t_L g261 ( 
.A1(n_219),
.A2(n_108),
.B1(n_89),
.B2(n_95),
.Y(n_261)
);

NAND2xp5_ASAP7_75t_L g262 ( 
.A(n_207),
.B(n_23),
.Y(n_262)
);

OAI21xp5_ASAP7_75t_L g263 ( 
.A1(n_213),
.A2(n_101),
.B(n_95),
.Y(n_263)
);

INVx1_ASAP7_75t_L g264 ( 
.A(n_227),
.Y(n_264)
);

INVx2_ASAP7_75t_L g265 ( 
.A(n_212),
.Y(n_265)
);

INVxp67_ASAP7_75t_L g266 ( 
.A(n_218),
.Y(n_266)
);

OAI32xp33_ASAP7_75t_L g267 ( 
.A1(n_218),
.A2(n_25),
.A3(n_24),
.B1(n_27),
.B2(n_28),
.Y(n_267)
);

OAI32xp33_ASAP7_75t_L g268 ( 
.A1(n_223),
.A2(n_31),
.A3(n_29),
.B1(n_32),
.B2(n_33),
.Y(n_268)
);

INVx1_ASAP7_75t_L g269 ( 
.A(n_234),
.Y(n_269)
);

AND2x2_ASAP7_75t_L g270 ( 
.A(n_266),
.B(n_193),
.Y(n_270)
);

NAND2xp5_ASAP7_75t_L g271 ( 
.A(n_255),
.B(n_193),
.Y(n_271)
);

AND2x2_ASAP7_75t_L g272 ( 
.A(n_266),
.B(n_226),
.Y(n_272)
);

INVx1_ASAP7_75t_L g273 ( 
.A(n_235),
.Y(n_273)
);

INVx1_ASAP7_75t_L g274 ( 
.A(n_247),
.Y(n_274)
);

AND2x2_ASAP7_75t_L g275 ( 
.A(n_232),
.B(n_226),
.Y(n_275)
);

INVx1_ASAP7_75t_L g276 ( 
.A(n_236),
.Y(n_276)
);

NAND2xp5_ASAP7_75t_L g277 ( 
.A(n_232),
.B(n_203),
.Y(n_277)
);

O2A1O1Ixp33_ASAP7_75t_L g278 ( 
.A1(n_237),
.A2(n_244),
.B(n_233),
.C(n_260),
.Y(n_278)
);

AOI21xp5_ASAP7_75t_L g279 ( 
.A1(n_237),
.A2(n_210),
.B(n_224),
.Y(n_279)
);

NAND2xp5_ASAP7_75t_L g280 ( 
.A(n_264),
.B(n_203),
.Y(n_280)
);

OR2x2_ASAP7_75t_L g281 ( 
.A(n_241),
.B(n_221),
.Y(n_281)
);

O2A1O1Ixp5_ASAP7_75t_L g282 ( 
.A1(n_231),
.A2(n_220),
.B(n_212),
.C(n_221),
.Y(n_282)
);

INVx1_ASAP7_75t_L g283 ( 
.A(n_249),
.Y(n_283)
);

INVx1_ASAP7_75t_L g284 ( 
.A(n_250),
.Y(n_284)
);

BUFx2_ASAP7_75t_L g285 ( 
.A(n_254),
.Y(n_285)
);

INVx1_ASAP7_75t_L g286 ( 
.A(n_252),
.Y(n_286)
);

INVx1_ASAP7_75t_L g287 ( 
.A(n_248),
.Y(n_287)
);

NAND2xp5_ASAP7_75t_L g288 ( 
.A(n_265),
.B(n_224),
.Y(n_288)
);

NAND2xp5_ASAP7_75t_SL g289 ( 
.A(n_257),
.B(n_230),
.Y(n_289)
);

AOI31xp33_ASAP7_75t_SL g290 ( 
.A1(n_238),
.A2(n_220),
.A3(n_197),
.B(n_211),
.Y(n_290)
);

NOR2x1_ASAP7_75t_L g291 ( 
.A(n_244),
.B(n_228),
.Y(n_291)
);

INVx1_ASAP7_75t_L g292 ( 
.A(n_253),
.Y(n_292)
);

NAND2xp5_ASAP7_75t_L g293 ( 
.A(n_243),
.B(n_258),
.Y(n_293)
);

NAND2xp5_ASAP7_75t_L g294 ( 
.A(n_254),
.B(n_35),
.Y(n_294)
);

BUFx2_ASAP7_75t_L g295 ( 
.A(n_245),
.Y(n_295)
);

INVxp67_ASAP7_75t_L g296 ( 
.A(n_262),
.Y(n_296)
);

HB1xp67_ASAP7_75t_L g297 ( 
.A(n_240),
.Y(n_297)
);

OAI22xp5_ASAP7_75t_L g298 ( 
.A1(n_239),
.A2(n_259),
.B1(n_261),
.B2(n_256),
.Y(n_298)
);

OAI21xp5_ASAP7_75t_L g299 ( 
.A1(n_242),
.A2(n_38),
.B(n_36),
.Y(n_299)
);

INVx1_ASAP7_75t_L g300 ( 
.A(n_273),
.Y(n_300)
);

OAI211xp5_ASAP7_75t_L g301 ( 
.A1(n_278),
.A2(n_239),
.B(n_251),
.C(n_267),
.Y(n_301)
);

OAI21xp5_ASAP7_75t_L g302 ( 
.A1(n_291),
.A2(n_282),
.B(n_279),
.Y(n_302)
);

AND2x4_ASAP7_75t_L g303 ( 
.A(n_285),
.B(n_295),
.Y(n_303)
);

OAI21xp5_ASAP7_75t_L g304 ( 
.A1(n_299),
.A2(n_268),
.B(n_246),
.Y(n_304)
);

NOR2xp33_ASAP7_75t_L g305 ( 
.A(n_296),
.B(n_259),
.Y(n_305)
);

INVx2_ASAP7_75t_SL g306 ( 
.A(n_285),
.Y(n_306)
);

OAI211xp5_ASAP7_75t_SL g307 ( 
.A1(n_277),
.A2(n_263),
.B(n_246),
.C(n_40),
.Y(n_307)
);

OAI322xp33_ASAP7_75t_L g308 ( 
.A1(n_271),
.A2(n_89),
.A3(n_95),
.B1(n_101),
.B2(n_289),
.C1(n_273),
.C2(n_269),
.Y(n_308)
);

INVx1_ASAP7_75t_L g309 ( 
.A(n_283),
.Y(n_309)
);

OAI21xp5_ASAP7_75t_L g310 ( 
.A1(n_297),
.A2(n_101),
.B(n_95),
.Y(n_310)
);

INVx1_ASAP7_75t_L g311 ( 
.A(n_283),
.Y(n_311)
);

XOR2x2_ASAP7_75t_L g312 ( 
.A(n_289),
.B(n_89),
.Y(n_312)
);

NAND4xp25_ASAP7_75t_L g313 ( 
.A(n_295),
.B(n_298),
.C(n_274),
.D(n_276),
.Y(n_313)
);

AOI21xp33_ASAP7_75t_L g314 ( 
.A1(n_294),
.A2(n_89),
.B(n_95),
.Y(n_314)
);

INVxp67_ASAP7_75t_L g315 ( 
.A(n_275),
.Y(n_315)
);

OAI21xp33_ASAP7_75t_L g316 ( 
.A1(n_270),
.A2(n_89),
.B(n_95),
.Y(n_316)
);

NOR2x1_ASAP7_75t_L g317 ( 
.A(n_284),
.B(n_95),
.Y(n_317)
);

INVxp67_ASAP7_75t_L g318 ( 
.A(n_275),
.Y(n_318)
);

AOI22xp5_ASAP7_75t_L g319 ( 
.A1(n_301),
.A2(n_302),
.B1(n_304),
.B2(n_313),
.Y(n_319)
);

AND2x2_ASAP7_75t_L g320 ( 
.A(n_303),
.B(n_270),
.Y(n_320)
);

NOR2x1_ASAP7_75t_L g321 ( 
.A(n_303),
.B(n_300),
.Y(n_321)
);

NAND2xp5_ASAP7_75t_L g322 ( 
.A(n_309),
.B(n_286),
.Y(n_322)
);

NAND2xp5_ASAP7_75t_L g323 ( 
.A(n_311),
.B(n_292),
.Y(n_323)
);

INVx1_ASAP7_75t_L g324 ( 
.A(n_315),
.Y(n_324)
);

INVx1_ASAP7_75t_SL g325 ( 
.A(n_306),
.Y(n_325)
);

OAI211xp5_ASAP7_75t_L g326 ( 
.A1(n_305),
.A2(n_288),
.B(n_280),
.C(n_293),
.Y(n_326)
);

NAND2xp5_ASAP7_75t_L g327 ( 
.A(n_318),
.B(n_272),
.Y(n_327)
);

INVx2_ASAP7_75t_SL g328 ( 
.A(n_317),
.Y(n_328)
);

AOI211xp5_ASAP7_75t_L g329 ( 
.A1(n_319),
.A2(n_307),
.B(n_308),
.C(n_290),
.Y(n_329)
);

O2A1O1Ixp5_ASAP7_75t_SL g330 ( 
.A1(n_326),
.A2(n_314),
.B(n_310),
.C(n_287),
.Y(n_330)
);

O2A1O1Ixp33_ASAP7_75t_L g331 ( 
.A1(n_328),
.A2(n_308),
.B(n_316),
.C(n_312),
.Y(n_331)
);

NAND4xp25_ASAP7_75t_L g332 ( 
.A(n_325),
.B(n_272),
.C(n_281),
.D(n_287),
.Y(n_332)
);

NAND4xp25_ASAP7_75t_SL g333 ( 
.A(n_321),
.B(n_325),
.C(n_320),
.D(n_324),
.Y(n_333)
);

XNOR2x1_ASAP7_75t_L g334 ( 
.A(n_327),
.B(n_281),
.Y(n_334)
);

AO22x2_ASAP7_75t_L g335 ( 
.A1(n_333),
.A2(n_322),
.B1(n_323),
.B2(n_95),
.Y(n_335)
);

INVx1_ASAP7_75t_L g336 ( 
.A(n_331),
.Y(n_336)
);

INVx1_ASAP7_75t_L g337 ( 
.A(n_329),
.Y(n_337)
);

NAND2xp5_ASAP7_75t_L g338 ( 
.A(n_336),
.B(n_337),
.Y(n_338)
);

INVx1_ASAP7_75t_L g339 ( 
.A(n_335),
.Y(n_339)
);

HB1xp67_ASAP7_75t_L g340 ( 
.A(n_339),
.Y(n_340)
);

INVx1_ASAP7_75t_L g341 ( 
.A(n_340),
.Y(n_341)
);

AOI22xp5_ASAP7_75t_L g342 ( 
.A1(n_341),
.A2(n_338),
.B1(n_335),
.B2(n_332),
.Y(n_342)
);

AOI221xp5_ASAP7_75t_L g343 ( 
.A1(n_342),
.A2(n_101),
.B1(n_330),
.B2(n_334),
.C(n_340),
.Y(n_343)
);


endmodule