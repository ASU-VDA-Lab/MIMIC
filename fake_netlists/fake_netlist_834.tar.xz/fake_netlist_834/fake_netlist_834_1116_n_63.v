module fake_netlist_834_1116_n_63 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_63);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_63;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_23;
wire n_34;
wire n_40;
wire n_44;
wire n_39;
wire n_28;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_55;
wire n_21;
wire n_35;
wire n_52;
wire n_38;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_18),
.B(n_1),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_17),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_3),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_14),
.A2(n_7),
.B1(n_0),
.B2(n_11),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_9),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_2),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_13),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

INVx4_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_0),
.Y(n_34)
);

AO22x1_ASAP7_75t_L g35 ( 
.A1(n_25),
.A2(n_17),
.B1(n_16),
.B2(n_2),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_21),
.Y(n_36)
);

AND2x6_ASAP7_75t_L g37 ( 
.A(n_24),
.B(n_4),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_SL g39 ( 
.A1(n_35),
.A2(n_25),
.B1(n_26),
.B2(n_22),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_22),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

NAND3xp33_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_34),
.C(n_35),
.Y(n_42)
);

AO22x1_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_39),
.B1(n_27),
.B2(n_30),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_33),
.C(n_26),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_38),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

NAND2xp33_ASAP7_75t_R g48 ( 
.A(n_43),
.B(n_41),
.Y(n_48)
);

INVx1_ASAP7_75t_SL g49 ( 
.A(n_46),
.Y(n_49)
);

AOI21xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_41),
.B(n_42),
.Y(n_50)
);

NOR2xp33_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_46),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_41),
.B1(n_28),
.B2(n_29),
.Y(n_52)
);

CKINVDCx20_ASAP7_75t_R g53 ( 
.A(n_49),
.Y(n_53)
);

AOI21xp33_ASAP7_75t_SL g54 ( 
.A1(n_51),
.A2(n_38),
.B(n_18),
.Y(n_54)
);

A2O1A1Ixp33_ASAP7_75t_SL g55 ( 
.A1(n_50),
.A2(n_41),
.B(n_37),
.C(n_19),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_41),
.B1(n_37),
.B2(n_20),
.Y(n_56)
);

OAI322xp33_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_20),
.A3(n_10),
.B1(n_8),
.B2(n_5),
.C1(n_15),
.C2(n_12),
.Y(n_57)
);

OR2x2_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_55),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_53),
.Y(n_59)
);

HB1xp67_ASAP7_75t_L g60 ( 
.A(n_53),
.Y(n_60)
);

CKINVDCx20_ASAP7_75t_R g61 ( 
.A(n_60),
.Y(n_61)
);

XNOR2x1_ASAP7_75t_L g62 ( 
.A(n_59),
.B(n_58),
.Y(n_62)
);

AOI22xp5_ASAP7_75t_SL g63 ( 
.A1(n_61),
.A2(n_57),
.B1(n_62),
.B2(n_35),
.Y(n_63)
);


endmodule