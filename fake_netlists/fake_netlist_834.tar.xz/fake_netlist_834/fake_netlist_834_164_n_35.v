module fake_netlist_834_164_n_35 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_35);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_35;

wire n_25;
wire n_20;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_17),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_16),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_4),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_1),
.Y(n_26)
);

AO32x1_ASAP7_75t_L g27 ( 
.A1(n_20),
.A2(n_3),
.A3(n_2),
.B1(n_5),
.B2(n_6),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_21),
.Y(n_28)
);

OR2x6_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_24),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_25),
.B1(n_22),
.B2(n_24),
.Y(n_30)
);

AOI21xp33_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_28),
.B(n_8),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_9),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_34)
);

OAI221xp5_ASAP7_75t_R g35 ( 
.A1(n_34),
.A2(n_15),
.B1(n_14),
.B2(n_18),
.C(n_19),
.Y(n_35)
);


endmodule