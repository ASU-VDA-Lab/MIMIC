module fake_netlist_834_1568_n_21 (n_4, n_2, n_5, n_3, n_0, n_1, n_21);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_21;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

AO21x2_ASAP7_75t_L g7 ( 
.A1(n_3),
.A2(n_0),
.B(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_6),
.Y(n_9)
);

INVxp67_ASAP7_75t_SL g10 ( 
.A(n_8),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

AOI222xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.B1(n_2),
.B2(n_0),
.C1(n_4),
.C2(n_1),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_9),
.B(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_9),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_9),
.B(n_4),
.C(n_2),
.Y(n_16)
);

NOR2x1p5_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_14),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_13),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B1(n_9),
.B2(n_3),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_4),
.B1(n_5),
.B2(n_18),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_5),
.B(n_20),
.Y(n_21)
);


endmodule