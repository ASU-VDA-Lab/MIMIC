module fake_netlist_834_1055_n_18 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_18);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_18;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;

CKINVDCx6p67_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_7),
.B(n_2),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_10),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_12),
.B1(n_4),
.B2(n_1),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_4),
.B2(n_1),
.Y(n_16)
);

OAI221xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_6),
.B1(n_5),
.B2(n_0),
.C(n_3),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_6),
.B1(n_9),
.B2(n_8),
.Y(n_18)
);


endmodule