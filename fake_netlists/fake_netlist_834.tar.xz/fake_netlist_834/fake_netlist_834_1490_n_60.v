module fake_netlist_834_1490_n_60 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_60);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_60;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

NAND2x1_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_13),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_2),
.B(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_26),
.B(n_5),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_5),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_19),
.B(n_16),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_22),
.B(n_23),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_29),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_25),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_33),
.B(n_25),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_36),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_31),
.B1(n_34),
.B2(n_32),
.C(n_33),
.Y(n_41)
);

OAI221xp5_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_32),
.B1(n_30),
.B2(n_27),
.C(n_21),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

INVx2_ASAP7_75t_SL g44 ( 
.A(n_43),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_38),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_39),
.Y(n_46)
);

XNOR2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_39),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_39),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_39),
.Y(n_49)
);

OAI22xp33_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_27),
.B1(n_37),
.B2(n_24),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_37),
.Y(n_51)
);

NOR2xp33_ASAP7_75t_R g52 ( 
.A(n_47),
.B(n_0),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_16),
.Y(n_53)
);

OAI211xp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_9),
.B(n_7),
.C(n_6),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

HB1xp67_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

NOR4xp25_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_14),
.C(n_42),
.D(n_32),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_51),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

AOI22xp5_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_58),
.B1(n_56),
.B2(n_57),
.Y(n_60)
);


endmodule