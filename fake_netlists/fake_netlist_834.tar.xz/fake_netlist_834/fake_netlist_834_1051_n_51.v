module fake_netlist_834_1051_n_51 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_51);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_51;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_47;
wire n_17;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;
wire n_43;
wire n_45;
wire n_46;

INVx3_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_3),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_SL g19 ( 
.A(n_6),
.B(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_7),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_8),
.B(n_10),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

BUFx4f_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_13),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_17),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_19),
.B(n_13),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

OR2x6_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

OR2x6_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_25),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_26),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_29),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_30),
.Y(n_37)
);

AOI21xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_32),
.B(n_18),
.Y(n_38)
);

AOI221xp5_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_27),
.B1(n_20),
.B2(n_15),
.C(n_22),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_37),
.B1(n_38),
.B2(n_15),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

INVx1_ASAP7_75t_SL g44 ( 
.A(n_40),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_14),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

NAND3xp33_ASAP7_75t_SL g47 ( 
.A(n_42),
.B(n_41),
.C(n_1),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_5),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_47),
.B1(n_49),
.B2(n_48),
.Y(n_51)
);


endmodule