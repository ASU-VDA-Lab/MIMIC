module fake_netlist_834_710_n_210 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_210);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_210;

wire n_49;
wire n_132;
wire n_97;
wire n_194;
wire n_81;
wire n_182;
wire n_114;
wire n_130;
wire n_80;
wire n_166;
wire n_123;
wire n_173;
wire n_156;
wire n_126;
wire n_154;
wire n_78;
wire n_153;
wire n_187;
wire n_195;
wire n_87;
wire n_167;
wire n_122;
wire n_54;
wire n_96;
wire n_95;
wire n_56;
wire n_59;
wire n_63;
wire n_94;
wire n_74;
wire n_64;
wire n_79;
wire n_177;
wire n_110;
wire n_61;
wire n_184;
wire n_86;
wire n_43;
wire n_45;
wire n_108;
wire n_192;
wire n_48;
wire n_163;
wire n_162;
wire n_209;
wire n_196;
wire n_158;
wire n_135;
wire n_171;
wire n_47;
wire n_118;
wire n_127;
wire n_202;
wire n_90;
wire n_76;
wire n_189;
wire n_160;
wire n_107;
wire n_125;
wire n_99;
wire n_151;
wire n_178;
wire n_72;
wire n_121;
wire n_73;
wire n_37;
wire n_207;
wire n_42;
wire n_120;
wire n_103;
wire n_155;
wire n_145;
wire n_200;
wire n_175;
wire n_185;
wire n_52;
wire n_199;
wire n_143;
wire n_170;
wire n_77;
wire n_161;
wire n_27;
wire n_190;
wire n_137;
wire n_57;
wire n_51;
wire n_138;
wire n_25;
wire n_136;
wire n_116;
wire n_179;
wire n_102;
wire n_119;
wire n_89;
wire n_152;
wire n_70;
wire n_172;
wire n_131;
wire n_128;
wire n_133;
wire n_139;
wire n_142;
wire n_115;
wire n_109;
wire n_41;
wire n_62;
wire n_44;
wire n_34;
wire n_40;
wire n_28;
wire n_117;
wire n_53;
wire n_144;
wire n_84;
wire n_58;
wire n_68;
wire n_183;
wire n_146;
wire n_104;
wire n_105;
wire n_168;
wire n_33;
wire n_106;
wire n_149;
wire n_188;
wire n_85;
wire n_205;
wire n_55;
wire n_164;
wire n_65;
wire n_159;
wire n_75;
wire n_140;
wire n_176;
wire n_67;
wire n_66;
wire n_101;
wire n_98;
wire n_91;
wire n_36;
wire n_203;
wire n_204;
wire n_50;
wire n_191;
wire n_112;
wire n_129;
wire n_181;
wire n_157;
wire n_198;
wire n_201;
wire n_83;
wire n_60;
wire n_39;
wire n_111;
wire n_32;
wire n_31;
wire n_169;
wire n_180;
wire n_93;
wire n_174;
wire n_26;
wire n_150;
wire n_71;
wire n_208;
wire n_92;
wire n_82;
wire n_186;
wire n_100;
wire n_69;
wire n_193;
wire n_165;
wire n_88;
wire n_29;
wire n_124;
wire n_197;
wire n_113;
wire n_30;
wire n_206;
wire n_147;
wire n_141;
wire n_134;
wire n_35;
wire n_148;
wire n_38;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_1),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_18),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_18),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_4),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_5),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_9),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_8),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_17),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_14),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_15),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_7),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_33),
.Y(n_40)
);

OR2x6_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_4),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_33),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_L g43 ( 
.A(n_37),
.B(n_26),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_28),
.Y(n_44)
);

INVx3_ASAP7_75t_L g45 ( 
.A(n_28),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_35),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_35),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_38),
.Y(n_48)
);

BUFx6f_ASAP7_75t_L g49 ( 
.A(n_38),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_39),
.Y(n_50)
);

INVx3_ASAP7_75t_L g51 ( 
.A(n_39),
.Y(n_51)
);

CKINVDCx20_ASAP7_75t_R g52 ( 
.A(n_27),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_26),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_40),
.B(n_25),
.Y(n_54)
);

BUFx8_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

OR2x2_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_36),
.Y(n_56)
);

INVx4_ASAP7_75t_L g57 ( 
.A(n_49),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_43),
.B(n_6),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_40),
.B(n_6),
.Y(n_59)
);

NOR2xp33_ASAP7_75t_L g60 ( 
.A(n_41),
.B(n_29),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_49),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_SL g62 ( 
.A(n_49),
.B(n_30),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_49),
.Y(n_63)
);

AND2x6_ASAP7_75t_L g64 ( 
.A(n_42),
.B(n_0),
.Y(n_64)
);

INVx2_ASAP7_75t_SL g65 ( 
.A(n_42),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_45),
.B(n_51),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_49),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_45),
.B(n_51),
.Y(n_68)
);

AND2x6_ASAP7_75t_L g69 ( 
.A(n_45),
.B(n_51),
.Y(n_69)
);

BUFx3_ASAP7_75t_L g70 ( 
.A(n_45),
.Y(n_70)
);

OR2x2_ASAP7_75t_L g71 ( 
.A(n_51),
.B(n_7),
.Y(n_71)
);

HB1xp67_ASAP7_75t_L g72 ( 
.A(n_41),
.Y(n_72)
);

AOI21xp5_ASAP7_75t_L g73 ( 
.A1(n_68),
.A2(n_41),
.B(n_46),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_70),
.Y(n_74)
);

A2O1A1Ixp33_ASAP7_75t_L g75 ( 
.A1(n_58),
.A2(n_50),
.B(n_44),
.C(n_46),
.Y(n_75)
);

NOR2x1_ASAP7_75t_SL g76 ( 
.A(n_71),
.B(n_41),
.Y(n_76)
);

OAI21xp5_ASAP7_75t_L g77 ( 
.A1(n_69),
.A2(n_41),
.B(n_44),
.Y(n_77)
);

NAND2xp5_ASAP7_75t_L g78 ( 
.A(n_70),
.B(n_47),
.Y(n_78)
);

NOR2xp33_ASAP7_75t_L g79 ( 
.A(n_72),
.B(n_50),
.Y(n_79)
);

AO32x2_ASAP7_75t_L g80 ( 
.A1(n_57),
.A2(n_48),
.A3(n_47),
.B1(n_8),
.B2(n_9),
.Y(n_80)
);

O2A1O1Ixp5_ASAP7_75t_L g81 ( 
.A1(n_66),
.A2(n_48),
.B(n_13),
.C(n_10),
.Y(n_81)
);

AND2x2_ASAP7_75t_L g82 ( 
.A(n_58),
.B(n_10),
.Y(n_82)
);

AOI21x1_ASAP7_75t_L g83 ( 
.A1(n_66),
.A2(n_3),
.B(n_2),
.Y(n_83)
);

OAI21x1_ASAP7_75t_L g84 ( 
.A1(n_68),
.A2(n_11),
.B(n_13),
.Y(n_84)
);

INVx2_ASAP7_75t_SL g85 ( 
.A(n_69),
.Y(n_85)
);

BUFx3_ASAP7_75t_L g86 ( 
.A(n_69),
.Y(n_86)
);

OR2x2_ASAP7_75t_L g87 ( 
.A(n_56),
.B(n_62),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_70),
.Y(n_88)
);

AOI21x1_ASAP7_75t_L g89 ( 
.A1(n_61),
.A2(n_15),
.B(n_14),
.Y(n_89)
);

AND2x2_ASAP7_75t_L g90 ( 
.A(n_54),
.B(n_52),
.Y(n_90)
);

INVxp67_ASAP7_75t_L g91 ( 
.A(n_56),
.Y(n_91)
);

NAND2xp5_ASAP7_75t_L g92 ( 
.A(n_65),
.B(n_16),
.Y(n_92)
);

OAI22x1_ASAP7_75t_L g93 ( 
.A1(n_91),
.A2(n_60),
.B1(n_71),
.B2(n_54),
.Y(n_93)
);

NAND2xp5_ASAP7_75t_L g94 ( 
.A(n_73),
.B(n_69),
.Y(n_94)
);

INVxp67_ASAP7_75t_L g95 ( 
.A(n_90),
.Y(n_95)
);

O2A1O1Ixp33_ASAP7_75t_L g96 ( 
.A1(n_75),
.A2(n_59),
.B(n_65),
.C(n_63),
.Y(n_96)
);

BUFx2_ASAP7_75t_L g97 ( 
.A(n_91),
.Y(n_97)
);

O2A1O1Ixp33_ASAP7_75t_L g98 ( 
.A1(n_81),
.A2(n_82),
.B(n_77),
.C(n_92),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_73),
.B(n_78),
.Y(n_99)
);

AND2x2_ASAP7_75t_L g100 ( 
.A(n_79),
.B(n_65),
.Y(n_100)
);

OR2x2_ASAP7_75t_L g101 ( 
.A(n_87),
.B(n_59),
.Y(n_101)
);

OA21x2_ASAP7_75t_L g102 ( 
.A1(n_81),
.A2(n_67),
.B(n_69),
.Y(n_102)
);

AOI211xp5_ASAP7_75t_L g103 ( 
.A1(n_82),
.A2(n_34),
.B(n_32),
.C(n_31),
.Y(n_103)
);

AOI21xp5_ASAP7_75t_L g104 ( 
.A1(n_78),
.A2(n_88),
.B(n_74),
.Y(n_104)
);

BUFx2_ASAP7_75t_L g105 ( 
.A(n_87),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_74),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_88),
.Y(n_107)
);

O2A1O1Ixp33_ASAP7_75t_L g108 ( 
.A1(n_82),
.A2(n_77),
.B(n_92),
.C(n_85),
.Y(n_108)
);

CKINVDCx5p33_ASAP7_75t_R g109 ( 
.A(n_90),
.Y(n_109)
);

AOI21xp5_ASAP7_75t_L g110 ( 
.A1(n_85),
.A2(n_57),
.B(n_69),
.Y(n_110)
);

BUFx6f_ASAP7_75t_L g111 ( 
.A(n_106),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_106),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_107),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_107),
.Y(n_114)
);

INVx2_ASAP7_75t_L g115 ( 
.A(n_102),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_104),
.Y(n_116)
);

NAND2xp5_ASAP7_75t_L g117 ( 
.A(n_100),
.B(n_76),
.Y(n_117)
);

AND2x4_ASAP7_75t_L g118 ( 
.A(n_95),
.B(n_105),
.Y(n_118)
);

AND2x4_ASAP7_75t_L g119 ( 
.A(n_105),
.B(n_86),
.Y(n_119)
);

HB1xp67_ASAP7_75t_L g120 ( 
.A(n_97),
.Y(n_120)
);

INVx1_ASAP7_75t_L g121 ( 
.A(n_104),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_112),
.Y(n_122)
);

INVx4_ASAP7_75t_L g123 ( 
.A(n_111),
.Y(n_123)
);

INVx2_ASAP7_75t_L g124 ( 
.A(n_111),
.Y(n_124)
);

OAI21xp5_ASAP7_75t_L g125 ( 
.A1(n_117),
.A2(n_98),
.B(n_108),
.Y(n_125)
);

INVx2_ASAP7_75t_L g126 ( 
.A(n_111),
.Y(n_126)
);

HB1xp67_ASAP7_75t_L g127 ( 
.A(n_120),
.Y(n_127)
);

BUFx2_ASAP7_75t_L g128 ( 
.A(n_119),
.Y(n_128)
);

HB1xp67_ASAP7_75t_L g129 ( 
.A(n_118),
.Y(n_129)
);

OR2x2_ASAP7_75t_L g130 ( 
.A(n_118),
.B(n_101),
.Y(n_130)
);

NOR2xp33_ASAP7_75t_SL g131 ( 
.A(n_123),
.B(n_109),
.Y(n_131)
);

INVxp67_ASAP7_75t_L g132 ( 
.A(n_127),
.Y(n_132)
);

NOR2xp33_ASAP7_75t_L g133 ( 
.A(n_130),
.B(n_97),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_122),
.Y(n_134)
);

INVxp33_ASAP7_75t_L g135 ( 
.A(n_129),
.Y(n_135)
);

INVx1_ASAP7_75t_L g136 ( 
.A(n_122),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_124),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_124),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_126),
.Y(n_139)
);

INVx2_ASAP7_75t_L g140 ( 
.A(n_126),
.Y(n_140)
);

AND2x2_ASAP7_75t_L g141 ( 
.A(n_130),
.B(n_101),
.Y(n_141)
);

AOI22xp33_ASAP7_75t_L g142 ( 
.A1(n_141),
.A2(n_93),
.B1(n_118),
.B2(n_128),
.Y(n_142)
);

INVx2_ASAP7_75t_L g143 ( 
.A(n_134),
.Y(n_143)
);

AOI22xp5_ASAP7_75t_L g144 ( 
.A1(n_133),
.A2(n_118),
.B1(n_93),
.B2(n_103),
.Y(n_144)
);

OAI21xp5_ASAP7_75t_L g145 ( 
.A1(n_137),
.A2(n_125),
.B(n_96),
.Y(n_145)
);

INVx1_ASAP7_75t_L g146 ( 
.A(n_134),
.Y(n_146)
);

AOI221x1_ASAP7_75t_L g147 ( 
.A1(n_136),
.A2(n_121),
.B1(n_116),
.B2(n_112),
.C(n_113),
.Y(n_147)
);

AND2x2_ASAP7_75t_L g148 ( 
.A(n_137),
.B(n_80),
.Y(n_148)
);

INVx2_ASAP7_75t_L g149 ( 
.A(n_136),
.Y(n_149)
);

OAI22xp5_ASAP7_75t_L g150 ( 
.A1(n_132),
.A2(n_103),
.B1(n_128),
.B2(n_113),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_138),
.Y(n_151)
);

AND2x2_ASAP7_75t_L g152 ( 
.A(n_138),
.B(n_80),
.Y(n_152)
);

OAI22xp5_ASAP7_75t_L g153 ( 
.A1(n_141),
.A2(n_114),
.B1(n_119),
.B2(n_111),
.Y(n_153)
);

OAI32xp33_ASAP7_75t_L g154 ( 
.A1(n_139),
.A2(n_114),
.A3(n_100),
.B1(n_116),
.B2(n_121),
.Y(n_154)
);

NAND2xp5_ASAP7_75t_SL g155 ( 
.A(n_131),
.B(n_111),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_139),
.Y(n_156)
);

NAND2xp5_ASAP7_75t_L g157 ( 
.A(n_144),
.B(n_140),
.Y(n_157)
);

NOR2xp33_ASAP7_75t_SL g158 ( 
.A(n_150),
.B(n_131),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_146),
.Y(n_159)
);

AOI221xp5_ASAP7_75t_L g160 ( 
.A1(n_142),
.A2(n_96),
.B1(n_98),
.B2(n_108),
.C(n_135),
.Y(n_160)
);

AOI32xp33_ASAP7_75t_L g161 ( 
.A1(n_146),
.A2(n_84),
.A3(n_80),
.B1(n_119),
.B2(n_140),
.Y(n_161)
);

AOI21xp5_ASAP7_75t_L g162 ( 
.A1(n_154),
.A2(n_99),
.B(n_123),
.Y(n_162)
);

NAND4xp25_ASAP7_75t_L g163 ( 
.A(n_144),
.B(n_140),
.C(n_119),
.D(n_99),
.Y(n_163)
);

AOI211xp5_ASAP7_75t_L g164 ( 
.A1(n_145),
.A2(n_84),
.B(n_80),
.C(n_111),
.Y(n_164)
);

NAND4xp75_ASAP7_75t_L g165 ( 
.A(n_155),
.B(n_55),
.C(n_94),
.D(n_102),
.Y(n_165)
);

AOI22xp5_ASAP7_75t_L g166 ( 
.A1(n_153),
.A2(n_55),
.B1(n_123),
.B2(n_64),
.Y(n_166)
);

AOI211xp5_ASAP7_75t_SL g167 ( 
.A1(n_151),
.A2(n_80),
.B(n_94),
.C(n_76),
.Y(n_167)
);

AOI21xp5_ASAP7_75t_L g168 ( 
.A1(n_154),
.A2(n_115),
.B(n_84),
.Y(n_168)
);

NOR2xp33_ASAP7_75t_L g169 ( 
.A(n_143),
.B(n_89),
.Y(n_169)
);

NOR2xp33_ASAP7_75t_R g170 ( 
.A(n_156),
.B(n_89),
.Y(n_170)
);

NAND3xp33_ASAP7_75t_L g171 ( 
.A(n_145),
.B(n_55),
.C(n_57),
.Y(n_171)
);

AOI21xp33_ASAP7_75t_L g172 ( 
.A1(n_156),
.A2(n_55),
.B(n_152),
.Y(n_172)
);

NAND2xp33_ASAP7_75t_L g173 ( 
.A(n_143),
.B(n_64),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_159),
.Y(n_174)
);

OAI21xp5_ASAP7_75t_L g175 ( 
.A1(n_158),
.A2(n_147),
.B(n_148),
.Y(n_175)
);

XOR2x2_ASAP7_75t_L g176 ( 
.A(n_167),
.B(n_16),
.Y(n_176)
);

NAND3xp33_ASAP7_75t_L g177 ( 
.A(n_163),
.B(n_157),
.C(n_160),
.Y(n_177)
);

AND2x2_ASAP7_75t_L g178 ( 
.A(n_169),
.B(n_149),
.Y(n_178)
);

NOR2xp33_ASAP7_75t_L g179 ( 
.A(n_172),
.B(n_17),
.Y(n_179)
);

NAND2xp5_ASAP7_75t_SL g180 ( 
.A(n_171),
.B(n_149),
.Y(n_180)
);

INVx1_ASAP7_75t_L g181 ( 
.A(n_170),
.Y(n_181)
);

INVxp67_ASAP7_75t_L g182 ( 
.A(n_165),
.Y(n_182)
);

AOI21xp5_ASAP7_75t_L g183 ( 
.A1(n_173),
.A2(n_162),
.B(n_164),
.Y(n_183)
);

INVx1_ASAP7_75t_L g184 ( 
.A(n_168),
.Y(n_184)
);

HB1xp67_ASAP7_75t_L g185 ( 
.A(n_166),
.Y(n_185)
);

INVxp67_ASAP7_75t_SL g186 ( 
.A(n_161),
.Y(n_186)
);

NOR2xp33_ASAP7_75t_L g187 ( 
.A(n_158),
.B(n_19),
.Y(n_187)
);

NAND3xp33_ASAP7_75t_L g188 ( 
.A(n_158),
.B(n_147),
.C(n_148),
.Y(n_188)
);

NAND3x1_ASAP7_75t_L g189 ( 
.A(n_187),
.B(n_152),
.C(n_83),
.Y(n_189)
);

BUFx4f_ASAP7_75t_SL g190 ( 
.A(n_181),
.Y(n_190)
);

OR5x1_ASAP7_75t_L g191 ( 
.A(n_176),
.B(n_80),
.C(n_21),
.D(n_19),
.E(n_20),
.Y(n_191)
);

AND2x4_ASAP7_75t_L g192 ( 
.A(n_174),
.B(n_83),
.Y(n_192)
);

NOR2xp67_ASAP7_75t_L g193 ( 
.A(n_183),
.B(n_22),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_174),
.Y(n_194)
);

AOI21xp33_ASAP7_75t_SL g195 ( 
.A1(n_177),
.A2(n_23),
.B(n_22),
.Y(n_195)
);

AND4x2_ASAP7_75t_L g196 ( 
.A(n_176),
.B(n_80),
.C(n_24),
.D(n_23),
.Y(n_196)
);

OR2x2_ASAP7_75t_L g197 ( 
.A(n_178),
.B(n_57),
.Y(n_197)
);

NAND4xp25_ASAP7_75t_L g198 ( 
.A(n_179),
.B(n_110),
.C(n_86),
.D(n_64),
.Y(n_198)
);

OAI32xp33_ASAP7_75t_L g199 ( 
.A1(n_191),
.A2(n_182),
.A3(n_185),
.B1(n_188),
.B2(n_184),
.Y(n_199)
);

NOR3xp33_ASAP7_75t_L g200 ( 
.A(n_195),
.B(n_193),
.C(n_198),
.Y(n_200)
);

CKINVDCx20_ASAP7_75t_R g201 ( 
.A(n_190),
.Y(n_201)
);

AOI221xp5_ASAP7_75t_L g202 ( 
.A1(n_194),
.A2(n_186),
.B1(n_175),
.B2(n_184),
.C(n_178),
.Y(n_202)
);

AND2x2_ASAP7_75t_L g203 ( 
.A(n_197),
.B(n_180),
.Y(n_203)
);

XNOR2xp5_ASAP7_75t_L g204 ( 
.A(n_201),
.B(n_203),
.Y(n_204)
);

INVx1_ASAP7_75t_SL g205 ( 
.A(n_199),
.Y(n_205)
);

INVx2_ASAP7_75t_L g206 ( 
.A(n_202),
.Y(n_206)
);

OAI22x1_ASAP7_75t_L g207 ( 
.A1(n_200),
.A2(n_196),
.B1(n_192),
.B2(n_189),
.Y(n_207)
);

OAI22xp5_ASAP7_75t_L g208 ( 
.A1(n_205),
.A2(n_206),
.B1(n_204),
.B2(n_200),
.Y(n_208)
);

AND2x4_ASAP7_75t_SL g209 ( 
.A(n_208),
.B(n_207),
.Y(n_209)
);

AOI22xp5_ASAP7_75t_L g210 ( 
.A1(n_209),
.A2(n_64),
.B1(n_69),
.B2(n_110),
.Y(n_210)
);


endmodule