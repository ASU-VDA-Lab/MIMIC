module fake_netlist_834_1272_n_26 (n_4, n_2, n_5, n_3, n_0, n_1, n_26);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_24;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

AND2x2_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_1),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_11)
);

OAI21x1_ASAP7_75t_SL g12 ( 
.A1(n_7),
.A2(n_3),
.B(n_2),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_8),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

NAND2x1_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_14),
.B(n_13),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_15),
.B1(n_14),
.B2(n_8),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_15),
.B1(n_13),
.B2(n_6),
.C(n_7),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_13),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_14),
.C(n_17),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_20),
.A2(n_4),
.B1(n_5),
.B2(n_15),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_5),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_23),
.B(n_24),
.Y(n_26)
);


endmodule