module fake_netlist_834_1240_n_18 (n_2, n_0, n_3, n_1, n_18);

input n_2;
input n_0;
input n_3;
input n_1;

output n_18;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_17;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_3),
.Y(n_4)
);

CKINVDCx11_ASAP7_75t_R g5 ( 
.A(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AND2x6_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

AND2x4_ASAP7_75t_SL g12 ( 
.A(n_8),
.B(n_5),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B1(n_7),
.B2(n_8),
.C1(n_10),
.C2(n_1),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_9),
.B1(n_7),
.B2(n_10),
.C(n_2),
.Y(n_14)
);

AOI321xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_9),
.A3(n_12),
.B1(n_2),
.B2(n_7),
.C(n_10),
.Y(n_15)
);

NOR2x1p5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_7),
.B1(n_10),
.B2(n_15),
.C1(n_9),
.C2(n_5),
.Y(n_18)
);


endmodule