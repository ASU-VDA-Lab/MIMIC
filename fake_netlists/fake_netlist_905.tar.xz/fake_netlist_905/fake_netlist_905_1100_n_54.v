module fake_netlist_905_1100_n_54 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_54);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_54;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_53;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_22;
wire n_25;
wire n_35;
wire n_32;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

INVx2_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_18),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_3),
.B(n_20),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_SL g26 ( 
.A(n_5),
.B(n_10),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_4),
.B(n_1),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

BUFx8_ASAP7_75t_L g31 ( 
.A(n_6),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_27),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_25),
.B(n_24),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_22),
.B(n_30),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_33),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

OAI31xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_35),
.A3(n_25),
.B(n_32),
.Y(n_40)
);

INVxp67_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_37),
.B1(n_36),
.B2(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_SL g43 ( 
.A(n_40),
.Y(n_43)
);

OR2x6_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_29),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_SL g45 ( 
.A1(n_43),
.A2(n_31),
.B(n_28),
.Y(n_45)
);

A2O1A1Ixp33_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_37),
.B(n_26),
.C(n_28),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_16),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_28),
.B1(n_18),
.B2(n_16),
.C(n_17),
.Y(n_49)
);

NOR4xp25_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_19),
.C(n_17),
.D(n_31),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_19),
.B1(n_8),
.B2(n_2),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_50),
.B1(n_12),
.B2(n_9),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_SL g54 ( 
.A1(n_53),
.A2(n_52),
.B1(n_15),
.B2(n_14),
.Y(n_54)
);


endmodule