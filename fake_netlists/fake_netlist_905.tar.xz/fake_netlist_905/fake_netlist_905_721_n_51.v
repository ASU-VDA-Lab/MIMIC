module fake_netlist_905_721_n_51 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_51);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_51;

wire n_33;
wire n_50;
wire n_34;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_28;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_3),
.Y(n_25)
);

OAI21x1_ASAP7_75t_L g26 ( 
.A1(n_7),
.A2(n_9),
.B(n_10),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_24),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_20),
.B(n_16),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_17),
.B(n_4),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_5),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_28),
.A2(n_24),
.B1(n_18),
.B2(n_16),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_33),
.B1(n_31),
.B2(n_27),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_26),
.B(n_29),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_36),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_30),
.B1(n_32),
.B2(n_25),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_R g41 ( 
.A(n_39),
.B(n_18),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_26),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_0),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_8),
.B1(n_2),
.B2(n_1),
.Y(n_44)
);

NOR2x1_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_12),
.Y(n_45)
);

BUFx6f_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

INVxp67_ASAP7_75t_SL g47 ( 
.A(n_46),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

OAI22x1_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_49)
);

INVxp33_ASAP7_75t_SL g50 ( 
.A(n_48),
.Y(n_50)
);

AOI222xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_21),
.B1(n_22),
.B2(n_23),
.C1(n_48),
.C2(n_49),
.Y(n_51)
);


endmodule