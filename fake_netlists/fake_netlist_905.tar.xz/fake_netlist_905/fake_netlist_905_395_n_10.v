module fake_netlist_905_395_n_10 (n_0, n_1, n_2, n_10);

input n_0;
input n_1;
input n_2;

output n_10;

wire n_5;
wire n_3;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

BUFx3_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx1_ASAP7_75t_SL g4 ( 
.A(n_1),
.Y(n_4)
);

AO31x2_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

OAI221xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_4),
.B1(n_3),
.B2(n_5),
.C(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule