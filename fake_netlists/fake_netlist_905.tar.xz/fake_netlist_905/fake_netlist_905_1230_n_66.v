module fake_netlist_905_1230_n_66 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_66);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_66;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_63;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_65;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_32;
wire n_22;
wire n_25;
wire n_41;
wire n_42;
wire n_35;
wire n_57;
wire n_43;
wire n_62;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;
wire n_56;

INVx1_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_0),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_10),
.B(n_18),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_16),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_7),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_4),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_15),
.A2(n_3),
.B1(n_13),
.B2(n_16),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_9),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_19),
.B(n_5),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_33),
.B(n_37),
.Y(n_39)
);

O2A1O1Ixp33_ASAP7_75t_SL g40 ( 
.A1(n_38),
.A2(n_27),
.B(n_26),
.C(n_24),
.Y(n_40)
);

OAI211xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_25),
.B(n_31),
.C(n_32),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_36),
.A2(n_24),
.B(n_34),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_29),
.Y(n_43)
);

OAI211xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_31),
.B(n_28),
.C(n_23),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_SL g45 ( 
.A1(n_42),
.A2(n_24),
.B(n_32),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_40),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

NAND3xp33_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_28),
.C(n_23),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

NAND2xp33_ASAP7_75t_SL g50 ( 
.A(n_43),
.B(n_34),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_43),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_48),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_SL g53 ( 
.A(n_50),
.B(n_34),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_SL g54 ( 
.A(n_47),
.B(n_34),
.Y(n_54)
);

AOI22xp5_ASAP7_75t_SL g55 ( 
.A1(n_51),
.A2(n_17),
.B1(n_3),
.B2(n_2),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_2),
.Y(n_56)
);

AOI322xp5_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_18),
.A3(n_17),
.B1(n_20),
.B2(n_21),
.C1(n_35),
.C2(n_6),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

NOR4xp25_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_55),
.C(n_58),
.D(n_57),
.Y(n_59)
);

NOR5xp2_ASAP7_75t_L g60 ( 
.A(n_58),
.B(n_21),
.C(n_20),
.D(n_8),
.E(n_11),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_55),
.Y(n_61)
);

CKINVDCx5p33_ASAP7_75t_R g62 ( 
.A(n_55),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_61),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_62),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_62),
.Y(n_65)
);

AOI322xp5_ASAP7_75t_L g66 ( 
.A1(n_64),
.A2(n_14),
.A3(n_35),
.B1(n_59),
.B2(n_60),
.C1(n_65),
.C2(n_63),
.Y(n_66)
);


endmodule