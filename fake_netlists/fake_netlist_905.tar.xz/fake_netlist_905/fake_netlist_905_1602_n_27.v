module fake_netlist_905_1602_n_27 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_27);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_27;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_22;
wire n_25;
wire n_26;

INVx2_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_19)
);

O2A1O1Ixp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_9),
.B(n_3),
.C(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_17),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_20),
.B(n_16),
.Y(n_23)
);

AOI322xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_22),
.A3(n_5),
.B1(n_4),
.B2(n_1),
.C1(n_7),
.C2(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OAI22x1_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_18),
.B1(n_6),
.B2(n_11),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_R g27 ( 
.A1(n_26),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_27)
);


endmodule