module fake_netlist_905_1944_n_194 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_26, n_10, n_8, n_194);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_26;
input n_10;
input n_8;

output n_194;

wire n_118;
wire n_100;
wire n_60;
wire n_104;
wire n_101;
wire n_52;
wire n_99;
wire n_127;
wire n_151;
wire n_152;
wire n_111;
wire n_154;
wire n_185;
wire n_153;
wire n_193;
wire n_30;
wire n_116;
wire n_164;
wire n_64;
wire n_102;
wire n_93;
wire n_157;
wire n_66;
wire n_65;
wire n_143;
wire n_88;
wire n_186;
wire n_169;
wire n_27;
wire n_192;
wire n_94;
wire n_182;
wire n_91;
wire n_71;
wire n_135;
wire n_174;
wire n_80;
wire n_149;
wire n_29;
wire n_69;
wire n_83;
wire n_134;
wire n_96;
wire n_128;
wire n_117;
wire n_131;
wire n_165;
wire n_190;
wire n_51;
wire n_50;
wire n_162;
wire n_55;
wire n_123;
wire n_110;
wire n_46;
wire n_183;
wire n_144;
wire n_54;
wire n_28;
wire n_59;
wire n_189;
wire n_177;
wire n_173;
wire n_166;
wire n_70;
wire n_40;
wire n_39;
wire n_132;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_126;
wire n_62;
wire n_120;
wire n_141;
wire n_150;
wire n_148;
wire n_188;
wire n_44;
wire n_79;
wire n_187;
wire n_87;
wire n_142;
wire n_159;
wire n_115;
wire n_155;
wire n_33;
wire n_184;
wire n_113;
wire n_129;
wire n_191;
wire n_172;
wire n_77;
wire n_107;
wire n_95;
wire n_53;
wire n_161;
wire n_180;
wire n_106;
wire n_137;
wire n_90;
wire n_167;
wire n_146;
wire n_81;
wire n_84;
wire n_171;
wire n_140;
wire n_61;
wire n_130;
wire n_122;
wire n_43;
wire n_138;
wire n_170;
wire n_139;
wire n_136;
wire n_48;
wire n_72;
wire n_176;
wire n_181;
wire n_133;
wire n_76;
wire n_38;
wire n_56;
wire n_175;
wire n_74;
wire n_125;
wire n_34;
wire n_179;
wire n_103;
wire n_37;
wire n_160;
wire n_108;
wire n_75;
wire n_47;
wire n_68;
wire n_158;
wire n_86;
wire n_63;
wire n_163;
wire n_105;
wire n_114;
wire n_124;
wire n_145;
wire n_85;
wire n_112;
wire n_156;
wire n_58;
wire n_49;
wire n_109;
wire n_147;
wire n_168;
wire n_67;
wire n_57;
wire n_35;
wire n_121;
wire n_97;
wire n_98;
wire n_119;
wire n_178;
wire n_36;
wire n_45;
wire n_73;
wire n_92;
wire n_89;
wire n_82;
wire n_78;

INVx1_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_8),
.Y(n_28)
);

CKINVDCx14_ASAP7_75t_R g29 ( 
.A(n_0),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_11),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_10),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_6),
.Y(n_33)
);

INVxp67_ASAP7_75t_SL g34 ( 
.A(n_24),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_20),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_17),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_26),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_9),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_13),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_2),
.Y(n_40)
);

INVxp67_ASAP7_75t_SL g41 ( 
.A(n_19),
.Y(n_41)
);

BUFx6f_ASAP7_75t_L g42 ( 
.A(n_16),
.Y(n_42)
);

INVxp67_ASAP7_75t_SL g43 ( 
.A(n_25),
.Y(n_43)
);

INVx2_ASAP7_75t_SL g44 ( 
.A(n_21),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_7),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_29),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_42),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_27),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_42),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_31),
.B(n_0),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_31),
.B(n_1),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_27),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_42),
.Y(n_53)
);

BUFx6f_ASAP7_75t_L g54 ( 
.A(n_42),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_28),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_28),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_48),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_52),
.Y(n_59)
);

AND2x4_ASAP7_75t_L g60 ( 
.A(n_50),
.B(n_33),
.Y(n_60)
);

AND2x6_ASAP7_75t_L g61 ( 
.A(n_50),
.B(n_30),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_55),
.Y(n_62)
);

AND2x4_ASAP7_75t_L g63 ( 
.A(n_50),
.B(n_33),
.Y(n_63)
);

AND2x4_ASAP7_75t_L g64 ( 
.A(n_50),
.B(n_45),
.Y(n_64)
);

INVxp67_ASAP7_75t_SL g65 ( 
.A(n_51),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_56),
.Y(n_66)
);

BUFx6f_ASAP7_75t_L g67 ( 
.A(n_54),
.Y(n_67)
);

INVx4_ASAP7_75t_L g68 ( 
.A(n_61),
.Y(n_68)
);

INVx2_ASAP7_75t_L g69 ( 
.A(n_58),
.Y(n_69)
);

BUFx6f_ASAP7_75t_L g70 ( 
.A(n_61),
.Y(n_70)
);

OR2x2_ASAP7_75t_L g71 ( 
.A(n_65),
.B(n_51),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_59),
.Y(n_72)
);

BUFx6f_ASAP7_75t_L g73 ( 
.A(n_61),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_59),
.Y(n_74)
);

BUFx3_ASAP7_75t_L g75 ( 
.A(n_61),
.Y(n_75)
);

INVx1_ASAP7_75t_SL g76 ( 
.A(n_61),
.Y(n_76)
);

INVx5_ASAP7_75t_L g77 ( 
.A(n_63),
.Y(n_77)
);

INVx2_ASAP7_75t_L g78 ( 
.A(n_62),
.Y(n_78)
);

INVx3_ASAP7_75t_L g79 ( 
.A(n_60),
.Y(n_79)
);

INVx4_ASAP7_75t_L g80 ( 
.A(n_60),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_66),
.Y(n_81)
);

INVx2_ASAP7_75t_L g82 ( 
.A(n_57),
.Y(n_82)
);

INVx2_ASAP7_75t_L g83 ( 
.A(n_57),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_60),
.Y(n_84)
);

BUFx8_ASAP7_75t_L g85 ( 
.A(n_64),
.Y(n_85)
);

BUFx6f_ASAP7_75t_L g86 ( 
.A(n_67),
.Y(n_86)
);

BUFx4f_ASAP7_75t_L g87 ( 
.A(n_63),
.Y(n_87)
);

INVx2_ASAP7_75t_L g88 ( 
.A(n_57),
.Y(n_88)
);

INVx4_ASAP7_75t_L g89 ( 
.A(n_70),
.Y(n_89)
);

NOR2xp33_ASAP7_75t_L g90 ( 
.A(n_71),
.B(n_46),
.Y(n_90)
);

INVxp67_ASAP7_75t_SL g91 ( 
.A(n_85),
.Y(n_91)
);

AO22x1_ASAP7_75t_L g92 ( 
.A1(n_85),
.A2(n_43),
.B1(n_41),
.B2(n_34),
.Y(n_92)
);

A2O1A1Ixp33_ASAP7_75t_L g93 ( 
.A1(n_72),
.A2(n_40),
.B(n_45),
.C(n_44),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_69),
.Y(n_94)
);

BUFx3_ASAP7_75t_L g95 ( 
.A(n_70),
.Y(n_95)
);

NOR2x1_ASAP7_75t_SL g96 ( 
.A(n_68),
.B(n_32),
.Y(n_96)
);

BUFx6f_ASAP7_75t_L g97 ( 
.A(n_70),
.Y(n_97)
);

INVx3_ASAP7_75t_L g98 ( 
.A(n_80),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_80),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_69),
.Y(n_100)
);

INVx2_ASAP7_75t_L g101 ( 
.A(n_69),
.Y(n_101)
);

BUFx6f_ASAP7_75t_L g102 ( 
.A(n_70),
.Y(n_102)
);

A2O1A1Ixp33_ASAP7_75t_L g103 ( 
.A1(n_74),
.A2(n_37),
.B(n_36),
.C(n_35),
.Y(n_103)
);

INVx3_ASAP7_75t_L g104 ( 
.A(n_79),
.Y(n_104)
);

BUFx2_ASAP7_75t_SL g105 ( 
.A(n_75),
.Y(n_105)
);

BUFx2_ASAP7_75t_L g106 ( 
.A(n_87),
.Y(n_106)
);

AOI21xp5_ASAP7_75t_L g107 ( 
.A1(n_74),
.A2(n_39),
.B(n_38),
.Y(n_107)
);

INVx6_ASAP7_75t_L g108 ( 
.A(n_77),
.Y(n_108)
);

INVx2_ASAP7_75t_L g109 ( 
.A(n_78),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_84),
.Y(n_110)
);

NAND2xp33_ASAP7_75t_L g111 ( 
.A(n_73),
.B(n_76),
.Y(n_111)
);

INVx2_ASAP7_75t_L g112 ( 
.A(n_81),
.Y(n_112)
);

AOI21xp5_ASAP7_75t_SL g113 ( 
.A1(n_97),
.A2(n_73),
.B(n_76),
.Y(n_113)
);

INVxp33_ASAP7_75t_L g114 ( 
.A(n_90),
.Y(n_114)
);

HB1xp67_ASAP7_75t_L g115 ( 
.A(n_91),
.Y(n_115)
);

INVx2_ASAP7_75t_L g116 ( 
.A(n_94),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_94),
.Y(n_117)
);

O2A1O1Ixp33_ASAP7_75t_SL g118 ( 
.A1(n_103),
.A2(n_53),
.B(n_49),
.C(n_47),
.Y(n_118)
);

AND2x4_ASAP7_75t_L g119 ( 
.A(n_106),
.B(n_82),
.Y(n_119)
);

INVx2_ASAP7_75t_L g120 ( 
.A(n_100),
.Y(n_120)
);

INVx2_ASAP7_75t_L g121 ( 
.A(n_101),
.Y(n_121)
);

AOI22xp33_ASAP7_75t_L g122 ( 
.A1(n_112),
.A2(n_88),
.B1(n_83),
.B2(n_82),
.Y(n_122)
);

INVx4_ASAP7_75t_L g123 ( 
.A(n_97),
.Y(n_123)
);

OR2x6_ASAP7_75t_L g124 ( 
.A(n_105),
.B(n_86),
.Y(n_124)
);

INVx2_ASAP7_75t_L g125 ( 
.A(n_109),
.Y(n_125)
);

BUFx3_ASAP7_75t_L g126 ( 
.A(n_108),
.Y(n_126)
);

BUFx3_ASAP7_75t_L g127 ( 
.A(n_97),
.Y(n_127)
);

INVx4_ASAP7_75t_L g128 ( 
.A(n_97),
.Y(n_128)
);

AO21x1_ASAP7_75t_SL g129 ( 
.A1(n_96),
.A2(n_110),
.B(n_99),
.Y(n_129)
);

OR2x2_ASAP7_75t_L g130 ( 
.A(n_92),
.B(n_93),
.Y(n_130)
);

AND2x4_ASAP7_75t_L g131 ( 
.A(n_104),
.B(n_98),
.Y(n_131)
);

AO31x2_ASAP7_75t_L g132 ( 
.A1(n_103),
.A2(n_5),
.A3(n_4),
.B(n_3),
.Y(n_132)
);

BUFx6f_ASAP7_75t_L g133 ( 
.A(n_102),
.Y(n_133)
);

INVx3_ASAP7_75t_L g134 ( 
.A(n_89),
.Y(n_134)
);

BUFx3_ASAP7_75t_L g135 ( 
.A(n_102),
.Y(n_135)
);

AOI22xp33_ASAP7_75t_L g136 ( 
.A1(n_114),
.A2(n_107),
.B1(n_111),
.B2(n_95),
.Y(n_136)
);

INVx2_ASAP7_75t_L g137 ( 
.A(n_116),
.Y(n_137)
);

INVx2_ASAP7_75t_L g138 ( 
.A(n_116),
.Y(n_138)
);

HB1xp67_ASAP7_75t_L g139 ( 
.A(n_117),
.Y(n_139)
);

AOI22xp33_ASAP7_75t_L g140 ( 
.A1(n_130),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_140)
);

AND2x2_ASAP7_75t_L g141 ( 
.A(n_115),
.B(n_22),
.Y(n_141)
);

INVx2_ASAP7_75t_L g142 ( 
.A(n_120),
.Y(n_142)
);

INVx2_ASAP7_75t_L g143 ( 
.A(n_120),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_132),
.Y(n_144)
);

INVx2_ASAP7_75t_L g145 ( 
.A(n_121),
.Y(n_145)
);

AND2x4_ASAP7_75t_L g146 ( 
.A(n_131),
.B(n_126),
.Y(n_146)
);

OAI21x1_ASAP7_75t_L g147 ( 
.A1(n_134),
.A2(n_113),
.B(n_125),
.Y(n_147)
);

BUFx6f_ASAP7_75t_L g148 ( 
.A(n_133),
.Y(n_148)
);

BUFx6f_ASAP7_75t_L g149 ( 
.A(n_133),
.Y(n_149)
);

OAI21xp5_ASAP7_75t_L g150 ( 
.A1(n_122),
.A2(n_119),
.B(n_118),
.Y(n_150)
);

AOI22xp33_ASAP7_75t_L g151 ( 
.A1(n_129),
.A2(n_124),
.B1(n_123),
.B2(n_128),
.Y(n_151)
);

AND2x4_ASAP7_75t_L g152 ( 
.A(n_139),
.B(n_123),
.Y(n_152)
);

INVx2_ASAP7_75t_L g153 ( 
.A(n_139),
.Y(n_153)
);

OA21x2_ASAP7_75t_L g154 ( 
.A1(n_144),
.A2(n_135),
.B(n_127),
.Y(n_154)
);

INVx2_ASAP7_75t_L g155 ( 
.A(n_137),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_142),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_143),
.Y(n_157)
);

OR2x2_ASAP7_75t_L g158 ( 
.A(n_145),
.B(n_138),
.Y(n_158)
);

AND2x2_ASAP7_75t_L g159 ( 
.A(n_146),
.B(n_141),
.Y(n_159)
);

AND2x2_ASAP7_75t_L g160 ( 
.A(n_151),
.B(n_150),
.Y(n_160)
);

AND2x2_ASAP7_75t_L g161 ( 
.A(n_147),
.B(n_136),
.Y(n_161)
);

AND2x2_ASAP7_75t_L g162 ( 
.A(n_136),
.B(n_140),
.Y(n_162)
);

AND2x4_ASAP7_75t_L g163 ( 
.A(n_148),
.B(n_149),
.Y(n_163)
);

AND2x2_ASAP7_75t_L g164 ( 
.A(n_153),
.B(n_160),
.Y(n_164)
);

INVx1_ASAP7_75t_L g165 ( 
.A(n_155),
.Y(n_165)
);

AND2x2_ASAP7_75t_L g166 ( 
.A(n_156),
.B(n_157),
.Y(n_166)
);

AND2x2_ASAP7_75t_L g167 ( 
.A(n_161),
.B(n_152),
.Y(n_167)
);

INVx1_ASAP7_75t_L g168 ( 
.A(n_154),
.Y(n_168)
);

AND2x2_ASAP7_75t_L g169 ( 
.A(n_158),
.B(n_162),
.Y(n_169)
);

BUFx2_ASAP7_75t_L g170 ( 
.A(n_154),
.Y(n_170)
);

AND2x2_ASAP7_75t_L g171 ( 
.A(n_159),
.B(n_163),
.Y(n_171)
);

AND2x2_ASAP7_75t_L g172 ( 
.A(n_167),
.B(n_164),
.Y(n_172)
);

AND2x2_ASAP7_75t_L g173 ( 
.A(n_167),
.B(n_169),
.Y(n_173)
);

AND2x2_ASAP7_75t_L g174 ( 
.A(n_171),
.B(n_165),
.Y(n_174)
);

AND2x2_ASAP7_75t_L g175 ( 
.A(n_166),
.B(n_168),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_175),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_174),
.Y(n_177)
);

AND2x2_ASAP7_75t_L g178 ( 
.A(n_172),
.B(n_170),
.Y(n_178)
);

AND2x2_ASAP7_75t_L g179 ( 
.A(n_178),
.B(n_173),
.Y(n_179)
);

INVx1_ASAP7_75t_L g180 ( 
.A(n_176),
.Y(n_180)
);

AND2x2_ASAP7_75t_L g181 ( 
.A(n_177),
.B(n_172),
.Y(n_181)
);

INVx1_ASAP7_75t_L g182 ( 
.A(n_180),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_180),
.Y(n_183)
);

HB1xp67_ASAP7_75t_L g184 ( 
.A(n_182),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_183),
.Y(n_185)
);

HB1xp67_ASAP7_75t_L g186 ( 
.A(n_184),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_184),
.Y(n_187)
);

INVx2_ASAP7_75t_L g188 ( 
.A(n_187),
.Y(n_188)
);

CKINVDCx20_ASAP7_75t_R g189 ( 
.A(n_186),
.Y(n_189)
);

NAND2xp5_ASAP7_75t_SL g190 ( 
.A(n_189),
.B(n_185),
.Y(n_190)
);

INVx1_ASAP7_75t_L g191 ( 
.A(n_190),
.Y(n_191)
);

INVx1_ASAP7_75t_L g192 ( 
.A(n_191),
.Y(n_192)
);

XNOR2xp5_ASAP7_75t_L g193 ( 
.A(n_192),
.B(n_188),
.Y(n_193)
);

AOI21xp5_ASAP7_75t_L g194 ( 
.A1(n_193),
.A2(n_179),
.B(n_181),
.Y(n_194)
);


endmodule