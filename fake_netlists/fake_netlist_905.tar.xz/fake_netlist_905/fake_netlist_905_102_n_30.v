module fake_netlist_905_102_n_30 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_30);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_30;

wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_25;
wire n_22;
wire n_26;
wire n_29;

INVx1_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_15),
.B(n_4),
.Y(n_17)
);

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_1),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_7),
.Y(n_21)
);

INVx4_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

AOI222xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_18),
.B1(n_20),
.B2(n_19),
.C1(n_17),
.C2(n_13),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_15),
.Y(n_26)
);

OAI211xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_17),
.B(n_3),
.C(n_2),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

NOR4xp25_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_9),
.C(n_6),
.D(n_5),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_30)
);


endmodule