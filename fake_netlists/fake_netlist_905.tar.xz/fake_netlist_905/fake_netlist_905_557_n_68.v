module fake_netlist_905_557_n_68 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_68);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_68;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_63;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_66;
wire n_65;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_67;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_42;
wire n_32;
wire n_25;
wire n_22;
wire n_41;
wire n_35;
wire n_57;
wire n_43;
wire n_62;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;
wire n_56;

INVx3_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_10),
.B(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_3),
.B(n_14),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_13),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_1),
.Y(n_33)
);

BUFx12f_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_22),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_25),
.B(n_16),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_28),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_28),
.Y(n_41)
);

NAND3xp33_ASAP7_75t_L g42 ( 
.A(n_36),
.B(n_26),
.C(n_23),
.Y(n_42)
);

AO31x2_ASAP7_75t_L g43 ( 
.A1(n_37),
.A2(n_33),
.A3(n_30),
.B(n_24),
.Y(n_43)
);

OAI211xp5_ASAP7_75t_L g44 ( 
.A1(n_37),
.A2(n_29),
.B(n_27),
.C(n_31),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OAI31xp33_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_40),
.A3(n_39),
.B(n_38),
.Y(n_46)
);

OAI221xp5_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_41),
.B1(n_38),
.B2(n_35),
.C(n_29),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_35),
.B1(n_31),
.B2(n_34),
.C(n_17),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_43),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_45),
.B(n_34),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_48),
.Y(n_54)
);

INVxp67_ASAP7_75t_SL g55 ( 
.A(n_52),
.Y(n_55)
);

NOR2xp33_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_17),
.Y(n_56)
);

OAI21xp5_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_35),
.B(n_18),
.Y(n_57)
);

NOR2x1p5_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_35),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_35),
.B1(n_20),
.B2(n_19),
.Y(n_59)
);

NOR2xp33_ASAP7_75t_L g60 ( 
.A(n_53),
.B(n_19),
.Y(n_60)
);

AND3x4_ASAP7_75t_L g61 ( 
.A(n_60),
.B(n_21),
.C(n_20),
.Y(n_61)
);

AOI21xp5_ASAP7_75t_L g62 ( 
.A1(n_57),
.A2(n_55),
.B(n_35),
.Y(n_62)
);

OAI322xp33_ASAP7_75t_L g63 ( 
.A1(n_59),
.A2(n_4),
.A3(n_5),
.B1(n_6),
.B2(n_7),
.C1(n_21),
.C2(n_58),
.Y(n_63)
);

BUFx2_ASAP7_75t_L g64 ( 
.A(n_58),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_64),
.Y(n_65)
);

CKINVDCx20_ASAP7_75t_R g66 ( 
.A(n_61),
.Y(n_66)
);

AND2x4_ASAP7_75t_L g67 ( 
.A(n_62),
.B(n_63),
.Y(n_67)
);

NAND3xp33_ASAP7_75t_L g68 ( 
.A(n_65),
.B(n_67),
.C(n_66),
.Y(n_68)
);


endmodule