module fake_netlist_768_1647_n_35 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_35);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_35;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_29;
wire n_32;

INVx2_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_6),
.Y(n_11)
);

NAND2xp33_ASAP7_75t_SL g12 ( 
.A(n_9),
.B(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_SL g17 ( 
.A1(n_11),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_0),
.Y(n_18)
);

CKINVDCx14_ASAP7_75t_R g19 ( 
.A(n_16),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_15),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_21)
);

O2A1O1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_13),
.B(n_15),
.C(n_10),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_SL g24 ( 
.A(n_17),
.B(n_12),
.C(n_13),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_20),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_19),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_22),
.B1(n_24),
.B2(n_17),
.C(n_18),
.Y(n_28)
);

AOI32xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_10),
.A3(n_24),
.B1(n_22),
.B2(n_5),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_SL g30 ( 
.A1(n_28),
.A2(n_27),
.B1(n_10),
.B2(n_26),
.C(n_5),
.Y(n_30)
);

OAI221xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_7),
.B1(n_5),
.B2(n_2),
.C(n_3),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_33),
.B1(n_7),
.B2(n_8),
.Y(n_34)
);

AOI222xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_8),
.B1(n_9),
.B2(n_32),
.C1(n_33),
.C2(n_17),
.Y(n_35)
);


endmodule