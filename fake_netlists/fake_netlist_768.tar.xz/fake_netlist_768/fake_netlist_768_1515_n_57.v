module fake_netlist_768_1515_n_57 (n_12, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_57);

input n_12;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_57;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_42;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_56;
wire n_15;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx3_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_6),
.B(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_1),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_5),
.B(n_11),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_9),
.B(n_0),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_8),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_1),
.Y(n_25)
);

BUFx12f_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_15),
.B(n_2),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_15),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_R g33 ( 
.A(n_29),
.B(n_25),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_15),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_27),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_20),
.B1(n_19),
.B2(n_24),
.Y(n_36)
);

NAND4xp25_ASAP7_75t_L g37 ( 
.A(n_30),
.B(n_16),
.C(n_17),
.D(n_19),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_32),
.B1(n_26),
.B2(n_24),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_33),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_35),
.Y(n_43)
);

INVx1_ASAP7_75t_SL g44 ( 
.A(n_41),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_40),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_36),
.B1(n_39),
.B2(n_32),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

NOR2x1_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_37),
.Y(n_48)
);

AO221x1_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_47),
.B1(n_24),
.B2(n_28),
.C(n_17),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

OAI221xp5_ASAP7_75t_SL g51 ( 
.A1(n_45),
.A2(n_20),
.B1(n_24),
.B2(n_4),
.C(n_5),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_28),
.Y(n_52)
);

OAI211xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_24),
.B(n_28),
.C(n_21),
.Y(n_53)
);

OR2x2_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_28),
.Y(n_54)
);

OAI21xp5_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_7),
.B(n_3),
.Y(n_55)
);

AND2x2_ASAP7_75t_SL g56 ( 
.A(n_55),
.B(n_49),
.Y(n_56)
);

AOI322xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_12),
.A3(n_14),
.B1(n_53),
.B2(n_54),
.C1(n_22),
.C2(n_48),
.Y(n_57)
);


endmodule