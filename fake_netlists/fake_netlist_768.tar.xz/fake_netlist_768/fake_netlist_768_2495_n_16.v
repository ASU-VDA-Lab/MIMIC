module fake_netlist_768_2495_n_16 (n_0, n_2, n_1, n_16);

input n_0;
input n_2;
input n_1;

output n_16;

wire n_12;
wire n_15;
wire n_14;
wire n_3;
wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

NOR2xp33_ASAP7_75t_R g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_0),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_5),
.Y(n_10)
);

OAI21xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B(n_5),
.Y(n_11)
);

OAI22xp33_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_5),
.B1(n_7),
.B2(n_0),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_10),
.B(n_1),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_1),
.B(n_2),
.C(n_6),
.Y(n_14)
);

XNOR2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);


endmodule