module fake_netlist_768_2721_n_13 (n_1, n_2, n_3, n_4, n_0, n_13);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_13;

wire n_12;
wire n_9;
wire n_11;
wire n_10;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_0),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_2),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B(n_8),
.Y(n_11)
);

NOR2x1p5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.Y(n_12)
);

NAND2xp33_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_7),
.Y(n_13)
);


endmodule