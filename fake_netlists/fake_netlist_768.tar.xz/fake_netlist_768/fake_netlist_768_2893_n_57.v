module fake_netlist_768_2893_n_57 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_57);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_57;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_42;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_1),
.B(n_16),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_20),
.A2(n_9),
.B1(n_15),
.B2(n_7),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_24),
.B(n_13),
.Y(n_31)
);

NAND2x1p5_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_14),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_26),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_22),
.A2(n_18),
.B1(n_16),
.B2(n_15),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_25),
.Y(n_35)
);

OAI21xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_28),
.B(n_23),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_31),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_37),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_36),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_SL g43 ( 
.A(n_42),
.B(n_30),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx2_ASAP7_75t_SL g45 ( 
.A(n_41),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_38),
.B1(n_42),
.B2(n_34),
.C(n_32),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_34),
.B(n_21),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

NAND5xp2_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_21),
.C(n_43),
.D(n_19),
.E(n_29),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_48),
.A2(n_27),
.B1(n_19),
.B2(n_38),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_2),
.Y(n_51)
);

NOR2xp67_ASAP7_75t_SL g52 ( 
.A(n_48),
.B(n_4),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

OR2x2_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_6),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_8),
.Y(n_55)
);

OAI22xp5_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_52),
.B1(n_11),
.B2(n_10),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_53),
.B1(n_54),
.B2(n_55),
.Y(n_57)
);


endmodule