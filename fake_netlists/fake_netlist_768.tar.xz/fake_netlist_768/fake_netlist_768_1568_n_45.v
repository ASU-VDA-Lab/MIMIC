module fake_netlist_768_1568_n_45 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_45);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_45;

wire n_23;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

INVx2_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_13),
.B(n_19),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_3),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_18),
.Y(n_29)
);

BUFx12f_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_22),
.Y(n_32)
);

AOI221xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_27),
.B1(n_22),
.B2(n_26),
.C(n_28),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_29),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_30),
.B1(n_29),
.B2(n_24),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_29),
.B1(n_25),
.B2(n_21),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

NOR4xp25_ASAP7_75t_SL g38 ( 
.A(n_36),
.B(n_19),
.C(n_1),
.D(n_0),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_4),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_7),
.C(n_6),
.Y(n_40)
);

OAI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_10),
.B1(n_9),
.B2(n_12),
.C(n_15),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_40),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_41),
.Y(n_43)
);

XNOR2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_16),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_43),
.B1(n_20),
.B2(n_17),
.Y(n_45)
);


endmodule