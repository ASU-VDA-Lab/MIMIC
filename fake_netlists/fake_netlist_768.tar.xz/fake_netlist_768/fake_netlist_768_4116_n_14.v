module fake_netlist_768_4116_n_14 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_14);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_14;

wire n_12;
wire n_8;
wire n_9;
wire n_10;
wire n_13;
wire n_7;
wire n_11;

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_0),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_6),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AND3x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.C(n_6),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_5),
.Y(n_14)
);


endmodule