module fake_netlist_768_2245_n_45 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_45);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_45;

wire n_20;
wire n_23;
wire n_14;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_13;
wire n_39;
wire n_11;
wire n_28;
wire n_42;
wire n_37;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_15;
wire n_19;
wire n_12;
wire n_41;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

AOI21x1_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_9),
.B(n_10),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_6),
.A2(n_8),
.B(n_5),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_11),
.A2(n_4),
.B(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_4),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_7),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_14),
.Y(n_23)
);

INVx4_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

O2A1O1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_13),
.A2(n_11),
.B(n_16),
.C(n_17),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_23),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_R g30 ( 
.A(n_20),
.B(n_15),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_24),
.B(n_15),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_25),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_26),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_24),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_29),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

NAND5xp2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_32),
.C(n_19),
.D(n_12),
.E(n_31),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_33),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_30),
.B1(n_31),
.B2(n_24),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_39),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_40),
.Y(n_42)
);

AO22x2_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_38),
.B1(n_31),
.B2(n_37),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_27),
.B1(n_43),
.B2(n_41),
.Y(n_45)
);


endmodule