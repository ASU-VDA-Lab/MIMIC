module fake_netlist_768_446_n_52 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_52);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_52;

wire n_46;
wire n_44;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_8),
.B(n_9),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_15),
.B(n_13),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_2),
.B(n_12),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_10),
.Y(n_29)
);

CKINVDCx16_ASAP7_75t_R g30 ( 
.A(n_0),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_1),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_18),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_22),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_16),
.Y(n_35)
);

OR2x6_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_16),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_27),
.B(n_18),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_31),
.B1(n_33),
.B2(n_29),
.Y(n_38)
);

OA21x2_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_25),
.B(n_28),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

OAI31xp33_ASAP7_75t_SL g41 ( 
.A1(n_38),
.A2(n_35),
.A3(n_34),
.B(n_36),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_29),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_33),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_43),
.Y(n_46)
);

O2A1O1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_26),
.B(n_24),
.C(n_3),
.Y(n_47)
);

NAND3xp33_ASAP7_75t_SL g48 ( 
.A(n_46),
.B(n_24),
.C(n_4),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_11),
.B1(n_7),
.B2(n_5),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

OR3x2_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_17),
.C(n_14),
.Y(n_51)
);

AOI222xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_19),
.B1(n_20),
.B2(n_21),
.C1(n_23),
.C2(n_51),
.Y(n_52)
);


endmodule