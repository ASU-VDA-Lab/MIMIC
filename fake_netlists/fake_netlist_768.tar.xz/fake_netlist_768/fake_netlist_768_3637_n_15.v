module fake_netlist_768_3637_n_15 (n_1, n_2, n_3, n_4, n_5, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B1(n_5),
.B2(n_4),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

AOI22x1_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_8)
);

OR2x6_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx5_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_6),
.B1(n_9),
.B2(n_8),
.C(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.C(n_4),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.C(n_5),
.Y(n_15)
);


endmodule