module fake_netlist_768_1501_n_37 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_37);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_37;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_5),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_0),
.B(n_9),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_16),
.B(n_2),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_6),
.B1(n_3),
.B2(n_7),
.C(n_9),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_12),
.B(n_10),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_10),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_11),
.Y(n_25)
);

BUFx2_ASAP7_75t_SL g26 ( 
.A(n_22),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_23),
.Y(n_30)
);

AOI322xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_15),
.A3(n_21),
.B1(n_27),
.B2(n_18),
.C1(n_19),
.C2(n_13),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

NAND4xp25_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_30),
.C(n_14),
.D(n_25),
.Y(n_34)
);

NAND2x1p5_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_29),
.Y(n_35)
);

XNOR2x1_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_20),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_33),
.B1(n_32),
.B2(n_24),
.Y(n_37)
);


endmodule