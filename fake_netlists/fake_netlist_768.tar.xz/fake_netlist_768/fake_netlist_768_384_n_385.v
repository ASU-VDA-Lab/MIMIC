module fake_netlist_768_384_n_385 (n_20, n_23, n_46, n_14, n_44, n_22, n_36, n_16, n_18, n_34, n_13, n_39, n_11, n_45, n_48, n_49, n_1, n_28, n_27, n_37, n_42, n_24, n_10, n_5, n_26, n_6, n_33, n_40, n_31, n_30, n_38, n_2, n_3, n_9, n_35, n_4, n_25, n_7, n_17, n_21, n_43, n_12, n_15, n_19, n_41, n_29, n_47, n_32, n_0, n_8, n_385);

input n_20;
input n_23;
input n_46;
input n_14;
input n_44;
input n_22;
input n_36;
input n_16;
input n_18;
input n_34;
input n_13;
input n_39;
input n_11;
input n_45;
input n_48;
input n_49;
input n_1;
input n_28;
input n_27;
input n_37;
input n_42;
input n_24;
input n_10;
input n_5;
input n_26;
input n_6;
input n_33;
input n_40;
input n_31;
input n_30;
input n_38;
input n_2;
input n_3;
input n_9;
input n_35;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_43;
input n_12;
input n_15;
input n_19;
input n_41;
input n_29;
input n_47;
input n_32;
input n_0;
input n_8;

output n_385;

wire n_311;
wire n_200;
wire n_217;
wire n_104;
wire n_275;
wire n_73;
wire n_112;
wire n_127;
wire n_325;
wire n_354;
wire n_182;
wire n_183;
wire n_189;
wire n_155;
wire n_266;
wire n_269;
wire n_367;
wire n_337;
wire n_234;
wire n_288;
wire n_131;
wire n_289;
wire n_126;
wire n_210;
wire n_140;
wire n_235;
wire n_184;
wire n_260;
wire n_377;
wire n_196;
wire n_72;
wire n_312;
wire n_95;
wire n_352;
wire n_282;
wire n_69;
wire n_248;
wire n_295;
wire n_167;
wire n_204;
wire n_384;
wire n_374;
wire n_324;
wire n_348;
wire n_222;
wire n_172;
wire n_207;
wire n_320;
wire n_315;
wire n_253;
wire n_227;
wire n_363;
wire n_87;
wire n_187;
wire n_117;
wire n_305;
wire n_79;
wire n_256;
wire n_249;
wire n_101;
wire n_91;
wire n_358;
wire n_115;
wire n_243;
wire n_349;
wire n_370;
wire n_66;
wire n_333;
wire n_159;
wire n_205;
wire n_181;
wire n_293;
wire n_170;
wire n_134;
wire n_247;
wire n_114;
wire n_379;
wire n_161;
wire n_135;
wire n_162;
wire n_373;
wire n_212;
wire n_327;
wire n_164;
wire n_359;
wire n_142;
wire n_258;
wire n_93;
wire n_146;
wire n_301;
wire n_250;
wire n_309;
wire n_62;
wire n_252;
wire n_231;
wire n_350;
wire n_106;
wire n_223;
wire n_291;
wire n_105;
wire n_302;
wire n_60;
wire n_304;
wire n_264;
wire n_372;
wire n_381;
wire n_245;
wire n_86;
wire n_55;
wire n_201;
wire n_313;
wire n_236;
wire n_276;
wire n_322;
wire n_76;
wire n_193;
wire n_51;
wire n_102;
wire n_98;
wire n_251;
wire n_118;
wire n_75;
wire n_270;
wire n_197;
wire n_85;
wire n_198;
wire n_174;
wire n_63;
wire n_343;
wire n_166;
wire n_125;
wire n_92;
wire n_246;
wire n_332;
wire n_241;
wire n_136;
wire n_362;
wire n_383;
wire n_238;
wire n_378;
wire n_279;
wire n_148;
wire n_226;
wire n_263;
wire n_96;
wire n_364;
wire n_353;
wire n_165;
wire n_188;
wire n_369;
wire n_103;
wire n_163;
wire n_344;
wire n_220;
wire n_199;
wire n_121;
wire n_116;
wire n_268;
wire n_328;
wire n_211;
wire n_107;
wire n_261;
wire n_321;
wire n_360;
wire n_179;
wire n_221;
wire n_154;
wire n_177;
wire n_206;
wire n_88;
wire n_232;
wire n_213;
wire n_318;
wire n_71;
wire n_215;
wire n_186;
wire n_156;
wire n_175;
wire n_81;
wire n_94;
wire n_380;
wire n_278;
wire n_287;
wire n_224;
wire n_218;
wire n_119;
wire n_271;
wire n_191;
wire n_326;
wire n_255;
wire n_347;
wire n_299;
wire n_382;
wire n_82;
wire n_145;
wire n_78;
wire n_371;
wire n_308;
wire n_180;
wire n_149;
wire n_70;
wire n_281;
wire n_283;
wire n_144;
wire n_331;
wire n_274;
wire n_319;
wire n_365;
wire n_61;
wire n_329;
wire n_323;
wire n_90;
wire n_169;
wire n_50;
wire n_298;
wire n_203;
wire n_216;
wire n_297;
wire n_361;
wire n_58;
wire n_123;
wire n_366;
wire n_262;
wire n_290;
wire n_99;
wire n_292;
wire n_254;
wire n_376;
wire n_267;
wire n_59;
wire n_89;
wire n_316;
wire n_158;
wire n_124;
wire n_284;
wire n_306;
wire n_208;
wire n_342;
wire n_314;
wire n_242;
wire n_178;
wire n_171;
wire n_129;
wire n_54;
wire n_83;
wire n_294;
wire n_219;
wire n_77;
wire n_80;
wire n_153;
wire n_68;
wire n_192;
wire n_176;
wire n_173;
wire n_139;
wire n_244;
wire n_285;
wire n_273;
wire n_53;
wire n_57;
wire n_336;
wire n_157;
wire n_84;
wire n_195;
wire n_334;
wire n_346;
wire n_286;
wire n_151;
wire n_257;
wire n_64;
wire n_300;
wire n_194;
wire n_108;
wire n_330;
wire n_340;
wire n_259;
wire n_97;
wire n_230;
wire n_132;
wire n_160;
wire n_310;
wire n_147;
wire n_237;
wire n_100;
wire n_56;
wire n_355;
wire n_356;
wire n_272;
wire n_335;
wire n_233;
wire n_111;
wire n_52;
wire n_307;
wire n_141;
wire n_214;
wire n_265;
wire n_110;
wire n_338;
wire n_190;
wire n_137;
wire n_345;
wire n_65;
wire n_375;
wire n_150;
wire n_128;
wire n_133;
wire n_280;
wire n_240;
wire n_229;
wire n_138;
wire n_130;
wire n_225;
wire n_122;
wire n_239;
wire n_209;
wire n_74;
wire n_317;
wire n_303;
wire n_357;
wire n_296;
wire n_109;
wire n_120;
wire n_341;
wire n_351;
wire n_168;
wire n_339;
wire n_228;
wire n_277;
wire n_143;
wire n_67;
wire n_368;
wire n_152;
wire n_185;
wire n_202;
wire n_113;

INVxp67_ASAP7_75t_SL g50 ( 
.A(n_22),
.Y(n_50)
);

INVxp33_ASAP7_75t_L g51 ( 
.A(n_5),
.Y(n_51)
);

CKINVDCx20_ASAP7_75t_R g52 ( 
.A(n_30),
.Y(n_52)
);

INVxp33_ASAP7_75t_SL g53 ( 
.A(n_29),
.Y(n_53)
);

INVxp67_ASAP7_75t_SL g54 ( 
.A(n_41),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_34),
.Y(n_55)
);

INVxp67_ASAP7_75t_SL g56 ( 
.A(n_16),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_15),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_45),
.Y(n_58)
);

INVxp67_ASAP7_75t_SL g59 ( 
.A(n_38),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_19),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_24),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_28),
.Y(n_62)
);

INVx2_ASAP7_75t_L g63 ( 
.A(n_27),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_7),
.Y(n_64)
);

INVxp67_ASAP7_75t_SL g65 ( 
.A(n_46),
.Y(n_65)
);

CKINVDCx14_ASAP7_75t_R g66 ( 
.A(n_9),
.Y(n_66)
);

CKINVDCx5p33_ASAP7_75t_R g67 ( 
.A(n_12),
.Y(n_67)
);

INVxp67_ASAP7_75t_SL g68 ( 
.A(n_33),
.Y(n_68)
);

NAND2xp5_ASAP7_75t_L g69 ( 
.A(n_51),
.B(n_0),
.Y(n_69)
);

AND2x2_ASAP7_75t_SL g70 ( 
.A(n_55),
.B(n_20),
.Y(n_70)
);

CKINVDCx20_ASAP7_75t_R g71 ( 
.A(n_66),
.Y(n_71)
);

CKINVDCx5p33_ASAP7_75t_R g72 ( 
.A(n_66),
.Y(n_72)
);

OR2x2_ASAP7_75t_L g73 ( 
.A(n_57),
.B(n_0),
.Y(n_73)
);

INVx2_ASAP7_75t_L g74 ( 
.A(n_62),
.Y(n_74)
);

BUFx6f_ASAP7_75t_L g75 ( 
.A(n_62),
.Y(n_75)
);

INVx2_ASAP7_75t_L g76 ( 
.A(n_62),
.Y(n_76)
);

CKINVDCx5p33_ASAP7_75t_R g77 ( 
.A(n_52),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_55),
.Y(n_78)
);

INVx2_ASAP7_75t_L g79 ( 
.A(n_62),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_55),
.Y(n_80)
);

NAND3x1_ASAP7_75t_L g81 ( 
.A(n_69),
.B(n_60),
.C(n_58),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_74),
.Y(n_82)
);

HB1xp67_ASAP7_75t_L g83 ( 
.A(n_69),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_74),
.Y(n_84)
);

NAND2xp5_ASAP7_75t_L g85 ( 
.A(n_78),
.B(n_58),
.Y(n_85)
);

INVx4_ASAP7_75t_L g86 ( 
.A(n_70),
.Y(n_86)
);

AND2x4_ASAP7_75t_L g87 ( 
.A(n_78),
.B(n_57),
.Y(n_87)
);

BUFx3_ASAP7_75t_L g88 ( 
.A(n_74),
.Y(n_88)
);

AND2x4_ASAP7_75t_L g89 ( 
.A(n_80),
.B(n_57),
.Y(n_89)
);

AND2x2_ASAP7_75t_L g90 ( 
.A(n_80),
.B(n_51),
.Y(n_90)
);

INVx2_ASAP7_75t_L g91 ( 
.A(n_75),
.Y(n_91)
);

OR2x2_ASAP7_75t_L g92 ( 
.A(n_73),
.B(n_56),
.Y(n_92)
);

BUFx6f_ASAP7_75t_L g93 ( 
.A(n_75),
.Y(n_93)
);

AOI22xp5_ASAP7_75t_L g94 ( 
.A1(n_70),
.A2(n_52),
.B1(n_67),
.B2(n_56),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_75),
.Y(n_95)
);

INVx2_ASAP7_75t_L g96 ( 
.A(n_75),
.Y(n_96)
);

BUFx10_ASAP7_75t_L g97 ( 
.A(n_70),
.Y(n_97)
);

BUFx6f_ASAP7_75t_L g98 ( 
.A(n_75),
.Y(n_98)
);

INVx4_ASAP7_75t_L g99 ( 
.A(n_75),
.Y(n_99)
);

AND2x2_ASAP7_75t_L g100 ( 
.A(n_73),
.B(n_64),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_76),
.Y(n_101)
);

BUFx6f_ASAP7_75t_L g102 ( 
.A(n_76),
.Y(n_102)
);

AND2x2_ASAP7_75t_L g103 ( 
.A(n_72),
.B(n_64),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_82),
.Y(n_104)
);

AOI22xp5_ASAP7_75t_L g105 ( 
.A1(n_86),
.A2(n_53),
.B1(n_64),
.B2(n_67),
.Y(n_105)
);

INVx2_ASAP7_75t_L g106 ( 
.A(n_102),
.Y(n_106)
);

NAND2xp5_ASAP7_75t_L g107 ( 
.A(n_83),
.B(n_53),
.Y(n_107)
);

NOR3xp33_ASAP7_75t_SL g108 ( 
.A(n_85),
.B(n_77),
.C(n_50),
.Y(n_108)
);

NOR2xp33_ASAP7_75t_L g109 ( 
.A(n_83),
.B(n_71),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_82),
.Y(n_110)
);

INVx2_ASAP7_75t_L g111 ( 
.A(n_102),
.Y(n_111)
);

OR2x6_ASAP7_75t_L g112 ( 
.A(n_86),
.B(n_58),
.Y(n_112)
);

OR2x2_ASAP7_75t_L g113 ( 
.A(n_92),
.B(n_76),
.Y(n_113)
);

NAND2xp5_ASAP7_75t_L g114 ( 
.A(n_90),
.B(n_50),
.Y(n_114)
);

INVx5_ASAP7_75t_L g115 ( 
.A(n_102),
.Y(n_115)
);

NOR2xp33_ASAP7_75t_L g116 ( 
.A(n_90),
.B(n_103),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_102),
.Y(n_117)
);

AND2x6_ASAP7_75t_SL g118 ( 
.A(n_100),
.B(n_60),
.Y(n_118)
);

INVx5_ASAP7_75t_L g119 ( 
.A(n_102),
.Y(n_119)
);

INVx1_ASAP7_75t_L g120 ( 
.A(n_84),
.Y(n_120)
);

BUFx6f_ASAP7_75t_L g121 ( 
.A(n_102),
.Y(n_121)
);

NAND2xp5_ASAP7_75t_L g122 ( 
.A(n_90),
.B(n_54),
.Y(n_122)
);

INVx4_ASAP7_75t_L g123 ( 
.A(n_87),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_100),
.B(n_54),
.Y(n_124)
);

CKINVDCx5p33_ASAP7_75t_R g125 ( 
.A(n_94),
.Y(n_125)
);

BUFx2_ASAP7_75t_L g126 ( 
.A(n_92),
.Y(n_126)
);

INVx2_ASAP7_75t_L g127 ( 
.A(n_102),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_84),
.Y(n_128)
);

A2O1A1Ixp33_ASAP7_75t_L g129 ( 
.A1(n_116),
.A2(n_89),
.B(n_87),
.C(n_88),
.Y(n_129)
);

INVx2_ASAP7_75t_L g130 ( 
.A(n_104),
.Y(n_130)
);

CKINVDCx5p33_ASAP7_75t_R g131 ( 
.A(n_108),
.Y(n_131)
);

INVx3_ASAP7_75t_L g132 ( 
.A(n_123),
.Y(n_132)
);

CKINVDCx5p33_ASAP7_75t_R g133 ( 
.A(n_118),
.Y(n_133)
);

BUFx6f_ASAP7_75t_L g134 ( 
.A(n_123),
.Y(n_134)
);

NAND2xp5_ASAP7_75t_SL g135 ( 
.A(n_123),
.B(n_86),
.Y(n_135)
);

NAND2xp5_ASAP7_75t_L g136 ( 
.A(n_126),
.B(n_123),
.Y(n_136)
);

BUFx2_ASAP7_75t_L g137 ( 
.A(n_112),
.Y(n_137)
);

NOR2x1_ASAP7_75t_L g138 ( 
.A(n_112),
.B(n_86),
.Y(n_138)
);

OR2x2_ASAP7_75t_L g139 ( 
.A(n_126),
.B(n_92),
.Y(n_139)
);

AOI21xp5_ASAP7_75t_L g140 ( 
.A1(n_104),
.A2(n_85),
.B(n_89),
.Y(n_140)
);

AND2x2_ASAP7_75t_L g141 ( 
.A(n_113),
.B(n_100),
.Y(n_141)
);

BUFx2_ASAP7_75t_L g142 ( 
.A(n_112),
.Y(n_142)
);

INVx2_ASAP7_75t_L g143 ( 
.A(n_110),
.Y(n_143)
);

OAI21xp5_ASAP7_75t_SL g144 ( 
.A1(n_105),
.A2(n_94),
.B(n_87),
.Y(n_144)
);

BUFx2_ASAP7_75t_L g145 ( 
.A(n_112),
.Y(n_145)
);

INVx2_ASAP7_75t_L g146 ( 
.A(n_110),
.Y(n_146)
);

BUFx6f_ASAP7_75t_L g147 ( 
.A(n_112),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_120),
.Y(n_148)
);

INVx2_ASAP7_75t_SL g149 ( 
.A(n_147),
.Y(n_149)
);

OAI221xp5_ASAP7_75t_L g150 ( 
.A1(n_144),
.A2(n_105),
.B1(n_125),
.B2(n_122),
.C(n_114),
.Y(n_150)
);

INVx4_ASAP7_75t_L g151 ( 
.A(n_147),
.Y(n_151)
);

AND2x2_ASAP7_75t_L g152 ( 
.A(n_141),
.B(n_113),
.Y(n_152)
);

OR2x2_ASAP7_75t_L g153 ( 
.A(n_139),
.B(n_107),
.Y(n_153)
);

INVx3_ASAP7_75t_L g154 ( 
.A(n_147),
.Y(n_154)
);

AND2x4_ASAP7_75t_L g155 ( 
.A(n_147),
.B(n_120),
.Y(n_155)
);

NAND2xp33_ASAP7_75t_R g156 ( 
.A(n_137),
.B(n_97),
.Y(n_156)
);

AND2x2_ASAP7_75t_L g157 ( 
.A(n_141),
.B(n_128),
.Y(n_157)
);

CKINVDCx8_ASAP7_75t_R g158 ( 
.A(n_147),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_130),
.Y(n_159)
);

HB1xp67_ASAP7_75t_L g160 ( 
.A(n_147),
.Y(n_160)
);

NAND2xp5_ASAP7_75t_L g161 ( 
.A(n_130),
.B(n_128),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_159),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_159),
.Y(n_163)
);

OAI22xp5_ASAP7_75t_L g164 ( 
.A1(n_150),
.A2(n_144),
.B1(n_161),
.B2(n_159),
.Y(n_164)
);

INVx1_ASAP7_75t_L g165 ( 
.A(n_161),
.Y(n_165)
);

HB1xp67_ASAP7_75t_L g166 ( 
.A(n_152),
.Y(n_166)
);

INVx1_ASAP7_75t_L g167 ( 
.A(n_157),
.Y(n_167)
);

INVx2_ASAP7_75t_L g168 ( 
.A(n_157),
.Y(n_168)
);

OAI211xp5_ASAP7_75t_L g169 ( 
.A1(n_150),
.A2(n_109),
.B(n_131),
.C(n_133),
.Y(n_169)
);

AOI22xp33_ASAP7_75t_L g170 ( 
.A1(n_152),
.A2(n_97),
.B1(n_142),
.B2(n_137),
.Y(n_170)
);

INVx2_ASAP7_75t_L g171 ( 
.A(n_157),
.Y(n_171)
);

BUFx2_ASAP7_75t_L g172 ( 
.A(n_151),
.Y(n_172)
);

INVx2_ASAP7_75t_L g173 ( 
.A(n_155),
.Y(n_173)
);

INVx2_ASAP7_75t_L g174 ( 
.A(n_155),
.Y(n_174)
);

AOI221xp5_ASAP7_75t_L g175 ( 
.A1(n_153),
.A2(n_103),
.B1(n_152),
.B2(n_124),
.C(n_139),
.Y(n_175)
);

AOI22xp33_ASAP7_75t_L g176 ( 
.A1(n_175),
.A2(n_97),
.B1(n_145),
.B2(n_142),
.Y(n_176)
);

AND2x4_ASAP7_75t_L g177 ( 
.A(n_173),
.B(n_151),
.Y(n_177)
);

OAI33xp33_ASAP7_75t_L g178 ( 
.A1(n_164),
.A2(n_61),
.A3(n_60),
.B1(n_162),
.B2(n_163),
.B3(n_167),
.Y(n_178)
);

OAI21xp33_ASAP7_75t_L g179 ( 
.A1(n_164),
.A2(n_153),
.B(n_155),
.Y(n_179)
);

OAI22xp5_ASAP7_75t_L g180 ( 
.A1(n_165),
.A2(n_145),
.B1(n_158),
.B2(n_130),
.Y(n_180)
);

NOR3xp33_ASAP7_75t_L g181 ( 
.A(n_169),
.B(n_103),
.C(n_153),
.Y(n_181)
);

AOI22xp33_ASAP7_75t_L g182 ( 
.A1(n_166),
.A2(n_97),
.B1(n_138),
.B2(n_155),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_162),
.Y(n_183)
);

INVx2_ASAP7_75t_L g184 ( 
.A(n_163),
.Y(n_184)
);

OAI21xp33_ASAP7_75t_SL g185 ( 
.A1(n_165),
.A2(n_151),
.B(n_138),
.Y(n_185)
);

AND2x2_ASAP7_75t_L g186 ( 
.A(n_168),
.B(n_171),
.Y(n_186)
);

NOR4xp25_ASAP7_75t_SL g187 ( 
.A(n_172),
.B(n_156),
.C(n_65),
.D(n_59),
.Y(n_187)
);

NAND2xp33_ASAP7_75t_R g188 ( 
.A(n_172),
.B(n_154),
.Y(n_188)
);

INVx1_ASAP7_75t_L g189 ( 
.A(n_167),
.Y(n_189)
);

BUFx3_ASAP7_75t_L g190 ( 
.A(n_171),
.Y(n_190)
);

AND2x4_ASAP7_75t_L g191 ( 
.A(n_173),
.B(n_151),
.Y(n_191)
);

BUFx2_ASAP7_75t_L g192 ( 
.A(n_174),
.Y(n_192)
);

NAND2xp5_ASAP7_75t_L g193 ( 
.A(n_174),
.B(n_118),
.Y(n_193)
);

OAI221xp5_ASAP7_75t_L g194 ( 
.A1(n_170),
.A2(n_129),
.B1(n_136),
.B2(n_135),
.C(n_158),
.Y(n_194)
);

AO21x2_ASAP7_75t_L g195 ( 
.A1(n_164),
.A2(n_140),
.B(n_148),
.Y(n_195)
);

INVx1_ASAP7_75t_L g196 ( 
.A(n_162),
.Y(n_196)
);

INVx1_ASAP7_75t_L g197 ( 
.A(n_162),
.Y(n_197)
);

INVx1_ASAP7_75t_L g198 ( 
.A(n_183),
.Y(n_198)
);

OR2x2_ASAP7_75t_L g199 ( 
.A(n_184),
.B(n_151),
.Y(n_199)
);

AOI221xp5_ASAP7_75t_L g200 ( 
.A1(n_181),
.A2(n_68),
.B1(n_65),
.B2(n_59),
.C(n_61),
.Y(n_200)
);

AND2x2_ASAP7_75t_L g201 ( 
.A(n_184),
.B(n_151),
.Y(n_201)
);

INVx1_ASAP7_75t_L g202 ( 
.A(n_183),
.Y(n_202)
);

INVx1_ASAP7_75t_L g203 ( 
.A(n_196),
.Y(n_203)
);

INVx1_ASAP7_75t_L g204 ( 
.A(n_196),
.Y(n_204)
);

INVx1_ASAP7_75t_L g205 ( 
.A(n_197),
.Y(n_205)
);

INVx4_ASAP7_75t_L g206 ( 
.A(n_177),
.Y(n_206)
);

OR2x2_ASAP7_75t_L g207 ( 
.A(n_184),
.B(n_160),
.Y(n_207)
);

AND2x2_ASAP7_75t_L g208 ( 
.A(n_186),
.B(n_155),
.Y(n_208)
);

OAI33xp33_ASAP7_75t_L g209 ( 
.A1(n_189),
.A2(n_61),
.A3(n_63),
.B1(n_79),
.B2(n_101),
.B3(n_148),
.Y(n_209)
);

AND2x4_ASAP7_75t_L g210 ( 
.A(n_177),
.B(n_154),
.Y(n_210)
);

INVx2_ASAP7_75t_SL g211 ( 
.A(n_190),
.Y(n_211)
);

NAND2x1_ASAP7_75t_L g212 ( 
.A(n_180),
.B(n_154),
.Y(n_212)
);

NAND2xp5_ASAP7_75t_L g213 ( 
.A(n_189),
.B(n_81),
.Y(n_213)
);

INVx2_ASAP7_75t_L g214 ( 
.A(n_190),
.Y(n_214)
);

NOR4xp75_ASAP7_75t_L g215 ( 
.A(n_179),
.B(n_81),
.C(n_2),
.D(n_1),
.Y(n_215)
);

INVx4_ASAP7_75t_L g216 ( 
.A(n_191),
.Y(n_216)
);

OAI321xp33_ASAP7_75t_L g217 ( 
.A1(n_179),
.A2(n_63),
.A3(n_68),
.B1(n_149),
.B2(n_79),
.C(n_101),
.Y(n_217)
);

NOR2xp33_ASAP7_75t_L g218 ( 
.A(n_193),
.B(n_136),
.Y(n_218)
);

HB1xp67_ASAP7_75t_L g219 ( 
.A(n_188),
.Y(n_219)
);

OAI33xp33_ASAP7_75t_L g220 ( 
.A1(n_180),
.A2(n_63),
.A3(n_79),
.B1(n_3),
.B2(n_2),
.B3(n_1),
.Y(n_220)
);

AND2x2_ASAP7_75t_L g221 ( 
.A(n_190),
.B(n_155),
.Y(n_221)
);

OR2x2_ASAP7_75t_L g222 ( 
.A(n_192),
.B(n_160),
.Y(n_222)
);

OR2x2_ASAP7_75t_L g223 ( 
.A(n_192),
.B(n_191),
.Y(n_223)
);

OR2x2_ASAP7_75t_L g224 ( 
.A(n_177),
.B(n_154),
.Y(n_224)
);

NAND2xp5_ASAP7_75t_L g225 ( 
.A(n_177),
.B(n_143),
.Y(n_225)
);

AOI31xp33_ASAP7_75t_L g226 ( 
.A1(n_185),
.A2(n_156),
.A3(n_63),
.B(n_149),
.Y(n_226)
);

INVx1_ASAP7_75t_L g227 ( 
.A(n_191),
.Y(n_227)
);

AOI22xp33_ASAP7_75t_L g228 ( 
.A1(n_178),
.A2(n_97),
.B1(n_146),
.B2(n_143),
.Y(n_228)
);

AND2x2_ASAP7_75t_L g229 ( 
.A(n_195),
.B(n_191),
.Y(n_229)
);

INVx1_ASAP7_75t_L g230 ( 
.A(n_185),
.Y(n_230)
);

OAI31xp33_ASAP7_75t_L g231 ( 
.A1(n_194),
.A2(n_176),
.A3(n_89),
.B(n_87),
.Y(n_231)
);

AND2x2_ASAP7_75t_L g232 ( 
.A(n_195),
.B(n_154),
.Y(n_232)
);

AOI33xp33_ASAP7_75t_L g233 ( 
.A1(n_187),
.A2(n_89),
.A3(n_87),
.B1(n_182),
.B2(n_4),
.B3(n_3),
.Y(n_233)
);

INVx1_ASAP7_75t_L g234 ( 
.A(n_195),
.Y(n_234)
);

INVx2_ASAP7_75t_L g235 ( 
.A(n_198),
.Y(n_235)
);

OAI22xp33_ASAP7_75t_L g236 ( 
.A1(n_226),
.A2(n_212),
.B1(n_219),
.B2(n_216),
.Y(n_236)
);

NAND2xp5_ASAP7_75t_L g237 ( 
.A(n_202),
.B(n_195),
.Y(n_237)
);

INVx1_ASAP7_75t_L g238 ( 
.A(n_203),
.Y(n_238)
);

INVx1_ASAP7_75t_SL g239 ( 
.A(n_199),
.Y(n_239)
);

BUFx12f_ASAP7_75t_L g240 ( 
.A(n_206),
.Y(n_240)
);

AOI33xp33_ASAP7_75t_L g241 ( 
.A1(n_200),
.A2(n_187),
.A3(n_89),
.B1(n_7),
.B2(n_6),
.B3(n_5),
.Y(n_241)
);

OAI31xp33_ASAP7_75t_L g242 ( 
.A1(n_231),
.A2(n_218),
.A3(n_230),
.B(n_232),
.Y(n_242)
);

NAND2xp5_ASAP7_75t_L g243 ( 
.A(n_204),
.B(n_143),
.Y(n_243)
);

INVx1_ASAP7_75t_L g244 ( 
.A(n_205),
.Y(n_244)
);

OR2x2_ASAP7_75t_L g245 ( 
.A(n_223),
.B(n_6),
.Y(n_245)
);

AND2x2_ASAP7_75t_L g246 ( 
.A(n_229),
.B(n_8),
.Y(n_246)
);

OR2x2_ASAP7_75t_L g247 ( 
.A(n_199),
.B(n_206),
.Y(n_247)
);

NOR2xp33_ASAP7_75t_L g248 ( 
.A(n_206),
.B(n_8),
.Y(n_248)
);

NOR3xp33_ASAP7_75t_L g249 ( 
.A(n_220),
.B(n_99),
.C(n_91),
.Y(n_249)
);

NOR2xp33_ASAP7_75t_R g250 ( 
.A(n_211),
.B(n_158),
.Y(n_250)
);

NAND2xp5_ASAP7_75t_L g251 ( 
.A(n_208),
.B(n_146),
.Y(n_251)
);

AND2x4_ASAP7_75t_L g252 ( 
.A(n_229),
.B(n_149),
.Y(n_252)
);

NAND2xp5_ASAP7_75t_L g253 ( 
.A(n_201),
.B(n_10),
.Y(n_253)
);

INVx2_ASAP7_75t_L g254 ( 
.A(n_201),
.Y(n_254)
);

INVx1_ASAP7_75t_L g255 ( 
.A(n_207),
.Y(n_255)
);

INVx1_ASAP7_75t_L g256 ( 
.A(n_207),
.Y(n_256)
);

INVx1_ASAP7_75t_SL g257 ( 
.A(n_225),
.Y(n_257)
);

INVxp33_ASAP7_75t_L g258 ( 
.A(n_216),
.Y(n_258)
);

INVx1_ASAP7_75t_L g259 ( 
.A(n_222),
.Y(n_259)
);

OR2x2_ASAP7_75t_L g260 ( 
.A(n_216),
.B(n_10),
.Y(n_260)
);

INVx2_ASAP7_75t_L g261 ( 
.A(n_234),
.Y(n_261)
);

INVx2_ASAP7_75t_L g262 ( 
.A(n_214),
.Y(n_262)
);

INVx1_ASAP7_75t_L g263 ( 
.A(n_227),
.Y(n_263)
);

INVx1_ASAP7_75t_L g264 ( 
.A(n_221),
.Y(n_264)
);

INVx1_ASAP7_75t_SL g265 ( 
.A(n_211),
.Y(n_265)
);

NAND2xp5_ASAP7_75t_L g266 ( 
.A(n_221),
.B(n_11),
.Y(n_266)
);

AND2x2_ASAP7_75t_L g267 ( 
.A(n_214),
.B(n_11),
.Y(n_267)
);

NAND2xp5_ASAP7_75t_L g268 ( 
.A(n_213),
.B(n_13),
.Y(n_268)
);

AND2x2_ASAP7_75t_L g269 ( 
.A(n_210),
.B(n_13),
.Y(n_269)
);

INVx2_ASAP7_75t_L g270 ( 
.A(n_210),
.Y(n_270)
);

NOR2xp33_ASAP7_75t_L g271 ( 
.A(n_224),
.B(n_14),
.Y(n_271)
);

AOI22xp33_ASAP7_75t_L g272 ( 
.A1(n_209),
.A2(n_134),
.B1(n_132),
.B2(n_88),
.Y(n_272)
);

NAND2xp5_ASAP7_75t_L g273 ( 
.A(n_210),
.B(n_14),
.Y(n_273)
);

INVx2_ASAP7_75t_L g274 ( 
.A(n_215),
.Y(n_274)
);

OR2x2_ASAP7_75t_L g275 ( 
.A(n_228),
.B(n_15),
.Y(n_275)
);

AND2x4_ASAP7_75t_L g276 ( 
.A(n_228),
.B(n_21),
.Y(n_276)
);

AOI21xp33_ASAP7_75t_L g277 ( 
.A1(n_217),
.A2(n_233),
.B(n_88),
.Y(n_277)
);

OAI32xp33_ASAP7_75t_L g278 ( 
.A1(n_258),
.A2(n_158),
.A3(n_18),
.B1(n_17),
.B2(n_99),
.Y(n_278)
);

AND2x2_ASAP7_75t_L g279 ( 
.A(n_264),
.B(n_17),
.Y(n_279)
);

OAI211xp5_ASAP7_75t_L g280 ( 
.A1(n_242),
.A2(n_96),
.B(n_95),
.C(n_91),
.Y(n_280)
);

INVx1_ASAP7_75t_L g281 ( 
.A(n_238),
.Y(n_281)
);

OAI32xp33_ASAP7_75t_L g282 ( 
.A1(n_258),
.A2(n_18),
.A3(n_99),
.B1(n_91),
.B2(n_95),
.Y(n_282)
);

NAND2xp5_ASAP7_75t_L g283 ( 
.A(n_259),
.B(n_95),
.Y(n_283)
);

INVx1_ASAP7_75t_L g284 ( 
.A(n_238),
.Y(n_284)
);

INVx2_ASAP7_75t_L g285 ( 
.A(n_261),
.Y(n_285)
);

AOI222xp33_ASAP7_75t_L g286 ( 
.A1(n_246),
.A2(n_99),
.B1(n_98),
.B2(n_93),
.C1(n_96),
.C2(n_132),
.Y(n_286)
);

OR4x1_ASAP7_75t_L g287 ( 
.A(n_255),
.B(n_26),
.C(n_25),
.D(n_23),
.Y(n_287)
);

AOI22xp33_ASAP7_75t_L g288 ( 
.A1(n_274),
.A2(n_134),
.B1(n_132),
.B2(n_93),
.Y(n_288)
);

NAND2xp5_ASAP7_75t_SL g289 ( 
.A(n_236),
.B(n_93),
.Y(n_289)
);

OR2x2_ASAP7_75t_L g290 ( 
.A(n_247),
.B(n_96),
.Y(n_290)
);

OAI321xp33_ASAP7_75t_L g291 ( 
.A1(n_274),
.A2(n_98),
.A3(n_93),
.B1(n_134),
.B2(n_121),
.C(n_106),
.Y(n_291)
);

INVx1_ASAP7_75t_L g292 ( 
.A(n_244),
.Y(n_292)
);

INVxp67_ASAP7_75t_SL g293 ( 
.A(n_260),
.Y(n_293)
);

INVxp67_ASAP7_75t_L g294 ( 
.A(n_247),
.Y(n_294)
);

INVx1_ASAP7_75t_L g295 ( 
.A(n_235),
.Y(n_295)
);

AOI22xp5_ASAP7_75t_L g296 ( 
.A1(n_248),
.A2(n_271),
.B1(n_269),
.B2(n_240),
.Y(n_296)
);

AOI22xp5_ASAP7_75t_L g297 ( 
.A1(n_269),
.A2(n_134),
.B1(n_132),
.B2(n_93),
.Y(n_297)
);

OAI22xp5_ASAP7_75t_L g298 ( 
.A1(n_260),
.A2(n_134),
.B1(n_119),
.B2(n_115),
.Y(n_298)
);

NAND2xp5_ASAP7_75t_L g299 ( 
.A(n_256),
.B(n_93),
.Y(n_299)
);

OAI211xp5_ASAP7_75t_L g300 ( 
.A1(n_250),
.A2(n_98),
.B(n_134),
.C(n_115),
.Y(n_300)
);

INVx1_ASAP7_75t_L g301 ( 
.A(n_263),
.Y(n_301)
);

NAND2xp5_ASAP7_75t_L g302 ( 
.A(n_239),
.B(n_98),
.Y(n_302)
);

A2O1A1Ixp33_ASAP7_75t_L g303 ( 
.A1(n_241),
.A2(n_245),
.B(n_276),
.C(n_277),
.Y(n_303)
);

INVx2_ASAP7_75t_L g304 ( 
.A(n_261),
.Y(n_304)
);

AND2x2_ASAP7_75t_L g305 ( 
.A(n_270),
.B(n_31),
.Y(n_305)
);

INVx1_ASAP7_75t_L g306 ( 
.A(n_254),
.Y(n_306)
);

AOI21xp33_ASAP7_75t_L g307 ( 
.A1(n_245),
.A2(n_98),
.B(n_32),
.Y(n_307)
);

NOR2xp33_ASAP7_75t_L g308 ( 
.A(n_273),
.B(n_35),
.Y(n_308)
);

NAND2xp5_ASAP7_75t_L g309 ( 
.A(n_257),
.B(n_98),
.Y(n_309)
);

OAI21xp5_ASAP7_75t_SL g310 ( 
.A1(n_276),
.A2(n_98),
.B(n_36),
.Y(n_310)
);

INVx1_ASAP7_75t_L g311 ( 
.A(n_254),
.Y(n_311)
);

INVx2_ASAP7_75t_SL g312 ( 
.A(n_240),
.Y(n_312)
);

XNOR2xp5_ASAP7_75t_L g313 ( 
.A(n_252),
.B(n_37),
.Y(n_313)
);

AOI21xp5_ASAP7_75t_SL g314 ( 
.A1(n_276),
.A2(n_267),
.B(n_253),
.Y(n_314)
);

AND2x2_ASAP7_75t_L g315 ( 
.A(n_270),
.B(n_39),
.Y(n_315)
);

OAI332xp33_ASAP7_75t_L g316 ( 
.A1(n_268),
.A2(n_117),
.A3(n_111),
.B1(n_106),
.B2(n_127),
.B3(n_40),
.C1(n_43),
.C2(n_42),
.Y(n_316)
);

OAI221xp5_ASAP7_75t_L g317 ( 
.A1(n_266),
.A2(n_117),
.B1(n_111),
.B2(n_106),
.C(n_127),
.Y(n_317)
);

NAND2xp5_ASAP7_75t_SL g318 ( 
.A(n_265),
.B(n_115),
.Y(n_318)
);

O2A1O1Ixp33_ASAP7_75t_SL g319 ( 
.A1(n_275),
.A2(n_48),
.B(n_47),
.C(n_44),
.Y(n_319)
);

OAI21xp5_ASAP7_75t_L g320 ( 
.A1(n_241),
.A2(n_119),
.B(n_115),
.Y(n_320)
);

INVx2_ASAP7_75t_SL g321 ( 
.A(n_318),
.Y(n_321)
);

NAND2xp5_ASAP7_75t_L g322 ( 
.A(n_293),
.B(n_237),
.Y(n_322)
);

NOR2xp33_ASAP7_75t_L g323 ( 
.A(n_294),
.B(n_252),
.Y(n_323)
);

INVx1_ASAP7_75t_SL g324 ( 
.A(n_312),
.Y(n_324)
);

OR2x2_ASAP7_75t_L g325 ( 
.A(n_306),
.B(n_262),
.Y(n_325)
);

XNOR2xp5_ASAP7_75t_L g326 ( 
.A(n_313),
.B(n_252),
.Y(n_326)
);

INVxp33_ASAP7_75t_L g327 ( 
.A(n_318),
.Y(n_327)
);

OR2x2_ASAP7_75t_L g328 ( 
.A(n_311),
.B(n_262),
.Y(n_328)
);

AND2x2_ASAP7_75t_L g329 ( 
.A(n_285),
.B(n_251),
.Y(n_329)
);

INVx1_ASAP7_75t_L g330 ( 
.A(n_301),
.Y(n_330)
);

NAND2xp5_ASAP7_75t_SL g331 ( 
.A(n_289),
.B(n_243),
.Y(n_331)
);

OAI22xp5_ASAP7_75t_L g332 ( 
.A1(n_296),
.A2(n_275),
.B1(n_272),
.B2(n_249),
.Y(n_332)
);

INVx1_ASAP7_75t_L g333 ( 
.A(n_281),
.Y(n_333)
);

AND3x2_ASAP7_75t_L g334 ( 
.A(n_314),
.B(n_49),
.C(n_111),
.Y(n_334)
);

INVx1_ASAP7_75t_L g335 ( 
.A(n_284),
.Y(n_335)
);

NAND2xp5_ASAP7_75t_L g336 ( 
.A(n_292),
.B(n_121),
.Y(n_336)
);

AND2x2_ASAP7_75t_L g337 ( 
.A(n_304),
.B(n_121),
.Y(n_337)
);

INVx1_ASAP7_75t_L g338 ( 
.A(n_295),
.Y(n_338)
);

INVx1_ASAP7_75t_L g339 ( 
.A(n_299),
.Y(n_339)
);

NAND2xp5_ASAP7_75t_L g340 ( 
.A(n_279),
.B(n_119),
.Y(n_340)
);

CKINVDCx5p33_ASAP7_75t_R g341 ( 
.A(n_290),
.Y(n_341)
);

INVx1_ASAP7_75t_L g342 ( 
.A(n_283),
.Y(n_342)
);

INVxp67_ASAP7_75t_L g343 ( 
.A(n_289),
.Y(n_343)
);

NAND2xp5_ASAP7_75t_L g344 ( 
.A(n_303),
.B(n_119),
.Y(n_344)
);

AND2x2_ASAP7_75t_SL g345 ( 
.A(n_323),
.B(n_288),
.Y(n_345)
);

O2A1O1Ixp33_ASAP7_75t_L g346 ( 
.A1(n_343),
.A2(n_310),
.B(n_278),
.C(n_307),
.Y(n_346)
);

AND2x2_ASAP7_75t_L g347 ( 
.A(n_323),
.B(n_302),
.Y(n_347)
);

AOI22xp5_ASAP7_75t_L g348 ( 
.A1(n_341),
.A2(n_308),
.B1(n_300),
.B2(n_297),
.Y(n_348)
);

XOR2x2_ASAP7_75t_L g349 ( 
.A(n_326),
.B(n_298),
.Y(n_349)
);

NOR2xp33_ASAP7_75t_SL g350 ( 
.A(n_334),
.B(n_282),
.Y(n_350)
);

OAI22xp5_ASAP7_75t_L g351 ( 
.A1(n_327),
.A2(n_288),
.B1(n_308),
.B2(n_309),
.Y(n_351)
);

INVx1_ASAP7_75t_SL g352 ( 
.A(n_324),
.Y(n_352)
);

INVx1_ASAP7_75t_L g353 ( 
.A(n_330),
.Y(n_353)
);

AOI222xp33_ASAP7_75t_L g354 ( 
.A1(n_332),
.A2(n_320),
.B1(n_280),
.B2(n_315),
.C1(n_305),
.C2(n_291),
.Y(n_354)
);

INVx1_ASAP7_75t_L g355 ( 
.A(n_333),
.Y(n_355)
);

AOI321xp33_ASAP7_75t_L g356 ( 
.A1(n_344),
.A2(n_316),
.A3(n_317),
.B1(n_287),
.B2(n_286),
.C(n_319),
.Y(n_356)
);

INVx1_ASAP7_75t_L g357 ( 
.A(n_335),
.Y(n_357)
);

AOI21xp33_ASAP7_75t_L g358 ( 
.A1(n_327),
.A2(n_319),
.B(n_119),
.Y(n_358)
);

INVx2_ASAP7_75t_SL g359 ( 
.A(n_341),
.Y(n_359)
);

AOI21xp33_ASAP7_75t_L g360 ( 
.A1(n_321),
.A2(n_342),
.B(n_331),
.Y(n_360)
);

AOI21xp33_ASAP7_75t_SL g361 ( 
.A1(n_331),
.A2(n_321),
.B(n_322),
.Y(n_361)
);

OAI21xp33_ASAP7_75t_L g362 ( 
.A1(n_329),
.A2(n_338),
.B(n_339),
.Y(n_362)
);

HB1xp67_ASAP7_75t_L g363 ( 
.A(n_352),
.Y(n_363)
);

AOI221xp5_ASAP7_75t_L g364 ( 
.A1(n_361),
.A2(n_329),
.B1(n_340),
.B2(n_325),
.C(n_328),
.Y(n_364)
);

HB1xp67_ASAP7_75t_L g365 ( 
.A(n_352),
.Y(n_365)
);

NOR2xp33_ASAP7_75t_R g366 ( 
.A(n_359),
.B(n_325),
.Y(n_366)
);

NAND2xp5_ASAP7_75t_SL g367 ( 
.A(n_345),
.B(n_337),
.Y(n_367)
);

NAND2xp5_ASAP7_75t_L g368 ( 
.A(n_362),
.B(n_337),
.Y(n_368)
);

NOR2x1_ASAP7_75t_L g369 ( 
.A(n_346),
.B(n_336),
.Y(n_369)
);

NAND2xp33_ASAP7_75t_SL g370 ( 
.A(n_347),
.B(n_351),
.Y(n_370)
);

AOI211xp5_ASAP7_75t_L g371 ( 
.A1(n_360),
.A2(n_350),
.B(n_358),
.C(n_348),
.Y(n_371)
);

NAND4xp25_ASAP7_75t_L g372 ( 
.A(n_371),
.B(n_350),
.C(n_354),
.D(n_356),
.Y(n_372)
);

NAND4xp25_ASAP7_75t_L g373 ( 
.A(n_370),
.B(n_369),
.C(n_354),
.D(n_367),
.Y(n_373)
);

AOI211xp5_ASAP7_75t_L g374 ( 
.A1(n_363),
.A2(n_353),
.B(n_357),
.C(n_355),
.Y(n_374)
);

OR2x2_ASAP7_75t_L g375 ( 
.A(n_365),
.B(n_368),
.Y(n_375)
);

NAND2xp5_ASAP7_75t_SL g376 ( 
.A(n_366),
.B(n_349),
.Y(n_376)
);

INVx2_ASAP7_75t_L g377 ( 
.A(n_375),
.Y(n_377)
);

INVx2_ASAP7_75t_SL g378 ( 
.A(n_376),
.Y(n_378)
);

CKINVDCx20_ASAP7_75t_R g379 ( 
.A(n_372),
.Y(n_379)
);

CKINVDCx20_ASAP7_75t_R g380 ( 
.A(n_379),
.Y(n_380)
);

AND4x1_ASAP7_75t_L g381 ( 
.A(n_379),
.B(n_374),
.C(n_364),
.D(n_373),
.Y(n_381)
);

INVx1_ASAP7_75t_L g382 ( 
.A(n_380),
.Y(n_382)
);

HB1xp67_ASAP7_75t_L g383 ( 
.A(n_382),
.Y(n_383)
);

NAND2xp5_ASAP7_75t_L g384 ( 
.A(n_383),
.B(n_378),
.Y(n_384)
);

AOI21xp5_ASAP7_75t_L g385 ( 
.A1(n_384),
.A2(n_377),
.B(n_381),
.Y(n_385)
);


endmodule