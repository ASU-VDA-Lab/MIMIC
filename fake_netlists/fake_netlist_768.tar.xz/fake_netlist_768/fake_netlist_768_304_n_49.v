module fake_netlist_768_304_n_49 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_49);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_49;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_28;
wire n_37;
wire n_27;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

AND2x4_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_10),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_17),
.B(n_21),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_3),
.B(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_12),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_9),
.Y(n_30)
);

INVx2_ASAP7_75t_SL g31 ( 
.A(n_25),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_22),
.B(n_18),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_31),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_35),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

OAI21xp33_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_35),
.B(n_33),
.Y(n_41)
);

OAI221xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_34),
.B1(n_29),
.B2(n_24),
.C(n_27),
.Y(n_42)
);

AO21x1_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_22),
.B(n_26),
.Y(n_43)
);

OAI221xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_30),
.B1(n_28),
.B2(n_18),
.C(n_19),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_30),
.B1(n_19),
.B2(n_0),
.Y(n_46)
);

NOR4xp25_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_30),
.C(n_2),
.D(n_1),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_46),
.Y(n_48)
);

AOI322xp5_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_47),
.A3(n_7),
.B1(n_6),
.B2(n_5),
.C1(n_16),
.C2(n_13),
.Y(n_49)
);


endmodule