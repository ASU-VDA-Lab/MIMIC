module fake_netlist_768_3886_n_52 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_52);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_52;

wire n_46;
wire n_44;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_27;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVx1_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_4),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_10),
.B(n_14),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_1),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_18),
.A2(n_6),
.B1(n_22),
.B2(n_8),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_11),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_18),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_15),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_16),
.Y(n_35)
);

NOR3xp33_ASAP7_75t_SL g36 ( 
.A(n_26),
.B(n_17),
.C(n_16),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_29),
.B1(n_30),
.B2(n_26),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_25),
.B1(n_30),
.B2(n_28),
.Y(n_39)
);

OAI33xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_34),
.A3(n_37),
.B1(n_27),
.B2(n_33),
.B3(n_36),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_36),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_17),
.Y(n_43)
);

NAND4xp25_ASAP7_75t_SL g44 ( 
.A(n_43),
.B(n_42),
.C(n_21),
.D(n_0),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_21),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_2),
.Y(n_47)
);

INVxp67_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

NAND5xp2_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_5),
.C(n_3),
.D(n_9),
.E(n_12),
.Y(n_49)
);

NOR2x1_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_13),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_20),
.B1(n_23),
.B2(n_51),
.Y(n_52)
);


endmodule