module fake_netlist_768_286_n_16 (n_0, n_2, n_1, n_16);

input n_0;
input n_2;
input n_1;

output n_16;

wire n_12;
wire n_15;
wire n_14;
wire n_3;
wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

INVx2_ASAP7_75t_SL g3 ( 
.A(n_1),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

OR2x6_ASAP7_75t_SL g5 ( 
.A(n_1),
.B(n_2),
.Y(n_5)
);

AOI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.Y(n_6)
);

CKINVDCx16_ASAP7_75t_R g7 ( 
.A(n_5),
.Y(n_7)
);

OAI22xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_3),
.B1(n_4),
.B2(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_2),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

OAI211xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_6),
.B(n_9),
.C(n_0),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_0),
.B1(n_10),
.B2(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_SL g14 ( 
.A(n_12),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_10),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B1(n_14),
.B2(n_7),
.Y(n_16)
);


endmodule