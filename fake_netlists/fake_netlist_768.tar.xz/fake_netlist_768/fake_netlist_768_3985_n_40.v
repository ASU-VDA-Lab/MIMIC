module fake_netlist_768_3985_n_40 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_40);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_40;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_0),
.B(n_7),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_1),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

AND2x6_ASAP7_75t_L g21 ( 
.A(n_3),
.B(n_4),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_5),
.Y(n_25)
);

INVx6_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_21),
.B1(n_16),
.B2(n_18),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_15),
.B1(n_19),
.B2(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

OAI211xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_23),
.B(n_24),
.C(n_20),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_21),
.Y(n_32)
);

XNOR2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_30),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_SL g34 ( 
.A1(n_32),
.A2(n_21),
.B(n_20),
.Y(n_34)
);

INVx3_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

NOR2x1_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_6),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_26),
.B1(n_9),
.B2(n_2),
.C(n_8),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_37),
.C(n_13),
.Y(n_40)
);


endmodule