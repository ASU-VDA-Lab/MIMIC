module fake_netlist_768_389_n_15 (n_0, n_2, n_1, n_15);

input n_0;
input n_2;
input n_1;

output n_15;

wire n_12;
wire n_14;
wire n_3;
wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx5_ASAP7_75t_SL g7 ( 
.A(n_5),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_3),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_SL g9 ( 
.A1(n_7),
.A2(n_6),
.B(n_4),
.C(n_2),
.Y(n_9)
);

AOI322xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_6),
.C1(n_3),
.C2(n_4),
.Y(n_10)
);

OAI222xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_1),
.B2(n_0),
.C1(n_2),
.C2(n_7),
.Y(n_11)
);

AOI211xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_8),
.B(n_1),
.C(n_0),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_7),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_1),
.B1(n_2),
.B2(n_7),
.C1(n_12),
.C2(n_14),
.Y(n_15)
);


endmodule