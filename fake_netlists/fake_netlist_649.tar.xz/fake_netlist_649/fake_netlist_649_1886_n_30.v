module fake_netlist_649_1886_n_30 (n_9, n_4, n_7, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_30);

input n_9;
input n_4;
input n_7;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_30;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_26;

NAND2xp33_ASAP7_75t_R g14 ( 
.A(n_10),
.B(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AND2x6_ASAP7_75t_L g16 ( 
.A(n_3),
.B(n_11),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_7),
.B(n_1),
.Y(n_17)
);

NAND2xp33_ASAP7_75t_R g18 ( 
.A(n_5),
.B(n_8),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_18),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_17),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_22),
.B(n_21),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.B1(n_15),
.B2(n_4),
.Y(n_26)
);

AOI211xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_6),
.B(n_4),
.C(n_16),
.Y(n_27)
);

BUFx4f_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI322xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_26),
.A3(n_6),
.B1(n_16),
.B2(n_9),
.C1(n_0),
.C2(n_13),
.Y(n_30)
);


endmodule