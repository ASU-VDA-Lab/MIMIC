module fake_netlist_649_3867_n_28 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_28);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_28;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_26;
wire n_13;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_2),
.B(n_10),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVxp33_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_5),
.C(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_SL g19 ( 
.A(n_15),
.Y(n_19)
);

OR2x6_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_14),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B1(n_13),
.B2(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_20),
.Y(n_23)
);

OAI321xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_18),
.A3(n_12),
.B1(n_7),
.B2(n_6),
.C(n_5),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_24),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AOI222xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_26),
.B1(n_7),
.B2(n_6),
.C1(n_9),
.C2(n_3),
.Y(n_28)
);


endmodule