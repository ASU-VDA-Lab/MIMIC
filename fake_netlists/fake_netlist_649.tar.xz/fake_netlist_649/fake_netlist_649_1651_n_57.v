module fake_netlist_649_1651_n_57 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_57);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_57;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_16;
wire n_22;
wire n_17;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_12),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_8),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_SL g28 ( 
.A(n_19),
.B(n_0),
.Y(n_28)
);

OR2x6_ASAP7_75t_L g29 ( 
.A(n_19),
.B(n_1),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_15),
.B(n_1),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_20),
.B(n_4),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_SL g32 ( 
.A1(n_29),
.A2(n_17),
.B1(n_20),
.B2(n_18),
.Y(n_32)
);

BUFx3_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

AND2x2_ASAP7_75t_SL g34 ( 
.A(n_31),
.B(n_16),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_27),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

OAI31xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_28),
.A3(n_31),
.B(n_30),
.Y(n_38)
);

BUFx4f_ASAP7_75t_SL g39 ( 
.A(n_34),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_L g40 ( 
.A(n_32),
.B(n_30),
.C(n_29),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_34),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_34),
.Y(n_44)
);

NOR2x1p5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_39),
.Y(n_45)
);

INVxp67_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

OAI21xp33_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_32),
.B(n_41),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_38),
.B1(n_25),
.B2(n_27),
.C(n_35),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_45),
.Y(n_49)
);

AOI221xp5_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_35),
.B1(n_33),
.B2(n_23),
.C(n_24),
.Y(n_50)
);

AOI211xp5_ASAP7_75t_L g51 ( 
.A1(n_44),
.A2(n_45),
.B(n_33),
.C(n_4),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_44),
.B1(n_6),
.B2(n_5),
.Y(n_52)
);

AND2x4_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_10),
.Y(n_53)
);

NOR4xp25_ASAP7_75t_SL g54 ( 
.A(n_48),
.B(n_7),
.C(n_5),
.D(n_11),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

AOI322xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_7),
.A3(n_53),
.B1(n_54),
.B2(n_32),
.C1(n_55),
.C2(n_28),
.Y(n_57)
);


endmodule