module fake_netlist_649_933_n_50 (n_9, n_4, n_7, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_50);

input n_9;
input n_4;
input n_7;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_50;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_16;
wire n_22;
wire n_17;
wire n_39;
wire n_14;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

BUFx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_1),
.B(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_2),
.B(n_10),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_3),
.B(n_2),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_7),
.B(n_6),
.Y(n_20)
);

BUFx10_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_0),
.B(n_11),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_13),
.B(n_12),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_21),
.B(n_0),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_22),
.B(n_4),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_14),
.B(n_4),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_14),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_21),
.B(n_5),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_SL g31 ( 
.A(n_27),
.B(n_25),
.Y(n_31)
);

NAND2xp33_ASAP7_75t_SL g32 ( 
.A(n_25),
.B(n_22),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_28),
.A2(n_16),
.B1(n_20),
.B2(n_17),
.Y(n_33)
);

NAND2xp33_ASAP7_75t_R g34 ( 
.A(n_29),
.B(n_23),
.Y(n_34)
);

OAI21x1_ASAP7_75t_SL g35 ( 
.A1(n_24),
.A2(n_20),
.B(n_18),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_26),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_26),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_31),
.A2(n_15),
.B1(n_26),
.B2(n_30),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_33),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_34),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_36),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_38),
.Y(n_43)
);

OAI222xp33_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_41),
.B1(n_19),
.B2(n_15),
.C1(n_21),
.C2(n_5),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_21),
.Y(n_45)
);

OAI322xp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_10),
.A3(n_11),
.B1(n_16),
.B2(n_25),
.C1(n_30),
.C2(n_24),
.Y(n_46)
);

XNOR2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_46),
.Y(n_47)
);

INVx3_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_47),
.Y(n_49)
);

BUFx2_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);


endmodule