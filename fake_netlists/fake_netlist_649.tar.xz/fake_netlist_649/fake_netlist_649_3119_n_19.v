module fake_netlist_649_3119_n_19 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_19);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_19;

wire n_18;
wire n_10;
wire n_11;
wire n_15;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

AND2x4_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_7),
.A2(n_2),
.B1(n_4),
.B2(n_8),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_5),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B1(n_13),
.B2(n_12),
.C1(n_6),
.C2(n_5),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_10),
.B1(n_12),
.B2(n_0),
.Y(n_17)
);

INVx4_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_1),
.B1(n_3),
.B2(n_12),
.C1(n_15),
.C2(n_16),
.Y(n_19)
);


endmodule