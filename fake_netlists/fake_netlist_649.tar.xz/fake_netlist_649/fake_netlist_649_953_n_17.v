module fake_netlist_649_953_n_17 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_17);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_17;

wire n_14;
wire n_10;
wire n_15;
wire n_9;
wire n_11;
wire n_13;
wire n_16;
wire n_12;

INVx1_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_7),
.B(n_4),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_14)
);

OA211x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_5),
.B(n_4),
.C(n_1),
.Y(n_15)
);

AOI22x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.C(n_3),
.Y(n_17)
);


endmodule