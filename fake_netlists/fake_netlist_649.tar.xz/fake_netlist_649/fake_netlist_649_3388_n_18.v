module fake_netlist_649_3388_n_18 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_18);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_18;

wire n_17;
wire n_14;
wire n_10;
wire n_11;
wire n_9;
wire n_15;
wire n_13;
wire n_16;
wire n_12;

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_2),
.Y(n_11)
);

AO31x2_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_6),
.A3(n_5),
.B(n_4),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B1(n_9),
.B2(n_10),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_16)
);

OAI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_17)
);

AO21x2_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_8),
.B(n_15),
.Y(n_18)
);


endmodule