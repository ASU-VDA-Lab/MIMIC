module fake_netlist_649_1540_n_17 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_17);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_17;

wire n_14;
wire n_10;
wire n_11;
wire n_9;
wire n_15;
wire n_13;
wire n_16;
wire n_12;

AND2x2_ASAP7_75t_SL g9 ( 
.A(n_8),
.B(n_0),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_4),
.A2(n_2),
.B1(n_6),
.B2(n_3),
.Y(n_10)
);

INVx4_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_SL g12 ( 
.A1(n_9),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_12)
);

AOI211xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_11),
.C(n_1),
.Y(n_13)
);

O2A1O1Ixp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_11),
.B(n_6),
.C(n_5),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_7),
.B1(n_15),
.B2(n_12),
.Y(n_17)
);


endmodule