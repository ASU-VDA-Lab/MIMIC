module fake_netlist_649_107_n_13 (n_4, n_1, n_2, n_0, n_3, n_13);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_13;

wire n_7;
wire n_5;
wire n_10;
wire n_6;
wire n_11;
wire n_12;
wire n_8;
wire n_9;

INVx1_ASAP7_75t_SL g5 ( 
.A(n_2),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

O2A1O1Ixp33_ASAP7_75t_SL g8 ( 
.A1(n_5),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

O2A1O1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B(n_7),
.C(n_0),
.Y(n_11)
);

OAI31xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_6),
.A3(n_7),
.B(n_3),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.B(n_4),
.Y(n_13)
);


endmodule