module fake_netlist_649_3951_n_20 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_20);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_20;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_6),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_10),
.B(n_11),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_9),
.B1(n_8),
.B2(n_11),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_9),
.B1(n_13),
.B2(n_1),
.C(n_4),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_9),
.C(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_5),
.B1(n_3),
.B2(n_0),
.Y(n_20)
);


endmodule