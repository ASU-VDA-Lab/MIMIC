module fake_netlist_649_621_n_32 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_32);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_32;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_9;
wire n_13;
wire n_8;

BUFx2_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_3),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_6),
.B(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_2),
.Y(n_14)
);

AND2x6_ASAP7_75t_SL g15 ( 
.A(n_11),
.B(n_4),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_5),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_5),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_8),
.A2(n_12),
.B1(n_13),
.B2(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_12),
.Y(n_20)
);

INVx4_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_16),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_12),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_20),
.B1(n_15),
.B2(n_19),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_23),
.B1(n_24),
.B2(n_21),
.C(n_13),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_21),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_28),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);


endmodule