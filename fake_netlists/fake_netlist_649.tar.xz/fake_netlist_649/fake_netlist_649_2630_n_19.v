module fake_netlist_649_2630_n_19 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_19);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_19;

wire n_18;
wire n_10;
wire n_11;
wire n_15;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_1),
.Y(n_12)
);

OR2x6_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_2),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_4),
.B(n_3),
.Y(n_14)
);

INVx5_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.Y(n_17)
);

O2A1O1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_12),
.B(n_11),
.C(n_6),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_9),
.B(n_7),
.Y(n_19)
);


endmodule