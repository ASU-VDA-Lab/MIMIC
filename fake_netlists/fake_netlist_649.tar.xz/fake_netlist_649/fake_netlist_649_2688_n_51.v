module fake_netlist_649_2688_n_51 (n_9, n_4, n_7, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_51);

input n_9;
input n_4;
input n_7;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_51;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_16;
wire n_22;
wire n_17;
wire n_39;
wire n_14;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_4),
.Y(n_14)
);

NOR2x1_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_13),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_11),
.B(n_1),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_0),
.B(n_2),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_9),
.B(n_2),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

OAI22xp33_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_23)
);

BUFx8_ASAP7_75t_SL g24 ( 
.A(n_18),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_16),
.Y(n_27)
);

CKINVDCx14_ASAP7_75t_R g28 ( 
.A(n_21),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

OAI21x1_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_14),
.B(n_22),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_25),
.A2(n_19),
.B1(n_21),
.B2(n_14),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_25),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

OAI321xp33_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_23),
.A3(n_17),
.B1(n_28),
.B2(n_26),
.C(n_27),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_30),
.B(n_26),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_33),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_33),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_31),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_37),
.Y(n_41)
);

AOI221x1_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_37),
.B1(n_34),
.B2(n_32),
.C(n_30),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_37),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_R g44 ( 
.A(n_41),
.B(n_24),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_43),
.Y(n_45)
);

NOR2x1_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_23),
.Y(n_46)
);

AOI21xp5_ASAP7_75t_L g47 ( 
.A1(n_41),
.A2(n_30),
.B(n_26),
.Y(n_47)
);

OAI322xp33_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_46),
.A3(n_47),
.B1(n_34),
.B2(n_32),
.C1(n_5),
.C2(n_6),
.Y(n_48)
);

OAI221xp5_ASAP7_75t_L g49 ( 
.A1(n_44),
.A2(n_15),
.B1(n_32),
.B2(n_6),
.C(n_7),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_48),
.B1(n_15),
.B2(n_7),
.Y(n_51)
);


endmodule