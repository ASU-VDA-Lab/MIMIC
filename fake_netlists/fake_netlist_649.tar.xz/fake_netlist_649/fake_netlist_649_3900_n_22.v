module fake_netlist_649_3900_n_22 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_22);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_22;

wire n_18;
wire n_19;
wire n_15;
wire n_11;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_1),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_9),
.B(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

AO21x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_7),
.B(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_13),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

OAI222xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.B1(n_15),
.B2(n_11),
.C1(n_6),
.C2(n_0),
.Y(n_19)
);

NAND3x1_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_15),
.C(n_2),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

OA21x2_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_8),
.B(n_4),
.Y(n_22)
);


endmodule