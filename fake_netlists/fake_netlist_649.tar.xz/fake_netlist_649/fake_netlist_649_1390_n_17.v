module fake_netlist_649_1390_n_17 (n_3, n_1, n_2, n_0, n_17);

input n_3;
input n_1;
input n_2;
input n_0;

output n_17;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_12;
wire n_10;
wire n_11;
wire n_16;
wire n_8;
wire n_15;
wire n_6;

BUFx10_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

XNOR2xp5_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_2),
.Y(n_5)
);

INVx5_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_0),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_4),
.B1(n_5),
.B2(n_1),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_2),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

AOI21xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_12),
.B(n_10),
.C(n_9),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_10),
.Y(n_15)
);

OAI321xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_1),
.A3(n_3),
.B1(n_4),
.B2(n_6),
.C(n_14),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B(n_13),
.Y(n_17)
);


endmodule