module fake_netlist_649_4868_n_25 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_25);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_25;

wire n_18;
wire n_19;
wire n_10;
wire n_24;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

AO22x2_ASAP7_75t_L g8 ( 
.A1(n_0),
.A2(n_3),
.B1(n_4),
.B2(n_2),
.Y(n_8)
);

INVxp33_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_7),
.B(n_10),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_6),
.B(n_1),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_11),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_9),
.Y(n_16)
);

AOI21xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_8),
.B(n_10),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_14),
.C(n_8),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_14),
.B(n_15),
.C(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

NOR2xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_1),
.Y(n_21)
);

NAND2x1p5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_13),
.Y(n_22)
);

AOI211xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.B(n_8),
.C(n_6),
.Y(n_23)
);

OAI22x1_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_23),
.B(n_24),
.Y(n_25)
);


endmodule