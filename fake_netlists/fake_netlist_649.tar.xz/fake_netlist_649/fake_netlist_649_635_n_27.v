module fake_netlist_649_635_n_27 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_27);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_27;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_11;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_26;
wire n_9;
wire n_13;
wire n_8;

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_3),
.C(n_4),
.Y(n_10)
);

AND3x2_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_0),
.C(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

AOI21xp33_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_9),
.A2(n_6),
.B(n_5),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_SL g16 ( 
.A1(n_8),
.A2(n_12),
.B1(n_11),
.B2(n_5),
.C(n_6),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_11),
.Y(n_17)
);

NOR4xp25_ASAP7_75t_SL g18 ( 
.A(n_14),
.B(n_7),
.C(n_6),
.D(n_5),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_15),
.Y(n_20)
);

AOI211xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B(n_17),
.C(n_16),
.Y(n_21)
);

AOI211xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_17),
.B(n_16),
.C(n_18),
.Y(n_22)
);

INVx5_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_19),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_23),
.A2(n_17),
.B1(n_19),
.B2(n_18),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_2),
.B(n_23),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_26),
.Y(n_27)
);


endmodule