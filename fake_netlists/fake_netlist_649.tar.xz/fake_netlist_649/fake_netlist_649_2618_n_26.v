module fake_netlist_649_2618_n_26 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_26);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_26;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;

OR2x2_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

OR2x6_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_5),
.B(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_1),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_7),
.A2(n_5),
.B(n_4),
.C(n_2),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_11),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

INVxp67_ASAP7_75t_SL g18 ( 
.A(n_16),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_17),
.B(n_14),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_17),
.B1(n_11),
.B2(n_9),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_13),
.C(n_19),
.Y(n_22)
);

NOR2xp67_ASAP7_75t_SL g23 ( 
.A(n_20),
.B(n_13),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_22),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_23),
.A2(n_6),
.B1(n_4),
.B2(n_3),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_6),
.B(n_25),
.Y(n_26)
);


endmodule