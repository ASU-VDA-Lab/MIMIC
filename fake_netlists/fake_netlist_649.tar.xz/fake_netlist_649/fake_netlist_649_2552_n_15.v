module fake_netlist_649_2552_n_15 (n_1, n_2, n_0, n_15);

input n_1;
input n_2;
input n_0;

output n_15;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;
wire n_3;

NOR2xp33_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_1),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_2),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_6),
.B(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_8),
.Y(n_10)
);

OAI321xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_0),
.A3(n_2),
.B1(n_6),
.B2(n_8),
.C(n_3),
.Y(n_11)
);

XNOR2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_12),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_0),
.B1(n_10),
.B2(n_11),
.C1(n_14),
.C2(n_12),
.Y(n_15)
);


endmodule