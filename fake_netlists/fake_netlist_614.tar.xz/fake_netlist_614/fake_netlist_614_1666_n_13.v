module fake_netlist_614_1666_n_13 (n_1, n_2, n_0, n_13);

input n_1;
input n_2;
input n_0;

output n_13;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_12;
wire n_3;

BUFx3_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

CKINVDCx20_ASAP7_75t_R g6 ( 
.A(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_0),
.Y(n_7)
);

INVxp67_ASAP7_75t_SL g8 ( 
.A(n_6),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_4),
.Y(n_9)
);

NOR2xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_4),
.Y(n_10)
);

NOR4xp25_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_4),
.C(n_5),
.D(n_3),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_4),
.B1(n_3),
.B2(n_0),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_2),
.B(n_11),
.Y(n_13)
);


endmodule