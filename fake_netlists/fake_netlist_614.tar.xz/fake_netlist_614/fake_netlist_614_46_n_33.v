module fake_netlist_614_46_n_33 (n_7, n_9, n_11, n_8, n_5, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_33);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_33;

wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_16;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

OR2x6_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

INVx2_ASAP7_75t_SL g21 ( 
.A(n_18),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_R g22 ( 
.A(n_16),
.B(n_0),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.B1(n_20),
.B2(n_15),
.Y(n_23)
);

AOI222xp33_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_17),
.B1(n_19),
.B2(n_7),
.C1(n_6),
.C2(n_4),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_22),
.B1(n_4),
.B2(n_1),
.C(n_2),
.Y(n_25)
);

NOR3xp33_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.C(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

CKINVDCx16_ASAP7_75t_R g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_8),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

OAI221xp5_ASAP7_75t_R g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_30),
.B2(n_10),
.C(n_11),
.Y(n_33)
);


endmodule