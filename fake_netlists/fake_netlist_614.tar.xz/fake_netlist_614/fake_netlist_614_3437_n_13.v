module fake_netlist_614_3437_n_13 (n_1, n_2, n_0, n_13);

input n_1;
input n_2;
input n_0;

output n_13;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_12;
wire n_3;

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_6)
);

AO31x2_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

OAI21xp33_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_4),
.B(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_7),
.Y(n_10)
);

NOR2x1_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_7),
.Y(n_11)
);

OAI22x1_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_5),
.B1(n_3),
.B2(n_8),
.Y(n_12)
);

OR2x6_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);


endmodule