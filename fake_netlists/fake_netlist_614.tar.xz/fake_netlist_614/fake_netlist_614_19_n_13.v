module fake_netlist_614_19_n_13 (n_1, n_2, n_0, n_13);

input n_1;
input n_2;
input n_0;

output n_13;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_12;
wire n_3;

BUFx6f_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_3),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_9),
.B(n_0),
.Y(n_10)
);

INVxp33_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_10),
.B1(n_7),
.B2(n_1),
.Y(n_13)
);


endmodule