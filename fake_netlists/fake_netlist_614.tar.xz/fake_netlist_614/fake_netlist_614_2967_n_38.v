module fake_netlist_614_2967_n_38 (n_7, n_9, n_11, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_38);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_38;

wire n_31;
wire n_37;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_1),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_10),
.B(n_13),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_7),
.B(n_3),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

INVx4_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_19),
.A2(n_11),
.B(n_9),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_17),
.B(n_0),
.Y(n_26)
);

A2O1A1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_19),
.B(n_22),
.C(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OA211x2_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_26),
.B(n_23),
.C(n_20),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_29),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_27),
.B1(n_23),
.B2(n_30),
.C(n_16),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_18),
.B1(n_4),
.B2(n_1),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_33),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_35),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_6),
.B1(n_7),
.B2(n_36),
.Y(n_38)
);


endmodule