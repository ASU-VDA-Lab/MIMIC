module fake_netlist_614_3353_n_23 (n_5, n_0, n_4, n_1, n_2, n_3, n_23);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_23;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_7;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

BUFx3_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

BUFx4f_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx4_ASAP7_75t_SL g10 ( 
.A(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_0),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_7),
.B(n_6),
.Y(n_13)
);

AOI22x1_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

NOR2x1_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_7),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_11),
.B1(n_9),
.B2(n_12),
.C(n_14),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_12),
.Y(n_18)
);

AOI211xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.B(n_14),
.C(n_1),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_10),
.B1(n_21),
.B2(n_20),
.Y(n_23)
);


endmodule