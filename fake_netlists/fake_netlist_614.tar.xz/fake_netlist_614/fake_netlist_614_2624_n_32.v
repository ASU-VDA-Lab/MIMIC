module fake_netlist_614_2624_n_32 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_32);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_32;

wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_5),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_10),
.B(n_4),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_11),
.B(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_5),
.B(n_1),
.Y(n_18)
);

INVx6_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_12),
.B(n_15),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_17),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_23),
.Y(n_27)
);

AOI32xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_20),
.A3(n_18),
.B1(n_24),
.B2(n_13),
.Y(n_28)
);

OAI211xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_25),
.B(n_26),
.C(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22x1_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_14),
.B1(n_19),
.B2(n_2),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_R g32 ( 
.A1(n_31),
.A2(n_9),
.B1(n_8),
.B2(n_4),
.Y(n_32)
);


endmodule