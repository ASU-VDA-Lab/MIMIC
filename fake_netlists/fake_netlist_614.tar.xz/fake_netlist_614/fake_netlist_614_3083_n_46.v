module fake_netlist_614_3083_n_46 (n_7, n_9, n_11, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_46);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_46;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_42;
wire n_33;
wire n_41;

INVx2_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_12),
.Y(n_17)
);

BUFx10_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_0),
.B(n_11),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_15),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_18),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_18),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_17),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

NAND4xp25_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_27),
.C(n_26),
.D(n_20),
.Y(n_32)
);

NAND2x1_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_30),
.Y(n_33)
);

INVxp67_ASAP7_75t_SL g34 ( 
.A(n_32),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_27),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_21),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_33),
.Y(n_37)
);

XNOR2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_6),
.Y(n_38)
);

CKINVDCx16_ASAP7_75t_R g39 ( 
.A(n_35),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_23),
.B1(n_4),
.B2(n_3),
.Y(n_40)
);

INVxp67_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_9),
.B(n_8),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_10),
.Y(n_43)
);

NAND2x1_ASAP7_75t_SL g44 ( 
.A(n_43),
.B(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_42),
.Y(n_45)
);

XOR2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_45),
.Y(n_46)
);


endmodule