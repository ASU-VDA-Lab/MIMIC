module fake_netlist_614_4471_n_12 (n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_12);

input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_12;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_10;

O2A1O1Ixp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_5),
.B(n_2),
.C(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_5),
.B(n_1),
.Y(n_8)
);

A2O1A1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_1),
.A2(n_6),
.B(n_4),
.C(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_4),
.Y(n_10)
);

NAND3x1_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.C(n_8),
.Y(n_11)
);

XNOR2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);


endmodule