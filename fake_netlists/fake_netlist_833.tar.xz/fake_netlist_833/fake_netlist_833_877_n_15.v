module fake_netlist_833_877_n_15 (n_2, n_0, n_3, n_1, n_15);

input n_2;
input n_0;
input n_3;
input n_1;

output n_15;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

AOI21xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

AND2x2_ASAP7_75t_SL g8 ( 
.A(n_6),
.B(n_5),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.Y(n_11)
);

NAND5xp2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.C(n_7),
.D(n_10),
.E(n_1),
.Y(n_12)
);

AOI322xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_2),
.A3(n_3),
.B1(n_8),
.B2(n_5),
.C1(n_4),
.C2(n_9),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_2),
.B1(n_3),
.B2(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);


endmodule