module fake_netlist_833_2037_n_41 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_41);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_41;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_8),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_13),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_15),
.B(n_4),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_23),
.Y(n_26)
);

O2A1O1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_16),
.B(n_5),
.C(n_4),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_20),
.A2(n_21),
.B1(n_22),
.B2(n_18),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_SL g29 ( 
.A(n_27),
.B(n_24),
.C(n_20),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

AOI211xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_28),
.B(n_21),
.C(n_19),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_5),
.Y(n_34)
);

AO22x2_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_31),
.B1(n_17),
.B2(n_0),
.Y(n_35)
);

OAI21xp33_ASAP7_75t_SL g36 ( 
.A1(n_33),
.A2(n_3),
.B(n_2),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_36),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_7),
.B(n_6),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_9),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_11),
.B1(n_14),
.B2(n_39),
.Y(n_41)
);


endmodule