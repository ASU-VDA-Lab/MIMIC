module fake_netlist_833_1324_n_18 (n_4, n_2, n_3, n_0, n_1, n_18);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_18;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_17;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_1),
.B(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_6),
.Y(n_9)
);

AOI211xp5_ASAP7_75t_SL g10 ( 
.A1(n_8),
.A2(n_5),
.B(n_1),
.C(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AOI21xp33_ASAP7_75t_SL g12 ( 
.A1(n_10),
.A2(n_5),
.B(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_8),
.B1(n_9),
.B2(n_11),
.C(n_10),
.Y(n_14)
);

NOR2x1_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_8),
.Y(n_15)
);

AND3x1_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_9),
.C(n_15),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_13),
.B1(n_1),
.B2(n_2),
.Y(n_17)
);

O2A1O1Ixp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_3),
.B(n_4),
.C(n_16),
.Y(n_18)
);


endmodule