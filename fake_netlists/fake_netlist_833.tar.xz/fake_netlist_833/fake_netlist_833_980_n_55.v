module fake_netlist_833_980_n_55 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_55);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_55;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_16),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_16),
.B1(n_7),
.B2(n_12),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_4),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_6),
.B(n_4),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_2),
.B(n_3),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_1),
.B(n_11),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_0),
.A2(n_2),
.B1(n_9),
.B2(n_10),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

OAI21x1_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_22),
.B(n_19),
.Y(n_31)
);

AOI22x1_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_23),
.B1(n_24),
.B2(n_21),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_27),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_28),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_34),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_31),
.Y(n_39)
);

O2A1O1Ixp5_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_21),
.B(n_23),
.C(n_24),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

O2A1O1Ixp5_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_36),
.B(n_37),
.C(n_38),
.Y(n_43)
);

OAI221xp5_ASAP7_75t_SL g44 ( 
.A1(n_39),
.A2(n_31),
.B1(n_25),
.B2(n_32),
.C(n_18),
.Y(n_44)
);

AOI31xp33_ASAP7_75t_L g45 ( 
.A1(n_39),
.A2(n_19),
.A3(n_23),
.B(n_21),
.Y(n_45)
);

NOR2x2_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_25),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_41),
.B1(n_39),
.B2(n_21),
.Y(n_47)
);

OAI221xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_40),
.B1(n_41),
.B2(n_0),
.C(n_1),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_42),
.A2(n_8),
.B1(n_5),
.B2(n_3),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_46),
.Y(n_50)
);

OR3x1_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_43),
.C(n_42),
.Y(n_51)
);

AOI221xp5_ASAP7_75t_L g52 ( 
.A1(n_47),
.A2(n_49),
.B1(n_10),
.B2(n_5),
.C(n_8),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

OAI222xp33_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_11),
.B1(n_13),
.B2(n_17),
.C1(n_48),
.C2(n_47),
.Y(n_54)
);

O2A1O1Ixp33_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_17),
.B(n_52),
.C(n_53),
.Y(n_55)
);


endmodule