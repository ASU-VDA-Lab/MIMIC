module fake_netlist_833_2751_n_60 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_60);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_60;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_34;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_2),
.B(n_7),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_19),
.Y(n_24)
);

NOR2x1_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_16),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_9),
.B(n_19),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_4),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_14),
.B(n_3),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_8),
.B(n_6),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_24),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_20),
.B(n_0),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

INVx5_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_8),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_28),
.B(n_24),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_22),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_32),
.B(n_21),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_30),
.B(n_28),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

AND2x4_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_37),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_SL g44 ( 
.A1(n_43),
.A2(n_38),
.B1(n_39),
.B2(n_26),
.Y(n_44)
);

OAI32xp33_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_29),
.A3(n_38),
.B1(n_23),
.B2(n_25),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_31),
.Y(n_46)
);

NOR2x1_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_23),
.Y(n_47)
);

OAI211xp5_ASAP7_75t_SL g48 ( 
.A1(n_44),
.A2(n_15),
.B(n_11),
.C(n_10),
.Y(n_48)
);

AOI21xp33_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_11),
.B(n_10),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_34),
.B1(n_18),
.B2(n_17),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_49),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

AND3x4_ASAP7_75t_L g54 ( 
.A(n_47),
.B(n_17),
.C(n_12),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_51),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_R g58 ( 
.A(n_54),
.B(n_13),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_55),
.Y(n_59)
);

OAI22xp33_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_57),
.B1(n_55),
.B2(n_58),
.Y(n_60)
);


endmodule