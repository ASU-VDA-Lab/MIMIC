module fake_netlist_833_1142_n_36 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_36);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_36;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_27;

INVxp67_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVxp67_ASAP7_75t_SL g20 ( 
.A(n_0),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_3),
.B(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_15),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_15),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_2),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_SL g26 ( 
.A(n_23),
.B(n_18),
.C(n_21),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_24),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_25),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_26),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

AND2x4_ASAP7_75t_SL g32 ( 
.A(n_31),
.B(n_28),
.Y(n_32)
);

OAI211xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_30),
.B(n_20),
.C(n_4),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_6),
.B1(n_5),
.B2(n_7),
.C(n_8),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_16),
.B1(n_12),
.B2(n_11),
.Y(n_36)
);


endmodule