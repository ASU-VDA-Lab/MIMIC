module fake_netlist_833_74_n_12 (n_2, n_0, n_3, n_1, n_12);

input n_2;
input n_0;
input n_3;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_9;
wire n_11;
wire n_8;

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx6_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_4),
.B1(n_2),
.B2(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_0),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_0),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_1),
.B1(n_3),
.B2(n_9),
.Y(n_11)
);

OAI22x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_3),
.B2(n_10),
.Y(n_12)
);


endmodule