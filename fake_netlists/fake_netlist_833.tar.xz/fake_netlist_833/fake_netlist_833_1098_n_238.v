module fake_netlist_833_1098_n_238 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_28, n_9, n_31, n_32, n_26, n_24, n_19, n_3, n_12, n_0, n_29, n_6, n_30, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_238);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_28;
input n_9;
input n_31;
input n_32;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_238;

wire n_49;
wire n_132;
wire n_97;
wire n_194;
wire n_221;
wire n_219;
wire n_81;
wire n_182;
wire n_114;
wire n_130;
wire n_80;
wire n_166;
wire n_123;
wire n_173;
wire n_156;
wire n_222;
wire n_126;
wire n_154;
wire n_78;
wire n_153;
wire n_195;
wire n_210;
wire n_187;
wire n_87;
wire n_167;
wire n_122;
wire n_54;
wire n_96;
wire n_95;
wire n_56;
wire n_232;
wire n_59;
wire n_63;
wire n_94;
wire n_74;
wire n_64;
wire n_79;
wire n_177;
wire n_110;
wire n_61;
wire n_184;
wire n_86;
wire n_43;
wire n_45;
wire n_108;
wire n_192;
wire n_48;
wire n_162;
wire n_163;
wire n_209;
wire n_196;
wire n_230;
wire n_158;
wire n_135;
wire n_171;
wire n_47;
wire n_118;
wire n_214;
wire n_127;
wire n_202;
wire n_90;
wire n_213;
wire n_76;
wire n_189;
wire n_160;
wire n_107;
wire n_125;
wire n_99;
wire n_151;
wire n_178;
wire n_72;
wire n_121;
wire n_73;
wire n_211;
wire n_235;
wire n_37;
wire n_207;
wire n_42;
wire n_120;
wire n_103;
wire n_155;
wire n_145;
wire n_227;
wire n_200;
wire n_175;
wire n_185;
wire n_52;
wire n_199;
wire n_143;
wire n_170;
wire n_77;
wire n_161;
wire n_190;
wire n_224;
wire n_229;
wire n_138;
wire n_57;
wire n_51;
wire n_137;
wire n_116;
wire n_136;
wire n_179;
wire n_102;
wire n_226;
wire n_119;
wire n_217;
wire n_89;
wire n_152;
wire n_172;
wire n_70;
wire n_131;
wire n_128;
wire n_133;
wire n_139;
wire n_142;
wire n_115;
wire n_109;
wire n_41;
wire n_62;
wire n_223;
wire n_34;
wire n_44;
wire n_144;
wire n_40;
wire n_117;
wire n_53;
wire n_84;
wire n_58;
wire n_68;
wire n_183;
wire n_146;
wire n_104;
wire n_105;
wire n_168;
wire n_225;
wire n_33;
wire n_106;
wire n_215;
wire n_149;
wire n_188;
wire n_85;
wire n_237;
wire n_205;
wire n_55;
wire n_164;
wire n_65;
wire n_159;
wire n_75;
wire n_140;
wire n_176;
wire n_67;
wire n_66;
wire n_101;
wire n_98;
wire n_91;
wire n_233;
wire n_36;
wire n_204;
wire n_203;
wire n_50;
wire n_191;
wire n_112;
wire n_129;
wire n_181;
wire n_157;
wire n_201;
wire n_198;
wire n_83;
wire n_228;
wire n_60;
wire n_39;
wire n_111;
wire n_169;
wire n_180;
wire n_93;
wire n_174;
wire n_216;
wire n_150;
wire n_220;
wire n_71;
wire n_208;
wire n_92;
wire n_82;
wire n_186;
wire n_100;
wire n_218;
wire n_69;
wire n_193;
wire n_234;
wire n_212;
wire n_165;
wire n_88;
wire n_124;
wire n_197;
wire n_113;
wire n_236;
wire n_206;
wire n_147;
wire n_231;
wire n_141;
wire n_134;
wire n_35;
wire n_148;
wire n_38;
wire n_46;

INVx1_ASAP7_75t_L g33 ( 
.A(n_1),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_23),
.Y(n_34)
);

CKINVDCx16_ASAP7_75t_R g35 ( 
.A(n_5),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_6),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_12),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_25),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_8),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_21),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_6),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_17),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_22),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_12),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_5),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_26),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_33),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_37),
.Y(n_48)
);

OAI21x1_ASAP7_75t_L g49 ( 
.A1(n_38),
.A2(n_14),
.B(n_13),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_41),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

BUFx6f_ASAP7_75t_L g52 ( 
.A(n_40),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_51),
.Y(n_54)
);

NOR2xp33_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_35),
.Y(n_55)
);

INVx2_ASAP7_75t_SL g56 ( 
.A(n_52),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_47),
.B(n_45),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_SL g58 ( 
.A(n_48),
.B(n_34),
.Y(n_58)
);

NAND2xp33_ASAP7_75t_L g59 ( 
.A(n_50),
.B(n_39),
.Y(n_59)
);

AND2x2_ASAP7_75t_L g60 ( 
.A(n_49),
.B(n_36),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_47),
.Y(n_61)
);

NOR3xp33_ASAP7_75t_L g62 ( 
.A(n_51),
.B(n_44),
.C(n_36),
.Y(n_62)
);

AOI22xp5_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_39),
.B1(n_44),
.B2(n_34),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_55),
.B(n_56),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_60),
.Y(n_65)
);

INVx3_ASAP7_75t_L g66 ( 
.A(n_60),
.Y(n_66)
);

AOI22xp5_ASAP7_75t_L g67 ( 
.A1(n_62),
.A2(n_46),
.B1(n_43),
.B2(n_42),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_60),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_53),
.Y(n_69)
);

BUFx3_ASAP7_75t_L g70 ( 
.A(n_56),
.Y(n_70)
);

INVx2_ASAP7_75t_SL g71 ( 
.A(n_57),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_53),
.Y(n_72)
);

AND2x2_ASAP7_75t_L g73 ( 
.A(n_57),
.B(n_0),
.Y(n_73)
);

INVx2_ASAP7_75t_L g74 ( 
.A(n_53),
.Y(n_74)
);

BUFx8_ASAP7_75t_L g75 ( 
.A(n_61),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_65),
.Y(n_76)
);

AND2x2_ASAP7_75t_L g77 ( 
.A(n_71),
.B(n_54),
.Y(n_77)
);

A2O1A1Ixp33_ASAP7_75t_L g78 ( 
.A1(n_65),
.A2(n_59),
.B(n_54),
.C(n_58),
.Y(n_78)
);

AND2x4_ASAP7_75t_L g79 ( 
.A(n_73),
.B(n_61),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_68),
.Y(n_80)
);

CKINVDCx5p33_ASAP7_75t_R g81 ( 
.A(n_75),
.Y(n_81)
);

INVx2_ASAP7_75t_SL g82 ( 
.A(n_66),
.Y(n_82)
);

OAI22xp5_ASAP7_75t_L g83 ( 
.A1(n_67),
.A2(n_63),
.B1(n_68),
.B2(n_71),
.Y(n_83)
);

AOI21xp5_ASAP7_75t_L g84 ( 
.A1(n_66),
.A2(n_64),
.B(n_69),
.Y(n_84)
);

NAND2xp5_ASAP7_75t_L g85 ( 
.A(n_66),
.B(n_56),
.Y(n_85)
);

BUFx3_ASAP7_75t_L g86 ( 
.A(n_66),
.Y(n_86)
);

INVx2_ASAP7_75t_L g87 ( 
.A(n_82),
.Y(n_87)
);

OAI21x1_ASAP7_75t_L g88 ( 
.A1(n_84),
.A2(n_69),
.B(n_72),
.Y(n_88)
);

OR2x2_ASAP7_75t_L g89 ( 
.A(n_77),
.B(n_73),
.Y(n_89)
);

NAND2xp5_ASAP7_75t_L g90 ( 
.A(n_82),
.B(n_76),
.Y(n_90)
);

AND2x2_ASAP7_75t_L g91 ( 
.A(n_76),
.B(n_63),
.Y(n_91)
);

AND2x2_ASAP7_75t_L g92 ( 
.A(n_80),
.B(n_67),
.Y(n_92)
);

OAI21x1_ASAP7_75t_L g93 ( 
.A1(n_84),
.A2(n_74),
.B(n_72),
.Y(n_93)
);

INVx1_ASAP7_75t_L g94 ( 
.A(n_80),
.Y(n_94)
);

AOI21xp33_ASAP7_75t_SL g95 ( 
.A1(n_89),
.A2(n_83),
.B(n_77),
.Y(n_95)
);

AND2x2_ASAP7_75t_L g96 ( 
.A(n_91),
.B(n_77),
.Y(n_96)
);

AND2x2_ASAP7_75t_L g97 ( 
.A(n_91),
.B(n_79),
.Y(n_97)
);

OR2x2_ASAP7_75t_L g98 ( 
.A(n_89),
.B(n_83),
.Y(n_98)
);

HB1xp67_ASAP7_75t_L g99 ( 
.A(n_92),
.Y(n_99)
);

INVx1_ASAP7_75t_L g100 ( 
.A(n_94),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_94),
.Y(n_101)
);

OA21x2_ASAP7_75t_L g102 ( 
.A1(n_100),
.A2(n_88),
.B(n_93),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_100),
.Y(n_103)
);

AND2x2_ASAP7_75t_L g104 ( 
.A(n_97),
.B(n_91),
.Y(n_104)
);

AOI22xp5_ASAP7_75t_L g105 ( 
.A1(n_97),
.A2(n_92),
.B1(n_79),
.B2(n_82),
.Y(n_105)
);

AOI22xp33_ASAP7_75t_L g106 ( 
.A1(n_99),
.A2(n_92),
.B1(n_75),
.B2(n_79),
.Y(n_106)
);

INVx2_ASAP7_75t_L g107 ( 
.A(n_101),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_101),
.Y(n_108)
);

AO21x2_ASAP7_75t_L g109 ( 
.A1(n_95),
.A2(n_88),
.B(n_93),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_98),
.Y(n_110)
);

CKINVDCx5p33_ASAP7_75t_R g111 ( 
.A(n_96),
.Y(n_111)
);

AND2x2_ASAP7_75t_L g112 ( 
.A(n_104),
.B(n_110),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_102),
.Y(n_113)
);

AND2x2_ASAP7_75t_L g114 ( 
.A(n_104),
.B(n_96),
.Y(n_114)
);

INVx2_ASAP7_75t_L g115 ( 
.A(n_102),
.Y(n_115)
);

AND2x2_ASAP7_75t_L g116 ( 
.A(n_104),
.B(n_98),
.Y(n_116)
);

AND2x2_ASAP7_75t_L g117 ( 
.A(n_110),
.B(n_95),
.Y(n_117)
);

AND2x2_ASAP7_75t_L g118 ( 
.A(n_107),
.B(n_103),
.Y(n_118)
);

AND2x2_ASAP7_75t_L g119 ( 
.A(n_107),
.B(n_79),
.Y(n_119)
);

AND2x2_ASAP7_75t_L g120 ( 
.A(n_107),
.B(n_103),
.Y(n_120)
);

NAND2xp5_ASAP7_75t_L g121 ( 
.A(n_108),
.B(n_105),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_102),
.Y(n_122)
);

AND2x2_ASAP7_75t_L g123 ( 
.A(n_108),
.B(n_87),
.Y(n_123)
);

INVx1_ASAP7_75t_L g124 ( 
.A(n_102),
.Y(n_124)
);

INVx1_ASAP7_75t_SL g125 ( 
.A(n_111),
.Y(n_125)
);

INVx2_ASAP7_75t_L g126 ( 
.A(n_102),
.Y(n_126)
);

AND2x4_ASAP7_75t_L g127 ( 
.A(n_105),
.B(n_87),
.Y(n_127)
);

AND2x2_ASAP7_75t_L g128 ( 
.A(n_109),
.B(n_88),
.Y(n_128)
);

AND2x2_ASAP7_75t_L g129 ( 
.A(n_112),
.B(n_109),
.Y(n_129)
);

OR2x2_ASAP7_75t_L g130 ( 
.A(n_112),
.B(n_109),
.Y(n_130)
);

NOR2x1_ASAP7_75t_L g131 ( 
.A(n_123),
.B(n_109),
.Y(n_131)
);

CKINVDCx16_ASAP7_75t_R g132 ( 
.A(n_125),
.Y(n_132)
);

AOI22xp33_ASAP7_75t_L g133 ( 
.A1(n_117),
.A2(n_106),
.B1(n_75),
.B2(n_86),
.Y(n_133)
);

BUFx2_ASAP7_75t_L g134 ( 
.A(n_128),
.Y(n_134)
);

CKINVDCx16_ASAP7_75t_R g135 ( 
.A(n_125),
.Y(n_135)
);

AND2x2_ASAP7_75t_L g136 ( 
.A(n_114),
.B(n_87),
.Y(n_136)
);

CKINVDCx20_ASAP7_75t_R g137 ( 
.A(n_114),
.Y(n_137)
);

INVx2_ASAP7_75t_L g138 ( 
.A(n_118),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_113),
.Y(n_139)
);

HB1xp67_ASAP7_75t_L g140 ( 
.A(n_118),
.Y(n_140)
);

NOR2xp33_ASAP7_75t_SL g141 ( 
.A(n_119),
.B(n_81),
.Y(n_141)
);

NAND2xp5_ASAP7_75t_L g142 ( 
.A(n_116),
.B(n_78),
.Y(n_142)
);

AND2x2_ASAP7_75t_L g143 ( 
.A(n_120),
.B(n_93),
.Y(n_143)
);

NAND2xp5_ASAP7_75t_L g144 ( 
.A(n_116),
.B(n_117),
.Y(n_144)
);

INVx1_ASAP7_75t_L g145 ( 
.A(n_113),
.Y(n_145)
);

AND2x2_ASAP7_75t_L g146 ( 
.A(n_120),
.B(n_90),
.Y(n_146)
);

AND2x4_ASAP7_75t_L g147 ( 
.A(n_127),
.B(n_123),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_122),
.Y(n_148)
);

OR2x2_ASAP7_75t_L g149 ( 
.A(n_121),
.B(n_74),
.Y(n_149)
);

INVx1_ASAP7_75t_SL g150 ( 
.A(n_119),
.Y(n_150)
);

OR2x2_ASAP7_75t_L g151 ( 
.A(n_121),
.B(n_90),
.Y(n_151)
);

INVxp67_ASAP7_75t_SL g152 ( 
.A(n_127),
.Y(n_152)
);

INVx2_ASAP7_75t_SL g153 ( 
.A(n_127),
.Y(n_153)
);

AND2x2_ASAP7_75t_L g154 ( 
.A(n_134),
.B(n_128),
.Y(n_154)
);

HB1xp67_ASAP7_75t_L g155 ( 
.A(n_140),
.Y(n_155)
);

NOR2x1_ASAP7_75t_L g156 ( 
.A(n_151),
.B(n_122),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_139),
.Y(n_157)
);

NOR2xp33_ASAP7_75t_L g158 ( 
.A(n_132),
.B(n_0),
.Y(n_158)
);

NAND2xp5_ASAP7_75t_L g159 ( 
.A(n_144),
.B(n_127),
.Y(n_159)
);

AND2x4_ASAP7_75t_SL g160 ( 
.A(n_136),
.B(n_128),
.Y(n_160)
);

NOR2xp33_ASAP7_75t_L g161 ( 
.A(n_132),
.B(n_1),
.Y(n_161)
);

O2A1O1Ixp33_ASAP7_75t_SL g162 ( 
.A1(n_142),
.A2(n_124),
.B(n_126),
.C(n_115),
.Y(n_162)
);

AND2x2_ASAP7_75t_L g163 ( 
.A(n_134),
.B(n_124),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_139),
.Y(n_164)
);

CKINVDCx16_ASAP7_75t_R g165 ( 
.A(n_135),
.Y(n_165)
);

AND2x2_ASAP7_75t_L g166 ( 
.A(n_129),
.B(n_147),
.Y(n_166)
);

OAI21xp33_ASAP7_75t_L g167 ( 
.A1(n_131),
.A2(n_126),
.B(n_115),
.Y(n_167)
);

INVxp67_ASAP7_75t_L g168 ( 
.A(n_141),
.Y(n_168)
);

AND2x2_ASAP7_75t_L g169 ( 
.A(n_129),
.B(n_115),
.Y(n_169)
);

INVx2_ASAP7_75t_L g170 ( 
.A(n_138),
.Y(n_170)
);

AND2x2_ASAP7_75t_L g171 ( 
.A(n_147),
.B(n_126),
.Y(n_171)
);

OAI22xp5_ASAP7_75t_L g172 ( 
.A1(n_133),
.A2(n_137),
.B1(n_151),
.B2(n_135),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_145),
.Y(n_173)
);

INVxp67_ASAP7_75t_L g174 ( 
.A(n_136),
.Y(n_174)
);

NAND2xp5_ASAP7_75t_L g175 ( 
.A(n_138),
.B(n_2),
.Y(n_175)
);

HB1xp67_ASAP7_75t_L g176 ( 
.A(n_130),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_145),
.Y(n_177)
);

INVx1_ASAP7_75t_L g178 ( 
.A(n_148),
.Y(n_178)
);

INVxp67_ASAP7_75t_L g179 ( 
.A(n_146),
.Y(n_179)
);

INVx1_ASAP7_75t_L g180 ( 
.A(n_148),
.Y(n_180)
);

INVx1_ASAP7_75t_SL g181 ( 
.A(n_150),
.Y(n_181)
);

NAND2xp5_ASAP7_75t_L g182 ( 
.A(n_146),
.B(n_130),
.Y(n_182)
);

NOR4xp25_ASAP7_75t_L g183 ( 
.A(n_161),
.B(n_153),
.C(n_149),
.D(n_143),
.Y(n_183)
);

NOR3xp33_ASAP7_75t_L g184 ( 
.A(n_172),
.B(n_131),
.C(n_149),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_164),
.Y(n_185)
);

NAND2xp5_ASAP7_75t_L g186 ( 
.A(n_157),
.B(n_143),
.Y(n_186)
);

INVx2_ASAP7_75t_L g187 ( 
.A(n_170),
.Y(n_187)
);

INVx2_ASAP7_75t_SL g188 ( 
.A(n_165),
.Y(n_188)
);

AOI211xp5_ASAP7_75t_L g189 ( 
.A1(n_158),
.A2(n_153),
.B(n_147),
.C(n_152),
.Y(n_189)
);

NAND3xp33_ASAP7_75t_L g190 ( 
.A(n_156),
.B(n_147),
.C(n_75),
.Y(n_190)
);

NOR2xp67_ASAP7_75t_L g191 ( 
.A(n_176),
.B(n_2),
.Y(n_191)
);

INVx1_ASAP7_75t_L g192 ( 
.A(n_157),
.Y(n_192)
);

INVx1_ASAP7_75t_SL g193 ( 
.A(n_181),
.Y(n_193)
);

OR2x2_ASAP7_75t_L g194 ( 
.A(n_182),
.B(n_3),
.Y(n_194)
);

NAND2xp5_ASAP7_75t_L g195 ( 
.A(n_173),
.B(n_3),
.Y(n_195)
);

AOI21xp5_ASAP7_75t_L g196 ( 
.A1(n_162),
.A2(n_85),
.B(n_86),
.Y(n_196)
);

INVx1_ASAP7_75t_SL g197 ( 
.A(n_155),
.Y(n_197)
);

NAND4xp25_ASAP7_75t_L g198 ( 
.A(n_167),
.B(n_175),
.C(n_163),
.D(n_173),
.Y(n_198)
);

OAI21xp5_ASAP7_75t_L g199 ( 
.A1(n_168),
.A2(n_85),
.B(n_86),
.Y(n_199)
);

NOR2xp33_ASAP7_75t_L g200 ( 
.A(n_179),
.B(n_174),
.Y(n_200)
);

OAI221xp5_ASAP7_75t_SL g201 ( 
.A1(n_159),
.A2(n_7),
.B1(n_4),
.B2(n_8),
.C(n_9),
.Y(n_201)
);

INVx1_ASAP7_75t_L g202 ( 
.A(n_177),
.Y(n_202)
);

AOI211xp5_ASAP7_75t_L g203 ( 
.A1(n_154),
.A2(n_9),
.B(n_7),
.C(n_4),
.Y(n_203)
);

NAND4xp25_ASAP7_75t_SL g204 ( 
.A(n_154),
.B(n_11),
.C(n_10),
.D(n_15),
.Y(n_204)
);

OAI211xp5_ASAP7_75t_SL g205 ( 
.A1(n_177),
.A2(n_11),
.B(n_10),
.C(n_16),
.Y(n_205)
);

INVx2_ASAP7_75t_SL g206 ( 
.A(n_166),
.Y(n_206)
);

OAI22xp33_ASAP7_75t_SL g207 ( 
.A1(n_201),
.A2(n_170),
.B1(n_180),
.B2(n_178),
.Y(n_207)
);

AOI22xp5_ASAP7_75t_L g208 ( 
.A1(n_204),
.A2(n_166),
.B1(n_171),
.B2(n_160),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_192),
.Y(n_209)
);

INVx1_ASAP7_75t_L g210 ( 
.A(n_202),
.Y(n_210)
);

NAND3xp33_ASAP7_75t_L g211 ( 
.A(n_184),
.B(n_180),
.C(n_171),
.Y(n_211)
);

NOR2xp33_ASAP7_75t_L g212 ( 
.A(n_195),
.B(n_163),
.Y(n_212)
);

OAI211xp5_ASAP7_75t_L g213 ( 
.A1(n_203),
.A2(n_183),
.B(n_198),
.C(n_195),
.Y(n_213)
);

NAND2xp5_ASAP7_75t_L g214 ( 
.A(n_186),
.B(n_169),
.Y(n_214)
);

AOI222xp33_ASAP7_75t_L g215 ( 
.A1(n_205),
.A2(n_160),
.B1(n_70),
.B2(n_20),
.C1(n_19),
.C2(n_18),
.Y(n_215)
);

INVx1_ASAP7_75t_L g216 ( 
.A(n_185),
.Y(n_216)
);

NOR2xp67_ASAP7_75t_L g217 ( 
.A(n_188),
.B(n_24),
.Y(n_217)
);

AOI322xp5_ASAP7_75t_L g218 ( 
.A1(n_200),
.A2(n_70),
.A3(n_29),
.B1(n_28),
.B2(n_27),
.C1(n_31),
.C2(n_30),
.Y(n_218)
);

NAND2xp5_ASAP7_75t_L g219 ( 
.A(n_186),
.B(n_70),
.Y(n_219)
);

AOI21xp5_ASAP7_75t_L g220 ( 
.A1(n_204),
.A2(n_190),
.B(n_196),
.Y(n_220)
);

NAND2xp5_ASAP7_75t_SL g221 ( 
.A(n_189),
.B(n_32),
.Y(n_221)
);

NOR2xp33_ASAP7_75t_L g222 ( 
.A(n_212),
.B(n_197),
.Y(n_222)
);

NAND2xp5_ASAP7_75t_L g223 ( 
.A(n_209),
.B(n_194),
.Y(n_223)
);

NAND4xp25_ASAP7_75t_L g224 ( 
.A(n_213),
.B(n_191),
.C(n_193),
.D(n_199),
.Y(n_224)
);

INVx2_ASAP7_75t_L g225 ( 
.A(n_210),
.Y(n_225)
);

BUFx2_ASAP7_75t_L g226 ( 
.A(n_216),
.Y(n_226)
);

NAND2xp5_ASAP7_75t_SL g227 ( 
.A(n_211),
.B(n_206),
.Y(n_227)
);

AND2x2_ASAP7_75t_L g228 ( 
.A(n_212),
.B(n_187),
.Y(n_228)
);

AOI22xp5_ASAP7_75t_L g229 ( 
.A1(n_224),
.A2(n_220),
.B1(n_207),
.B2(n_221),
.Y(n_229)
);

NAND2xp5_ASAP7_75t_L g230 ( 
.A(n_226),
.B(n_214),
.Y(n_230)
);

HB1xp67_ASAP7_75t_L g231 ( 
.A(n_225),
.Y(n_231)
);

INVx1_ASAP7_75t_L g232 ( 
.A(n_223),
.Y(n_232)
);

NAND4xp25_ASAP7_75t_L g233 ( 
.A(n_229),
.B(n_215),
.C(n_222),
.D(n_223),
.Y(n_233)
);

NAND3x1_ASAP7_75t_L g234 ( 
.A(n_232),
.B(n_228),
.C(n_208),
.Y(n_234)
);

XNOR2xp5_ASAP7_75t_L g235 ( 
.A(n_234),
.B(n_217),
.Y(n_235)
);

AOI21xp5_ASAP7_75t_L g236 ( 
.A1(n_235),
.A2(n_233),
.B(n_227),
.Y(n_236)
);

INVx4_ASAP7_75t_L g237 ( 
.A(n_236),
.Y(n_237)
);

AOI221x1_ASAP7_75t_L g238 ( 
.A1(n_237),
.A2(n_230),
.B1(n_219),
.B2(n_231),
.C(n_218),
.Y(n_238)
);


endmodule