module fake_netlist_833_2902_n_23 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_23);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

CKINVDCx16_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_10),
.B1(n_2),
.B2(n_1),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_4),
.C(n_3),
.Y(n_20)
);

AO221x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_6),
.B1(n_5),
.B2(n_7),
.C(n_8),
.Y(n_21)
);

INVx1_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_23)
);


endmodule