module fake_netlist_833_917_n_17 (n_4, n_2, n_5, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_16;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_1),
.Y(n_7)
);

CKINVDCx16_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx6_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

CKINVDCx14_ASAP7_75t_R g11 ( 
.A(n_10),
.Y(n_11)
);

AOI321xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_6),
.A3(n_7),
.B1(n_10),
.B2(n_1),
.C(n_0),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B(n_10),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_1),
.B2(n_0),
.C(n_2),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_9),
.Y(n_15)
);

OAI22x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_0),
.B1(n_4),
.B2(n_3),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_9),
.B1(n_5),
.B2(n_3),
.Y(n_17)
);


endmodule