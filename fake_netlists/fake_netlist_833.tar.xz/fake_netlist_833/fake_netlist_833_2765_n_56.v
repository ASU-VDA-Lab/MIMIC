module fake_netlist_833_2765_n_56 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_56);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_56;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_23;
wire n_39;
wire n_28;
wire n_53;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_29;
wire n_30;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_11),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_18),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_3),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_7),
.B(n_2),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_12),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_20),
.B(n_26),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_24),
.B(n_5),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_26),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_22),
.Y(n_33)
);

OAI21x1_ASAP7_75t_SL g34 ( 
.A1(n_29),
.A2(n_16),
.B(n_5),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_16),
.Y(n_35)
);

INVx4_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

INVxp67_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVx1_ASAP7_75t_SL g39 ( 
.A(n_37),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_32),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

NOR4xp25_ASAP7_75t_SL g42 ( 
.A(n_41),
.B(n_38),
.C(n_34),
.D(n_36),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

NOR2x1_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_23),
.Y(n_45)
);

INVx1_ASAP7_75t_SL g46 ( 
.A(n_43),
.Y(n_46)
);

NAND4xp75_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_19),
.C(n_23),
.D(n_25),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_42),
.Y(n_48)
);

NAND5xp2_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_27),
.C(n_18),
.D(n_17),
.E(n_28),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_46),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_30),
.Y(n_52)
);

OAI222xp33_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_30),
.B1(n_8),
.B2(n_1),
.C1(n_10),
.C2(n_4),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

AOI322xp5_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_49),
.A3(n_55),
.B1(n_53),
.B2(n_52),
.C1(n_13),
.C2(n_15),
.Y(n_56)
);


endmodule