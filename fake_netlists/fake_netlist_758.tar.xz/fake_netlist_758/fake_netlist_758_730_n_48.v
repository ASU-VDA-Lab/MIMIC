module fake_netlist_758_730_n_48 (n_12, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_48);

input n_12;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_48;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_15;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

NAND2xp33_ASAP7_75t_SL g15 ( 
.A(n_1),
.B(n_6),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_3),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_14),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_SL g24 ( 
.A(n_15),
.B(n_18),
.C(n_20),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_25)
);

NAND2xp33_ASAP7_75t_SL g26 ( 
.A(n_22),
.B(n_0),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_22),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_21),
.B1(n_17),
.B2(n_19),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_25),
.B1(n_28),
.B2(n_27),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_17),
.B(n_21),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_16),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_23),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_30),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

NOR3xp33_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_33),
.C(n_36),
.Y(n_46)
);

CKINVDCx20_ASAP7_75t_R g47 ( 
.A(n_45),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_46),
.A3(n_42),
.B1(n_45),
.B2(n_7),
.C1(n_10),
.C2(n_13),
.Y(n_48)
);


endmodule