module fake_netlist_758_1287_n_47 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_47);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_47;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_20),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_2),
.B(n_15),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_0),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_6),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_12),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_1),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_7),
.Y(n_30)
);

BUFx12f_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_22),
.B(n_19),
.C(n_3),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_30),
.B(n_4),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_30),
.B(n_29),
.Y(n_34)
);

INVx4_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_32),
.B1(n_28),
.B2(n_26),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_34),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_27),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

OAI221xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_25),
.B1(n_24),
.B2(n_5),
.C(n_8),
.Y(n_41)
);

NOR3xp33_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_11),
.C(n_9),
.Y(n_42)
);

NAND2xp33_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_13),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

OR2x6_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_14),
.Y(n_46)
);

OAI22xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_45),
.B1(n_21),
.B2(n_18),
.Y(n_47)
);


endmodule