module fake_netlist_758_1744_n_31 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_31);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_31;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_30;
wire n_25;
wire n_21;
wire n_19;
wire n_29;

INVx1_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

INVxp33_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_17),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_8),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_20),
.B(n_13),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_22),
.B(n_14),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_19),
.C(n_18),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_21),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

OAI21xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_24),
.B(n_0),
.Y(n_28)
);

AND3x4_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_2),
.C(n_1),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_10),
.B1(n_9),
.B2(n_12),
.C1(n_16),
.C2(n_15),
.Y(n_31)
);


endmodule