module fake_netlist_758_2102_n_34 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_34);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_34;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_13),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_16),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_1),
.B(n_0),
.Y(n_24)
);

AND3x1_ASAP7_75t_SL g25 ( 
.A(n_20),
.B(n_14),
.C(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_19),
.B1(n_21),
.B2(n_22),
.Y(n_27)
);

AO31x2_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_14),
.A3(n_23),
.B(n_22),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_27),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_25),
.B(n_28),
.C(n_3),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

AO22x2_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_34)
);


endmodule