module fake_netlist_758_1681_n_20 (n_0, n_2, n_1, n_3, n_20);

input n_0;
input n_2;
input n_1;
input n_3;

output n_20;

wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_4;
wire n_7;
wire n_17;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

AOI22xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

NAND3xp33_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_1),
.C(n_0),
.Y(n_6)
);

O2A1O1Ixp5_ASAP7_75t_SL g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_3),
.C(n_2),
.Y(n_7)
);

INVxp67_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NAND2x1p5_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_2),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_9),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_7),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_7),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_11),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B1(n_12),
.B2(n_8),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_12),
.B(n_8),
.C(n_4),
.Y(n_15)
);

NOR4xp75_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_12),
.C(n_13),
.D(n_15),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_SL g17 ( 
.A(n_15),
.B(n_12),
.C(n_13),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

AOI21xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_13),
.B(n_12),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_12),
.B1(n_13),
.B2(n_19),
.Y(n_20)
);


endmodule