module fake_netlist_758_1633_n_18 (n_0, n_2, n_1, n_3, n_18);

input n_0;
input n_2;
input n_1;
input n_3;

output n_18;

wire n_12;
wire n_15;
wire n_14;
wire n_11;
wire n_9;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_13;
wire n_17;
wire n_16;
wire n_6;
wire n_8;

AO22x2_ASAP7_75t_L g4 ( 
.A1(n_1),
.A2(n_2),
.B1(n_3),
.B2(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

NOR4xp25_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_2),
.C(n_1),
.D(n_0),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_6),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_4),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_4),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_7),
.B1(n_10),
.B2(n_9),
.C(n_0),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_7),
.B(n_9),
.C(n_0),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_1),
.Y(n_15)
);

XNOR2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.C(n_3),
.Y(n_18)
);


endmodule