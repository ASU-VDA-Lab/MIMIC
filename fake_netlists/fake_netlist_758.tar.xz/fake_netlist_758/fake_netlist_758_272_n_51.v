module fake_netlist_758_272_n_51 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_51);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_51;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_16),
.A2(n_1),
.B1(n_10),
.B2(n_18),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_13),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_19),
.B(n_3),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_6),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_14),
.B(n_0),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_28),
.B(n_15),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_24),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_30),
.Y(n_34)
);

OA21x2_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_20),
.B(n_33),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_35),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_37),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_35),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_24),
.B1(n_32),
.B2(n_26),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_25),
.B1(n_21),
.B2(n_23),
.Y(n_41)
);

AOI322xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_27),
.A3(n_23),
.B1(n_29),
.B2(n_39),
.C1(n_17),
.C2(n_19),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_39),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_29),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_42),
.Y(n_45)
);

BUFx12f_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

NAND3xp33_ASAP7_75t_SL g47 ( 
.A(n_42),
.B(n_22),
.C(n_4),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_22),
.Y(n_48)
);

AO21x2_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_22),
.B(n_7),
.Y(n_49)
);

NOR3xp33_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_47),
.C(n_46),
.Y(n_50)
);

OAI221xp5_ASAP7_75t_R g51 ( 
.A1(n_50),
.A2(n_49),
.B1(n_48),
.B2(n_8),
.C(n_9),
.Y(n_51)
);


endmodule