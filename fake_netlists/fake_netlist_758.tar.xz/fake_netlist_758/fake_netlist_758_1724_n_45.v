module fake_netlist_758_1724_n_45 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_45);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_45;

wire n_23;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_37;
wire n_27;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_3),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_7),
.Y(n_29)
);

O2A1O1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_19),
.B(n_18),
.C(n_0),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_SL g31 ( 
.A(n_25),
.B(n_19),
.C(n_1),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_2),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_22),
.Y(n_36)
);

AOI21xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_30),
.B(n_21),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_28),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

O2A1O1Ixp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_27),
.B(n_26),
.C(n_23),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_28),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_29),
.B1(n_5),
.B2(n_4),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_9),
.B1(n_8),
.B2(n_6),
.Y(n_44)
);

AOI222xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_44),
.B1(n_17),
.B2(n_10),
.C1(n_20),
.C2(n_13),
.Y(n_45)
);


endmodule