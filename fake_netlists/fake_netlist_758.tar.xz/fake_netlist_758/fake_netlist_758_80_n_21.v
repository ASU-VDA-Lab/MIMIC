module fake_netlist_758_80_n_21 (n_0, n_2, n_1, n_3, n_21);

input n_0;
input n_2;
input n_1;
input n_3;

output n_21;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_4;
wire n_7;
wire n_17;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

NAND4xp25_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_4),
.C(n_10),
.D(n_2),
.Y(n_14)
);

AOI31xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_12),
.A3(n_11),
.B(n_4),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_2),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_0),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_16),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_1),
.B(n_3),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_3),
.B1(n_18),
.B2(n_19),
.Y(n_21)
);


endmodule