module fake_netlist_758_419_n_24 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_8, n_24);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_24;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_9;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_SL g13 ( 
.A(n_6),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_3),
.B(n_0),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_SL g15 ( 
.A1(n_11),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_9),
.B2(n_13),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_10),
.Y(n_17)
);

AOI21xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_9),
.B(n_13),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_17),
.C(n_10),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_19),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_14),
.B1(n_4),
.B2(n_1),
.Y(n_22)
);

OAI22x1_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_5),
.B1(n_7),
.B2(n_16),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_5),
.B1(n_20),
.B2(n_22),
.Y(n_24)
);


endmodule