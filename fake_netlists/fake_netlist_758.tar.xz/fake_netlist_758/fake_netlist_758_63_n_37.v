module fake_netlist_758_63_n_37 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_37);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_37;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_21;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_18),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_3),
.B(n_12),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_4),
.B(n_7),
.Y(n_23)
);

INVx2_ASAP7_75t_SL g24 ( 
.A(n_10),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_18),
.B(n_11),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_16),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_27),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_21),
.B1(n_25),
.B2(n_23),
.Y(n_29)
);

OR2x6_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_16),
.Y(n_30)
);

OAI32xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.A3(n_20),
.B1(n_22),
.B2(n_19),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_19),
.B1(n_1),
.B2(n_0),
.Y(n_32)
);

CKINVDCx16_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_6),
.B(n_5),
.C(n_2),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_33),
.Y(n_35)
);

AOI211xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_13),
.B(n_9),
.C(n_8),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_35),
.A2(n_36),
.B1(n_17),
.B2(n_15),
.Y(n_37)
);


endmodule