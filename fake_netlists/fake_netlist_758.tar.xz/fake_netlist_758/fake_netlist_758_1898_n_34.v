module fake_netlist_758_1898_n_34 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_34);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_34;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_4),
.Y(n_12)
);

CKINVDCx6p67_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_SL g14 ( 
.A(n_4),
.B(n_6),
.Y(n_14)
);

AND3x2_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_7),
.C(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_5),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_11),
.B(n_6),
.C(n_3),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_10),
.B(n_9),
.C(n_8),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_19),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_21),
.B(n_12),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_13),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_18),
.B(n_15),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_25),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_23),
.C(n_20),
.Y(n_28)
);

AOI322xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_13),
.A3(n_16),
.B1(n_17),
.B2(n_24),
.C1(n_22),
.C2(n_14),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_28),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

OAI31xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_17),
.A3(n_31),
.B(n_32),
.Y(n_34)
);


endmodule