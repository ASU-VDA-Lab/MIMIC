module fake_netlist_758_1980_n_45 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_45);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_45;

wire n_20;
wire n_23;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

NAND2xp33_ASAP7_75t_R g20 ( 
.A(n_7),
.B(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_4),
.B(n_6),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_13),
.B(n_10),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_19),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_5),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_8),
.B(n_11),
.Y(n_28)
);

NOR2xp67_ASAP7_75t_L g29 ( 
.A(n_21),
.B(n_17),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_SL g31 ( 
.A(n_24),
.B(n_18),
.C(n_17),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

AO22x1_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_26),
.B1(n_31),
.B2(n_24),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_32),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_34),
.B(n_22),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_27),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_27),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

OR5x1_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_18),
.C(n_20),
.D(n_28),
.E(n_23),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_SL g43 ( 
.A1(n_40),
.A2(n_9),
.B(n_3),
.C(n_0),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

OAI31xp33_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_42),
.A3(n_14),
.B(n_12),
.Y(n_45)
);


endmodule