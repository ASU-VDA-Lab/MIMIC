module fake_netlist_758_1037_n_36 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_36);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_36;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_34;
wire n_13;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_2),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_12),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx5_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_14),
.B1(n_19),
.B2(n_20),
.Y(n_23)
);

AOI33xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_19),
.A3(n_14),
.B1(n_21),
.B2(n_1),
.B3(n_0),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_21),
.B1(n_16),
.B2(n_20),
.C(n_0),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_20),
.Y(n_26)
);

INVx4_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI322xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_28),
.A3(n_27),
.B1(n_25),
.B2(n_2),
.C1(n_1),
.C2(n_4),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_27),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_6),
.C(n_5),
.Y(n_34)
);

AO22x2_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_31),
.B1(n_7),
.B2(n_5),
.Y(n_35)
);

AOI322xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_3),
.A3(n_7),
.B1(n_10),
.B2(n_33),
.C1(n_14),
.C2(n_34),
.Y(n_36)
);


endmodule