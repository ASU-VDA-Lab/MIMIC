module fake_netlist_758_1258_n_30 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_30);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_30;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_16;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_29;

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_8),
.B(n_7),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_12),
.B(n_13),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_17),
.B(n_18),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_21),
.Y(n_24)
);

AND2x4_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

OAI322xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_6),
.A3(n_16),
.B1(n_20),
.B2(n_3),
.C1(n_1),
.C2(n_4),
.Y(n_26)
);

O2A1O1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_6),
.B(n_9),
.C(n_5),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AO22x2_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_15),
.B1(n_14),
.B2(n_11),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);


endmodule