module fake_netlist_758_1553_n_65 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_65);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_65;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_64;
wire n_22;
wire n_62;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_42;
wire n_37;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_63;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_4),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_11),
.B(n_19),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_16),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_14),
.B(n_17),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_SL g31 ( 
.A1(n_21),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_27),
.B(n_0),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_22),
.B(n_2),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

OAI21xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_24),
.B(n_23),
.Y(n_36)
);

A2O1A1Ixp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_23),
.B(n_28),
.C(n_25),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_32),
.A2(n_24),
.B(n_33),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_36),
.B(n_23),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_39),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_39),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_SL g46 ( 
.A1(n_45),
.A2(n_30),
.B1(n_42),
.B2(n_31),
.C(n_37),
.Y(n_46)
);

OAI211xp5_ASAP7_75t_SL g47 ( 
.A1(n_43),
.A2(n_31),
.B(n_28),
.C(n_25),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_42),
.B1(n_40),
.B2(n_29),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_43),
.Y(n_50)
);

OAI211xp5_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_42),
.B(n_20),
.C(n_38),
.Y(n_51)
);

XNOR2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_3),
.Y(n_52)
);

OAI321xp33_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_38),
.A3(n_40),
.B1(n_9),
.B2(n_8),
.C(n_7),
.Y(n_53)
);

OAI21xp5_ASAP7_75t_L g54 ( 
.A1(n_49),
.A2(n_20),
.B(n_7),
.Y(n_54)
);

INVxp67_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

NAND3xp33_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_9),
.C(n_8),
.Y(n_56)
);

OAI21xp33_ASAP7_75t_SL g57 ( 
.A1(n_50),
.A2(n_12),
.B(n_11),
.Y(n_57)
);

AND4x1_ASAP7_75t_L g58 ( 
.A(n_50),
.B(n_17),
.C(n_15),
.D(n_12),
.Y(n_58)
);

NAND4xp25_ASAP7_75t_L g59 ( 
.A(n_51),
.B(n_19),
.C(n_18),
.D(n_15),
.Y(n_59)
);

NOR2xp33_ASAP7_75t_L g60 ( 
.A(n_55),
.B(n_53),
.Y(n_60)
);

AO22x2_ASAP7_75t_L g61 ( 
.A1(n_56),
.A2(n_58),
.B1(n_59),
.B2(n_57),
.Y(n_61)
);

AOI21x1_ASAP7_75t_L g62 ( 
.A1(n_56),
.A2(n_18),
.B(n_5),
.Y(n_62)
);

INVxp67_ASAP7_75t_L g63 ( 
.A(n_59),
.Y(n_63)
);

INVx3_ASAP7_75t_SL g64 ( 
.A(n_61),
.Y(n_64)
);

AOI22xp33_ASAP7_75t_SL g65 ( 
.A1(n_64),
.A2(n_60),
.B1(n_63),
.B2(n_62),
.Y(n_65)
);


endmodule