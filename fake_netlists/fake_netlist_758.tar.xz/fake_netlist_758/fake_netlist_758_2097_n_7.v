module fake_netlist_758_2097_n_7 (n_1, n_2, n_3, n_4, n_0, n_7);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_7;

wire n_5;
wire n_6;

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AOI221xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_2),
.B2(n_4),
.C(n_6),
.Y(n_7)
);


endmodule