module fake_netlist_746_3268_n_38 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_38);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_38;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_16;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx8_ASAP7_75t_R g11 ( 
.A(n_10),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_7),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_1),
.B(n_5),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_6),
.B(n_5),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_0),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_1),
.B(n_0),
.Y(n_20)
);

OR2x6_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_2),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_18),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_11),
.A2(n_4),
.B1(n_7),
.B2(n_12),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_17),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_21),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_26),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_24),
.B(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_28),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_29),
.B1(n_30),
.B2(n_34),
.C(n_33),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_35),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_31),
.B1(n_11),
.B2(n_12),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_16),
.B1(n_31),
.B2(n_20),
.Y(n_38)
);


endmodule