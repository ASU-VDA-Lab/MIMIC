module fake_netlist_746_1818_n_13 (n_0, n_2, n_1, n_13);

input n_0;
input n_2;
input n_1;

output n_13;

wire n_12;
wire n_3;
wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_5),
.Y(n_8)
);

NOR2x1p5_ASAP7_75t_SL g9 ( 
.A(n_7),
.B(n_6),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_8),
.B(n_5),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_5),
.B(n_1),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_11),
.Y(n_13)
);


endmodule