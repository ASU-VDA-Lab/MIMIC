module fake_netlist_746_1605_n_26 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_26);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_24;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

INVx2_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

BUFx10_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_4),
.B(n_7),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_3),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_10),
.B(n_2),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_14),
.B(n_16),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_7),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

NOR4xp25_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_20),
.C(n_18),
.D(n_1),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_9),
.B1(n_8),
.B2(n_5),
.Y(n_24)
);

AO21x2_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_12),
.B(n_11),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_13),
.Y(n_26)
);


endmodule