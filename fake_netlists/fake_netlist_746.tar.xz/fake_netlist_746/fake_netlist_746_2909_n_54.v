module fake_netlist_746_2909_n_54 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_54);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_54;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_42;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_52;
wire n_32;

INVx1_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

AND2x2_ASAP7_75t_SL g19 ( 
.A(n_8),
.B(n_7),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_5),
.B(n_10),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_2),
.Y(n_25)
);

AND2x6_ASAP7_75t_L g26 ( 
.A(n_5),
.B(n_6),
.Y(n_26)
);

BUFx8_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_21),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_19),
.A2(n_17),
.B1(n_16),
.B2(n_4),
.Y(n_30)
);

INVx4_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_20),
.B(n_21),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_24),
.B(n_18),
.C(n_19),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_25),
.B1(n_23),
.B2(n_22),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_29),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

NOR2x1_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_34),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_31),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_25),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_31),
.Y(n_43)
);

NAND3x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_39),
.C(n_27),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_28),
.B(n_23),
.Y(n_45)
);

INVx2_ASAP7_75t_SL g46 ( 
.A(n_41),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_R g47 ( 
.A1(n_46),
.A2(n_28),
.B1(n_17),
.B2(n_4),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_45),
.Y(n_48)
);

NOR2x1_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_23),
.Y(n_49)
);

NAND4xp25_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_27),
.C(n_26),
.D(n_0),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

OAI222xp33_ASAP7_75t_L g53 ( 
.A1(n_47),
.A2(n_3),
.B1(n_12),
.B2(n_14),
.C1(n_26),
.C2(n_50),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_26),
.B1(n_52),
.B2(n_53),
.Y(n_54)
);


endmodule