module fake_netlist_746_1399_n_17 (n_0, n_2, n_1, n_3, n_17);

input n_0;
input n_2;
input n_1;
input n_3;

output n_17;

wire n_12;
wire n_15;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_13;
wire n_16;
wire n_6;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_0),
.Y(n_6)
);

AO21x2_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_4),
.B(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_8),
.Y(n_9)
);

OAI322xp33_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_6),
.A3(n_5),
.B1(n_2),
.B2(n_3),
.C1(n_0),
.C2(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_5),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_7),
.B(n_0),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_SL g13 ( 
.A1(n_11),
.A2(n_10),
.B(n_7),
.C(n_1),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_7),
.B(n_10),
.Y(n_14)
);

OR3x1_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_3),
.C(n_2),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_2),
.B1(n_3),
.B2(n_14),
.C1(n_13),
.C2(n_16),
.Y(n_17)
);


endmodule