module fake_netlist_746_800_n_27 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_27);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_27;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_24;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_13),
.B(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_7),
.B(n_3),
.Y(n_18)
);

NAND2x1p5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_3),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_4),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI32xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.A3(n_20),
.B1(n_16),
.B2(n_17),
.Y(n_23)
);

AOI321xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_22),
.A3(n_19),
.B1(n_6),
.B2(n_5),
.C(n_14),
.Y(n_24)
);

XNOR2x1_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_5),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AOI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_8),
.B1(n_0),
.B2(n_10),
.C1(n_12),
.C2(n_11),
.Y(n_27)
);


endmodule