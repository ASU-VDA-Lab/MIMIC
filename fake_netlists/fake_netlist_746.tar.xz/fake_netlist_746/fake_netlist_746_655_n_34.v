module fake_netlist_746_655_n_34 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_34);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_34;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_2),
.B(n_0),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_18)
);

NAND2x1p5_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_4),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_5),
.Y(n_21)
);

AO31x2_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_16),
.A3(n_17),
.B(n_5),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

AOI32xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_15),
.A3(n_20),
.B1(n_19),
.B2(n_23),
.Y(n_27)
);

OAI211xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_20),
.B(n_25),
.C(n_19),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_6),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_31),
.A2(n_16),
.B1(n_7),
.B2(n_9),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_10),
.B1(n_11),
.B2(n_32),
.Y(n_34)
);


endmodule