module fake_netlist_746_185_n_28 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_28);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_28;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;

OA21x2_ASAP7_75t_L g10 ( 
.A1(n_3),
.A2(n_2),
.B(n_4),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B1(n_12),
.B2(n_10),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_15),
.C(n_11),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_11),
.B1(n_15),
.B2(n_14),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_19),
.B(n_0),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_5),
.C(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_1),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AOI322xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_5),
.A3(n_6),
.B1(n_7),
.B2(n_9),
.C1(n_25),
.C2(n_27),
.Y(n_28)
);


endmodule