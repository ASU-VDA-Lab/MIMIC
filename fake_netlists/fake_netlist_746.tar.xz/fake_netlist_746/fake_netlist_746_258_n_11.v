module fake_netlist_746_258_n_11 (n_0, n_2, n_1, n_3, n_11);

input n_0;
input n_2;
input n_1;
input n_3;

output n_11;

wire n_9;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

OA21x2_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_3),
.B(n_0),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

AOI221xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B1(n_5),
.B2(n_0),
.C(n_1),
.Y(n_9)
);

NAND3x1_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_5),
.C(n_4),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);


endmodule