module fake_netlist_746_496_n_26 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_26);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_24;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

AND2x6_ASAP7_75t_L g17 ( 
.A(n_4),
.B(n_11),
.Y(n_17)
);

INVxp67_ASAP7_75t_SL g18 ( 
.A(n_2),
.Y(n_18)
);

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_1),
.B(n_0),
.Y(n_19)
);

AOI221x1_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_14),
.B1(n_16),
.B2(n_15),
.C(n_18),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.B(n_3),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_17),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B(n_17),
.C(n_4),
.Y(n_23)
);

NAND5xp2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.C(n_6),
.D(n_5),
.E(n_19),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_7),
.B1(n_6),
.B2(n_10),
.Y(n_26)
);


endmodule