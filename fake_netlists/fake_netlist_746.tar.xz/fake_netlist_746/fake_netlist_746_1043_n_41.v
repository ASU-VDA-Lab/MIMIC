module fake_netlist_746_1043_n_41 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_41);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_41;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_5),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_1),
.B(n_2),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

AND2x6_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_8),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_16),
.B1(n_14),
.B2(n_17),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_23),
.Y(n_26)
);

INVx2_ASAP7_75t_SL g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_23),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NOR4xp25_ASAP7_75t_SL g31 ( 
.A(n_28),
.B(n_19),
.C(n_27),
.D(n_4),
.Y(n_31)
);

NAND4xp25_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_18),
.C(n_21),
.D(n_28),
.Y(n_32)
);

OAI221xp5_ASAP7_75t_SL g33 ( 
.A1(n_31),
.A2(n_27),
.B1(n_16),
.B2(n_4),
.C(n_6),
.Y(n_33)
);

AOI221x1_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_15),
.B1(n_7),
.B2(n_6),
.C(n_9),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_32),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

CKINVDCx16_ASAP7_75t_R g37 ( 
.A(n_34),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

XNOR2xp5_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_11),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_12),
.B1(n_15),
.B2(n_37),
.C1(n_38),
.C2(n_39),
.Y(n_41)
);


endmodule