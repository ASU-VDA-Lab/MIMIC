module fake_netlist_746_1449_n_26 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_26);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_24;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

INVx2_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_8),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_11),
.Y(n_18)
);

AOI21x1_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_3),
.B(n_0),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_17),
.C(n_15),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B1(n_18),
.B2(n_0),
.Y(n_21)
);

NOR2x1_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

AOI222xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_4),
.B1(n_1),
.B2(n_5),
.C1(n_7),
.C2(n_6),
.Y(n_23)
);

A2O1A1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_6),
.B(n_4),
.C(n_1),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OA21x2_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_7),
.B(n_19),
.Y(n_26)
);


endmodule