module fake_netlist_746_1094_n_16 (n_0, n_2, n_1, n_3, n_16);

input n_0;
input n_2;
input n_1;
input n_3;

output n_16;

wire n_12;
wire n_15;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

AOI22xp33_ASAP7_75t_L g4 ( 
.A1(n_0),
.A2(n_2),
.B1(n_3),
.B2(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_1),
.Y(n_9)
);

NOR2x1_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_0),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_SL g11 ( 
.A1(n_8),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.C(n_9),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_9),
.B(n_3),
.C(n_2),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_9),
.B1(n_8),
.B2(n_6),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AO21x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_9),
.B(n_14),
.Y(n_16)
);


endmodule