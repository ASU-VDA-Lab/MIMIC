module fake_netlist_746_383_n_25 (n_1, n_2, n_3, n_4, n_5, n_0, n_25);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_25;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_24;
wire n_10;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;
wire n_8;

BUFx4f_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_3),
.B(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_4),
.Y(n_11)
);

NOR2xp67_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_11),
.Y(n_12)
);

OAI21x1_ASAP7_75t_SL g13 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

AND2x6_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_1),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_6),
.A2(n_1),
.B1(n_4),
.B2(n_3),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_7),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_8),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

NAND4xp25_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_15),
.C(n_10),
.D(n_9),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_16),
.B1(n_13),
.B2(n_6),
.Y(n_22)
);

AO22x2_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_11),
.B1(n_6),
.B2(n_16),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_14),
.Y(n_24)
);

XOR2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_24),
.Y(n_25)
);


endmodule