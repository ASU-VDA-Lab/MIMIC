module fake_netlist_746_2080_n_24 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_24);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_24;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_2),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_3),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_5),
.B(n_7),
.Y(n_15)
);

OA22x2_ASAP7_75t_L g16 ( 
.A1(n_4),
.A2(n_0),
.B1(n_8),
.B2(n_7),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_11),
.B(n_4),
.Y(n_17)
);

NAND2x1_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_SL g19 ( 
.A(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_15),
.B(n_17),
.C(n_19),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_16),
.B(n_1),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_6),
.B1(n_12),
.B2(n_10),
.Y(n_24)
);


endmodule