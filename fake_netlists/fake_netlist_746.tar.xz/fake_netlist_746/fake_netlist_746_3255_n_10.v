module fake_netlist_746_3255_n_10 (n_0, n_2, n_1, n_10);

input n_0;
input n_2;
input n_1;

output n_10;

wire n_3;
wire n_9;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

AND2x4_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_SL g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

A2O1A1Ixp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_5),
.B(n_2),
.C(n_0),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_6),
.B(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule