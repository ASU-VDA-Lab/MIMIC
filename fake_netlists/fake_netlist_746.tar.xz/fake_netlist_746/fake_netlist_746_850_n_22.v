module fake_netlist_746_850_n_22 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_22);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_22;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_7),
.Y(n_16)
);

AO21x2_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_2),
.B(n_0),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_15),
.B1(n_12),
.B2(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI32xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.A3(n_10),
.B1(n_5),
.B2(n_6),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_11),
.Y(n_22)
);


endmodule