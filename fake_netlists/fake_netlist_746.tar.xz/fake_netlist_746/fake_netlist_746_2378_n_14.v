module fake_netlist_746_2378_n_14 (n_0, n_2, n_1, n_14);

input n_0;
input n_2;
input n_1;

output n_14;

wire n_12;
wire n_3;
wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

BUFx6f_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

INVx1_ASAP7_75t_SL g4 ( 
.A(n_1),
.Y(n_4)
);

OAI21x1_ASAP7_75t_SL g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_3),
.Y(n_7)
);

NOR2x1_ASAP7_75t_SL g8 ( 
.A(n_5),
.B(n_3),
.Y(n_8)
);

INVxp67_ASAP7_75t_SL g9 ( 
.A(n_7),
.Y(n_9)
);

OAI211xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_3),
.C(n_8),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AOI21xp33_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_2),
.B(n_13),
.Y(n_14)
);


endmodule