module fake_netlist_785_1944_n_10 (n_1, n_0, n_10);

input n_1;
input n_0;

output n_10;

wire n_7;
wire n_5;
wire n_6;
wire n_3;
wire n_9;
wire n_2;
wire n_4;
wire n_8;

INVx3_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

INVx1_ASAP7_75t_SL g3 ( 
.A(n_0),
.Y(n_3)
);

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_2),
.Y(n_4)
);

AOI22xp33_ASAP7_75t_SL g5 ( 
.A1(n_3),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_3),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_SL g8 ( 
.A1(n_7),
.A2(n_2),
.B1(n_6),
.B2(n_5),
.C(n_1),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B1(n_2),
.B2(n_0),
.Y(n_9)
);

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_1),
.B1(n_6),
.B2(n_8),
.Y(n_10)
);


endmodule