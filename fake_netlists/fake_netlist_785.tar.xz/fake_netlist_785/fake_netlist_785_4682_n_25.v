module fake_netlist_785_4682_n_25 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_25);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_25;

wire n_20;
wire n_17;
wire n_12;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_2),
.B(n_6),
.Y(n_12)
);

OA21x2_ASAP7_75t_L g13 ( 
.A1(n_3),
.A2(n_7),
.B(n_1),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_10),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_SL g16 ( 
.A(n_12),
.B(n_5),
.C(n_4),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_4),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND4xp25_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.C(n_11),
.D(n_16),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_15),
.B(n_6),
.C(n_5),
.Y(n_22)
);

BUFx4f_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI322xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_0),
.A3(n_8),
.B1(n_13),
.B2(n_21),
.C1(n_14),
.C2(n_17),
.Y(n_25)
);


endmodule