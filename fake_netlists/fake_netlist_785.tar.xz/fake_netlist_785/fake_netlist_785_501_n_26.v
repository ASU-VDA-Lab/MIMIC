module fake_netlist_785_501_n_26 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_26);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_26;

wire n_20;
wire n_17;
wire n_12;
wire n_25;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

BUFx12f_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_1),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_9),
.B(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_11),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_11),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_7),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_SL g19 ( 
.A(n_17),
.B(n_15),
.Y(n_19)
);

AOI321xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_8),
.A3(n_16),
.B1(n_13),
.B2(n_11),
.C(n_1),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_8),
.B1(n_3),
.B2(n_0),
.C(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_20),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_19),
.B1(n_4),
.B2(n_0),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_4),
.B1(n_6),
.B2(n_22),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_6),
.B1(n_23),
.B2(n_25),
.Y(n_26)
);


endmodule