module fake_netlist_785_4400_n_14 (n_1, n_0, n_3, n_2, n_4, n_14);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_14;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_9;
wire n_12;
wire n_13;
wire n_8;

CKINVDCx20_ASAP7_75t_R g5 ( 
.A(n_0),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_6),
.Y(n_7)
);

OAI22xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_5),
.B1(n_2),
.B2(n_1),
.Y(n_8)
);

INVxp67_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NOR3xp33_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_4),
.C(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);


endmodule