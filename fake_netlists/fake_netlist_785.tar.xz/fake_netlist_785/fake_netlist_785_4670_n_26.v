module fake_netlist_785_4670_n_26 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_26);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_26;

wire n_20;
wire n_17;
wire n_12;
wire n_25;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_23;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

AND3x2_ASAP7_75t_L g14 ( 
.A(n_3),
.B(n_7),
.C(n_5),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_0),
.Y(n_15)
);

NOR2x1_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_14),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_12),
.B(n_0),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_SL g19 ( 
.A(n_15),
.B(n_13),
.C(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_19),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_17),
.C(n_14),
.D(n_21),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

OAI22x1_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_9),
.B1(n_8),
.B2(n_6),
.Y(n_26)
);


endmodule