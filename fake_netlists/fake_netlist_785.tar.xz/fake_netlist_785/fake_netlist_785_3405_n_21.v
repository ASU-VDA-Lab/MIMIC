module fake_netlist_785_3405_n_21 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_21);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_21;

wire n_20;
wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_19;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_7),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_10),
.B(n_0),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_3),
.Y(n_14)
);

OR2x2_ASAP7_75t_SL g15 ( 
.A(n_13),
.B(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_12),
.B1(n_4),
.B2(n_1),
.C(n_2),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_1),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_5),
.B1(n_9),
.B2(n_8),
.Y(n_21)
);


endmodule