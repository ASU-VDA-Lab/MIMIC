module fake_netlist_785_4644_n_213 (n_37, n_45, n_0, n_44, n_55, n_64, n_20, n_6, n_47, n_52, n_29, n_36, n_63, n_17, n_62, n_2, n_12, n_65, n_50, n_58, n_1, n_35, n_25, n_31, n_40, n_5, n_66, n_27, n_34, n_39, n_46, n_33, n_24, n_26, n_42, n_18, n_13, n_48, n_43, n_49, n_15, n_56, n_11, n_16, n_38, n_54, n_61, n_60, n_23, n_57, n_28, n_4, n_9, n_8, n_30, n_7, n_10, n_19, n_59, n_53, n_21, n_3, n_41, n_51, n_32, n_22, n_14, n_213);

input n_37;
input n_45;
input n_0;
input n_44;
input n_55;
input n_64;
input n_20;
input n_6;
input n_47;
input n_52;
input n_29;
input n_36;
input n_63;
input n_17;
input n_62;
input n_2;
input n_12;
input n_65;
input n_50;
input n_58;
input n_1;
input n_35;
input n_25;
input n_31;
input n_40;
input n_5;
input n_66;
input n_27;
input n_34;
input n_39;
input n_46;
input n_33;
input n_24;
input n_26;
input n_42;
input n_18;
input n_13;
input n_48;
input n_43;
input n_49;
input n_15;
input n_56;
input n_11;
input n_16;
input n_38;
input n_54;
input n_61;
input n_60;
input n_23;
input n_57;
input n_28;
input n_4;
input n_9;
input n_8;
input n_30;
input n_7;
input n_10;
input n_19;
input n_59;
input n_53;
input n_21;
input n_3;
input n_41;
input n_51;
input n_32;
input n_22;
input n_14;

output n_213;

wire n_183;
wire n_116;
wire n_140;
wire n_153;
wire n_100;
wire n_73;
wire n_119;
wire n_101;
wire n_105;
wire n_124;
wire n_186;
wire n_187;
wire n_107;
wire n_158;
wire n_68;
wire n_67;
wire n_184;
wire n_179;
wire n_127;
wire n_132;
wire n_166;
wire n_210;
wire n_197;
wire n_79;
wire n_181;
wire n_74;
wire n_104;
wire n_146;
wire n_85;
wire n_182;
wire n_89;
wire n_106;
wire n_168;
wire n_178;
wire n_207;
wire n_143;
wire n_102;
wire n_83;
wire n_201;
wire n_75;
wire n_165;
wire n_117;
wire n_121;
wire n_96;
wire n_169;
wire n_180;
wire n_185;
wire n_76;
wire n_174;
wire n_199;
wire n_204;
wire n_148;
wire n_175;
wire n_128;
wire n_202;
wire n_88;
wire n_171;
wire n_84;
wire n_195;
wire n_155;
wire n_156;
wire n_152;
wire n_90;
wire n_126;
wire n_103;
wire n_139;
wire n_147;
wire n_151;
wire n_164;
wire n_82;
wire n_86;
wire n_129;
wire n_123;
wire n_196;
wire n_150;
wire n_177;
wire n_198;
wire n_176;
wire n_188;
wire n_167;
wire n_92;
wire n_189;
wire n_91;
wire n_70;
wire n_125;
wire n_69;
wire n_137;
wire n_71;
wire n_209;
wire n_212;
wire n_145;
wire n_133;
wire n_194;
wire n_142;
wire n_109;
wire n_122;
wire n_78;
wire n_112;
wire n_161;
wire n_157;
wire n_190;
wire n_110;
wire n_203;
wire n_118;
wire n_111;
wire n_149;
wire n_170;
wire n_200;
wire n_205;
wire n_163;
wire n_172;
wire n_159;
wire n_77;
wire n_138;
wire n_130;
wire n_160;
wire n_206;
wire n_108;
wire n_162;
wire n_97;
wire n_173;
wire n_94;
wire n_141;
wire n_211;
wire n_154;
wire n_136;
wire n_193;
wire n_135;
wire n_144;
wire n_113;
wire n_114;
wire n_81;
wire n_95;
wire n_98;
wire n_80;
wire n_99;
wire n_192;
wire n_87;
wire n_191;
wire n_115;
wire n_120;
wire n_208;
wire n_134;
wire n_93;
wire n_131;
wire n_72;

NOR2xp67_ASAP7_75t_L g67 ( 
.A(n_66),
.B(n_61),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_28),
.Y(n_68)
);

BUFx3_ASAP7_75t_L g69 ( 
.A(n_7),
.Y(n_69)
);

INVx1_ASAP7_75t_SL g70 ( 
.A(n_53),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_58),
.Y(n_71)
);

BUFx6f_ASAP7_75t_L g72 ( 
.A(n_5),
.Y(n_72)
);

XOR2xp5_ASAP7_75t_L g73 ( 
.A(n_27),
.B(n_39),
.Y(n_73)
);

CKINVDCx5p33_ASAP7_75t_R g74 ( 
.A(n_8),
.Y(n_74)
);

INVx2_ASAP7_75t_L g75 ( 
.A(n_54),
.Y(n_75)
);

BUFx3_ASAP7_75t_L g76 ( 
.A(n_55),
.Y(n_76)
);

INVx3_ASAP7_75t_L g77 ( 
.A(n_65),
.Y(n_77)
);

INVx3_ASAP7_75t_L g78 ( 
.A(n_57),
.Y(n_78)
);

INVx2_ASAP7_75t_L g79 ( 
.A(n_64),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_2),
.Y(n_80)
);

NOR2xp67_ASAP7_75t_L g81 ( 
.A(n_45),
.B(n_59),
.Y(n_81)
);

INVxp67_ASAP7_75t_SL g82 ( 
.A(n_35),
.Y(n_82)
);

CKINVDCx16_ASAP7_75t_R g83 ( 
.A(n_56),
.Y(n_83)
);

CKINVDCx16_ASAP7_75t_R g84 ( 
.A(n_31),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_3),
.Y(n_85)
);

BUFx5_ASAP7_75t_L g86 ( 
.A(n_30),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_15),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_24),
.Y(n_88)
);

NAND2xp5_ASAP7_75t_L g89 ( 
.A(n_12),
.B(n_20),
.Y(n_89)
);

BUFx5_ASAP7_75t_L g90 ( 
.A(n_60),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_43),
.Y(n_91)
);

BUFx6f_ASAP7_75t_L g92 ( 
.A(n_18),
.Y(n_92)
);

CKINVDCx5p33_ASAP7_75t_R g93 ( 
.A(n_52),
.Y(n_93)
);

BUFx3_ASAP7_75t_L g94 ( 
.A(n_26),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_33),
.Y(n_95)
);

BUFx5_ASAP7_75t_L g96 ( 
.A(n_42),
.Y(n_96)
);

CKINVDCx5p33_ASAP7_75t_R g97 ( 
.A(n_29),
.Y(n_97)
);

CKINVDCx5p33_ASAP7_75t_R g98 ( 
.A(n_34),
.Y(n_98)
);

NOR2xp67_ASAP7_75t_L g99 ( 
.A(n_21),
.B(n_62),
.Y(n_99)
);

CKINVDCx5p33_ASAP7_75t_R g100 ( 
.A(n_41),
.Y(n_100)
);

CKINVDCx5p33_ASAP7_75t_R g101 ( 
.A(n_4),
.Y(n_101)
);

CKINVDCx5p33_ASAP7_75t_R g102 ( 
.A(n_63),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_68),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_80),
.Y(n_104)
);

INVx2_ASAP7_75t_L g105 ( 
.A(n_85),
.Y(n_105)
);

AND2x2_ASAP7_75t_SL g106 ( 
.A(n_83),
.B(n_0),
.Y(n_106)
);

AND2x2_ASAP7_75t_SL g107 ( 
.A(n_84),
.B(n_1),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_71),
.Y(n_108)
);

AND2x4_ASAP7_75t_L g109 ( 
.A(n_69),
.B(n_6),
.Y(n_109)
);

INVx4_ASAP7_75t_L g110 ( 
.A(n_72),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_77),
.B(n_1),
.Y(n_111)
);

NAND2x1p5_ASAP7_75t_L g112 ( 
.A(n_78),
.B(n_9),
.Y(n_112)
);

BUFx6f_ASAP7_75t_L g113 ( 
.A(n_72),
.Y(n_113)
);

INVx2_ASAP7_75t_SL g114 ( 
.A(n_101),
.Y(n_114)
);

AND2x4_ASAP7_75t_L g115 ( 
.A(n_76),
.B(n_10),
.Y(n_115)
);

AND2x4_ASAP7_75t_L g116 ( 
.A(n_94),
.B(n_11),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_113),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_113),
.Y(n_118)
);

INVx2_ASAP7_75t_L g119 ( 
.A(n_105),
.Y(n_119)
);

INVx2_ASAP7_75t_L g120 ( 
.A(n_103),
.Y(n_120)
);

NOR2xp33_ASAP7_75t_SL g121 ( 
.A(n_106),
.B(n_107),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_108),
.Y(n_122)
);

AO21x2_ASAP7_75t_L g123 ( 
.A1(n_111),
.A2(n_81),
.B(n_67),
.Y(n_123)
);

AND2x2_ASAP7_75t_L g124 ( 
.A(n_114),
.B(n_108),
.Y(n_124)
);

INVx1_ASAP7_75t_L g125 ( 
.A(n_110),
.Y(n_125)
);

NAND2xp5_ASAP7_75t_SL g126 ( 
.A(n_115),
.B(n_70),
.Y(n_126)
);

BUFx6f_ASAP7_75t_L g127 ( 
.A(n_117),
.Y(n_127)
);

NOR2xp33_ASAP7_75t_L g128 ( 
.A(n_126),
.B(n_116),
.Y(n_128)
);

NAND2xp5_ASAP7_75t_L g129 ( 
.A(n_124),
.B(n_109),
.Y(n_129)
);

INVx2_ASAP7_75t_L g130 ( 
.A(n_119),
.Y(n_130)
);

NOR2xp33_ASAP7_75t_L g131 ( 
.A(n_125),
.B(n_123),
.Y(n_131)
);

NAND2xp5_ASAP7_75t_L g132 ( 
.A(n_122),
.B(n_109),
.Y(n_132)
);

NOR2xp33_ASAP7_75t_L g133 ( 
.A(n_121),
.B(n_115),
.Y(n_133)
);

INVx2_ASAP7_75t_L g134 ( 
.A(n_120),
.Y(n_134)
);

INVx2_ASAP7_75t_L g135 ( 
.A(n_118),
.Y(n_135)
);

AOI21xp5_ASAP7_75t_L g136 ( 
.A1(n_132),
.A2(n_89),
.B(n_82),
.Y(n_136)
);

BUFx3_ASAP7_75t_L g137 ( 
.A(n_127),
.Y(n_137)
);

OAI21xp5_ASAP7_75t_L g138 ( 
.A1(n_131),
.A2(n_99),
.B(n_112),
.Y(n_138)
);

AOI22xp33_ASAP7_75t_L g139 ( 
.A1(n_133),
.A2(n_128),
.B1(n_129),
.B2(n_134),
.Y(n_139)
);

BUFx6f_ASAP7_75t_L g140 ( 
.A(n_135),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_130),
.Y(n_141)
);

INVx2_ASAP7_75t_L g142 ( 
.A(n_130),
.Y(n_142)
);

OAI21x1_ASAP7_75t_L g143 ( 
.A1(n_142),
.A2(n_136),
.B(n_141),
.Y(n_143)
);

OAI21x1_ASAP7_75t_L g144 ( 
.A1(n_140),
.A2(n_88),
.B(n_87),
.Y(n_144)
);

NAND2xp5_ASAP7_75t_L g145 ( 
.A(n_139),
.B(n_91),
.Y(n_145)
);

NAND2xp5_ASAP7_75t_L g146 ( 
.A(n_139),
.B(n_95),
.Y(n_146)
);

CKINVDCx5p33_ASAP7_75t_R g147 ( 
.A(n_137),
.Y(n_147)
);

INVx1_ASAP7_75t_SL g148 ( 
.A(n_137),
.Y(n_148)
);

AOI21xp5_ASAP7_75t_L g149 ( 
.A1(n_138),
.A2(n_79),
.B(n_75),
.Y(n_149)
);

AOI21xp5_ASAP7_75t_SL g150 ( 
.A1(n_138),
.A2(n_73),
.B(n_92),
.Y(n_150)
);

BUFx6f_ASAP7_75t_L g151 ( 
.A(n_137),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_141),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_141),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_143),
.Y(n_154)
);

AND2x2_ASAP7_75t_L g155 ( 
.A(n_148),
.B(n_104),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_152),
.Y(n_156)
);

BUFx12f_ASAP7_75t_L g157 ( 
.A(n_147),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_153),
.Y(n_158)
);

OA21x2_ASAP7_75t_L g159 ( 
.A1(n_149),
.A2(n_146),
.B(n_145),
.Y(n_159)
);

INVx3_ASAP7_75t_L g160 ( 
.A(n_151),
.Y(n_160)
);

AO31x2_ASAP7_75t_L g161 ( 
.A1(n_150),
.A2(n_96),
.A3(n_90),
.B(n_86),
.Y(n_161)
);

OAI21x1_ASAP7_75t_L g162 ( 
.A1(n_144),
.A2(n_90),
.B(n_86),
.Y(n_162)
);

INVx2_ASAP7_75t_L g163 ( 
.A(n_152),
.Y(n_163)
);

OAI21x1_ASAP7_75t_L g164 ( 
.A1(n_143),
.A2(n_96),
.B(n_13),
.Y(n_164)
);

OAI21x1_ASAP7_75t_L g165 ( 
.A1(n_143),
.A2(n_16),
.B(n_14),
.Y(n_165)
);

AND2x2_ASAP7_75t_L g166 ( 
.A(n_155),
.B(n_74),
.Y(n_166)
);

INVx3_ASAP7_75t_L g167 ( 
.A(n_160),
.Y(n_167)
);

INVx1_ASAP7_75t_L g168 ( 
.A(n_158),
.Y(n_168)
);

INVx4_ASAP7_75t_SL g169 ( 
.A(n_161),
.Y(n_169)
);

INVx2_ASAP7_75t_L g170 ( 
.A(n_154),
.Y(n_170)
);

INVx2_ASAP7_75t_L g171 ( 
.A(n_164),
.Y(n_171)
);

INVx2_ASAP7_75t_L g172 ( 
.A(n_165),
.Y(n_172)
);

BUFx3_ASAP7_75t_L g173 ( 
.A(n_157),
.Y(n_173)
);

INVx2_ASAP7_75t_L g174 ( 
.A(n_159),
.Y(n_174)
);

OAI21x1_ASAP7_75t_L g175 ( 
.A1(n_162),
.A2(n_19),
.B(n_17),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_156),
.Y(n_176)
);

INVx2_ASAP7_75t_L g177 ( 
.A(n_163),
.Y(n_177)
);

INVx1_ASAP7_75t_L g178 ( 
.A(n_156),
.Y(n_178)
);

OAI21x1_ASAP7_75t_L g179 ( 
.A1(n_164),
.A2(n_23),
.B(n_22),
.Y(n_179)
);

AND2x2_ASAP7_75t_L g180 ( 
.A(n_155),
.B(n_93),
.Y(n_180)
);

AND2x2_ASAP7_75t_L g181 ( 
.A(n_166),
.B(n_97),
.Y(n_181)
);

NAND2xp5_ASAP7_75t_L g182 ( 
.A(n_168),
.B(n_98),
.Y(n_182)
);

INVx2_ASAP7_75t_L g183 ( 
.A(n_177),
.Y(n_183)
);

NAND2xp5_ASAP7_75t_L g184 ( 
.A(n_176),
.B(n_100),
.Y(n_184)
);

AND2x2_ASAP7_75t_L g185 ( 
.A(n_180),
.B(n_102),
.Y(n_185)
);

INVx2_ASAP7_75t_L g186 ( 
.A(n_178),
.Y(n_186)
);

HB1xp67_ASAP7_75t_L g187 ( 
.A(n_170),
.Y(n_187)
);

INVx2_ASAP7_75t_L g188 ( 
.A(n_167),
.Y(n_188)
);

NOR2x1_ASAP7_75t_R g189 ( 
.A(n_173),
.B(n_25),
.Y(n_189)
);

INVx1_ASAP7_75t_L g190 ( 
.A(n_174),
.Y(n_190)
);

BUFx3_ASAP7_75t_L g191 ( 
.A(n_179),
.Y(n_191)
);

OR2x2_ASAP7_75t_L g192 ( 
.A(n_186),
.B(n_171),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_183),
.B(n_169),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_187),
.Y(n_194)
);

NAND2xp5_ASAP7_75t_L g195 ( 
.A(n_190),
.B(n_172),
.Y(n_195)
);

AND2x2_ASAP7_75t_L g196 ( 
.A(n_188),
.B(n_175),
.Y(n_196)
);

INVx1_ASAP7_75t_L g197 ( 
.A(n_194),
.Y(n_197)
);

INVx1_ASAP7_75t_L g198 ( 
.A(n_197),
.Y(n_198)
);

INVx2_ASAP7_75t_L g199 ( 
.A(n_198),
.Y(n_199)
);

INVx2_ASAP7_75t_L g200 ( 
.A(n_199),
.Y(n_200)
);

AOI221xp5_ASAP7_75t_L g201 ( 
.A1(n_200),
.A2(n_185),
.B1(n_181),
.B2(n_182),
.C(n_184),
.Y(n_201)
);

NAND4xp25_ASAP7_75t_L g202 ( 
.A(n_201),
.B(n_184),
.C(n_182),
.D(n_193),
.Y(n_202)
);

AOI211xp5_ASAP7_75t_L g203 ( 
.A1(n_202),
.A2(n_189),
.B(n_196),
.C(n_192),
.Y(n_203)
);

AOI21xp5_ASAP7_75t_L g204 ( 
.A1(n_203),
.A2(n_195),
.B(n_191),
.Y(n_204)
);

INVx1_ASAP7_75t_L g205 ( 
.A(n_204),
.Y(n_205)
);

AND2x2_ASAP7_75t_SL g206 ( 
.A(n_205),
.B(n_32),
.Y(n_206)
);

INVx1_ASAP7_75t_L g207 ( 
.A(n_206),
.Y(n_207)
);

AOI21x1_ASAP7_75t_L g208 ( 
.A1(n_207),
.A2(n_37),
.B(n_36),
.Y(n_208)
);

NAND2xp5_ASAP7_75t_SL g209 ( 
.A(n_208),
.B(n_38),
.Y(n_209)
);

OAI21xp33_ASAP7_75t_L g210 ( 
.A1(n_209),
.A2(n_44),
.B(n_40),
.Y(n_210)
);

OAI21xp5_ASAP7_75t_L g211 ( 
.A1(n_210),
.A2(n_47),
.B(n_46),
.Y(n_211)
);

OR2x6_ASAP7_75t_L g212 ( 
.A(n_211),
.B(n_48),
.Y(n_212)
);

AOI22xp33_ASAP7_75t_L g213 ( 
.A1(n_212),
.A2(n_51),
.B1(n_50),
.B2(n_49),
.Y(n_213)
);


endmodule