module fake_netlist_785_197_n_24 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_24);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_24;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

AND3x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_7),
.C(n_5),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_8),
.B1(n_11),
.B2(n_3),
.Y(n_13)
);

CKINVDCx6p67_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_6),
.B(n_0),
.Y(n_15)
);

AOI22x1_ASAP7_75t_L g16 ( 
.A1(n_6),
.A2(n_5),
.B1(n_2),
.B2(n_7),
.Y(n_16)
);

OAI21x1_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_4),
.B(n_1),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_15),
.B(n_16),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_12),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NAND4xp25_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_19),
.C(n_13),
.D(n_14),
.Y(n_21)
);

CKINVDCx12_ASAP7_75t_R g22 ( 
.A(n_21),
.Y(n_22)
);

NAND2x1_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_19),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_17),
.B(n_14),
.Y(n_24)
);


endmodule