module fake_netlist_785_437_n_5 (n_1, n_2, n_0, n_5);

input n_1;
input n_2;
input n_0;

output n_5;

wire n_3;
wire n_4;

OR2x2_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

HB1xp67_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_3),
.Y(n_5)
);


endmodule