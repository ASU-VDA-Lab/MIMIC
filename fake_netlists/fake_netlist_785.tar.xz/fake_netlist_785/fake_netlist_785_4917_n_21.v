module fake_netlist_785_4917_n_21 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_21);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_21;

wire n_20;
wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_16;
wire n_11;
wire n_9;
wire n_8;
wire n_10;
wire n_19;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_3),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

AOI21x1_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_7),
.B(n_0),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_12),
.Y(n_14)
);

OAI22x1_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_8),
.B1(n_9),
.B2(n_10),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B(n_9),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_11),
.B2(n_9),
.C(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_SL g19 ( 
.A(n_18),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_11),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_21)
);


endmodule