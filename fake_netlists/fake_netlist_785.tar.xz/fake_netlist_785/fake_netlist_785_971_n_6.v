module fake_netlist_785_971_n_6 (n_1, n_2, n_0, n_6);

input n_1;
input n_2;
input n_0;

output n_6;

wire n_5;
wire n_3;
wire n_4;

INVxp67_ASAP7_75t_SL g3 ( 
.A(n_2),
.Y(n_3)
);

OA21x2_ASAP7_75t_L g4 ( 
.A1(n_0),
.A2(n_2),
.B(n_1),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

OA22x2_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B1(n_4),
.B2(n_3),
.Y(n_6)
);


endmodule