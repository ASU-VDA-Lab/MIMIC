module fake_netlist_785_2703_n_21 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_21);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_21;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_14;

INVx1_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

AO22x1_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_2),
.B1(n_5),
.B2(n_3),
.Y(n_12)
);

OA22x2_ASAP7_75t_L g13 ( 
.A1(n_7),
.A2(n_5),
.B1(n_6),
.B2(n_0),
.Y(n_13)
);

BUFx10_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_4),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_13),
.B1(n_12),
.B2(n_10),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

AOI22x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_20)
);

OR2x6_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_12),
.Y(n_21)
);


endmodule