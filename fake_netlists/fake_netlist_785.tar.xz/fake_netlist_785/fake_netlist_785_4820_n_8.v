module fake_netlist_785_4820_n_8 (n_1, n_2, n_0, n_8);

input n_1;
input n_2;
input n_0;

output n_8;

wire n_7;
wire n_5;
wire n_6;
wire n_3;
wire n_4;

BUFx8_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx5_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_1),
.Y(n_5)
);

NOR3xp33_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_3),
.C(n_2),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);


endmodule