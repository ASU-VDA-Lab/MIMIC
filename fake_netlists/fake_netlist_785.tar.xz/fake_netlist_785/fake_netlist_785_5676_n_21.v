module fake_netlist_785_5676_n_21 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_21);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_21;

wire n_20;
wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_19;
wire n_14;

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

OA22x2_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_13)
);

AO22x2_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_12),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_14),
.B(n_13),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_10),
.C(n_14),
.Y(n_18)
);

NAND4xp75_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_14),
.C(n_7),
.D(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OA21x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_3),
.B(n_7),
.Y(n_21)
);


endmodule