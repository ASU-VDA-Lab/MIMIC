module fake_netlist_785_3646_n_5 (n_1, n_0, n_5);

input n_1;
input n_0;

output n_5;

wire n_3;
wire n_2;
wire n_4;

INVx1_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

AND2x2_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

OAI211xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_0),
.B(n_1),
.C(n_2),
.Y(n_4)
);

BUFx2_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);


endmodule