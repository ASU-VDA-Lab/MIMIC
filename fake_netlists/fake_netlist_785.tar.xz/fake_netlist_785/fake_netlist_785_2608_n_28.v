module fake_netlist_785_2608_n_28 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_4, n_8, n_28);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_4;
input n_8;

output n_28;

wire n_20;
wire n_17;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVxp67_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_14),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.B1(n_17),
.B2(n_15),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_13),
.B1(n_6),
.B2(n_4),
.C(n_5),
.Y(n_21)
);

NOR2x1_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_0),
.Y(n_22)
);

NOR4xp25_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_20),
.C(n_7),
.D(n_3),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_22),
.B1(n_10),
.B2(n_9),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_23),
.B1(n_12),
.B2(n_7),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_26),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);


endmodule