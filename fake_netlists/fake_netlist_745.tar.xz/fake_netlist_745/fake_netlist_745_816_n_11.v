module fake_netlist_745_816_n_11 (n_0, n_2, n_1, n_11);

input n_0;
input n_2;
input n_1;

output n_11;

wire n_3;
wire n_9;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

INVx3_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

AOI21xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

NOR4xp25_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_3),
.C(n_4),
.D(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI31xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_4),
.A3(n_2),
.B(n_1),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_3),
.B(n_9),
.Y(n_11)
);


endmodule