module fake_netlist_745_596_n_14 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_14);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_14;

wire n_12;
wire n_8;
wire n_9;
wire n_10;
wire n_13;
wire n_7;
wire n_11;

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_0),
.Y(n_9)
);

AO21x1_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_3),
.B(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI321xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.A3(n_7),
.B1(n_10),
.B2(n_2),
.C(n_1),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_SL g13 ( 
.A(n_12),
.B(n_11),
.C(n_2),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_5),
.B(n_11),
.Y(n_14)
);


endmodule