module fake_netlist_745_2915_n_43 (n_12, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_43);

input n_12;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_43;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_15;
wire n_41;
wire n_29;
wire n_32;

AND2x2_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_2),
.B(n_3),
.Y(n_17)
);

AND2x6_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_7),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

O2A1O1Ixp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_11),
.B(n_10),
.C(n_8),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

NOR2x2_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_0),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_20),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_16),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_18),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_25),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

OAI32xp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_17),
.A3(n_20),
.B1(n_15),
.B2(n_23),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

AOI221x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_20),
.B1(n_15),
.B2(n_21),
.C(n_27),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

NOR2x1p5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_34),
.Y(n_36)
);

NAND4xp75_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_21),
.C(n_31),
.D(n_1),
.Y(n_37)
);

OAI21xp5_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_18),
.B(n_20),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

OR4x1_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_18),
.C(n_2),
.D(n_1),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_18),
.B1(n_4),
.B2(n_3),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_41),
.B1(n_18),
.B2(n_40),
.Y(n_42)
);

OAI22xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_6),
.B1(n_18),
.B2(n_13),
.Y(n_43)
);


endmodule