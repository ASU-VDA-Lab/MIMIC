module fake_netlist_745_4525_n_26 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_26);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_24;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;

INVx1_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

OA21x2_ASAP7_75t_L g14 ( 
.A1(n_4),
.A2(n_1),
.B(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_12),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_R g19 ( 
.A(n_17),
.B(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND4xp75_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_14),
.C(n_17),
.D(n_13),
.Y(n_22)
);

OAI22xp33_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_15),
.B1(n_19),
.B2(n_6),
.Y(n_23)
);

NOR2x1p5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_7),
.B1(n_10),
.B2(n_2),
.Y(n_26)
);


endmodule