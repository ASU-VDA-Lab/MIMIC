module fake_netlist_745_4662_n_22 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_8, n_22);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_22;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_9;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;

BUFx3_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_7),
.Y(n_12)
);

INVxp67_ASAP7_75t_SL g13 ( 
.A(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

AO31x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.A3(n_10),
.B(n_12),
.Y(n_15)
);

INVx3_ASAP7_75t_SL g16 ( 
.A(n_9),
.Y(n_16)
);

BUFx12f_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.B1(n_13),
.B2(n_15),
.C(n_17),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_15),
.B1(n_3),
.B2(n_2),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_4),
.Y(n_22)
);


endmodule