module fake_netlist_745_903_n_43 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_43);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_43;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_13;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_7),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_10),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_13),
.B(n_0),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_16),
.Y(n_26)
);

NAND3xp33_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_23),
.C(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_24),
.A2(n_18),
.B1(n_19),
.B2(n_15),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_19),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_27),
.Y(n_32)
);

XNOR2xp5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_14),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_29),
.C(n_18),
.Y(n_35)
);

NOR2x1_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_18),
.Y(n_36)
);

A2O1A1Ixp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_37)
);

OAI211xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_33),
.B(n_3),
.C(n_2),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_39)
);

CKINVDCx12_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_12),
.B(n_9),
.Y(n_42)
);

AOI222xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_38),
.B1(n_11),
.B2(n_4),
.C1(n_6),
.C2(n_42),
.Y(n_43)
);


endmodule