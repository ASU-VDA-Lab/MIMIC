module fake_netlist_745_895_n_31 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_31);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_31;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_29;

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_7),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_5),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

INVxp33_ASAP7_75t_SL g13 ( 
.A(n_5),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_1),
.B(n_7),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_0),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_1),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_9),
.B(n_3),
.Y(n_19)
);

OAI21x1_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_12),
.B(n_16),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_12),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_12),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_21),
.B1(n_13),
.B2(n_18),
.C(n_11),
.Y(n_25)
);

OAI221xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_11),
.B1(n_10),
.B2(n_19),
.C(n_20),
.Y(n_26)
);

AND3x4_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_23),
.C(n_2),
.Y(n_27)
);

NOR2x1_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_24),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_24),
.B(n_4),
.Y(n_30)
);

AOI21xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_6),
.B(n_30),
.Y(n_31)
);


endmodule