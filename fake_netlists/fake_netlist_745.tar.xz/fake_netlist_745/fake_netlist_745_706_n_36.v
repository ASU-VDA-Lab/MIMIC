module fake_netlist_745_706_n_36 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_36);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_36;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_9),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_10),
.B(n_1),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_2),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_14),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_15),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_22),
.B(n_18),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_21),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_25),
.B1(n_23),
.B2(n_18),
.C(n_11),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_13),
.C(n_11),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_13),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_4),
.B1(n_3),
.B2(n_5),
.C1(n_7),
.C2(n_6),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_31),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

OAI21xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_8),
.B(n_7),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_R g36 ( 
.A1(n_33),
.A2(n_35),
.B1(n_30),
.B2(n_34),
.Y(n_36)
);


endmodule