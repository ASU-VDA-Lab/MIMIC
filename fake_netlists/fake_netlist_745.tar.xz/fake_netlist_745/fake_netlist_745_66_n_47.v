module fake_netlist_745_66_n_47 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_47);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_47;

wire n_20;
wire n_23;
wire n_46;
wire n_14;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_18;
wire n_16;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_15;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_10),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_5),
.B(n_13),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_11),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_9),
.B(n_5),
.Y(n_18)
);

INVx6_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_6),
.A2(n_7),
.B1(n_8),
.B2(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_15),
.B(n_4),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_14),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_17),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

BUFx3_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_26),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_24),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_23),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_32),
.B(n_30),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_33),
.B(n_29),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_21),
.Y(n_37)
);

NAND2xp33_ASAP7_75t_SL g38 ( 
.A(n_35),
.B(n_18),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NOR2xp67_ASAP7_75t_SL g40 ( 
.A(n_37),
.B(n_18),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_16),
.B(n_15),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

NAND4xp25_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_15),
.C(n_1),
.D(n_0),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

XNOR2xp5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_38),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_R g47 ( 
.A1(n_46),
.A2(n_3),
.B1(n_44),
.B2(n_45),
.Y(n_47)
);


endmodule