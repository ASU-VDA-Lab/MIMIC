module fake_netlist_745_5010_n_26 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_26);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_24;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_6),
.B(n_1),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx16_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_4),
.B(n_3),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_7),
.B1(n_6),
.B2(n_8),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_14),
.B(n_18),
.C(n_17),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.C(n_13),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_17),
.B2(n_7),
.C(n_9),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_10),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

OR2x6_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_12),
.Y(n_26)
);


endmodule