module fake_netlist_745_3363_n_27 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_27);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_27;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_24;
wire n_10;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_9),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_5),
.B(n_2),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_1),
.B(n_5),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_4),
.B(n_8),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_6),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_6),
.Y(n_18)
);

CKINVDCx14_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_15),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI31xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_13),
.A3(n_14),
.B(n_16),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_19),
.B1(n_15),
.B2(n_11),
.C(n_7),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_10),
.B1(n_22),
.B2(n_3),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_22),
.Y(n_26)
);

NOR2xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);


endmodule