module fake_netlist_745_3329_n_28 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_28);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_28;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_27;
wire n_24;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_4),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_11),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_R g14 ( 
.A(n_10),
.B(n_7),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_7),
.Y(n_17)
);

O2A1O1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_6),
.B(n_5),
.C(n_1),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

O2A1O1Ixp33_ASAP7_75t_SL g21 ( 
.A1(n_18),
.A2(n_13),
.B(n_14),
.C(n_12),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_20),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_17),
.C(n_16),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_21),
.C(n_6),
.D(n_5),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_2),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_26),
.B1(n_9),
.B2(n_3),
.Y(n_28)
);


endmodule