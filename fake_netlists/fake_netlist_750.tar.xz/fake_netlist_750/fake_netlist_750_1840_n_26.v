module fake_netlist_750_1840_n_26 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_26);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_24;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_3),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_2),
.B(n_4),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

O2A1O1Ixp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_6),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_19),
.B(n_13),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_14),
.Y(n_21)
);

OAI322xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_16),
.A3(n_13),
.B1(n_18),
.B2(n_14),
.C1(n_1),
.C2(n_8),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

OA22x2_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_23),
.B1(n_14),
.B2(n_9),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_26)
);


endmodule