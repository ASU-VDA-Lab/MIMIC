module fake_netlist_750_1867_n_31 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_31);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_31;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_30;
wire n_9;
wire n_25;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;
wire n_29;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_6),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_R g9 ( 
.A(n_1),
.B(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_4),
.B(n_2),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_5),
.B(n_2),
.C(n_1),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_5),
.B1(n_2),
.B2(n_1),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_L g16 ( 
.A1(n_7),
.A2(n_8),
.B(n_12),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.Y(n_17)
);

NOR2x1p5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_12),
.Y(n_18)
);

OAI21xp33_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_12),
.B(n_8),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

AOI211xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_19),
.B(n_13),
.C(n_20),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_21),
.B1(n_18),
.B2(n_9),
.C(n_11),
.Y(n_25)
);

OAI221xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_23),
.B1(n_21),
.B2(n_15),
.C(n_11),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_24),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.B1(n_26),
.B2(n_21),
.Y(n_29)
);

OAI22x1_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_9),
.B1(n_6),
.B2(n_5),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_0),
.B1(n_3),
.B2(n_30),
.Y(n_31)
);


endmodule