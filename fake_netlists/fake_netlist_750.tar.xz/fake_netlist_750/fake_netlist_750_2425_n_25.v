module fake_netlist_750_2425_n_25 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_25);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_25;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_24;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_3),
.B(n_12),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_1),
.A2(n_11),
.B1(n_0),
.B2(n_2),
.Y(n_16)
);

INVx5_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

AOI21xp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_6),
.B(n_4),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_10),
.B(n_5),
.Y(n_19)
);

INVx4_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_18),
.Y(n_21)
);

NOR2xp67_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_17),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_14),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_16),
.B1(n_17),
.B2(n_4),
.C(n_7),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_7),
.Y(n_25)
);


endmodule