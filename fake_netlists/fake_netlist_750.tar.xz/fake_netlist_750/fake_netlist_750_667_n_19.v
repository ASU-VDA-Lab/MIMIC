module fake_netlist_750_667_n_19 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_19);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_19;

wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_17;
wire n_12;
wire n_15;

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_15),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B(n_1),
.C(n_0),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_4),
.B1(n_2),
.B2(n_7),
.C1(n_9),
.C2(n_8),
.Y(n_19)
);


endmodule