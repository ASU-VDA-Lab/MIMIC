module fake_netlist_750_846_n_21 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_21);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_21;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_17;
wire n_15;
wire n_12;
wire n_19;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_2),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_3),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_5),
.B(n_4),
.Y(n_15)
);

AO21x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_5),
.B(n_4),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_12),
.B2(n_13),
.C(n_16),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_1),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_21)
);


endmodule