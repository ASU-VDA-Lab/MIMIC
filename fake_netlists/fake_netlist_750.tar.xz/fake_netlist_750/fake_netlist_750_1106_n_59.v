module fake_netlist_750_1106_n_59 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_59);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_59;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_42;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_57;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

AND2x2_ASAP7_75t_L g20 ( 
.A(n_0),
.B(n_11),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_2),
.A2(n_8),
.B(n_12),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_13),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_18),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_10),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_7),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_3),
.Y(n_31)
);

BUFx4f_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

NOR2x1p5_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_0),
.Y(n_34)
);

BUFx12f_ASAP7_75t_SL g35 ( 
.A(n_20),
.Y(n_35)
);

BUFx4f_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_23),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_30),
.B(n_1),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_33),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AO31x2_ASAP7_75t_L g41 ( 
.A1(n_32),
.A2(n_29),
.A3(n_28),
.B(n_25),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_SL g43 ( 
.A1(n_40),
.A2(n_30),
.B(n_31),
.C(n_25),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_38),
.B1(n_35),
.B2(n_32),
.Y(n_44)
);

OAI211xp5_ASAP7_75t_L g45 ( 
.A1(n_39),
.A2(n_27),
.B(n_22),
.C(n_40),
.Y(n_45)
);

AO22x1_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_38),
.B1(n_20),
.B2(n_28),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_46),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_34),
.Y(n_50)
);

NAND2xp33_ASAP7_75t_SL g51 ( 
.A(n_46),
.B(n_27),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_32),
.Y(n_52)
);

AOI322xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_29),
.A3(n_24),
.B1(n_35),
.B2(n_16),
.C1(n_1),
.C2(n_17),
.Y(n_53)
);

OAI221xp5_ASAP7_75t_L g54 ( 
.A1(n_49),
.A2(n_36),
.B1(n_24),
.B2(n_41),
.C(n_16),
.Y(n_54)
);

NOR3xp33_ASAP7_75t_SL g55 ( 
.A(n_52),
.B(n_41),
.C(n_36),
.Y(n_55)
);

OAI221xp5_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_36),
.B1(n_19),
.B2(n_21),
.C(n_4),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_54),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_57),
.Y(n_58)
);

OAI332xp33_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_6),
.A3(n_9),
.B1(n_14),
.B2(n_55),
.B3(n_56),
.C1(n_23),
.C2(n_48),
.Y(n_59)
);


endmodule