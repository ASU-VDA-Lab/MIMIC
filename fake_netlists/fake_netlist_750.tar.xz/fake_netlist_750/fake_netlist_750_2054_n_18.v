module fake_netlist_750_2054_n_18 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_18);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_18;

wire n_12;
wire n_15;
wire n_14;
wire n_11;
wire n_9;
wire n_10;
wire n_7;
wire n_16;
wire n_17;
wire n_13;
wire n_8;

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

AO31x2_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_5),
.A3(n_4),
.B(n_1),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_4),
.B(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_7),
.B(n_9),
.Y(n_14)
);

NAND4xp75_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.C(n_6),
.D(n_5),
.Y(n_15)
);

OAI22x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B1(n_6),
.B2(n_5),
.Y(n_16)
);

OAI22x1_ASAP7_75t_SL g17 ( 
.A1(n_15),
.A2(n_6),
.B1(n_2),
.B2(n_0),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_3),
.B(n_17),
.Y(n_18)
);


endmodule