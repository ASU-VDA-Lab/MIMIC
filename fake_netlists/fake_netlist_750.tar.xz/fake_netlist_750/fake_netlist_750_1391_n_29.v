module fake_netlist_750_1391_n_29 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_29);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_29;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_16;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_7),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_21),
.B1(n_17),
.B2(n_18),
.C(n_20),
.Y(n_26)
);

AOI322xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_16),
.A3(n_7),
.B1(n_3),
.B2(n_4),
.C1(n_1),
.C2(n_2),
.Y(n_27)
);

OAI22x1_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_8),
.B1(n_6),
.B2(n_5),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_14),
.B1(n_13),
.B2(n_9),
.Y(n_29)
);


endmodule