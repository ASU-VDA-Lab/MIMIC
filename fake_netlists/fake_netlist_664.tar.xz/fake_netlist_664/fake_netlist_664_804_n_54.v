module fake_netlist_664_804_n_54 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_54);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_54;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_13),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_11),
.B(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_5),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_10),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_0),
.B(n_7),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

OAI22xp33_ASAP7_75t_L g28 ( 
.A1(n_22),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_19),
.B(n_1),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_29),
.B1(n_28),
.B2(n_30),
.Y(n_32)
);

INVx4_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

CKINVDCx11_ASAP7_75t_R g35 ( 
.A(n_27),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_SL g37 ( 
.A(n_32),
.B(n_25),
.Y(n_37)
);

INVxp67_ASAP7_75t_SL g38 ( 
.A(n_33),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_33),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_19),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_38),
.B(n_20),
.Y(n_42)
);

NOR3x1_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_25),
.C(n_35),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_R g45 ( 
.A(n_44),
.B(n_40),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

O2A1O1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_26),
.B(n_24),
.C(n_16),
.Y(n_47)
);

AOI211xp5_ASAP7_75t_SL g48 ( 
.A1(n_44),
.A2(n_24),
.B(n_17),
.C(n_16),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_45),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_SL g51 ( 
.A1(n_48),
.A2(n_18),
.B1(n_17),
.B2(n_3),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

NOR2xp67_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_6),
.Y(n_53)
);

AOI222xp33_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_49),
.B1(n_51),
.B2(n_52),
.C1(n_47),
.C2(n_8),
.Y(n_54)
);


endmodule