module fake_netlist_664_289_n_58 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_58);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_58;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_22;
wire n_17;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_8),
.B(n_1),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_11),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

XOR2xp5_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_15),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_18),
.B(n_11),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_12),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_12),
.Y(n_32)
);

BUFx12f_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

AND2x6_ASAP7_75t_L g34 ( 
.A(n_24),
.B(n_0),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

CKINVDCx16_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

OAI211xp5_ASAP7_75t_L g37 ( 
.A1(n_32),
.A2(n_27),
.B(n_23),
.C(n_21),
.Y(n_37)
);

OR2x6_ASAP7_75t_L g38 ( 
.A(n_31),
.B(n_22),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_29),
.B1(n_30),
.B2(n_17),
.C1(n_34),
.C2(n_20),
.Y(n_41)
);

AO21x2_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_30),
.B(n_29),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

INVx2_ASAP7_75t_SL g44 ( 
.A(n_42),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_36),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_40),
.Y(n_46)
);

OAI21xp33_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_41),
.B(n_17),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_34),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_44),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_51),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_24),
.B1(n_14),
.B2(n_13),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_50),
.Y(n_54)
);

INVxp33_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

AOI21xp5_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_24),
.B(n_34),
.Y(n_57)
);

AOI22xp33_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_55),
.B1(n_52),
.B2(n_57),
.Y(n_58)
);


endmodule