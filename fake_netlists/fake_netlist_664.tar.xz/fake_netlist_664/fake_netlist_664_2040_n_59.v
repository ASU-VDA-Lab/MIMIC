module fake_netlist_664_2040_n_59 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_59);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_59;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

OAI21x1_ASAP7_75t_L g28 ( 
.A1(n_3),
.A2(n_7),
.B(n_2),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_21),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_0),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_22),
.B(n_0),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_25),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_32)
);

BUFx3_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

CKINVDCx11_ASAP7_75t_R g34 ( 
.A(n_30),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_32),
.B1(n_25),
.B2(n_31),
.C(n_26),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_30),
.B1(n_32),
.B2(n_33),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_SL g40 ( 
.A(n_37),
.B(n_19),
.C(n_36),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_35),
.B1(n_30),
.B2(n_20),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_40),
.Y(n_45)
);

OAI211xp5_ASAP7_75t_SL g46 ( 
.A1(n_43),
.A2(n_34),
.B(n_29),
.C(n_20),
.Y(n_46)
);

O2A1O1Ixp33_ASAP7_75t_SL g47 ( 
.A1(n_43),
.A2(n_23),
.B(n_24),
.C(n_27),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_34),
.B1(n_30),
.B2(n_23),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_29),
.B1(n_27),
.B2(n_24),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

AND2x4_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_29),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_46),
.A2(n_28),
.B1(n_16),
.B2(n_5),
.Y(n_52)
);

AO22x2_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_28),
.B1(n_18),
.B2(n_17),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

AOI22xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_18),
.B1(n_17),
.B2(n_6),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_49),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_SL g57 ( 
.A1(n_54),
.A2(n_15),
.B1(n_9),
.B2(n_8),
.Y(n_57)
);

CKINVDCx20_ASAP7_75t_R g58 ( 
.A(n_55),
.Y(n_58)
);

AOI22x1_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_53),
.B1(n_56),
.B2(n_58),
.Y(n_59)
);


endmodule