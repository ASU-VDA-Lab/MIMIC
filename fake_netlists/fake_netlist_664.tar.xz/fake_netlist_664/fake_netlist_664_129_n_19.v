module fake_netlist_664_129_n_19 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_19);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_19;

wire n_18;
wire n_10;
wire n_11;
wire n_15;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;

INVx3_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_4),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_SL g15 ( 
.A(n_13),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B(n_10),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_8),
.C(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_7),
.B(n_2),
.Y(n_19)
);


endmodule