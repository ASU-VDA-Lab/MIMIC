module fake_netlist_664_380_n_18 (n_4, n_1, n_2, n_0, n_5, n_3, n_18);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_18;

wire n_7;
wire n_17;
wire n_14;
wire n_13;
wire n_10;
wire n_12;
wire n_6;
wire n_11;
wire n_16;
wire n_8;
wire n_15;
wire n_9;

BUFx3_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_3),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_2),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_SL g10 ( 
.A(n_7),
.B(n_4),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_8),
.B(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_6),
.Y(n_14)
);

AOI211xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B(n_8),
.C(n_9),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.C(n_13),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_5),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_1),
.Y(n_18)
);


endmodule