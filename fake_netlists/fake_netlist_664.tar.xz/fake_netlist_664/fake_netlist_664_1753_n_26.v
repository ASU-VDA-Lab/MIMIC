module fake_netlist_664_1753_n_26 (n_4, n_1, n_2, n_0, n_3, n_26);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_26;

wire n_18;
wire n_19;
wire n_10;
wire n_5;
wire n_25;
wire n_24;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

BUFx3_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_1),
.B(n_3),
.C(n_2),
.Y(n_11)
);

AO31x2_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_2),
.A3(n_4),
.B(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_7),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_9),
.B(n_11),
.Y(n_18)
);

AND4x1_ASAP7_75t_SL g19 ( 
.A(n_16),
.B(n_5),
.C(n_8),
.D(n_6),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_SL g20 ( 
.A1(n_18),
.A2(n_5),
.B(n_6),
.C(n_14),
.Y(n_20)
);

AOI322xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_2),
.A3(n_4),
.B1(n_7),
.B2(n_8),
.C1(n_15),
.C2(n_5),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_17),
.Y(n_22)
);

NOR4xp75_ASAP7_75t_SL g23 ( 
.A(n_19),
.B(n_4),
.C(n_7),
.D(n_8),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_SL g24 ( 
.A1(n_20),
.A2(n_15),
.B(n_10),
.Y(n_24)
);

OA22x2_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_21),
.B1(n_22),
.B2(n_23),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_22),
.B(n_23),
.Y(n_26)
);


endmodule