module fake_netlist_664_2254_n_29 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_29);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_29;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_26;

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_5),
.B(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_SL g21 ( 
.A(n_19),
.B(n_7),
.C(n_0),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_15),
.A2(n_7),
.B1(n_9),
.B2(n_1),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_22),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_15),
.B1(n_18),
.B2(n_16),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

OA21x2_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_17),
.B(n_20),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_10),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_14),
.B1(n_12),
.B2(n_11),
.Y(n_29)
);


endmodule