module fake_netlist_664_791_n_30 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_30);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_30;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_26;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_12),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_2),
.B(n_7),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_15),
.B1(n_16),
.B2(n_13),
.Y(n_19)
);

BUFx12f_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_15),
.B(n_18),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_20),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_21),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_19),
.Y(n_26)
);

AOI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_25),
.B1(n_20),
.B2(n_18),
.C1(n_23),
.C2(n_1),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_30)
);


endmodule