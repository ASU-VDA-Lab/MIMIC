module fake_netlist_664_2402_n_27 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_27);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_27;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_26;
wire n_13;

BUFx10_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_10),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_2),
.B(n_4),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_12),
.B1(n_15),
.B2(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_14),
.C(n_13),
.Y(n_20)
);

NAND3x1_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_18),
.C(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_5),
.B(n_1),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B1(n_9),
.B2(n_6),
.Y(n_27)
);


endmodule