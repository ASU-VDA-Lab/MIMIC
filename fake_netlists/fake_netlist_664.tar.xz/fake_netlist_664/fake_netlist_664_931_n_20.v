module fake_netlist_664_931_n_20 (n_4, n_1, n_2, n_0, n_3, n_20);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_20;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

CKINVDCx20_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_5),
.A2(n_0),
.B(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_SL g12 ( 
.A(n_9),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_10),
.B(n_11),
.Y(n_16)
);

OAI221xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_10),
.B1(n_9),
.B2(n_13),
.C(n_8),
.Y(n_17)
);

NAND3x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_11),
.C(n_2),
.Y(n_18)
);

BUFx4f_ASAP7_75t_SL g19 ( 
.A(n_18),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_4),
.B1(n_17),
.B2(n_15),
.Y(n_20)
);


endmodule