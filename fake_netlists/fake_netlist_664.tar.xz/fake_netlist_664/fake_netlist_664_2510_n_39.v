module fake_netlist_664_2510_n_39 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_39);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_39;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_18),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_5),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_11),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_12),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_2),
.B(n_0),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_22),
.A2(n_6),
.B(n_3),
.Y(n_28)
);

CKINVDCx12_ASAP7_75t_R g29 ( 
.A(n_26),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

INVxp67_ASAP7_75t_SL g32 ( 
.A(n_29),
.Y(n_32)
);

NAND4xp25_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_27),
.C(n_21),
.D(n_19),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_24),
.B(n_23),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_32),
.B1(n_9),
.B2(n_7),
.C(n_8),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_37),
.B1(n_13),
.B2(n_10),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_39)
);


endmodule