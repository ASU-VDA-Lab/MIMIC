module fake_netlist_664_2348_n_23 (n_4, n_1, n_2, n_0, n_3, n_23);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_23;

wire n_18;
wire n_19;
wire n_10;
wire n_5;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVxp67_ASAP7_75t_SL g5 ( 
.A(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_SL g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

AOI21xp33_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_6),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_8),
.B1(n_5),
.B2(n_0),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_10),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_8),
.B(n_1),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B1(n_12),
.B2(n_2),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_12),
.C(n_3),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_17),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_19),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

OA21x2_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_20),
.B(n_21),
.Y(n_23)
);


endmodule