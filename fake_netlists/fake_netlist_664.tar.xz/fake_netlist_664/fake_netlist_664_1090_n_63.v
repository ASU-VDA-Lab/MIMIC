module fake_netlist_664_1090_n_63 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_63);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_63;

wire n_36;
wire n_59;
wire n_62;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_60;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;
wire n_61;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_5),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_8),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_14),
.B(n_3),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_18),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_18),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_15),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_17),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_24),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_25),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_26),
.B(n_0),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

BUFx12f_ASAP7_75t_L g40 ( 
.A(n_33),
.Y(n_40)
);

AO21x2_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_21),
.B(n_36),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_27),
.B1(n_30),
.B2(n_22),
.Y(n_42)
);

BUFx6f_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_20),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_44),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_40),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_31),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_43),
.Y(n_50)
);

INVx3_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_48),
.Y(n_52)
);

XNOR2x2_ASAP7_75t_L g53 ( 
.A(n_52),
.B(n_46),
.Y(n_53)
);

CKINVDCx5p33_ASAP7_75t_R g54 ( 
.A(n_51),
.Y(n_54)
);

OAI332xp33_ASAP7_75t_L g55 ( 
.A1(n_50),
.A2(n_23),
.A3(n_32),
.B1(n_40),
.B2(n_41),
.B3(n_28),
.C1(n_2),
.C2(n_1),
.Y(n_55)
);

OAI211xp5_ASAP7_75t_SL g56 ( 
.A1(n_49),
.A2(n_23),
.B(n_32),
.C(n_28),
.Y(n_56)
);

INVx1_ASAP7_75t_SL g57 ( 
.A(n_54),
.Y(n_57)
);

AOI22xp33_ASAP7_75t_R g58 ( 
.A1(n_55),
.A2(n_28),
.B1(n_7),
.B2(n_4),
.Y(n_58)
);

XNOR2xp5_ASAP7_75t_L g59 ( 
.A(n_53),
.B(n_9),
.Y(n_59)
);

OAI211xp5_ASAP7_75t_SL g60 ( 
.A1(n_56),
.A2(n_54),
.B(n_11),
.C(n_10),
.Y(n_60)
);

INVx4_ASAP7_75t_L g61 ( 
.A(n_57),
.Y(n_61)
);

NOR2xp67_ASAP7_75t_L g62 ( 
.A(n_59),
.B(n_60),
.Y(n_62)
);

AOI22xp5_ASAP7_75t_L g63 ( 
.A1(n_61),
.A2(n_58),
.B1(n_62),
.B2(n_59),
.Y(n_63)
);


endmodule