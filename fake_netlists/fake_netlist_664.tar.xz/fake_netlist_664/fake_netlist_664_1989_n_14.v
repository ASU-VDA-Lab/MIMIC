module fake_netlist_664_1989_n_14 (n_3, n_1, n_2, n_0, n_14);

input n_3;
input n_1;
input n_2;
input n_0;

output n_14;

wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_6;
wire n_8;
wire n_11;
wire n_9;

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_4),
.B(n_5),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

NOR2xp67_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_4),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND4xp75_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_6),
.C(n_11),
.D(n_5),
.Y(n_14)
);


endmodule