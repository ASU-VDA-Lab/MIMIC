module fake_netlist_664_233_n_13 (n_1, n_2, n_0, n_13);

input n_1;
input n_2;
input n_0;

output n_13;

wire n_9;
wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;
wire n_3;

INVx3_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx6_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_5)
);

AOI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_0),
.Y(n_6)
);

AO21x2_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_4),
.B(n_3),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_3),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_0),
.Y(n_9)
);

O2A1O1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_7),
.B(n_4),
.C(n_0),
.Y(n_11)
);

OAI221xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_1),
.B1(n_2),
.B2(n_11),
.C(n_9),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_2),
.B(n_1),
.Y(n_13)
);


endmodule