module fake_netlist_664_1880_n_54 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_54);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_54;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx4_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_6),
.B(n_4),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_15),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_13),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_0),
.B(n_20),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_22),
.B(n_7),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_19),
.B(n_2),
.Y(n_35)
);

INVx2_ASAP7_75t_SL g36 ( 
.A(n_25),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_28),
.B(n_18),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_28),
.A2(n_24),
.B(n_18),
.C(n_1),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_34),
.B1(n_26),
.B2(n_32),
.Y(n_40)
);

AO21x2_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_29),
.B(n_35),
.Y(n_41)
);

OAI21xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_39),
.B(n_31),
.Y(n_42)
);

AO21x2_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_34),
.B(n_33),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_37),
.Y(n_46)
);

AOI321xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_36),
.A3(n_43),
.B1(n_26),
.B2(n_27),
.C(n_3),
.Y(n_47)
);

OAI221xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_27),
.B1(n_9),
.B2(n_5),
.C(n_8),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

AOI21xp33_ASAP7_75t_SL g50 ( 
.A1(n_48),
.A2(n_12),
.B(n_10),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_27),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

AOI22xp33_ASAP7_75t_SL g54 ( 
.A1(n_53),
.A2(n_17),
.B1(n_21),
.B2(n_52),
.Y(n_54)
);


endmodule