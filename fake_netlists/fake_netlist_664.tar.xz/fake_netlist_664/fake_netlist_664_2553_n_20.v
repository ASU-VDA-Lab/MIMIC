module fake_netlist_664_2553_n_20 (n_4, n_1, n_2, n_0, n_5, n_3, n_20);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_20;

wire n_18;
wire n_19;
wire n_10;
wire n_15;
wire n_11;
wire n_7;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

BUFx6f_ASAP7_75t_SL g6 ( 
.A(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_1),
.Y(n_7)
);

AO22x2_ASAP7_75t_L g8 ( 
.A1(n_2),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_2),
.C(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_14)
);

O2A1O1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_12),
.B(n_13),
.C(n_9),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_9),
.B(n_8),
.Y(n_16)
);

OR5x1_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_8),
.C(n_6),
.D(n_2),
.E(n_4),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_5),
.C(n_4),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_3),
.B(n_17),
.Y(n_19)
);

AO21x2_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_18),
.B(n_16),
.Y(n_20)
);


endmodule