module fake_netlist_664_761_n_23 (n_4, n_1, n_2, n_0, n_5, n_3, n_23);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_23;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_3),
.B(n_5),
.Y(n_6)
);

INVx5_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_3),
.B(n_4),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

AO31x2_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_5),
.A3(n_2),
.B(n_1),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_10),
.B(n_9),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_10),
.C(n_2),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_10),
.B1(n_11),
.B2(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_11),
.B1(n_20),
.B2(n_19),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_11),
.Y(n_22)
);

OA21x2_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_11),
.B(n_22),
.Y(n_23)
);


endmodule