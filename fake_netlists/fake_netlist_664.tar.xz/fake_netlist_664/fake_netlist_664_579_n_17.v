module fake_netlist_664_579_n_17 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_17);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_17;

wire n_14;
wire n_10;
wire n_15;
wire n_9;
wire n_11;
wire n_13;
wire n_16;
wire n_12;

NAND2x1p5_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_3),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

OA21x2_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_6),
.B(n_4),
.Y(n_12)
);

OAI21xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_9),
.B1(n_12),
.B2(n_7),
.C1(n_1),
.C2(n_0),
.Y(n_15)
);

OA22x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_9),
.B2(n_5),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);


endmodule