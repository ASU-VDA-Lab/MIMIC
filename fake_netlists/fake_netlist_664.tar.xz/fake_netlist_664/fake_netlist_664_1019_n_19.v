module fake_netlist_664_1019_n_19 (n_3, n_1, n_2, n_0, n_19);

input n_3;
input n_1;
input n_2;
input n_0;

output n_19;

wire n_18;
wire n_10;
wire n_5;
wire n_11;
wire n_15;
wire n_7;
wire n_16;
wire n_12;
wire n_4;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

AND2x2_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

INVxp33_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

OA21x2_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

AOI211x1_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

NOR2x1p5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_SL g14 ( 
.A1(n_11),
.A2(n_7),
.B(n_4),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_14),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AO22x2_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_4),
.B1(n_8),
.B2(n_16),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_16),
.B(n_18),
.Y(n_19)
);


endmodule