module fake_netlist_664_851_n_23 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_23);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_23;

wire n_18;
wire n_19;
wire n_10;
wire n_15;
wire n_11;
wire n_20;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;

AND2x4_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_6),
.B1(n_3),
.B2(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVx4_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_1),
.B(n_4),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

CKINVDCx16_ASAP7_75t_R g18 ( 
.A(n_15),
.Y(n_18)
);

AOI21x1_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_14),
.B(n_9),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_11),
.B(n_4),
.Y(n_22)
);

AOI222xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_5),
.B1(n_6),
.B2(n_11),
.C1(n_20),
.C2(n_22),
.Y(n_23)
);


endmodule