module fake_netlist_855_4264_n_10 (n_2, n_0, n_1, n_10);

input n_2;
input n_0;
input n_1;

output n_10;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_8;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVxp67_ASAP7_75t_SL g7 ( 
.A(n_6),
.Y(n_7)
);

AO221x1_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_4),
.B1(n_5),
.B2(n_0),
.C(n_2),
.Y(n_8)
);

XNOR2x1_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_7),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule