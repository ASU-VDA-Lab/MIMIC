module fake_netlist_855_2234_n_30 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_30);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_18;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_6),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_4),
.B(n_5),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_1),
.Y(n_16)
);

BUFx12f_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

INVx3_ASAP7_75t_SL g19 ( 
.A(n_18),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AOI21xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_20),
.B(n_16),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_R g25 ( 
.A(n_23),
.B(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_13),
.B(n_14),
.Y(n_27)
);

NAND5xp2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_25),
.C(n_15),
.D(n_0),
.E(n_7),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_R g30 ( 
.A1(n_29),
.A2(n_10),
.B1(n_25),
.B2(n_28),
.C(n_15),
.Y(n_30)
);


endmodule