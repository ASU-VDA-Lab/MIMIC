module fake_netlist_855_2462_n_27 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_27);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_6),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_5),
.B(n_4),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_10),
.B(n_14),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_10),
.B(n_15),
.Y(n_19)
);

NOR2x1p5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_15),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_R g21 ( 
.A(n_19),
.B(n_12),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_17),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_16),
.B2(n_18),
.Y(n_23)
);

NOR4xp25_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_6),
.C(n_5),
.D(n_4),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

AO22x2_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_8),
.B1(n_3),
.B2(n_2),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_9),
.B1(n_25),
.B2(n_10),
.Y(n_27)
);


endmodule