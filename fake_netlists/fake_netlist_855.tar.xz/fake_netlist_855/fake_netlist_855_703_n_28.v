module fake_netlist_855_703_n_28 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_28);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

INVx1_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

NAND2xp33_ASAP7_75t_L g13 ( 
.A(n_1),
.B(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_7),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_7),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_12),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_14),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_16),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B1(n_11),
.B2(n_18),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_15),
.C(n_13),
.Y(n_22)
);

OAI32xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_12),
.A3(n_16),
.B1(n_0),
.B2(n_1),
.Y(n_23)
);

OAI322xp33_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_3),
.A3(n_2),
.B1(n_6),
.B2(n_8),
.C1(n_4),
.C2(n_5),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_25),
.B1(n_23),
.B2(n_2),
.Y(n_28)
);


endmodule