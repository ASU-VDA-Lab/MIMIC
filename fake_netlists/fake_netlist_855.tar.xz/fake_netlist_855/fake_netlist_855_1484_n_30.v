module fake_netlist_855_1484_n_30 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_30);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_9),
.B(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_R g14 ( 
.A(n_8),
.B(n_7),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_7),
.A2(n_8),
.B1(n_5),
.B2(n_4),
.Y(n_15)
);

INVx5_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_11),
.Y(n_19)
);

BUFx4f_ASAP7_75t_SL g20 ( 
.A(n_17),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_11),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OAI32xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.A3(n_13),
.B1(n_14),
.B2(n_18),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_15),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_18),
.B(n_13),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_16),
.B(n_22),
.C(n_10),
.Y(n_26)
);

NOR2x1_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_0),
.Y(n_27)
);

AND4x1_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_4),
.C(n_1),
.D(n_0),
.Y(n_28)
);

AO22x2_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_25),
.B1(n_6),
.B2(n_2),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_R g30 ( 
.A1(n_29),
.A2(n_3),
.B1(n_10),
.B2(n_28),
.Y(n_30)
);


endmodule