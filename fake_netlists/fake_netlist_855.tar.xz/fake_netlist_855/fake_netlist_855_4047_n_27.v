module fake_netlist_855_4047_n_27 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_27);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_21;
wire n_16;
wire n_11;

INVx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx11_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_10),
.Y(n_16)
);

OAI22xp33_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B(n_11),
.C(n_15),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_17),
.B(n_16),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_13),
.B(n_20),
.C(n_12),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_1),
.B1(n_0),
.B2(n_3),
.C(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

BUFx8_ASAP7_75t_SL g25 ( 
.A(n_23),
.Y(n_25)
);

AO22x2_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B1(n_9),
.B2(n_8),
.Y(n_27)
);


endmodule