module fake_netlist_855_3945_n_11 (n_2, n_0, n_3, n_1, n_11);

input n_2;
input n_0;
input n_3;
input n_1;

output n_11;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_9;
wire n_8;

INVx2_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AOI22xp33_ASAP7_75t_L g5 ( 
.A1(n_0),
.A2(n_1),
.B1(n_3),
.B2(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_SL g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.C(n_3),
.Y(n_8)
);

AOI32xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.A3(n_2),
.B1(n_0),
.B2(n_1),
.Y(n_9)
);

AOI22x1_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B1(n_1),
.B2(n_0),
.Y(n_10)
);

OAI21x1_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_2),
.B(n_8),
.Y(n_11)
);


endmodule