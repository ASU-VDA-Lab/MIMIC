module fake_netlist_855_3041_n_7 (n_2, n_0, n_1, n_7);

input n_2;
input n_0;
input n_1;

output n_7;

wire n_6;
wire n_4;
wire n_5;
wire n_3;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_0),
.B1(n_2),
.B2(n_5),
.Y(n_7)
);


endmodule