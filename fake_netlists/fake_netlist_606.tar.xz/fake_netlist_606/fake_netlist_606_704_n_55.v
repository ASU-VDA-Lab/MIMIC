module fake_netlist_606_704_n_55 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_25, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_55);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_25;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_55;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_27;
wire n_28;
wire n_52;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_51;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

AND2x6_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_5),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_6),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_15),
.B(n_1),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_13),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_17),
.B(n_20),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_10),
.B(n_24),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_2),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_19),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_4),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_29),
.B(n_25),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_0),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

INVx6_ASAP7_75t_L g39 ( 
.A(n_26),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_26),
.B1(n_34),
.B2(n_33),
.Y(n_40)
);

BUFx3_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_36),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_42),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_26),
.B1(n_39),
.B2(n_33),
.Y(n_44)
);

CKINVDCx16_ASAP7_75t_R g45 ( 
.A(n_43),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_44),
.Y(n_46)
);

INVxp67_ASAP7_75t_SL g47 ( 
.A(n_45),
.Y(n_47)
);

NOR3xp33_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_41),
.C(n_31),
.Y(n_48)
);

AOI221x1_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_35),
.B1(n_28),
.B2(n_30),
.C(n_40),
.Y(n_49)
);

NAND2xp33_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_27),
.Y(n_50)
);

NAND4xp25_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_35),
.C(n_7),
.D(n_3),
.Y(n_51)
);

NAND3xp33_ASAP7_75t_SL g52 ( 
.A(n_50),
.B(n_9),
.C(n_8),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_14),
.B1(n_12),
.B2(n_11),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

AOI322xp5_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_16),
.A3(n_18),
.B1(n_21),
.B2(n_22),
.C1(n_23),
.C2(n_53),
.Y(n_55)
);


endmodule