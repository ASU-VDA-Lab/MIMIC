module fake_netlist_606_1596_n_24 (n_7, n_9, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_24);

input n_7;
input n_9;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_24;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

AND3x1_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_1),
.C(n_0),
.Y(n_14)
);

INVx5_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_8),
.B(n_3),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_6),
.B(n_4),
.C(n_10),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.B1(n_12),
.B2(n_15),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_6),
.C(n_4),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVxp33_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_15),
.B1(n_16),
.B2(n_23),
.Y(n_24)
);


endmodule