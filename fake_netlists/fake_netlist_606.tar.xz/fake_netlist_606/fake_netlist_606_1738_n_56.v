module fake_netlist_606_1738_n_56 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_56);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_56;

wire n_31;
wire n_37;
wire n_39;
wire n_54;
wire n_53;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_52;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

NOR2x1_ASAP7_75t_L g25 ( 
.A(n_1),
.B(n_13),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_0),
.B(n_20),
.Y(n_26)
);

AND2x6_ASAP7_75t_L g27 ( 
.A(n_3),
.B(n_4),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_8),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_9),
.A2(n_7),
.B1(n_17),
.B2(n_11),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_23),
.B(n_2),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_10),
.B(n_23),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_18),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

CKINVDCx11_ASAP7_75t_R g35 ( 
.A(n_28),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_5),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_6),
.Y(n_37)
);

OR2x6_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_12),
.Y(n_38)
);

BUFx3_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

OAI21x1_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_25),
.B(n_31),
.Y(n_40)
);

OAI21x1_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_29),
.B(n_27),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_38),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_35),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_41),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_40),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_34),
.Y(n_46)
);

AOI21xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_26),
.B(n_27),
.Y(n_47)
);

AOI21xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_15),
.B(n_14),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_27),
.Y(n_50)
);

NOR3xp33_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_30),
.C(n_16),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_19),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_21),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_22),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_54),
.Y(n_55)
);

AOI22xp33_ASAP7_75t_SL g56 ( 
.A1(n_55),
.A2(n_53),
.B1(n_52),
.B2(n_51),
.Y(n_56)
);


endmodule