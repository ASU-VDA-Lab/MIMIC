module fake_netlist_606_2326_n_10 (n_1, n_2, n_0, n_10);

input n_1;
input n_2;
input n_0;

output n_10;

wire n_7;
wire n_9;
wire n_8;
wire n_5;
wire n_6;
wire n_4;
wire n_3;

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_4),
.B(n_3),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

AOI222xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_6),
.C2(n_5),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_R g9 ( 
.A(n_8),
.B(n_1),
.Y(n_9)
);

NOR2xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_1),
.Y(n_10)
);


endmodule