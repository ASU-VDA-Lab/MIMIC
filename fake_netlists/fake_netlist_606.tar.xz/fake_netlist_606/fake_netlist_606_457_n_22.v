module fake_netlist_606_457_n_22 (n_5, n_0, n_4, n_1, n_2, n_3, n_22);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_22;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_17;
wire n_7;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

BUFx10_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

INVx5_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_6),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_4),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

OAI31xp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_8),
.A3(n_7),
.B(n_6),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AOI21xp33_ASAP7_75t_SL g18 ( 
.A1(n_16),
.A2(n_14),
.B(n_2),
.Y(n_18)
);

OAI21xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_12),
.B(n_7),
.Y(n_19)
);

OA22x2_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.B1(n_7),
.B2(n_6),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

AO221x1_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_3),
.B1(n_4),
.B2(n_6),
.C(n_20),
.Y(n_22)
);


endmodule