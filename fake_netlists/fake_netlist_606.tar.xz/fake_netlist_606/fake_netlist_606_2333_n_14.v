module fake_netlist_606_2333_n_14 (n_0, n_4, n_1, n_2, n_3, n_14);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_14;

wire n_7;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

NAND2xp33_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_2),
.Y(n_6)
);

BUFx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

NOR2x1_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_2),
.B(n_0),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_3),
.B1(n_4),
.B2(n_11),
.Y(n_14)
);


endmodule