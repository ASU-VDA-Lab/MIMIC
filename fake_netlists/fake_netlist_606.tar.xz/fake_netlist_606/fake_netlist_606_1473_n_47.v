module fake_netlist_606_1473_n_47 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_47);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_47;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_43;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_5),
.A2(n_11),
.B1(n_12),
.B2(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_8),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_SL g31 ( 
.A(n_21),
.B(n_19),
.C(n_3),
.Y(n_31)
);

OAI21x1_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_25),
.B(n_24),
.Y(n_32)
);

OA21x2_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_27),
.B(n_26),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_35),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_31),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_23),
.B1(n_26),
.B2(n_19),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_9),
.B1(n_7),
.B2(n_4),
.Y(n_42)
);

INVxp67_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_44),
.B1(n_18),
.B2(n_17),
.Y(n_47)
);


endmodule