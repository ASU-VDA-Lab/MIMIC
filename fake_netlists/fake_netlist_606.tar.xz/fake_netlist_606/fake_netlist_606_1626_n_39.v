module fake_netlist_606_1626_n_39 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_39);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_39;

wire n_31;
wire n_37;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

INVx8_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_7),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_11),
.B(n_6),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_3),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_SL g26 ( 
.A1(n_23),
.A2(n_16),
.B(n_4),
.C(n_1),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_4),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_19),
.Y(n_28)
);

NOR3xp33_ASAP7_75t_SL g29 ( 
.A(n_27),
.B(n_21),
.C(n_20),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_24),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_29),
.B1(n_26),
.B2(n_17),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI211xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_17),
.B(n_16),
.C(n_2),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_SL g36 ( 
.A(n_34),
.B(n_9),
.C(n_5),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_10),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_13),
.B1(n_15),
.B2(n_38),
.Y(n_39)
);


endmodule