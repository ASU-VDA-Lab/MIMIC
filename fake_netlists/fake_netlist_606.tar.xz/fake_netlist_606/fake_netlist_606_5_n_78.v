module fake_netlist_606_5_n_78 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_25, n_26, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_78);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_25;
input n_26;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_78;

wire n_75;
wire n_37;
wire n_54;
wire n_44;
wire n_36;
wire n_65;
wire n_63;
wire n_47;
wire n_57;
wire n_55;
wire n_76;
wire n_64;
wire n_68;
wire n_53;
wire n_39;
wire n_77;
wire n_29;
wire n_27;
wire n_35;
wire n_69;
wire n_71;
wire n_42;
wire n_59;
wire n_50;
wire n_58;
wire n_28;
wire n_52;
wire n_49;
wire n_51;
wire n_45;
wire n_73;
wire n_56;
wire n_66;
wire n_32;
wire n_33;
wire n_41;
wire n_34;
wire n_31;
wire n_40;
wire n_30;
wire n_61;
wire n_62;
wire n_70;
wire n_67;
wire n_48;
wire n_60;
wire n_38;
wire n_46;
wire n_43;
wire n_74;
wire n_72;

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_13),
.B(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_7),
.A2(n_11),
.B1(n_21),
.B2(n_4),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_12),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_19),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_2),
.B(n_9),
.Y(n_34)
);

INVx6_ASAP7_75t_L g35 ( 
.A(n_1),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_8),
.Y(n_36)
);

XNOR2xp5_ASAP7_75t_L g37 ( 
.A(n_22),
.B(n_0),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_3),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_24),
.B(n_14),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_17),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_27),
.A2(n_26),
.B1(n_25),
.B2(n_17),
.Y(n_41)
);

XOR2x2_ASAP7_75t_L g42 ( 
.A(n_27),
.B(n_25),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_SL g43 ( 
.A(n_28),
.B(n_26),
.C(n_5),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_35),
.Y(n_44)
);

INVx2_ASAP7_75t_SL g45 ( 
.A(n_35),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_38),
.Y(n_46)
);

INVx3_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

OAI21xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_29),
.B(n_31),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_40),
.Y(n_49)
);

OAI21x1_ASAP7_75t_L g50 ( 
.A1(n_40),
.A2(n_34),
.B(n_28),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_32),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_49),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_47),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_50),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_48),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

OR2x2_ASAP7_75t_L g57 ( 
.A(n_51),
.B(n_42),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_50),
.Y(n_58)
);

AOI222xp33_ASAP7_75t_L g59 ( 
.A1(n_54),
.A2(n_43),
.B1(n_47),
.B2(n_45),
.C1(n_37),
.C2(n_50),
.Y(n_59)
);

NOR3xp33_ASAP7_75t_L g60 ( 
.A(n_57),
.B(n_43),
.C(n_41),
.Y(n_60)
);

INVxp67_ASAP7_75t_L g61 ( 
.A(n_54),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_61),
.Y(n_62)
);

OAI21xp33_ASAP7_75t_SL g63 ( 
.A1(n_58),
.A2(n_30),
.B(n_56),
.Y(n_63)
);

AOI221x1_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_36),
.B1(n_33),
.B2(n_47),
.C(n_34),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_59),
.Y(n_65)
);

NAND5xp2_ASAP7_75t_L g66 ( 
.A(n_59),
.B(n_39),
.C(n_36),
.D(n_33),
.E(n_47),
.Y(n_66)
);

NAND2xp5_ASAP7_75t_SL g67 ( 
.A(n_65),
.B(n_33),
.Y(n_67)
);

NOR2xp67_ASAP7_75t_L g68 ( 
.A(n_66),
.B(n_47),
.Y(n_68)
);

INVx6_ASAP7_75t_L g69 ( 
.A(n_62),
.Y(n_69)
);

NOR4xp75_ASAP7_75t_L g70 ( 
.A(n_63),
.B(n_36),
.C(n_10),
.D(n_6),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_65),
.B(n_15),
.Y(n_71)
);

OAI21xp5_ASAP7_75t_L g72 ( 
.A1(n_68),
.A2(n_64),
.B(n_16),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_69),
.Y(n_73)
);

AND2x4_ASAP7_75t_L g74 ( 
.A(n_70),
.B(n_64),
.Y(n_74)
);

BUFx2_ASAP7_75t_L g75 ( 
.A(n_71),
.Y(n_75)
);

OAI22xp5_ASAP7_75t_SL g76 ( 
.A1(n_73),
.A2(n_18),
.B1(n_67),
.B2(n_72),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_75),
.Y(n_77)
);

AOI22x1_ASAP7_75t_L g78 ( 
.A1(n_77),
.A2(n_72),
.B1(n_74),
.B2(n_76),
.Y(n_78)
);


endmodule