module fake_netlist_606_990_n_51 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_51);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_51;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_3),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_14),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_12),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_R g33 ( 
.A(n_18),
.B(n_23),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_19),
.Y(n_34)
);

BUFx4f_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_28),
.B1(n_24),
.B2(n_25),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_28),
.B1(n_30),
.B2(n_26),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_36),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_36),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

NAND2xp33_ASAP7_75t_SL g44 ( 
.A(n_42),
.B(n_33),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_43),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_31),
.B1(n_19),
.B2(n_0),
.Y(n_46)
);

AOI211xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_5),
.B(n_4),
.C(n_1),
.Y(n_47)
);

OAI221xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_7),
.B1(n_6),
.B2(n_8),
.C(n_11),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

BUFx2_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

AOI322xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_13),
.A3(n_16),
.B1(n_17),
.B2(n_21),
.C1(n_22),
.C2(n_50),
.Y(n_51)
);


endmodule