module fake_netlist_606_1045_n_51 (n_7, n_9, n_11, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_51);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_51;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_50;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_42;
wire n_33;
wire n_41;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

BUFx10_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_11),
.B(n_3),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_8),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_4),
.B(n_14),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_3),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_1),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_2),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_21),
.B(n_10),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_4),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_28),
.A2(n_19),
.B1(n_23),
.B2(n_16),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_24),
.A2(n_17),
.B1(n_20),
.B2(n_22),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_25),
.B(n_22),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_20),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_19),
.Y(n_36)
);

NAND2x1p5_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_22),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_34),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_19),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_37),
.B1(n_22),
.B2(n_17),
.Y(n_41)
);

OA211x2_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_27),
.B(n_6),
.C(n_5),
.Y(n_42)
);

OAI21xp5_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_22),
.B(n_18),
.Y(n_43)
);

NOR4xp75_ASAP7_75t_SL g44 ( 
.A(n_38),
.B(n_7),
.C(n_18),
.D(n_12),
.Y(n_44)
);

BUFx12f_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_7),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

AND4x1_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_27),
.C(n_15),
.D(n_13),
.Y(n_48)
);

INVxp67_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

OAI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_45),
.A2(n_44),
.B1(n_47),
.B2(n_48),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_45),
.B1(n_48),
.B2(n_49),
.Y(n_51)
);


endmodule