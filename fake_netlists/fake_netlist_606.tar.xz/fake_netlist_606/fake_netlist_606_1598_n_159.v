module fake_netlist_606_1598_n_159 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_25, n_26, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_159);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_25;
input n_26;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_159;

wire n_137;
wire n_133;
wire n_75;
wire n_37;
wire n_109;
wire n_121;
wire n_119;
wire n_54;
wire n_120;
wire n_123;
wire n_44;
wire n_36;
wire n_87;
wire n_125;
wire n_65;
wire n_106;
wire n_83;
wire n_63;
wire n_88;
wire n_126;
wire n_116;
wire n_47;
wire n_57;
wire n_135;
wire n_82;
wire n_55;
wire n_76;
wire n_64;
wire n_157;
wire n_68;
wire n_146;
wire n_81;
wire n_97;
wire n_39;
wire n_53;
wire n_122;
wire n_77;
wire n_29;
wire n_27;
wire n_101;
wire n_35;
wire n_80;
wire n_112;
wire n_69;
wire n_99;
wire n_86;
wire n_110;
wire n_78;
wire n_114;
wire n_141;
wire n_71;
wire n_149;
wire n_42;
wire n_132;
wire n_155;
wire n_96;
wire n_84;
wire n_107;
wire n_115;
wire n_148;
wire n_150;
wire n_158;
wire n_117;
wire n_130;
wire n_94;
wire n_129;
wire n_59;
wire n_102;
wire n_134;
wire n_50;
wire n_143;
wire n_58;
wire n_28;
wire n_142;
wire n_52;
wire n_95;
wire n_51;
wire n_49;
wire n_145;
wire n_45;
wire n_73;
wire n_104;
wire n_108;
wire n_56;
wire n_85;
wire n_66;
wire n_32;
wire n_33;
wire n_92;
wire n_41;
wire n_105;
wire n_153;
wire n_147;
wire n_34;
wire n_103;
wire n_144;
wire n_31;
wire n_79;
wire n_139;
wire n_111;
wire n_40;
wire n_30;
wire n_61;
wire n_62;
wire n_70;
wire n_90;
wire n_67;
wire n_89;
wire n_152;
wire n_48;
wire n_91;
wire n_128;
wire n_138;
wire n_140;
wire n_60;
wire n_46;
wire n_38;
wire n_156;
wire n_151;
wire n_43;
wire n_131;
wire n_136;
wire n_154;
wire n_74;
wire n_113;
wire n_118;
wire n_93;
wire n_72;
wire n_98;
wire n_100;
wire n_127;
wire n_124;

INVx1_ASAP7_75t_L g27 ( 
.A(n_8),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVxp67_ASAP7_75t_SL g30 ( 
.A(n_21),
.Y(n_30)
);

INVxp67_ASAP7_75t_SL g31 ( 
.A(n_25),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_0),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_3),
.Y(n_33)
);

INVxp67_ASAP7_75t_SL g34 ( 
.A(n_24),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_4),
.Y(n_35)
);

INVxp67_ASAP7_75t_SL g36 ( 
.A(n_9),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_19),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_15),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_22),
.Y(n_39)
);

INVxp67_ASAP7_75t_L g40 ( 
.A(n_27),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_28),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_28),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_29),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_37),
.Y(n_44)
);

XOR2xp5_ASAP7_75t_L g45 ( 
.A(n_32),
.B(n_1),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

OR2x6_ASAP7_75t_L g49 ( 
.A(n_40),
.B(n_33),
.Y(n_49)
);

NAND2x1p5_ASAP7_75t_L g50 ( 
.A(n_41),
.B(n_37),
.Y(n_50)
);

INVx2_ASAP7_75t_SL g51 ( 
.A(n_42),
.Y(n_51)
);

AO22x2_ASAP7_75t_L g52 ( 
.A1(n_45),
.A2(n_36),
.B1(n_31),
.B2(n_30),
.Y(n_52)
);

AND3x1_ASAP7_75t_SL g53 ( 
.A(n_52),
.B(n_45),
.C(n_35),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_40),
.Y(n_54)
);

INVx5_ASAP7_75t_L g55 ( 
.A(n_49),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_51),
.B(n_43),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_46),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_48),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_47),
.Y(n_59)
);

AND2x2_ASAP7_75t_L g60 ( 
.A(n_49),
.B(n_35),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_55),
.B(n_50),
.Y(n_61)
);

OR2x6_ASAP7_75t_L g62 ( 
.A(n_60),
.B(n_52),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_55),
.B(n_52),
.Y(n_63)
);

NOR2xp67_ASAP7_75t_L g64 ( 
.A(n_55),
.B(n_2),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_54),
.Y(n_65)
);

AOI21xp5_ASAP7_75t_L g66 ( 
.A1(n_56),
.A2(n_34),
.B(n_39),
.Y(n_66)
);

INVxp67_ASAP7_75t_L g67 ( 
.A(n_60),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_65),
.B(n_55),
.Y(n_68)
);

INVx2_ASAP7_75t_L g69 ( 
.A(n_61),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_61),
.Y(n_70)
);

AND2x4_ASAP7_75t_L g71 ( 
.A(n_63),
.B(n_55),
.Y(n_71)
);

AND2x4_ASAP7_75t_L g72 ( 
.A(n_63),
.B(n_55),
.Y(n_72)
);

AND2x2_ASAP7_75t_L g73 ( 
.A(n_62),
.B(n_67),
.Y(n_73)
);

AND2x2_ASAP7_75t_L g74 ( 
.A(n_62),
.B(n_55),
.Y(n_74)
);

AND2x2_ASAP7_75t_L g75 ( 
.A(n_62),
.B(n_57),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_69),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_69),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_69),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_69),
.Y(n_79)
);

INVxp67_ASAP7_75t_SL g80 ( 
.A(n_75),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_70),
.Y(n_81)
);

INVx8_ASAP7_75t_L g82 ( 
.A(n_74),
.Y(n_82)
);

INVx3_ASAP7_75t_L g83 ( 
.A(n_76),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_76),
.Y(n_84)
);

INVx2_ASAP7_75t_L g85 ( 
.A(n_77),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_78),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_78),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_79),
.Y(n_88)
);

OR2x2_ASAP7_75t_L g89 ( 
.A(n_80),
.B(n_75),
.Y(n_89)
);

AND2x4_ASAP7_75t_L g90 ( 
.A(n_83),
.B(n_81),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_84),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_84),
.Y(n_92)
);

AND2x2_ASAP7_75t_L g93 ( 
.A(n_83),
.B(n_81),
.Y(n_93)
);

INVx1_ASAP7_75t_L g94 ( 
.A(n_84),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_85),
.Y(n_95)
);

INVxp67_ASAP7_75t_L g96 ( 
.A(n_83),
.Y(n_96)
);

AND2x2_ASAP7_75t_L g97 ( 
.A(n_83),
.B(n_75),
.Y(n_97)
);

INVx1_ASAP7_75t_L g98 ( 
.A(n_85),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_91),
.Y(n_99)
);

INVx1_ASAP7_75t_L g100 ( 
.A(n_91),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_92),
.Y(n_101)
);

INVx1_ASAP7_75t_SL g102 ( 
.A(n_93),
.Y(n_102)
);

NOR2xp33_ASAP7_75t_L g103 ( 
.A(n_97),
.B(n_38),
.Y(n_103)
);

OAI222xp33_ASAP7_75t_L g104 ( 
.A1(n_96),
.A2(n_89),
.B1(n_88),
.B2(n_86),
.C1(n_87),
.C2(n_85),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_92),
.Y(n_105)
);

AND2x2_ASAP7_75t_L g106 ( 
.A(n_94),
.B(n_87),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_94),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_95),
.Y(n_108)
);

OR2x2_ASAP7_75t_L g109 ( 
.A(n_98),
.B(n_73),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_90),
.Y(n_110)
);

NAND2x1_ASAP7_75t_SL g111 ( 
.A(n_110),
.B(n_90),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_101),
.Y(n_112)
);

INVxp67_ASAP7_75t_L g113 ( 
.A(n_103),
.Y(n_113)
);

INVx1_ASAP7_75t_SL g114 ( 
.A(n_102),
.Y(n_114)
);

AND2x2_ASAP7_75t_L g115 ( 
.A(n_110),
.B(n_73),
.Y(n_115)
);

NOR2x1_ASAP7_75t_L g116 ( 
.A(n_104),
.B(n_64),
.Y(n_116)
);

AOI221x1_ASAP7_75t_L g117 ( 
.A1(n_105),
.A2(n_108),
.B1(n_107),
.B2(n_99),
.C(n_100),
.Y(n_117)
);

NAND2xp5_ASAP7_75t_L g118 ( 
.A(n_106),
.B(n_5),
.Y(n_118)
);

NOR2xp33_ASAP7_75t_L g119 ( 
.A(n_109),
.B(n_6),
.Y(n_119)
);

AND2x2_ASAP7_75t_L g120 ( 
.A(n_107),
.B(n_73),
.Y(n_120)
);

OR2x2_ASAP7_75t_L g121 ( 
.A(n_109),
.B(n_7),
.Y(n_121)
);

OAI32xp33_ASAP7_75t_L g122 ( 
.A1(n_102),
.A2(n_74),
.A3(n_53),
.B1(n_8),
.B2(n_9),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_101),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_SL g124 ( 
.A(n_116),
.B(n_74),
.Y(n_124)
);

NOR2x1_ASAP7_75t_L g125 ( 
.A(n_121),
.B(n_72),
.Y(n_125)
);

INVx1_ASAP7_75t_L g126 ( 
.A(n_112),
.Y(n_126)
);

NAND3xp33_ASAP7_75t_L g127 ( 
.A(n_113),
.B(n_66),
.C(n_71),
.Y(n_127)
);

AND2x2_ASAP7_75t_L g128 ( 
.A(n_115),
.B(n_114),
.Y(n_128)
);

NOR3xp33_ASAP7_75t_L g129 ( 
.A(n_122),
.B(n_68),
.C(n_58),
.Y(n_129)
);

AND2x2_ASAP7_75t_L g130 ( 
.A(n_115),
.B(n_10),
.Y(n_130)
);

NOR3xp33_ASAP7_75t_L g131 ( 
.A(n_122),
.B(n_68),
.C(n_58),
.Y(n_131)
);

AOI21xp33_ASAP7_75t_L g132 ( 
.A1(n_119),
.A2(n_12),
.B(n_11),
.Y(n_132)
);

NAND2xp5_ASAP7_75t_SL g133 ( 
.A(n_121),
.B(n_82),
.Y(n_133)
);

INVx1_ASAP7_75t_SL g134 ( 
.A(n_111),
.Y(n_134)
);

NOR2x1_ASAP7_75t_L g135 ( 
.A(n_118),
.B(n_72),
.Y(n_135)
);

NAND3xp33_ASAP7_75t_L g136 ( 
.A(n_117),
.B(n_72),
.C(n_71),
.Y(n_136)
);

INVx1_ASAP7_75t_SL g137 ( 
.A(n_111),
.Y(n_137)
);

AOI21xp5_ASAP7_75t_L g138 ( 
.A1(n_124),
.A2(n_117),
.B(n_123),
.Y(n_138)
);

NAND3xp33_ASAP7_75t_SL g139 ( 
.A(n_134),
.B(n_137),
.C(n_124),
.Y(n_139)
);

AOI22xp5_ASAP7_75t_L g140 ( 
.A1(n_125),
.A2(n_120),
.B1(n_123),
.B2(n_82),
.Y(n_140)
);

OAI221xp5_ASAP7_75t_L g141 ( 
.A1(n_135),
.A2(n_68),
.B1(n_13),
.B2(n_11),
.C(n_12),
.Y(n_141)
);

NOR3xp33_ASAP7_75t_L g142 ( 
.A(n_127),
.B(n_132),
.C(n_130),
.Y(n_142)
);

OAI21xp5_ASAP7_75t_L g143 ( 
.A1(n_133),
.A2(n_71),
.B(n_72),
.Y(n_143)
);

NOR3xp33_ASAP7_75t_L g144 ( 
.A(n_129),
.B(n_131),
.C(n_136),
.Y(n_144)
);

NAND2xp5_ASAP7_75t_L g145 ( 
.A(n_128),
.B(n_13),
.Y(n_145)
);

AOI221xp5_ASAP7_75t_L g146 ( 
.A1(n_133),
.A2(n_72),
.B1(n_71),
.B2(n_82),
.C(n_14),
.Y(n_146)
);

OR2x6_ASAP7_75t_L g147 ( 
.A(n_143),
.B(n_82),
.Y(n_147)
);

NOR3xp33_ASAP7_75t_L g148 ( 
.A(n_139),
.B(n_126),
.C(n_71),
.Y(n_148)
);

OAI22xp5_ASAP7_75t_SL g149 ( 
.A1(n_141),
.A2(n_71),
.B1(n_16),
.B2(n_14),
.Y(n_149)
);

AO22x2_ASAP7_75t_L g150 ( 
.A1(n_138),
.A2(n_16),
.B1(n_20),
.B2(n_18),
.Y(n_150)
);

XNOR2xp5_ASAP7_75t_L g151 ( 
.A(n_145),
.B(n_23),
.Y(n_151)
);

NAND2xp5_ASAP7_75t_SL g152 ( 
.A(n_144),
.B(n_59),
.Y(n_152)
);

OAI22xp5_ASAP7_75t_L g153 ( 
.A1(n_148),
.A2(n_140),
.B1(n_146),
.B2(n_142),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_150),
.Y(n_154)
);

NAND4xp25_ASAP7_75t_L g155 ( 
.A(n_152),
.B(n_149),
.C(n_150),
.D(n_151),
.Y(n_155)
);

XNOR2xp5_ASAP7_75t_L g156 ( 
.A(n_155),
.B(n_147),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_154),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_157),
.Y(n_158)
);

OAI22xp33_ASAP7_75t_L g159 ( 
.A1(n_158),
.A2(n_153),
.B1(n_147),
.B2(n_156),
.Y(n_159)
);


endmodule