module fake_netlist_606_2484_n_25 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_25);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_25;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_10),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_12),
.C(n_14),
.Y(n_18)
);

AOI33xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_17),
.A3(n_15),
.B1(n_12),
.B2(n_5),
.B3(n_4),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

NAND4xp25_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_7),
.C(n_6),
.D(n_5),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.Y(n_24)
);

AOI322xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_3),
.C1(n_8),
.C2(n_23),
.Y(n_25)
);


endmodule