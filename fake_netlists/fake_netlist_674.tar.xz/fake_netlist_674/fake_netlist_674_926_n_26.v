module fake_netlist_674_926_n_26 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_26);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_26;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_4),
.B(n_3),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_6),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_11)
);

INVx4_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AO31x2_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_6),
.A3(n_5),
.B(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_9),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_11),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_15),
.B(n_14),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_16),
.B(n_14),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_18),
.B1(n_11),
.B2(n_7),
.C(n_8),
.Y(n_22)
);

NAND4xp75_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_5),
.C(n_2),
.D(n_0),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_0),
.B1(n_16),
.B2(n_23),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_22),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_16),
.B1(n_24),
.B2(n_22),
.Y(n_26)
);


endmodule