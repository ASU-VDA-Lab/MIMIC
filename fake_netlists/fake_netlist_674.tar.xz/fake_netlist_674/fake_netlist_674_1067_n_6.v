module fake_netlist_674_1067_n_6 (n_1, n_0, n_6);

input n_1;
input n_0;

output n_6;

wire n_4;
wire n_2;
wire n_5;
wire n_3;

NAND2xp5_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

OR2x2_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_SL g4 ( 
.A(n_3),
.Y(n_4)
);

AOI21xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

OAI22xp5_ASAP7_75t_SL g6 ( 
.A1(n_5),
.A2(n_4),
.B1(n_0),
.B2(n_1),
.Y(n_6)
);


endmodule