module fake_netlist_674_1732_n_38 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_38);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_38;

wire n_36;
wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

NOR2xp67_ASAP7_75t_L g21 ( 
.A(n_2),
.B(n_12),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_4),
.Y(n_22)
);

AOI21x1_ASAP7_75t_L g23 ( 
.A1(n_14),
.A2(n_6),
.B(n_15),
.Y(n_23)
);

CKINVDCx6p67_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_18),
.B(n_8),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_0),
.B(n_7),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_15),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_16),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_17),
.B1(n_16),
.B2(n_1),
.C(n_3),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_22),
.B1(n_25),
.B2(n_26),
.C(n_24),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_21),
.Y(n_31)
);

NOR2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_17),
.Y(n_32)
);

OA21x2_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B(n_23),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_5),
.Y(n_34)
);

CKINVDCx6p67_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

INVxp67_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_13),
.B1(n_11),
.B2(n_10),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_35),
.B1(n_20),
.B2(n_19),
.Y(n_38)
);


endmodule