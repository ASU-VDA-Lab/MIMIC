module fake_netlist_674_980_n_22 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_22);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_22;

wire n_18;
wire n_19;
wire n_15;
wire n_20;
wire n_16;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

OR2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_4),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_0),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_L g15 ( 
.A(n_1),
.B(n_2),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_7),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_7),
.B1(n_6),
.B2(n_3),
.Y(n_17)
);

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.Y(n_18)
);

XNOR2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_14),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

XOR2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_6),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_15),
.B1(n_16),
.B2(n_9),
.C1(n_8),
.C2(n_5),
.Y(n_22)
);


endmodule