module fake_netlist_674_1412_n_37 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_37);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_37;

wire n_36;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_1),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_18),
.B(n_4),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_2),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_21),
.A2(n_16),
.B(n_3),
.C(n_0),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_16),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

OR2x2_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_20),
.Y(n_29)
);

OR2x6_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_24),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_28),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_30),
.B1(n_25),
.B2(n_22),
.Y(n_32)
);

OAI211xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_23),
.B(n_7),
.C(n_5),
.Y(n_33)
);

OAI211xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_13),
.B(n_11),
.C(n_9),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_34),
.Y(n_35)
);

INVxp67_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_17),
.B1(n_15),
.B2(n_14),
.Y(n_37)
);


endmodule