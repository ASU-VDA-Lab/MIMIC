module fake_netlist_674_324_n_51 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_51);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_51;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_17;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_8),
.B(n_2),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_7),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

BUFx4f_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

AND2x6_ASAP7_75t_L g30 ( 
.A(n_18),
.B(n_3),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_29),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_28),
.B1(n_24),
.B2(n_19),
.C(n_23),
.Y(n_35)
);

NOR4xp25_ASAP7_75t_SL g36 ( 
.A(n_33),
.B(n_30),
.C(n_6),
.D(n_4),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_24),
.Y(n_37)
);

OAI33xp33_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_20),
.A3(n_30),
.B1(n_21),
.B2(n_18),
.B3(n_4),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_30),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_30),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_21),
.B(n_18),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_6),
.Y(n_42)
);

OAI22xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_21),
.B1(n_22),
.B2(n_17),
.Y(n_43)
);

AOI222xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_17),
.B1(n_22),
.B2(n_26),
.C1(n_16),
.C2(n_9),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

XNOR2xp5_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_10),
.Y(n_46)
);

XOR2xp5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_11),
.Y(n_47)
);

OAI221xp5_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_22),
.B1(n_17),
.B2(n_26),
.C(n_12),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

AOI222xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_22),
.B1(n_26),
.B2(n_47),
.C1(n_48),
.C2(n_49),
.Y(n_51)
);


endmodule