module fake_netlist_674_59_n_9 (n_1, n_2, n_0, n_9);

input n_1;
input n_2;
input n_0;

output n_9;

wire n_4;
wire n_7;
wire n_5;
wire n_8;
wire n_6;
wire n_3;

AND2x2_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

AOI22xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

OR2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_0),
.Y(n_6)
);

O2A1O1Ixp5_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_5),
.B(n_3),
.C(n_0),
.Y(n_7)
);

AND5x1_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_0),
.C(n_1),
.D(n_2),
.E(n_4),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B1(n_2),
.B2(n_5),
.Y(n_9)
);


endmodule