module fake_netlist_674_313_n_66 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_66);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_66;

wire n_36;
wire n_59;
wire n_62;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_64;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_60;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_63;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_65;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;
wire n_61;

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_8),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_14),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_1),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_16),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_0),
.B(n_13),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_2),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_20),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

BUFx4f_ASAP7_75t_L g37 ( 
.A(n_23),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_25),
.B(n_18),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_32),
.B(n_18),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_29),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_27),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_31),
.B(n_21),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_36),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

OAI22xp33_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_31),
.B1(n_34),
.B2(n_24),
.Y(n_45)
);

OA21x2_ASAP7_75t_L g46 ( 
.A1(n_39),
.A2(n_35),
.B(n_33),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_43),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_40),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_42),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_46),
.Y(n_52)
);

NAND2x1_ASAP7_75t_L g53 ( 
.A(n_52),
.B(n_46),
.Y(n_53)
);

O2A1O1Ixp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_52),
.B(n_39),
.C(n_51),
.Y(n_54)
);

OAI221xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_38),
.B1(n_46),
.B2(n_45),
.C(n_33),
.Y(n_55)
);

OAI21xp5_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_55),
.B(n_53),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

AOI21xp33_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_30),
.B(n_26),
.Y(n_58)
);

NAND2x1p5_ASAP7_75t_L g59 ( 
.A(n_57),
.B(n_23),
.Y(n_59)
);

NAND4xp25_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_28),
.C(n_37),
.D(n_3),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_SL g61 ( 
.A(n_58),
.B(n_5),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_59),
.Y(n_62)
);

AOI21x1_ASAP7_75t_L g63 ( 
.A1(n_61),
.A2(n_7),
.B(n_6),
.Y(n_63)
);

CKINVDCx6p67_ASAP7_75t_R g64 ( 
.A(n_60),
.Y(n_64)
);

OAI22xp5_ASAP7_75t_L g65 ( 
.A1(n_64),
.A2(n_17),
.B1(n_11),
.B2(n_10),
.Y(n_65)
);

AOI22xp33_ASAP7_75t_SL g66 ( 
.A1(n_65),
.A2(n_62),
.B1(n_64),
.B2(n_63),
.Y(n_66)
);


endmodule