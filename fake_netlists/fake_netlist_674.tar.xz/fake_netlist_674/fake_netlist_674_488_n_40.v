module fake_netlist_674_488_n_40 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_40);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_40;

wire n_36;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

BUFx10_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_17),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_1),
.C(n_0),
.Y(n_28)
);

BUFx4f_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_22),
.B(n_18),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_SL g33 ( 
.A(n_32),
.B(n_21),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_30),
.C(n_27),
.Y(n_35)
);

OAI221xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_31),
.B1(n_26),
.B2(n_23),
.C(n_24),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_19),
.B(n_18),
.Y(n_37)
);

AOI211xp5_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_19),
.B(n_27),
.C(n_2),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_38),
.B1(n_5),
.B2(n_4),
.Y(n_39)
);

AOI222xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_10),
.B1(n_8),
.B2(n_13),
.C1(n_16),
.C2(n_15),
.Y(n_40)
);


endmodule