module fake_netlist_674_1075_n_21 (n_4, n_1, n_2, n_0, n_5, n_3, n_21);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_10;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

A2O1A1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_3),
.A2(n_1),
.B(n_4),
.C(n_0),
.Y(n_10)
);

CKINVDCx6p67_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_10),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_10),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_0),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_12),
.C(n_14),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_14),
.C(n_15),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.B1(n_19),
.B2(n_16),
.Y(n_21)
);


endmodule