module fake_netlist_674_359_n_13 (n_4, n_1, n_2, n_0, n_3, n_13);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_13;

wire n_9;
wire n_7;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

AO31x2_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_3),
.A3(n_1),
.B(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NOR4xp25_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.C(n_5),
.D(n_6),
.Y(n_10)
);

XNOR2x1_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_0),
.Y(n_11)
);

INVxp33_ASAP7_75t_SL g12 ( 
.A(n_11),
.Y(n_12)
);

OAI222xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_1),
.B1(n_3),
.B2(n_4),
.C1(n_7),
.C2(n_11),
.Y(n_13)
);


endmodule