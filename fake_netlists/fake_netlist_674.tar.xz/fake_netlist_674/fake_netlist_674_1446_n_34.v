module fake_netlist_674_1446_n_34 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_34);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_34;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

INVx2_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_5),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_19),
.A2(n_9),
.B(n_0),
.Y(n_24)
);

A2O1A1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_6),
.B(n_4),
.C(n_1),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_SL g26 ( 
.A1(n_17),
.A2(n_16),
.B(n_6),
.C(n_4),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_22),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_28),
.B(n_26),
.Y(n_30)
);

NAND4xp25_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_29),
.C(n_23),
.D(n_17),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

OAI22x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_23),
.B1(n_21),
.B2(n_16),
.Y(n_33)
);

AOI222xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_11),
.B1(n_10),
.B2(n_12),
.C1(n_15),
.C2(n_14),
.Y(n_34)
);


endmodule