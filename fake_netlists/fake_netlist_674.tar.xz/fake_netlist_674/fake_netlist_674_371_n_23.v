module fake_netlist_674_371_n_23 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_23);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_23;

wire n_18;
wire n_19;
wire n_10;
wire n_15;
wire n_11;
wire n_20;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;

BUFx3_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx5_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_11),
.B1(n_12),
.B2(n_9),
.C(n_4),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_12),
.Y(n_16)
);

AOI21xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_14),
.B(n_12),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_12),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND5xp2_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_7),
.C(n_6),
.D(n_12),
.E(n_2),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_7),
.B(n_6),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_22),
.Y(n_23)
);


endmodule