module fake_netlist_674_107_n_52 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_52);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_52;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx2_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_8),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_3),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_2),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

INVx5_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_19),
.B(n_1),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_22),
.A2(n_16),
.B1(n_5),
.B2(n_1),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_25),
.B1(n_24),
.B2(n_26),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_24),
.Y(n_34)
);

OAI21x1_ASAP7_75t_L g35 ( 
.A1(n_30),
.A2(n_19),
.B(n_23),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx4_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_26),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_31),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_37),
.Y(n_41)
);

OAI221xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_31),
.B1(n_36),
.B2(n_21),
.C(n_20),
.Y(n_42)
);

OAI21xp33_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_35),
.B(n_17),
.Y(n_43)
);

OAI211xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_35),
.B(n_28),
.C(n_20),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_34),
.B1(n_28),
.B2(n_0),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_4),
.Y(n_46)
);

AOI21xp5_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_9),
.B(n_7),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_47),
.B1(n_14),
.B2(n_13),
.Y(n_51)
);

AOI21xp5_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_49),
.B(n_50),
.Y(n_52)
);


endmodule