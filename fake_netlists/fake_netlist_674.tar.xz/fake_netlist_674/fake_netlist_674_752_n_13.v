module fake_netlist_674_752_n_13 (n_1, n_2, n_0, n_13);

input n_1;
input n_2;
input n_0;

output n_13;

wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_6;
wire n_11;
wire n_12;
wire n_8;
wire n_9;
wire n_3;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

CKINVDCx11_ASAP7_75t_R g4 ( 
.A(n_1),
.Y(n_4)
);

INVx2_ASAP7_75t_SL g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_4),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

INVxp33_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_6),
.B(n_7),
.C(n_1),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);


endmodule