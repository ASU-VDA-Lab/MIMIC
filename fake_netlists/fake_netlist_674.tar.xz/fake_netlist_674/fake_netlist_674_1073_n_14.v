module fake_netlist_674_1073_n_14 (n_4, n_1, n_2, n_0, n_3, n_14);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_14;

wire n_9;
wire n_7;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B1(n_4),
.B2(n_0),
.Y(n_5)
);

OAI21xp33_ASAP7_75t_SL g6 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_5),
.Y(n_7)
);

O2A1O1Ixp5_ASAP7_75t_SL g8 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_2),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B(n_4),
.C(n_2),
.Y(n_11)
);

OAI211xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B(n_8),
.C(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B(n_10),
.Y(n_14)
);


endmodule