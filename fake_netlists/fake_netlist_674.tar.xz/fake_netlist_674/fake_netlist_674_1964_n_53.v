module fake_netlist_674_1964_n_53 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_53);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_53;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

AND2x2_ASAP7_75t_L g25 ( 
.A(n_0),
.B(n_17),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_16),
.B(n_1),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_13),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_SL g29 ( 
.A(n_9),
.B(n_24),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_2),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_18),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_11),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_12),
.Y(n_34)
);

AO22x1_ASAP7_75t_L g35 ( 
.A1(n_28),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_35)
);

INVx2_ASAP7_75t_SL g36 ( 
.A(n_31),
.Y(n_36)
);

BUFx4f_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_6),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_R g39 ( 
.A(n_36),
.B(n_29),
.Y(n_39)
);

INVx4_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_27),
.Y(n_41)
);

OAI211xp5_ASAP7_75t_SL g42 ( 
.A1(n_40),
.A2(n_38),
.B(n_35),
.C(n_30),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_33),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AOI211xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_26),
.B(n_25),
.C(n_32),
.Y(n_47)
);

O2A1O1Ixp33_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_10),
.B(n_8),
.C(n_7),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_47),
.Y(n_49)
);

NAND4xp25_ASAP7_75t_SL g50 ( 
.A(n_48),
.B(n_20),
.C(n_19),
.D(n_14),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_49),
.Y(n_51)
);

CKINVDCx20_ASAP7_75t_R g52 ( 
.A(n_50),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_SL g53 ( 
.A1(n_52),
.A2(n_22),
.B1(n_23),
.B2(n_51),
.Y(n_53)
);


endmodule