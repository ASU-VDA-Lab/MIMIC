module fake_netlist_674_1658_n_16 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_16);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_16;

wire n_14;
wire n_13;
wire n_10;
wire n_12;
wire n_15;
wire n_11;
wire n_9;

OAI221xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_3),
.B1(n_5),
.B2(n_4),
.C(n_2),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_4),
.A2(n_8),
.B1(n_0),
.B2(n_6),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_7),
.B(n_0),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_5),
.B(n_1),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

NAND4xp25_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.C(n_6),
.D(n_1),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_13),
.C(n_12),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);


endmodule