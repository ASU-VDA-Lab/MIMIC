module fake_netlist_674_622_n_29 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_29);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_29;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_26;

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_7),
.B(n_13),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

AO32x2_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_7),
.A3(n_5),
.B1(n_2),
.B2(n_3),
.Y(n_22)
);

OR2x6_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_18),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_22),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_20),
.B(n_19),
.C(n_6),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

OAI22x1_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_29)
);


endmodule