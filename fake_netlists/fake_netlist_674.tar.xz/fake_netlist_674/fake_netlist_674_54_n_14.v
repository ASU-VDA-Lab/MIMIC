module fake_netlist_674_54_n_14 (n_1, n_0, n_14);

input n_1;
input n_0;

output n_14;

wire n_9;
wire n_4;
wire n_7;
wire n_13;
wire n_2;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;
wire n_3;

INVx4_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVx3_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

AOI21xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

A2O1A1Ixp33_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_0),
.B(n_1),
.C(n_2),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_2),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

OAI22xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_2),
.B1(n_3),
.B2(n_0),
.Y(n_8)
);

OAI31xp33_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_3),
.A3(n_1),
.B(n_0),
.Y(n_9)
);

OAI222xp33_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_6),
.B1(n_7),
.B2(n_2),
.C1(n_3),
.C2(n_0),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B1(n_7),
.B2(n_2),
.Y(n_11)
);

NOR3x1_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_9),
.C(n_0),
.Y(n_12)
);

AND4x1_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_1),
.C(n_7),
.D(n_11),
.Y(n_13)
);

OA22x2_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_1),
.B1(n_11),
.B2(n_8),
.Y(n_14)
);


endmodule