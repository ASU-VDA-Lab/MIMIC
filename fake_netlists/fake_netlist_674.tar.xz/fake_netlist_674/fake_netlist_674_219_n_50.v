module fake_netlist_674_219_n_50 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_50);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_50;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx5_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

NAND2x1_ASAP7_75t_L g20 ( 
.A(n_8),
.B(n_15),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_0),
.A2(n_7),
.B1(n_13),
.B2(n_16),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

OA21x2_ASAP7_75t_L g24 ( 
.A1(n_3),
.A2(n_17),
.B(n_12),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_20),
.A2(n_4),
.B(n_1),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_20),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

NOR2x1_ASAP7_75t_SL g34 ( 
.A(n_33),
.B(n_22),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx2_ASAP7_75t_SL g36 ( 
.A(n_35),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_29),
.Y(n_37)
);

NOR2xp67_ASAP7_75t_SL g38 ( 
.A(n_36),
.B(n_24),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_29),
.B(n_24),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_37),
.B(n_21),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_30),
.Y(n_44)
);

O2A1O1Ixp33_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_30),
.B(n_23),
.C(n_19),
.Y(n_45)
);

INVx3_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

OAI21xp33_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_19),
.B(n_17),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_46),
.A2(n_11),
.B1(n_6),
.B2(n_5),
.Y(n_49)
);

OA22x2_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_46),
.B1(n_48),
.B2(n_47),
.Y(n_50)
);


endmodule