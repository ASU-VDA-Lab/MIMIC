module fake_netlist_624_2423_n_9 (n_1, n_0, n_9);

input n_1;
input n_0;

output n_9;

wire n_7;
wire n_8;
wire n_5;
wire n_6;
wire n_4;
wire n_2;
wire n_3;

INVx1_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

OAI21x1_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_3),
.Y(n_5)
);

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B1(n_4),
.B2(n_2),
.Y(n_6)
);

NOR2x1p5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);


endmodule