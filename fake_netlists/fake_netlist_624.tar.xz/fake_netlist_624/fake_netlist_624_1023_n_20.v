module fake_netlist_624_1023_n_20 (n_5, n_0, n_4, n_1, n_2, n_3, n_20);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_20;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_7;
wire n_19;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_2),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_R g7 ( 
.A(n_1),
.B(n_3),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_6),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_1),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_6),
.B1(n_9),
.B2(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_12),
.B1(n_7),
.B2(n_11),
.C(n_8),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.C(n_8),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_20)
);


endmodule