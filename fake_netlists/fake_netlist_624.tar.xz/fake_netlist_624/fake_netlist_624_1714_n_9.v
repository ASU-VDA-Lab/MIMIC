module fake_netlist_624_1714_n_9 (n_1, n_0, n_9);

input n_1;
input n_0;

output n_9;

wire n_7;
wire n_8;
wire n_5;
wire n_6;
wire n_4;
wire n_2;
wire n_3;

INVx3_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

BUFx4_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

NAND2x1p5_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_3),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

NAND3xp33_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_1),
.C(n_0),
.Y(n_6)
);

OAI21xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

BUFx4f_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);


endmodule