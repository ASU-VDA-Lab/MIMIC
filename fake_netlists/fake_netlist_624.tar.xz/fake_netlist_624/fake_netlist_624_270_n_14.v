module fake_netlist_624_270_n_14 (n_1, n_2, n_0, n_14);

input n_1;
input n_2;
input n_0;

output n_14;

wire n_7;
wire n_11;
wire n_9;
wire n_8;
wire n_5;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;
wire n_3;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

BUFx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x6_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_2),
.Y(n_5)
);

BUFx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_3),
.A2(n_2),
.B(n_5),
.Y(n_7)
);

NOR2x1_ASAP7_75t_R g8 ( 
.A(n_4),
.B(n_5),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_5),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NOR3xp33_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_9),
.C(n_6),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_7),
.B(n_11),
.Y(n_14)
);


endmodule