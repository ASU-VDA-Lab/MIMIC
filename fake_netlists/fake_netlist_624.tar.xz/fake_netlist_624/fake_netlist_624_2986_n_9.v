module fake_netlist_624_2986_n_9 (n_1, n_2, n_0, n_9);

input n_1;
input n_2;
input n_0;

output n_9;

wire n_7;
wire n_8;
wire n_5;
wire n_6;
wire n_4;
wire n_3;

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

INVx6_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_3),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_9)
);


endmodule