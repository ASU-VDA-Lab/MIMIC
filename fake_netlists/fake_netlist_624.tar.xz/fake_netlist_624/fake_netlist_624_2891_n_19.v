module fake_netlist_624_2891_n_19 (n_7, n_9, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_19);

input n_7;
input n_9;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_19;

wire n_11;
wire n_15;
wire n_18;
wire n_17;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

INVxp67_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B1(n_11),
.B2(n_7),
.C(n_0),
.Y(n_15)
);

OAI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_3),
.B2(n_2),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_5),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_9),
.C(n_6),
.Y(n_18)
);

XOR2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_10),
.Y(n_19)
);


endmodule