module fake_netlist_624_1383_n_20 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_20);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_20;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_9;
wire n_19;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

INVx8_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_9),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_12),
.Y(n_16)
);

NAND5xp2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_7),
.C(n_15),
.D(n_2),
.E(n_3),
.Y(n_17)
);

NOR2x1_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_10),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

OR2x6_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_6),
.Y(n_20)
);


endmodule