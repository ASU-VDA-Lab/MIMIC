module fake_netlist_819_2841_n_22 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_22);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

NAND2xp33_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_6),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_4),
.A2(n_5),
.B1(n_0),
.B2(n_6),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_1),
.Y(n_12)
);

A2O1A1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_7),
.A2(n_5),
.B(n_3),
.C(n_2),
.Y(n_13)
);

AO21x2_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_3),
.B(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AO21x2_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_7),
.B(n_8),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_14),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_8),
.Y(n_18)
);

NAND4xp25_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_11),
.C(n_17),
.D(n_16),
.Y(n_19)
);

AND2x2_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI22x1_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_16),
.B1(n_15),
.B2(n_18),
.Y(n_22)
);


endmodule