module fake_netlist_819_3482_n_35 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_35);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_35;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

AND2x2_ASAP7_75t_L g16 ( 
.A(n_1),
.B(n_7),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_15),
.Y(n_17)
);

BUFx8_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_0),
.B(n_6),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

OAI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_19),
.B1(n_21),
.B2(n_20),
.Y(n_25)
);

INVx6_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_16),
.B1(n_23),
.B2(n_18),
.Y(n_27)
);

NOR2x1_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_18),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_28),
.B(n_26),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_4),
.Y(n_30)
);

XOR2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_2),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OAI222xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_15),
.B1(n_4),
.B2(n_8),
.C1(n_5),
.C2(n_3),
.Y(n_34)
);

OAI321xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_33),
.A3(n_12),
.B1(n_9),
.B2(n_13),
.C(n_11),
.Y(n_35)
);


endmodule