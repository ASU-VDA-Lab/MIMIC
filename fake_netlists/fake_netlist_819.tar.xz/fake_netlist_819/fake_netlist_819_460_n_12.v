module fake_netlist_819_460_n_12 (n_2, n_0, n_1, n_12);

input n_2;
input n_0;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

BUFx3_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

OA21x2_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_5)
);

OAI22xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_4),
.Y(n_8)
);

AOI222xp33_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_3),
.B1(n_4),
.B2(n_2),
.C1(n_1),
.C2(n_5),
.Y(n_9)
);

NAND2x1p5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_4),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_4),
.B2(n_3),
.Y(n_11)
);

AOI222xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C1(n_7),
.C2(n_6),
.Y(n_12)
);


endmodule