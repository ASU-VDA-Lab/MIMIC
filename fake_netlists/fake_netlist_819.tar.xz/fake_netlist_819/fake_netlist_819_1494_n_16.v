module fake_netlist_819_1494_n_16 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_16);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_15;
wire n_13;
wire n_14;
wire n_12;
wire n_10;
wire n_11;
wire n_9;
wire n_8;

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_5),
.B(n_1),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_3),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_0),
.B1(n_4),
.B2(n_7),
.Y(n_10)
);

AO31x2_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_5),
.A3(n_4),
.B(n_1),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B1(n_10),
.B2(n_12),
.C(n_11),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B1(n_7),
.B2(n_6),
.Y(n_16)
);


endmodule