module fake_netlist_819_313_n_32 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_32);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_9;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

CKINVDCx16_ASAP7_75t_R g9 ( 
.A(n_8),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_3),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_2),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_4),
.B(n_3),
.C(n_1),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_SL g17 ( 
.A(n_10),
.B(n_4),
.C(n_1),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_15),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

XOR2xp5_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_9),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_15),
.B1(n_23),
.B2(n_13),
.Y(n_27)
);

O2A1O1Ixp33_ASAP7_75t_SL g28 ( 
.A1(n_26),
.A2(n_16),
.B(n_17),
.C(n_12),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_14),
.B1(n_11),
.B2(n_12),
.C(n_19),
.Y(n_29)
);

BUFx2_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_28),
.B1(n_20),
.B2(n_6),
.Y(n_32)
);


endmodule