module fake_netlist_819_1484_n_15 (n_2, n_0, n_3, n_1, n_15);

input n_2;
input n_0;
input n_3;
input n_1;

output n_15;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_SL g5 ( 
.A(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_1),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_SL g11 ( 
.A1(n_8),
.A2(n_5),
.B1(n_6),
.B2(n_2),
.Y(n_11)
);

OAI22xp33_ASAP7_75t_SL g12 ( 
.A1(n_10),
.A2(n_9),
.B1(n_8),
.B2(n_3),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_11),
.B(n_3),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);


endmodule