module fake_netlist_819_2455_n_27 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_27);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_21;
wire n_16;

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_12),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

CKINVDCx16_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx4_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_13),
.C(n_14),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_16),
.B1(n_17),
.B2(n_15),
.C(n_18),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OA22x2_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_3),
.B1(n_5),
.B2(n_4),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_11),
.B1(n_9),
.B2(n_6),
.Y(n_27)
);


endmodule