module fake_netlist_609_2314_n_20 (n_1, n_2, n_3, n_0, n_20);

input n_1;
input n_2;
input n_3;
input n_0;

output n_20;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_4;
wire n_7;
wire n_19;
wire n_10;
wire n_16;
wire n_5;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

INVx2_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_0),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_0),
.Y(n_6)
);

NAND3xp33_ASAP7_75t_SL g7 ( 
.A(n_5),
.B(n_1),
.C(n_0),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_4),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_7),
.B(n_9),
.C(n_10),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_10),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_13),
.B1(n_15),
.B2(n_12),
.C(n_0),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_15),
.B(n_12),
.Y(n_17)
);

AO22x2_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_2),
.B1(n_3),
.B2(n_18),
.Y(n_20)
);


endmodule