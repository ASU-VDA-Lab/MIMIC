module fake_netlist_609_1350_n_44 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_44);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_44;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_36;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_38;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_16),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_18),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_24),
.B(n_20),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_22),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_27),
.B(n_25),
.C(n_21),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_28),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_1),
.Y(n_36)
);

OAI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_6),
.B1(n_3),
.B2(n_2),
.Y(n_37)
);

XNOR2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_7),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

NOR3x1_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_11),
.C(n_8),
.Y(n_40)
);

NOR2xp67_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_13),
.Y(n_41)
);

OAI21xp5_ASAP7_75t_SL g42 ( 
.A1(n_40),
.A2(n_15),
.B(n_14),
.Y(n_42)
);

INVx1_ASAP7_75t_SL g43 ( 
.A(n_41),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_42),
.B1(n_19),
.B2(n_17),
.Y(n_44)
);


endmodule