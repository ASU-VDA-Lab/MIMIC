module fake_netlist_609_3908_n_53 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_53);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_53;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_42;
wire n_33;
wire n_41;

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_6),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_22),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_8),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_7),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_3),
.Y(n_30)
);

OAI22xp33_ASAP7_75t_L g31 ( 
.A1(n_21),
.A2(n_13),
.B1(n_2),
.B2(n_20),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_16),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_28),
.B(n_27),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_23),
.Y(n_34)
);

NOR2xp67_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_23),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_29),
.B1(n_25),
.B2(n_32),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_33),
.A2(n_27),
.B(n_24),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_36),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_27),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_38),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

OAI221xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_39),
.B1(n_9),
.B2(n_4),
.C(n_5),
.Y(n_45)
);

INVx3_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_11),
.B(n_10),
.Y(n_47)
);

NOR2x1_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_12),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

AOI22x1_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_48),
.B1(n_15),
.B2(n_14),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

AOI21xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_18),
.B(n_17),
.Y(n_52)
);

AOI21xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_51),
.B(n_19),
.Y(n_53)
);


endmodule