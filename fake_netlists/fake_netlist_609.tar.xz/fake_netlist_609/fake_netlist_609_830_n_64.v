module fake_netlist_609_830_n_64 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_64);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_64;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_18;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_58;
wire n_62;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_63;
wire n_26;
wire n_60;
wire n_19;
wire n_46;
wire n_38;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_14),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_5),
.B(n_1),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

AND3x1_ASAP7_75t_L g28 ( 
.A(n_21),
.B(n_6),
.C(n_4),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_SL g30 ( 
.A(n_17),
.B(n_16),
.C(n_4),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

OR2x6_ASAP7_75t_SL g33 ( 
.A(n_22),
.B(n_16),
.Y(n_33)
);

BUFx12f_ASAP7_75t_L g34 ( 
.A(n_19),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_23),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

CKINVDCx14_ASAP7_75t_R g37 ( 
.A(n_33),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_20),
.B1(n_18),
.B2(n_24),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_32),
.B(n_25),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_18),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_31),
.B(n_18),
.Y(n_41)
);

AO21x2_ASAP7_75t_L g42 ( 
.A1(n_30),
.A2(n_20),
.B(n_2),
.Y(n_42)
);

OA21x2_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_29),
.B(n_36),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_20),
.B1(n_31),
.B2(n_34),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

INVxp67_ASAP7_75t_L g46 ( 
.A(n_40),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_38),
.Y(n_48)
);

NAND2xp33_ASAP7_75t_SL g49 ( 
.A(n_44),
.B(n_42),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_46),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_50),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_43),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_43),
.Y(n_54)
);

OA22x2_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_37),
.B1(n_28),
.B2(n_49),
.Y(n_55)
);

OAI221xp5_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_28),
.B1(n_37),
.B2(n_31),
.C(n_42),
.Y(n_56)
);

XOR2xp5_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_40),
.Y(n_57)
);

NAND4xp25_ASAP7_75t_SL g58 ( 
.A(n_54),
.B(n_12),
.C(n_8),
.D(n_7),
.Y(n_58)
);

AO22x2_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_15),
.B1(n_53),
.B2(n_55),
.Y(n_59)
);

CKINVDCx5p33_ASAP7_75t_R g60 ( 
.A(n_58),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_56),
.B(n_48),
.Y(n_61)
);

AND2x4_ASAP7_75t_L g62 ( 
.A(n_61),
.B(n_60),
.Y(n_62)
);

HB1xp67_ASAP7_75t_L g63 ( 
.A(n_59),
.Y(n_63)
);

NAND3xp33_ASAP7_75t_L g64 ( 
.A(n_63),
.B(n_59),
.C(n_62),
.Y(n_64)
);


endmodule