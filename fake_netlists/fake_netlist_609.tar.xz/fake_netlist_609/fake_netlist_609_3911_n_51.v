module fake_netlist_609_3911_n_51 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_51);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_51;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_12),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_3),
.B(n_8),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_18),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_22),
.B(n_2),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_19),
.B(n_16),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_11),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_35),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

NOR3xp33_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_32),
.C(n_27),
.Y(n_41)
);

OA211x2_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_30),
.B(n_31),
.C(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_SL g43 ( 
.A(n_40),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NOR4xp25_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_25),
.C(n_28),
.D(n_24),
.Y(n_46)
);

OAI221xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_24),
.B1(n_4),
.B2(n_0),
.C(n_1),
.Y(n_47)
);

AO22x2_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_9),
.B1(n_7),
.B2(n_6),
.Y(n_48)
);

XNOR2x1_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_10),
.Y(n_49)
);

XNOR2xp5_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_14),
.Y(n_50)
);

AOI322xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_48),
.A3(n_20),
.B1(n_17),
.B2(n_15),
.C1(n_23),
.C2(n_21),
.Y(n_51)
);


endmodule