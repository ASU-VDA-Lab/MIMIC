module fake_netlist_609_126_n_41 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_17, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_41);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_17;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_41;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_10),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

OAI21x1_ASAP7_75t_L g20 ( 
.A1(n_9),
.A2(n_16),
.B(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_14),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_6),
.A2(n_0),
.B1(n_16),
.B2(n_12),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_24),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_23),
.B1(n_22),
.B2(n_18),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AO21x2_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_20),
.B(n_19),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_26),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_26),
.B1(n_19),
.B2(n_25),
.Y(n_34)
);

OAI21xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_25),
.B(n_15),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_32),
.B(n_25),
.Y(n_36)
);

A2O1A1Ixp33_ASAP7_75t_SL g37 ( 
.A1(n_34),
.A2(n_25),
.B(n_17),
.C(n_15),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_37),
.Y(n_38)
);

CKINVDCx20_ASAP7_75t_R g39 ( 
.A(n_36),
.Y(n_39)
);

NOR3xp33_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_39),
.C(n_17),
.Y(n_40)
);

AOI322xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_25),
.A3(n_5),
.B1(n_4),
.B2(n_1),
.C1(n_13),
.C2(n_11),
.Y(n_41)
);


endmodule