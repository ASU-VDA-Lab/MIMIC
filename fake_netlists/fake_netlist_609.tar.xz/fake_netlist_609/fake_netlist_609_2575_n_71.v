module fake_netlist_609_2575_n_71 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_71);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_71;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_58;
wire n_62;
wire n_67;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_65;
wire n_69;
wire n_25;
wire n_63;
wire n_26;
wire n_60;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_70;
wire n_43;
wire n_56;
wire n_20;
wire n_66;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_64;
wire n_68;

INVx1_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_10),
.B(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_13),
.B(n_11),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_17),
.A2(n_1),
.B1(n_16),
.B2(n_11),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

NAND2x1p5_ASAP7_75t_L g32 ( 
.A(n_24),
.B(n_0),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_22),
.B(n_0),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_20),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_34)
);

BUFx12f_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_21),
.B(n_3),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_20),
.B(n_5),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_30),
.A2(n_26),
.B1(n_29),
.B2(n_24),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_19),
.B(n_16),
.Y(n_39)
);

OAI22xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_27),
.B1(n_23),
.B2(n_25),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_35),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_SL g42 ( 
.A1(n_32),
.A2(n_27),
.B1(n_24),
.B2(n_23),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_31),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_37),
.B(n_28),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_37),
.B(n_17),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_41),
.Y(n_48)
);

INVx1_ASAP7_75t_SL g49 ( 
.A(n_41),
.Y(n_49)
);

OAI22xp5_ASAP7_75t_L g50 ( 
.A1(n_42),
.A2(n_32),
.B1(n_33),
.B2(n_34),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

NAND4xp25_ASAP7_75t_SL g52 ( 
.A(n_49),
.B(n_44),
.C(n_45),
.D(n_40),
.Y(n_52)
);

INVxp67_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

AND2x2_ASAP7_75t_SL g54 ( 
.A(n_50),
.B(n_39),
.Y(n_54)
);

BUFx2_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

OAI22xp5_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_32),
.B1(n_45),
.B2(n_44),
.Y(n_56)
);

AND2x2_ASAP7_75t_SL g57 ( 
.A(n_51),
.B(n_39),
.Y(n_57)
);

INVx2_ASAP7_75t_SL g58 ( 
.A(n_52),
.Y(n_58)
);

AOI221xp5_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_52),
.B1(n_39),
.B2(n_49),
.C(n_37),
.Y(n_59)
);

AOI21xp5_ASAP7_75t_L g60 ( 
.A1(n_56),
.A2(n_47),
.B(n_31),
.Y(n_60)
);

AOI221x1_ASAP7_75t_L g61 ( 
.A1(n_58),
.A2(n_31),
.B1(n_36),
.B2(n_35),
.C(n_18),
.Y(n_61)
);

OAI221xp5_ASAP7_75t_SL g62 ( 
.A1(n_55),
.A2(n_18),
.B1(n_31),
.B2(n_40),
.C(n_38),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_57),
.B(n_31),
.Y(n_63)
);

CKINVDCx5p33_ASAP7_75t_R g64 ( 
.A(n_63),
.Y(n_64)
);

CKINVDCx5p33_ASAP7_75t_R g65 ( 
.A(n_60),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_59),
.B(n_57),
.Y(n_66)
);

BUFx4f_ASAP7_75t_SL g67 ( 
.A(n_62),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_65),
.Y(n_68)
);

NAND2xp5_ASAP7_75t_L g69 ( 
.A(n_67),
.B(n_61),
.Y(n_69)
);

INVx1_ASAP7_75t_SL g70 ( 
.A(n_64),
.Y(n_70)
);

OAI221xp5_ASAP7_75t_R g71 ( 
.A1(n_69),
.A2(n_66),
.B1(n_67),
.B2(n_68),
.C(n_70),
.Y(n_71)
);


endmodule