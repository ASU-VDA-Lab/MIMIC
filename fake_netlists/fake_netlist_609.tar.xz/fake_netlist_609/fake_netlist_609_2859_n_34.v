module fake_netlist_609_2859_n_34 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_34);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_34;

wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;
wire n_14;
wire n_13;
wire n_12;

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_3),
.A2(n_8),
.B1(n_0),
.B2(n_1),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_7),
.Y(n_18)
);

OAI22x1_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_4),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_6),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_R g23 ( 
.A(n_21),
.B(n_15),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_17),
.Y(n_24)
);

NOR2x1_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_20),
.B1(n_17),
.B2(n_13),
.C(n_16),
.Y(n_27)
);

OAI21xp33_ASAP7_75t_SL g28 ( 
.A1(n_26),
.A2(n_16),
.B(n_19),
.Y(n_28)
);

AOI211xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B(n_18),
.C(n_16),
.Y(n_29)
);

OAI21x1_ASAP7_75t_SL g30 ( 
.A1(n_27),
.A2(n_25),
.B(n_6),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OAI22x1_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_25),
.B1(n_9),
.B2(n_8),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_11),
.B2(n_10),
.Y(n_34)
);


endmodule