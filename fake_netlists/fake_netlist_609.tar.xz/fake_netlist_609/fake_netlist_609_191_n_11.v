module fake_netlist_609_191_n_11 (n_1, n_0, n_11);

input n_1;
input n_0;

output n_11;

wire n_7;
wire n_9;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_2;
wire n_3;

INVxp33_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

CKINVDCx5p33_ASAP7_75t_R g3 ( 
.A(n_1),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);

AOI22xp33_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.Y(n_5)
);

AO31x2_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_0),
.A3(n_1),
.B(n_5),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_0),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.Y(n_10)
);

XNOR2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_6),
.Y(n_11)
);


endmodule