module fake_netlist_609_2237_n_63 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_63);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_63;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_18;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_58;
wire n_62;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_60;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_4),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_8),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_9),
.B(n_5),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_7),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

INVx6_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

INVx4_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

BUFx12f_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_R g33 ( 
.A(n_17),
.B(n_26),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_18),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_30),
.B(n_20),
.Y(n_36)
);

INVx4_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_30),
.B(n_19),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_33),
.Y(n_39)
);

OAI22xp33_ASAP7_75t_L g40 ( 
.A1(n_28),
.A2(n_19),
.B1(n_22),
.B2(n_25),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_28),
.B(n_25),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_34),
.B1(n_35),
.B2(n_22),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_36),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_35),
.C(n_31),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_39),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_37),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_43),
.B(n_37),
.Y(n_49)
);

INVx3_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

NAND4xp25_ASAP7_75t_SL g53 ( 
.A(n_49),
.B(n_16),
.C(n_6),
.D(n_4),
.Y(n_53)
);

NOR2x1_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_0),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_52),
.Y(n_55)
);

INVx5_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_51),
.Y(n_57)
);

CKINVDCx5p33_ASAP7_75t_R g58 ( 
.A(n_57),
.Y(n_58)
);

OAI221xp5_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_29),
.B1(n_16),
.B2(n_1),
.C(n_12),
.Y(n_59)
);

AOI22xp33_ASAP7_75t_R g60 ( 
.A1(n_56),
.A2(n_29),
.B1(n_55),
.B2(n_54),
.Y(n_60)
);

HB1xp67_ASAP7_75t_L g61 ( 
.A(n_57),
.Y(n_61)
);

HB1xp67_ASAP7_75t_L g62 ( 
.A(n_58),
.Y(n_62)
);

AOI22xp5_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_59),
.B1(n_61),
.B2(n_60),
.Y(n_63)
);


endmodule