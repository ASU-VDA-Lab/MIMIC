module fake_netlist_609_184_n_37 (n_7, n_9, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_37);

input n_7;
input n_9;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_37;

wire n_11;
wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;
wire n_14;
wire n_13;
wire n_12;

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_1),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_0),
.Y(n_17)
);

INVx5_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

NOR2xp67_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_1),
.Y(n_19)
);

INVx5_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_16),
.B(n_2),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_R g23 ( 
.A(n_21),
.B(n_4),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_22),
.A2(n_21),
.B1(n_20),
.B2(n_18),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_26),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_5),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_23),
.Y(n_30)
);

OA22x2_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_6),
.B1(n_5),
.B2(n_9),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_29),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_R g36 ( 
.A1(n_35),
.A2(n_10),
.B1(n_20),
.B2(n_34),
.Y(n_36)
);

XNOR2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_33),
.Y(n_37)
);


endmodule