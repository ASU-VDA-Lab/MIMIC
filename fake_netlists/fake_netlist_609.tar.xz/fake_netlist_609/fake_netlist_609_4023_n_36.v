module fake_netlist_609_4023_n_36 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_36);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_36;

wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;
wire n_14;
wire n_13;
wire n_12;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_11),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_6),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

AND2x6_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_3),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_14),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_16),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_21),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

NOR3xp33_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_13),
.C(n_23),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_23),
.B1(n_13),
.B2(n_18),
.C(n_15),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_19),
.B1(n_18),
.B2(n_12),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_19),
.Y(n_33)
);

NAND3xp33_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_18),
.C(n_12),
.Y(n_34)
);

OAI21xp5_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_17),
.B(n_8),
.Y(n_35)
);

XNOR2x1_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_33),
.Y(n_36)
);


endmodule