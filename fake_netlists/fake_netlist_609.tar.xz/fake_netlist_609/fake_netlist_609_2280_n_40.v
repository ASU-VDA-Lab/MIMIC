module fake_netlist_609_2280_n_40 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_40);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_40;

wire n_31;
wire n_37;
wire n_39;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

NOR2xp67_ASAP7_75t_L g17 ( 
.A(n_11),
.B(n_9),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_10),
.B(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_9),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_6),
.B(n_5),
.Y(n_23)
);

NAND2x1p5_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_7),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_18),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_25)
);

OA22x2_ASAP7_75t_L g26 ( 
.A1(n_20),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_R g28 ( 
.A(n_24),
.B(n_21),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_19),
.Y(n_34)
);

OAI321xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_18),
.A3(n_22),
.B1(n_28),
.B2(n_23),
.C(n_17),
.Y(n_35)
);

O2A1O1Ixp33_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_33),
.B(n_17),
.C(n_28),
.Y(n_36)
);

CKINVDCx16_ASAP7_75t_R g37 ( 
.A(n_36),
.Y(n_37)
);

NOR3x1_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_4),
.C(n_3),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_4),
.Y(n_39)
);

AOI222xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.B1(n_16),
.B2(n_10),
.C1(n_14),
.C2(n_8),
.Y(n_40)
);


endmodule