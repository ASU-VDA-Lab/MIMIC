module fake_netlist_609_2655_n_35 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_35);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_35;

wire n_11;
wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;
wire n_14;
wire n_13;
wire n_12;

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_3),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_1),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_SL g15 ( 
.A1(n_1),
.A2(n_2),
.B1(n_5),
.B2(n_8),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_5),
.C(n_4),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_5),
.B(n_4),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_16),
.Y(n_22)
);

BUFx4f_ASAP7_75t_SL g23 ( 
.A(n_19),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_SL g24 ( 
.A(n_21),
.B(n_14),
.C(n_10),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_24),
.B1(n_20),
.B2(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

OAI211xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_14),
.B(n_11),
.C(n_10),
.Y(n_27)
);

AOI31xp33_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_11),
.A3(n_12),
.B(n_15),
.Y(n_28)
);

OA22x2_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_26),
.B1(n_19),
.B2(n_17),
.Y(n_29)
);

OAI211xp5_ASAP7_75t_SL g30 ( 
.A1(n_28),
.A2(n_18),
.B(n_17),
.C(n_4),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_29),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_29),
.Y(n_33)
);

OAI22x1_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_28),
.B1(n_18),
.B2(n_6),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_32),
.B1(n_33),
.B2(n_31),
.Y(n_35)
);


endmodule