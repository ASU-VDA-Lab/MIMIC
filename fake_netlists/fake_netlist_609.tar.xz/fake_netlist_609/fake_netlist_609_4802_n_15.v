module fake_netlist_609_4802_n_15 (n_0, n_4, n_1, n_2, n_3, n_15);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_15;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_12;

AND2x6_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_1),
.Y(n_5)
);

AND2x6_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_2),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_1),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_3),
.Y(n_10)
);

OR2x2_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AO22x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_6),
.B1(n_11),
.B2(n_10),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_6),
.Y(n_14)
);

XOR2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);


endmodule