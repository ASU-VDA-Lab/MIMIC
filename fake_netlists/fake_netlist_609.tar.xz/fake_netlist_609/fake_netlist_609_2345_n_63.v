module fake_netlist_609_2345_n_63 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_63);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_63;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_58;
wire n_27;
wire n_28;
wire n_62;
wire n_52;
wire n_49;
wire n_24;
wire n_48;
wire n_35;
wire n_45;
wire n_51;
wire n_25;
wire n_26;
wire n_60;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_34;

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_12),
.B(n_14),
.Y(n_23)
);

CKINVDCx6p67_ASAP7_75t_R g24 ( 
.A(n_13),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_17),
.B(n_18),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_3),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_0),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_0),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_1),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

INVxp67_ASAP7_75t_SL g34 ( 
.A(n_21),
.Y(n_34)
);

NAND2x1_ASAP7_75t_L g35 ( 
.A(n_22),
.B(n_2),
.Y(n_35)
);

INVx4_ASAP7_75t_L g36 ( 
.A(n_22),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_26),
.B1(n_25),
.B2(n_21),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_29),
.B(n_23),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_L g40 ( 
.A1(n_33),
.A2(n_30),
.B1(n_25),
.B2(n_32),
.C(n_31),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_33),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

BUFx6f_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_41),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

AOI321xp33_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_40),
.A3(n_41),
.B1(n_29),
.B2(n_43),
.C(n_20),
.Y(n_48)
);

AOI211xp5_ASAP7_75t_L g49 ( 
.A1(n_44),
.A2(n_40),
.B(n_43),
.C(n_21),
.Y(n_49)
);

AOI21xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_44),
.B(n_43),
.Y(n_50)
);

AOI221xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_43),
.B1(n_21),
.B2(n_36),
.C(n_20),
.Y(n_51)
);

AOI322xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_43),
.A3(n_28),
.B1(n_19),
.B2(n_16),
.C1(n_24),
.C2(n_36),
.Y(n_52)
);

A2O1A1Ixp33_ASAP7_75t_L g53 ( 
.A1(n_47),
.A2(n_43),
.B(n_28),
.C(n_36),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

AOI221xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_19),
.B1(n_16),
.B2(n_24),
.C(n_4),
.Y(n_55)
);

NOR3xp33_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_7),
.C(n_5),
.Y(n_56)
);

INVxp67_ASAP7_75t_SL g57 ( 
.A(n_52),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

XNOR2xp5_ASAP7_75t_L g60 ( 
.A(n_57),
.B(n_10),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

OAI22xp5_ASAP7_75t_SL g62 ( 
.A1(n_60),
.A2(n_55),
.B1(n_15),
.B2(n_11),
.Y(n_62)
);

AOI22xp33_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_59),
.B1(n_60),
.B2(n_61),
.Y(n_63)
);


endmodule