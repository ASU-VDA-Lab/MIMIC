module fake_netlist_609_2056_n_18 (n_5, n_0, n_4, n_1, n_2, n_3, n_18);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_18;

wire n_7;
wire n_9;
wire n_11;
wire n_16;
wire n_8;
wire n_15;
wire n_14;
wire n_17;
wire n_10;
wire n_13;
wire n_6;
wire n_12;

AO22x2_ASAP7_75t_L g6 ( 
.A1(n_0),
.A2(n_1),
.B1(n_4),
.B2(n_3),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_2),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B1(n_7),
.B2(n_9),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_11),
.B1(n_6),
.B2(n_16),
.Y(n_18)
);


endmodule