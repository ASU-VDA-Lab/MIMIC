module fake_netlist_609_1875_n_82 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_82);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_82;

wire n_75;
wire n_37;
wire n_54;
wire n_44;
wire n_36;
wire n_65;
wire n_63;
wire n_47;
wire n_57;
wire n_55;
wire n_76;
wire n_64;
wire n_68;
wire n_81;
wire n_39;
wire n_53;
wire n_77;
wire n_29;
wire n_27;
wire n_35;
wire n_80;
wire n_69;
wire n_78;
wire n_71;
wire n_42;
wire n_59;
wire n_50;
wire n_58;
wire n_28;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_45;
wire n_73;
wire n_56;
wire n_66;
wire n_32;
wire n_23;
wire n_33;
wire n_41;
wire n_34;
wire n_31;
wire n_79;
wire n_40;
wire n_21;
wire n_30;
wire n_22;
wire n_61;
wire n_62;
wire n_70;
wire n_67;
wire n_48;
wire n_25;
wire n_26;
wire n_60;
wire n_38;
wire n_46;
wire n_43;
wire n_74;
wire n_72;

BUFx2_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_14),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_4),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_10),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_15),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_18),
.B(n_3),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_17),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_8),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_6),
.B(n_20),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_17),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_12),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_11),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_23),
.Y(n_36)
);

NOR3xp33_ASAP7_75t_SL g37 ( 
.A(n_33),
.B(n_19),
.C(n_18),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_26),
.Y(n_38)
);

OR2x6_ASAP7_75t_L g39 ( 
.A(n_21),
.B(n_19),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_24),
.B(n_0),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_30),
.B(n_1),
.Y(n_41)
);

BUFx10_ASAP7_75t_L g42 ( 
.A(n_26),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_26),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_35),
.Y(n_44)
);

INVx5_ASAP7_75t_L g45 ( 
.A(n_22),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_34),
.Y(n_46)
);

NAND3x1_ASAP7_75t_L g47 ( 
.A(n_40),
.B(n_29),
.C(n_25),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_38),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_38),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_39),
.B(n_32),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_38),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_39),
.A2(n_32),
.B1(n_29),
.B2(n_22),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_43),
.Y(n_53)
);

INVxp67_ASAP7_75t_SL g54 ( 
.A(n_48),
.Y(n_54)
);

AOI221xp5_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_37),
.B1(n_36),
.B2(n_44),
.C(n_40),
.Y(n_55)
);

OR2x2_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_39),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

OAI33xp33_ASAP7_75t_L g58 ( 
.A1(n_49),
.A2(n_46),
.A3(n_41),
.B1(n_28),
.B2(n_27),
.B3(n_42),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_50),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

AOI31xp67_ASAP7_75t_SL g61 ( 
.A1(n_58),
.A2(n_47),
.A3(n_46),
.B(n_51),
.Y(n_61)
);

AND2x2_ASAP7_75t_L g62 ( 
.A(n_55),
.B(n_51),
.Y(n_62)
);

NOR3xp33_ASAP7_75t_SL g63 ( 
.A(n_54),
.B(n_42),
.C(n_22),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_60),
.Y(n_64)
);

INVxp67_ASAP7_75t_L g65 ( 
.A(n_59),
.Y(n_65)
);

OAI21xp5_ASAP7_75t_L g66 ( 
.A1(n_62),
.A2(n_45),
.B(n_31),
.Y(n_66)
);

AOI21xp5_ASAP7_75t_L g67 ( 
.A1(n_62),
.A2(n_45),
.B(n_31),
.Y(n_67)
);

AND2x4_ASAP7_75t_L g68 ( 
.A(n_59),
.B(n_2),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_64),
.Y(n_69)
);

AOI32xp33_ASAP7_75t_L g70 ( 
.A1(n_68),
.A2(n_61),
.A3(n_63),
.B1(n_31),
.B2(n_5),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_65),
.Y(n_71)
);

CKINVDCx5p33_ASAP7_75t_R g72 ( 
.A(n_68),
.Y(n_72)
);

CKINVDCx14_ASAP7_75t_R g73 ( 
.A(n_67),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_69),
.Y(n_74)
);

CKINVDCx5p33_ASAP7_75t_R g75 ( 
.A(n_72),
.Y(n_75)
);

AND2x4_ASAP7_75t_L g76 ( 
.A(n_71),
.B(n_66),
.Y(n_76)
);

INVxp67_ASAP7_75t_L g77 ( 
.A(n_73),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_73),
.Y(n_78)
);

OAI222xp33_ASAP7_75t_L g79 ( 
.A1(n_78),
.A2(n_70),
.B1(n_77),
.B2(n_76),
.C1(n_74),
.C2(n_75),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_76),
.Y(n_80)
);

CKINVDCx20_ASAP7_75t_R g81 ( 
.A(n_75),
.Y(n_81)
);

AOI322xp5_ASAP7_75t_L g82 ( 
.A1(n_80),
.A2(n_7),
.A3(n_13),
.B1(n_45),
.B2(n_61),
.C1(n_79),
.C2(n_81),
.Y(n_82)
);


endmodule