module fake_netlist_738_1481_n_19 (n_1, n_2, n_3, n_4, n_0, n_19);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_19;

wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_12;
wire n_15;
wire n_8;

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

AND2x6_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_0),
.Y(n_6)
);

AND2x6_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_1),
.B(n_3),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_3),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

OA21x2_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_6),
.B(n_7),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_11),
.Y(n_16)
);

OAI22xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_12),
.B1(n_9),
.B2(n_13),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.B1(n_9),
.B2(n_5),
.C1(n_8),
.C2(n_6),
.Y(n_19)
);


endmodule