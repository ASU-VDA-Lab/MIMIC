module fake_netlist_738_1116_n_22 (n_1, n_2, n_3, n_4, n_5, n_0, n_22);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_22;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_8;

INVxp33_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

O2A1O1Ixp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.C(n_2),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_11),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_7),
.B2(n_9),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_SL g17 ( 
.A1(n_15),
.A2(n_12),
.B1(n_7),
.B2(n_10),
.Y(n_17)
);

NAND2xp33_ASAP7_75t_R g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_14),
.B(n_12),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_14),
.Y(n_20)
);

AOI22x1_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_20),
.B1(n_5),
.B2(n_4),
.Y(n_22)
);


endmodule