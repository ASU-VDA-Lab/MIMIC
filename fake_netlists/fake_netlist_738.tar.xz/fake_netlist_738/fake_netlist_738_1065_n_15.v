module fake_netlist_738_1065_n_15 (n_1, n_2, n_3, n_4, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_11;
wire n_9;
wire n_10;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

INVx2_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_1),
.A2(n_3),
.B1(n_0),
.B2(n_2),
.Y(n_7)
);

A2O1A1Ixp33_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B(n_2),
.C(n_0),
.Y(n_8)
);

CKINVDCx11_ASAP7_75t_R g9 ( 
.A(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND4xp25_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_7),
.C(n_10),
.D(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_9),
.B1(n_1),
.B2(n_3),
.Y(n_15)
);


endmodule