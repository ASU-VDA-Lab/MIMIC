module fake_netlist_738_517_n_35 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_35);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_35;

wire n_20;
wire n_23;
wire n_22;
wire n_34;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

INVx2_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_11),
.B(n_2),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_4),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_24),
.B(n_0),
.Y(n_26)
);

INVx4_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

OAI21x1_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_20),
.B(n_19),
.Y(n_28)
);

CKINVDCx16_ASAP7_75t_R g29 ( 
.A(n_27),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_21),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B1(n_23),
.B2(n_18),
.C1(n_22),
.C2(n_1),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

AOI222xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_13),
.B1(n_12),
.B2(n_15),
.C1(n_17),
.C2(n_16),
.Y(n_35)
);


endmodule