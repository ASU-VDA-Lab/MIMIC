module fake_netlist_738_16_n_24 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_24);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_24;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

INVx2_ASAP7_75t_SL g13 ( 
.A(n_0),
.Y(n_13)
);

XNOR2xp5_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_2),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

AND3x2_ASAP7_75t_L g16 ( 
.A(n_6),
.B(n_8),
.C(n_10),
.Y(n_16)
);

INVx4_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_3),
.B(n_1),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_14),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_18),
.B(n_15),
.Y(n_21)
);

OAI21xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_16),
.B(n_6),
.Y(n_22)
);

O2A1O1Ixp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_11),
.B(n_9),
.C(n_5),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_7),
.B(n_12),
.Y(n_24)
);


endmodule