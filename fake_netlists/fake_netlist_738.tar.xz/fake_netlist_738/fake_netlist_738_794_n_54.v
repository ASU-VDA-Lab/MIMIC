module fake_netlist_738_794_n_54 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_54);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_54;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_42;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_41;
wire n_19;
wire n_29;
wire n_47;
wire n_52;
wire n_32;

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_4),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

NAND2x1_ASAP7_75t_L g30 ( 
.A(n_20),
.B(n_16),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_22),
.B(n_18),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_21),
.B(n_0),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_2),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_24),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

BUFx4f_ASAP7_75t_SL g37 ( 
.A(n_31),
.Y(n_37)
);

INVxp67_ASAP7_75t_SL g38 ( 
.A(n_34),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_23),
.Y(n_39)
);

AO21x2_ASAP7_75t_L g40 ( 
.A1(n_35),
.A2(n_32),
.B(n_25),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_40),
.Y(n_42)
);

INVxp67_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_41),
.B(n_19),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_SL g45 ( 
.A1(n_42),
.A2(n_26),
.B(n_28),
.Y(n_45)
);

OAI21xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_43),
.B(n_37),
.Y(n_46)
);

OAI211xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_37),
.B(n_6),
.C(n_3),
.Y(n_47)
);

NAND2xp33_ASAP7_75t_R g48 ( 
.A(n_45),
.B(n_8),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_14),
.B1(n_12),
.B2(n_10),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_48),
.Y(n_50)
);

INVx8_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

INVxp33_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_17),
.B1(n_51),
.B2(n_52),
.Y(n_54)
);


endmodule