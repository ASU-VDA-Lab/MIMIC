module fake_netlist_738_1047_n_52 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_52);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_52;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_0),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx3_ASAP7_75t_SL g28 ( 
.A(n_24),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_25),
.Y(n_29)
);

CKINVDCx8_ASAP7_75t_R g30 ( 
.A(n_16),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_19),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_31)
);

AO31x2_ASAP7_75t_L g32 ( 
.A1(n_26),
.A2(n_19),
.A3(n_20),
.B(n_22),
.Y(n_32)
);

NAND2x1p5_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_20),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_18),
.B1(n_23),
.B2(n_22),
.C(n_21),
.Y(n_34)
);

OAI22xp33_ASAP7_75t_L g35 ( 
.A1(n_28),
.A2(n_17),
.B1(n_22),
.B2(n_21),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_35),
.B(n_30),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

OAI21xp5_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_27),
.B(n_22),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_30),
.Y(n_39)
);

NAND2xp33_ASAP7_75t_SL g40 ( 
.A(n_36),
.B(n_28),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_32),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_31),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_41),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_38),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_4),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_21),
.B1(n_32),
.B2(n_14),
.Y(n_46)
);

AOI31xp33_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_7),
.A3(n_6),
.B(n_3),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_45),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_46),
.Y(n_49)
);

OAI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_47),
.A2(n_21),
.B1(n_12),
.B2(n_11),
.Y(n_50)
);

NOR2xp67_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_13),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_50),
.B1(n_49),
.B2(n_48),
.Y(n_52)
);


endmodule