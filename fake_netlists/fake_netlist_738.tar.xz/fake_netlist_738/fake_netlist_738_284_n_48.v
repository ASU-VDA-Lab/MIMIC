module fake_netlist_738_284_n_48 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_48);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_48;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_39;
wire n_34;
wire n_18;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_10),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_2),
.B(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_3),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

BUFx4f_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_26),
.Y(n_32)
);

OAI22xp33_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_20),
.B1(n_19),
.B2(n_21),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_27),
.A2(n_31),
.B(n_30),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_26),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_32),
.A2(n_29),
.B1(n_27),
.B2(n_30),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_29),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_35),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_33),
.Y(n_39)
);

OAI21xp5_ASAP7_75t_SL g40 ( 
.A1(n_38),
.A2(n_24),
.B(n_23),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

OAI311xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_9),
.A3(n_2),
.B1(n_15),
.C1(n_17),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_24),
.B1(n_34),
.B2(n_18),
.Y(n_43)
);

NOR2x1p5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_17),
.Y(n_44)
);

CKINVDCx20_ASAP7_75t_R g45 ( 
.A(n_43),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_0),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_8),
.B1(n_5),
.B2(n_4),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_12),
.B1(n_47),
.B2(n_44),
.Y(n_48)
);


endmodule