module fake_netlist_738_1856_n_36 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_36);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_36;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_34;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx8_ASAP7_75t_R g17 ( 
.A(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_14),
.B(n_16),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_10),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_8),
.B(n_3),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_4),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_20),
.B(n_1),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_19),
.A2(n_15),
.B1(n_5),
.B2(n_4),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_24),
.C(n_18),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_22),
.C(n_17),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_25),
.Y(n_30)
);

NAND4xp25_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_29),
.C(n_23),
.D(n_21),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_21),
.B1(n_26),
.B2(n_5),
.C(n_16),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_32),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_7),
.B(n_2),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_33),
.B1(n_12),
.B2(n_9),
.Y(n_36)
);


endmodule