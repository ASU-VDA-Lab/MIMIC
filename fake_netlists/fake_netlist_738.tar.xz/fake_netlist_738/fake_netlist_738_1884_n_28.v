module fake_netlist_738_1884_n_28 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_28);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_28;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_27;
wire n_24;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

INVx8_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_6),
.B(n_12),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

INVx5_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_3),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_4),
.B(n_0),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_1),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_22),
.B(n_14),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_20),
.B1(n_19),
.B2(n_16),
.C(n_18),
.Y(n_25)
);

NOR2xp67_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_1),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_17),
.B1(n_12),
.B2(n_5),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_28)
);


endmodule