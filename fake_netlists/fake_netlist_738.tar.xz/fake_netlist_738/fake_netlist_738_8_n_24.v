module fake_netlist_738_8_n_24 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_24);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_24;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

INVx2_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

AND2x6_ASAP7_75t_L g14 ( 
.A(n_5),
.B(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

AOI21x1_ASAP7_75t_L g16 ( 
.A1(n_2),
.A2(n_12),
.B(n_9),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_6),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_7),
.B(n_1),
.C(n_0),
.Y(n_18)
);

INVx2_ASAP7_75t_SL g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_14),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_18),
.B1(n_14),
.B2(n_7),
.C(n_16),
.Y(n_21)
);

AND3x4_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_4),
.C(n_3),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_10),
.Y(n_24)
);


endmodule