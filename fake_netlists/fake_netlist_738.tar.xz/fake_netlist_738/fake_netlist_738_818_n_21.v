module fake_netlist_738_818_n_21 (n_1, n_2, n_3, n_4, n_5, n_0, n_21);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_21;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_4),
.Y(n_7)
);

NAND3xp33_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_4),
.C(n_5),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_1),
.B2(n_0),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_0),
.Y(n_13)
);

OAI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B1(n_9),
.B2(n_10),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_9),
.B1(n_10),
.B2(n_1),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_12),
.B1(n_9),
.B2(n_2),
.C(n_3),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_SL g17 ( 
.A1(n_15),
.A2(n_9),
.B(n_3),
.C(n_2),
.Y(n_17)
);

XNOR2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_4),
.Y(n_18)
);

AND4x1_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_5),
.C(n_10),
.D(n_16),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_10),
.Y(n_20)
);

AOI22x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_19),
.B1(n_18),
.B2(n_13),
.Y(n_21)
);


endmodule