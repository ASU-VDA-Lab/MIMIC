module fake_netlist_738_290_n_55 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_55);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_55;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_27;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx3_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_9),
.B(n_15),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_2),
.B(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

AND3x2_ASAP7_75t_L g27 ( 
.A(n_1),
.B(n_6),
.C(n_14),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_17),
.Y(n_30)
);

NOR2xp67_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_16),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_SL g34 ( 
.A(n_24),
.B(n_8),
.C(n_5),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

A2O1A1Ixp33_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_33),
.B(n_30),
.C(n_28),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_29),
.A2(n_24),
.B1(n_18),
.B2(n_20),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_34),
.Y(n_39)
);

CKINVDCx16_ASAP7_75t_R g40 ( 
.A(n_38),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

NOR2x1_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_37),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

NAND3x1_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_22),
.C(n_27),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_34),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_SL g48 ( 
.A(n_47),
.B(n_27),
.Y(n_48)
);

AND2x2_ASAP7_75t_SL g49 ( 
.A(n_46),
.B(n_21),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

AND2x4_ASAP7_75t_L g51 ( 
.A(n_50),
.B(n_11),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_49),
.Y(n_52)
);

INVx1_ASAP7_75t_SL g53 ( 
.A(n_48),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_SL g55 ( 
.A1(n_54),
.A2(n_51),
.B1(n_52),
.B2(n_53),
.Y(n_55)
);


endmodule