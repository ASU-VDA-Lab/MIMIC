module fake_netlist_738_1812_n_58 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_58);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_58;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_5),
.Y(n_19)
);

INVx4_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVxp67_ASAP7_75t_SL g22 ( 
.A(n_11),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_5),
.B(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_17),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_7),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_1),
.B(n_4),
.Y(n_26)
);

NAND2x1p5_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_8),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_1),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

BUFx4f_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_19),
.B(n_0),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_20),
.Y(n_32)
);

NAND2x1_ASAP7_75t_L g33 ( 
.A(n_20),
.B(n_26),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_20),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_SL g35 ( 
.A(n_31),
.B(n_24),
.C(n_19),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_24),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_32),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_34),
.B(n_29),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

XNOR2x1_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_37),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_35),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_30),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

NAND2x1p5_ASAP7_75t_SL g45 ( 
.A(n_41),
.B(n_25),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_46),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_28),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_36),
.B1(n_27),
.B2(n_22),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

AOI21xp5_ASAP7_75t_L g52 ( 
.A1(n_47),
.A2(n_45),
.B(n_23),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

AOI221xp5_ASAP7_75t_L g54 ( 
.A1(n_49),
.A2(n_16),
.B1(n_0),
.B2(n_17),
.C(n_18),
.Y(n_54)
);

CKINVDCx20_ASAP7_75t_R g55 ( 
.A(n_51),
.Y(n_55)
);

NOR3xp33_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_50),
.C(n_18),
.Y(n_56)
);

AOI22xp33_ASAP7_75t_SL g57 ( 
.A1(n_53),
.A2(n_10),
.B1(n_9),
.B2(n_6),
.Y(n_57)
);

AOI322xp5_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_12),
.A3(n_13),
.B1(n_14),
.B2(n_54),
.C1(n_55),
.C2(n_57),
.Y(n_58)
);


endmodule