module fake_netlist_738_191_n_59 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_59);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_59;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_42;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

OR2x2_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_8),
.B(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

BUFx8_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_7),
.B(n_12),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_6),
.C(n_4),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_23),
.B(n_0),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_24),
.B(n_0),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_21),
.B(n_24),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_22),
.B(n_20),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_SL g35 ( 
.A1(n_32),
.A2(n_26),
.B1(n_25),
.B2(n_1),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_29),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

XNOR2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_35),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_SL g46 ( 
.A(n_45),
.B(n_26),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_38),
.B1(n_26),
.B2(n_31),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_42),
.Y(n_49)
);

OAI21xp33_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_43),
.B(n_38),
.Y(n_50)
);

AND3x2_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_5),
.C(n_1),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_5),
.Y(n_52)
);

INVx3_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

NAND3xp33_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_28),
.C(n_27),
.Y(n_54)
);

AO221x1_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.C(n_28),
.Y(n_55)
);

OAI22xp5_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_27),
.B1(n_18),
.B2(n_13),
.Y(n_56)
);

XNOR2xp5_ASAP7_75t_L g57 ( 
.A(n_56),
.B(n_51),
.Y(n_57)
);

AOI21xp5_ASAP7_75t_L g58 ( 
.A1(n_54),
.A2(n_53),
.B(n_55),
.Y(n_58)
);

OR2x6_ASAP7_75t_L g59 ( 
.A(n_58),
.B(n_57),
.Y(n_59)
);


endmodule