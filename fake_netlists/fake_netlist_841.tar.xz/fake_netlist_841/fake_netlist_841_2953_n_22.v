module fake_netlist_841_2953_n_22 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_22);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_SL g13 ( 
.A(n_11),
.B(n_6),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_10),
.B(n_11),
.Y(n_14)
);

CKINVDCx16_ASAP7_75t_R g15 ( 
.A(n_13),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_14),
.B(n_8),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_9),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NOR2x1_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_15),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_19),
.Y(n_20)
);

NAND5xp2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_3),
.C(n_2),
.D(n_4),
.E(n_5),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_R g22 ( 
.A1(n_21),
.A2(n_5),
.B1(n_10),
.B2(n_20),
.Y(n_22)
);


endmodule