module fake_netlist_841_1535_n_27 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_27);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;

INVx2_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_10),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_17),
.B1(n_16),
.B2(n_13),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

NOR2xp67_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_14),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_0),
.Y(n_25)
);

OR2x6_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_2),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_11),
.B1(n_4),
.B2(n_3),
.Y(n_27)
);


endmodule