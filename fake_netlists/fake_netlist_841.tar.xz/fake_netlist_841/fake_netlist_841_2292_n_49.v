module fake_netlist_841_2292_n_49 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_49);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_49;

wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_3),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_20),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_6),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_1),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_13),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_18),
.B(n_2),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_12),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_4),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

BUFx8_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_16),
.Y(n_33)
);

NAND2x1p5_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_16),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_26),
.B(n_27),
.Y(n_36)
);

OAI22xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_34),
.B1(n_33),
.B2(n_28),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_34),
.B1(n_24),
.B2(n_22),
.C(n_23),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_32),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_30),
.B1(n_25),
.B2(n_32),
.C(n_17),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_32),
.B1(n_19),
.B2(n_17),
.C(n_18),
.Y(n_43)
);

AOI221x1_ASAP7_75t_SL g44 ( 
.A1(n_41),
.A2(n_19),
.B1(n_7),
.B2(n_0),
.C(n_5),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_8),
.Y(n_45)
);

AOI321xp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_11),
.A3(n_10),
.B1(n_14),
.B2(n_21),
.C(n_15),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_46),
.Y(n_48)
);

OR2x6_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_48),
.Y(n_49)
);


endmodule