module fake_netlist_841_523_n_26 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_26);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

AND2x2_ASAP7_75t_SL g13 ( 
.A(n_6),
.B(n_2),
.Y(n_13)
);

AND3x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_4),
.C(n_5),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

INVx8_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

OAI22xp33_ASAP7_75t_L g17 ( 
.A1(n_8),
.A2(n_9),
.B1(n_1),
.B2(n_7),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

INVx1_ASAP7_75t_SL g19 ( 
.A(n_16),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_10),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B1(n_15),
.B2(n_17),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B(n_14),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_12),
.Y(n_26)
);


endmodule