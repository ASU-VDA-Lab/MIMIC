module fake_netlist_841_122_n_61 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_61);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_61;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_44;
wire n_39;
wire n_28;
wire n_53;
wire n_60;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_7),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_1),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_4),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_0),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_27),
.B(n_15),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_23),
.B(n_15),
.Y(n_32)
);

AOI21x1_ASAP7_75t_L g33 ( 
.A1(n_21),
.A2(n_3),
.B(n_2),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_24),
.B(n_16),
.Y(n_35)
);

NAND2xp33_ASAP7_75t_R g36 ( 
.A(n_32),
.B(n_22),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_30),
.A2(n_19),
.B1(n_26),
.B2(n_22),
.Y(n_37)
);

INVx8_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_R g39 ( 
.A(n_33),
.B(n_25),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_37),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_31),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_42),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_42),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_SL g50 ( 
.A(n_45),
.B(n_25),
.Y(n_50)
);

NAND5xp2_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_35),
.C(n_20),
.D(n_36),
.E(n_16),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_48),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_R g53 ( 
.A(n_48),
.B(n_28),
.Y(n_53)
);

AOI221xp5_ASAP7_75t_L g54 ( 
.A1(n_47),
.A2(n_26),
.B1(n_22),
.B2(n_34),
.C(n_28),
.Y(n_54)
);

AND2x4_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_34),
.Y(n_55)
);

XNOR2xp5_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_18),
.Y(n_56)
);

XNOR2x1_ASAP7_75t_L g57 ( 
.A(n_51),
.B(n_18),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_54),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_59),
.Y(n_60)
);

AOI322xp5_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_56),
.A3(n_58),
.B1(n_57),
.B2(n_9),
.C1(n_6),
.C2(n_10),
.Y(n_61)
);


endmodule