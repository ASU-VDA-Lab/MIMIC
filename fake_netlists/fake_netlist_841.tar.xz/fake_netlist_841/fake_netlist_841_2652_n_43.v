module fake_netlist_841_2652_n_43 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_43);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_43;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_16),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_9),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_16),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_0),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_18),
.B1(n_24),
.B2(n_23),
.Y(n_30)
);

NOR2x1_ASAP7_75t_R g31 ( 
.A(n_29),
.B(n_19),
.Y(n_31)
);

OR2x6_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_28),
.Y(n_32)
);

INVxp67_ASAP7_75t_SL g33 ( 
.A(n_30),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_21),
.Y(n_34)
);

NAND5xp2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_2),
.C(n_1),
.D(n_5),
.E(n_7),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_32),
.Y(n_37)
);

NAND3xp33_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_20),
.C(n_8),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_SL g41 ( 
.A1(n_38),
.A2(n_20),
.B1(n_13),
.B2(n_11),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_20),
.B1(n_41),
.B2(n_15),
.Y(n_43)
);


endmodule