module fake_netlist_841_2061_n_67 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_67);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_67;

wire n_49;
wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_60;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx3_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

INVx6_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_8),
.A2(n_3),
.B1(n_17),
.B2(n_1),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_14),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_10),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_16),
.Y(n_31)
);

INVx6_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_20),
.A2(n_22),
.B1(n_21),
.B2(n_0),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_17),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_15),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_24),
.B(n_11),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_29),
.Y(n_38)
);

BUFx8_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

BUFx12f_ASAP7_75t_L g40 ( 
.A(n_32),
.Y(n_40)
);

NAND2xp33_ASAP7_75t_SL g41 ( 
.A(n_29),
.B(n_11),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_32),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_SL g43 ( 
.A(n_24),
.B(n_16),
.Y(n_43)
);

AO21x2_ASAP7_75t_L g44 ( 
.A1(n_37),
.A2(n_27),
.B(n_25),
.Y(n_44)
);

A2O1A1Ixp33_ASAP7_75t_L g45 ( 
.A1(n_37),
.A2(n_36),
.B(n_30),
.C(n_31),
.Y(n_45)
);

OAI21xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_36),
.B(n_30),
.Y(n_46)
);

OA21x2_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_42),
.B(n_35),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

AND2x4_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_28),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_38),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_41),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_46),
.Y(n_53)
);

AND2x4_ASAP7_75t_L g54 ( 
.A(n_48),
.B(n_44),
.Y(n_54)
);

AOI222xp33_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_39),
.B1(n_33),
.B2(n_40),
.C1(n_35),
.C2(n_32),
.Y(n_55)
);

AOI221x1_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_48),
.B1(n_50),
.B2(n_45),
.C(n_53),
.Y(n_56)
);

AOI221xp5_ASAP7_75t_SL g57 ( 
.A1(n_53),
.A2(n_50),
.B1(n_44),
.B2(n_47),
.C(n_39),
.Y(n_57)
);

INVx2_ASAP7_75t_SL g58 ( 
.A(n_52),
.Y(n_58)
);

A2O1A1Ixp33_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_54),
.B(n_44),
.C(n_26),
.Y(n_59)
);

OAI211xp5_ASAP7_75t_L g60 ( 
.A1(n_55),
.A2(n_58),
.B(n_56),
.C(n_57),
.Y(n_60)
);

AOI322xp5_ASAP7_75t_L g61 ( 
.A1(n_58),
.A2(n_19),
.A3(n_18),
.B1(n_20),
.B2(n_23),
.C1(n_21),
.C2(n_26),
.Y(n_61)
);

AND2x4_ASAP7_75t_L g62 ( 
.A(n_59),
.B(n_2),
.Y(n_62)
);

NOR2xp33_ASAP7_75t_L g63 ( 
.A(n_60),
.B(n_23),
.Y(n_63)
);

AND4x1_ASAP7_75t_L g64 ( 
.A(n_59),
.B(n_7),
.C(n_6),
.D(n_4),
.Y(n_64)
);

NOR2xp33_ASAP7_75t_L g65 ( 
.A(n_63),
.B(n_61),
.Y(n_65)
);

OAI21x1_ASAP7_75t_L g66 ( 
.A1(n_65),
.A2(n_64),
.B(n_62),
.Y(n_66)
);

OR2x6_ASAP7_75t_L g67 ( 
.A(n_66),
.B(n_62),
.Y(n_67)
);


endmodule