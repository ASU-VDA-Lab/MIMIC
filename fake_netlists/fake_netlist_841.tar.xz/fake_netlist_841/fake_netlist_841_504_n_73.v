module fake_netlist_841_504_n_73 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_73);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_73;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_57;
wire n_70;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_23;
wire n_44;
wire n_34;
wire n_28;
wire n_39;
wire n_53;
wire n_60;
wire n_31;
wire n_32;
wire n_40;
wire n_58;
wire n_68;
wire n_26;
wire n_72;
wire n_24;
wire n_71;
wire n_43;
wire n_37;
wire n_54;
wire n_42;
wire n_69;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_67;
wire n_45;
wire n_46;
wire n_51;

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_15),
.A2(n_13),
.B1(n_16),
.B2(n_18),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_8),
.A2(n_6),
.B1(n_2),
.B2(n_5),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_11),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_10),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_3),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_26),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_27),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_26),
.B(n_1),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_23),
.B(n_10),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_21),
.B(n_11),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_20),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_25),
.B(n_16),
.Y(n_39)
);

BUFx6f_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OA21x2_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_29),
.B(n_28),
.Y(n_41)
);

OAI22xp33_ASAP7_75t_L g42 ( 
.A1(n_33),
.A2(n_24),
.B1(n_27),
.B2(n_30),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_37),
.A2(n_9),
.B(n_7),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_L g45 ( 
.A1(n_39),
.A2(n_20),
.B(n_31),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_41),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_41),
.B(n_39),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_43),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_41),
.B(n_39),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_41),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_41),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_33),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_47),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_49),
.B(n_47),
.Y(n_55)
);

OAI221xp5_ASAP7_75t_SL g56 ( 
.A1(n_53),
.A2(n_42),
.B1(n_32),
.B2(n_35),
.C(n_44),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_51),
.B(n_52),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_46),
.Y(n_58)
);

AOI21xp33_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_50),
.B(n_52),
.Y(n_59)
);

OAI22xp33_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_32),
.B1(n_42),
.B2(n_44),
.Y(n_60)
);

O2A1O1Ixp5_ASAP7_75t_L g61 ( 
.A1(n_56),
.A2(n_49),
.B(n_51),
.C(n_45),
.Y(n_61)
);

XOR2xp5_ASAP7_75t_L g62 ( 
.A(n_57),
.B(n_41),
.Y(n_62)
);

OAI221xp5_ASAP7_75t_L g63 ( 
.A1(n_55),
.A2(n_45),
.B1(n_34),
.B2(n_31),
.C(n_20),
.Y(n_63)
);

INVx3_ASAP7_75t_SL g64 ( 
.A(n_62),
.Y(n_64)
);

OR2x2_ASAP7_75t_L g65 ( 
.A(n_62),
.B(n_34),
.Y(n_65)
);

NAND5xp2_ASAP7_75t_L g66 ( 
.A(n_59),
.B(n_31),
.C(n_17),
.D(n_20),
.E(n_43),
.Y(n_66)
);

CKINVDCx16_ASAP7_75t_R g67 ( 
.A(n_60),
.Y(n_67)
);

OR2x2_ASAP7_75t_L g68 ( 
.A(n_63),
.B(n_17),
.Y(n_68)
);

INVx2_ASAP7_75t_L g69 ( 
.A(n_68),
.Y(n_69)
);

OAI221xp5_ASAP7_75t_SL g70 ( 
.A1(n_65),
.A2(n_38),
.B1(n_61),
.B2(n_43),
.C(n_14),
.Y(n_70)
);

HB1xp67_ASAP7_75t_L g71 ( 
.A(n_64),
.Y(n_71)
);

AOI22xp5_ASAP7_75t_L g72 ( 
.A1(n_69),
.A2(n_67),
.B1(n_66),
.B2(n_40),
.Y(n_72)
);

AOI322xp5_ASAP7_75t_L g73 ( 
.A1(n_72),
.A2(n_40),
.A3(n_70),
.B1(n_67),
.B2(n_71),
.C1(n_42),
.C2(n_69),
.Y(n_73)
);


endmodule