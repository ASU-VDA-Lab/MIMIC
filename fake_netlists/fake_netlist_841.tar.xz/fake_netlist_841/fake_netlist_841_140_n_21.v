module fake_netlist_841_140_n_21 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_21);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_21;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_11;

INVx2_ASAP7_75t_SL g11 ( 
.A(n_4),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_3),
.A2(n_2),
.B1(n_5),
.B2(n_10),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_7),
.B(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

NOR4xp25_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_4),
.C(n_1),
.D(n_0),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_12),
.B1(n_14),
.B2(n_11),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_16),
.B1(n_13),
.B2(n_0),
.C(n_1),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.C(n_5),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_6),
.B1(n_7),
.B2(n_8),
.C1(n_9),
.C2(n_17),
.Y(n_21)
);


endmodule