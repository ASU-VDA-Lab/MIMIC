module fake_netlist_841_2496_n_8 (n_2, n_0, n_1, n_8);

input n_2;
input n_0;
input n_1;

output n_8;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

HB1xp67_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_5),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_8)
);


endmodule