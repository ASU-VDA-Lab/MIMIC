module fake_netlist_841_1631_n_23 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_23);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_2),
.A2(n_0),
.B1(n_7),
.B2(n_3),
.Y(n_14)
);

NAND2x1p5_ASAP7_75t_L g15 ( 
.A(n_6),
.B(n_4),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_L g16 ( 
.A(n_8),
.B(n_10),
.C(n_7),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_1),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.B1(n_14),
.B2(n_12),
.C(n_16),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_14),
.B(n_4),
.C(n_1),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_6),
.B(n_5),
.Y(n_23)
);


endmodule