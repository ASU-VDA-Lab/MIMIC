module fake_netlist_841_723_n_52 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_52);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_52;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

AND2x2_ASAP7_75t_L g25 ( 
.A(n_0),
.B(n_17),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_1),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_13),
.Y(n_30)
);

OA21x2_ASAP7_75t_L g31 ( 
.A1(n_10),
.A2(n_24),
.B(n_4),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_11),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_6),
.Y(n_33)
);

NAND2xp33_ASAP7_75t_SL g34 ( 
.A(n_32),
.B(n_18),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_26),
.B(n_18),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_29),
.Y(n_36)
);

AO22x1_ASAP7_75t_L g37 ( 
.A1(n_29),
.A2(n_5),
.B1(n_3),
.B2(n_2),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NOR4xp25_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_34),
.C(n_35),
.D(n_28),
.Y(n_40)
);

INVx2_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_32),
.B1(n_37),
.B2(n_27),
.C(n_33),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_30),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_31),
.Y(n_44)
);

OAI21xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_25),
.B(n_31),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_8),
.B1(n_7),
.B2(n_9),
.C(n_14),
.Y(n_46)
);

AOI21xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_16),
.B(n_15),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_19),
.Y(n_49)
);

CKINVDCx16_ASAP7_75t_R g50 ( 
.A(n_48),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_20),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_21),
.B1(n_23),
.B2(n_51),
.Y(n_52)
);


endmodule