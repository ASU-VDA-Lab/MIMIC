module fake_netlist_608_1118_n_24 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_24);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_24;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

AND3x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_0),
.C(n_7),
.Y(n_12)
);

INVxp67_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_5),
.Y(n_15)
);

OR2x6_ASAP7_75t_L g16 ( 
.A(n_8),
.B(n_2),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_3),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B1(n_15),
.B2(n_12),
.C(n_4),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_10),
.B(n_6),
.Y(n_24)
);


endmodule