module fake_netlist_608_573_n_31 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_31);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_31;

wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;

INVx3_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_1),
.A2(n_6),
.B1(n_3),
.B2(n_4),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_14),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_13),
.B(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_7),
.B(n_11),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_17),
.B(n_0),
.Y(n_24)
);

OAI222xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_18),
.B1(n_21),
.B2(n_17),
.C1(n_22),
.C2(n_19),
.Y(n_25)
);

OAI211xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_21),
.B(n_5),
.C(n_0),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_23),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_25),
.B1(n_23),
.B2(n_22),
.C(n_20),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_28),
.B(n_5),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_16),
.B1(n_15),
.B2(n_8),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_12),
.B1(n_10),
.B2(n_9),
.Y(n_31)
);


endmodule