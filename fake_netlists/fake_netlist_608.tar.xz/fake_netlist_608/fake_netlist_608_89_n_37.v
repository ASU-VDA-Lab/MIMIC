module fake_netlist_608_89_n_37 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_37);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_37;

wire n_31;
wire n_21;
wire n_30;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_32;
wire n_23;
wire n_33;

INVx1_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_9),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_SL g23 ( 
.A(n_14),
.B(n_5),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

BUFx10_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_18),
.C(n_17),
.Y(n_27)
);

NAND2x1p5_ASAP7_75t_L g28 ( 
.A(n_21),
.B(n_17),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_24),
.A2(n_2),
.B(n_1),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AO31x2_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_26),
.A3(n_25),
.B(n_22),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_27),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_18),
.A3(n_31),
.B1(n_6),
.B2(n_7),
.C1(n_3),
.C2(n_4),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

NOR2x1_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_31),
.Y(n_36)
);

AOI322xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_10),
.A3(n_8),
.B1(n_19),
.B2(n_20),
.C1(n_12),
.C2(n_13),
.Y(n_37)
);


endmodule