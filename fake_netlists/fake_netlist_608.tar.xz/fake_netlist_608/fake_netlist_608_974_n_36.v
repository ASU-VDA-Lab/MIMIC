module fake_netlist_608_974_n_36 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_36);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_36;

wire n_31;
wire n_21;
wire n_30;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

NAND2xp33_ASAP7_75t_R g19 ( 
.A(n_1),
.B(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_11),
.B(n_16),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_14),
.B(n_6),
.Y(n_22)
);

BUFx10_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_5),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_8),
.Y(n_25)
);

BUFx12f_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_20),
.A2(n_3),
.B(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_25),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_24),
.Y(n_30)
);

OAI222xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_27),
.B1(n_19),
.B2(n_21),
.C1(n_22),
.C2(n_26),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_30),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_SL g33 ( 
.A(n_32),
.B(n_15),
.C(n_13),
.Y(n_33)
);

OAI321xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_15),
.A3(n_13),
.B1(n_10),
.B2(n_9),
.C(n_7),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_18),
.B1(n_17),
.B2(n_12),
.Y(n_36)
);


endmodule