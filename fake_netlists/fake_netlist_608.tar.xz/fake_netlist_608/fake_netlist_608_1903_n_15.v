module fake_netlist_608_1903_n_15 (n_1, n_2, n_0, n_15);

input n_1;
input n_2;
input n_0;

output n_15;

wire n_7;
wire n_11;
wire n_9;
wire n_8;
wire n_5;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;
wire n_3;

CKINVDCx20_ASAP7_75t_R g3 ( 
.A(n_2),
.Y(n_3)
);

BUFx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

AOI21xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.Y(n_5)
);

AO21x2_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AOI221x1_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_5),
.B1(n_2),
.B2(n_1),
.C(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_7),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_8),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_0),
.B1(n_1),
.B2(n_9),
.C1(n_14),
.C2(n_11),
.Y(n_15)
);


endmodule