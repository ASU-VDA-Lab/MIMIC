module fake_netlist_608_313_n_17 (n_5, n_0, n_4, n_1, n_2, n_3, n_17);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_17;

wire n_7;
wire n_11;
wire n_16;
wire n_8;
wire n_15;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_SL g14 ( 
.A(n_13),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_15),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_8),
.B1(n_4),
.B2(n_5),
.C1(n_3),
.C2(n_2),
.Y(n_17)
);


endmodule