module fake_netlist_608_1771_n_8 (n_1, n_2, n_3, n_0, n_8);

input n_1;
input n_2;
input n_3;
input n_0;

output n_8;

wire n_7;
wire n_5;
wire n_6;
wire n_4;

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

XNOR2x1_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

NAND2xp33_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_2),
.Y(n_8)
);


endmodule