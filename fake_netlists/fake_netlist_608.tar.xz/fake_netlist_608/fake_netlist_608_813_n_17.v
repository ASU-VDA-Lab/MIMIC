module fake_netlist_608_813_n_17 (n_1, n_2, n_3, n_0, n_17);

input n_1;
input n_2;
input n_3;
input n_0;

output n_17;

wire n_7;
wire n_9;
wire n_11;
wire n_16;
wire n_8;
wire n_5;
wire n_15;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

AND2x6_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_1),
.Y(n_6)
);

AOI21xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_6),
.B1(n_1),
.B2(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_10),
.B(n_3),
.C(n_2),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_12),
.B(n_2),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_1),
.B1(n_3),
.B2(n_16),
.Y(n_17)
);


endmodule