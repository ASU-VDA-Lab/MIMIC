module fake_netlist_608_608_n_35 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_35);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_35;

wire n_31;
wire n_21;
wire n_30;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_25;
wire n_26;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

OR2x2_ASAP7_75t_L g20 ( 
.A(n_3),
.B(n_4),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_11),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_23),
.B(n_0),
.Y(n_27)
);

AO31x2_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_25),
.A3(n_20),
.B(n_24),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_21),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_28),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_6),
.B1(n_5),
.B2(n_7),
.C(n_9),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_13),
.B1(n_12),
.B2(n_10),
.Y(n_34)
);

AOI222xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_15),
.B1(n_14),
.B2(n_16),
.C1(n_19),
.C2(n_17),
.Y(n_35)
);


endmodule