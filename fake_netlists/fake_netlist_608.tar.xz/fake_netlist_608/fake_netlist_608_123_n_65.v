module fake_netlist_608_123_n_65 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_65);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_65;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_62;
wire n_58;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_63;
wire n_26;
wire n_60;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_64;

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_2),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_1),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_19),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_4),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_3),
.Y(n_33)
);

A2O1A1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_22),
.A2(n_9),
.B(n_8),
.C(n_3),
.Y(n_34)
);

NAND2x1_ASAP7_75t_L g35 ( 
.A(n_28),
.B(n_8),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_29),
.Y(n_36)
);

BUFx12f_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_30),
.B(n_10),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_27),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_29),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_34),
.A2(n_25),
.B1(n_31),
.B2(n_21),
.C(n_26),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_36),
.B(n_27),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_37),
.Y(n_43)
);

NAND2xp33_ASAP7_75t_R g44 ( 
.A(n_38),
.B(n_10),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NAND2x1p5_ASAP7_75t_L g46 ( 
.A(n_40),
.B(n_35),
.Y(n_46)
);

AOI21xp5_ASAP7_75t_L g47 ( 
.A1(n_40),
.A2(n_39),
.B(n_32),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_L g48 ( 
.A1(n_41),
.A2(n_33),
.B1(n_35),
.B2(n_37),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_41),
.Y(n_49)
);

OR2x6_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_31),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_42),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_39),
.Y(n_52)
);

OAI21xp33_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_43),
.B(n_44),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_11),
.Y(n_55)
);

O2A1O1Ixp33_ASAP7_75t_SL g56 ( 
.A1(n_50),
.A2(n_44),
.B(n_23),
.C(n_7),
.Y(n_56)
);

AOI311xp33_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_16),
.A3(n_15),
.B(n_17),
.C(n_18),
.Y(n_57)
);

NAND4xp25_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_55),
.C(n_17),
.D(n_16),
.Y(n_58)
);

NOR2xp33_ASAP7_75t_R g59 ( 
.A(n_54),
.B(n_18),
.Y(n_59)
);

OAI221xp5_ASAP7_75t_L g60 ( 
.A1(n_53),
.A2(n_23),
.B1(n_20),
.B2(n_12),
.C(n_13),
.Y(n_60)
);

INVx3_ASAP7_75t_SL g61 ( 
.A(n_59),
.Y(n_61)
);

INVx6_ASAP7_75t_L g62 ( 
.A(n_59),
.Y(n_62)
);

NAND3xp33_ASAP7_75t_L g63 ( 
.A(n_57),
.B(n_23),
.C(n_20),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_63),
.Y(n_64)
);

AOI322xp5_ASAP7_75t_L g65 ( 
.A1(n_64),
.A2(n_61),
.A3(n_62),
.B1(n_23),
.B2(n_63),
.C1(n_58),
.C2(n_60),
.Y(n_65)
);


endmodule