module fake_netlist_608_1539_n_58 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_58);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_58;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_3),
.B(n_10),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_11),
.B(n_12),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_8),
.B(n_9),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_4),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_2),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_14),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_26),
.A2(n_22),
.B1(n_21),
.B2(n_15),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

AOI21xp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_25),
.B(n_26),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_38),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_37),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_41),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_39),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_23),
.B1(n_27),
.B2(n_29),
.Y(n_47)
);

AND2x4_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_27),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_47),
.A2(n_46),
.B1(n_48),
.B2(n_29),
.Y(n_49)
);

OAI21xp5_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_34),
.B(n_31),
.Y(n_50)
);

AOI322xp5_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_31),
.A3(n_21),
.B1(n_15),
.B2(n_30),
.C1(n_24),
.C2(n_32),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_SL g52 ( 
.A1(n_49),
.A2(n_32),
.B1(n_30),
.B2(n_24),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_50),
.Y(n_53)
);

OAI211xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_32),
.B(n_30),
.C(n_24),
.Y(n_54)
);

OAI21x1_ASAP7_75t_SL g55 ( 
.A1(n_52),
.A2(n_1),
.B(n_0),
.Y(n_55)
);

OAI22xp5_ASAP7_75t_SL g56 ( 
.A1(n_53),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_56)
);

INVx1_ASAP7_75t_SL g57 ( 
.A(n_56),
.Y(n_57)
);

OAI22xp33_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_55),
.B1(n_54),
.B2(n_13),
.Y(n_58)
);


endmodule