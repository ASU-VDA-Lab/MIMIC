module fake_netlist_608_775_n_69 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_69);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_69;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_61;
wire n_29;
wire n_58;
wire n_27;
wire n_28;
wire n_62;
wire n_67;
wire n_52;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_65;
wire n_25;
wire n_63;
wire n_26;
wire n_60;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_66;
wire n_32;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_64;
wire n_34;
wire n_68;

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_3),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_13),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_17),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_8),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_R g33 ( 
.A(n_20),
.B(n_19),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_21),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_23),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_22),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_R g37 ( 
.A(n_31),
.B(n_32),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_30),
.A2(n_19),
.B1(n_18),
.B2(n_15),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_29),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_36),
.B1(n_35),
.B2(n_25),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_30),
.B1(n_35),
.B2(n_26),
.Y(n_43)
);

OAI31xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_26),
.A3(n_27),
.B(n_40),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

OAI211xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_42),
.B(n_37),
.C(n_33),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_33),
.Y(n_48)
);

INVx1_ASAP7_75t_SL g49 ( 
.A(n_46),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_49),
.Y(n_51)
);

NOR2x1_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_27),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_35),
.Y(n_53)
);

INVx2_ASAP7_75t_SL g54 ( 
.A(n_49),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_15),
.Y(n_55)
);

INVx1_ASAP7_75t_SL g56 ( 
.A(n_51),
.Y(n_56)
);

NAND5xp2_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_20),
.C(n_18),
.D(n_22),
.E(n_24),
.Y(n_57)
);

AO22x2_ASAP7_75t_L g58 ( 
.A1(n_51),
.A2(n_24),
.B1(n_1),
.B2(n_0),
.Y(n_58)
);

NAND5xp2_ASAP7_75t_L g59 ( 
.A(n_53),
.B(n_4),
.C(n_2),
.D(n_6),
.E(n_7),
.Y(n_59)
);

OA22x2_ASAP7_75t_L g60 ( 
.A1(n_54),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_52),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_51),
.B(n_14),
.Y(n_62)
);

HB1xp67_ASAP7_75t_L g63 ( 
.A(n_56),
.Y(n_63)
);

INVx1_ASAP7_75t_SL g64 ( 
.A(n_56),
.Y(n_64)
);

NOR3x2_ASAP7_75t_L g65 ( 
.A(n_57),
.B(n_58),
.C(n_60),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_61),
.Y(n_66)
);

CKINVDCx20_ASAP7_75t_R g67 ( 
.A(n_62),
.Y(n_67)
);

INVx4_ASAP7_75t_L g68 ( 
.A(n_58),
.Y(n_68)
);

AOI322xp5_ASAP7_75t_L g69 ( 
.A1(n_66),
.A2(n_65),
.A3(n_67),
.B1(n_64),
.B2(n_63),
.C1(n_68),
.C2(n_59),
.Y(n_69)
);


endmodule