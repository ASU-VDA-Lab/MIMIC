module fake_netlist_608_1555_n_11 (n_0, n_4, n_1, n_2, n_3, n_11);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_11;

wire n_7;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_9;

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_1),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_7),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_3),
.Y(n_11)
);


endmodule