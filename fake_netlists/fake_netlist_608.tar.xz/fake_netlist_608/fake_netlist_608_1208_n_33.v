module fake_netlist_608_1208_n_33 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_33);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_33;

wire n_31;
wire n_21;
wire n_30;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

NOR2xp67_ASAP7_75t_L g20 ( 
.A(n_7),
.B(n_9),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_16),
.B(n_3),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

O2A1O1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_18),
.B(n_16),
.C(n_0),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_24),
.B(n_23),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_20),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_19),
.Y(n_28)
);

AOI221x1_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.B1(n_25),
.B2(n_18),
.C(n_1),
.Y(n_29)
);

OAI211xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_21),
.B(n_4),
.C(n_2),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_13),
.B1(n_10),
.B2(n_8),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_17),
.B1(n_15),
.B2(n_14),
.Y(n_33)
);


endmodule