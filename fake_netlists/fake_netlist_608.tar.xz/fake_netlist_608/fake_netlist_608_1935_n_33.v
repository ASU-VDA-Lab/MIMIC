module fake_netlist_608_1935_n_33 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_33);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_33;

wire n_11;
wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

AND2x2_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_7),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_2),
.B(n_3),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_SL g14 ( 
.A1(n_3),
.A2(n_0),
.B1(n_1),
.B2(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_2),
.B(n_1),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_11),
.A2(n_6),
.B(n_4),
.Y(n_19)
);

AO31x2_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_4),
.A3(n_6),
.B(n_10),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_21),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_SL g23 ( 
.A(n_18),
.B(n_14),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI32xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_23),
.A3(n_12),
.B1(n_22),
.B2(n_13),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

NAND4xp25_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_23),
.C(n_17),
.D(n_19),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx4_ASAP7_75t_SL g30 ( 
.A(n_28),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_14),
.B2(n_20),
.Y(n_33)
);


endmodule