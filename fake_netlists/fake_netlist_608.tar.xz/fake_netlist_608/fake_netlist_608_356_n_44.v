module fake_netlist_608_356_n_44 (n_7, n_9, n_11, n_8, n_5, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_44);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_44;

wire n_31;
wire n_15;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_1),
.B(n_7),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_11),
.B(n_4),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_4),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_24),
.Y(n_27)
);

INVx4_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_23),
.B(n_18),
.Y(n_29)
);

OAI33xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_25),
.A3(n_16),
.B1(n_15),
.B2(n_19),
.B3(n_20),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_27),
.B(n_22),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_21),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_29),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

HB1xp67_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

XNOR2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_30),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_5),
.Y(n_39)
);

OAI21xp33_ASAP7_75t_SL g40 ( 
.A1(n_38),
.A2(n_7),
.B(n_6),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_10),
.B1(n_9),
.B2(n_2),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx8_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_13),
.B1(n_41),
.B2(n_42),
.Y(n_44)
);


endmodule