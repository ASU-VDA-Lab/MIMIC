module fake_netlist_837_244_n_40 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_40);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_40;

wire n_25;
wire n_20;
wire n_36;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_3),
.B(n_7),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

NOR2xp67_ASAP7_75t_L g20 ( 
.A(n_2),
.B(n_8),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_14),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_8),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_12),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_20),
.A2(n_16),
.B(n_15),
.C(n_14),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_15),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_25),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_R g29 ( 
.A(n_27),
.B(n_17),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_27),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_17),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

O2A1O1Ixp33_ASAP7_75t_SL g33 ( 
.A1(n_31),
.A2(n_26),
.B(n_19),
.C(n_21),
.Y(n_33)
);

NAND4xp25_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_29),
.C(n_23),
.D(n_22),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVxp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_13),
.Y(n_37)
);

AOI21xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_18),
.B(n_0),
.Y(n_38)
);

NAND2x1_ASAP7_75t_SL g39 ( 
.A(n_36),
.B(n_13),
.Y(n_39)
);

AOI322xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_1),
.A3(n_4),
.B1(n_5),
.B2(n_6),
.C1(n_11),
.C2(n_38),
.Y(n_40)
);


endmodule