module fake_netlist_837_2530_n_32 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_27;

AND2x4_ASAP7_75t_L g17 ( 
.A(n_2),
.B(n_8),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_17),
.A2(n_16),
.B(n_7),
.C(n_15),
.Y(n_23)
);

OAI21x1_ASAP7_75t_L g24 ( 
.A1(n_19),
.A2(n_18),
.B(n_17),
.Y(n_24)
);

OR2x6_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_17),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_22),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

NOR3xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_26),
.C(n_20),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_21),
.B1(n_7),
.B2(n_15),
.C1(n_16),
.C2(n_10),
.Y(n_30)
);

OAI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_5),
.B1(n_13),
.B2(n_6),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.Y(n_32)
);


endmodule