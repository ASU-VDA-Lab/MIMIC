module fake_netlist_837_846_n_46 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_46);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_46;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;

CKINVDCx8_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_0),
.B(n_2),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_5),
.B(n_4),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_6),
.A2(n_10),
.B1(n_11),
.B2(n_7),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_9),
.Y(n_22)
);

INVx4_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

INVx2_ASAP7_75t_SL g24 ( 
.A(n_13),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_14),
.A2(n_3),
.B1(n_7),
.B2(n_1),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_16),
.B1(n_20),
.B2(n_19),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_22),
.A2(n_20),
.B1(n_19),
.B2(n_15),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_23),
.B(n_15),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_25),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_28),
.B(n_24),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_34),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_31),
.Y(n_36)
);

AOI31xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_17),
.A3(n_32),
.B(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

O2A1O1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_37),
.B(n_34),
.C(n_30),
.Y(n_39)
);

OAI22xp33_ASAP7_75t_SL g40 ( 
.A1(n_38),
.A2(n_12),
.B1(n_31),
.B2(n_30),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_21),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_40),
.A2(n_23),
.B1(n_17),
.B2(n_38),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_SL g46 ( 
.A1(n_45),
.A2(n_42),
.B1(n_43),
.B2(n_44),
.Y(n_46)
);


endmodule