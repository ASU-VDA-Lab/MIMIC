module fake_netlist_837_2822_n_26 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_26);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

AOI22xp33_ASAP7_75t_SL g13 ( 
.A1(n_0),
.A2(n_4),
.B1(n_1),
.B2(n_11),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_12),
.B(n_9),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_10),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

NAND2xp33_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_1),
.Y(n_18)
);

AOI21x1_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_2),
.B(n_3),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVxp67_ASAP7_75t_SL g21 ( 
.A(n_19),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_13),
.C(n_14),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_20),
.Y(n_23)
);

NAND5xp2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_19),
.C(n_15),
.D(n_21),
.E(n_14),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_21),
.B(n_23),
.Y(n_25)
);

OAI222xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_2),
.B1(n_3),
.B2(n_0),
.C1(n_5),
.C2(n_6),
.Y(n_26)
);


endmodule