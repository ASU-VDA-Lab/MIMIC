module fake_netlist_837_59_n_32 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

INVx5_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_11),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_14),
.B1(n_12),
.B2(n_0),
.C(n_1),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_16),
.Y(n_23)
);

AOI321xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_0),
.A3(n_12),
.B1(n_7),
.B2(n_9),
.C(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_25),
.B(n_24),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_12),
.B1(n_2),
.B2(n_3),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

XNOR2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_30),
.Y(n_32)
);


endmodule