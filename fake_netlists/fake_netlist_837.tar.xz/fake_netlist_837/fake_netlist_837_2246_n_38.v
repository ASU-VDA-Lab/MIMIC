module fake_netlist_837_2246_n_38 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_38);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_38;

wire n_25;
wire n_36;
wire n_22;
wire n_34;
wire n_23;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_27;

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_13),
.B(n_2),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_19),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_8),
.B(n_18),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_18),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_17),
.Y(n_26)
);

BUFx10_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

BUFx5_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_L g29 ( 
.A(n_22),
.B(n_20),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_20),
.B1(n_9),
.B2(n_19),
.Y(n_30)
);

AO32x2_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_24),
.A3(n_27),
.B1(n_23),
.B2(n_21),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_23),
.Y(n_33)
);

OAI22xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.B1(n_29),
.B2(n_26),
.Y(n_34)
);

NAND4xp75_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_28),
.C(n_16),
.D(n_7),
.Y(n_35)
);

OAI322xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_11),
.A3(n_6),
.B1(n_10),
.B2(n_5),
.C1(n_14),
.C2(n_15),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_3),
.B1(n_4),
.B2(n_0),
.Y(n_37)
);

XOR2xp5_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_1),
.Y(n_38)
);


endmodule