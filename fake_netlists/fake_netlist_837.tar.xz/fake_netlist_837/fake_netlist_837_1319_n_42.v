module fake_netlist_837_1319_n_42 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_42);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_42;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_2),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_0),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_13),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_19),
.A2(n_9),
.B1(n_18),
.B2(n_17),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_17),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_25),
.Y(n_28)
);

AO31x2_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_20),
.A3(n_22),
.B(n_23),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_26),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_24),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_24),
.B(n_12),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_9),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_36),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_34),
.B1(n_8),
.B2(n_7),
.C(n_10),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_14),
.B(n_4),
.C(n_6),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_41),
.A2(n_39),
.B1(n_1),
.B2(n_3),
.Y(n_42)
);


endmodule