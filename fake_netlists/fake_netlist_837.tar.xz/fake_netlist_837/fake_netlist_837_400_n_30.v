module fake_netlist_837_400_n_30 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_30);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.Y(n_19)
);

INVx4_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

AO31x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.A3(n_16),
.B(n_14),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_19),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B1(n_13),
.B2(n_2),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_21),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_18),
.B1(n_21),
.B2(n_3),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_21),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

BUFx2_ASAP7_75t_SL g29 ( 
.A(n_28),
.Y(n_29)
);

AOI322xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_27),
.A3(n_1),
.B1(n_7),
.B2(n_11),
.C1(n_6),
.C2(n_4),
.Y(n_30)
);


endmodule