module fake_netlist_837_2576_n_46 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_46);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_46;

wire n_25;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_43;
wire n_45;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_0),
.Y(n_21)
);

NOR2xp67_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_8),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_16),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_29),
.B1(n_22),
.B2(n_24),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_14),
.B(n_10),
.Y(n_31)
);

BUFx3_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

AO21x2_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_31),
.B(n_26),
.Y(n_35)
);

OAI33xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_23),
.A3(n_27),
.B1(n_12),
.B2(n_7),
.B3(n_18),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_27),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

OAI21xp5_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_37),
.B(n_6),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_3),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_20),
.B(n_2),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_43),
.B1(n_4),
.B2(n_1),
.Y(n_46)
);


endmodule