module fake_netlist_837_588_n_42 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_42);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_42;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_9),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_15),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_13),
.Y(n_21)
);

AND2x2_ASAP7_75t_SL g22 ( 
.A(n_16),
.B(n_2),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_SL g25 ( 
.A(n_21),
.B(n_9),
.C(n_12),
.Y(n_25)
);

OR2x6_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_10),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_19),
.B1(n_22),
.B2(n_24),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_22),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_31),
.Y(n_34)
);

A2O1A1Ixp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_25),
.B(n_20),
.C(n_7),
.Y(n_35)
);

AOI31xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_32),
.A3(n_8),
.B(n_6),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

NAND3xp33_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_5),
.C(n_14),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_1),
.B1(n_3),
.B2(n_41),
.Y(n_42)
);


endmodule