module fake_netlist_837_2717_n_27 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_27);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_13),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_SL g20 ( 
.A(n_18),
.B(n_15),
.C(n_16),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_R g21 ( 
.A(n_20),
.B(n_17),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_14),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_19),
.C(n_6),
.D(n_5),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OAI31xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_8),
.A3(n_4),
.B(n_7),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.Y(n_27)
);


endmodule