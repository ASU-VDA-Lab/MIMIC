module fake_netlist_837_2730_n_53 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_53);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_53;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

OAI22xp5_ASAP7_75t_SL g18 ( 
.A1(n_15),
.A2(n_17),
.B1(n_12),
.B2(n_3),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_16),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_13),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_21),
.B(n_17),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_16),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_22),
.B(n_11),
.Y(n_30)
);

OAI21xp5_ASAP7_75t_L g31 ( 
.A1(n_20),
.A2(n_14),
.B(n_6),
.Y(n_31)
);

NOR2x1_ASAP7_75t_SL g32 ( 
.A(n_28),
.B(n_26),
.Y(n_32)
);

AOI222xp33_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_18),
.B1(n_19),
.B2(n_24),
.C1(n_31),
.C2(n_23),
.Y(n_33)
);

CKINVDCx11_ASAP7_75t_R g34 ( 
.A(n_27),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_30),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVx1_ASAP7_75t_SL g39 ( 
.A(n_37),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_32),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AOI321xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_37),
.A3(n_24),
.B1(n_26),
.B2(n_4),
.C(n_0),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_26),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

OAI211xp5_ASAP7_75t_SL g45 ( 
.A1(n_42),
.A2(n_39),
.B(n_1),
.C(n_2),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

BUFx6f_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_46),
.Y(n_49)
);

HB1xp67_ASAP7_75t_SL g50 ( 
.A(n_46),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

AOI22xp33_ASAP7_75t_SL g53 ( 
.A1(n_52),
.A2(n_51),
.B1(n_48),
.B2(n_50),
.Y(n_53)
);


endmodule