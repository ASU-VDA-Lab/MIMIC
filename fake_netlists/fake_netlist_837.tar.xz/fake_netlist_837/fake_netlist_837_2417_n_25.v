module fake_netlist_837_2417_n_25 (n_4, n_2, n_5, n_3, n_0, n_1, n_25);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_25;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_24;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_3),
.B1(n_2),
.B2(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_1),
.B1(n_0),
.B2(n_3),
.Y(n_11)
);

OA21x2_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

OAI22xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_SL g17 ( 
.A1(n_14),
.A2(n_11),
.B(n_9),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_6),
.B1(n_12),
.B2(n_0),
.Y(n_18)
);

AO221x1_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_6),
.B1(n_13),
.B2(n_5),
.C(n_4),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_6),
.B(n_17),
.C(n_15),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_6),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_6),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_20),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

AOI21xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_22),
.B(n_24),
.Y(n_25)
);


endmodule