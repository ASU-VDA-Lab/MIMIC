module fake_netlist_846_436_n_35 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_35);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_35;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

INVx2_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_6),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_0),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_11),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

INVx5_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

INVx4_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_10),
.B1(n_16),
.B2(n_14),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_18),
.B(n_9),
.C(n_2),
.Y(n_23)
);

INVxp67_ASAP7_75t_SL g24 ( 
.A(n_21),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

INVx5_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_22),
.Y(n_28)
);

INVxp67_ASAP7_75t_SL g29 ( 
.A(n_26),
.Y(n_29)
);

XNOR2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_23),
.Y(n_30)
);

XNOR2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_27),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_29),
.B(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

NAND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_7),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_19),
.B1(n_20),
.B2(n_33),
.Y(n_35)
);


endmodule