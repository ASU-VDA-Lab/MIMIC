module fake_netlist_846_337_n_73 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_73);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_73;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_57;
wire n_70;
wire n_50;
wire n_41;
wire n_62;
wire n_44;
wire n_60;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_34;
wire n_31;
wire n_32;
wire n_58;
wire n_68;
wire n_26;
wire n_72;
wire n_71;
wire n_37;
wire n_42;
wire n_54;
wire n_69;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_35;
wire n_52;
wire n_38;
wire n_61;
wire n_27;
wire n_67;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_15),
.B1(n_9),
.B2(n_10),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_SL g29 ( 
.A(n_17),
.B(n_21),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_7),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_6),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_11),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_22),
.B(n_16),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_4),
.B(n_17),
.Y(n_36)
);

INVx3_ASAP7_75t_L g37 ( 
.A(n_2),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_3),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_8),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_31),
.B(n_12),
.Y(n_40)
);

OR2x6_ASAP7_75t_L g41 ( 
.A(n_32),
.B(n_12),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_31),
.B(n_18),
.Y(n_42)
);

O2A1O1Ixp33_ASAP7_75t_L g43 ( 
.A1(n_36),
.A2(n_20),
.B(n_19),
.C(n_18),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_31),
.B(n_19),
.Y(n_44)
);

BUFx8_ASAP7_75t_L g45 ( 
.A(n_35),
.Y(n_45)
);

INVx2_ASAP7_75t_SL g46 ( 
.A(n_45),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_41),
.B(n_42),
.Y(n_47)
);

O2A1O1Ixp5_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_35),
.B(n_37),
.C(n_26),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_41),
.B(n_35),
.Y(n_49)
);

NAND2x1_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_37),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_40),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_47),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_49),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_51),
.B(n_49),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

OAI21xp33_ASAP7_75t_L g58 ( 
.A1(n_53),
.A2(n_46),
.B(n_29),
.Y(n_58)
);

AOI22xp33_ASAP7_75t_L g59 ( 
.A1(n_53),
.A2(n_27),
.B1(n_37),
.B2(n_25),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_54),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_56),
.Y(n_61)
);

AOI22xp33_ASAP7_75t_SL g62 ( 
.A1(n_57),
.A2(n_56),
.B1(n_55),
.B2(n_38),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_61),
.Y(n_63)
);

OAI322xp33_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_43),
.A3(n_33),
.B1(n_28),
.B2(n_25),
.C1(n_39),
.C2(n_34),
.Y(n_64)
);

NAND5xp2_ASAP7_75t_L g65 ( 
.A(n_59),
.B(n_33),
.C(n_28),
.D(n_34),
.E(n_39),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_63),
.Y(n_66)
);

AOI221xp5_ASAP7_75t_L g67 ( 
.A1(n_65),
.A2(n_30),
.B1(n_23),
.B2(n_20),
.C(n_22),
.Y(n_67)
);

OR2x2_ASAP7_75t_L g68 ( 
.A(n_64),
.B(n_24),
.Y(n_68)
);

AND2x2_ASAP7_75t_SL g69 ( 
.A(n_67),
.B(n_1),
.Y(n_69)
);

BUFx3_ASAP7_75t_L g70 ( 
.A(n_66),
.Y(n_70)
);

OAI221xp5_ASAP7_75t_L g71 ( 
.A1(n_67),
.A2(n_62),
.B1(n_59),
.B2(n_58),
.C(n_68),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_70),
.Y(n_72)
);

AOI22xp5_ASAP7_75t_L g73 ( 
.A1(n_72),
.A2(n_69),
.B1(n_71),
.B2(n_70),
.Y(n_73)
);


endmodule