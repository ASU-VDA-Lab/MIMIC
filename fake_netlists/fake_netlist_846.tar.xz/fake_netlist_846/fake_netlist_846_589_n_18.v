module fake_netlist_846_589_n_18 (n_2, n_0, n_3, n_1, n_18);

input n_2;
input n_0;
input n_3;
input n_1;

output n_18;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_17;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

AND2x2_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_3),
.Y(n_4)
);

NAND2xp33_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_0),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_SL g11 ( 
.A1(n_8),
.A2(n_4),
.B(n_7),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

NAND4xp75_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_7),
.C(n_5),
.D(n_2),
.Y(n_13)
);

NAND5xp2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.C(n_9),
.D(n_2),
.E(n_3),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_8),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_11),
.B1(n_13),
.B2(n_2),
.C(n_1),
.Y(n_16)
);

XNOR2x1_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_14),
.Y(n_17)
);

AOI21xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_14),
.B(n_16),
.Y(n_18)
);


endmodule