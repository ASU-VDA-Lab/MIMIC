module fake_netlist_846_327_n_20 (n_4, n_2, n_3, n_0, n_1, n_20);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_5;
wire n_11;
wire n_8;

AOI22xp33_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_0),
.B1(n_4),
.B2(n_2),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVxp67_ASAP7_75t_SL g7 ( 
.A(n_1),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_0),
.B1(n_4),
.B2(n_8),
.Y(n_11)
);

INVxp67_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVxp67_ASAP7_75t_SL g13 ( 
.A(n_10),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_5),
.C(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

AOI211xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_6),
.B(n_14),
.C(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_6),
.B1(n_17),
.B2(n_14),
.Y(n_20)
);


endmodule