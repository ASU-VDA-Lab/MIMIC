module fake_netlist_846_1473_n_43 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_43);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_43;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NOR2xp67_ASAP7_75t_L g20 ( 
.A(n_8),
.B(n_5),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_1),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_0),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_22),
.B(n_2),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_3),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_26),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_21),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_28),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_23),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_25),
.B1(n_24),
.B2(n_4),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_12),
.B1(n_9),
.B2(n_7),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_13),
.Y(n_40)
);

BUFx4f_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_40),
.B1(n_17),
.B2(n_14),
.Y(n_43)
);


endmodule