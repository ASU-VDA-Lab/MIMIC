module fake_netlist_846_1175_n_23 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_23);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

OA21x2_ASAP7_75t_L g10 ( 
.A1(n_5),
.A2(n_7),
.B(n_4),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_2),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_6),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_11),
.B(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

AND2x6_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_9),
.Y(n_15)
);

OAI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B1(n_12),
.B2(n_10),
.Y(n_16)
);

NAND5xp2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.C(n_10),
.D(n_1),
.E(n_4),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_19),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_3),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_21),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);


endmodule