module fake_netlist_846_1023_n_31 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_31);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_31;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

INVx1_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_9),
.B(n_1),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_2),
.Y(n_19)
);

NOR2x1_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_10),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_17),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_16),
.B1(n_18),
.B2(n_19),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_7),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.Y(n_26)
);

INVxp67_ASAP7_75t_SL g27 ( 
.A(n_26),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_7),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_20),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI322xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_4),
.A3(n_3),
.B1(n_12),
.B2(n_13),
.C1(n_5),
.C2(n_8),
.Y(n_31)
);


endmodule