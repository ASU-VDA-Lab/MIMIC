module fake_netlist_846_340_n_14 (n_0, n_1, n_14);

input n_0;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_2;
wire n_13;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

INVx2_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx8_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OAI22xp33_ASAP7_75t_SL g10 ( 
.A1(n_8),
.A2(n_5),
.B1(n_6),
.B2(n_0),
.Y(n_10)
);

NAND5xp2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_0),
.C(n_1),
.D(n_6),
.E(n_10),
.Y(n_11)
);

AOI22x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B1(n_0),
.B2(n_1),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_1),
.B(n_13),
.Y(n_14)
);


endmodule