module fake_netlist_846_263_n_34 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_34);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

AND2x6_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_5),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_4),
.B1(n_6),
.B2(n_2),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_11),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_SL g22 ( 
.A(n_19),
.B(n_0),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_SL g25 ( 
.A(n_21),
.B(n_14),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_SL g27 ( 
.A1(n_25),
.A2(n_18),
.B1(n_16),
.B2(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_22),
.B1(n_16),
.B2(n_18),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_1),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI222xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_9),
.B1(n_10),
.B2(n_18),
.C1(n_22),
.C2(n_29),
.Y(n_34)
);


endmodule