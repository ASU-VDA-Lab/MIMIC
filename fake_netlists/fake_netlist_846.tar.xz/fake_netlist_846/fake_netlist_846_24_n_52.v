module fake_netlist_846_24_n_52 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_52);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_52;

wire n_49;
wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

OA21x2_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_2),
.B(n_15),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_0),
.B(n_22),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_19),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_R g28 ( 
.A(n_19),
.B(n_5),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_3),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_16),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_SL g33 ( 
.A(n_6),
.B(n_8),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_25),
.B(n_18),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_29),
.B(n_18),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_30),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_37),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_24),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_34),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_35),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_40),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_39),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_42),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_31),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_32),
.B(n_26),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_33),
.B1(n_28),
.B2(n_24),
.C(n_1),
.Y(n_48)
);

BUFx2_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_11),
.B1(n_9),
.B2(n_7),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_SL g51 ( 
.A1(n_48),
.A2(n_17),
.B1(n_14),
.B2(n_12),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_20),
.B1(n_23),
.B2(n_50),
.Y(n_52)
);


endmodule