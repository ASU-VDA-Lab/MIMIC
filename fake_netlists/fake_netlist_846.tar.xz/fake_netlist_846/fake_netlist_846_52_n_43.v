module fake_netlist_846_52_n_43 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_43);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_43;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

INVx2_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_12),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_5),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_22),
.A2(n_3),
.B(n_0),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_21),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_20),
.B1(n_26),
.B2(n_23),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_24),
.Y(n_32)
);

NOR2xp67_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_28),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_27),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_4),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

NOR4xp25_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_8),
.C(n_7),
.D(n_6),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_11),
.B1(n_9),
.B2(n_14),
.C(n_15),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_40),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_18),
.B1(n_19),
.B2(n_42),
.Y(n_43)
);


endmodule