module fake_netlist_846_1283_n_17 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_17);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_15;
wire n_13;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;
wire n_9;
wire n_8;

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVxp67_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_2),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_7),
.B(n_1),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_12)
);

AO31x2_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_6),
.A3(n_8),
.B(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_8),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_12),
.B(n_13),
.Y(n_17)
);


endmodule