module fake_netlist_846_439_n_57 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_57);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_57;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_30;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_5),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_3),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_6),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_18),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_15),
.A2(n_10),
.B1(n_17),
.B2(n_1),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_19),
.B(n_17),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_R g32 ( 
.A(n_23),
.B(n_0),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_20),
.B(n_18),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_24),
.A2(n_9),
.B1(n_7),
.B2(n_4),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_30),
.A2(n_24),
.B1(n_21),
.B2(n_29),
.Y(n_37)
);

CKINVDCx6p67_ASAP7_75t_R g38 ( 
.A(n_33),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_22),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_34),
.A2(n_28),
.B1(n_27),
.B2(n_11),
.Y(n_40)
);

INVx5_ASAP7_75t_L g41 ( 
.A(n_31),
.Y(n_41)
);

AOI21xp33_ASAP7_75t_SL g42 ( 
.A1(n_37),
.A2(n_35),
.B(n_31),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_42),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_39),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_33),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_35),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

OAI211xp5_ASAP7_75t_L g53 ( 
.A1(n_48),
.A2(n_13),
.B(n_32),
.C(n_49),
.Y(n_53)
);

AOI21xp33_ASAP7_75t_SL g54 ( 
.A1(n_51),
.A2(n_50),
.B(n_53),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_54),
.B(n_52),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_55),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_56),
.Y(n_57)
);


endmodule