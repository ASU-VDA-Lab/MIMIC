module fake_netlist_846_937_n_16 (n_4, n_2, n_3, n_0, n_1, n_16);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_2),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_2),
.Y(n_6)
);

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);

AND2x4_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_7),
.Y(n_12)
);

NAND4xp75_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.C(n_7),
.D(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_1),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_1),
.B1(n_3),
.B2(n_14),
.Y(n_16)
);


endmodule