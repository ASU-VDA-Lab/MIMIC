module fake_netlist_787_1203_n_18 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_18);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_18;

wire n_15;
wire n_11;
wire n_16;
wire n_17;
wire n_12;
wire n_9;
wire n_10;
wire n_13;
wire n_14;

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_2),
.A2(n_6),
.B1(n_1),
.B2(n_5),
.Y(n_9)
);

AND2x6_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_3),
.Y(n_12)
);

OA21x2_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_7),
.B(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NOR2xp67_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

OAI22xp33_ASAP7_75t_R g17 ( 
.A1(n_16),
.A2(n_9),
.B1(n_10),
.B2(n_4),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_7),
.B1(n_10),
.B2(n_12),
.C1(n_9),
.C2(n_11),
.Y(n_18)
);


endmodule