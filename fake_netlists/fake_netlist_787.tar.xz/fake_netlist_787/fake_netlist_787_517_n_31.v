module fake_netlist_787_517_n_31 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_31);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_31;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

AND3x2_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_9),
.C(n_8),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_9),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_10),
.A2(n_3),
.B(n_1),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_12),
.Y(n_19)
);

CKINVDCx16_ASAP7_75t_R g20 ( 
.A(n_19),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NOR2xp67_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_19),
.Y(n_23)
);

AOI211xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_18),
.B(n_14),
.C(n_13),
.Y(n_24)
);

AOI21xp33_ASAP7_75t_R g25 ( 
.A1(n_22),
.A2(n_11),
.B(n_16),
.Y(n_25)
);

AND4x1_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_5),
.C(n_4),
.D(n_3),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_22),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_15),
.Y(n_28)
);

OAI22x1_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B1(n_5),
.B2(n_4),
.Y(n_29)
);

NAND2x1_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_15),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_7),
.B1(n_8),
.B2(n_30),
.Y(n_31)
);


endmodule