module fake_netlist_787_191_n_26 (n_1, n_2, n_3, n_0, n_26);

input n_1;
input n_2;
input n_3;
input n_0;

output n_26;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_25;
wire n_5;
wire n_24;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_4;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_1),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_1),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_5),
.A2(n_0),
.B(n_3),
.C(n_6),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_10),
.Y(n_17)
);

OAI22xp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_5),
.B1(n_4),
.B2(n_12),
.Y(n_18)
);

INVx2_ASAP7_75t_SL g19 ( 
.A(n_16),
.Y(n_19)
);

AOI211xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_5),
.B(n_4),
.C(n_13),
.Y(n_20)
);

NAND3xp33_ASAP7_75t_SL g21 ( 
.A(n_18),
.B(n_14),
.C(n_3),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_20),
.B(n_18),
.C(n_3),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_4),
.B1(n_22),
.B2(n_23),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_4),
.B(n_22),
.Y(n_26)
);


endmodule