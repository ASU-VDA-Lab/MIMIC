module fake_netlist_787_1096_n_17 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_17);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_17;

wire n_15;
wire n_11;
wire n_16;
wire n_12;
wire n_9;
wire n_8;
wire n_10;
wire n_13;
wire n_14;

INVx1_ASAP7_75t_SL g8 ( 
.A(n_6),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_3),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_2),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_4),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_6),
.B(n_4),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B1(n_11),
.B2(n_8),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B(n_9),
.C(n_12),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_0),
.B1(n_1),
.B2(n_7),
.C(n_8),
.Y(n_17)
);


endmodule