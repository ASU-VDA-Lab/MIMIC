module fake_netlist_787_2187_n_18 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_18);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_18;

wire n_15;
wire n_11;
wire n_16;
wire n_17;
wire n_12;
wire n_9;
wire n_10;
wire n_13;
wire n_14;

INVx1_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_SL g10 ( 
.A(n_2),
.B(n_6),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_3),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_7),
.C(n_0),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B1(n_12),
.B2(n_11),
.Y(n_15)
);

O2A1O1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B(n_5),
.C(n_4),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);


endmodule