module fake_netlist_787_1103_n_6 (n_1, n_2, n_3, n_0, n_6);

input n_1;
input n_2;
input n_3;
input n_0;

output n_6;

wire n_5;
wire n_4;

BUFx3_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_4),
.B(n_1),
.Y(n_6)
);


endmodule