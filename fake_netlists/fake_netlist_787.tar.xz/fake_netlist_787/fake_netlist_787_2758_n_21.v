module fake_netlist_787_2758_n_21 (n_1, n_0, n_5, n_3, n_2, n_4, n_21);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_21;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_14;

INVx2_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVxp67_ASAP7_75t_SL g9 ( 
.A(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

AO21x2_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

AO21x2_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_4),
.B(n_2),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_6),
.A2(n_4),
.B(n_3),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_10),
.C(n_6),
.Y(n_15)
);

OAI31xp33_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_5),
.A3(n_8),
.B(n_11),
.Y(n_16)
);

OAI321xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_8),
.A3(n_11),
.B1(n_12),
.B2(n_14),
.C(n_16),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_12),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OR2x6_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_17),
.Y(n_21)
);


endmodule