module fake_netlist_787_2697_n_17 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_17);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_17;

wire n_15;
wire n_11;
wire n_16;
wire n_12;
wire n_9;
wire n_8;
wire n_10;
wire n_13;
wire n_14;

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_3),
.B(n_7),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

OA21x2_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B1(n_12),
.B2(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_1),
.B1(n_4),
.B2(n_5),
.C1(n_6),
.C2(n_11),
.Y(n_17)
);


endmodule