module fake_netlist_787_379_n_7 (n_1, n_0, n_7);

input n_1;
input n_0;

output n_7;

wire n_5;
wire n_6;
wire n_3;
wire n_2;
wire n_4;

NOR2xp33_ASAP7_75t_SL g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

OAI21x1_ASAP7_75t_L g3 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_3)
);

INVx1_ASAP7_75t_SL g4 ( 
.A(n_3),
.Y(n_4)
);

AOI21xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_3),
.B(n_1),
.Y(n_5)
);

INVxp67_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_0),
.B1(n_1),
.B2(n_4),
.Y(n_7)
);


endmodule