module fake_netlist_787_560_n_5 (n_0, n_5);

input n_0;

output n_5;

wire n_1;
wire n_3;
wire n_2;
wire n_4;

BUFx12f_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

INVx2_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

OAI21xp33_ASAP7_75t_SL g4 ( 
.A1(n_3),
.A2(n_0),
.B(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);


endmodule