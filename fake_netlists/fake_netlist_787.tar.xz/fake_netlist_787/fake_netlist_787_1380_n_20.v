module fake_netlist_787_1380_n_20 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_20);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_20;

wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_9;
wire n_10;
wire n_19;
wire n_14;

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_1),
.A2(n_3),
.B1(n_6),
.B2(n_2),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_0),
.B(n_1),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_4),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

NAND4xp25_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.C(n_7),
.D(n_5),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_11),
.B(n_7),
.Y(n_20)
);


endmodule