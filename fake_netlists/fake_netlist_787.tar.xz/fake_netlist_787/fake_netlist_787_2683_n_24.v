module fake_netlist_787_2683_n_24 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_24);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_24;

wire n_20;
wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_9;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_4),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_13),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B1(n_12),
.B2(n_11),
.C(n_10),
.Y(n_16)
);

NAND5xp2_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_10),
.C(n_15),
.D(n_4),
.E(n_6),
.Y(n_17)
);

AND2x2_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_11),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_17),
.B(n_12),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_7),
.C(n_6),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_SL g22 ( 
.A(n_20),
.B(n_18),
.C(n_7),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

AOI322xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_3),
.A3(n_5),
.B1(n_7),
.B2(n_8),
.C1(n_21),
.C2(n_22),
.Y(n_24)
);


endmodule