module fake_netlist_787_1898_n_21 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_21);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_21;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_19;
wire n_14;

INVx1_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_5),
.A2(n_9),
.B1(n_6),
.B2(n_2),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_7),
.B(n_4),
.C(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.B(n_14),
.C(n_12),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_8),
.Y(n_21)
);


endmodule