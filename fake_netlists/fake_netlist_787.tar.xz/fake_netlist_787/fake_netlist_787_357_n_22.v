module fake_netlist_787_357_n_22 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_22);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_22;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_21;
wire n_14;

OR2x2_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_6),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_3),
.B(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_4),
.Y(n_16)
);

OAI221xp5_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_7),
.B1(n_4),
.B2(n_0),
.C(n_2),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.Y(n_18)
);

AOI21xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_14),
.B(n_17),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_13),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_13),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_7),
.B1(n_8),
.B2(n_9),
.C1(n_20),
.C2(n_18),
.Y(n_22)
);


endmodule