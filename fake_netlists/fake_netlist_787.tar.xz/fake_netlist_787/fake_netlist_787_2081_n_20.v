module fake_netlist_787_2081_n_20 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_20);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_20;

wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_10;
wire n_19;
wire n_14;

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_2),
.B(n_6),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_L g12 ( 
.A(n_4),
.B(n_1),
.C(n_7),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_3),
.B(n_4),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.Y(n_16)
);

NAND3x1_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.C(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_5),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.B(n_5),
.Y(n_20)
);


endmodule