module fake_netlist_787_1942_n_16 (n_1, n_0, n_5, n_3, n_2, n_4, n_16);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_16;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_6;
wire n_14;
wire n_8;
wire n_12;
wire n_13;
wire n_9;

CKINVDCx16_ASAP7_75t_R g6 ( 
.A(n_5),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_2),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_R g8 ( 
.A(n_4),
.B(n_3),
.Y(n_8)
);

NOR2x1p5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_6),
.B1(n_10),
.B2(n_8),
.C(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_16)
);


endmodule