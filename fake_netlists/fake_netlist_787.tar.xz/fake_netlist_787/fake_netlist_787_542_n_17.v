module fake_netlist_787_542_n_17 (n_1, n_0, n_5, n_3, n_2, n_4, n_17);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_17;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_16;
wire n_6;
wire n_14;
wire n_8;
wire n_12;
wire n_13;
wire n_9;

AND2x2_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_2),
.Y(n_6)
);

OAI22xp33_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_0),
.B1(n_2),
.B2(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_3),
.Y(n_9)
);

NAND2x1p5_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_0),
.Y(n_10)
);

OAI22xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_1),
.B1(n_0),
.B2(n_3),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B1(n_7),
.B2(n_9),
.C(n_8),
.Y(n_15)
);

AOI21x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B(n_12),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_8),
.B1(n_10),
.B2(n_14),
.Y(n_17)
);


endmodule