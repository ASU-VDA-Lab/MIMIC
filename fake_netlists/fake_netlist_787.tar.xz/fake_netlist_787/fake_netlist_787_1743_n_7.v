module fake_netlist_787_1743_n_7 (n_1, n_0, n_7);

input n_1;
input n_0;

output n_7;

wire n_5;
wire n_6;
wire n_3;
wire n_2;
wire n_4;

AND2x6_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx4_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AOI21xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.Y(n_5)
);

NAND4xp75_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_1),
.C(n_0),
.D(n_4),
.Y(n_6)
);

OAI21xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_7)
);


endmodule