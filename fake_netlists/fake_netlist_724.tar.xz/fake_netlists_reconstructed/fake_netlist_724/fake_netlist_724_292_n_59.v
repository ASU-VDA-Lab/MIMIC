module fake_netlist_724_292_n_59 (n_3, n_14, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_5, n_59);

input n_3;
input n_14;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_5;

output n_59;

wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_20;
wire n_27;
wire n_36;
wire n_24;
wire n_37;
wire n_29;
wire n_41;
wire n_55;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_57;
wire n_25;
wire n_46;
wire n_23;
wire n_56;
wire n_21;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_22;
wire n_19;

AND2x4_ASAP7_75t_L g19 ( 
.A(n_4),
.B(n_3),
.Y(n_19)
);

BUFx12f_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_5),
.B(n_10),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_1),
.B(n_14),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_9),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_16),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_SL g27 ( 
.A(n_8),
.B(n_2),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_7),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_21),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_24),
.B(n_23),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_19),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_30),
.A2(n_31),
.B(n_29),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_36),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx6_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_29),
.C(n_37),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_26),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_35),
.B1(n_37),
.B2(n_25),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_35),
.B1(n_26),
.B2(n_38),
.C(n_19),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_42),
.B1(n_38),
.B2(n_35),
.Y(n_48)
);

AO22x2_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_38),
.B1(n_35),
.B2(n_19),
.Y(n_49)
);

CKINVDCx16_ASAP7_75t_R g50 ( 
.A(n_43),
.Y(n_50)
);

NOR4xp75_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_50),
.C(n_20),
.D(n_15),
.Y(n_51)
);

NOR3xp33_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_34),
.C(n_38),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_38),
.Y(n_53)
);

AND2x2_ASAP7_75t_SL g54 ( 
.A(n_50),
.B(n_27),
.Y(n_54)
);

NAND4xp75_ASAP7_75t_L g55 ( 
.A(n_47),
.B(n_20),
.C(n_17),
.D(n_15),
.Y(n_55)
);

AOI22x1_ASAP7_75t_SL g56 ( 
.A1(n_54),
.A2(n_51),
.B1(n_55),
.B2(n_52),
.Y(n_56)
);

AOI31xp33_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_18),
.A3(n_17),
.B(n_0),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_58)
);

OAI21xp5_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_57),
.B(n_56),
.Y(n_59)
);


endmodule