module fake_netlist_724_3012_n_54 (n_3, n_14, n_20, n_0, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_54);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_54;

wire n_32;
wire n_48;
wire n_33;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_37;
wire n_29;
wire n_41;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_25;
wire n_46;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_40;
wire n_34;
wire n_51;
wire n_26;

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_15),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_10),
.B(n_1),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_22),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_24),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_2),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_16),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_13),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_4),
.B(n_23),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_18),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_8),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_28),
.A2(n_22),
.B1(n_21),
.B2(n_0),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

NOR3xp33_ASAP7_75t_SL g38 ( 
.A(n_26),
.B(n_21),
.C(n_3),
.Y(n_38)
);

NAND2xp33_ASAP7_75t_SL g39 ( 
.A(n_27),
.B(n_5),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_32),
.B1(n_29),
.B2(n_25),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_35),
.B1(n_27),
.B2(n_31),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

NOR4xp25_ASAP7_75t_SL g44 ( 
.A(n_41),
.B(n_38),
.C(n_31),
.D(n_6),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_SL g47 ( 
.A(n_46),
.B(n_40),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_34),
.Y(n_48)
);

NAND2xp33_ASAP7_75t_SL g49 ( 
.A(n_48),
.B(n_33),
.Y(n_49)
);

NAND3xp33_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_34),
.C(n_7),
.Y(n_50)
);

OR3x2_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_12),
.C(n_11),
.Y(n_51)
);

NOR4xp25_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_34),
.C(n_17),
.D(n_14),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_SL g54 ( 
.A1(n_53),
.A2(n_52),
.B1(n_20),
.B2(n_19),
.Y(n_54)
);


endmodule