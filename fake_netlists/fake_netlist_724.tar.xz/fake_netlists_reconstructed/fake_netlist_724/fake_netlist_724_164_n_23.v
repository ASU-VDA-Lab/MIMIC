module fake_netlist_724_164_n_23 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_23);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_23;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

BUFx8_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_10),
.Y(n_13)
);

OR2x6_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_5),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_13),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_15),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_9),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI322xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_12),
.A3(n_4),
.B1(n_2),
.B2(n_1),
.C1(n_7),
.C2(n_6),
.Y(n_23)
);


endmodule