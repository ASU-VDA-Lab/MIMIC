module fake_netlist_724_214_n_51 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_51);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_51;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_27;
wire n_37;
wire n_36;
wire n_24;
wire n_41;
wire n_29;
wire n_43;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_25;
wire n_46;
wire n_23;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_6),
.A2(n_10),
.B1(n_16),
.B2(n_22),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_0),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_14),
.B(n_20),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_20),
.B(n_7),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_15),
.B(n_21),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_12),
.Y(n_31)
);

AND2x6_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_2),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_30),
.A2(n_23),
.B1(n_31),
.B2(n_27),
.Y(n_35)
);

BUFx3_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_34),
.B1(n_33),
.B2(n_30),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx3_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

AND2x4_ASAP7_75t_SL g41 ( 
.A(n_38),
.B(n_24),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_41),
.B(n_36),
.Y(n_42)
);

OAI31xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_29),
.A3(n_39),
.B(n_26),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_32),
.B1(n_40),
.B2(n_43),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_42),
.Y(n_45)
);

NOR2x1_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_40),
.Y(n_46)
);

NOR3xp33_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_17),
.C(n_15),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

NAND2x1_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_3),
.Y(n_49)
);

AOI32xp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_18),
.A3(n_8),
.B1(n_4),
.B2(n_5),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_SL g51 ( 
.A1(n_50),
.A2(n_49),
.B1(n_13),
.B2(n_9),
.Y(n_51)
);


endmodule