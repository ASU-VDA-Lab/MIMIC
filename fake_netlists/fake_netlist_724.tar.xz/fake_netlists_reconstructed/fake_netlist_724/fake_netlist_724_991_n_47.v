module fake_netlist_724_991_n_47 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_19, n_5, n_47);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_19;
input n_5;

output n_47;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_37;
wire n_24;
wire n_29;
wire n_41;
wire n_43;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_25;
wire n_46;
wire n_23;
wire n_21;
wire n_26;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_22;

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_9),
.B(n_3),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_12),
.Y(n_29)
);

OR2x6_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_18),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_27),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

OAI22xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_30),
.B1(n_31),
.B2(n_32),
.Y(n_35)
);

INVxp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_30),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

O2A1O1Ixp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_24),
.B(n_29),
.C(n_28),
.Y(n_40)
);

NOR3xp33_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_39),
.C(n_23),
.Y(n_41)
);

OA21x2_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_25),
.B(n_26),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_19),
.Y(n_43)
);

NAND3x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_25),
.C(n_23),
.Y(n_44)
);

OAI222xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C1(n_5),
.C2(n_4),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_7),
.Y(n_46)
);

AOI322xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_45),
.A3(n_14),
.B1(n_13),
.B2(n_8),
.C1(n_17),
.C2(n_16),
.Y(n_47)
);


endmodule