module fake_netlist_724_3295_n_17 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_17);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_17;

wire n_12;
wire n_10;
wire n_15;
wire n_14;
wire n_13;
wire n_16;
wire n_9;
wire n_11;

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_11),
.B1(n_9),
.B2(n_10),
.C(n_0),
.Y(n_13)
);

XOR2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_1),
.Y(n_14)
);

AOI21xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_3),
.B(n_2),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_5),
.C(n_4),
.Y(n_16)
);

AO221x1_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_7),
.B1(n_5),
.B2(n_4),
.C(n_8),
.Y(n_17)
);


endmodule