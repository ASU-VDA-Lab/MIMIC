module fake_netlist_724_1944_n_47 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_47);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_47;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_37;
wire n_29;
wire n_24;
wire n_41;
wire n_43;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_25;
wire n_46;
wire n_23;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_26;

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_21),
.Y(n_23)
);

OAI21x1_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_13),
.B(n_5),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_18),
.B(n_12),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_3),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_8),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

INVx3_ASAP7_75t_SL g34 ( 
.A(n_25),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_30),
.Y(n_35)
);

INVx5_ASAP7_75t_SL g36 ( 
.A(n_32),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_34),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_26),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_31),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_29),
.Y(n_40)
);

OAI221xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_23),
.B1(n_24),
.B2(n_0),
.C(n_1),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

NOR2x1p5_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_2),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_4),
.Y(n_44)
);

OAI22x1_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_10),
.B1(n_9),
.B2(n_6),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_11),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_20),
.B1(n_22),
.B2(n_46),
.Y(n_47)
);


endmodule