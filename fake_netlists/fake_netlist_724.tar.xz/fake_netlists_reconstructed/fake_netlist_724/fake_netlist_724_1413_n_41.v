module fake_netlist_724_1413_n_41 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_41);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_41;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_31;
wire n_18;
wire n_28;
wire n_39;
wire n_25;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_38;
wire n_34;
wire n_40;
wire n_16;
wire n_22;
wire n_19;

INVx1_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

BUFx8_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

OAI22xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_12),
.B1(n_11),
.B2(n_9),
.Y(n_20)
);

BUFx12f_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_9),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_22),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NOR4xp25_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_20),
.C(n_18),
.D(n_21),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

XNOR2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_11),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_32),
.B(n_29),
.Y(n_34)
);

XNOR2xp5_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_3),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

OAI21x1_ASAP7_75t_SL g37 ( 
.A1(n_35),
.A2(n_6),
.B(n_4),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NOR2x1_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_7),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_SL g41 ( 
.A1(n_39),
.A2(n_10),
.B1(n_37),
.B2(n_40),
.Y(n_41)
);


endmodule