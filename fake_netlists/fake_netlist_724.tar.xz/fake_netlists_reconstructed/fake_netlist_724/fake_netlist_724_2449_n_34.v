module fake_netlist_724_2449_n_34 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_5, n_34);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_34;

wire n_32;
wire n_33;
wire n_30;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_18;
wire n_31;
wire n_28;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_22;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_0),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_4),
.B(n_10),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

O2A1O1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_14),
.B(n_13),
.C(n_12),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_21),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_12),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_25),
.B(n_17),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_23),
.B1(n_19),
.B2(n_18),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_29),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_28),
.B2(n_24),
.C1(n_14),
.C2(n_13),
.Y(n_31)
);

CKINVDCx16_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

OAI22x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_15),
.B1(n_3),
.B2(n_1),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_16),
.B1(n_9),
.B2(n_8),
.Y(n_34)
);


endmodule