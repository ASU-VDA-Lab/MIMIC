module fake_netlist_724_236_n_155 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_6, n_19, n_5, n_155);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_6;
input n_19;
input n_5;

output n_155;

wire n_154;
wire n_68;
wire n_82;
wire n_37;
wire n_112;
wire n_141;
wire n_31;
wire n_39;
wire n_121;
wire n_65;
wire n_140;
wire n_144;
wire n_128;
wire n_56;
wire n_130;
wire n_94;
wire n_62;
wire n_69;
wire n_123;
wire n_97;
wire n_135;
wire n_139;
wire n_55;
wire n_148;
wire n_110;
wire n_102;
wire n_60;
wire n_105;
wire n_33;
wire n_61;
wire n_75;
wire n_106;
wire n_79;
wire n_30;
wire n_118;
wire n_54;
wire n_77;
wire n_73;
wire n_27;
wire n_125;
wire n_24;
wire n_131;
wire n_85;
wire n_126;
wire n_120;
wire n_116;
wire n_132;
wire n_70;
wire n_142;
wire n_129;
wire n_67;
wire n_92;
wire n_81;
wire n_44;
wire n_124;
wire n_74;
wire n_53;
wire n_64;
wire n_107;
wire n_138;
wire n_49;
wire n_40;
wire n_51;
wire n_147;
wire n_59;
wire n_111;
wire n_117;
wire n_22;
wire n_93;
wire n_84;
wire n_32;
wire n_48;
wire n_143;
wire n_35;
wire n_136;
wire n_96;
wire n_104;
wire n_115;
wire n_41;
wire n_98;
wire n_100;
wire n_145;
wire n_76;
wire n_57;
wire n_43;
wire n_137;
wire n_71;
wire n_25;
wire n_113;
wire n_80;
wire n_108;
wire n_119;
wire n_87;
wire n_42;
wire n_34;
wire n_89;
wire n_58;
wire n_86;
wire n_72;
wire n_114;
wire n_151;
wire n_90;
wire n_63;
wire n_101;
wire n_127;
wire n_146;
wire n_36;
wire n_29;
wire n_66;
wire n_83;
wire n_91;
wire n_95;
wire n_150;
wire n_152;
wire n_45;
wire n_28;
wire n_52;
wire n_133;
wire n_78;
wire n_153;
wire n_46;
wire n_122;
wire n_88;
wire n_134;
wire n_23;
wire n_99;
wire n_47;
wire n_50;
wire n_38;
wire n_109;
wire n_103;
wire n_149;
wire n_26;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_20),
.Y(n_24)
);

INVxp33_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_21),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_21),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_8),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_19),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_12),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

BUFx10_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_25),
.A2(n_8),
.B1(n_3),
.B2(n_2),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_29),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_29),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_25),
.B(n_3),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_33),
.B1(n_31),
.B2(n_22),
.Y(n_43)
);

A2O1A1Ixp33_ASAP7_75t_L g44 ( 
.A1(n_36),
.A2(n_40),
.B(n_38),
.C(n_41),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_34),
.B(n_30),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_34),
.B(n_30),
.Y(n_46)
);

INVx4_ASAP7_75t_L g47 ( 
.A(n_37),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_36),
.A2(n_33),
.B(n_32),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_39),
.A2(n_32),
.B1(n_28),
.B2(n_24),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_37),
.B(n_38),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_L g51 ( 
.A1(n_40),
.A2(n_4),
.B(n_0),
.Y(n_51)
);

OAI321xp33_ASAP7_75t_L g52 ( 
.A1(n_39),
.A2(n_10),
.A3(n_9),
.B1(n_11),
.B2(n_13),
.C(n_12),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_35),
.B(n_9),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_5),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_47),
.B(n_6),
.Y(n_55)
);

OAI22xp5_ASAP7_75t_L g56 ( 
.A1(n_44),
.A2(n_49),
.B1(n_53),
.B2(n_48),
.Y(n_56)
);

AND2x4_ASAP7_75t_L g57 ( 
.A(n_47),
.B(n_10),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_47),
.B(n_46),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_44),
.Y(n_59)
);

AND2x4_ASAP7_75t_L g60 ( 
.A(n_45),
.B(n_13),
.Y(n_60)
);

INVx3_ASAP7_75t_L g61 ( 
.A(n_51),
.Y(n_61)
);

BUFx6f_ASAP7_75t_L g62 ( 
.A(n_52),
.Y(n_62)
);

BUFx3_ASAP7_75t_L g63 ( 
.A(n_43),
.Y(n_63)
);

AND2x2_ASAP7_75t_L g64 ( 
.A(n_47),
.B(n_14),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_44),
.Y(n_65)
);

AND2x2_ASAP7_75t_L g66 ( 
.A(n_47),
.B(n_14),
.Y(n_66)
);

HB1xp67_ASAP7_75t_L g67 ( 
.A(n_57),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_59),
.Y(n_68)
);

INVx3_ASAP7_75t_L g69 ( 
.A(n_57),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_61),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_61),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_61),
.Y(n_72)
);

AOI22xp33_ASAP7_75t_L g73 ( 
.A1(n_62),
.A2(n_63),
.B1(n_65),
.B2(n_59),
.Y(n_73)
);

INVx3_ASAP7_75t_L g74 ( 
.A(n_57),
.Y(n_74)
);

OR2x2_ASAP7_75t_L g75 ( 
.A(n_58),
.B(n_15),
.Y(n_75)
);

BUFx2_ASAP7_75t_L g76 ( 
.A(n_57),
.Y(n_76)
);

AND2x2_ASAP7_75t_L g77 ( 
.A(n_58),
.B(n_15),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_59),
.Y(n_78)
);

NAND2xp5_ASAP7_75t_SL g79 ( 
.A(n_75),
.B(n_58),
.Y(n_79)
);

OAI22xp5_ASAP7_75t_L g80 ( 
.A1(n_75),
.A2(n_62),
.B1(n_65),
.B2(n_56),
.Y(n_80)
);

NAND2xp33_ASAP7_75t_SL g81 ( 
.A(n_75),
.B(n_64),
.Y(n_81)
);

AND2x2_ASAP7_75t_L g82 ( 
.A(n_77),
.B(n_58),
.Y(n_82)
);

NAND3xp33_ASAP7_75t_L g83 ( 
.A(n_73),
.B(n_62),
.C(n_56),
.Y(n_83)
);

AND2x2_ASAP7_75t_L g84 ( 
.A(n_77),
.B(n_64),
.Y(n_84)
);

OA21x2_ASAP7_75t_L g85 ( 
.A1(n_70),
.A2(n_65),
.B(n_54),
.Y(n_85)
);

AND2x2_ASAP7_75t_L g86 ( 
.A(n_77),
.B(n_76),
.Y(n_86)
);

AND2x2_ASAP7_75t_L g87 ( 
.A(n_82),
.B(n_76),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_82),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_79),
.Y(n_89)
);

NAND2xp5_ASAP7_75t_L g90 ( 
.A(n_84),
.B(n_68),
.Y(n_90)
);

AND2x2_ASAP7_75t_L g91 ( 
.A(n_84),
.B(n_67),
.Y(n_91)
);

AND2x2_ASAP7_75t_L g92 ( 
.A(n_86),
.B(n_67),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_86),
.Y(n_93)
);

NOR2x1_ASAP7_75t_L g94 ( 
.A(n_89),
.B(n_57),
.Y(n_94)
);

OR2x2_ASAP7_75t_L g95 ( 
.A(n_92),
.B(n_81),
.Y(n_95)
);

INVx1_ASAP7_75t_SL g96 ( 
.A(n_92),
.Y(n_96)
);

NAND2x1_ASAP7_75t_L g97 ( 
.A(n_89),
.B(n_70),
.Y(n_97)
);

AOI22xp33_ASAP7_75t_L g98 ( 
.A1(n_93),
.A2(n_63),
.B1(n_57),
.B2(n_60),
.Y(n_98)
);

OR2x2_ASAP7_75t_L g99 ( 
.A(n_93),
.B(n_60),
.Y(n_99)
);

OAI221xp5_ASAP7_75t_L g100 ( 
.A1(n_88),
.A2(n_63),
.B1(n_56),
.B2(n_73),
.C(n_64),
.Y(n_100)
);

INVx1_ASAP7_75t_SL g101 ( 
.A(n_91),
.Y(n_101)
);

NAND2xp5_ASAP7_75t_L g102 ( 
.A(n_96),
.B(n_88),
.Y(n_102)
);

INVx2_ASAP7_75t_SL g103 ( 
.A(n_97),
.Y(n_103)
);

NAND2xp5_ASAP7_75t_L g104 ( 
.A(n_101),
.B(n_90),
.Y(n_104)
);

NOR2xp33_ASAP7_75t_L g105 ( 
.A(n_95),
.B(n_63),
.Y(n_105)
);

OAI22xp5_ASAP7_75t_L g106 ( 
.A1(n_100),
.A2(n_90),
.B1(n_87),
.B2(n_80),
.Y(n_106)
);

AND2x2_ASAP7_75t_L g107 ( 
.A(n_99),
.B(n_87),
.Y(n_107)
);

NOR2xp33_ASAP7_75t_L g108 ( 
.A(n_100),
.B(n_60),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_94),
.Y(n_109)
);

NAND2xp33_ASAP7_75t_SL g110 ( 
.A(n_98),
.B(n_64),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_96),
.B(n_68),
.Y(n_111)
);

AND2x2_ASAP7_75t_L g112 ( 
.A(n_96),
.B(n_78),
.Y(n_112)
);

AND2x2_ASAP7_75t_L g113 ( 
.A(n_96),
.B(n_78),
.Y(n_113)
);

AOI221xp5_ASAP7_75t_L g114 ( 
.A1(n_106),
.A2(n_60),
.B1(n_80),
.B2(n_57),
.C(n_66),
.Y(n_114)
);

NAND3xp33_ASAP7_75t_L g115 ( 
.A(n_109),
.B(n_83),
.C(n_62),
.Y(n_115)
);

NAND3xp33_ASAP7_75t_L g116 ( 
.A(n_109),
.B(n_83),
.C(n_62),
.Y(n_116)
);

NOR2xp33_ASAP7_75t_L g117 ( 
.A(n_102),
.B(n_16),
.Y(n_117)
);

AOI211x1_ASAP7_75t_L g118 ( 
.A1(n_104),
.A2(n_66),
.B(n_18),
.C(n_16),
.Y(n_118)
);

NAND2xp5_ASAP7_75t_L g119 ( 
.A(n_112),
.B(n_60),
.Y(n_119)
);

NOR2x1_ASAP7_75t_L g120 ( 
.A(n_111),
.B(n_57),
.Y(n_120)
);

INVx1_ASAP7_75t_L g121 ( 
.A(n_113),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_113),
.Y(n_122)
);

NAND4xp25_ASAP7_75t_L g123 ( 
.A(n_105),
.B(n_66),
.C(n_60),
.D(n_69),
.Y(n_123)
);

NOR2x1_ASAP7_75t_L g124 ( 
.A(n_106),
.B(n_66),
.Y(n_124)
);

NOR2x1_ASAP7_75t_L g125 ( 
.A(n_108),
.B(n_69),
.Y(n_125)
);

NOR2xp67_ASAP7_75t_L g126 ( 
.A(n_103),
.B(n_7),
.Y(n_126)
);

AOI22xp5_ASAP7_75t_L g127 ( 
.A1(n_123),
.A2(n_110),
.B1(n_107),
.B2(n_103),
.Y(n_127)
);

AOI22xp5_ASAP7_75t_L g128 ( 
.A1(n_124),
.A2(n_62),
.B1(n_74),
.B2(n_69),
.Y(n_128)
);

INVx1_ASAP7_75t_L g129 ( 
.A(n_121),
.Y(n_129)
);

INVx2_ASAP7_75t_L g130 ( 
.A(n_122),
.Y(n_130)
);

INVx1_ASAP7_75t_L g131 ( 
.A(n_117),
.Y(n_131)
);

XNOR2xp5_ASAP7_75t_L g132 ( 
.A(n_125),
.B(n_69),
.Y(n_132)
);

INVx2_ASAP7_75t_L g133 ( 
.A(n_120),
.Y(n_133)
);

INVx2_ASAP7_75t_L g134 ( 
.A(n_118),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_119),
.Y(n_135)
);

AO22x2_ASAP7_75t_L g136 ( 
.A1(n_116),
.A2(n_74),
.B1(n_71),
.B2(n_70),
.Y(n_136)
);

NAND3xp33_ASAP7_75t_L g137 ( 
.A(n_114),
.B(n_62),
.C(n_71),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_126),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_130),
.Y(n_139)
);

AO22x2_ASAP7_75t_L g140 ( 
.A1(n_129),
.A2(n_138),
.B1(n_133),
.B2(n_131),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_135),
.Y(n_141)
);

AND2x4_ASAP7_75t_L g142 ( 
.A(n_134),
.B(n_115),
.Y(n_142)
);

INVx1_ASAP7_75t_SL g143 ( 
.A(n_132),
.Y(n_143)
);

INVx1_ASAP7_75t_SL g144 ( 
.A(n_127),
.Y(n_144)
);

INVx2_ASAP7_75t_L g145 ( 
.A(n_136),
.Y(n_145)
);

AND2x4_ASAP7_75t_L g146 ( 
.A(n_128),
.B(n_137),
.Y(n_146)
);

INVx3_ASAP7_75t_L g147 ( 
.A(n_136),
.Y(n_147)
);

AOI221xp5_ASAP7_75t_L g148 ( 
.A1(n_144),
.A2(n_62),
.B1(n_61),
.B2(n_55),
.C(n_72),
.Y(n_148)
);

AND4x1_ASAP7_75t_L g149 ( 
.A(n_141),
.B(n_54),
.C(n_85),
.D(n_140),
.Y(n_149)
);

NAND2xp5_ASAP7_75t_L g150 ( 
.A(n_139),
.B(n_85),
.Y(n_150)
);

INVx2_ASAP7_75t_L g151 ( 
.A(n_150),
.Y(n_151)
);

OAI21xp5_ASAP7_75t_L g152 ( 
.A1(n_149),
.A2(n_147),
.B(n_145),
.Y(n_152)
);

NAND2xp5_ASAP7_75t_L g153 ( 
.A(n_148),
.B(n_142),
.Y(n_153)
);

AOI222xp33_ASAP7_75t_L g154 ( 
.A1(n_153),
.A2(n_147),
.B1(n_143),
.B2(n_140),
.C1(n_146),
.C2(n_145),
.Y(n_154)
);

OAI221xp5_ASAP7_75t_R g155 ( 
.A1(n_154),
.A2(n_152),
.B1(n_140),
.B2(n_151),
.C(n_146),
.Y(n_155)
);


endmodule