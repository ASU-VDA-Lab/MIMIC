module fake_netlist_724_1855_n_26 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_26);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_26;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_18;
wire n_25;
wire n_23;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

INVx2_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

XOR2xp5_ASAP7_75t_R g15 ( 
.A(n_12),
.B(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_4),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_7),
.A2(n_1),
.B1(n_13),
.B2(n_5),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_2),
.B(n_11),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_6),
.B(n_3),
.C(n_0),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_20),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_15),
.B(n_16),
.C(n_18),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_8),
.B(n_6),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);


endmodule