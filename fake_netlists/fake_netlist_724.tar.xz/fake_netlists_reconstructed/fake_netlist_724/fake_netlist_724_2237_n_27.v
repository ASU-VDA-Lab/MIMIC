module fake_netlist_724_2237_n_27 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_27);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_27;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_11;
wire n_9;
wire n_25;
wire n_12;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_0),
.A2(n_6),
.B1(n_4),
.B2(n_2),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_0),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_2),
.B(n_1),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_4),
.B(n_3),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

INVxp67_ASAP7_75t_SL g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_9),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_18),
.B1(n_12),
.B2(n_10),
.Y(n_21)
);

OAI21xp33_ASAP7_75t_SL g22 ( 
.A1(n_20),
.A2(n_12),
.B(n_15),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_20),
.B1(n_5),
.B2(n_3),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_SL g26 ( 
.A1(n_23),
.A2(n_7),
.B(n_6),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_8),
.B(n_26),
.Y(n_27)
);


endmodule