module fake_netlist_724_1444_n_52 (n_3, n_14, n_20, n_0, n_27, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_25, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_26, n_16, n_22, n_6, n_19, n_5, n_52);

input n_3;
input n_14;
input n_20;
input n_0;
input n_27;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_25;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_26;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_52;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_36;
wire n_37;
wire n_41;
wire n_29;
wire n_43;
wire n_31;
wire n_45;
wire n_39;
wire n_28;
wire n_46;
wire n_47;
wire n_44;
wire n_42;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_16),
.B(n_5),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

BUFx10_ASAP7_75t_L g30 ( 
.A(n_10),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_4),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_7),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_24),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_2),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_12),
.B(n_13),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_3),
.B(n_23),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

OAI21xp33_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_1),
.B(n_0),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_33),
.A2(n_34),
.B1(n_32),
.B2(n_31),
.Y(n_39)
);

AND2x4_ASAP7_75t_SL g40 ( 
.A(n_37),
.B(n_30),
.Y(n_40)
);

CKINVDCx6p67_ASAP7_75t_R g41 ( 
.A(n_39),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_38),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_41),
.Y(n_44)
);

OAI221xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_28),
.B1(n_29),
.B2(n_24),
.C(n_25),
.Y(n_45)
);

AOI322xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_42),
.A3(n_26),
.B1(n_25),
.B2(n_29),
.C1(n_35),
.C2(n_36),
.Y(n_46)
);

AOI322xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_26),
.A3(n_29),
.B1(n_9),
.B2(n_14),
.C1(n_6),
.C2(n_8),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

NOR4xp25_ASAP7_75t_SL g49 ( 
.A(n_47),
.B(n_18),
.C(n_17),
.D(n_15),
.Y(n_49)
);

INVx2_ASAP7_75t_SL g50 ( 
.A(n_48),
.Y(n_50)
);

OAI22x1_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_21),
.B1(n_20),
.B2(n_19),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_22),
.B1(n_27),
.B2(n_51),
.Y(n_52)
);


endmodule