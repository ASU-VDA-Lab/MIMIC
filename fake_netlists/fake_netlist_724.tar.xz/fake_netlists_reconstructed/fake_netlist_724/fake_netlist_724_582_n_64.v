module fake_netlist_724_582_n_64 (n_3, n_14, n_20, n_0, n_27, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_25, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_26, n_16, n_22, n_6, n_19, n_5, n_64);

input n_3;
input n_14;
input n_20;
input n_0;
input n_27;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_25;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_26;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_64;

wire n_60;
wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_61;
wire n_30;
wire n_63;
wire n_35;
wire n_54;
wire n_36;
wire n_29;
wire n_41;
wire n_37;
wire n_55;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_57;
wire n_46;
wire n_56;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_62;
wire n_50;
wire n_38;
wire n_49;
wire n_40;
wire n_34;
wire n_51;
wire n_59;

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_12),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

NOR2xp67_ASAP7_75t_L g32 ( 
.A(n_5),
.B(n_25),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_17),
.B(n_26),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_16),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_1),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_3),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_20),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_8),
.Y(n_38)
);

CKINVDCx16_ASAP7_75t_R g39 ( 
.A(n_11),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_28),
.Y(n_40)
);

AND2x6_ASAP7_75t_L g41 ( 
.A(n_30),
.B(n_0),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_28),
.B(n_24),
.Y(n_42)
);

INVx3_ASAP7_75t_SL g43 ( 
.A(n_39),
.Y(n_43)
);

INVxp67_ASAP7_75t_SL g44 ( 
.A(n_29),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_40),
.A2(n_31),
.B1(n_35),
.B2(n_34),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_38),
.B(n_36),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_41),
.B1(n_42),
.B2(n_33),
.Y(n_48)
);

AOI322xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_33),
.A3(n_43),
.B1(n_27),
.B2(n_24),
.C1(n_26),
.C2(n_37),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_41),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_50),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

NOR2xp67_ASAP7_75t_SL g53 ( 
.A(n_52),
.B(n_45),
.Y(n_53)
);

NOR3xp33_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_32),
.C(n_49),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_2),
.Y(n_55)
);

AOI211xp5_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_9),
.Y(n_57)
);

AOI22x1_ASAP7_75t_L g58 ( 
.A1(n_53),
.A2(n_14),
.B1(n_13),
.B2(n_10),
.Y(n_58)
);

CKINVDCx5p33_ASAP7_75t_R g59 ( 
.A(n_58),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_56),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_60),
.Y(n_62)
);

OR2x2_ASAP7_75t_L g63 ( 
.A(n_61),
.B(n_15),
.Y(n_63)
);

AOI322xp5_ASAP7_75t_L g64 ( 
.A1(n_62),
.A2(n_18),
.A3(n_21),
.B1(n_22),
.B2(n_23),
.C1(n_59),
.C2(n_63),
.Y(n_64)
);


endmodule