module fake_netlist_724_2144_n_15 (n_0, n_2, n_1, n_15);

input n_0;
input n_2;
input n_1;

output n_15;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_14;
wire n_3;
wire n_4;
wire n_5;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_0),
.Y(n_4)
);

O2A1O1Ixp33_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_4),
.B(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_5),
.Y(n_10)
);

O2A1O1Ixp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_11)
);

NAND2xp33_ASAP7_75t_SL g12 ( 
.A(n_9),
.B(n_1),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_2),
.B1(n_10),
.B2(n_9),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

AO21x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B(n_11),
.Y(n_15)
);


endmodule