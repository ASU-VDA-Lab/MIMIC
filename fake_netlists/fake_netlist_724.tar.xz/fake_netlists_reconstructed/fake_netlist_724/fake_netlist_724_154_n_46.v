module fake_netlist_724_154_n_46 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_6, n_19, n_5, n_46);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_6;
input n_19;
input n_5;

output n_46;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_27;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_43;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_25;
wire n_23;
wire n_26;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_22;

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_10),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_15),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

INVx2_ASAP7_75t_SL g27 ( 
.A(n_17),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_13),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_4),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_20),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_18),
.B(n_17),
.C(n_16),
.Y(n_32)
);

O2A1O1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_27),
.A2(n_19),
.B(n_18),
.C(n_16),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_30),
.B1(n_26),
.B2(n_24),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_24),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_29),
.Y(n_37)
);

OAI22xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_29),
.B1(n_28),
.B2(n_25),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_SL g39 ( 
.A1(n_37),
.A2(n_33),
.B(n_32),
.Y(n_39)
);

AOI211xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_23),
.B(n_21),
.C(n_19),
.Y(n_40)
);

AOI211xp5_ASAP7_75t_SL g41 ( 
.A1(n_38),
.A2(n_21),
.B(n_1),
.C(n_0),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_39),
.B1(n_5),
.B2(n_3),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_6),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_11),
.B1(n_12),
.B2(n_44),
.Y(n_46)
);


endmodule