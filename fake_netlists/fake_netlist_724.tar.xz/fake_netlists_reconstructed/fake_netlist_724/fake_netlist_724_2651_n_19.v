module fake_netlist_724_2651_n_19 (n_1, n_2, n_0, n_3, n_4, n_5, n_19);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;
input n_5;

output n_19;

wire n_14;
wire n_17;
wire n_13;
wire n_7;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_8;
wire n_10;
wire n_15;
wire n_16;
wire n_6;

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_R g7 ( 
.A(n_1),
.B(n_3),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_R g8 ( 
.A(n_5),
.B(n_4),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_1),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

CKINVDCx16_ASAP7_75t_R g12 ( 
.A(n_10),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

NAND2x1p5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

AOI21xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_6),
.B(n_3),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

XNOR2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_2),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_17),
.A2(n_18),
.B1(n_7),
.B2(n_8),
.Y(n_19)
);


endmodule