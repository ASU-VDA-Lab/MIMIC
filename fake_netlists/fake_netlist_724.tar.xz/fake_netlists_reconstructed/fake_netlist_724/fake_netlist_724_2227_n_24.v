module fake_netlist_724_2227_n_24 (n_12, n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_24);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_24;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_23;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

AND2x6_ASAP7_75t_L g15 ( 
.A(n_0),
.B(n_10),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_16),
.B(n_14),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_3),
.B(n_2),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_6),
.C(n_5),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_11),
.Y(n_24)
);


endmodule