module fake_netlist_751_2724_n_64 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_64);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_64;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_22;
wire n_62;
wire n_36;
wire n_34;
wire n_18;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_63;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_7),
.B(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

OR2x6_ASAP7_75t_L g23 ( 
.A(n_4),
.B(n_5),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

BUFx4f_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_25),
.B(n_0),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_17),
.Y(n_33)
);

NAND3xp33_ASAP7_75t_SL g34 ( 
.A(n_20),
.B(n_16),
.C(n_5),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_SL g36 ( 
.A(n_32),
.B(n_26),
.C(n_21),
.Y(n_36)
);

XNOR2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_23),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_29),
.Y(n_38)
);

AO21x2_ASAP7_75t_L g39 ( 
.A1(n_30),
.A2(n_21),
.B(n_19),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_31),
.A2(n_22),
.B1(n_27),
.B2(n_18),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_35),
.B(n_16),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_30),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_37),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_39),
.B(n_35),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_36),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_42),
.B(n_36),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_41),
.Y(n_49)
);

AOI21xp5_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_45),
.B(n_39),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_44),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_34),
.Y(n_53)
);

OAI22xp33_ASAP7_75t_SL g54 ( 
.A1(n_53),
.A2(n_28),
.B1(n_33),
.B2(n_2),
.Y(n_54)
);

AOI322xp5_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_40),
.A3(n_18),
.B1(n_33),
.B2(n_11),
.C1(n_3),
.C2(n_15),
.Y(n_55)
);

HB1xp67_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

INVx1_ASAP7_75t_SL g57 ( 
.A(n_50),
.Y(n_57)
);

AND2x4_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_33),
.Y(n_58)
);

NOR2xp33_ASAP7_75t_L g59 ( 
.A(n_54),
.B(n_28),
.Y(n_59)
);

NAND2x1_ASAP7_75t_L g60 ( 
.A(n_55),
.B(n_33),
.Y(n_60)
);

BUFx12f_ASAP7_75t_L g61 ( 
.A(n_57),
.Y(n_61)
);

AND2x4_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_59),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_58),
.Y(n_63)
);

OAI221xp5_ASAP7_75t_R g64 ( 
.A1(n_62),
.A2(n_60),
.B1(n_61),
.B2(n_63),
.C(n_37),
.Y(n_64)
);


endmodule