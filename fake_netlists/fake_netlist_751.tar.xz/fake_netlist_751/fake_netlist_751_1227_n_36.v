module fake_netlist_751_1227_n_36 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_36);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_36;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_9;
wire n_35;
wire n_25;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_29;
wire n_32;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

BUFx10_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

BUFx10_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

AO21x2_ASAP7_75t_L g12 ( 
.A1(n_5),
.A2(n_3),
.B(n_2),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_8),
.B(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

NOR2x1_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_6),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_13),
.B(n_6),
.Y(n_18)
);

BUFx8_ASAP7_75t_SL g19 ( 
.A(n_11),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_16),
.B(n_8),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_14),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_15),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_8),
.Y(n_26)
);

OAI32xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_20),
.A3(n_17),
.B1(n_10),
.B2(n_23),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

AOI21xp33_ASAP7_75t_SL g29 ( 
.A1(n_26),
.A2(n_19),
.B(n_12),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_28),
.B(n_8),
.Y(n_30)
);

OAI211xp5_ASAP7_75t_SL g31 ( 
.A1(n_28),
.A2(n_17),
.B(n_9),
.C(n_12),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_0),
.B1(n_3),
.B2(n_5),
.C1(n_9),
.C2(n_29),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_30),
.Y(n_33)
);

NAND5xp2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_0),
.C(n_9),
.D(n_27),
.E(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_34),
.B1(n_33),
.B2(n_9),
.Y(n_36)
);


endmodule