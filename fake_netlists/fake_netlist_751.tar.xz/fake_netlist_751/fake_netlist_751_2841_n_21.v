module fake_netlist_751_2841_n_21 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_21);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_21;

wire n_20;
wire n_14;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_17;
wire n_12;
wire n_15;
wire n_19;

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_1),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_3),
.B(n_8),
.Y(n_13)
);

OAI22xp33_ASAP7_75t_L g14 ( 
.A1(n_7),
.A2(n_2),
.B1(n_4),
.B2(n_9),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_13),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_11),
.B(n_16),
.Y(n_19)
);

AO22x2_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);


endmodule