module fake_netlist_751_3395_n_63 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_63);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_63;

wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_22;
wire n_62;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_42;
wire n_37;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_57;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx2_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_15),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_2),
.B(n_3),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_0),
.B(n_17),
.Y(n_26)
);

INVx4_ASAP7_75t_L g27 ( 
.A(n_13),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_5),
.B(n_17),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_11),
.B(n_16),
.Y(n_29)
);

INVxp33_ASAP7_75t_L g30 ( 
.A(n_2),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_27),
.B(n_0),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_18),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_SL g33 ( 
.A(n_27),
.B(n_1),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_21),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

AO21x2_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_29),
.B(n_25),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_23),
.B(n_27),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_31),
.A2(n_23),
.B(n_25),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_33),
.A2(n_28),
.B(n_22),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_36),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_36),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_36),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

A2O1A1Ixp33_ASAP7_75t_SL g49 ( 
.A1(n_45),
.A2(n_37),
.B(n_39),
.C(n_32),
.Y(n_49)
);

NOR3x1_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_24),
.C(n_18),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_47),
.Y(n_51)
);

OAI211xp5_ASAP7_75t_SL g52 ( 
.A1(n_49),
.A2(n_44),
.B(n_24),
.C(n_35),
.Y(n_52)
);

INVx3_ASAP7_75t_L g53 ( 
.A(n_47),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_46),
.Y(n_54)
);

NAND4xp75_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_26),
.C(n_20),
.D(n_19),
.Y(n_55)
);

AOI221xp5_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_26),
.B1(n_35),
.B2(n_19),
.C(n_20),
.Y(n_56)
);

OAI21xp5_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_6),
.B(n_4),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

NOR3xp33_ASAP7_75t_SL g59 ( 
.A(n_55),
.B(n_53),
.C(n_7),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

AOI222xp33_ASAP7_75t_SL g61 ( 
.A1(n_58),
.A2(n_8),
.B1(n_9),
.B2(n_12),
.C1(n_56),
.C2(n_59),
.Y(n_61)
);

INVxp33_ASAP7_75t_L g62 ( 
.A(n_59),
.Y(n_62)
);

AOI22x1_ASAP7_75t_L g63 ( 
.A1(n_61),
.A2(n_60),
.B1(n_27),
.B2(n_62),
.Y(n_63)
);


endmodule