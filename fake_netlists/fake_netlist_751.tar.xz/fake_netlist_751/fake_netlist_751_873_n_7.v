module fake_netlist_751_873_n_7 (n_1, n_2, n_3, n_4, n_0, n_7);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_7;

wire n_5;
wire n_6;

OAI221xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B1(n_0),
.B2(n_1),
.C(n_3),
.Y(n_5)
);

INVxp67_ASAP7_75t_SL g6 ( 
.A(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);


endmodule