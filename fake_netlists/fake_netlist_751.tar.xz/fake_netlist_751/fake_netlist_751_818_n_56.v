module fake_netlist_751_818_n_56 (n_12, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_56);

input n_12;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_56;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_42;
wire n_37;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_15;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_11),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_1),
.B(n_14),
.Y(n_17)
);

CKINVDCx16_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

CKINVDCx14_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_1),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_10),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_4),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_SL g27 ( 
.A(n_23),
.B(n_0),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_18),
.B(n_19),
.Y(n_29)
);

A2O1A1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_20),
.A2(n_17),
.B(n_26),
.C(n_19),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_16),
.A2(n_5),
.B(n_4),
.C(n_0),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_15),
.B(n_6),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

AND2x2_ASAP7_75t_SL g34 ( 
.A(n_15),
.B(n_14),
.Y(n_34)
);

A2O1A1Ixp33_ASAP7_75t_SL g35 ( 
.A1(n_22),
.A2(n_12),
.B(n_9),
.C(n_3),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_28),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_30),
.B(n_25),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_33),
.Y(n_38)
);

OR2x6_ASAP7_75t_L g39 ( 
.A(n_31),
.B(n_32),
.Y(n_39)
);

INVx3_ASAP7_75t_L g40 ( 
.A(n_33),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_28),
.B(n_34),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AND2x4_ASAP7_75t_L g43 ( 
.A(n_36),
.B(n_29),
.Y(n_43)
);

AND2x4_ASAP7_75t_L g44 ( 
.A(n_36),
.B(n_24),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_38),
.Y(n_45)
);

O2A1O1Ixp33_ASAP7_75t_SL g46 ( 
.A1(n_42),
.A2(n_35),
.B(n_40),
.C(n_36),
.Y(n_46)
);

OAI22xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_39),
.B1(n_41),
.B2(n_40),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_44),
.B1(n_41),
.B2(n_39),
.Y(n_49)
);

AOI21xp5_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_39),
.B(n_37),
.Y(n_50)
);

OAI221xp5_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_39),
.B1(n_27),
.B2(n_44),
.C(n_37),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_49),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

NOR2xp33_ASAP7_75t_R g54 ( 
.A(n_51),
.B(n_44),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

AOI22xp33_ASAP7_75t_R g56 ( 
.A1(n_55),
.A2(n_54),
.B1(n_52),
.B2(n_22),
.Y(n_56)
);


endmodule