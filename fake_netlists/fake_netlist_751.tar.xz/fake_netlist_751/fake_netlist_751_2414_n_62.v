module fake_netlist_751_2414_n_62 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_62);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_62;

wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_22;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_42;
wire n_37;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx2_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_9),
.B(n_11),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_4),
.B(n_17),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_3),
.B(n_14),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_12),
.B(n_13),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_17),
.B(n_1),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_16),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_10),
.B(n_18),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_5),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_11),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_21),
.B(n_15),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_21),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_26),
.B(n_15),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_26),
.Y(n_38)
);

INVxp67_ASAP7_75t_L g39 ( 
.A(n_23),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_29),
.B(n_33),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_29),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

OA21x2_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_24),
.B(n_22),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_38),
.Y(n_44)
);

OAI21x1_ASAP7_75t_L g45 ( 
.A1(n_36),
.A2(n_28),
.B(n_27),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_39),
.B(n_30),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

BUFx2_ASAP7_75t_SL g48 ( 
.A(n_36),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_42),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_34),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_43),
.B(n_44),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_46),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_43),
.B1(n_47),
.B2(n_44),
.Y(n_53)
);

NAND2xp33_ASAP7_75t_SL g54 ( 
.A(n_52),
.B(n_51),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

OAI21xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_45),
.B(n_49),
.Y(n_56)
);

AOI32xp33_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_35),
.A3(n_32),
.B1(n_37),
.B2(n_41),
.Y(n_57)
);

NOR3xp33_ASAP7_75t_L g58 ( 
.A(n_57),
.B(n_25),
.C(n_20),
.Y(n_58)
);

NAND4xp75_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_25),
.C(n_6),
.D(n_0),
.Y(n_59)
);

AND2x2_ASAP7_75t_L g60 ( 
.A(n_58),
.B(n_25),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_60),
.B(n_59),
.Y(n_61)
);

CKINVDCx20_ASAP7_75t_R g62 ( 
.A(n_61),
.Y(n_62)
);


endmodule