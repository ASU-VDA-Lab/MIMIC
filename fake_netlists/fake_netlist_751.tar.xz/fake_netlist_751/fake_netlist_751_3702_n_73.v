module fake_netlist_751_3702_n_73 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_73);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_73;

wire n_46;
wire n_44;
wire n_61;
wire n_66;
wire n_62;
wire n_64;
wire n_71;
wire n_72;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_68;
wire n_49;
wire n_28;
wire n_65;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_50;
wire n_31;
wire n_30;
wire n_38;
wire n_53;
wire n_57;
wire n_35;
wire n_63;
wire n_25;
wire n_69;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_67;
wire n_55;
wire n_29;
wire n_47;
wire n_70;
wire n_52;
wire n_54;
wire n_32;

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_11),
.B(n_6),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_11),
.B(n_21),
.Y(n_25)
);

CKINVDCx8_ASAP7_75t_R g26 ( 
.A(n_17),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_8),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_18),
.B(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_13),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_15),
.B(n_4),
.Y(n_32)
);

AND2x6_ASAP7_75t_L g33 ( 
.A(n_23),
.B(n_7),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_18),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_19),
.B(n_16),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_27),
.B(n_0),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_29),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_27),
.B(n_16),
.Y(n_38)
);

AND2x2_ASAP7_75t_SL g39 ( 
.A(n_35),
.B(n_1),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_27),
.B(n_30),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_34),
.Y(n_41)
);

INVx2_ASAP7_75t_SL g42 ( 
.A(n_40),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_37),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_34),
.B1(n_35),
.B2(n_25),
.C(n_28),
.Y(n_44)
);

OAI21x1_ASAP7_75t_L g45 ( 
.A1(n_37),
.A2(n_30),
.B(n_32),
.Y(n_45)
);

INVxp67_ASAP7_75t_SL g46 ( 
.A(n_43),
.Y(n_46)
);

AO21x2_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_36),
.B(n_38),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_42),
.A2(n_39),
.B1(n_44),
.B2(n_43),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

NAND2x1p5_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_39),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

A2O1A1Ixp33_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_48),
.B(n_35),
.C(n_41),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

AOI321xp33_ASAP7_75t_L g57 ( 
.A1(n_50),
.A2(n_26),
.A3(n_24),
.B1(n_31),
.B2(n_30),
.C(n_17),
.Y(n_57)
);

OAI211xp5_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_26),
.B(n_31),
.C(n_50),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_SL g59 ( 
.A(n_56),
.B(n_52),
.Y(n_59)
);

AOI221xp5_ASAP7_75t_L g60 ( 
.A1(n_55),
.A2(n_47),
.B1(n_33),
.B2(n_19),
.C(n_20),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_L g61 ( 
.A1(n_54),
.A2(n_47),
.B1(n_33),
.B2(n_20),
.Y(n_61)
);

AND2x2_ASAP7_75t_L g62 ( 
.A(n_55),
.B(n_21),
.Y(n_62)
);

OAI22xp33_ASAP7_75t_SL g63 ( 
.A1(n_58),
.A2(n_23),
.B1(n_22),
.B2(n_33),
.Y(n_63)
);

NAND2x1p5_ASAP7_75t_SL g64 ( 
.A(n_62),
.B(n_33),
.Y(n_64)
);

NOR3xp33_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_33),
.C(n_22),
.Y(n_65)
);

OAI21xp5_ASAP7_75t_L g66 ( 
.A1(n_61),
.A2(n_33),
.B(n_47),
.Y(n_66)
);

AND2x4_ASAP7_75t_L g67 ( 
.A(n_59),
.B(n_3),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_SL g68 ( 
.A(n_63),
.B(n_5),
.Y(n_68)
);

CKINVDCx20_ASAP7_75t_R g69 ( 
.A(n_66),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_67),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_65),
.B(n_9),
.Y(n_71)
);

OAI22xp5_ASAP7_75t_SL g72 ( 
.A1(n_69),
.A2(n_67),
.B1(n_64),
.B2(n_10),
.Y(n_72)
);

OAI22xp5_ASAP7_75t_L g73 ( 
.A1(n_72),
.A2(n_70),
.B1(n_68),
.B2(n_71),
.Y(n_73)
);


endmodule