module fake_netlist_751_4066_n_46 (n_12, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_46);

input n_12;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_46;

wire n_20;
wire n_23;
wire n_44;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_15;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_5),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_15),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_19),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_26)
);

NOR2x1_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_6),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

A2O1A1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_21),
.B(n_20),
.C(n_15),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_24),
.A2(n_22),
.B1(n_20),
.B2(n_16),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_28),
.B1(n_30),
.B2(n_26),
.C(n_29),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_27),
.B(n_21),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_23),
.B1(n_18),
.B2(n_0),
.C(n_1),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_2),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_4),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_4),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_SL g39 ( 
.A(n_35),
.B(n_36),
.C(n_37),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_13),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_R g41 ( 
.A(n_39),
.B(n_13),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_14),
.Y(n_42)
);

AND2x2_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_18),
.Y(n_43)
);

INVxp67_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

CKINVDCx16_ASAP7_75t_R g45 ( 
.A(n_44),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_R g46 ( 
.A1(n_45),
.A2(n_41),
.B1(n_43),
.B2(n_18),
.C(n_7),
.Y(n_46)
);


endmodule