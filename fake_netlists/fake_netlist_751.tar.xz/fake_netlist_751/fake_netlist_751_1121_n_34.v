module fake_netlist_751_1121_n_34 (n_1, n_2, n_3, n_4, n_5, n_0, n_34);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_34;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_6;
wire n_33;
wire n_31;
wire n_30;
wire n_9;
wire n_25;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;
wire n_29;
wire n_32;
wire n_8;

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

XNOR2xp5_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_4),
.B(n_1),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_4),
.B(n_1),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_SL g15 ( 
.A(n_9),
.B(n_4),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_6),
.B1(n_9),
.B2(n_7),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_11),
.B(n_6),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_7),
.B1(n_6),
.B2(n_9),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_9),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

OAI21xp33_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_17),
.B(n_23),
.Y(n_24)
);

NAND4xp75_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_14),
.C(n_19),
.D(n_2),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_22),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_L g27 ( 
.A1(n_22),
.A2(n_15),
.B(n_9),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

AND3x4_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_3),
.C(n_2),
.Y(n_29)
);

XNOR2x1_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_20),
.Y(n_30)
);

AOI221xp5_ASAP7_75t_L g31 ( 
.A1(n_24),
.A2(n_6),
.B1(n_9),
.B2(n_21),
.C(n_26),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_6),
.B1(n_28),
.B2(n_31),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_29),
.B2(n_19),
.Y(n_34)
);


endmodule