module fake_netlist_751_772_n_12 (n_0, n_1, n_12);

input n_0;
input n_1;

output n_12;

wire n_2;
wire n_3;
wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

NAND2xp5_ASAP7_75t_L g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

INVxp67_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

INVx5_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx4_ASAP7_75t_SL g5 ( 
.A(n_2),
.Y(n_5)
);

CKINVDCx16_ASAP7_75t_R g6 ( 
.A(n_5),
.Y(n_6)
);

OAI33xp33_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_3),
.B3(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI211xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_7),
.B(n_5),
.C(n_6),
.Y(n_10)
);

AOI211xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B1(n_1),
.B2(n_0),
.Y(n_12)
);


endmodule