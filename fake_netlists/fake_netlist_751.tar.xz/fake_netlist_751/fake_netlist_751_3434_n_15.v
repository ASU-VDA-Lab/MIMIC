module fake_netlist_751_3434_n_15 (n_1, n_2, n_3, n_4, n_5, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_11;
wire n_9;
wire n_10;
wire n_13;
wire n_7;
wire n_6;
wire n_8;

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_1),
.B1(n_0),
.B2(n_4),
.Y(n_6)
);

INVxp67_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

AOI21x1_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_7),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_2),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_11),
.B(n_9),
.C(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_3),
.B1(n_4),
.B2(n_5),
.C1(n_7),
.C2(n_6),
.Y(n_15)
);


endmodule