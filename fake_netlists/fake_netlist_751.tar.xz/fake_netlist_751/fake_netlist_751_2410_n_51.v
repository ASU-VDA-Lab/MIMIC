module fake_netlist_751_2410_n_51 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_25, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_51);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_51;

wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVx2_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_3),
.B(n_15),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_7),
.B(n_20),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_13),
.B(n_9),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_0),
.B(n_25),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_R g33 ( 
.A(n_19),
.B(n_12),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_14),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_30),
.B1(n_32),
.B2(n_29),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

NOR4xp25_ASAP7_75t_SL g41 ( 
.A(n_38),
.B(n_31),
.C(n_28),
.D(n_33),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_35),
.B1(n_32),
.B2(n_1),
.C(n_2),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_5),
.B1(n_4),
.B2(n_8),
.C(n_10),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_11),
.Y(n_49)
);

XNOR2xp5_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_16),
.Y(n_50)
);

AOI222xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_49),
.B1(n_22),
.B2(n_17),
.C1(n_23),
.C2(n_18),
.Y(n_51)
);


endmodule