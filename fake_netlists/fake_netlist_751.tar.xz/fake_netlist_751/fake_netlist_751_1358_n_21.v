module fake_netlist_751_1358_n_21 (n_0, n_2, n_1, n_3, n_21);

input n_0;
input n_2;
input n_1;
input n_3;

output n_21;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_4;
wire n_7;
wire n_17;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

CKINVDCx6p67_ASAP7_75t_R g5 ( 
.A(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AOI21xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

NOR4xp25_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.C(n_0),
.D(n_2),
.Y(n_8)
);

AOI221xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_5),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_5),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_11),
.B1(n_12),
.B2(n_4),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NAND4xp25_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_12),
.C(n_13),
.D(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI22x1_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_2),
.B1(n_3),
.B2(n_12),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_17),
.B(n_20),
.Y(n_21)
);


endmodule