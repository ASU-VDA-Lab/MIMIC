module fake_netlist_751_2211_n_66 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_66);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_66;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_64;
wire n_22;
wire n_62;
wire n_36;
wire n_18;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_65;
wire n_27;
wire n_42;
wire n_37;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_63;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_10),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_16),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_8),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_R g27 ( 
.A(n_3),
.B(n_10),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_12),
.B(n_9),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_4),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_0),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_25),
.B(n_1),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_18),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_21),
.Y(n_34)
);

OAI22xp33_ASAP7_75t_L g35 ( 
.A1(n_27),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_35)
);

A2O1A1Ixp33_ASAP7_75t_L g36 ( 
.A1(n_21),
.A2(n_5),
.B(n_4),
.C(n_2),
.Y(n_36)
);

O2A1O1Ixp5_ASAP7_75t_L g37 ( 
.A1(n_21),
.A2(n_14),
.B(n_7),
.C(n_5),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_26),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_20),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_26),
.B(n_11),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_19),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_41)
);

A2O1A1Ixp33_ASAP7_75t_L g42 ( 
.A1(n_30),
.A2(n_17),
.B(n_25),
.C(n_24),
.Y(n_42)
);

NAND2xp33_ASAP7_75t_R g43 ( 
.A(n_28),
.B(n_17),
.Y(n_43)
);

BUFx2_ASAP7_75t_R g44 ( 
.A(n_32),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_SL g45 ( 
.A1(n_41),
.A2(n_29),
.B(n_30),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_39),
.Y(n_46)
);

NAND2xp33_ASAP7_75t_R g47 ( 
.A(n_33),
.B(n_22),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_R g48 ( 
.A(n_43),
.B(n_27),
.Y(n_48)
);

NAND2xp33_ASAP7_75t_R g49 ( 
.A(n_32),
.B(n_23),
.Y(n_49)
);

NAND2xp33_ASAP7_75t_SL g50 ( 
.A(n_41),
.B(n_31),
.Y(n_50)
);

CKINVDCx8_ASAP7_75t_R g51 ( 
.A(n_35),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_46),
.B(n_29),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_34),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_45),
.B(n_34),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_45),
.B(n_34),
.Y(n_56)
);

OAI21xp33_ASAP7_75t_SL g57 ( 
.A1(n_54),
.A2(n_56),
.B(n_53),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_52),
.B(n_55),
.Y(n_58)
);

NAND4xp25_ASAP7_75t_L g59 ( 
.A(n_58),
.B(n_50),
.C(n_42),
.D(n_36),
.Y(n_59)
);

AOI322xp5_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_51),
.A3(n_30),
.B1(n_44),
.B2(n_40),
.C1(n_49),
.C2(n_47),
.Y(n_60)
);

AOI221xp5_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_37),
.B1(n_44),
.B2(n_26),
.C(n_38),
.Y(n_61)
);

BUFx2_ASAP7_75t_L g62 ( 
.A(n_61),
.Y(n_62)
);

BUFx2_ASAP7_75t_L g63 ( 
.A(n_59),
.Y(n_63)
);

HB1xp67_ASAP7_75t_L g64 ( 
.A(n_60),
.Y(n_64)
);

OAI22xp5_ASAP7_75t_SL g65 ( 
.A1(n_64),
.A2(n_26),
.B1(n_38),
.B2(n_63),
.Y(n_65)
);

AOI22xp33_ASAP7_75t_L g66 ( 
.A1(n_65),
.A2(n_63),
.B1(n_64),
.B2(n_62),
.Y(n_66)
);


endmodule