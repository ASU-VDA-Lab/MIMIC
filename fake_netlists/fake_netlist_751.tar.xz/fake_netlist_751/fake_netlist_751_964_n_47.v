module fake_netlist_751_964_n_47 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_47);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_47;

wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_19),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

OA21x2_ASAP7_75t_L g29 ( 
.A1(n_14),
.A2(n_7),
.B(n_4),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_0),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_13),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_1),
.B(n_12),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_SL g33 ( 
.A(n_27),
.B(n_3),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_31),
.B(n_5),
.Y(n_35)
);

BUFx10_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_30),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_35),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_25),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_32),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_29),
.B(n_26),
.Y(n_42)
);

AOI32xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_28),
.A3(n_29),
.B1(n_6),
.B2(n_8),
.Y(n_43)
);

NAND5xp2_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_42),
.C(n_11),
.D(n_9),
.E(n_10),
.Y(n_44)
);

NOR3xp33_ASAP7_75t_SL g45 ( 
.A(n_44),
.B(n_18),
.C(n_17),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_23),
.B1(n_22),
.B2(n_21),
.Y(n_47)
);


endmodule