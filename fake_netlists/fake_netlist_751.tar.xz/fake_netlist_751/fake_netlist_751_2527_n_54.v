module fake_netlist_751_2527_n_54 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_26, n_6, n_2, n_3, n_9, n_4, n_25, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_54);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_26;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_54;

wire n_46;
wire n_44;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_52;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_24),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_5),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_18),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_0),
.Y(n_32)
);

INVxp67_ASAP7_75t_SL g33 ( 
.A(n_23),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_17),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_12),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_1),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

NOR2x1_ASAP7_75t_L g39 ( 
.A(n_29),
.B(n_6),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_37),
.B1(n_36),
.B2(n_30),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_35),
.B1(n_34),
.B2(n_28),
.Y(n_41)
);

OAI21x1_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_10),
.B(n_7),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

INVx3_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_32),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_32),
.Y(n_47)
);

OAI311xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_13),
.A3(n_11),
.B1(n_14),
.C1(n_15),
.Y(n_48)
);

OAI211xp5_ASAP7_75t_SL g49 ( 
.A1(n_47),
.A2(n_20),
.B(n_19),
.C(n_16),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_48),
.Y(n_50)
);

XNOR2xp5_ASAP7_75t_SL g51 ( 
.A(n_49),
.B(n_21),
.Y(n_51)
);

CKINVDCx20_ASAP7_75t_R g52 ( 
.A(n_50),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_22),
.Y(n_53)
);

OA22x2_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_25),
.B1(n_26),
.B2(n_52),
.Y(n_54)
);


endmodule