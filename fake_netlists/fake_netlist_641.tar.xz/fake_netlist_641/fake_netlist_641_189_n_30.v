module fake_netlist_641_189_n_30 (n_4, n_1, n_2, n_0, n_3, n_30);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_30;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_26;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_2),
.B(n_1),
.Y(n_11)
);

O2A1O1Ixp5_ASAP7_75t_L g12 ( 
.A1(n_5),
.A2(n_1),
.B(n_2),
.C(n_9),
.Y(n_12)
);

BUFx2_ASAP7_75t_SL g13 ( 
.A(n_6),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_10),
.A2(n_9),
.B1(n_5),
.B2(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_13),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_17),
.B(n_14),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_17),
.B(n_14),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_14),
.B(n_15),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_20),
.Y(n_24)
);

NAND4xp75_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_20),
.C(n_2),
.D(n_11),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_13),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_15),
.B1(n_14),
.B2(n_6),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_15),
.C(n_14),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_15),
.B1(n_27),
.B2(n_28),
.Y(n_30)
);


endmodule