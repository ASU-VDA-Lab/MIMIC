module fake_netlist_641_5351_n_3 (n_1, n_0, n_3);

input n_1;
input n_0;

output n_3;

wire n_2;

BUFx12f_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);


endmodule