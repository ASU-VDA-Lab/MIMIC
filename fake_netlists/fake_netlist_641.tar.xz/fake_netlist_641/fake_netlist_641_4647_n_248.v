module fake_netlist_641_4647_n_248 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_28, n_11, n_15, n_7, n_30, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_27, n_2, n_29, n_31, n_26, n_9, n_13, n_8, n_6, n_248);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_28;
input n_11;
input n_15;
input n_7;
input n_30;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_27;
input n_2;
input n_29;
input n_31;
input n_26;
input n_9;
input n_13;
input n_8;
input n_6;

output n_248;

wire n_168;
wire n_99;
wire n_62;
wire n_70;
wire n_90;
wire n_101;
wire n_38;
wire n_58;
wire n_166;
wire n_144;
wire n_155;
wire n_139;
wire n_57;
wire n_84;
wire n_214;
wire n_247;
wire n_35;
wire n_89;
wire n_209;
wire n_152;
wire n_116;
wire n_96;
wire n_172;
wire n_45;
wire n_107;
wire n_220;
wire n_218;
wire n_78;
wire n_235;
wire n_245;
wire n_191;
wire n_66;
wire n_154;
wire n_164;
wire n_118;
wire n_60;
wire n_137;
wire n_39;
wire n_197;
wire n_189;
wire n_243;
wire n_173;
wire n_183;
wire n_63;
wire n_190;
wire n_211;
wire n_206;
wire n_177;
wire n_192;
wire n_194;
wire n_184;
wire n_187;
wire n_238;
wire n_81;
wire n_37;
wire n_71;
wire n_124;
wire n_163;
wire n_91;
wire n_165;
wire n_121;
wire n_157;
wire n_201;
wire n_105;
wire n_92;
wire n_244;
wire n_125;
wire n_117;
wire n_230;
wire n_136;
wire n_40;
wire n_217;
wire n_223;
wire n_110;
wire n_170;
wire n_49;
wire n_207;
wire n_241;
wire n_151;
wire n_53;
wire n_161;
wire n_77;
wire n_234;
wire n_75;
wire n_48;
wire n_180;
wire n_142;
wire n_232;
wire n_93;
wire n_203;
wire n_199;
wire n_181;
wire n_41;
wire n_143;
wire n_213;
wire n_65;
wire n_109;
wire n_33;
wire n_208;
wire n_122;
wire n_219;
wire n_240;
wire n_119;
wire n_149;
wire n_43;
wire n_182;
wire n_227;
wire n_82;
wire n_204;
wire n_120;
wire n_85;
wire n_61;
wire n_176;
wire n_72;
wire n_246;
wire n_229;
wire n_242;
wire n_51;
wire n_160;
wire n_231;
wire n_226;
wire n_54;
wire n_86;
wire n_156;
wire n_68;
wire n_198;
wire n_130;
wire n_210;
wire n_140;
wire n_174;
wire n_233;
wire n_202;
wire n_167;
wire n_175;
wire n_195;
wire n_67;
wire n_112;
wire n_179;
wire n_52;
wire n_50;
wire n_113;
wire n_169;
wire n_237;
wire n_103;
wire n_104;
wire n_127;
wire n_162;
wire n_100;
wire n_150;
wire n_236;
wire n_129;
wire n_146;
wire n_76;
wire n_83;
wire n_134;
wire n_200;
wire n_196;
wire n_106;
wire n_133;
wire n_225;
wire n_36;
wire n_59;
wire n_97;
wire n_34;
wire n_131;
wire n_64;
wire n_148;
wire n_44;
wire n_159;
wire n_228;
wire n_123;
wire n_141;
wire n_87;
wire n_115;
wire n_145;
wire n_79;
wire n_215;
wire n_128;
wire n_205;
wire n_108;
wire n_126;
wire n_185;
wire n_73;
wire n_132;
wire n_56;
wire n_98;
wire n_69;
wire n_224;
wire n_147;
wire n_171;
wire n_94;
wire n_212;
wire n_221;
wire n_222;
wire n_193;
wire n_138;
wire n_46;
wire n_153;
wire n_42;
wire n_158;
wire n_216;
wire n_55;
wire n_239;
wire n_102;
wire n_135;
wire n_95;
wire n_178;
wire n_74;
wire n_32;
wire n_186;
wire n_47;
wire n_188;
wire n_80;
wire n_88;
wire n_114;
wire n_111;

INVx1_ASAP7_75t_L g32 ( 
.A(n_11),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_12),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_17),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_9),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_26),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_29),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_14),
.Y(n_38)
);

INVxp67_ASAP7_75t_SL g39 ( 
.A(n_25),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_10),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_19),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_1),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_1),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_37),
.Y(n_44)
);

NOR2xp67_ASAP7_75t_L g45 ( 
.A(n_38),
.B(n_0),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_37),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_R g47 ( 
.A(n_33),
.B(n_0),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_33),
.Y(n_48)
);

INVx3_ASAP7_75t_L g49 ( 
.A(n_34),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_32),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_35),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_38),
.Y(n_52)
);

AO22x2_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_39),
.B1(n_42),
.B2(n_41),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_45),
.A2(n_36),
.B1(n_39),
.B2(n_44),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_38),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_49),
.B(n_32),
.Y(n_56)
);

BUFx6f_ASAP7_75t_L g57 ( 
.A(n_50),
.Y(n_57)
);

AO22x2_ASAP7_75t_L g58 ( 
.A1(n_50),
.A2(n_39),
.B1(n_42),
.B2(n_41),
.Y(n_58)
);

NOR3xp33_ASAP7_75t_L g59 ( 
.A(n_45),
.B(n_42),
.C(n_41),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_49),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_50),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_49),
.B(n_48),
.Y(n_62)
);

NOR2xp33_ASAP7_75t_L g63 ( 
.A(n_48),
.B(n_51),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_62),
.B(n_51),
.Y(n_64)
);

OAI22xp5_ASAP7_75t_L g65 ( 
.A1(n_54),
.A2(n_36),
.B1(n_43),
.B2(n_44),
.Y(n_65)
);

BUFx2_ASAP7_75t_L g66 ( 
.A(n_58),
.Y(n_66)
);

NAND3xp33_ASAP7_75t_SL g67 ( 
.A(n_54),
.B(n_46),
.C(n_47),
.Y(n_67)
);

BUFx6f_ASAP7_75t_L g68 ( 
.A(n_57),
.Y(n_68)
);

HB1xp67_ASAP7_75t_L g69 ( 
.A(n_63),
.Y(n_69)
);

AOI21xp5_ASAP7_75t_L g70 ( 
.A1(n_52),
.A2(n_49),
.B(n_32),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_60),
.B(n_61),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_60),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_57),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_L g74 ( 
.A(n_61),
.B(n_40),
.Y(n_74)
);

NOR2xp33_ASAP7_75t_R g75 ( 
.A(n_55),
.B(n_46),
.Y(n_75)
);

AOI21xp5_ASAP7_75t_L g76 ( 
.A1(n_56),
.A2(n_40),
.B(n_35),
.Y(n_76)
);

NAND2xp5_ASAP7_75t_L g77 ( 
.A(n_57),
.B(n_40),
.Y(n_77)
);

HB1xp67_ASAP7_75t_L g78 ( 
.A(n_66),
.Y(n_78)
);

INVx2_ASAP7_75t_L g79 ( 
.A(n_72),
.Y(n_79)
);

BUFx2_ASAP7_75t_L g80 ( 
.A(n_66),
.Y(n_80)
);

CKINVDCx6p67_ASAP7_75t_R g81 ( 
.A(n_69),
.Y(n_81)
);

OAI21x1_ASAP7_75t_L g82 ( 
.A1(n_70),
.A2(n_43),
.B(n_58),
.Y(n_82)
);

OAI22xp5_ASAP7_75t_L g83 ( 
.A1(n_65),
.A2(n_58),
.B1(n_53),
.B2(n_43),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_72),
.Y(n_84)
);

INVx2_ASAP7_75t_SL g85 ( 
.A(n_68),
.Y(n_85)
);

AOI22xp33_ASAP7_75t_L g86 ( 
.A1(n_65),
.A2(n_58),
.B1(n_53),
.B2(n_59),
.Y(n_86)
);

NOR2xp33_ASAP7_75t_L g87 ( 
.A(n_64),
.B(n_67),
.Y(n_87)
);

OAI21xp5_ASAP7_75t_L g88 ( 
.A1(n_76),
.A2(n_53),
.B(n_34),
.Y(n_88)
);

CKINVDCx5p33_ASAP7_75t_R g89 ( 
.A(n_81),
.Y(n_89)
);

HB1xp67_ASAP7_75t_L g90 ( 
.A(n_78),
.Y(n_90)
);

BUFx3_ASAP7_75t_L g91 ( 
.A(n_80),
.Y(n_91)
);

OR2x2_ASAP7_75t_L g92 ( 
.A(n_80),
.B(n_71),
.Y(n_92)
);

NAND2xp33_ASAP7_75t_R g93 ( 
.A(n_80),
.B(n_75),
.Y(n_93)
);

OR2x2_ASAP7_75t_L g94 ( 
.A(n_78),
.B(n_71),
.Y(n_94)
);

AND2x2_ASAP7_75t_L g95 ( 
.A(n_87),
.B(n_53),
.Y(n_95)
);

OR2x2_ASAP7_75t_L g96 ( 
.A(n_92),
.B(n_81),
.Y(n_96)
);

INVx4_ASAP7_75t_L g97 ( 
.A(n_91),
.Y(n_97)
);

NAND2x1_ASAP7_75t_L g98 ( 
.A(n_95),
.B(n_85),
.Y(n_98)
);

AOI21xp5_ASAP7_75t_L g99 ( 
.A1(n_95),
.A2(n_85),
.B(n_87),
.Y(n_99)
);

NAND2xp5_ASAP7_75t_L g100 ( 
.A(n_92),
.B(n_86),
.Y(n_100)
);

OAI21x1_ASAP7_75t_L g101 ( 
.A1(n_95),
.A2(n_82),
.B(n_84),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_94),
.Y(n_102)
);

OAI21x1_ASAP7_75t_L g103 ( 
.A1(n_92),
.A2(n_82),
.B(n_84),
.Y(n_103)
);

AND2x2_ASAP7_75t_L g104 ( 
.A(n_101),
.B(n_86),
.Y(n_104)
);

AND2x4_ASAP7_75t_L g105 ( 
.A(n_97),
.B(n_91),
.Y(n_105)
);

AND2x4_ASAP7_75t_L g106 ( 
.A(n_97),
.B(n_91),
.Y(n_106)
);

AND2x2_ASAP7_75t_L g107 ( 
.A(n_101),
.B(n_82),
.Y(n_107)
);

INVx2_ASAP7_75t_L g108 ( 
.A(n_103),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_103),
.Y(n_109)
);

INVx2_ASAP7_75t_L g110 ( 
.A(n_98),
.Y(n_110)
);

INVx2_ASAP7_75t_L g111 ( 
.A(n_98),
.Y(n_111)
);

INVx4_ASAP7_75t_L g112 ( 
.A(n_97),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_99),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_102),
.Y(n_114)
);

INVxp67_ASAP7_75t_SL g115 ( 
.A(n_102),
.Y(n_115)
);

AND2x2_ASAP7_75t_L g116 ( 
.A(n_100),
.B(n_83),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_97),
.Y(n_117)
);

HB1xp67_ASAP7_75t_L g118 ( 
.A(n_114),
.Y(n_118)
);

OR2x2_ASAP7_75t_L g119 ( 
.A(n_116),
.B(n_96),
.Y(n_119)
);

INVx1_ASAP7_75t_L g120 ( 
.A(n_109),
.Y(n_120)
);

INVx2_ASAP7_75t_SL g121 ( 
.A(n_110),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_109),
.Y(n_122)
);

AND2x2_ASAP7_75t_L g123 ( 
.A(n_116),
.B(n_90),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_116),
.B(n_83),
.Y(n_124)
);

INVx2_ASAP7_75t_L g125 ( 
.A(n_108),
.Y(n_125)
);

AND2x2_ASAP7_75t_L g126 ( 
.A(n_104),
.B(n_90),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_109),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_114),
.B(n_115),
.Y(n_128)
);

INVx2_ASAP7_75t_L g129 ( 
.A(n_108),
.Y(n_129)
);

INVx2_ASAP7_75t_L g130 ( 
.A(n_108),
.Y(n_130)
);

AND2x2_ASAP7_75t_L g131 ( 
.A(n_104),
.B(n_114),
.Y(n_131)
);

AOI22xp5_ASAP7_75t_L g132 ( 
.A1(n_115),
.A2(n_93),
.B1(n_81),
.B2(n_96),
.Y(n_132)
);

AOI22xp33_ASAP7_75t_L g133 ( 
.A1(n_105),
.A2(n_34),
.B1(n_89),
.B2(n_88),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_108),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_107),
.Y(n_135)
);

INVx1_ASAP7_75t_L g136 ( 
.A(n_107),
.Y(n_136)
);

NAND2xp5_ASAP7_75t_L g137 ( 
.A(n_104),
.B(n_94),
.Y(n_137)
);

AND2x4_ASAP7_75t_L g138 ( 
.A(n_105),
.B(n_106),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_107),
.Y(n_139)
);

INVxp67_ASAP7_75t_L g140 ( 
.A(n_117),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_113),
.Y(n_141)
);

AOI22xp33_ASAP7_75t_L g142 ( 
.A1(n_126),
.A2(n_34),
.B1(n_106),
.B2(n_105),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_120),
.Y(n_143)
);

AOI21xp33_ASAP7_75t_L g144 ( 
.A1(n_132),
.A2(n_93),
.B(n_110),
.Y(n_144)
);

HB1xp67_ASAP7_75t_L g145 ( 
.A(n_118),
.Y(n_145)
);

A2O1A1Ixp33_ASAP7_75t_L g146 ( 
.A1(n_133),
.A2(n_104),
.B(n_88),
.C(n_113),
.Y(n_146)
);

NOR3xp33_ASAP7_75t_L g147 ( 
.A(n_132),
.B(n_74),
.C(n_34),
.Y(n_147)
);

NAND2xp5_ASAP7_75t_L g148 ( 
.A(n_126),
.B(n_106),
.Y(n_148)
);

NAND2xp5_ASAP7_75t_SL g149 ( 
.A(n_137),
.B(n_110),
.Y(n_149)
);

NOR2xp33_ASAP7_75t_SL g150 ( 
.A(n_123),
.B(n_106),
.Y(n_150)
);

OAI22xp33_ASAP7_75t_L g151 ( 
.A1(n_124),
.A2(n_119),
.B1(n_137),
.B2(n_123),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_120),
.Y(n_152)
);

NAND4xp25_ASAP7_75t_L g153 ( 
.A(n_119),
.B(n_74),
.C(n_94),
.D(n_77),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_128),
.Y(n_154)
);

AOI21xp5_ASAP7_75t_L g155 ( 
.A1(n_121),
.A2(n_113),
.B(n_112),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_128),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_122),
.Y(n_157)
);

AOI22xp5_ASAP7_75t_L g158 ( 
.A1(n_124),
.A2(n_106),
.B1(n_105),
.B2(n_111),
.Y(n_158)
);

NAND2xp5_ASAP7_75t_L g159 ( 
.A(n_131),
.B(n_106),
.Y(n_159)
);

NAND2xp5_ASAP7_75t_SL g160 ( 
.A(n_138),
.B(n_111),
.Y(n_160)
);

AND2x2_ASAP7_75t_L g161 ( 
.A(n_131),
.B(n_117),
.Y(n_161)
);

OAI322xp33_ASAP7_75t_L g162 ( 
.A1(n_135),
.A2(n_77),
.A3(n_5),
.B1(n_4),
.B2(n_2),
.C1(n_7),
.C2(n_6),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_122),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_125),
.Y(n_164)
);

NOR2xp33_ASAP7_75t_L g165 ( 
.A(n_138),
.B(n_105),
.Y(n_165)
);

AOI322xp5_ASAP7_75t_L g166 ( 
.A1(n_135),
.A2(n_4),
.A3(n_2),
.B1(n_7),
.B2(n_16),
.C1(n_5),
.C2(n_6),
.Y(n_166)
);

AND2x2_ASAP7_75t_L g167 ( 
.A(n_136),
.B(n_117),
.Y(n_167)
);

AOI22xp5_ASAP7_75t_L g168 ( 
.A1(n_138),
.A2(n_105),
.B1(n_111),
.B2(n_112),
.Y(n_168)
);

INVx1_ASAP7_75t_L g169 ( 
.A(n_127),
.Y(n_169)
);

AOI222xp33_ASAP7_75t_L g170 ( 
.A1(n_136),
.A2(n_139),
.B1(n_138),
.B2(n_140),
.C1(n_141),
.C2(n_79),
.Y(n_170)
);

INVx1_ASAP7_75t_L g171 ( 
.A(n_127),
.Y(n_171)
);

AOI322xp5_ASAP7_75t_L g172 ( 
.A1(n_139),
.A2(n_17),
.A3(n_16),
.B1(n_20),
.B2(n_21),
.C1(n_18),
.C2(n_19),
.Y(n_172)
);

OR2x2_ASAP7_75t_L g173 ( 
.A(n_125),
.B(n_129),
.Y(n_173)
);

NOR2x1_ASAP7_75t_L g174 ( 
.A(n_153),
.B(n_111),
.Y(n_174)
);

AND2x2_ASAP7_75t_L g175 ( 
.A(n_161),
.B(n_167),
.Y(n_175)
);

OAI21xp33_ASAP7_75t_L g176 ( 
.A1(n_172),
.A2(n_47),
.B(n_121),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_143),
.Y(n_177)
);

NOR2xp33_ASAP7_75t_L g178 ( 
.A(n_165),
.B(n_18),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_143),
.Y(n_179)
);

INVx1_ASAP7_75t_L g180 ( 
.A(n_152),
.Y(n_180)
);

NOR2xp33_ASAP7_75t_L g181 ( 
.A(n_159),
.B(n_20),
.Y(n_181)
);

NOR2xp33_ASAP7_75t_L g182 ( 
.A(n_154),
.B(n_21),
.Y(n_182)
);

AND2x2_ASAP7_75t_L g183 ( 
.A(n_161),
.B(n_125),
.Y(n_183)
);

OAI221xp5_ASAP7_75t_L g184 ( 
.A1(n_166),
.A2(n_121),
.B1(n_140),
.B2(n_117),
.C(n_134),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_152),
.Y(n_185)
);

AOI22xp33_ASAP7_75t_L g186 ( 
.A1(n_147),
.A2(n_112),
.B1(n_79),
.B2(n_84),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_157),
.Y(n_187)
);

NAND2xp5_ASAP7_75t_L g188 ( 
.A(n_145),
.B(n_129),
.Y(n_188)
);

INVx2_ASAP7_75t_L g189 ( 
.A(n_164),
.Y(n_189)
);

INVx2_ASAP7_75t_SL g190 ( 
.A(n_163),
.Y(n_190)
);

NOR2x1_ASAP7_75t_L g191 ( 
.A(n_156),
.B(n_112),
.Y(n_191)
);

INVx1_ASAP7_75t_L g192 ( 
.A(n_169),
.Y(n_192)
);

NAND2xp5_ASAP7_75t_L g193 ( 
.A(n_151),
.B(n_129),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_171),
.Y(n_194)
);

INVx1_ASAP7_75t_L g195 ( 
.A(n_167),
.Y(n_195)
);

AND2x2_ASAP7_75t_L g196 ( 
.A(n_164),
.B(n_130),
.Y(n_196)
);

NOR2xp33_ASAP7_75t_L g197 ( 
.A(n_148),
.B(n_162),
.Y(n_197)
);

AOI21xp33_ASAP7_75t_SL g198 ( 
.A1(n_144),
.A2(n_23),
.B(n_22),
.Y(n_198)
);

INVx1_ASAP7_75t_L g199 ( 
.A(n_173),
.Y(n_199)
);

INVx1_ASAP7_75t_L g200 ( 
.A(n_173),
.Y(n_200)
);

OR2x2_ASAP7_75t_L g201 ( 
.A(n_149),
.B(n_130),
.Y(n_201)
);

AOI21xp33_ASAP7_75t_L g202 ( 
.A1(n_170),
.A2(n_134),
.B(n_79),
.Y(n_202)
);

NOR3xp33_ASAP7_75t_L g203 ( 
.A(n_146),
.B(n_112),
.C(n_84),
.Y(n_203)
);

AND2x2_ASAP7_75t_L g204 ( 
.A(n_149),
.B(n_130),
.Y(n_204)
);

OAI21xp33_ASAP7_75t_L g205 ( 
.A1(n_182),
.A2(n_150),
.B(n_158),
.Y(n_205)
);

AOI221xp5_ASAP7_75t_SL g206 ( 
.A1(n_176),
.A2(n_155),
.B1(n_146),
.B2(n_160),
.C(n_142),
.Y(n_206)
);

OAI221xp5_ASAP7_75t_SL g207 ( 
.A1(n_197),
.A2(n_203),
.B1(n_184),
.B2(n_178),
.C(n_181),
.Y(n_207)
);

O2A1O1Ixp5_ASAP7_75t_L g208 ( 
.A1(n_193),
.A2(n_160),
.B(n_112),
.C(n_22),
.Y(n_208)
);

OAI221xp5_ASAP7_75t_SL g209 ( 
.A1(n_186),
.A2(n_168),
.B1(n_25),
.B2(n_23),
.C(n_24),
.Y(n_209)
);

NAND4xp25_ASAP7_75t_L g210 ( 
.A(n_174),
.B(n_27),
.C(n_26),
.D(n_24),
.Y(n_210)
);

A2O1A1Ixp33_ASAP7_75t_SL g211 ( 
.A1(n_177),
.A2(n_73),
.B(n_28),
.C(n_27),
.Y(n_211)
);

OAI211xp5_ASAP7_75t_SL g212 ( 
.A1(n_187),
.A2(n_30),
.B(n_29),
.C(n_28),
.Y(n_212)
);

OAI21xp5_ASAP7_75t_L g213 ( 
.A1(n_198),
.A2(n_73),
.B(n_85),
.Y(n_213)
);

NAND4xp25_ASAP7_75t_L g214 ( 
.A(n_188),
.B(n_31),
.C(n_30),
.D(n_3),
.Y(n_214)
);

OAI211xp5_ASAP7_75t_SL g215 ( 
.A1(n_187),
.A2(n_31),
.B(n_13),
.C(n_8),
.Y(n_215)
);

OAI211xp5_ASAP7_75t_L g216 ( 
.A1(n_191),
.A2(n_57),
.B(n_68),
.C(n_15),
.Y(n_216)
);

INVx1_ASAP7_75t_L g217 ( 
.A(n_177),
.Y(n_217)
);

INVx1_ASAP7_75t_L g218 ( 
.A(n_179),
.Y(n_218)
);

OAI22xp5_ASAP7_75t_L g219 ( 
.A1(n_195),
.A2(n_57),
.B1(n_68),
.B2(n_190),
.Y(n_219)
);

OAI21xp5_ASAP7_75t_L g220 ( 
.A1(n_202),
.A2(n_68),
.B(n_192),
.Y(n_220)
);

AOI221xp5_ASAP7_75t_L g221 ( 
.A1(n_192),
.A2(n_194),
.B1(n_180),
.B2(n_179),
.C(n_185),
.Y(n_221)
);

O2A1O1Ixp33_ASAP7_75t_L g222 ( 
.A1(n_185),
.A2(n_68),
.B(n_190),
.C(n_194),
.Y(n_222)
);

A2O1A1Ixp33_ASAP7_75t_L g223 ( 
.A1(n_195),
.A2(n_68),
.B(n_199),
.C(n_204),
.Y(n_223)
);

NAND3xp33_ASAP7_75t_L g224 ( 
.A(n_201),
.B(n_204),
.C(n_200),
.Y(n_224)
);

NOR2x1_ASAP7_75t_L g225 ( 
.A(n_222),
.B(n_201),
.Y(n_225)
);

XNOR2xp5_ASAP7_75t_L g226 ( 
.A(n_214),
.B(n_175),
.Y(n_226)
);

AOI22xp5_ASAP7_75t_L g227 ( 
.A1(n_210),
.A2(n_183),
.B1(n_189),
.B2(n_196),
.Y(n_227)
);

NAND2xp5_ASAP7_75t_L g228 ( 
.A(n_217),
.B(n_183),
.Y(n_228)
);

AOI22xp5_ASAP7_75t_L g229 ( 
.A1(n_205),
.A2(n_189),
.B1(n_196),
.B2(n_212),
.Y(n_229)
);

AOI22xp5_ASAP7_75t_L g230 ( 
.A1(n_206),
.A2(n_215),
.B1(n_216),
.B2(n_213),
.Y(n_230)
);

HB1xp67_ASAP7_75t_L g231 ( 
.A(n_218),
.Y(n_231)
);

AOI21xp5_ASAP7_75t_L g232 ( 
.A1(n_211),
.A2(n_207),
.B(n_209),
.Y(n_232)
);

AOI221xp5_ASAP7_75t_L g233 ( 
.A1(n_221),
.A2(n_208),
.B1(n_211),
.B2(n_223),
.C(n_224),
.Y(n_233)
);

OAI211xp5_ASAP7_75t_L g234 ( 
.A1(n_223),
.A2(n_207),
.B(n_210),
.C(n_214),
.Y(n_234)
);

NAND2xp5_ASAP7_75t_L g235 ( 
.A(n_219),
.B(n_220),
.Y(n_235)
);

OAI31xp33_ASAP7_75t_SL g236 ( 
.A1(n_234),
.A2(n_233),
.A3(n_226),
.B(n_225),
.Y(n_236)
);

BUFx2_ASAP7_75t_L g237 ( 
.A(n_231),
.Y(n_237)
);

INVx1_ASAP7_75t_L g238 ( 
.A(n_228),
.Y(n_238)
);

INVx1_ASAP7_75t_L g239 ( 
.A(n_228),
.Y(n_239)
);

INVx3_ASAP7_75t_SL g240 ( 
.A(n_232),
.Y(n_240)
);

OAI22xp5_ASAP7_75t_SL g241 ( 
.A1(n_240),
.A2(n_227),
.B1(n_230),
.B2(n_235),
.Y(n_241)
);

INVx1_ASAP7_75t_L g242 ( 
.A(n_238),
.Y(n_242)
);

OAI21x1_ASAP7_75t_L g243 ( 
.A1(n_238),
.A2(n_229),
.B(n_239),
.Y(n_243)
);

INVxp33_ASAP7_75t_SL g244 ( 
.A(n_241),
.Y(n_244)
);

BUFx3_ASAP7_75t_L g245 ( 
.A(n_242),
.Y(n_245)
);

OAI22xp5_ASAP7_75t_L g246 ( 
.A1(n_244),
.A2(n_240),
.B1(n_237),
.B2(n_242),
.Y(n_246)
);

AOI22xp33_ASAP7_75t_L g247 ( 
.A1(n_246),
.A2(n_240),
.B1(n_243),
.B2(n_245),
.Y(n_247)
);

AOI22x1_ASAP7_75t_L g248 ( 
.A1(n_247),
.A2(n_237),
.B1(n_236),
.B2(n_245),
.Y(n_248)
);


endmodule