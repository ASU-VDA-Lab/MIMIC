module fake_netlist_641_4652_n_64 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_64);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_64;

wire n_36;
wire n_59;
wire n_62;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_60;
wire n_22;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_63;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;
wire n_61;

INVx2_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_13),
.A2(n_4),
.B1(n_6),
.B2(n_7),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_15),
.A2(n_8),
.B1(n_21),
.B2(n_18),
.Y(n_29)
);

OAI21x1_ASAP7_75t_L g30 ( 
.A1(n_16),
.A2(n_3),
.B(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_0),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_22),
.B(n_2),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_24),
.B(n_2),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_25),
.B(n_26),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_32),
.Y(n_37)
);

A2O1A1Ixp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_30),
.B(n_25),
.C(n_29),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_31),
.B(n_28),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_34),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_33),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_38),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

O2A1O1Ixp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_41),
.B(n_35),
.C(n_26),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_23),
.Y(n_48)
);

AOI21xp33_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_45),
.B(n_30),
.Y(n_49)
);

OAI211xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_45),
.B(n_25),
.C(n_27),
.Y(n_50)
);

NAND4xp25_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_11),
.C(n_10),
.D(n_3),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_SL g52 ( 
.A(n_47),
.B(n_27),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_10),
.Y(n_53)
);

OAI21xp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_16),
.B(n_11),
.Y(n_54)
);

NAND4xp25_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_52),
.C(n_18),
.D(n_17),
.Y(n_55)
);

NAND3xp33_ASAP7_75t_SL g56 ( 
.A(n_50),
.B(n_20),
.C(n_19),
.Y(n_56)
);

AND2x4_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_1),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_SL g58 ( 
.A(n_54),
.B(n_27),
.Y(n_58)
);

AND2x4_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_20),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_27),
.Y(n_60)
);

AOI21xp5_ASAP7_75t_L g61 ( 
.A1(n_58),
.A2(n_60),
.B(n_57),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_57),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_62),
.Y(n_63)
);

OA21x2_ASAP7_75t_L g64 ( 
.A1(n_63),
.A2(n_61),
.B(n_59),
.Y(n_64)
);


endmodule