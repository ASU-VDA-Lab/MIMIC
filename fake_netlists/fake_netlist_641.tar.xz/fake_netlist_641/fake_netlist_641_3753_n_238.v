module fake_netlist_641_3753_n_238 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_28, n_11, n_15, n_7, n_30, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_27, n_2, n_29, n_26, n_9, n_13, n_8, n_6, n_238);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_28;
input n_11;
input n_15;
input n_7;
input n_30;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_27;
input n_2;
input n_29;
input n_26;
input n_9;
input n_13;
input n_8;
input n_6;

output n_238;

wire n_168;
wire n_99;
wire n_62;
wire n_70;
wire n_90;
wire n_101;
wire n_38;
wire n_58;
wire n_144;
wire n_155;
wire n_166;
wire n_139;
wire n_57;
wire n_84;
wire n_214;
wire n_35;
wire n_89;
wire n_209;
wire n_152;
wire n_116;
wire n_96;
wire n_172;
wire n_45;
wire n_107;
wire n_220;
wire n_218;
wire n_78;
wire n_235;
wire n_191;
wire n_66;
wire n_154;
wire n_164;
wire n_118;
wire n_60;
wire n_137;
wire n_39;
wire n_197;
wire n_189;
wire n_173;
wire n_183;
wire n_63;
wire n_190;
wire n_211;
wire n_206;
wire n_192;
wire n_177;
wire n_31;
wire n_194;
wire n_184;
wire n_187;
wire n_81;
wire n_37;
wire n_71;
wire n_124;
wire n_163;
wire n_91;
wire n_165;
wire n_121;
wire n_157;
wire n_201;
wire n_105;
wire n_92;
wire n_125;
wire n_117;
wire n_230;
wire n_136;
wire n_40;
wire n_217;
wire n_223;
wire n_110;
wire n_170;
wire n_49;
wire n_207;
wire n_151;
wire n_53;
wire n_161;
wire n_77;
wire n_234;
wire n_75;
wire n_48;
wire n_180;
wire n_142;
wire n_232;
wire n_93;
wire n_203;
wire n_199;
wire n_181;
wire n_41;
wire n_143;
wire n_213;
wire n_65;
wire n_109;
wire n_33;
wire n_208;
wire n_122;
wire n_219;
wire n_119;
wire n_149;
wire n_43;
wire n_182;
wire n_227;
wire n_82;
wire n_204;
wire n_120;
wire n_85;
wire n_61;
wire n_176;
wire n_72;
wire n_229;
wire n_51;
wire n_160;
wire n_231;
wire n_226;
wire n_54;
wire n_86;
wire n_156;
wire n_68;
wire n_198;
wire n_130;
wire n_210;
wire n_140;
wire n_174;
wire n_233;
wire n_202;
wire n_167;
wire n_175;
wire n_195;
wire n_67;
wire n_112;
wire n_179;
wire n_52;
wire n_50;
wire n_113;
wire n_169;
wire n_237;
wire n_103;
wire n_104;
wire n_127;
wire n_162;
wire n_100;
wire n_150;
wire n_236;
wire n_129;
wire n_146;
wire n_83;
wire n_76;
wire n_134;
wire n_196;
wire n_200;
wire n_106;
wire n_133;
wire n_225;
wire n_36;
wire n_59;
wire n_131;
wire n_34;
wire n_97;
wire n_64;
wire n_148;
wire n_44;
wire n_159;
wire n_228;
wire n_123;
wire n_141;
wire n_87;
wire n_145;
wire n_115;
wire n_79;
wire n_215;
wire n_128;
wire n_205;
wire n_108;
wire n_126;
wire n_185;
wire n_73;
wire n_132;
wire n_56;
wire n_98;
wire n_69;
wire n_224;
wire n_147;
wire n_171;
wire n_94;
wire n_212;
wire n_221;
wire n_222;
wire n_193;
wire n_138;
wire n_46;
wire n_153;
wire n_42;
wire n_158;
wire n_216;
wire n_55;
wire n_102;
wire n_135;
wire n_95;
wire n_178;
wire n_74;
wire n_32;
wire n_186;
wire n_47;
wire n_188;
wire n_80;
wire n_88;
wire n_114;
wire n_111;

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_5),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_23),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_6),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_25),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_24),
.Y(n_36)
);

INVxp67_ASAP7_75t_SL g37 ( 
.A(n_29),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_15),
.Y(n_38)
);

INVxp67_ASAP7_75t_L g39 ( 
.A(n_16),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_19),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_26),
.Y(n_41)
);

INVxp67_ASAP7_75t_SL g42 ( 
.A(n_22),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_28),
.Y(n_43)
);

INVxp33_ASAP7_75t_L g44 ( 
.A(n_7),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_27),
.Y(n_45)
);

INVxp67_ASAP7_75t_SL g46 ( 
.A(n_13),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_13),
.Y(n_47)
);

INVx3_ASAP7_75t_SL g48 ( 
.A(n_31),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_34),
.Y(n_49)
);

BUFx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

NOR2xp33_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_0),
.Y(n_51)
);

CKINVDCx16_ASAP7_75t_R g52 ( 
.A(n_33),
.Y(n_52)
);

INVxp67_ASAP7_75t_L g53 ( 
.A(n_34),
.Y(n_53)
);

CKINVDCx5p33_ASAP7_75t_R g54 ( 
.A(n_36),
.Y(n_54)
);

OR2x6_ASAP7_75t_L g55 ( 
.A(n_39),
.B(n_38),
.Y(n_55)
);

INVxp67_ASAP7_75t_L g56 ( 
.A(n_38),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_32),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_32),
.Y(n_58)
);

NOR2xp33_ASAP7_75t_R g59 ( 
.A(n_35),
.B(n_0),
.Y(n_59)
);

INVx4_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

OR2x2_ASAP7_75t_SL g61 ( 
.A(n_49),
.B(n_47),
.Y(n_61)
);

NAND3xp33_ASAP7_75t_SL g62 ( 
.A(n_59),
.B(n_39),
.C(n_47),
.Y(n_62)
);

INVxp67_ASAP7_75t_L g63 ( 
.A(n_50),
.Y(n_63)
);

AND2x2_ASAP7_75t_L g64 ( 
.A(n_57),
.B(n_35),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_57),
.Y(n_65)
);

INVx3_ASAP7_75t_L g66 ( 
.A(n_58),
.Y(n_66)
);

AND2x2_ASAP7_75t_L g67 ( 
.A(n_58),
.B(n_40),
.Y(n_67)
);

AOI22xp5_ASAP7_75t_L g68 ( 
.A1(n_51),
.A2(n_46),
.B1(n_42),
.B2(n_37),
.Y(n_68)
);

NAND2xp33_ASAP7_75t_L g69 ( 
.A(n_58),
.B(n_40),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_49),
.Y(n_70)
);

OAI221xp5_ASAP7_75t_L g71 ( 
.A1(n_53),
.A2(n_42),
.B1(n_37),
.B2(n_41),
.C(n_43),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_55),
.Y(n_72)
);

NAND2xp5_ASAP7_75t_L g73 ( 
.A(n_60),
.B(n_66),
.Y(n_73)
);

BUFx6f_ASAP7_75t_L g74 ( 
.A(n_65),
.Y(n_74)
);

INVx3_ASAP7_75t_L g75 ( 
.A(n_60),
.Y(n_75)
);

OAI21xp33_ASAP7_75t_L g76 ( 
.A1(n_71),
.A2(n_55),
.B(n_53),
.Y(n_76)
);

O2A1O1Ixp33_ASAP7_75t_SL g77 ( 
.A1(n_71),
.A2(n_72),
.B(n_62),
.C(n_70),
.Y(n_77)
);

NAND2xp5_ASAP7_75t_L g78 ( 
.A(n_72),
.B(n_54),
.Y(n_78)
);

INVx3_ASAP7_75t_SL g79 ( 
.A(n_61),
.Y(n_79)
);

BUFx6f_ASAP7_75t_L g80 ( 
.A(n_65),
.Y(n_80)
);

BUFx3_ASAP7_75t_L g81 ( 
.A(n_64),
.Y(n_81)
);

OAI21xp5_ASAP7_75t_L g82 ( 
.A1(n_68),
.A2(n_55),
.B(n_56),
.Y(n_82)
);

A2O1A1Ixp33_ASAP7_75t_L g83 ( 
.A1(n_68),
.A2(n_69),
.B(n_67),
.C(n_64),
.Y(n_83)
);

AND2x2_ASAP7_75t_L g84 ( 
.A(n_70),
.B(n_55),
.Y(n_84)
);

AOI21xp5_ASAP7_75t_L g85 ( 
.A1(n_69),
.A2(n_55),
.B(n_41),
.Y(n_85)
);

O2A1O1Ixp33_ASAP7_75t_L g86 ( 
.A1(n_62),
.A2(n_56),
.B(n_50),
.C(n_43),
.Y(n_86)
);

INVx3_ASAP7_75t_SL g87 ( 
.A(n_61),
.Y(n_87)
);

NAND2xp5_ASAP7_75t_L g88 ( 
.A(n_60),
.B(n_45),
.Y(n_88)
);

NAND2xp5_ASAP7_75t_L g89 ( 
.A(n_81),
.B(n_83),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_74),
.Y(n_90)
);

OAI21x1_ASAP7_75t_L g91 ( 
.A1(n_85),
.A2(n_88),
.B(n_75),
.Y(n_91)
);

BUFx4f_ASAP7_75t_L g92 ( 
.A(n_79),
.Y(n_92)
);

AO21x2_ASAP7_75t_L g93 ( 
.A1(n_82),
.A2(n_88),
.B(n_73),
.Y(n_93)
);

OAI21x1_ASAP7_75t_L g94 ( 
.A1(n_75),
.A2(n_67),
.B(n_64),
.Y(n_94)
);

AO222x2_ASAP7_75t_L g95 ( 
.A1(n_86),
.A2(n_63),
.B1(n_52),
.B2(n_67),
.C1(n_61),
.C2(n_82),
.Y(n_95)
);

INVx3_ASAP7_75t_L g96 ( 
.A(n_75),
.Y(n_96)
);

BUFx6f_ASAP7_75t_L g97 ( 
.A(n_74),
.Y(n_97)
);

CKINVDCx5p33_ASAP7_75t_R g98 ( 
.A(n_79),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_81),
.B(n_60),
.Y(n_99)
);

OA21x2_ASAP7_75t_L g100 ( 
.A1(n_73),
.A2(n_76),
.B(n_84),
.Y(n_100)
);

AOI22xp33_ASAP7_75t_SL g101 ( 
.A1(n_84),
.A2(n_52),
.B1(n_63),
.B2(n_45),
.Y(n_101)
);

BUFx6f_ASAP7_75t_L g102 ( 
.A(n_74),
.Y(n_102)
);

HB1xp67_ASAP7_75t_L g103 ( 
.A(n_81),
.Y(n_103)
);

OAI21x1_ASAP7_75t_L g104 ( 
.A1(n_75),
.A2(n_66),
.B(n_65),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_76),
.B(n_66),
.Y(n_105)
);

AOI22xp33_ASAP7_75t_L g106 ( 
.A1(n_93),
.A2(n_87),
.B1(n_79),
.B2(n_66),
.Y(n_106)
);

NAND2xp33_ASAP7_75t_R g107 ( 
.A(n_98),
.B(n_100),
.Y(n_107)
);

NAND2xp5_ASAP7_75t_SL g108 ( 
.A(n_89),
.B(n_87),
.Y(n_108)
);

OR2x6_ASAP7_75t_L g109 ( 
.A(n_103),
.B(n_89),
.Y(n_109)
);

NOR3xp33_ASAP7_75t_SL g110 ( 
.A(n_98),
.B(n_78),
.C(n_87),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_103),
.B(n_77),
.Y(n_111)
);

AOI22xp33_ASAP7_75t_L g112 ( 
.A1(n_93),
.A2(n_66),
.B1(n_80),
.B2(n_74),
.Y(n_112)
);

INVx4_ASAP7_75t_L g113 ( 
.A(n_92),
.Y(n_113)
);

AND2x4_ASAP7_75t_L g114 ( 
.A(n_99),
.B(n_74),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_99),
.Y(n_115)
);

OR2x6_ASAP7_75t_L g116 ( 
.A(n_105),
.B(n_100),
.Y(n_116)
);

OR2x2_ASAP7_75t_L g117 ( 
.A(n_101),
.B(n_48),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_111),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_115),
.Y(n_119)
);

HB1xp67_ASAP7_75t_L g120 ( 
.A(n_109),
.Y(n_120)
);

INVxp67_ASAP7_75t_L g121 ( 
.A(n_117),
.Y(n_121)
);

A2O1A1Ixp33_ASAP7_75t_L g122 ( 
.A1(n_108),
.A2(n_110),
.B(n_92),
.C(n_105),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_114),
.Y(n_123)
);

BUFx2_ASAP7_75t_L g124 ( 
.A(n_109),
.Y(n_124)
);

AOI22xp33_ASAP7_75t_L g125 ( 
.A1(n_108),
.A2(n_93),
.B1(n_92),
.B2(n_101),
.Y(n_125)
);

INVx4_ASAP7_75t_L g126 ( 
.A(n_113),
.Y(n_126)
);

AOI21xp33_ASAP7_75t_L g127 ( 
.A1(n_109),
.A2(n_93),
.B(n_100),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_114),
.Y(n_128)
);

BUFx3_ASAP7_75t_L g129 ( 
.A(n_124),
.Y(n_129)
);

OR2x2_ASAP7_75t_L g130 ( 
.A(n_124),
.B(n_116),
.Y(n_130)
);

AND2x2_ASAP7_75t_L g131 ( 
.A(n_118),
.B(n_93),
.Y(n_131)
);

OR2x2_ASAP7_75t_L g132 ( 
.A(n_120),
.B(n_116),
.Y(n_132)
);

BUFx2_ASAP7_75t_L g133 ( 
.A(n_123),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_119),
.Y(n_134)
);

NAND2xp5_ASAP7_75t_L g135 ( 
.A(n_118),
.B(n_100),
.Y(n_135)
);

AND2x2_ASAP7_75t_L g136 ( 
.A(n_123),
.B(n_100),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_119),
.Y(n_137)
);

NAND2xp5_ASAP7_75t_L g138 ( 
.A(n_128),
.B(n_100),
.Y(n_138)
);

AND2x2_ASAP7_75t_L g139 ( 
.A(n_128),
.B(n_106),
.Y(n_139)
);

BUFx2_ASAP7_75t_L g140 ( 
.A(n_132),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_134),
.Y(n_141)
);

OAI22xp5_ASAP7_75t_L g142 ( 
.A1(n_134),
.A2(n_121),
.B1(n_95),
.B2(n_125),
.Y(n_142)
);

OR2x2_ASAP7_75t_L g143 ( 
.A(n_130),
.B(n_116),
.Y(n_143)
);

NAND2xp5_ASAP7_75t_L g144 ( 
.A(n_131),
.B(n_106),
.Y(n_144)
);

AOI33xp33_ASAP7_75t_L g145 ( 
.A1(n_137),
.A2(n_95),
.A3(n_112),
.B1(n_3),
.B2(n_2),
.B3(n_1),
.Y(n_145)
);

AND2x2_ASAP7_75t_L g146 ( 
.A(n_139),
.B(n_127),
.Y(n_146)
);

AND2x2_ASAP7_75t_L g147 ( 
.A(n_139),
.B(n_127),
.Y(n_147)
);

INVxp67_ASAP7_75t_L g148 ( 
.A(n_133),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_137),
.Y(n_149)
);

NAND2xp5_ASAP7_75t_L g150 ( 
.A(n_131),
.B(n_122),
.Y(n_150)
);

NOR2xp33_ASAP7_75t_L g151 ( 
.A(n_132),
.B(n_130),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_136),
.Y(n_152)
);

INVx2_ASAP7_75t_L g153 ( 
.A(n_136),
.Y(n_153)
);

AND2x2_ASAP7_75t_L g154 ( 
.A(n_131),
.B(n_136),
.Y(n_154)
);

AND2x2_ASAP7_75t_L g155 ( 
.A(n_133),
.B(n_112),
.Y(n_155)
);

OAI21xp5_ASAP7_75t_L g156 ( 
.A1(n_142),
.A2(n_92),
.B(n_94),
.Y(n_156)
);

AOI22xp33_ASAP7_75t_L g157 ( 
.A1(n_142),
.A2(n_129),
.B1(n_92),
.B2(n_135),
.Y(n_157)
);

NAND2xp5_ASAP7_75t_SL g158 ( 
.A(n_145),
.B(n_129),
.Y(n_158)
);

OR2x2_ASAP7_75t_L g159 ( 
.A(n_140),
.B(n_129),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_141),
.Y(n_160)
);

INVx1_ASAP7_75t_L g161 ( 
.A(n_141),
.Y(n_161)
);

A2O1A1Ixp33_ASAP7_75t_L g162 ( 
.A1(n_155),
.A2(n_91),
.B(n_94),
.C(n_107),
.Y(n_162)
);

INVx2_ASAP7_75t_L g163 ( 
.A(n_149),
.Y(n_163)
);

AOI21xp33_ASAP7_75t_SL g164 ( 
.A1(n_151),
.A2(n_48),
.B(n_1),
.Y(n_164)
);

AOI22xp33_ASAP7_75t_L g165 ( 
.A1(n_147),
.A2(n_146),
.B1(n_140),
.B2(n_151),
.Y(n_165)
);

AOI22xp33_ASAP7_75t_L g166 ( 
.A1(n_147),
.A2(n_138),
.B1(n_113),
.B2(n_126),
.Y(n_166)
);

OR2x2_ASAP7_75t_L g167 ( 
.A(n_154),
.B(n_138),
.Y(n_167)
);

OR2x2_ASAP7_75t_L g168 ( 
.A(n_144),
.B(n_90),
.Y(n_168)
);

OR2x2_ASAP7_75t_L g169 ( 
.A(n_143),
.B(n_146),
.Y(n_169)
);

AOI221xp5_ASAP7_75t_SL g170 ( 
.A1(n_148),
.A2(n_3),
.B1(n_2),
.B2(n_4),
.C(n_5),
.Y(n_170)
);

OR2x2_ASAP7_75t_L g171 ( 
.A(n_143),
.B(n_90),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_149),
.Y(n_172)
);

INVx2_ASAP7_75t_L g173 ( 
.A(n_153),
.Y(n_173)
);

OR2x2_ASAP7_75t_L g174 ( 
.A(n_153),
.B(n_91),
.Y(n_174)
);

NOR3xp33_ASAP7_75t_L g175 ( 
.A(n_164),
.B(n_150),
.C(n_152),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_160),
.Y(n_176)
);

AND2x2_ASAP7_75t_L g177 ( 
.A(n_163),
.B(n_152),
.Y(n_177)
);

OAI22xp5_ASAP7_75t_L g178 ( 
.A1(n_157),
.A2(n_155),
.B1(n_153),
.B2(n_126),
.Y(n_178)
);

INVxp67_ASAP7_75t_L g179 ( 
.A(n_159),
.Y(n_179)
);

AND2x2_ASAP7_75t_L g180 ( 
.A(n_163),
.B(n_8),
.Y(n_180)
);

AND2x2_ASAP7_75t_L g181 ( 
.A(n_161),
.B(n_8),
.Y(n_181)
);

INVx1_ASAP7_75t_L g182 ( 
.A(n_172),
.Y(n_182)
);

AND2x2_ASAP7_75t_L g183 ( 
.A(n_169),
.B(n_9),
.Y(n_183)
);

AND2x2_ASAP7_75t_L g184 ( 
.A(n_173),
.B(n_9),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_173),
.Y(n_185)
);

INVx1_ASAP7_75t_L g186 ( 
.A(n_174),
.Y(n_186)
);

NAND2x1_ASAP7_75t_L g187 ( 
.A(n_171),
.B(n_126),
.Y(n_187)
);

INVx1_ASAP7_75t_L g188 ( 
.A(n_174),
.Y(n_188)
);

OR2x2_ASAP7_75t_L g189 ( 
.A(n_167),
.B(n_10),
.Y(n_189)
);

INVx1_ASAP7_75t_L g190 ( 
.A(n_168),
.Y(n_190)
);

INVx1_ASAP7_75t_SL g191 ( 
.A(n_158),
.Y(n_191)
);

INVx1_ASAP7_75t_SL g192 ( 
.A(n_158),
.Y(n_192)
);

INVx1_ASAP7_75t_SL g193 ( 
.A(n_156),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_165),
.Y(n_194)
);

NAND2xp5_ASAP7_75t_L g195 ( 
.A(n_165),
.B(n_10),
.Y(n_195)
);

INVx2_ASAP7_75t_L g196 ( 
.A(n_162),
.Y(n_196)
);

INVx1_ASAP7_75t_L g197 ( 
.A(n_162),
.Y(n_197)
);

AOI221xp5_ASAP7_75t_L g198 ( 
.A1(n_197),
.A2(n_170),
.B1(n_157),
.B2(n_11),
.C(n_12),
.Y(n_198)
);

AOI211xp5_ASAP7_75t_L g199 ( 
.A1(n_175),
.A2(n_195),
.B(n_192),
.C(n_191),
.Y(n_199)
);

NAND4xp25_ASAP7_75t_L g200 ( 
.A(n_197),
.B(n_166),
.C(n_14),
.D(n_12),
.Y(n_200)
);

NOR2xp33_ASAP7_75t_L g201 ( 
.A(n_189),
.B(n_14),
.Y(n_201)
);

OAI211xp5_ASAP7_75t_L g202 ( 
.A1(n_196),
.A2(n_17),
.B(n_16),
.C(n_15),
.Y(n_202)
);

NOR2x1_ASAP7_75t_L g203 ( 
.A(n_189),
.B(n_126),
.Y(n_203)
);

OAI222xp33_ASAP7_75t_L g204 ( 
.A1(n_193),
.A2(n_18),
.B1(n_17),
.B2(n_90),
.C1(n_21),
.C2(n_20),
.Y(n_204)
);

NOR2x1p5_ASAP7_75t_L g205 ( 
.A(n_194),
.B(n_18),
.Y(n_205)
);

AOI31xp33_ASAP7_75t_L g206 ( 
.A1(n_183),
.A2(n_194),
.A3(n_181),
.B(n_180),
.Y(n_206)
);

NAND2xp5_ASAP7_75t_L g207 ( 
.A(n_176),
.B(n_182),
.Y(n_207)
);

OAI22xp5_ASAP7_75t_L g208 ( 
.A1(n_178),
.A2(n_102),
.B1(n_97),
.B2(n_96),
.Y(n_208)
);

NOR4xp75_ASAP7_75t_L g209 ( 
.A(n_187),
.B(n_184),
.C(n_177),
.D(n_179),
.Y(n_209)
);

AOI21xp5_ASAP7_75t_L g210 ( 
.A1(n_187),
.A2(n_104),
.B(n_97),
.Y(n_210)
);

NAND3xp33_ASAP7_75t_SL g211 ( 
.A(n_190),
.B(n_102),
.C(n_97),
.Y(n_211)
);

AOI222xp33_ASAP7_75t_L g212 ( 
.A1(n_198),
.A2(n_186),
.B1(n_188),
.B2(n_182),
.C1(n_177),
.C2(n_185),
.Y(n_212)
);

AOI22xp5_ASAP7_75t_L g213 ( 
.A1(n_200),
.A2(n_102),
.B1(n_97),
.B2(n_80),
.Y(n_213)
);

CKINVDCx6p67_ASAP7_75t_R g214 ( 
.A(n_207),
.Y(n_214)
);

NOR2xp33_ASAP7_75t_L g215 ( 
.A(n_201),
.B(n_206),
.Y(n_215)
);

HB1xp67_ASAP7_75t_L g216 ( 
.A(n_209),
.Y(n_216)
);

AOI321xp33_ASAP7_75t_L g217 ( 
.A1(n_202),
.A2(n_97),
.A3(n_102),
.B1(n_203),
.B2(n_204),
.C(n_205),
.Y(n_217)
);

AND2x4_ASAP7_75t_L g218 ( 
.A(n_210),
.B(n_102),
.Y(n_218)
);

OR2x2_ASAP7_75t_L g219 ( 
.A(n_211),
.B(n_208),
.Y(n_219)
);

OAI221xp5_ASAP7_75t_L g220 ( 
.A1(n_198),
.A2(n_200),
.B1(n_199),
.B2(n_175),
.C(n_170),
.Y(n_220)
);

HB1xp67_ASAP7_75t_L g221 ( 
.A(n_216),
.Y(n_221)
);

INVx1_ASAP7_75t_L g222 ( 
.A(n_214),
.Y(n_222)
);

NAND4xp25_ASAP7_75t_L g223 ( 
.A(n_220),
.B(n_217),
.C(n_212),
.D(n_215),
.Y(n_223)
);

HB1xp67_ASAP7_75t_L g224 ( 
.A(n_219),
.Y(n_224)
);

CKINVDCx5p33_ASAP7_75t_R g225 ( 
.A(n_213),
.Y(n_225)
);

HB1xp67_ASAP7_75t_L g226 ( 
.A(n_218),
.Y(n_226)
);

BUFx2_ASAP7_75t_L g227 ( 
.A(n_218),
.Y(n_227)
);

INVxp67_ASAP7_75t_L g228 ( 
.A(n_221),
.Y(n_228)
);

INVx1_ASAP7_75t_L g229 ( 
.A(n_224),
.Y(n_229)
);

INVx2_ASAP7_75t_L g230 ( 
.A(n_227),
.Y(n_230)
);

INVx1_ASAP7_75t_L g231 ( 
.A(n_227),
.Y(n_231)
);

INVx1_ASAP7_75t_L g232 ( 
.A(n_226),
.Y(n_232)
);

OAI21x1_ASAP7_75t_L g233 ( 
.A1(n_231),
.A2(n_230),
.B(n_232),
.Y(n_233)
);

HB1xp67_ASAP7_75t_L g234 ( 
.A(n_230),
.Y(n_234)
);

NAND2xp5_ASAP7_75t_L g235 ( 
.A(n_234),
.B(n_228),
.Y(n_235)
);

NAND5xp2_ASAP7_75t_L g236 ( 
.A(n_233),
.B(n_217),
.C(n_229),
.D(n_231),
.E(n_222),
.Y(n_236)
);

AOI22x1_ASAP7_75t_L g237 ( 
.A1(n_236),
.A2(n_225),
.B1(n_223),
.B2(n_233),
.Y(n_237)
);

AOI21xp33_ASAP7_75t_L g238 ( 
.A1(n_237),
.A2(n_235),
.B(n_225),
.Y(n_238)
);


endmodule