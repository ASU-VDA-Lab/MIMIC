module fake_netlist_641_2594_n_19 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_19);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_19;

wire n_18;
wire n_10;
wire n_11;
wire n_15;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;

INVx1_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_7),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_1),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_0),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_3),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_5),
.B(n_4),
.Y(n_13)
);

NOR2x1_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

NOR4xp25_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.C(n_12),
.D(n_13),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_14),
.B2(n_13),
.C(n_4),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.Y(n_17)
);

AOI22x1_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_12),
.B1(n_10),
.B2(n_6),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_17),
.B(n_12),
.Y(n_19)
);


endmodule