module fake_netlist_641_1855_n_30 (n_4, n_1, n_2, n_0, n_3, n_30);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_30;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_26;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx8_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_2),
.B(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_1),
.Y(n_9)
);

O2A1O1Ixp33_ASAP7_75t_SL g10 ( 
.A1(n_7),
.A2(n_2),
.B(n_0),
.C(n_3),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_6),
.B(n_8),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_5),
.A2(n_6),
.B(n_9),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_6),
.A2(n_2),
.B(n_0),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_13),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_0),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_10),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

AOI211xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_18),
.B(n_15),
.C(n_16),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_18),
.B1(n_15),
.B2(n_16),
.C(n_0),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_18),
.C(n_2),
.D(n_3),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_21),
.C(n_18),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_22),
.A2(n_3),
.B1(n_4),
.B2(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_27),
.Y(n_29)
);

O2A1O1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_26),
.B(n_28),
.C(n_27),
.Y(n_30)
);


endmodule