module fake_netlist_641_4362_n_17 (n_4, n_1, n_2, n_0, n_5, n_3, n_17);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_17;

wire n_7;
wire n_14;
wire n_13;
wire n_10;
wire n_12;
wire n_11;
wire n_16;
wire n_8;
wire n_15;
wire n_6;
wire n_9;

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

NOR2xp67_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_2),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_1),
.Y(n_9)
);

AO21x2_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.B(n_7),
.Y(n_10)
);

OA21x2_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_3),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);


endmodule