module fake_netlist_641_2149_n_53 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_53);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_53;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_19),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_23),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_21),
.B(n_5),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_3),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_14),
.Y(n_31)
);

OA21x2_ASAP7_75t_L g32 ( 
.A1(n_20),
.A2(n_16),
.B(n_1),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_8),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

INVx2_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_30),
.B(n_18),
.Y(n_38)
);

AO32x2_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_32),
.A3(n_33),
.B1(n_29),
.B2(n_18),
.Y(n_39)
);

OAI21x1_ASAP7_75t_L g40 ( 
.A1(n_35),
.A2(n_32),
.B(n_25),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_38),
.B1(n_35),
.B2(n_37),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_31),
.B1(n_26),
.B2(n_27),
.Y(n_42)
);

HB1xp67_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

NAND4xp25_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_4),
.C(n_2),
.D(n_0),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_6),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AOI221x1_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_9),
.B1(n_7),
.B2(n_10),
.C(n_11),
.Y(n_47)
);

INVx2_ASAP7_75t_SL g48 ( 
.A(n_45),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_SL g49 ( 
.A(n_48),
.B(n_12),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_47),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_50),
.Y(n_51)
);

AND2x4_ASAP7_75t_SL g52 ( 
.A(n_49),
.B(n_13),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_15),
.B1(n_22),
.B2(n_52),
.Y(n_53)
);


endmodule