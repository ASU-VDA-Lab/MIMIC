module fake_netlist_641_85_n_43 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_43);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_43;

wire n_36;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

INVx2_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_10),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_12),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_17),
.B(n_13),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

BUFx3_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_SL g32 ( 
.A(n_30),
.B(n_24),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_28),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_29),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_32),
.Y(n_35)
);

NOR3xp33_ASAP7_75t_SL g36 ( 
.A(n_35),
.B(n_26),
.C(n_34),
.Y(n_36)
);

NOR3xp33_ASAP7_75t_SL g37 ( 
.A(n_35),
.B(n_19),
.C(n_27),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

XOR2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_27),
.Y(n_39)
);

NAND5xp2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_19),
.C(n_23),
.D(n_20),
.E(n_1),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_3),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_42)
);

OAI322xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_41),
.A3(n_14),
.B1(n_11),
.B2(n_8),
.C1(n_18),
.C2(n_15),
.Y(n_43)
);


endmodule