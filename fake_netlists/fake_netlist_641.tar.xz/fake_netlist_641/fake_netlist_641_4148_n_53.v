module fake_netlist_641_4148_n_53 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_53);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_53;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_15),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_8),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_0),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_9),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

INVx6_ASAP7_75t_L g27 ( 
.A(n_3),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_12),
.B(n_7),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_20),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

OA21x2_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_21),
.B(n_28),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_19),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_29),
.B1(n_31),
.B2(n_24),
.C(n_25),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_29),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_39),
.Y(n_40)
);

CKINVDCx14_ASAP7_75t_R g41 ( 
.A(n_37),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_34),
.B1(n_36),
.B2(n_27),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_34),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

OAI21xp33_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_36),
.B(n_32),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_34),
.Y(n_48)
);

A2O1A1Ixp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_34),
.B(n_36),
.C(n_32),
.Y(n_49)
);

AND3x1_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_46),
.C(n_27),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_52)
);

AOI222xp33_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_51),
.B1(n_11),
.B2(n_6),
.C1(n_14),
.C2(n_10),
.Y(n_53)
);


endmodule