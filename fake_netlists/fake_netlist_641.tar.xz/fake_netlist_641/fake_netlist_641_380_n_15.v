module fake_netlist_641_380_n_15 (n_3, n_1, n_2, n_0, n_15);

input n_3;
input n_1;
input n_2;
input n_0;

output n_15;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_13;
wire n_10;
wire n_5;
wire n_12;
wire n_11;
wire n_8;
wire n_6;

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_0),
.B(n_1),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AO31x2_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_10),
.Y(n_11)
);

AOI211xp5_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_10),
.B(n_4),
.C(n_5),
.Y(n_12)
);

NAND3x1_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_2),
.C(n_1),
.Y(n_13)
);

AOI21xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_3),
.B(n_8),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_3),
.Y(n_15)
);


endmodule