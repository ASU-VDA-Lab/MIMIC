module fake_netlist_641_43_n_52 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_52);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_52;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_2),
.A2(n_14),
.B1(n_0),
.B2(n_12),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_11),
.B(n_20),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

INVxp33_ASAP7_75t_SL g26 ( 
.A(n_19),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_13),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_16),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_8),
.B(n_10),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_9),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_3),
.B(n_1),
.Y(n_32)
);

NOR2x1p5_ASAP7_75t_L g33 ( 
.A(n_25),
.B(n_15),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_27),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_34),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_36),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_36),
.Y(n_40)
);

OAI22xp33_ASAP7_75t_SL g41 ( 
.A1(n_40),
.A2(n_26),
.B1(n_22),
.B2(n_31),
.Y(n_41)
);

AOI221x1_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_32),
.B1(n_31),
.B2(n_24),
.C(n_30),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

O2A1O1Ixp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_28),
.B(n_30),
.C(n_23),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_43),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_15),
.Y(n_47)
);

NOR2xp67_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_4),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_47),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

AOI222xp33_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_28),
.B1(n_18),
.B2(n_17),
.C1(n_7),
.C2(n_6),
.Y(n_51)
);

OAI21xp5_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_50),
.B(n_18),
.Y(n_52)
);


endmodule