module fake_netlist_641_3237_n_22 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_22);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_22;

wire n_18;
wire n_19;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

AOI21x1_ASAP7_75t_L g12 ( 
.A1(n_5),
.A2(n_3),
.B(n_4),
.Y(n_12)
);

OAI22xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_0),
.B1(n_2),
.B2(n_6),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_9),
.B(n_1),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

AOI221x1_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.B1(n_12),
.B2(n_13),
.C(n_7),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_12),
.B(n_10),
.Y(n_22)
);


endmodule