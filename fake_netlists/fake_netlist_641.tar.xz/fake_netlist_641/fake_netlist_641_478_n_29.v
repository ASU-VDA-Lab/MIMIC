module fake_netlist_641_478_n_29 (n_4, n_1, n_2, n_0, n_3, n_29);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_29;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_26;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_0),
.A2(n_1),
.B1(n_3),
.B2(n_2),
.Y(n_9)
);

O2A1O1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_11)
);

AO31x2_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_2),
.A3(n_0),
.B(n_3),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_5),
.B(n_4),
.Y(n_13)
);

BUFx3_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_7),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_7),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_SL g17 ( 
.A1(n_10),
.A2(n_6),
.B1(n_8),
.B2(n_9),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_11),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_SL g21 ( 
.A(n_18),
.B(n_15),
.Y(n_21)
);

OAI221xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_17),
.B1(n_6),
.B2(n_14),
.C(n_15),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_14),
.Y(n_23)
);

OAI322xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_9),
.A3(n_12),
.B1(n_14),
.B2(n_17),
.C1(n_19),
.C2(n_21),
.Y(n_24)
);

NAND4xp75_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_14),
.C(n_8),
.D(n_13),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

XNOR2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_23),
.Y(n_28)
);

OAI211xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_24),
.B(n_25),
.C(n_28),
.Y(n_29)
);


endmodule