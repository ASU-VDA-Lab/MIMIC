module fake_netlist_641_4171_n_55 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_55);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_55;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx3_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

AND2x6_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_3),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_L g28 ( 
.A(n_9),
.B(n_16),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_6),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_21),
.B(n_19),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_23),
.B(n_27),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_31),
.B1(n_24),
.B2(n_22),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_35),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_36),
.Y(n_42)
);

NAND2x1p5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_25),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_33),
.B1(n_28),
.B2(n_30),
.C(n_16),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_26),
.Y(n_45)
);

OAI21xp5_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_30),
.B(n_18),
.Y(n_46)
);

XOR2x2_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_45),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_19),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_26),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

AOI21xp33_ASAP7_75t_SL g51 ( 
.A1(n_47),
.A2(n_5),
.B(n_4),
.Y(n_51)
);

OR5x1_ASAP7_75t_L g52 ( 
.A(n_51),
.B(n_26),
.C(n_10),
.D(n_7),
.E(n_8),
.Y(n_52)
);

OR3x1_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_49),
.C(n_11),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);

AO221x2_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_52),
.B1(n_15),
.B2(n_13),
.C(n_14),
.Y(n_55)
);


endmodule