module fake_netlist_641_333_n_22 (n_3, n_1, n_2, n_0, n_22);

input n_3;
input n_1;
input n_2;
input n_0;

output n_22;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_4;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

OAI22x1_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_3),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_1),
.A2(n_3),
.B(n_2),
.Y(n_6)
);

NAND3xp33_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_2),
.C(n_1),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_9),
.B1(n_4),
.B2(n_0),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

OA22x2_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_4),
.B1(n_11),
.B2(n_9),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_11),
.B(n_12),
.Y(n_17)
);

NOR4xp25_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_12),
.C(n_2),
.D(n_13),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_12),
.C(n_13),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_13),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B1(n_19),
.B2(n_18),
.Y(n_21)
);

AO21x2_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B(n_17),
.Y(n_22)
);


endmodule