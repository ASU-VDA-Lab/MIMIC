module fake_netlist_641_5132_n_45 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_45);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_45;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_17),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_5),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_3),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_13),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_22),
.B(n_24),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_23),
.B(n_16),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_21),
.B1(n_28),
.B2(n_26),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_30),
.B1(n_31),
.B2(n_26),
.Y(n_34)
);

NOR5xp2_ASAP7_75t_SL g35 ( 
.A(n_32),
.B(n_19),
.C(n_18),
.D(n_16),
.E(n_28),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_27),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_19),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_36),
.B(n_0),
.Y(n_38)
);

INVxp33_ASAP7_75t_SL g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_8),
.B1(n_2),
.B2(n_1),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_12),
.B1(n_10),
.B2(n_9),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_14),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_15),
.B1(n_20),
.B2(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);


endmodule