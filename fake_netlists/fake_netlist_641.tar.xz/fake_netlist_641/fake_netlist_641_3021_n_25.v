module fake_netlist_641_3021_n_25 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_25);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_25;

wire n_18;
wire n_19;
wire n_24;
wire n_15;
wire n_11;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_5),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_1),
.A2(n_3),
.B(n_5),
.C(n_4),
.Y(n_12)
);

BUFx8_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_2),
.B(n_4),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_7),
.B(n_8),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_2),
.B(n_3),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_0),
.Y(n_19)
);

OAI22xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_11),
.B1(n_15),
.B2(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

NOR4xp25_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_12),
.C(n_18),
.D(n_17),
.Y(n_22)
);

AND3x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_18),
.C(n_0),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_7),
.B(n_6),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_23),
.B(n_20),
.Y(n_25)
);


endmodule