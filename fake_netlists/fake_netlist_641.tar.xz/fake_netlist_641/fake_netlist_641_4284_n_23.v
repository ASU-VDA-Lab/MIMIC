module fake_netlist_641_4284_n_23 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_23);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_23;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_1),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_12),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_15),
.C(n_10),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_SL g18 ( 
.A1(n_16),
.A2(n_11),
.B(n_2),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

NAND2xp33_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_4),
.Y(n_20)
);

AO221x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.C(n_3),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_R g23 ( 
.A1(n_21),
.A2(n_22),
.B1(n_7),
.B2(n_6),
.Y(n_23)
);


endmodule