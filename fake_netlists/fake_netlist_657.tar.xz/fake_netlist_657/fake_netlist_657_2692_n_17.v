module fake_netlist_657_2692_n_17 (n_4, n_1, n_2, n_0, n_3, n_17);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_17;

wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_12;
wire n_10;
wire n_11;
wire n_16;
wire n_8;
wire n_15;
wire n_6;
wire n_9;

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_1),
.Y(n_7)
);

OAI22xp5_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_8)
);

INVx4_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

NAND2xp33_ASAP7_75t_R g10 ( 
.A(n_9),
.B(n_6),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_5),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.Y(n_12)
);

XNOR2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_1),
.C(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B1(n_4),
.B2(n_3),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_3),
.B(n_7),
.Y(n_17)
);


endmodule