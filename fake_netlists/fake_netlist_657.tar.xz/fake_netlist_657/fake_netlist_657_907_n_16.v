module fake_netlist_657_907_n_16 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_16);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_16;

wire n_7;
wire n_14;
wire n_13;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_15;
wire n_9;

INVx1_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_3),
.B(n_0),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AO221x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B1(n_8),
.B2(n_11),
.C(n_10),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_8),
.C(n_9),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_11),
.B1(n_4),
.B2(n_1),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_R g16 ( 
.A1(n_15),
.A2(n_6),
.B1(n_4),
.B2(n_1),
.Y(n_16)
);


endmodule