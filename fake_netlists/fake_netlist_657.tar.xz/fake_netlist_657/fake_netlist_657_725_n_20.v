module fake_netlist_657_725_n_20 (n_3, n_1, n_2, n_0, n_20);

input n_3;
input n_1;
input n_2;
input n_0;

output n_20;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_16;
wire n_12;
wire n_4;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

CKINVDCx16_ASAP7_75t_R g4 ( 
.A(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_0),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_2),
.Y(n_8)
);

NOR3xp33_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_1),
.C(n_3),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_4),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_5),
.Y(n_12)
);

INVxp67_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AOI211xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_13),
.B(n_15),
.C(n_16),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OR2x6_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);


endmodule