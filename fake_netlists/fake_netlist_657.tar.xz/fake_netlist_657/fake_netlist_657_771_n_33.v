module fake_netlist_657_771_n_33 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_33);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_33;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_32;
wire n_13;

INVx2_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_0),
.B(n_4),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_1),
.B(n_2),
.Y(n_12)
);

OR2x6_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_0),
.Y(n_13)
);

INVx5_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_8),
.B(n_1),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_6),
.B(n_7),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_15),
.B(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_3),
.B(n_2),
.Y(n_19)
);

OAI21x1_ASAP7_75t_L g20 ( 
.A1(n_12),
.A2(n_11),
.B(n_14),
.Y(n_20)
);

OAI21x1_ASAP7_75t_SL g21 ( 
.A1(n_14),
.A2(n_4),
.B(n_3),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_19),
.C(n_13),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_20),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_26),
.B(n_23),
.Y(n_29)
);

AND4x1_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_25),
.C(n_21),
.D(n_13),
.Y(n_30)
);

INVx4_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_17),
.Y(n_32)
);

OAI21xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_25),
.B(n_30),
.Y(n_33)
);


endmodule