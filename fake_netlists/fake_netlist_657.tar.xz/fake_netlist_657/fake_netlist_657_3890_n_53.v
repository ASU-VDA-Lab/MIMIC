module fake_netlist_657_3890_n_53 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_53);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_53;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_8),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_7),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_21),
.Y(n_27)
);

AND2x2_ASAP7_75t_SL g28 ( 
.A(n_2),
.B(n_9),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_6),
.B(n_5),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_1),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_15),
.B(n_16),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_13),
.B(n_11),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_10),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_28),
.A2(n_19),
.B1(n_3),
.B2(n_0),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_19),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_24),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

OA21x2_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_25),
.B(n_32),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_34),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_39),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

NAND2x1_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_25),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_26),
.Y(n_46)
);

OA22x2_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_27),
.B1(n_31),
.B2(n_29),
.Y(n_47)
);

NOR2x1p5_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_24),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_37),
.Y(n_49)
);

NOR2xp67_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_4),
.Y(n_50)
);

OAI22xp5_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_17),
.B1(n_14),
.B2(n_12),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_SL g53 ( 
.A1(n_52),
.A2(n_50),
.B1(n_22),
.B2(n_18),
.Y(n_53)
);


endmodule