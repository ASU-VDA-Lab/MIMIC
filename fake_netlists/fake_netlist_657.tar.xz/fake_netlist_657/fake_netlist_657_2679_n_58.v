module fake_netlist_657_2679_n_58 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_26, n_9, n_13, n_8, n_6, n_58);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_26;
input n_9;
input n_13;
input n_8;
input n_6;

output n_58;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_40;
wire n_54;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx1_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_10),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_5),
.B(n_8),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_18),
.B(n_21),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_14),
.B(n_12),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_4),
.Y(n_33)
);

INVx6_ASAP7_75t_L g34 ( 
.A(n_6),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_11),
.A2(n_22),
.B1(n_13),
.B2(n_7),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_25),
.B(n_20),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_0),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_27),
.B(n_23),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_28),
.Y(n_41)
);

OAI21x1_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_37),
.B(n_33),
.Y(n_42)
);

BUFx4f_ASAP7_75t_SL g43 ( 
.A(n_39),
.Y(n_43)
);

AO21x2_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_36),
.B(n_30),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_41),
.Y(n_45)
);

BUFx6f_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_44),
.Y(n_47)
);

INVxp67_ASAP7_75t_SL g48 ( 
.A(n_46),
.Y(n_48)
);

OAI221xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_46),
.B1(n_35),
.B2(n_48),
.C(n_43),
.Y(n_49)
);

OAI22xp33_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_43),
.B1(n_46),
.B2(n_32),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_31),
.B1(n_32),
.B2(n_29),
.Y(n_51)
);

OAI21xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_31),
.B(n_23),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_24),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_32),
.B1(n_25),
.B2(n_24),
.Y(n_54)
);

AOI222xp33_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_3),
.B1(n_1),
.B2(n_9),
.C1(n_16),
.C2(n_15),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

XNOR2xp5_ASAP7_75t_L g57 ( 
.A(n_56),
.B(n_17),
.Y(n_57)
);

AOI21xp33_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_55),
.B(n_19),
.Y(n_58)
);


endmodule