module fake_netlist_657_3144_n_50 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_50);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_50;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx1_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

BUFx8_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_8),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

AND2x6_ASAP7_75t_L g26 ( 
.A(n_14),
.B(n_10),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_13),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_1),
.C(n_0),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_24),
.B(n_18),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_SL g31 ( 
.A1(n_20),
.A2(n_19),
.B1(n_18),
.B2(n_3),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_23),
.C(n_27),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_28),
.A2(n_25),
.B(n_22),
.Y(n_33)
);

AOI21xp33_ASAP7_75t_L g34 ( 
.A1(n_29),
.A2(n_31),
.B(n_22),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_19),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_38),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_40),
.C(n_41),
.Y(n_43)
);

NAND3xp33_ASAP7_75t_SL g44 ( 
.A(n_41),
.B(n_26),
.C(n_4),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_SL g45 ( 
.A1(n_43),
.A2(n_26),
.B1(n_9),
.B2(n_7),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_11),
.Y(n_46)
);

OAI22xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_26),
.B1(n_17),
.B2(n_16),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_47),
.Y(n_50)
);


endmodule