module fake_netlist_657_4465_n_54 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_54);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_54;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

BUFx8_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_18),
.B(n_7),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_3),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_15),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_6),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_25),
.Y(n_35)
);

NOR2x2_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_25),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_0),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_2),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_28),
.B(n_33),
.C(n_29),
.Y(n_39)
);

OAI21x1_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_32),
.B(n_29),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AND2x2_ASAP7_75t_SL g43 ( 
.A(n_42),
.B(n_35),
.Y(n_43)
);

OAI21xp5_ASAP7_75t_SL g44 ( 
.A1(n_41),
.A2(n_35),
.B(n_36),
.Y(n_44)
);

OAI22xp33_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_30),
.B1(n_26),
.B2(n_5),
.Y(n_45)
);

AOI321xp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_30),
.A3(n_10),
.B1(n_8),
.B2(n_11),
.C(n_9),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_13),
.B(n_12),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_47),
.Y(n_49)
);

OR2x2_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_17),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_21),
.B1(n_20),
.B2(n_19),
.Y(n_52)
);

OAI22x1_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_23),
.B1(n_24),
.B2(n_52),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);


endmodule