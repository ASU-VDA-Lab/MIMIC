module fake_netlist_657_4539_n_32 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_32);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_32;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;

INVx2_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_7),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

INVx5_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_6),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_19),
.B1(n_20),
.B2(n_18),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI221x1_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_21),
.B1(n_24),
.B2(n_0),
.C(n_1),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_8),
.B1(n_4),
.B2(n_2),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

AOI322xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_10),
.A3(n_9),
.B1(n_13),
.B2(n_14),
.C1(n_11),
.C2(n_12),
.Y(n_32)
);


endmodule