module fake_netlist_657_1576_n_31 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_31);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_31;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_26;
wire n_9;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_3),
.Y(n_10)
);

INVxp67_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

BUFx10_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_14),
.B1(n_11),
.B2(n_9),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_15),
.B(n_1),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

NAND3xp33_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_10),
.C(n_13),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_18),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_15),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_10),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

OA21x2_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_21),
.B(n_22),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_27),
.B1(n_8),
.B2(n_5),
.Y(n_31)
);


endmodule