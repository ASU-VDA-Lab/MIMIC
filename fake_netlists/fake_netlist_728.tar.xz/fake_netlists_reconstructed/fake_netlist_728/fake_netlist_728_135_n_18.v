module fake_netlist_728_135_n_18 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_18);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_18;

wire n_12;
wire n_10;
wire n_15;
wire n_14;
wire n_17;
wire n_13;
wire n_16;
wire n_9;
wire n_11;

INVx1_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVxp67_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_5),
.B(n_6),
.Y(n_12)
);

AO21x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_11),
.B(n_9),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_R g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_1),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_9),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_6),
.B(n_4),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_3),
.B1(n_4),
.B2(n_7),
.C1(n_8),
.C2(n_10),
.Y(n_18)
);


endmodule