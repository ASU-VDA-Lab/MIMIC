module fake_netlist_728_2113_n_17 (n_1, n_2, n_6, n_0, n_3, n_4, n_5, n_17);

input n_1;
input n_2;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_17;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_15;
wire n_16;
wire n_14;
wire n_9;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_6),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_2),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NOR4xp25_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_8),
.C(n_7),
.D(n_9),
.Y(n_12)
);

OA21x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_3),
.B(n_9),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B1(n_4),
.B2(n_0),
.C(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_17)
);


endmodule