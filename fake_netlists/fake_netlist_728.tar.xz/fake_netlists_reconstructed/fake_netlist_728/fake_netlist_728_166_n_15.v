module fake_netlist_728_166_n_15 (n_1, n_2, n_0, n_3, n_4, n_5, n_15);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;
input n_5;

output n_15;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_14;

AND2x2_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_0),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

AOI21x1_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

OAI321xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.A3(n_6),
.B1(n_7),
.B2(n_5),
.C(n_4),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_4),
.B1(n_7),
.B2(n_12),
.C1(n_11),
.C2(n_10),
.Y(n_15)
);


endmodule