module fake_netlist_728_606_n_19 (n_8, n_1, n_2, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_19);

input n_8;
input n_1;
input n_2;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_19;

wire n_14;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_15;
wire n_16;

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_0),
.A2(n_4),
.B1(n_5),
.B2(n_10),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_2),
.A2(n_5),
.B1(n_8),
.B2(n_6),
.Y(n_12)
);

NAND2xp33_ASAP7_75t_SL g13 ( 
.A(n_7),
.B(n_9),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_11),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_13),
.B(n_3),
.C(n_1),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);


endmodule