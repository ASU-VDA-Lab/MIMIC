module fake_netlist_728_1016_n_21 (n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_21);

input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_21;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_12;
wire n_15;
wire n_16;
wire n_19;

AND2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_2),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_3),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_6),
.B(n_7),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B(n_0),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B1(n_15),
.B2(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NOR5xp2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_4),
.C(n_1),
.D(n_5),
.E(n_6),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_14),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_7),
.B1(n_5),
.B2(n_1),
.C(n_11),
.Y(n_21)
);


endmodule