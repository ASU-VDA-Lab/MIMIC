module fake_netlist_728_1590_n_18 (n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_18);

input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_18;

wire n_12;
wire n_8;
wire n_10;
wire n_15;
wire n_14;
wire n_17;
wire n_13;
wire n_16;
wire n_9;
wire n_11;

INVx5_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVxp67_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVxp67_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_5),
.B(n_2),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_6),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_1),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_3),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_13),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_11),
.B2(n_4),
.Y(n_18)
);


endmodule