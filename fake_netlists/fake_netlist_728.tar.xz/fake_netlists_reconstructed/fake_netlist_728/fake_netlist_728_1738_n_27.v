module fake_netlist_728_1738_n_27 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_27);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_27;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_11;
wire n_9;
wire n_25;
wire n_12;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx16_ASAP7_75t_R g9 ( 
.A(n_7),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_4),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_8),
.B(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_SL g14 ( 
.A(n_9),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_4),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_13),
.B2(n_11),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_SL g17 ( 
.A1(n_15),
.A2(n_13),
.B(n_11),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

O2A1O1Ixp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_17),
.B(n_14),
.C(n_10),
.Y(n_20)
);

AOI221x1_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_14),
.B1(n_7),
.B2(n_4),
.C(n_6),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_SL g22 ( 
.A1(n_19),
.A2(n_6),
.B(n_1),
.C(n_0),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_0),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_22),
.B(n_2),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_3),
.B1(n_5),
.B2(n_6),
.C1(n_8),
.C2(n_25),
.Y(n_27)
);


endmodule