module fake_netlist_728_1923_n_21 (n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_21);

input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_21;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_12;
wire n_15;
wire n_16;
wire n_19;

AND2x2_ASAP7_75t_L g12 ( 
.A(n_5),
.B(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_2),
.B1(n_10),
.B2(n_3),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_4),
.A2(n_0),
.B1(n_8),
.B2(n_6),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_6),
.B(n_4),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

OAI32xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_13),
.A3(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.C(n_7),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_9),
.Y(n_20)
);

INVx4_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);


endmodule