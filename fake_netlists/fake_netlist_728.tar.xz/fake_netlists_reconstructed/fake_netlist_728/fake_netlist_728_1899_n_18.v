module fake_netlist_728_1899_n_18 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_18);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_18;

wire n_12;
wire n_10;
wire n_15;
wire n_14;
wire n_17;
wire n_13;
wire n_16;
wire n_11;

AND2x6_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_8),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_5),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_2),
.B1(n_4),
.B2(n_6),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_10),
.B2(n_0),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.C(n_4),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_3),
.Y(n_17)
);

AOI321xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_5),
.A3(n_6),
.B1(n_8),
.B2(n_9),
.C(n_11),
.Y(n_18)
);


endmodule