module fake_netlist_728_1726_n_34 (n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_34);

input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_34;

wire n_32;
wire n_33;
wire n_30;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_25;
wire n_12;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_3),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_10),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

XOR2xp5_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_11),
.Y(n_15)
);

AOI21x1_ASAP7_75t_L g16 ( 
.A1(n_0),
.A2(n_5),
.B(n_1),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_9),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_6),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_12),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_13),
.C(n_14),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_17),
.B1(n_16),
.B2(n_13),
.Y(n_26)
);

NAND2x1_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_20),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_15),
.B1(n_21),
.B2(n_20),
.C(n_16),
.Y(n_28)
);

OA211x2_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_15),
.B(n_1),
.C(n_0),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

OAI211xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_4),
.B(n_3),
.C(n_2),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_32)
);

XOR2xp5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_7),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_R g34 ( 
.A1(n_32),
.A2(n_11),
.B1(n_31),
.B2(n_33),
.C(n_15),
.Y(n_34)
);


endmodule