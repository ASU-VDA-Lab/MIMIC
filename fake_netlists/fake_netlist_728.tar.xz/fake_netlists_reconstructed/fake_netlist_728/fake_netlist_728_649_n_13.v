module fake_netlist_728_649_n_13 (n_0, n_2, n_1, n_13);

input n_0;
input n_2;
input n_1;

output n_13;

wire n_12;
wire n_8;
wire n_11;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_3;
wire n_4;
wire n_5;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

AND2x4_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

OAI22xp5_ASAP7_75t_SL g5 ( 
.A1(n_3),
.A2(n_4),
.B1(n_0),
.B2(n_1),
.Y(n_5)
);

OAI211xp5_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AND2x2_ASAP7_75t_SL g8 ( 
.A(n_5),
.B(n_4),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_4),
.B1(n_6),
.B2(n_0),
.Y(n_9)
);

AOI211xp5_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_4),
.C(n_8),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_0),
.C(n_1),
.Y(n_11)
);

OAI22x1_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_0),
.B1(n_2),
.B2(n_1),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_1),
.B1(n_2),
.B2(n_12),
.Y(n_13)
);


endmodule