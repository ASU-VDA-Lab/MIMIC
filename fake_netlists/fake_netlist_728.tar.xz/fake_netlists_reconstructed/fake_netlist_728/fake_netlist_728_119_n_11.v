module fake_netlist_728_119_n_11 (n_1, n_2, n_0, n_3, n_4, n_11);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_11;

wire n_8;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_5;

INVx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_1),
.A2(n_3),
.B1(n_0),
.B2(n_4),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_3),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

AOI221xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_6),
.B1(n_7),
.B2(n_0),
.C(n_1),
.Y(n_9)
);

AND3x1_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.C(n_2),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_2),
.B1(n_4),
.B2(n_6),
.Y(n_11)
);


endmodule