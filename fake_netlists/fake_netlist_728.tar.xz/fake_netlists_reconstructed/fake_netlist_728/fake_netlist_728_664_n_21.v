module fake_netlist_728_664_n_21 (n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_21);

input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_21;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_12;
wire n_15;
wire n_16;
wire n_19;

INVx3_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_4),
.A2(n_6),
.B1(n_8),
.B2(n_9),
.Y(n_13)
);

INVx6_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_7),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_13),
.B(n_15),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_7),
.B1(n_6),
.B2(n_14),
.C(n_0),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_2),
.C(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_11),
.B(n_3),
.Y(n_21)
);


endmodule