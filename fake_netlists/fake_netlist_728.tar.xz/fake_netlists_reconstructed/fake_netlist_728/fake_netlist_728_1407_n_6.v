module fake_netlist_728_1407_n_6 (n_0, n_1, n_6);

input n_0;
input n_1;

output n_6;

wire n_2;
wire n_3;
wire n_4;
wire n_5;

NAND2xp5_ASAP7_75t_L g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

AND2x4_ASAP7_75t_SL g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

NOR3xp33_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_1),
.C(n_0),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

OAI222xp33_ASAP7_75t_SL g6 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_4),
.C2(n_3),
.Y(n_6)
);


endmodule