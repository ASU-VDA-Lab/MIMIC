module fake_netlist_728_1880_n_38 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_38);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_38;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_11;
wire n_9;
wire n_25;
wire n_22;
wire n_12;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_34;
wire n_16;
wire n_26;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_1),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_12),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_12),
.B(n_0),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_12),
.B(n_0),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_12),
.A2(n_6),
.B(n_5),
.C(n_3),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_3),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_11),
.A2(n_8),
.B(n_6),
.Y(n_22)
);

INVx4_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_11),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_19),
.B(n_9),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_18),
.Y(n_26)
);

CKINVDCx16_ASAP7_75t_R g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_20),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_23),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_26),
.B1(n_23),
.B2(n_24),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OAI221xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_23),
.B1(n_29),
.B2(n_24),
.C(n_14),
.Y(n_33)
);

AOI211xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_28),
.B(n_15),
.C(n_10),
.Y(n_34)
);

OAI322xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_15),
.A3(n_23),
.B1(n_16),
.B2(n_13),
.C1(n_27),
.C2(n_22),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_32),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_SL g38 ( 
.A1(n_37),
.A2(n_27),
.B1(n_35),
.B2(n_34),
.Y(n_38)
);


endmodule