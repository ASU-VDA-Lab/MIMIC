module fake_netlist_728_347_n_3 (n_0, n_1, n_3);

input n_0;
input n_1;

output n_3;

wire n_2;

NOR2x1_ASAP7_75t_SL g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

AND2x4_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);


endmodule