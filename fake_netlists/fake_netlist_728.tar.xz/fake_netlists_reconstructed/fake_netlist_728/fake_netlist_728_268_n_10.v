module fake_netlist_728_268_n_10 (n_0, n_2, n_1, n_10);

input n_0;
input n_2;
input n_1;

output n_10;

wire n_8;
wire n_7;
wire n_9;
wire n_6;
wire n_3;
wire n_4;
wire n_5;

INVx2_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

OAI22xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_5)
);

NAND3xp33_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_3),
.C(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_6),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_7),
.B1(n_2),
.B2(n_0),
.Y(n_10)
);


endmodule