module fake_netlist_728_1492_n_24 (n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_24);

input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_24;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_8;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

OR2x6_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_2),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_3),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

BUFx4f_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

OAI22xp33_ASAP7_75t_L g12 ( 
.A1(n_1),
.A2(n_5),
.B1(n_6),
.B2(n_7),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

INVxp67_ASAP7_75t_SL g14 ( 
.A(n_9),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.Y(n_18)
);

OAI31xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.A3(n_17),
.B(n_11),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_4),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_13),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_4),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_13),
.B(n_22),
.Y(n_24)
);


endmodule