module fake_netlist_728_2129_n_18 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_18);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_18;

wire n_12;
wire n_10;
wire n_15;
wire n_14;
wire n_17;
wire n_13;
wire n_16;
wire n_11;

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_1),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_2),
.B(n_6),
.Y(n_12)
);

AO31x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.A3(n_6),
.B(n_4),
.Y(n_13)
);

INVxp67_ASAP7_75t_SL g14 ( 
.A(n_13),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);

OAI21xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_13),
.B(n_4),
.Y(n_16)
);

OAI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B1(n_7),
.B2(n_0),
.Y(n_17)
);

OAI211xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_11),
.B(n_9),
.C(n_3),
.Y(n_18)
);


endmodule