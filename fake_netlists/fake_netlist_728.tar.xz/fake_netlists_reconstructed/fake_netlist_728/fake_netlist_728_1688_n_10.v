module fake_netlist_728_1688_n_10 (n_0, n_2, n_1, n_10);

input n_0;
input n_2;
input n_1;

output n_10;

wire n_8;
wire n_7;
wire n_9;
wire n_6;
wire n_3;
wire n_4;
wire n_5;

NOR2x1p5_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

A2O1A1Ixp33_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_5)
);

O2A1O1Ixp33_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_4),
.B(n_3),
.C(n_1),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_7)
);

NAND2x1_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI222xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.C1(n_4),
.C2(n_5),
.Y(n_10)
);


endmodule