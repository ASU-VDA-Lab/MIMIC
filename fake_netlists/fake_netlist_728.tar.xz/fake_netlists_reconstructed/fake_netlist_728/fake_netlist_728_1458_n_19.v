module fake_netlist_728_1458_n_19 (n_1, n_2, n_6, n_0, n_3, n_4, n_5, n_19);

input n_1;
input n_2;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_19;

wire n_14;
wire n_17;
wire n_13;
wire n_7;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_8;
wire n_10;
wire n_15;
wire n_16;

INVxp67_ASAP7_75t_SL g7 ( 
.A(n_5),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_1),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

NOR2x1_ASAP7_75t_SL g11 ( 
.A(n_8),
.B(n_0),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);

NAND4xp25_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.C(n_9),
.D(n_7),
.Y(n_15)
);

NAND5xp2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_11),
.C(n_5),
.D(n_2),
.E(n_4),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_10),
.B1(n_6),
.B2(n_5),
.Y(n_17)
);

AOI221x1_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_3),
.B1(n_6),
.B2(n_15),
.C(n_14),
.Y(n_18)
);

OR2x6_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_18),
.Y(n_19)
);


endmodule