module fake_netlist_731_541_n_57 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_57);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_57;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_56;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

NAND2xp33_ASAP7_75t_L g17 ( 
.A(n_11),
.B(n_10),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_4),
.B(n_6),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_6),
.B(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_24),
.B(n_1),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

CKINVDCx14_ASAP7_75t_R g32 ( 
.A(n_27),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_30),
.Y(n_36)
);

OAI33xp33_ASAP7_75t_L g37 ( 
.A1(n_31),
.A2(n_26),
.A3(n_19),
.B1(n_24),
.B2(n_22),
.B3(n_21),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_33),
.Y(n_41)
);

NOR2x1_ASAP7_75t_SL g42 ( 
.A(n_38),
.B(n_31),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_33),
.Y(n_43)
);

AOI21xp33_ASAP7_75t_SL g44 ( 
.A1(n_41),
.A2(n_28),
.B(n_5),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

OAI21xp33_ASAP7_75t_SL g47 ( 
.A1(n_43),
.A2(n_40),
.B(n_34),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_33),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_33),
.Y(n_49)
);

INVxp67_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

NAND5xp2_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_20),
.C(n_25),
.D(n_17),
.E(n_37),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_21),
.B1(n_47),
.B2(n_17),
.Y(n_52)
);

OA21x2_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_48),
.B(n_51),
.Y(n_53)
);

BUFx2_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_54),
.Y(n_55)
);

OAI321xp33_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_8),
.A3(n_3),
.B1(n_12),
.B2(n_14),
.C(n_13),
.Y(n_56)
);

AO22x2_ASAP7_75t_L g57 ( 
.A1(n_55),
.A2(n_15),
.B1(n_53),
.B2(n_56),
.Y(n_57)
);


endmodule