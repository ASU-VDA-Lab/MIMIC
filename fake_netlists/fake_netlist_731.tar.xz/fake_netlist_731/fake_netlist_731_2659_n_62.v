module fake_netlist_731_2659_n_62 (n_20, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_62);

input n_20;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_62;

wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_3),
.B(n_11),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_2),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_10),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_12),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_18),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_13),
.B(n_5),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_16),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_7),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_31),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_27),
.Y(n_37)
);

AND2x6_ASAP7_75t_SL g38 ( 
.A(n_28),
.B(n_19),
.Y(n_38)
);

INVx3_ASAP7_75t_L g39 ( 
.A(n_31),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_25),
.B(n_19),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

AO31x2_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_32),
.A3(n_30),
.B(n_29),
.Y(n_42)
);

OA21x2_ASAP7_75t_L g43 ( 
.A1(n_37),
.A2(n_34),
.B(n_35),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_31),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_36),
.Y(n_45)
);

OA21x2_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_33),
.B(n_23),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_42),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_43),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

AOI221xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_39),
.B1(n_36),
.B2(n_42),
.C(n_26),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_42),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_39),
.B1(n_24),
.B2(n_20),
.Y(n_53)
);

INVx3_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

OR2x2_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_24),
.Y(n_56)
);

NOR2xp33_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_24),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_54),
.B(n_1),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_53),
.B1(n_6),
.B2(n_4),
.Y(n_59)
);

OR2x2_ASAP7_75t_SL g60 ( 
.A(n_56),
.B(n_8),
.Y(n_60)
);

XOR2x2_ASAP7_75t_L g61 ( 
.A(n_59),
.B(n_58),
.Y(n_61)
);

AOI22xp5_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_60),
.B1(n_22),
.B2(n_17),
.Y(n_62)
);


endmodule