module fake_netlist_731_2788_n_66 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_66);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_66;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_64;
wire n_22;
wire n_62;
wire n_36;
wire n_34;
wire n_39;
wire n_18;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_65;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_57;
wire n_35;
wire n_63;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_1),
.B(n_7),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_0),
.B(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

INVx4_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_0),
.B(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

OAI21xp33_ASAP7_75t_SL g28 ( 
.A1(n_20),
.A2(n_8),
.B(n_3),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_SL g29 ( 
.A(n_21),
.B(n_13),
.C(n_8),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_27),
.B(n_13),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_27),
.B(n_26),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_22),
.Y(n_34)
);

OAI21x1_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_27),
.B(n_26),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_30),
.A2(n_19),
.B(n_26),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_30),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_28),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_33),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_35),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVxp67_ASAP7_75t_SL g42 ( 
.A(n_37),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_37),
.B(n_35),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

OAI32xp33_ASAP7_75t_L g47 ( 
.A1(n_40),
.A2(n_28),
.A3(n_22),
.B1(n_25),
.B2(n_27),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_40),
.B1(n_43),
.B2(n_41),
.Y(n_48)
);

AOI322xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_29),
.A3(n_25),
.B1(n_20),
.B2(n_31),
.C1(n_23),
.C2(n_27),
.Y(n_49)
);

INVxp67_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

OAI221xp5_ASAP7_75t_L g51 ( 
.A1(n_45),
.A2(n_22),
.B1(n_36),
.B2(n_23),
.C(n_20),
.Y(n_51)
);

O2A1O1Ixp33_ASAP7_75t_L g52 ( 
.A1(n_47),
.A2(n_19),
.B(n_22),
.C(n_18),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_SL g53 ( 
.A(n_48),
.B(n_18),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

NAND5xp2_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_47),
.C(n_16),
.D(n_14),
.E(n_15),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_51),
.A2(n_24),
.B1(n_33),
.B2(n_15),
.Y(n_56)
);

AOI211xp5_ASAP7_75t_L g57 ( 
.A1(n_52),
.A2(n_24),
.B(n_17),
.C(n_16),
.Y(n_57)
);

CKINVDCx5p33_ASAP7_75t_R g58 ( 
.A(n_50),
.Y(n_58)
);

HB1xp67_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_53),
.B(n_57),
.Y(n_62)
);

AOI21xp33_ASAP7_75t_L g63 ( 
.A1(n_56),
.A2(n_17),
.B(n_5),
.Y(n_63)
);

AOI22xp33_ASAP7_75t_L g64 ( 
.A1(n_62),
.A2(n_55),
.B1(n_61),
.B2(n_60),
.Y(n_64)
);

CKINVDCx20_ASAP7_75t_R g65 ( 
.A(n_59),
.Y(n_65)
);

AOI22x1_ASAP7_75t_L g66 ( 
.A1(n_65),
.A2(n_9),
.B1(n_63),
.B2(n_64),
.Y(n_66)
);


endmodule