module fake_netlist_731_1523_n_45 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_45);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_45;

wire n_20;
wire n_23;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

AND2x4_ASAP7_75t_L g20 ( 
.A(n_0),
.B(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_9),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_7),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_4),
.B(n_8),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

BUFx12f_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_20),
.Y(n_31)
);

BUFx12f_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

AOI211xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_28),
.B(n_30),
.C(n_20),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_32),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_19),
.Y(n_36)
);

XNOR2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_26),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_24),
.B1(n_23),
.B2(n_27),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_37),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_19),
.Y(n_41)
);

NOR4xp25_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_5),
.C(n_3),
.D(n_1),
.Y(n_42)
);

CKINVDCx20_ASAP7_75t_R g43 ( 
.A(n_41),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_10),
.B1(n_6),
.B2(n_11),
.C(n_12),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_16),
.B1(n_17),
.B2(n_44),
.Y(n_45)
);


endmodule