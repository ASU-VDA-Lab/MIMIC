module fake_netlist_731_850_n_13 (n_1, n_2, n_3, n_4, n_5, n_0, n_13);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_13;

wire n_12;
wire n_9;
wire n_11;
wire n_10;
wire n_7;
wire n_6;
wire n_8;

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_2),
.B(n_4),
.Y(n_6)
);

INVxp67_ASAP7_75t_SL g7 ( 
.A(n_2),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_0),
.B(n_1),
.Y(n_8)
);

AND2x6_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_6),
.Y(n_9)
);

OAI32xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.A3(n_4),
.B1(n_0),
.B2(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_3),
.B1(n_5),
.B2(n_11),
.Y(n_13)
);


endmodule