module fake_netlist_731_1603_n_53 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_53);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_53;

wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_42;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_52;
wire n_32;

INVx2_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_12),
.B(n_9),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_3),
.B(n_15),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_8),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_2),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_6),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_21),
.B(n_22),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_0),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_24),
.B(n_16),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

BUFx4f_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_26),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_37)
);

A2O1A1Ixp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_35),
.B(n_34),
.C(n_32),
.Y(n_38)
);

CKINVDCx14_ASAP7_75t_R g39 ( 
.A(n_36),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_37),
.B1(n_25),
.B2(n_31),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AOI21xp33_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_28),
.B(n_29),
.Y(n_44)
);

OAI211xp5_ASAP7_75t_SL g45 ( 
.A1(n_42),
.A2(n_30),
.B(n_28),
.C(n_27),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_17),
.Y(n_46)
);

AOI221x1_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_19),
.B1(n_5),
.B2(n_1),
.C(n_4),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_33),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_SL g50 ( 
.A(n_48),
.B(n_10),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_49),
.Y(n_51)
);

AND2x4_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_47),
.Y(n_52)
);

AOI322xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_11),
.A3(n_13),
.B1(n_14),
.B2(n_20),
.C1(n_23),
.C2(n_52),
.Y(n_53)
);


endmodule