module fake_netlist_731_3128_n_65 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_65);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_65;

wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_64;
wire n_22;
wire n_62;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_42;
wire n_27;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_63;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_11),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_2),
.B(n_5),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_16),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_1),
.A2(n_8),
.B1(n_6),
.B2(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

AND2x6_ASAP7_75t_L g29 ( 
.A(n_13),
.B(n_4),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_3),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_23),
.B(n_1),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_25),
.B(n_2),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_25),
.A2(n_10),
.B1(n_9),
.B2(n_7),
.Y(n_33)
);

CKINVDCx8_ASAP7_75t_R g34 ( 
.A(n_29),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_21),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_22),
.B(n_7),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

AO21x2_ASAP7_75t_L g38 ( 
.A1(n_31),
.A2(n_24),
.B(n_30),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_32),
.B(n_22),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_37),
.Y(n_43)
);

INVxp67_ASAP7_75t_SL g44 ( 
.A(n_40),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NAND4xp25_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_35),
.C(n_33),
.D(n_28),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_SL g47 ( 
.A1(n_41),
.A2(n_35),
.B1(n_26),
.B2(n_21),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_42),
.Y(n_48)
);

AOI32xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_26),
.A3(n_24),
.B1(n_36),
.B2(n_32),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_46),
.Y(n_50)
);

OR2x6_ASAP7_75t_L g51 ( 
.A(n_45),
.B(n_27),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_38),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_39),
.Y(n_53)
);

OAI31xp33_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_36),
.A3(n_32),
.B(n_39),
.Y(n_54)
);

AOI221xp5_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_32),
.B1(n_40),
.B2(n_44),
.C(n_43),
.Y(n_55)
);

O2A1O1Ixp33_ASAP7_75t_L g56 ( 
.A1(n_51),
.A2(n_43),
.B(n_34),
.C(n_9),
.Y(n_56)
);

NOR2x1p5_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_16),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_56),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_55),
.A2(n_34),
.B1(n_18),
.B2(n_17),
.Y(n_59)
);

AOI211xp5_ASAP7_75t_L g60 ( 
.A1(n_54),
.A2(n_29),
.B(n_20),
.C(n_0),
.Y(n_60)
);

OR3x1_ASAP7_75t_L g61 ( 
.A(n_58),
.B(n_29),
.C(n_12),
.Y(n_61)
);

HB1xp67_ASAP7_75t_L g62 ( 
.A(n_57),
.Y(n_62)
);

AO22x2_ASAP7_75t_L g63 ( 
.A1(n_59),
.A2(n_14),
.B1(n_29),
.B2(n_60),
.Y(n_63)
);

AOI22xp5_ASAP7_75t_L g64 ( 
.A1(n_63),
.A2(n_57),
.B1(n_58),
.B2(n_62),
.Y(n_64)
);

XNOR2xp5_ASAP7_75t_L g65 ( 
.A(n_64),
.B(n_61),
.Y(n_65)
);


endmodule