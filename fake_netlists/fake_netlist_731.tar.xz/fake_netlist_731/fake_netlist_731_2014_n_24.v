module fake_netlist_731_2014_n_24 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_24);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;

output n_24;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_9;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

AND2x4_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_4),
.Y(n_8)
);

NAND2xp33_ASAP7_75t_R g9 ( 
.A(n_5),
.B(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_2),
.B(n_1),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_8),
.B1(n_10),
.B2(n_9),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_8),
.B1(n_12),
.B2(n_13),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_15),
.B(n_14),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AOI21xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_10),
.B(n_4),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_6),
.B(n_5),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.C1(n_21),
.C2(n_0),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_24)
);


endmodule