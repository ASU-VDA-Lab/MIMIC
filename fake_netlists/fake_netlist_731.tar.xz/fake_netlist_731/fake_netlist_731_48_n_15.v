module fake_netlist_731_48_n_15 (n_1, n_2, n_3, n_4, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_8;
wire n_9;
wire n_10;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_11;

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_3),
.Y(n_7)
);

AOI221x1_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_0),
.B1(n_4),
.B2(n_2),
.C(n_3),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI21xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B(n_5),
.Y(n_11)
);

OAI221xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B1(n_5),
.B2(n_8),
.C(n_0),
.Y(n_12)
);

AND3x4_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_0),
.C(n_2),
.Y(n_13)
);

XNOR2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_4),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_5),
.B(n_13),
.Y(n_15)
);


endmodule