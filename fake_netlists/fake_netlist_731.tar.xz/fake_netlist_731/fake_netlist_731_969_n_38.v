module fake_netlist_731_969_n_38 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_38);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_38;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_5),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_4),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_1),
.B(n_0),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_19),
.B(n_16),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_20),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_16),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_24),
.B2(n_18),
.C1(n_22),
.C2(n_21),
.Y(n_31)
);

NAND5xp2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_29),
.C(n_25),
.D(n_2),
.E(n_3),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_10),
.C(n_7),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_11),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_32),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

INVxp67_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_37),
.B1(n_14),
.B2(n_13),
.Y(n_38)
);


endmodule