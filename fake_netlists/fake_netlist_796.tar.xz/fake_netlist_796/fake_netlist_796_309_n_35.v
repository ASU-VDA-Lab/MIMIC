module fake_netlist_796_309_n_35 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_35);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_35;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_18;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

INVx2_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

AOI21x1_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_8),
.B(n_16),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_5),
.B(n_15),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_3),
.B(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

INVx5_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_12),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_17),
.B(n_18),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

OAI322xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_24),
.A3(n_23),
.B1(n_29),
.B2(n_26),
.C1(n_19),
.C2(n_22),
.Y(n_31)
);

AND4x1_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_26),
.C(n_1),
.D(n_0),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_13),
.B1(n_7),
.B2(n_6),
.Y(n_35)
);


endmodule