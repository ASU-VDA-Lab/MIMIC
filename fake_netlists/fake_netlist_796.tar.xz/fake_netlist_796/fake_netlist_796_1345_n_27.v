module fake_netlist_796_1345_n_27 (n_1, n_0, n_5, n_3, n_2, n_4, n_27);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_27;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_25;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

NAND2xp33_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

AO31x2_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_4),
.A3(n_2),
.B(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_8),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_2),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_11),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_11),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_11),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_SL g19 ( 
.A(n_17),
.B(n_15),
.Y(n_19)
);

AOI21x1_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_13),
.B(n_10),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_12),
.B(n_5),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_12),
.B(n_18),
.C(n_20),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_SL g23 ( 
.A1(n_19),
.A2(n_12),
.B(n_16),
.C(n_8),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

OAI22x1_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_25),
.B1(n_23),
.B2(n_12),
.Y(n_27)
);


endmodule