module fake_netlist_796_916_n_15 (n_1, n_0, n_3, n_2, n_4, n_15);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_15;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_14;
wire n_9;
wire n_12;
wire n_13;
wire n_8;

INVx4_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

OAI22x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);

AO32x2_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_6),
.A3(n_2),
.B1(n_0),
.B2(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_3),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_4),
.Y(n_15)
);


endmodule