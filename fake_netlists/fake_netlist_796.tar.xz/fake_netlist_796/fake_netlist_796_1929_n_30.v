module fake_netlist_796_1929_n_30 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_30);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_30;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_23;
wire n_28;
wire n_19;
wire n_21;
wire n_22;

AND2x6_ASAP7_75t_L g17 ( 
.A(n_11),
.B(n_10),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_4),
.B(n_15),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_3),
.Y(n_20)
);

AND3x2_ASAP7_75t_L g21 ( 
.A(n_1),
.B(n_5),
.C(n_9),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_2),
.Y(n_22)
);

OAI21xp33_ASAP7_75t_L g23 ( 
.A1(n_19),
.A2(n_13),
.B(n_0),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_17),
.B1(n_22),
.B2(n_20),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_17),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_18),
.B(n_17),
.C(n_21),
.Y(n_26)
);

NOR3x1_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_8),
.C(n_7),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_27),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_16),
.B1(n_14),
.B2(n_12),
.Y(n_30)
);


endmodule