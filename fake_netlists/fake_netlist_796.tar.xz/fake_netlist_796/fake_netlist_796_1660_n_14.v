module fake_netlist_796_1660_n_14 (n_1, n_0, n_5, n_3, n_2, n_4, n_14);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_14;

wire n_7;
wire n_10;
wire n_11;
wire n_6;
wire n_9;
wire n_12;
wire n_13;
wire n_8;

OR2x2_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_3),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

A2O1A1Ixp33_ASAP7_75t_SL g8 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.C(n_4),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_5),
.B(n_1),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_5),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

NAND4xp75_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_8),
.C(n_9),
.D(n_11),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_10),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);


endmodule