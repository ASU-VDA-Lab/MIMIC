module fake_netlist_796_714_n_48 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_24, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_48);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_24;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_48;

wire n_37;
wire n_45;
wire n_44;
wire n_47;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_42;
wire n_43;
wire n_38;
wire n_28;
wire n_30;
wire n_41;
wire n_32;

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_11),
.B(n_16),
.Y(n_26)
);

NOR2xp67_ASAP7_75t_L g27 ( 
.A(n_5),
.B(n_7),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_6),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_18),
.B(n_14),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_16),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_32),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_25),
.B1(n_27),
.B2(n_29),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_28),
.B(n_26),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_34),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_30),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_SL g40 ( 
.A1(n_38),
.A2(n_24),
.B1(n_18),
.B2(n_0),
.C(n_1),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

NAND4xp25_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_4),
.C(n_3),
.D(n_2),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_9),
.C(n_8),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_40),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_13),
.B1(n_12),
.B2(n_10),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_19),
.B1(n_17),
.B2(n_15),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_21),
.B1(n_22),
.B2(n_46),
.Y(n_48)
);


endmodule