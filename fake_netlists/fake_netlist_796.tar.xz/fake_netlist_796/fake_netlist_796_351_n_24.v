module fake_netlist_796_351_n_24 (n_1, n_2, n_3, n_0, n_24);

input n_1;
input n_2;
input n_3;
input n_0;

output n_24;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_5;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_4;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_1),
.Y(n_4)
);

BUFx8_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

BUFx3_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

BUFx6f_ASAP7_75t_SL g8 ( 
.A(n_6),
.Y(n_8)
);

INVx3_ASAP7_75t_SL g9 ( 
.A(n_4),
.Y(n_9)
);

A2O1A1Ixp33_ASAP7_75t_SL g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_2),
.C(n_0),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_3),
.B(n_6),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_5),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_5),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_3),
.C(n_8),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_8),
.Y(n_16)
);

OAI32xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.A3(n_13),
.B1(n_7),
.B2(n_14),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

AOI211xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_15),
.B(n_16),
.C(n_17),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_SL g22 ( 
.A(n_19),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_15),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_22),
.B1(n_15),
.B2(n_16),
.Y(n_24)
);


endmodule