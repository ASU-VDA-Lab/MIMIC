module fake_netlist_796_350_n_31 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_31);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_31;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_22;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_9),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_11),
.Y(n_18)
);

CKINVDCx8_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_R g22 ( 
.A(n_15),
.B(n_6),
.Y(n_22)
);

OR2x6_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_21),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_1),
.B(n_0),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_16),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_18),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_20),
.B1(n_24),
.B2(n_22),
.Y(n_27)
);

OAI211xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_19),
.B(n_16),
.C(n_2),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OAI22x1_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_14),
.B1(n_13),
.B2(n_8),
.Y(n_31)
);


endmodule