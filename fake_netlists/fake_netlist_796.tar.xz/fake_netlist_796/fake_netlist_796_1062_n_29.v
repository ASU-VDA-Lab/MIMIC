module fake_netlist_796_1062_n_29 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_29);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_29;

wire n_20;
wire n_17;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_21;
wire n_22;

BUFx3_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_7),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

INVxp67_ASAP7_75t_SL g19 ( 
.A(n_7),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_3),
.Y(n_20)
);

AO22x1_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_15),
.A2(n_9),
.B(n_8),
.C(n_5),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_15),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_20),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_SL g26 ( 
.A(n_25),
.B(n_20),
.C(n_22),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_16),
.B1(n_17),
.B2(n_18),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_29)
);


endmodule