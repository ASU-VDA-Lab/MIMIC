module fake_netlist_796_484_n_47 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_14, n_47);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_14;

output n_47;

wire n_37;
wire n_45;
wire n_44;
wire n_36;
wire n_29;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_43;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_41;
wire n_32;
wire n_22;

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_7),
.B(n_17),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

OA21x2_ASAP7_75t_L g25 ( 
.A1(n_1),
.A2(n_3),
.B(n_14),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_10),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_13),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_11),
.B(n_15),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_18),
.B(n_20),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_24),
.B(n_18),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_23),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_30),
.B(n_27),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_28),
.Y(n_35)
);

NOR4xp25_ASAP7_75t_SL g36 ( 
.A(n_35),
.B(n_26),
.C(n_32),
.D(n_25),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_29),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_R g40 ( 
.A(n_38),
.B(n_39),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_29),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

OAI221xp5_ASAP7_75t_R g44 ( 
.A1(n_42),
.A2(n_19),
.B1(n_25),
.B2(n_22),
.C(n_0),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_22),
.B1(n_19),
.B2(n_4),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

AOI322xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_44),
.A3(n_9),
.B1(n_8),
.B2(n_6),
.C1(n_21),
.C2(n_12),
.Y(n_47)
);


endmodule