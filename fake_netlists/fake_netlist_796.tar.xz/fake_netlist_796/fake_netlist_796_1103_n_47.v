module fake_netlist_796_1103_n_47 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_47);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_47;

wire n_37;
wire n_45;
wire n_44;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_43;
wire n_38;
wire n_28;
wire n_30;
wire n_41;
wire n_32;

INVx2_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

NOR2xp67_ASAP7_75t_L g27 ( 
.A(n_0),
.B(n_18),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_7),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_4),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

O2A1O1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_24),
.A2(n_25),
.B(n_29),
.C(n_27),
.Y(n_33)
);

NAND3xp33_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_19),
.C(n_18),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

OAI21xp5_ASAP7_75t_SL g36 ( 
.A1(n_34),
.A2(n_30),
.B(n_19),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

NAND2x1_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_30),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_31),
.B1(n_28),
.B2(n_33),
.Y(n_40)
);

OAI311xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_2),
.A3(n_1),
.B1(n_3),
.C1(n_5),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_R g42 ( 
.A(n_39),
.B(n_6),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_8),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_SL g45 ( 
.A1(n_44),
.A2(n_12),
.B1(n_11),
.B2(n_9),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_SL g46 ( 
.A1(n_43),
.A2(n_17),
.B1(n_16),
.B2(n_13),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_46),
.B1(n_23),
.B2(n_21),
.Y(n_47)
);


endmodule