module fake_netlist_796_1696_n_16 (n_1, n_0, n_5, n_3, n_2, n_4, n_16);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_16;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_6;
wire n_14;
wire n_9;
wire n_12;
wire n_13;
wire n_8;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_3),
.Y(n_6)
);

NAND3xp33_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_2),
.C(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

AOI221xp5_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_3),
.Y(n_9)
);

OA21x2_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND4xp25_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_7),
.C(n_9),
.D(n_4),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_10),
.C(n_7),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NOR2x1_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.Y(n_16)
);


endmodule