module fake_netlist_796_1061_n_19 (n_1, n_0, n_3, n_2, n_4, n_19);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_19;

wire n_6;
wire n_17;
wire n_12;
wire n_5;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_14;

INVxp33_ASAP7_75t_SL g5 ( 
.A(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

AOI21xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_6),
.B(n_0),
.Y(n_7)
);

OAI22x1_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_2),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_3),
.C(n_2),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_4),
.B1(n_3),
.B2(n_0),
.Y(n_14)
);

OAI21xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_4),
.B(n_1),
.Y(n_15)
);

NOR2x1p5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI21xp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_1),
.B(n_16),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_14),
.B(n_17),
.Y(n_19)
);


endmodule