module fake_netlist_796_481_n_30 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_30);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_30;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_27;
wire n_26;
wire n_24;
wire n_18;
wire n_23;
wire n_28;
wire n_19;
wire n_21;
wire n_22;

NOR2xp67_ASAP7_75t_L g17 ( 
.A(n_7),
.B(n_16),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_12),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

AND3x2_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_8),
.C(n_6),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_17),
.A2(n_16),
.B1(n_6),
.B2(n_4),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_20),
.B1(n_18),
.B2(n_19),
.C(n_4),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

NAND4xp25_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_21),
.C(n_22),
.D(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

AOI22x1_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_9),
.B1(n_5),
.B2(n_3),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_14),
.B1(n_13),
.B2(n_10),
.Y(n_30)
);


endmodule