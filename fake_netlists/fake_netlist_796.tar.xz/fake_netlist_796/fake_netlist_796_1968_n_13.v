module fake_netlist_796_1968_n_13 (n_1, n_2, n_3, n_0, n_13);

input n_1;
input n_2;
input n_3;
input n_0;

output n_13;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_9;
wire n_12;
wire n_4;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_0),
.Y(n_4)
);

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_3),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_1),
.B1(n_2),
.B2(n_5),
.Y(n_8)
);

OAI21xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B(n_1),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_10),
.C(n_7),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.C(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);


endmodule