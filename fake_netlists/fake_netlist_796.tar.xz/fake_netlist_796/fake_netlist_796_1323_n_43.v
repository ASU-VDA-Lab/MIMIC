module fake_netlist_796_1323_n_43 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_43);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_43;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_41;
wire n_32;
wire n_22;

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

INVx4_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_14),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_R g24 ( 
.A(n_6),
.B(n_18),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_12),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_1),
.B(n_7),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_L g29 ( 
.A1(n_23),
.A2(n_4),
.B(n_3),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_22),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_29),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_26),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_21),
.Y(n_36)
);

OAI211xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_27),
.B(n_24),
.C(n_5),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_38)
);

NOR3xp33_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_15),
.C(n_13),
.Y(n_39)
);

BUFx6f_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_39),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_41),
.B1(n_19),
.B2(n_17),
.Y(n_43)
);


endmodule