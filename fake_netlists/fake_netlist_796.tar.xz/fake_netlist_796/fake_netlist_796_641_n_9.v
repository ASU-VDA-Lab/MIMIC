module fake_netlist_796_641_n_9 (n_1, n_0, n_9);

input n_1;
input n_0;

output n_9;

wire n_7;
wire n_5;
wire n_6;
wire n_3;
wire n_2;
wire n_4;
wire n_8;

NAND2xp5_ASAP7_75t_SL g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

AND2x2_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

OAI21x1_ASAP7_75t_SL g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_5),
.B1(n_2),
.B2(n_1),
.Y(n_9)
);


endmodule