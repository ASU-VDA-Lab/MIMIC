module fake_netlist_796_1430_n_7 (n_1, n_0, n_3, n_2, n_4, n_7);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_7;

wire n_5;
wire n_6;

OAI221xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.C(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

NOR4xp25_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.C(n_1),
.D(n_6),
.Y(n_7)
);


endmodule