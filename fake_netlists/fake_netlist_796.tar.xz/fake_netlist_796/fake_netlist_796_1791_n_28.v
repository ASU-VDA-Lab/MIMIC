module fake_netlist_796_1791_n_28 (n_1, n_0, n_5, n_3, n_2, n_4, n_28);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_28;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

NAND2xp33_ASAP7_75t_SL g6 ( 
.A(n_2),
.B(n_5),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx4_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

BUFx8_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

INVx4_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_8),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

AOI32xp33_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_7),
.A3(n_9),
.B1(n_8),
.B2(n_12),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_9),
.C(n_14),
.Y(n_20)
);

AOI211xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_11),
.B(n_4),
.C(n_3),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_14),
.Y(n_22)
);

NAND4xp75_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_17),
.C(n_4),
.D(n_3),
.Y(n_23)
);

NOR2x1_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_3),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_4),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_5),
.B(n_23),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_5),
.C(n_26),
.Y(n_28)
);


endmodule