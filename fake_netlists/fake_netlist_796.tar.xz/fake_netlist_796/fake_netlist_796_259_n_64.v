module fake_netlist_796_259_n_64 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_64);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_64;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_52;
wire n_29;
wire n_36;
wire n_63;
wire n_62;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_42;
wire n_24;
wire n_33;
wire n_26;
wire n_49;
wire n_48;
wire n_43;
wire n_56;
wire n_38;
wire n_54;
wire n_61;
wire n_60;
wire n_57;
wire n_23;
wire n_28;
wire n_30;
wire n_59;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;
wire n_47;

INVx2_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

AND2x6_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_11),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_4),
.B(n_12),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_0),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_7),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

BUFx12f_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_6),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_5),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_13),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_32),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_30),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_21),
.B(n_13),
.Y(n_38)
);

AOI21x1_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_24),
.B(n_22),
.Y(n_39)
);

BUFx8_ASAP7_75t_SL g40 ( 
.A(n_35),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

OAI211xp5_ASAP7_75t_L g42 ( 
.A1(n_35),
.A2(n_21),
.B(n_28),
.C(n_29),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

AO21x2_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_41),
.B(n_25),
.Y(n_44)
);

AOI211x1_ASAP7_75t_L g45 ( 
.A1(n_39),
.A2(n_42),
.B(n_41),
.C(n_34),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_37),
.Y(n_46)
);

INVx2_ASAP7_75t_SL g47 ( 
.A(n_44),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_42),
.Y(n_48)
);

OAI21xp33_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_44),
.B(n_37),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

INVx3_ASAP7_75t_SL g52 ( 
.A(n_51),
.Y(n_52)
);

AOI322xp5_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_30),
.A3(n_33),
.B1(n_36),
.B2(n_26),
.C1(n_14),
.C2(n_16),
.Y(n_53)
);

NOR2xp33_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_36),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_55),
.Y(n_56)
);

OR5x1_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_16),
.C(n_14),
.D(n_19),
.E(n_20),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_R g58 ( 
.A(n_52),
.B(n_33),
.Y(n_58)
);

NOR2x1_ASAP7_75t_L g59 ( 
.A(n_54),
.B(n_33),
.Y(n_59)
);

OAI22x1_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_23),
.B1(n_2),
.B2(n_1),
.Y(n_60)
);

NOR3xp33_ASAP7_75t_SL g61 ( 
.A(n_56),
.B(n_58),
.C(n_59),
.Y(n_61)
);

NOR2x1_ASAP7_75t_L g62 ( 
.A(n_59),
.B(n_23),
.Y(n_62)
);

OAI22xp5_ASAP7_75t_SL g63 ( 
.A1(n_60),
.A2(n_23),
.B1(n_18),
.B2(n_15),
.Y(n_63)
);

NAND3xp33_ASAP7_75t_L g64 ( 
.A(n_63),
.B(n_61),
.C(n_62),
.Y(n_64)
);


endmodule