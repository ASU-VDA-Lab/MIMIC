module fake_netlist_796_1137_n_21 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_21);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_21;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_14;

INVx1_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_4),
.Y(n_8)
);

INVx6_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_2),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_1),
.Y(n_11)
);

NAND2x1p5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_1),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_SL g13 ( 
.A1(n_8),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.C(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_9),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_13),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_15),
.B(n_7),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_7),
.B1(n_9),
.B2(n_4),
.Y(n_18)
);

INVx3_ASAP7_75t_SL g19 ( 
.A(n_17),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_9),
.B1(n_3),
.B2(n_5),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_18),
.B1(n_9),
.B2(n_6),
.C(n_3),
.Y(n_21)
);


endmodule