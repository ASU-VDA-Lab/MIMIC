module fake_netlist_796_773_n_56 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_56);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_56;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_20;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_17;
wire n_50;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_18;
wire n_48;
wire n_43;
wire n_49;
wire n_38;
wire n_54;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;

INVx1_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_0),
.B(n_8),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_5),
.B(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_6),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_1),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_26),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_28),
.A2(n_27),
.B1(n_25),
.B2(n_20),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

INVxp67_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_28),
.A2(n_23),
.B1(n_18),
.B2(n_22),
.Y(n_36)
);

NAND3xp33_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_22),
.C(n_18),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_29),
.B(n_31),
.Y(n_38)
);

AOI211xp5_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_19),
.B(n_17),
.C(n_24),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_34),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_34),
.Y(n_41)
);

NAND2xp33_ASAP7_75t_SL g42 ( 
.A(n_38),
.B(n_24),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_SL g43 ( 
.A(n_42),
.B(n_5),
.C(n_2),
.Y(n_43)
);

CKINVDCx16_ASAP7_75t_R g44 ( 
.A(n_40),
.Y(n_44)
);

NAND2xp33_ASAP7_75t_SL g45 ( 
.A(n_41),
.B(n_32),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_44),
.B1(n_45),
.B2(n_42),
.C(n_31),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

BUFx6f_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

OAI221xp5_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.C(n_3),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_4),
.Y(n_51)
);

NOR2x1_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_7),
.Y(n_52)
);

NOR4xp25_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_12),
.C(n_11),
.D(n_10),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

CKINVDCx20_ASAP7_75t_R g55 ( 
.A(n_52),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_50),
.B1(n_54),
.B2(n_53),
.Y(n_56)
);


endmodule