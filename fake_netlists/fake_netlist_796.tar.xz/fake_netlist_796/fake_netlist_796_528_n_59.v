module fake_netlist_796_528_n_59 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_17, n_9, n_2, n_12, n_13, n_4, n_8, n_59);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_17;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_59;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_20;
wire n_52;
wire n_29;
wire n_36;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_18;
wire n_49;
wire n_48;
wire n_43;
wire n_56;
wire n_38;
wire n_54;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_19;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;
wire n_47;

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_8),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_SL g24 ( 
.A(n_4),
.B(n_6),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_2),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_12),
.B(n_10),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_0),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_23),
.B(n_2),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_23),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

CKINVDCx11_ASAP7_75t_R g34 ( 
.A(n_32),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_28),
.A2(n_19),
.B(n_27),
.Y(n_36)
);

NAND2x1p5_ASAP7_75t_L g37 ( 
.A(n_28),
.B(n_25),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_22),
.B1(n_21),
.B2(n_18),
.C(n_26),
.Y(n_38)
);

OAI33xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_33),
.A3(n_29),
.B1(n_22),
.B2(n_21),
.B3(n_18),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_36),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_28),
.Y(n_42)
);

NOR4xp25_ASAP7_75t_SL g43 ( 
.A(n_39),
.B(n_26),
.C(n_24),
.D(n_34),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_28),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

INVx2_ASAP7_75t_SL g48 ( 
.A(n_47),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_R g49 ( 
.A(n_45),
.B(n_24),
.Y(n_49)
);

AOI221xp5_ASAP7_75t_SL g50 ( 
.A1(n_46),
.A2(n_27),
.B1(n_33),
.B2(n_29),
.C(n_30),
.Y(n_50)
);

AOI31xp33_ASAP7_75t_L g51 ( 
.A1(n_44),
.A2(n_19),
.A3(n_30),
.B(n_25),
.Y(n_51)
);

AND2x4_ASAP7_75t_SL g52 ( 
.A(n_48),
.B(n_47),
.Y(n_52)
);

OAI322xp33_ASAP7_75t_L g53 ( 
.A1(n_48),
.A2(n_19),
.A3(n_25),
.B1(n_8),
.B2(n_10),
.C1(n_3),
.C2(n_5),
.Y(n_53)
);

OAI211xp5_ASAP7_75t_SL g54 ( 
.A1(n_51),
.A2(n_49),
.B(n_50),
.C(n_5),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_SL g55 ( 
.A(n_50),
.B(n_11),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_55),
.Y(n_56)
);

AOI22xp33_ASAP7_75t_SL g57 ( 
.A1(n_52),
.A2(n_17),
.B1(n_16),
.B2(n_11),
.Y(n_57)
);

AOI22xp33_ASAP7_75t_L g58 ( 
.A1(n_54),
.A2(n_17),
.B1(n_16),
.B2(n_7),
.Y(n_58)
);

AOI322xp5_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_9),
.A3(n_13),
.B1(n_14),
.B2(n_53),
.C1(n_57),
.C2(n_56),
.Y(n_59)
);


endmodule