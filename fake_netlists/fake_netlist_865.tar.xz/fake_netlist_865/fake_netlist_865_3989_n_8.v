module fake_netlist_865_3989_n_8 (n_4, n_2, n_5, n_3, n_0, n_1, n_8);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_8;

wire n_6;
wire n_7;

AND2x2_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_2),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_4),
.Y(n_7)
);

NOR4xp75_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_5),
.C(n_0),
.D(n_6),
.Y(n_8)
);


endmodule