module fake_netlist_865_620_n_14 (n_2, n_0, n_3, n_1, n_14);

input n_2;
input n_0;
input n_3;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

INVxp33_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

O2A1O1Ixp33_ASAP7_75t_SL g6 ( 
.A1(n_5),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_6)
);

NAND3x1_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.C(n_0),
.Y(n_7)
);

INVx8_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI21xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.B(n_4),
.Y(n_10)
);

OR5x1_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_3),
.C(n_2),
.D(n_1),
.E(n_6),
.Y(n_11)
);

NOR4xp75_ASAP7_75t_SL g12 ( 
.A(n_10),
.B(n_3),
.C(n_2),
.D(n_9),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_12),
.B(n_3),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B(n_12),
.Y(n_14)
);


endmodule