module fake_netlist_865_2989_n_49 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_49);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_49;

wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_43;
wire n_45;
wire n_46;

INVx2_ASAP7_75t_SL g22 ( 
.A(n_9),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_8),
.B(n_13),
.Y(n_26)
);

BUFx8_ASAP7_75t_L g27 ( 
.A(n_7),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_21),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_22),
.B(n_18),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_22),
.A2(n_19),
.B1(n_18),
.B2(n_0),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_25),
.B(n_19),
.Y(n_33)
);

CKINVDCx8_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_31),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_28),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

AOI211xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_26),
.B(n_23),
.C(n_30),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_27),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_29),
.C(n_24),
.Y(n_43)
);

AND4x2_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_3),
.C(n_2),
.D(n_1),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_24),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_29),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_4),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_47),
.B1(n_20),
.B2(n_15),
.Y(n_49)
);


endmodule