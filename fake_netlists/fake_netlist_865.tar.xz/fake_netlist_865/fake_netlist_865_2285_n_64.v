module fake_netlist_865_2285_n_64 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_64);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_64;

wire n_49;
wire n_48;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_34;
wire n_23;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

AND2x6_ASAP7_75t_L g22 ( 
.A(n_11),
.B(n_9),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_19),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_12),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_4),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

NAND2x1_ASAP7_75t_L g30 ( 
.A(n_20),
.B(n_1),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_10),
.B(n_14),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_5),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_19),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_25),
.B(n_16),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_29),
.B(n_18),
.Y(n_36)
);

INVx3_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_SL g39 ( 
.A1(n_33),
.A2(n_20),
.B1(n_18),
.B2(n_2),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_26),
.B(n_3),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_35),
.B(n_32),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_35),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_34),
.A2(n_22),
.B1(n_27),
.B2(n_23),
.Y(n_43)
);

OAI21x1_ASAP7_75t_L g44 ( 
.A1(n_36),
.A2(n_31),
.B(n_30),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_34),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_37),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_41),
.Y(n_48)
);

INVx1_ASAP7_75t_SL g49 ( 
.A(n_45),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_44),
.Y(n_50)
);

AOI32xp33_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_39),
.A3(n_46),
.B1(n_43),
.B2(n_47),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_L g53 ( 
.A1(n_48),
.A2(n_39),
.B1(n_38),
.B2(n_37),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

AOI211xp5_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_54),
.B(n_52),
.C(n_51),
.Y(n_55)
);

AOI21xp33_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_24),
.B(n_38),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_51),
.B(n_22),
.Y(n_57)
);

AOI21xp5_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_24),
.B(n_22),
.Y(n_58)
);

CKINVDCx5p33_ASAP7_75t_R g59 ( 
.A(n_56),
.Y(n_59)
);

NAND5xp2_ASAP7_75t_L g60 ( 
.A(n_55),
.B(n_24),
.C(n_8),
.D(n_6),
.E(n_7),
.Y(n_60)
);

OAI21xp5_ASAP7_75t_L g61 ( 
.A1(n_58),
.A2(n_15),
.B(n_13),
.Y(n_61)
);

CKINVDCx20_ASAP7_75t_R g62 ( 
.A(n_59),
.Y(n_62)
);

OR2x6_ASAP7_75t_L g63 ( 
.A(n_61),
.B(n_60),
.Y(n_63)
);

AOI21xp33_ASAP7_75t_L g64 ( 
.A1(n_63),
.A2(n_62),
.B(n_59),
.Y(n_64)
);


endmodule