module fake_netlist_865_2668_n_27 (n_4, n_2, n_3, n_0, n_1, n_27);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

BUFx10_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

BUFx4f_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_6),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_5),
.A2(n_2),
.B(n_0),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_5),
.B(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_9),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_10),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_11),
.B(n_12),
.Y(n_16)
);

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_13),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_8),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_14),
.C(n_15),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_15),
.Y(n_20)
);

OAI32xp33_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_15),
.A3(n_8),
.B1(n_0),
.B2(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NOR4xp25_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_16),
.C(n_17),
.D(n_2),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_17),
.Y(n_24)
);

AO22x2_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_3),
.B1(n_4),
.B2(n_22),
.Y(n_25)
);

AOI22x1_ASAP7_75t_SL g26 ( 
.A1(n_23),
.A2(n_3),
.B1(n_11),
.B2(n_7),
.Y(n_26)
);

AO21x2_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_24),
.B(n_26),
.Y(n_27)
);


endmodule