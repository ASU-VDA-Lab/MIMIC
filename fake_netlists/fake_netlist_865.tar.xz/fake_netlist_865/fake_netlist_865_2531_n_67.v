module fake_netlist_865_2531_n_67 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_67);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_67;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_44;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_18;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx2_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_5),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_1),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_14),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_3),
.B(n_6),
.Y(n_30)
);

A2O1A1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_24),
.A2(n_16),
.B(n_15),
.C(n_13),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

OR2x4_ASAP7_75t_L g33 ( 
.A(n_23),
.B(n_13),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

NAND2x1_ASAP7_75t_L g35 ( 
.A(n_29),
.B(n_16),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_23),
.B(n_2),
.Y(n_36)
);

BUFx4f_ASAP7_75t_L g37 ( 
.A(n_25),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_19),
.Y(n_38)
);

NOR2x1_ASAP7_75t_R g39 ( 
.A(n_23),
.B(n_8),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_21),
.B(n_22),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_32),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVxp67_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_38),
.B(n_21),
.Y(n_44)
);

OR2x6_ASAP7_75t_L g45 ( 
.A(n_35),
.B(n_22),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_36),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_33),
.A2(n_28),
.B1(n_27),
.B2(n_20),
.Y(n_47)
);

NAND2xp33_ASAP7_75t_SL g48 ( 
.A(n_46),
.B(n_34),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_41),
.Y(n_49)
);

NOR2xp67_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_18),
.Y(n_50)
);

INVxp67_ASAP7_75t_SL g51 ( 
.A(n_42),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_43),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

AOI21xp5_ASAP7_75t_L g54 ( 
.A1(n_48),
.A2(n_44),
.B(n_45),
.Y(n_54)
);

NOR2xp33_ASAP7_75t_SL g55 ( 
.A(n_51),
.B(n_31),
.Y(n_55)
);

NOR2xp33_ASAP7_75t_SL g56 ( 
.A(n_55),
.B(n_39),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

OR2x2_ASAP7_75t_L g58 ( 
.A(n_54),
.B(n_52),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_50),
.Y(n_59)
);

NOR3xp33_ASAP7_75t_L g60 ( 
.A(n_59),
.B(n_30),
.C(n_26),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_57),
.Y(n_61)
);

AOI22x1_ASAP7_75t_L g62 ( 
.A1(n_58),
.A2(n_25),
.B1(n_37),
.B2(n_12),
.Y(n_62)
);

CKINVDCx20_ASAP7_75t_R g63 ( 
.A(n_56),
.Y(n_63)
);

INVx2_ASAP7_75t_L g64 ( 
.A(n_61),
.Y(n_64)
);

OR3x2_ASAP7_75t_L g65 ( 
.A(n_63),
.B(n_60),
.C(n_62),
.Y(n_65)
);

NOR2x1p5_ASAP7_75t_L g66 ( 
.A(n_65),
.B(n_64),
.Y(n_66)
);

AOI22xp5_ASAP7_75t_L g67 ( 
.A1(n_66),
.A2(n_63),
.B1(n_56),
.B2(n_65),
.Y(n_67)
);


endmodule