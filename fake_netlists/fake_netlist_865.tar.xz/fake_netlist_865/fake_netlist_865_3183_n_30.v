module fake_netlist_865_3183_n_30 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_30);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_18;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_2),
.A2(n_9),
.B1(n_7),
.B2(n_3),
.Y(n_11)
);

AO21x2_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_8),
.B(n_10),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_15),
.B1(n_11),
.B2(n_14),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_4),
.B(n_1),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_4),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_12),
.Y(n_19)
);

AO31x2_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_12),
.A3(n_6),
.B(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_16),
.B1(n_19),
.B2(n_20),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_20),
.Y(n_23)
);

XOR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_24),
.Y(n_26)
);

CKINVDCx16_ASAP7_75t_R g27 ( 
.A(n_25),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_6),
.B1(n_24),
.B2(n_28),
.Y(n_30)
);


endmodule