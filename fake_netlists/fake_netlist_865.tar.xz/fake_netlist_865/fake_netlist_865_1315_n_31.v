module fake_netlist_865_1315_n_31 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_31);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_31;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

INVx3_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_1),
.A2(n_8),
.B1(n_7),
.B2(n_2),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_6),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_3),
.B(n_10),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_14),
.B(n_15),
.Y(n_22)
);

OR2x6_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_15),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

OAI211xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.B(n_13),
.C(n_21),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_0),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);


endmodule