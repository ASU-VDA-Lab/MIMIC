module fake_netlist_865_3684_n_30 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_30);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

AND2x6_ASAP7_75t_L g16 ( 
.A(n_5),
.B(n_4),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_0),
.Y(n_17)
);

OAI22xp33_ASAP7_75t_L g18 ( 
.A1(n_1),
.A2(n_4),
.B1(n_9),
.B2(n_11),
.Y(n_18)
);

OR2x6_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_1),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B(n_18),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_13),
.C(n_22),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_19),
.B1(n_16),
.B2(n_5),
.C(n_6),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_16),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_25),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_7),
.B1(n_6),
.B2(n_3),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_27),
.B1(n_7),
.B2(n_8),
.Y(n_30)
);


endmodule