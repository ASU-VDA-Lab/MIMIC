module fake_netlist_865_945_n_52 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_52);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_52;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_47;
wire n_17;
wire n_14;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx2_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_7),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_5),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_0),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_0),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_13),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_1),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_20),
.B(n_14),
.Y(n_30)
);

BUFx4f_ASAP7_75t_L g31 ( 
.A(n_16),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_13),
.Y(n_32)
);

BUFx4f_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_27),
.A2(n_30),
.B1(n_29),
.B2(n_26),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_33),
.B(n_32),
.Y(n_36)
);

AO32x1_ASAP7_75t_L g37 ( 
.A1(n_32),
.A2(n_21),
.A3(n_22),
.B1(n_19),
.B2(n_15),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_25),
.B(n_2),
.Y(n_38)
);

OAI221xp5_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_25),
.B1(n_31),
.B2(n_33),
.C(n_30),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_35),
.A2(n_26),
.B1(n_29),
.B2(n_31),
.Y(n_40)
);

INVx4_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_39),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_36),
.Y(n_43)
);

NAND3xp33_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_28),
.C(n_24),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_28),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_28),
.Y(n_47)
);

NAND4xp75_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_37),
.C(n_4),
.D(n_2),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_42),
.Y(n_50)
);

XNOR2xp5_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_50),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);


endmodule