module fake_netlist_865_2794_n_22 (n_4, n_2, n_3, n_0, n_1, n_22);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

INVx4_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

A2O1A1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_1),
.C(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

OAI33xp33_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_5),
.A3(n_6),
.B1(n_7),
.B2(n_8),
.B3(n_0),
.Y(n_15)
);

O2A1O1Ixp33_ASAP7_75t_SL g16 ( 
.A1(n_14),
.A2(n_9),
.B(n_5),
.C(n_7),
.Y(n_16)
);

XNOR2xp5_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_6),
.Y(n_17)
);

OAI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_8),
.B1(n_7),
.B2(n_13),
.Y(n_18)
);

AOI322xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_1),
.A3(n_0),
.B1(n_2),
.B2(n_4),
.C1(n_3),
.C2(n_15),
.Y(n_19)
);

NAND4xp25_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_16),
.C(n_2),
.D(n_1),
.Y(n_20)
);

INVxp67_ASAP7_75t_SL g21 ( 
.A(n_18),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_R g22 ( 
.A1(n_20),
.A2(n_3),
.B1(n_4),
.B2(n_21),
.Y(n_22)
);


endmodule