module fake_netlist_865_364_n_51 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_51);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_51;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

INVx2_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

XNOR2xp5_ASAP7_75t_L g27 ( 
.A(n_12),
.B(n_22),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_15),
.B(n_16),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_6),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_5),
.B(n_18),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_10),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_18),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_26),
.B(n_23),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_23),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_25),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_36),
.B1(n_35),
.B2(n_34),
.Y(n_38)
);

AOI33xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_33),
.A3(n_28),
.B1(n_27),
.B2(n_31),
.B3(n_25),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_30),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_30),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_41),
.Y(n_43)
);

OAI221xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_41),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_4),
.B1(n_3),
.B2(n_7),
.C(n_8),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_9),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AND2x4_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_13),
.Y(n_49)
);

CKINVDCx20_ASAP7_75t_R g50 ( 
.A(n_47),
.Y(n_50)
);

AOI22x1_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_50),
.B1(n_21),
.B2(n_17),
.Y(n_51)
);


endmodule