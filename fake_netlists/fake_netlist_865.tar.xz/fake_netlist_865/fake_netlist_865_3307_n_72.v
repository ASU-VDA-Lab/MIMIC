module fake_netlist_865_3307_n_72 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_72);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_72;

wire n_48;
wire n_49;
wire n_36;
wire n_47;
wire n_57;
wire n_70;
wire n_50;
wire n_41;
wire n_62;
wire n_44;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_60;
wire n_31;
wire n_32;
wire n_58;
wire n_68;
wire n_71;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_69;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_52;
wire n_35;
wire n_38;
wire n_61;
wire n_67;
wire n_45;
wire n_46;
wire n_51;

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_7),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_22),
.B(n_1),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_5),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_3),
.Y(n_33)
);

NAND2xp33_ASAP7_75t_L g34 ( 
.A(n_12),
.B(n_15),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_16),
.Y(n_35)
);

AND2x6_ASAP7_75t_L g36 ( 
.A(n_10),
.B(n_0),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_26),
.B(n_20),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_25),
.B(n_13),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_25),
.B(n_8),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_19),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_31),
.B(n_29),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_29),
.A2(n_6),
.B(n_4),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_32),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_32),
.B(n_19),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_41),
.B(n_43),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_SL g46 ( 
.A(n_40),
.B(n_30),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_44),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_42),
.A2(n_34),
.B(n_30),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

CKINVDCx20_ASAP7_75t_R g50 ( 
.A(n_46),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_45),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_37),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_50),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

INVxp67_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

NAND3xp33_ASAP7_75t_L g58 ( 
.A(n_57),
.B(n_34),
.C(n_54),
.Y(n_58)
);

AOI21xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_35),
.B(n_30),
.Y(n_59)
);

AOI222xp33_ASAP7_75t_L g60 ( 
.A1(n_55),
.A2(n_37),
.B1(n_35),
.B2(n_33),
.C1(n_39),
.C2(n_28),
.Y(n_60)
);

AOI221xp5_ASAP7_75t_L g61 ( 
.A1(n_56),
.A2(n_35),
.B1(n_38),
.B2(n_20),
.C(n_21),
.Y(n_61)
);

OAI211xp5_ASAP7_75t_SL g62 ( 
.A1(n_60),
.A2(n_23),
.B(n_22),
.C(n_21),
.Y(n_62)
);

NOR2xp67_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_23),
.Y(n_63)
);

OAI221xp5_ASAP7_75t_L g64 ( 
.A1(n_61),
.A2(n_36),
.B1(n_27),
.B2(n_9),
.C(n_11),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_59),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_65),
.Y(n_66)
);

NAND3x1_ASAP7_75t_L g67 ( 
.A(n_65),
.B(n_17),
.C(n_14),
.Y(n_67)
);

NAND2x1p5_ASAP7_75t_L g68 ( 
.A(n_63),
.B(n_36),
.Y(n_68)
);

AND2x2_ASAP7_75t_L g69 ( 
.A(n_66),
.B(n_18),
.Y(n_69)
);

OAI22xp5_ASAP7_75t_SL g70 ( 
.A1(n_68),
.A2(n_64),
.B1(n_62),
.B2(n_36),
.Y(n_70)
);

AOI21xp5_ASAP7_75t_L g71 ( 
.A1(n_70),
.A2(n_66),
.B(n_69),
.Y(n_71)
);

AO221x2_ASAP7_75t_L g72 ( 
.A1(n_71),
.A2(n_36),
.B1(n_67),
.B2(n_70),
.C(n_66),
.Y(n_72)
);


endmodule