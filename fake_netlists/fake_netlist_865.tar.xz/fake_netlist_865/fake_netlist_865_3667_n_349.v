module fake_netlist_865_3667_n_349 (n_48, n_49, n_25, n_20, n_15, n_13, n_2, n_36, n_47, n_17, n_14, n_22, n_41, n_4, n_7, n_23, n_34, n_40, n_28, n_39, n_44, n_9, n_31, n_32, n_26, n_24, n_43, n_37, n_19, n_42, n_3, n_33, n_12, n_0, n_29, n_6, n_30, n_18, n_10, n_16, n_21, n_5, n_35, n_38, n_11, n_27, n_1, n_45, n_8, n_46, n_349);

input n_48;
input n_49;
input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_36;
input n_47;
input n_17;
input n_14;
input n_22;
input n_41;
input n_4;
input n_7;
input n_23;
input n_34;
input n_40;
input n_28;
input n_39;
input n_44;
input n_9;
input n_31;
input n_32;
input n_26;
input n_24;
input n_43;
input n_37;
input n_19;
input n_42;
input n_3;
input n_33;
input n_12;
input n_0;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_35;
input n_38;
input n_11;
input n_27;
input n_1;
input n_45;
input n_8;
input n_46;

output n_349;

wire n_298;
wire n_114;
wire n_261;
wire n_316;
wire n_166;
wire n_240;
wire n_326;
wire n_154;
wire n_340;
wire n_153;
wire n_195;
wire n_210;
wire n_87;
wire n_95;
wire n_325;
wire n_232;
wire n_63;
wire n_110;
wire n_265;
wire n_61;
wire n_108;
wire n_163;
wire n_209;
wire n_196;
wire n_294;
wire n_202;
wire n_90;
wire n_76;
wire n_299;
wire n_272;
wire n_160;
wire n_338;
wire n_329;
wire n_99;
wire n_155;
wire n_314;
wire n_52;
wire n_229;
wire n_51;
wire n_119;
wire n_312;
wire n_152;
wire n_131;
wire n_133;
wire n_274;
wire n_323;
wire n_223;
wire n_279;
wire n_84;
wire n_303;
wire n_270;
wire n_188;
wire n_343;
wire n_205;
wire n_65;
wire n_247;
wire n_300;
wire n_309;
wire n_281;
wire n_129;
wire n_198;
wire n_201;
wire n_169;
wire n_180;
wire n_220;
wire n_267;
wire n_208;
wire n_82;
wire n_234;
wire n_165;
wire n_141;
wire n_305;
wire n_280;
wire n_331;
wire n_221;
wire n_311;
wire n_293;
wire n_156;
wire n_347;
wire n_126;
wire n_296;
wire n_78;
wire n_187;
wire n_96;
wire n_94;
wire n_162;
wire n_135;
wire n_324;
wire n_275;
wire n_107;
wire n_301;
wire n_288;
wire n_178;
wire n_121;
wire n_73;
wire n_211;
wire n_235;
wire n_246;
wire n_344;
wire n_175;
wire n_185;
wire n_161;
wire n_224;
wire n_179;
wire n_137;
wire n_57;
wire n_226;
wire n_116;
wire n_284;
wire n_128;
wire n_139;
wire n_115;
wire n_339;
wire n_144;
wire n_328;
wire n_283;
wire n_183;
wire n_345;
wire n_106;
wire n_149;
wire n_237;
wire n_159;
wire n_91;
wire n_233;
wire n_333;
wire n_204;
wire n_191;
wire n_317;
wire n_181;
wire n_60;
wire n_260;
wire n_291;
wire n_186;
wire n_218;
wire n_69;
wire n_212;
wire n_241;
wire n_256;
wire n_134;
wire n_254;
wire n_148;
wire n_245;
wire n_193;
wire n_132;
wire n_194;
wire n_219;
wire n_250;
wire n_81;
wire n_273;
wire n_80;
wire n_123;
wire n_290;
wire n_319;
wire n_167;
wire n_122;
wire n_289;
wire n_56;
wire n_59;
wire n_74;
wire n_341;
wire n_79;
wire n_177;
wire n_244;
wire n_158;
wire n_171;
wire n_259;
wire n_214;
wire n_127;
wire n_295;
wire n_213;
wire n_257;
wire n_72;
wire n_266;
wire n_320;
wire n_249;
wire n_120;
wire n_327;
wire n_145;
wire n_307;
wire n_200;
wire n_170;
wire n_77;
wire n_138;
wire n_217;
wire n_253;
wire n_238;
wire n_322;
wire n_332;
wire n_62;
wire n_117;
wire n_104;
wire n_168;
wire n_285;
wire n_310;
wire n_176;
wire n_271;
wire n_330;
wire n_101;
wire n_336;
wire n_242;
wire n_313;
wire n_157;
wire n_83;
wire n_348;
wire n_334;
wire n_346;
wire n_216;
wire n_150;
wire n_71;
wire n_92;
wire n_100;
wire n_124;
wire n_236;
wire n_206;
wire n_147;
wire n_268;
wire n_97;
wire n_182;
wire n_335;
wire n_130;
wire n_239;
wire n_173;
wire n_287;
wire n_318;
wire n_222;
wire n_277;
wire n_263;
wire n_269;
wire n_54;
wire n_304;
wire n_64;
wire n_278;
wire n_264;
wire n_292;
wire n_297;
wire n_184;
wire n_86;
wire n_192;
wire n_230;
wire n_118;
wire n_189;
wire n_125;
wire n_255;
wire n_151;
wire n_302;
wire n_258;
wire n_207;
wire n_103;
wire n_227;
wire n_215;
wire n_199;
wire n_190;
wire n_143;
wire n_251;
wire n_136;
wire n_102;
wire n_89;
wire n_262;
wire n_70;
wire n_172;
wire n_142;
wire n_337;
wire n_109;
wire n_53;
wire n_315;
wire n_58;
wire n_68;
wire n_146;
wire n_248;
wire n_105;
wire n_306;
wire n_321;
wire n_225;
wire n_85;
wire n_55;
wire n_164;
wire n_252;
wire n_75;
wire n_140;
wire n_342;
wire n_67;
wire n_66;
wire n_98;
wire n_286;
wire n_203;
wire n_50;
wire n_112;
wire n_228;
wire n_111;
wire n_93;
wire n_174;
wire n_197;
wire n_88;
wire n_243;
wire n_276;
wire n_113;
wire n_282;
wire n_231;
wire n_308;

INVx1_ASAP7_75t_L g50 ( 
.A(n_6),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_24),
.Y(n_52)
);

INVxp33_ASAP7_75t_SL g53 ( 
.A(n_27),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_17),
.Y(n_54)
);

CKINVDCx5p33_ASAP7_75t_R g55 ( 
.A(n_20),
.Y(n_55)
);

INVxp33_ASAP7_75t_L g56 ( 
.A(n_13),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_31),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_47),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_12),
.Y(n_59)
);

CKINVDCx16_ASAP7_75t_R g60 ( 
.A(n_49),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_22),
.B(n_18),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_1),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_41),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_45),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_44),
.Y(n_65)
);

CKINVDCx5p33_ASAP7_75t_R g66 ( 
.A(n_29),
.Y(n_66)
);

INVxp33_ASAP7_75t_L g67 ( 
.A(n_34),
.Y(n_67)
);

INVxp33_ASAP7_75t_SL g68 ( 
.A(n_1),
.Y(n_68)
);

INVxp33_ASAP7_75t_L g69 ( 
.A(n_19),
.Y(n_69)
);

CKINVDCx16_ASAP7_75t_R g70 ( 
.A(n_33),
.Y(n_70)
);

HB1xp67_ASAP7_75t_L g71 ( 
.A(n_40),
.Y(n_71)
);

HB1xp67_ASAP7_75t_L g72 ( 
.A(n_21),
.Y(n_72)
);

BUFx3_ASAP7_75t_L g73 ( 
.A(n_51),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_51),
.Y(n_74)
);

INVx3_ASAP7_75t_L g75 ( 
.A(n_52),
.Y(n_75)
);

CKINVDCx20_ASAP7_75t_R g76 ( 
.A(n_60),
.Y(n_76)
);

CKINVDCx5p33_ASAP7_75t_R g77 ( 
.A(n_60),
.Y(n_77)
);

NAND2xp5_ASAP7_75t_L g78 ( 
.A(n_71),
.B(n_0),
.Y(n_78)
);

AND2x4_ASAP7_75t_L g79 ( 
.A(n_71),
.B(n_0),
.Y(n_79)
);

BUFx10_ASAP7_75t_L g80 ( 
.A(n_72),
.Y(n_80)
);

INVx1_ASAP7_75t_SL g81 ( 
.A(n_70),
.Y(n_81)
);

CKINVDCx5p33_ASAP7_75t_R g82 ( 
.A(n_70),
.Y(n_82)
);

CKINVDCx20_ASAP7_75t_R g83 ( 
.A(n_72),
.Y(n_83)
);

CKINVDCx5p33_ASAP7_75t_R g84 ( 
.A(n_53),
.Y(n_84)
);

NAND2xp5_ASAP7_75t_L g85 ( 
.A(n_50),
.B(n_2),
.Y(n_85)
);

INVx2_ASAP7_75t_L g86 ( 
.A(n_52),
.Y(n_86)
);

CKINVDCx5p33_ASAP7_75t_R g87 ( 
.A(n_68),
.Y(n_87)
);

INVx2_ASAP7_75t_L g88 ( 
.A(n_54),
.Y(n_88)
);

BUFx3_ASAP7_75t_L g89 ( 
.A(n_73),
.Y(n_89)
);

BUFx6f_ASAP7_75t_L g90 ( 
.A(n_73),
.Y(n_90)
);

OR2x2_ASAP7_75t_L g91 ( 
.A(n_81),
.B(n_56),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_86),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_86),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_86),
.Y(n_94)
);

OAI221xp5_ASAP7_75t_L g95 ( 
.A1(n_85),
.A2(n_62),
.B1(n_59),
.B2(n_50),
.C(n_54),
.Y(n_95)
);

INVxp67_ASAP7_75t_L g96 ( 
.A(n_80),
.Y(n_96)
);

NOR2xp33_ASAP7_75t_L g97 ( 
.A(n_80),
.B(n_67),
.Y(n_97)
);

INVx1_ASAP7_75t_L g98 ( 
.A(n_86),
.Y(n_98)
);

AND2x2_ASAP7_75t_L g99 ( 
.A(n_80),
.B(n_69),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_88),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_88),
.Y(n_101)
);

INVxp67_ASAP7_75t_L g102 ( 
.A(n_81),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_88),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_88),
.Y(n_104)
);

BUFx3_ASAP7_75t_L g105 ( 
.A(n_73),
.Y(n_105)
);

CKINVDCx20_ASAP7_75t_R g106 ( 
.A(n_83),
.Y(n_106)
);

AOI22xp5_ASAP7_75t_L g107 ( 
.A1(n_95),
.A2(n_79),
.B1(n_74),
.B2(n_78),
.Y(n_107)
);

AOI21xp5_ASAP7_75t_L g108 ( 
.A1(n_89),
.A2(n_74),
.B(n_75),
.Y(n_108)
);

O2A1O1Ixp33_ASAP7_75t_L g109 ( 
.A1(n_95),
.A2(n_78),
.B(n_85),
.C(n_79),
.Y(n_109)
);

NAND2xp5_ASAP7_75t_L g110 ( 
.A(n_99),
.B(n_80),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_SL g111 ( 
.A(n_96),
.B(n_80),
.Y(n_111)
);

NAND2x1p5_ASAP7_75t_L g112 ( 
.A(n_92),
.B(n_79),
.Y(n_112)
);

OAI21xp5_ASAP7_75t_L g113 ( 
.A1(n_92),
.A2(n_75),
.B(n_79),
.Y(n_113)
);

O2A1O1Ixp33_ASAP7_75t_L g114 ( 
.A1(n_93),
.A2(n_79),
.B(n_75),
.C(n_59),
.Y(n_114)
);

NAND2x1p5_ASAP7_75t_L g115 ( 
.A(n_93),
.B(n_75),
.Y(n_115)
);

AND2x2_ASAP7_75t_L g116 ( 
.A(n_99),
.B(n_77),
.Y(n_116)
);

NAND2xp5_ASAP7_75t_L g117 ( 
.A(n_96),
.B(n_82),
.Y(n_117)
);

NAND2xp5_ASAP7_75t_SL g118 ( 
.A(n_97),
.B(n_84),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_98),
.Y(n_119)
);

NOR2xp33_ASAP7_75t_L g120 ( 
.A(n_102),
.B(n_87),
.Y(n_120)
);

NAND2xp5_ASAP7_75t_L g121 ( 
.A(n_89),
.B(n_73),
.Y(n_121)
);

NOR2xp33_ASAP7_75t_R g122 ( 
.A(n_106),
.B(n_76),
.Y(n_122)
);

A2O1A1Ixp33_ASAP7_75t_L g123 ( 
.A1(n_98),
.A2(n_75),
.B(n_58),
.C(n_57),
.Y(n_123)
);

AO21x2_ASAP7_75t_L g124 ( 
.A1(n_101),
.A2(n_61),
.B(n_57),
.Y(n_124)
);

INVx1_ASAP7_75t_L g125 ( 
.A(n_101),
.Y(n_125)
);

AND2x4_ASAP7_75t_L g126 ( 
.A(n_91),
.B(n_62),
.Y(n_126)
);

INVx3_ASAP7_75t_L g127 ( 
.A(n_94),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_89),
.B(n_83),
.Y(n_128)
);

BUFx2_ASAP7_75t_L g129 ( 
.A(n_91),
.Y(n_129)
);

AO21x2_ASAP7_75t_L g130 ( 
.A1(n_124),
.A2(n_63),
.B(n_58),
.Y(n_130)
);

AOI22xp33_ASAP7_75t_L g131 ( 
.A1(n_129),
.A2(n_104),
.B1(n_103),
.B2(n_94),
.Y(n_131)
);

NAND3xp33_ASAP7_75t_L g132 ( 
.A(n_109),
.B(n_90),
.C(n_103),
.Y(n_132)
);

BUFx5_ASAP7_75t_L g133 ( 
.A(n_119),
.Y(n_133)
);

INVx3_ASAP7_75t_L g134 ( 
.A(n_115),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_119),
.Y(n_135)
);

INVx1_ASAP7_75t_L g136 ( 
.A(n_125),
.Y(n_136)
);

OAI21x1_ASAP7_75t_L g137 ( 
.A1(n_113),
.A2(n_61),
.B(n_94),
.Y(n_137)
);

AND2x2_ASAP7_75t_L g138 ( 
.A(n_129),
.B(n_104),
.Y(n_138)
);

BUFx3_ASAP7_75t_L g139 ( 
.A(n_115),
.Y(n_139)
);

AO21x2_ASAP7_75t_L g140 ( 
.A1(n_124),
.A2(n_64),
.B(n_63),
.Y(n_140)
);

AND2x4_ASAP7_75t_L g141 ( 
.A(n_116),
.B(n_76),
.Y(n_141)
);

OAI21xp5_ASAP7_75t_L g142 ( 
.A1(n_114),
.A2(n_100),
.B(n_105),
.Y(n_142)
);

OR2x2_ASAP7_75t_L g143 ( 
.A(n_128),
.B(n_100),
.Y(n_143)
);

OAI21x1_ASAP7_75t_L g144 ( 
.A1(n_115),
.A2(n_112),
.B(n_108),
.Y(n_144)
);

OR2x6_ASAP7_75t_L g145 ( 
.A(n_112),
.B(n_105),
.Y(n_145)
);

NOR2xp33_ASAP7_75t_SL g146 ( 
.A(n_112),
.B(n_105),
.Y(n_146)
);

A2O1A1Ixp33_ASAP7_75t_L g147 ( 
.A1(n_107),
.A2(n_100),
.B(n_65),
.C(n_64),
.Y(n_147)
);

BUFx8_ASAP7_75t_L g148 ( 
.A(n_116),
.Y(n_148)
);

OAI21x1_ASAP7_75t_L g149 ( 
.A1(n_125),
.A2(n_65),
.B(n_90),
.Y(n_149)
);

INVx2_ASAP7_75t_SL g150 ( 
.A(n_127),
.Y(n_150)
);

AO21x2_ASAP7_75t_L g151 ( 
.A1(n_124),
.A2(n_90),
.B(n_23),
.Y(n_151)
);

NAND2x1p5_ASAP7_75t_L g152 ( 
.A(n_127),
.B(n_111),
.Y(n_152)
);

INVx8_ASAP7_75t_L g153 ( 
.A(n_145),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_138),
.Y(n_154)
);

O2A1O1Ixp33_ASAP7_75t_SL g155 ( 
.A1(n_135),
.A2(n_123),
.B(n_110),
.C(n_121),
.Y(n_155)
);

NAND3xp33_ASAP7_75t_SL g156 ( 
.A(n_147),
.B(n_107),
.C(n_122),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_138),
.Y(n_157)
);

AOI22xp33_ASAP7_75t_L g158 ( 
.A1(n_141),
.A2(n_126),
.B1(n_120),
.B2(n_118),
.Y(n_158)
);

HB1xp67_ASAP7_75t_L g159 ( 
.A(n_148),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_138),
.Y(n_160)
);

OR2x6_ASAP7_75t_L g161 ( 
.A(n_139),
.B(n_126),
.Y(n_161)
);

NAND2xp33_ASAP7_75t_R g162 ( 
.A(n_141),
.B(n_126),
.Y(n_162)
);

NAND2xp33_ASAP7_75t_R g163 ( 
.A(n_141),
.B(n_126),
.Y(n_163)
);

CKINVDCx5p33_ASAP7_75t_R g164 ( 
.A(n_148),
.Y(n_164)
);

CKINVDCx20_ASAP7_75t_R g165 ( 
.A(n_148),
.Y(n_165)
);

INVx6_ASAP7_75t_L g166 ( 
.A(n_148),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_L g167 ( 
.A(n_131),
.B(n_117),
.Y(n_167)
);

OAI22xp5_ASAP7_75t_L g168 ( 
.A1(n_139),
.A2(n_127),
.B1(n_90),
.B2(n_55),
.Y(n_168)
);

INVx1_ASAP7_75t_L g169 ( 
.A(n_143),
.Y(n_169)
);

NOR3xp33_ASAP7_75t_SL g170 ( 
.A(n_132),
.B(n_66),
.C(n_2),
.Y(n_170)
);

OR2x2_ASAP7_75t_L g171 ( 
.A(n_169),
.B(n_143),
.Y(n_171)
);

AO31x2_ASAP7_75t_L g172 ( 
.A1(n_154),
.A2(n_136),
.A3(n_135),
.B(n_140),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_157),
.Y(n_173)
);

AND2x2_ASAP7_75t_L g174 ( 
.A(n_160),
.B(n_133),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_161),
.Y(n_175)
);

INVx2_ASAP7_75t_L g176 ( 
.A(n_153),
.Y(n_176)
);

HB1xp67_ASAP7_75t_L g177 ( 
.A(n_161),
.Y(n_177)
);

OA21x2_ASAP7_75t_L g178 ( 
.A1(n_170),
.A2(n_149),
.B(n_137),
.Y(n_178)
);

O2A1O1Ixp5_ASAP7_75t_L g179 ( 
.A1(n_167),
.A2(n_132),
.B(n_142),
.C(n_136),
.Y(n_179)
);

NAND2xp5_ASAP7_75t_L g180 ( 
.A(n_158),
.B(n_133),
.Y(n_180)
);

INVx1_ASAP7_75t_L g181 ( 
.A(n_161),
.Y(n_181)
);

BUFx3_ASAP7_75t_L g182 ( 
.A(n_153),
.Y(n_182)
);

OR2x2_ASAP7_75t_L g183 ( 
.A(n_153),
.B(n_141),
.Y(n_183)
);

OR2x6_ASAP7_75t_SL g184 ( 
.A(n_164),
.B(n_146),
.Y(n_184)
);

AND2x4_ASAP7_75t_L g185 ( 
.A(n_176),
.B(n_182),
.Y(n_185)
);

INVx2_ASAP7_75t_L g186 ( 
.A(n_172),
.Y(n_186)
);

AOI22xp33_ASAP7_75t_L g187 ( 
.A1(n_171),
.A2(n_156),
.B1(n_166),
.B2(n_159),
.Y(n_187)
);

AND2x2_ASAP7_75t_L g188 ( 
.A(n_172),
.B(n_140),
.Y(n_188)
);

AND2x2_ASAP7_75t_L g189 ( 
.A(n_172),
.B(n_140),
.Y(n_189)
);

AND2x4_ASAP7_75t_SL g190 ( 
.A(n_176),
.B(n_134),
.Y(n_190)
);

INVx1_ASAP7_75t_L g191 ( 
.A(n_172),
.Y(n_191)
);

INVxp67_ASAP7_75t_L g192 ( 
.A(n_184),
.Y(n_192)
);

AOI22xp33_ASAP7_75t_L g193 ( 
.A1(n_171),
.A2(n_156),
.B1(n_166),
.B2(n_165),
.Y(n_193)
);

AND2x4_ASAP7_75t_L g194 ( 
.A(n_176),
.B(n_182),
.Y(n_194)
);

AND2x4_ASAP7_75t_L g195 ( 
.A(n_182),
.B(n_139),
.Y(n_195)
);

INVx3_ASAP7_75t_L g196 ( 
.A(n_174),
.Y(n_196)
);

BUFx3_ASAP7_75t_L g197 ( 
.A(n_184),
.Y(n_197)
);

AND2x2_ASAP7_75t_L g198 ( 
.A(n_172),
.B(n_140),
.Y(n_198)
);

AND2x4_ASAP7_75t_L g199 ( 
.A(n_175),
.B(n_134),
.Y(n_199)
);

AND2x2_ASAP7_75t_L g200 ( 
.A(n_196),
.B(n_172),
.Y(n_200)
);

OR2x2_ASAP7_75t_L g201 ( 
.A(n_191),
.B(n_186),
.Y(n_201)
);

OAI33xp33_ASAP7_75t_L g202 ( 
.A1(n_191),
.A2(n_173),
.A3(n_171),
.B1(n_175),
.B2(n_181),
.B3(n_183),
.Y(n_202)
);

INVx1_ASAP7_75t_L g203 ( 
.A(n_196),
.Y(n_203)
);

HB1xp67_ASAP7_75t_L g204 ( 
.A(n_194),
.Y(n_204)
);

AOI211x1_ASAP7_75t_SL g205 ( 
.A1(n_186),
.A2(n_180),
.B(n_168),
.C(n_162),
.Y(n_205)
);

INVx1_ASAP7_75t_L g206 ( 
.A(n_196),
.Y(n_206)
);

INVx1_ASAP7_75t_L g207 ( 
.A(n_191),
.Y(n_207)
);

HB1xp67_ASAP7_75t_L g208 ( 
.A(n_194),
.Y(n_208)
);

AND2x4_ASAP7_75t_L g209 ( 
.A(n_197),
.B(n_181),
.Y(n_209)
);

NAND2xp5_ASAP7_75t_L g210 ( 
.A(n_189),
.B(n_173),
.Y(n_210)
);

INVx1_ASAP7_75t_L g211 ( 
.A(n_196),
.Y(n_211)
);

INVx1_ASAP7_75t_L g212 ( 
.A(n_186),
.Y(n_212)
);

NOR2xp33_ASAP7_75t_L g213 ( 
.A(n_185),
.B(n_183),
.Y(n_213)
);

NAND4xp75_ASAP7_75t_L g214 ( 
.A(n_188),
.B(n_178),
.C(n_174),
.D(n_184),
.Y(n_214)
);

INVx1_ASAP7_75t_L g215 ( 
.A(n_186),
.Y(n_215)
);

INVx1_ASAP7_75t_L g216 ( 
.A(n_186),
.Y(n_216)
);

CKINVDCx16_ASAP7_75t_R g217 ( 
.A(n_197),
.Y(n_217)
);

AND2x2_ASAP7_75t_SL g218 ( 
.A(n_198),
.B(n_177),
.Y(n_218)
);

AOI32xp33_ASAP7_75t_L g219 ( 
.A1(n_213),
.A2(n_197),
.A3(n_193),
.B1(n_187),
.B2(n_188),
.Y(n_219)
);

OAI22xp5_ASAP7_75t_L g220 ( 
.A1(n_218),
.A2(n_193),
.B1(n_187),
.B2(n_192),
.Y(n_220)
);

INVx1_ASAP7_75t_L g221 ( 
.A(n_207),
.Y(n_221)
);

HB1xp67_ASAP7_75t_L g222 ( 
.A(n_212),
.Y(n_222)
);

INVx1_ASAP7_75t_L g223 ( 
.A(n_207),
.Y(n_223)
);

OAI22xp5_ASAP7_75t_L g224 ( 
.A1(n_218),
.A2(n_192),
.B1(n_166),
.B2(n_217),
.Y(n_224)
);

NOR2xp33_ASAP7_75t_L g225 ( 
.A(n_210),
.B(n_185),
.Y(n_225)
);

AOI21xp33_ASAP7_75t_L g226 ( 
.A1(n_209),
.A2(n_192),
.B(n_188),
.Y(n_226)
);

NOR4xp25_ASAP7_75t_L g227 ( 
.A(n_212),
.B(n_188),
.C(n_189),
.D(n_198),
.Y(n_227)
);

INVx1_ASAP7_75t_L g228 ( 
.A(n_201),
.Y(n_228)
);

AOI22xp5_ASAP7_75t_L g229 ( 
.A1(n_202),
.A2(n_163),
.B1(n_195),
.B2(n_185),
.Y(n_229)
);

INVx1_ASAP7_75t_L g230 ( 
.A(n_201),
.Y(n_230)
);

NAND2xp5_ASAP7_75t_L g231 ( 
.A(n_200),
.B(n_198),
.Y(n_231)
);

INVx1_ASAP7_75t_L g232 ( 
.A(n_215),
.Y(n_232)
);

INVx1_ASAP7_75t_L g233 ( 
.A(n_215),
.Y(n_233)
);

INVxp67_ASAP7_75t_SL g234 ( 
.A(n_216),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_216),
.Y(n_235)
);

INVx3_ASAP7_75t_L g236 ( 
.A(n_209),
.Y(n_236)
);

NAND2xp5_ASAP7_75t_L g237 ( 
.A(n_200),
.B(n_196),
.Y(n_237)
);

HB1xp67_ASAP7_75t_L g238 ( 
.A(n_204),
.Y(n_238)
);

OR2x2_ASAP7_75t_L g239 ( 
.A(n_208),
.B(n_196),
.Y(n_239)
);

OAI21xp5_ASAP7_75t_SL g240 ( 
.A1(n_205),
.A2(n_209),
.B(n_185),
.Y(n_240)
);

INVxp67_ASAP7_75t_SL g241 ( 
.A(n_203),
.Y(n_241)
);

INVx1_ASAP7_75t_L g242 ( 
.A(n_206),
.Y(n_242)
);

NAND2xp5_ASAP7_75t_L g243 ( 
.A(n_211),
.B(n_196),
.Y(n_243)
);

AND2x4_ASAP7_75t_L g244 ( 
.A(n_214),
.B(n_197),
.Y(n_244)
);

AOI21xp5_ASAP7_75t_L g245 ( 
.A1(n_214),
.A2(n_146),
.B(n_180),
.Y(n_245)
);

NAND2xp33_ASAP7_75t_L g246 ( 
.A(n_214),
.B(n_133),
.Y(n_246)
);

OAI22xp33_ASAP7_75t_SL g247 ( 
.A1(n_217),
.A2(n_197),
.B1(n_185),
.B2(n_194),
.Y(n_247)
);

AND4x1_ASAP7_75t_L g248 ( 
.A(n_227),
.B(n_5),
.C(n_4),
.D(n_3),
.Y(n_248)
);

AND2x2_ASAP7_75t_L g249 ( 
.A(n_231),
.B(n_199),
.Y(n_249)
);

INVx1_ASAP7_75t_L g250 ( 
.A(n_221),
.Y(n_250)
);

INVx2_ASAP7_75t_L g251 ( 
.A(n_232),
.Y(n_251)
);

OR2x2_ASAP7_75t_L g252 ( 
.A(n_228),
.B(n_172),
.Y(n_252)
);

NAND2xp5_ASAP7_75t_L g253 ( 
.A(n_230),
.B(n_199),
.Y(n_253)
);

INVx1_ASAP7_75t_L g254 ( 
.A(n_223),
.Y(n_254)
);

AND2x2_ASAP7_75t_L g255 ( 
.A(n_237),
.B(n_199),
.Y(n_255)
);

OAI31xp33_ASAP7_75t_SL g256 ( 
.A1(n_224),
.A2(n_194),
.A3(n_185),
.B(n_195),
.Y(n_256)
);

INVx1_ASAP7_75t_L g257 ( 
.A(n_233),
.Y(n_257)
);

INVx2_ASAP7_75t_L g258 ( 
.A(n_235),
.Y(n_258)
);

AND2x2_ASAP7_75t_L g259 ( 
.A(n_236),
.B(n_199),
.Y(n_259)
);

INVx1_ASAP7_75t_L g260 ( 
.A(n_222),
.Y(n_260)
);

INVx2_ASAP7_75t_SL g261 ( 
.A(n_222),
.Y(n_261)
);

INVxp67_ASAP7_75t_SL g262 ( 
.A(n_234),
.Y(n_262)
);

INVx1_ASAP7_75t_L g263 ( 
.A(n_234),
.Y(n_263)
);

NAND2xp5_ASAP7_75t_L g264 ( 
.A(n_225),
.B(n_199),
.Y(n_264)
);

NAND2xp5_ASAP7_75t_L g265 ( 
.A(n_242),
.B(n_199),
.Y(n_265)
);

NAND2xp5_ASAP7_75t_L g266 ( 
.A(n_219),
.B(n_199),
.Y(n_266)
);

AND2x2_ASAP7_75t_L g267 ( 
.A(n_236),
.B(n_151),
.Y(n_267)
);

INVx1_ASAP7_75t_L g268 ( 
.A(n_241),
.Y(n_268)
);

OR2x2_ASAP7_75t_L g269 ( 
.A(n_238),
.B(n_185),
.Y(n_269)
);

INVx1_ASAP7_75t_L g270 ( 
.A(n_241),
.Y(n_270)
);

NAND2xp5_ASAP7_75t_L g271 ( 
.A(n_238),
.B(n_243),
.Y(n_271)
);

AND2x2_ASAP7_75t_L g272 ( 
.A(n_244),
.B(n_151),
.Y(n_272)
);

NAND2xp5_ASAP7_75t_L g273 ( 
.A(n_239),
.B(n_194),
.Y(n_273)
);

NAND2xp5_ASAP7_75t_L g274 ( 
.A(n_220),
.B(n_194),
.Y(n_274)
);

NOR2xp33_ASAP7_75t_L g275 ( 
.A(n_240),
.B(n_3),
.Y(n_275)
);

NOR2xp33_ASAP7_75t_L g276 ( 
.A(n_247),
.B(n_4),
.Y(n_276)
);

INVx1_ASAP7_75t_L g277 ( 
.A(n_244),
.Y(n_277)
);

INVx1_ASAP7_75t_L g278 ( 
.A(n_229),
.Y(n_278)
);

INVxp67_ASAP7_75t_L g279 ( 
.A(n_226),
.Y(n_279)
);

INVx1_ASAP7_75t_L g280 ( 
.A(n_246),
.Y(n_280)
);

AND2x2_ASAP7_75t_L g281 ( 
.A(n_245),
.B(n_151),
.Y(n_281)
);

AOI22xp5_ASAP7_75t_L g282 ( 
.A1(n_275),
.A2(n_194),
.B1(n_195),
.B2(n_130),
.Y(n_282)
);

AOI221xp5_ASAP7_75t_L g283 ( 
.A1(n_276),
.A2(n_155),
.B1(n_130),
.B2(n_179),
.C(n_195),
.Y(n_283)
);

O2A1O1Ixp5_ASAP7_75t_L g284 ( 
.A1(n_262),
.A2(n_195),
.B(n_179),
.C(n_134),
.Y(n_284)
);

AOI22xp33_ASAP7_75t_L g285 ( 
.A1(n_266),
.A2(n_195),
.B1(n_130),
.B2(n_190),
.Y(n_285)
);

OAI22xp33_ASAP7_75t_L g286 ( 
.A1(n_274),
.A2(n_269),
.B1(n_280),
.B2(n_277),
.Y(n_286)
);

INVx1_ASAP7_75t_SL g287 ( 
.A(n_269),
.Y(n_287)
);

OAI211xp5_ASAP7_75t_SL g288 ( 
.A1(n_278),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_288)
);

NAND4xp25_ASAP7_75t_L g289 ( 
.A(n_256),
.B(n_195),
.C(n_142),
.D(n_7),
.Y(n_289)
);

AOI211xp5_ASAP7_75t_L g290 ( 
.A1(n_279),
.A2(n_137),
.B(n_149),
.C(n_8),
.Y(n_290)
);

OAI32xp33_ASAP7_75t_L g291 ( 
.A1(n_277),
.A2(n_134),
.A3(n_10),
.B1(n_8),
.B2(n_9),
.Y(n_291)
);

AOI22xp5_ASAP7_75t_L g292 ( 
.A1(n_259),
.A2(n_249),
.B1(n_255),
.B2(n_253),
.Y(n_292)
);

AOI21xp33_ASAP7_75t_SL g293 ( 
.A1(n_261),
.A2(n_10),
.B(n_9),
.Y(n_293)
);

NOR2xp33_ASAP7_75t_R g294 ( 
.A(n_259),
.B(n_11),
.Y(n_294)
);

AND2x2_ASAP7_75t_L g295 ( 
.A(n_249),
.B(n_190),
.Y(n_295)
);

NAND4xp75_ASAP7_75t_L g296 ( 
.A(n_272),
.B(n_178),
.C(n_12),
.D(n_11),
.Y(n_296)
);

XNOR2xp5_ASAP7_75t_L g297 ( 
.A(n_255),
.B(n_13),
.Y(n_297)
);

AO21x1_ASAP7_75t_L g298 ( 
.A1(n_263),
.A2(n_190),
.B(n_149),
.Y(n_298)
);

NAND2xp5_ASAP7_75t_L g299 ( 
.A(n_271),
.B(n_178),
.Y(n_299)
);

A2O1A1Ixp33_ASAP7_75t_L g300 ( 
.A1(n_261),
.A2(n_190),
.B(n_137),
.C(n_144),
.Y(n_300)
);

AND2x2_ASAP7_75t_L g301 ( 
.A(n_273),
.B(n_190),
.Y(n_301)
);

AOI21xp5_ASAP7_75t_L g302 ( 
.A1(n_263),
.A2(n_178),
.B(n_151),
.Y(n_302)
);

AOI321xp33_ASAP7_75t_L g303 ( 
.A1(n_264),
.A2(n_16),
.A3(n_15),
.B1(n_14),
.B2(n_178),
.C(n_25),
.Y(n_303)
);

AOI222xp33_ASAP7_75t_L g304 ( 
.A1(n_265),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.C1(n_150),
.C2(n_144),
.Y(n_304)
);

AOI221x1_ASAP7_75t_L g305 ( 
.A1(n_260),
.A2(n_90),
.B1(n_30),
.B2(n_26),
.C(n_28),
.Y(n_305)
);

AOI22xp33_ASAP7_75t_L g306 ( 
.A1(n_272),
.A2(n_145),
.B1(n_152),
.B2(n_150),
.Y(n_306)
);

AOI21xp5_ASAP7_75t_L g307 ( 
.A1(n_268),
.A2(n_145),
.B(n_144),
.Y(n_307)
);

OAI221xp5_ASAP7_75t_L g308 ( 
.A1(n_248),
.A2(n_152),
.B1(n_145),
.B2(n_150),
.C(n_90),
.Y(n_308)
);

AND2x2_ASAP7_75t_L g309 ( 
.A(n_287),
.B(n_292),
.Y(n_309)
);

A2O1A1Ixp33_ASAP7_75t_L g310 ( 
.A1(n_289),
.A2(n_270),
.B(n_268),
.C(n_260),
.Y(n_310)
);

O2A1O1Ixp33_ASAP7_75t_L g311 ( 
.A1(n_293),
.A2(n_252),
.B(n_270),
.C(n_257),
.Y(n_311)
);

AOI22xp5_ASAP7_75t_L g312 ( 
.A1(n_282),
.A2(n_254),
.B1(n_250),
.B2(n_257),
.Y(n_312)
);

AOI211x1_ASAP7_75t_L g313 ( 
.A1(n_286),
.A2(n_254),
.B(n_250),
.C(n_281),
.Y(n_313)
);

AOI22xp33_ASAP7_75t_L g314 ( 
.A1(n_283),
.A2(n_252),
.B1(n_267),
.B2(n_281),
.Y(n_314)
);

INVx1_ASAP7_75t_L g315 ( 
.A(n_299),
.Y(n_315)
);

NOR2xp33_ASAP7_75t_SL g316 ( 
.A(n_308),
.B(n_251),
.Y(n_316)
);

AOI222xp33_ASAP7_75t_L g317 ( 
.A1(n_297),
.A2(n_267),
.B1(n_258),
.B2(n_251),
.C1(n_35),
.C2(n_32),
.Y(n_317)
);

OAI221xp5_ASAP7_75t_L g318 ( 
.A1(n_303),
.A2(n_258),
.B1(n_152),
.B2(n_145),
.C(n_36),
.Y(n_318)
);

OAI321xp33_ASAP7_75t_L g319 ( 
.A1(n_286),
.A2(n_145),
.A3(n_152),
.B1(n_39),
.B2(n_38),
.C(n_37),
.Y(n_319)
);

NAND2x1p5_ASAP7_75t_L g320 ( 
.A(n_307),
.B(n_133),
.Y(n_320)
);

AOI22xp33_ASAP7_75t_L g321 ( 
.A1(n_304),
.A2(n_133),
.B1(n_43),
.B2(n_42),
.Y(n_321)
);

AOI322xp5_ASAP7_75t_L g322 ( 
.A1(n_285),
.A2(n_46),
.A3(n_133),
.B1(n_295),
.B2(n_301),
.C1(n_306),
.C2(n_294),
.Y(n_322)
);

AOI21xp5_ASAP7_75t_L g323 ( 
.A1(n_298),
.A2(n_133),
.B(n_284),
.Y(n_323)
);

NAND4xp75_ASAP7_75t_L g324 ( 
.A(n_305),
.B(n_133),
.C(n_284),
.D(n_302),
.Y(n_324)
);

NAND2xp5_ASAP7_75t_SL g325 ( 
.A(n_300),
.B(n_133),
.Y(n_325)
);

NOR3xp33_ASAP7_75t_L g326 ( 
.A(n_288),
.B(n_133),
.C(n_291),
.Y(n_326)
);

HB1xp67_ASAP7_75t_L g327 ( 
.A(n_315),
.Y(n_327)
);

AND2x4_ASAP7_75t_L g328 ( 
.A(n_309),
.B(n_296),
.Y(n_328)
);

CKINVDCx20_ASAP7_75t_R g329 ( 
.A(n_312),
.Y(n_329)
);

INVx1_ASAP7_75t_L g330 ( 
.A(n_311),
.Y(n_330)
);

NAND2xp33_ASAP7_75t_R g331 ( 
.A(n_323),
.B(n_290),
.Y(n_331)
);

NOR2xp33_ASAP7_75t_L g332 ( 
.A(n_316),
.B(n_288),
.Y(n_332)
);

O2A1O1Ixp33_ASAP7_75t_L g333 ( 
.A1(n_310),
.A2(n_318),
.B(n_326),
.C(n_317),
.Y(n_333)
);

CKINVDCx20_ASAP7_75t_R g334 ( 
.A(n_325),
.Y(n_334)
);

HB1xp67_ASAP7_75t_L g335 ( 
.A(n_320),
.Y(n_335)
);

HB1xp67_ASAP7_75t_L g336 ( 
.A(n_320),
.Y(n_336)
);

INVxp67_ASAP7_75t_L g337 ( 
.A(n_328),
.Y(n_337)
);

XNOR2xp5_ASAP7_75t_L g338 ( 
.A(n_329),
.B(n_313),
.Y(n_338)
);

INVx1_ASAP7_75t_L g339 ( 
.A(n_327),
.Y(n_339)
);

NAND2xp5_ASAP7_75t_L g340 ( 
.A(n_330),
.B(n_328),
.Y(n_340)
);

AND3x4_ASAP7_75t_L g341 ( 
.A(n_333),
.B(n_322),
.C(n_319),
.Y(n_341)
);

NOR4xp25_ASAP7_75t_L g342 ( 
.A(n_332),
.B(n_321),
.C(n_314),
.D(n_324),
.Y(n_342)
);

INVx1_ASAP7_75t_SL g343 ( 
.A(n_340),
.Y(n_343)
);

INVxp67_ASAP7_75t_L g344 ( 
.A(n_337),
.Y(n_344)
);

INVx2_ASAP7_75t_SL g345 ( 
.A(n_339),
.Y(n_345)
);

INVx1_ASAP7_75t_L g346 ( 
.A(n_344),
.Y(n_346)
);

OAI221xp5_ASAP7_75t_L g347 ( 
.A1(n_343),
.A2(n_338),
.B1(n_342),
.B2(n_332),
.C(n_331),
.Y(n_347)
);

AOI22xp5_ASAP7_75t_L g348 ( 
.A1(n_347),
.A2(n_341),
.B1(n_345),
.B2(n_334),
.Y(n_348)
);

AOI221xp5_ASAP7_75t_L g349 ( 
.A1(n_348),
.A2(n_346),
.B1(n_342),
.B2(n_335),
.C(n_336),
.Y(n_349)
);


endmodule