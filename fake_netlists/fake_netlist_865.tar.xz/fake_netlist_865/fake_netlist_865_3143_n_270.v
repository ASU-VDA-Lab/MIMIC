module fake_netlist_865_3143_n_270 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_28, n_9, n_31, n_32, n_26, n_24, n_19, n_3, n_33, n_12, n_0, n_29, n_6, n_30, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_270);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_28;
input n_9;
input n_31;
input n_32;
input n_26;
input n_24;
input n_19;
input n_3;
input n_33;
input n_12;
input n_0;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_270;

wire n_49;
wire n_132;
wire n_97;
wire n_194;
wire n_219;
wire n_221;
wire n_250;
wire n_81;
wire n_182;
wire n_114;
wire n_261;
wire n_130;
wire n_80;
wire n_239;
wire n_166;
wire n_123;
wire n_173;
wire n_240;
wire n_156;
wire n_222;
wire n_126;
wire n_154;
wire n_251;
wire n_78;
wire n_263;
wire n_269;
wire n_195;
wire n_153;
wire n_187;
wire n_210;
wire n_87;
wire n_167;
wire n_122;
wire n_54;
wire n_96;
wire n_95;
wire n_56;
wire n_232;
wire n_59;
wire n_63;
wire n_94;
wire n_74;
wire n_64;
wire n_79;
wire n_177;
wire n_110;
wire n_265;
wire n_61;
wire n_184;
wire n_86;
wire n_264;
wire n_43;
wire n_45;
wire n_108;
wire n_192;
wire n_244;
wire n_48;
wire n_163;
wire n_162;
wire n_209;
wire n_196;
wire n_230;
wire n_158;
wire n_135;
wire n_171;
wire n_47;
wire n_118;
wire n_259;
wire n_214;
wire n_127;
wire n_202;
wire n_90;
wire n_213;
wire n_199;
wire n_76;
wire n_257;
wire n_189;
wire n_160;
wire n_107;
wire n_125;
wire n_255;
wire n_99;
wire n_151;
wire n_178;
wire n_258;
wire n_121;
wire n_72;
wire n_266;
wire n_73;
wire n_211;
wire n_235;
wire n_37;
wire n_207;
wire n_42;
wire n_249;
wire n_120;
wire n_103;
wire n_155;
wire n_145;
wire n_227;
wire n_200;
wire n_246;
wire n_175;
wire n_185;
wire n_52;
wire n_215;
wire n_143;
wire n_170;
wire n_77;
wire n_161;
wire n_190;
wire n_224;
wire n_229;
wire n_138;
wire n_57;
wire n_51;
wire n_137;
wire n_116;
wire n_136;
wire n_179;
wire n_102;
wire n_226;
wire n_119;
wire n_217;
wire n_89;
wire n_253;
wire n_262;
wire n_152;
wire n_70;
wire n_172;
wire n_238;
wire n_131;
wire n_128;
wire n_133;
wire n_139;
wire n_142;
wire n_115;
wire n_109;
wire n_41;
wire n_62;
wire n_223;
wire n_34;
wire n_44;
wire n_144;
wire n_40;
wire n_117;
wire n_53;
wire n_84;
wire n_58;
wire n_68;
wire n_183;
wire n_146;
wire n_248;
wire n_104;
wire n_105;
wire n_168;
wire n_225;
wire n_106;
wire n_149;
wire n_188;
wire n_85;
wire n_237;
wire n_205;
wire n_55;
wire n_164;
wire n_65;
wire n_159;
wire n_247;
wire n_252;
wire n_75;
wire n_140;
wire n_176;
wire n_67;
wire n_66;
wire n_101;
wire n_98;
wire n_91;
wire n_233;
wire n_36;
wire n_242;
wire n_204;
wire n_203;
wire n_50;
wire n_191;
wire n_112;
wire n_129;
wire n_181;
wire n_157;
wire n_198;
wire n_201;
wire n_83;
wire n_228;
wire n_60;
wire n_39;
wire n_111;
wire n_169;
wire n_180;
wire n_93;
wire n_174;
wire n_216;
wire n_150;
wire n_220;
wire n_260;
wire n_71;
wire n_267;
wire n_208;
wire n_92;
wire n_82;
wire n_186;
wire n_100;
wire n_218;
wire n_69;
wire n_193;
wire n_234;
wire n_212;
wire n_165;
wire n_88;
wire n_124;
wire n_197;
wire n_243;
wire n_113;
wire n_236;
wire n_206;
wire n_256;
wire n_241;
wire n_147;
wire n_231;
wire n_268;
wire n_141;
wire n_134;
wire n_35;
wire n_148;
wire n_38;
wire n_254;
wire n_245;
wire n_46;

INVx1_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

INVxp67_ASAP7_75t_SL g35 ( 
.A(n_11),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_25),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_26),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_23),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_8),
.Y(n_39)
);

CKINVDCx16_ASAP7_75t_R g40 ( 
.A(n_5),
.Y(n_40)
);

INVxp67_ASAP7_75t_L g41 ( 
.A(n_24),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_14),
.Y(n_42)
);

BUFx6f_ASAP7_75t_L g43 ( 
.A(n_16),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_16),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_32),
.Y(n_45)
);

CKINVDCx14_ASAP7_75t_R g46 ( 
.A(n_11),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_46),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_38),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_38),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_34),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_39),
.B(n_0),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_40),
.Y(n_52)
);

INVx3_ASAP7_75t_L g53 ( 
.A(n_43),
.Y(n_53)
);

CKINVDCx5p33_ASAP7_75t_R g54 ( 
.A(n_41),
.Y(n_54)
);

OAI22xp5_ASAP7_75t_L g55 ( 
.A1(n_48),
.A2(n_44),
.B1(n_42),
.B2(n_39),
.Y(n_55)
);

INVx3_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

A2O1A1Ixp33_ASAP7_75t_L g57 ( 
.A1(n_50),
.A2(n_37),
.B(n_36),
.C(n_34),
.Y(n_57)
);

NAND2x1p5_ASAP7_75t_L g58 ( 
.A(n_50),
.B(n_36),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_53),
.Y(n_59)
);

BUFx6f_ASAP7_75t_L g60 ( 
.A(n_53),
.Y(n_60)
);

AO22x2_ASAP7_75t_L g61 ( 
.A1(n_51),
.A2(n_45),
.B1(n_37),
.B2(n_42),
.Y(n_61)
);

AOI22xp5_ASAP7_75t_L g62 ( 
.A1(n_48),
.A2(n_35),
.B1(n_44),
.B2(n_43),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_53),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_49),
.B(n_45),
.Y(n_64)
);

AND2x4_ASAP7_75t_L g65 ( 
.A(n_51),
.B(n_43),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_SL g66 ( 
.A(n_54),
.B(n_43),
.Y(n_66)
);

INVx2_ASAP7_75t_L g67 ( 
.A(n_53),
.Y(n_67)
);

AOI21xp5_ASAP7_75t_L g68 ( 
.A1(n_66),
.A2(n_54),
.B(n_47),
.Y(n_68)
);

AOI221xp5_ASAP7_75t_L g69 ( 
.A1(n_55),
.A2(n_52),
.B1(n_47),
.B2(n_43),
.C(n_0),
.Y(n_69)
);

OAI22xp5_ASAP7_75t_SL g70 ( 
.A1(n_64),
.A2(n_52),
.B1(n_2),
.B2(n_1),
.Y(n_70)
);

OAI21xp33_ASAP7_75t_SL g71 ( 
.A1(n_62),
.A2(n_2),
.B(n_1),
.Y(n_71)
);

NAND2xp5_ASAP7_75t_L g72 ( 
.A(n_65),
.B(n_3),
.Y(n_72)
);

AOI21xp5_ASAP7_75t_L g73 ( 
.A1(n_58),
.A2(n_18),
.B(n_17),
.Y(n_73)
);

INVxp67_ASAP7_75t_L g74 ( 
.A(n_61),
.Y(n_74)
);

NOR2xp33_ASAP7_75t_L g75 ( 
.A(n_65),
.B(n_19),
.Y(n_75)
);

AND2x2_ASAP7_75t_L g76 ( 
.A(n_61),
.B(n_3),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_58),
.Y(n_77)
);

OAI21x1_ASAP7_75t_L g78 ( 
.A1(n_58),
.A2(n_21),
.B(n_20),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_61),
.Y(n_79)
);

NOR2xp33_ASAP7_75t_L g80 ( 
.A(n_65),
.B(n_22),
.Y(n_80)
);

AOI21xp5_ASAP7_75t_L g81 ( 
.A1(n_65),
.A2(n_28),
.B(n_27),
.Y(n_81)
);

INVx3_ASAP7_75t_L g82 ( 
.A(n_61),
.Y(n_82)
);

INVx2_ASAP7_75t_L g83 ( 
.A(n_82),
.Y(n_83)
);

AO32x2_ASAP7_75t_L g84 ( 
.A1(n_70),
.A2(n_57),
.A3(n_62),
.B1(n_30),
.B2(n_31),
.Y(n_84)
);

AND2x2_ASAP7_75t_L g85 ( 
.A(n_82),
.B(n_77),
.Y(n_85)
);

NAND2xp5_ASAP7_75t_L g86 ( 
.A(n_77),
.B(n_56),
.Y(n_86)
);

AND2x4_ASAP7_75t_L g87 ( 
.A(n_82),
.B(n_4),
.Y(n_87)
);

OAI21x1_ASAP7_75t_L g88 ( 
.A1(n_78),
.A2(n_56),
.B(n_59),
.Y(n_88)
);

OAI21x1_ASAP7_75t_L g89 ( 
.A1(n_78),
.A2(n_56),
.B(n_59),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_82),
.Y(n_90)
);

INVx2_ASAP7_75t_L g91 ( 
.A(n_79),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_79),
.Y(n_92)
);

AND2x2_ASAP7_75t_L g93 ( 
.A(n_76),
.B(n_4),
.Y(n_93)
);

AO21x2_ASAP7_75t_L g94 ( 
.A1(n_81),
.A2(n_63),
.B(n_67),
.Y(n_94)
);

AO31x2_ASAP7_75t_L g95 ( 
.A1(n_91),
.A2(n_80),
.A3(n_75),
.B(n_73),
.Y(n_95)
);

AND2x4_ASAP7_75t_L g96 ( 
.A(n_85),
.B(n_74),
.Y(n_96)
);

BUFx12f_ASAP7_75t_L g97 ( 
.A(n_87),
.Y(n_97)
);

AND2x2_ASAP7_75t_SL g98 ( 
.A(n_93),
.B(n_87),
.Y(n_98)
);

OR2x2_ASAP7_75t_L g99 ( 
.A(n_93),
.B(n_76),
.Y(n_99)
);

NAND2xp5_ASAP7_75t_L g100 ( 
.A(n_93),
.B(n_69),
.Y(n_100)
);

NOR2xp33_ASAP7_75t_L g101 ( 
.A(n_85),
.B(n_68),
.Y(n_101)
);

BUFx8_ASAP7_75t_L g102 ( 
.A(n_93),
.Y(n_102)
);

INVx2_ASAP7_75t_L g103 ( 
.A(n_98),
.Y(n_103)
);

INVxp67_ASAP7_75t_SL g104 ( 
.A(n_102),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_98),
.Y(n_105)
);

OA21x2_ASAP7_75t_L g106 ( 
.A1(n_101),
.A2(n_89),
.B(n_88),
.Y(n_106)
);

HB1xp67_ASAP7_75t_L g107 ( 
.A(n_98),
.Y(n_107)
);

OAI21xp33_ASAP7_75t_SL g108 ( 
.A1(n_99),
.A2(n_89),
.B(n_88),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_96),
.Y(n_109)
);

NAND2xp5_ASAP7_75t_L g110 ( 
.A(n_100),
.B(n_92),
.Y(n_110)
);

BUFx2_ASAP7_75t_L g111 ( 
.A(n_97),
.Y(n_111)
);

OR2x2_ASAP7_75t_L g112 ( 
.A(n_107),
.B(n_99),
.Y(n_112)
);

AND2x2_ASAP7_75t_L g113 ( 
.A(n_107),
.B(n_91),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_110),
.Y(n_114)
);

AND2x4_ASAP7_75t_L g115 ( 
.A(n_105),
.B(n_103),
.Y(n_115)
);

AND2x2_ASAP7_75t_L g116 ( 
.A(n_103),
.B(n_91),
.Y(n_116)
);

AND2x4_ASAP7_75t_L g117 ( 
.A(n_105),
.B(n_91),
.Y(n_117)
);

NOR2xp33_ASAP7_75t_L g118 ( 
.A(n_109),
.B(n_102),
.Y(n_118)
);

HB1xp67_ASAP7_75t_L g119 ( 
.A(n_108),
.Y(n_119)
);

AND2x2_ASAP7_75t_L g120 ( 
.A(n_103),
.B(n_92),
.Y(n_120)
);

NAND2xp5_ASAP7_75t_L g121 ( 
.A(n_110),
.B(n_92),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_109),
.Y(n_122)
);

HB1xp67_ASAP7_75t_L g123 ( 
.A(n_108),
.Y(n_123)
);

CKINVDCx5p33_ASAP7_75t_R g124 ( 
.A(n_104),
.Y(n_124)
);

AND2x2_ASAP7_75t_L g125 ( 
.A(n_106),
.B(n_87),
.Y(n_125)
);

NOR3xp33_ASAP7_75t_L g126 ( 
.A(n_124),
.B(n_70),
.C(n_71),
.Y(n_126)
);

OR2x2_ASAP7_75t_L g127 ( 
.A(n_112),
.B(n_104),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_114),
.B(n_102),
.Y(n_128)
);

INVx1_ASAP7_75t_L g129 ( 
.A(n_122),
.Y(n_129)
);

HB1xp67_ASAP7_75t_L g130 ( 
.A(n_124),
.Y(n_130)
);

BUFx2_ASAP7_75t_L g131 ( 
.A(n_125),
.Y(n_131)
);

NAND2xp5_ASAP7_75t_L g132 ( 
.A(n_114),
.B(n_71),
.Y(n_132)
);

INVx1_ASAP7_75t_SL g133 ( 
.A(n_113),
.Y(n_133)
);

INVx2_ASAP7_75t_L g134 ( 
.A(n_125),
.Y(n_134)
);

OR2x2_ASAP7_75t_L g135 ( 
.A(n_112),
.B(n_106),
.Y(n_135)
);

INVx2_ASAP7_75t_L g136 ( 
.A(n_125),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_122),
.Y(n_137)
);

HB1xp67_ASAP7_75t_L g138 ( 
.A(n_113),
.Y(n_138)
);

NAND2xp5_ASAP7_75t_L g139 ( 
.A(n_112),
.B(n_96),
.Y(n_139)
);

INVx1_ASAP7_75t_L g140 ( 
.A(n_115),
.Y(n_140)
);

HB1xp67_ASAP7_75t_L g141 ( 
.A(n_113),
.Y(n_141)
);

INVx1_ASAP7_75t_L g142 ( 
.A(n_115),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_115),
.Y(n_143)
);

NAND2xp5_ASAP7_75t_L g144 ( 
.A(n_121),
.B(n_120),
.Y(n_144)
);

AND2x2_ASAP7_75t_L g145 ( 
.A(n_115),
.B(n_116),
.Y(n_145)
);

INVx1_ASAP7_75t_L g146 ( 
.A(n_115),
.Y(n_146)
);

NAND2xp5_ASAP7_75t_L g147 ( 
.A(n_121),
.B(n_96),
.Y(n_147)
);

AND2x2_ASAP7_75t_L g148 ( 
.A(n_116),
.B(n_106),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_120),
.Y(n_149)
);

AOI22xp33_ASAP7_75t_SL g150 ( 
.A1(n_131),
.A2(n_111),
.B1(n_118),
.B2(n_119),
.Y(n_150)
);

INVx1_ASAP7_75t_SL g151 ( 
.A(n_130),
.Y(n_151)
);

NAND2xp5_ASAP7_75t_L g152 ( 
.A(n_138),
.B(n_120),
.Y(n_152)
);

AOI311xp33_ASAP7_75t_L g153 ( 
.A1(n_126),
.A2(n_118),
.A3(n_84),
.B(n_72),
.C(n_5),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_129),
.Y(n_154)
);

AOI22xp5_ASAP7_75t_L g155 ( 
.A1(n_128),
.A2(n_97),
.B1(n_111),
.B2(n_117),
.Y(n_155)
);

NAND2xp5_ASAP7_75t_L g156 ( 
.A(n_141),
.B(n_117),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_129),
.Y(n_157)
);

INVxp67_ASAP7_75t_L g158 ( 
.A(n_127),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_137),
.Y(n_159)
);

NAND2xp5_ASAP7_75t_L g160 ( 
.A(n_149),
.B(n_117),
.Y(n_160)
);

OAI221xp5_ASAP7_75t_L g161 ( 
.A1(n_132),
.A2(n_111),
.B1(n_123),
.B2(n_119),
.C(n_106),
.Y(n_161)
);

INVx1_ASAP7_75t_SL g162 ( 
.A(n_133),
.Y(n_162)
);

NOR2xp33_ASAP7_75t_L g163 ( 
.A(n_127),
.B(n_137),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_140),
.Y(n_164)
);

AND2x2_ASAP7_75t_L g165 ( 
.A(n_131),
.B(n_123),
.Y(n_165)
);

AND2x2_ASAP7_75t_L g166 ( 
.A(n_134),
.B(n_136),
.Y(n_166)
);

OAI22xp33_ASAP7_75t_L g167 ( 
.A1(n_133),
.A2(n_87),
.B1(n_117),
.B2(n_116),
.Y(n_167)
);

NAND2xp5_ASAP7_75t_SL g168 ( 
.A(n_135),
.B(n_117),
.Y(n_168)
);

OAI21xp5_ASAP7_75t_SL g169 ( 
.A1(n_144),
.A2(n_87),
.B(n_96),
.Y(n_169)
);

INVx1_ASAP7_75t_SL g170 ( 
.A(n_145),
.Y(n_170)
);

AND2x2_ASAP7_75t_L g171 ( 
.A(n_134),
.B(n_106),
.Y(n_171)
);

AND2x2_ASAP7_75t_L g172 ( 
.A(n_134),
.B(n_106),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_149),
.Y(n_173)
);

AOI221xp5_ASAP7_75t_L g174 ( 
.A1(n_140),
.A2(n_87),
.B1(n_63),
.B2(n_85),
.C(n_84),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_145),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_135),
.Y(n_176)
);

OAI32xp33_ASAP7_75t_L g177 ( 
.A1(n_136),
.A2(n_84),
.A3(n_8),
.B1(n_6),
.B2(n_7),
.Y(n_177)
);

OAI22xp5_ASAP7_75t_L g178 ( 
.A1(n_147),
.A2(n_84),
.B1(n_85),
.B2(n_86),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_142),
.Y(n_179)
);

NAND3xp33_ASAP7_75t_L g180 ( 
.A(n_142),
.B(n_90),
.C(n_84),
.Y(n_180)
);

NAND2x1p5_ASAP7_75t_L g181 ( 
.A(n_143),
.B(n_88),
.Y(n_181)
);

NAND2xp5_ASAP7_75t_L g182 ( 
.A(n_148),
.B(n_6),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_154),
.Y(n_183)
);

NOR3xp33_ASAP7_75t_L g184 ( 
.A(n_182),
.B(n_146),
.C(n_143),
.Y(n_184)
);

INVxp67_ASAP7_75t_L g185 ( 
.A(n_151),
.Y(n_185)
);

NAND2xp5_ASAP7_75t_L g186 ( 
.A(n_163),
.B(n_148),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_157),
.Y(n_187)
);

INVx1_ASAP7_75t_L g188 ( 
.A(n_159),
.Y(n_188)
);

NAND2xp5_ASAP7_75t_SL g189 ( 
.A(n_150),
.B(n_136),
.Y(n_189)
);

NAND2xp5_ASAP7_75t_L g190 ( 
.A(n_163),
.B(n_146),
.Y(n_190)
);

INVxp67_ASAP7_75t_L g191 ( 
.A(n_168),
.Y(n_191)
);

NAND2xp5_ASAP7_75t_L g192 ( 
.A(n_176),
.B(n_139),
.Y(n_192)
);

NAND2x1_ASAP7_75t_L g193 ( 
.A(n_165),
.B(n_83),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_179),
.Y(n_194)
);

NOR2xp33_ASAP7_75t_L g195 ( 
.A(n_158),
.B(n_7),
.Y(n_195)
);

INVx2_ASAP7_75t_L g196 ( 
.A(n_164),
.Y(n_196)
);

NOR2xp33_ASAP7_75t_L g197 ( 
.A(n_175),
.B(n_9),
.Y(n_197)
);

NAND2xp5_ASAP7_75t_L g198 ( 
.A(n_173),
.B(n_9),
.Y(n_198)
);

INVx2_ASAP7_75t_L g199 ( 
.A(n_164),
.Y(n_199)
);

NAND2xp5_ASAP7_75t_L g200 ( 
.A(n_162),
.B(n_10),
.Y(n_200)
);

INVx1_ASAP7_75t_L g201 ( 
.A(n_166),
.Y(n_201)
);

INVx2_ASAP7_75t_L g202 ( 
.A(n_166),
.Y(n_202)
);

NAND2xp5_ASAP7_75t_L g203 ( 
.A(n_152),
.B(n_10),
.Y(n_203)
);

INVx1_ASAP7_75t_L g204 ( 
.A(n_160),
.Y(n_204)
);

INVx1_ASAP7_75t_L g205 ( 
.A(n_171),
.Y(n_205)
);

INVx2_ASAP7_75t_L g206 ( 
.A(n_171),
.Y(n_206)
);

NAND2xp5_ASAP7_75t_SL g207 ( 
.A(n_167),
.B(n_88),
.Y(n_207)
);

INVx1_ASAP7_75t_SL g208 ( 
.A(n_170),
.Y(n_208)
);

AND2x2_ASAP7_75t_L g209 ( 
.A(n_165),
.B(n_89),
.Y(n_209)
);

INVx2_ASAP7_75t_L g210 ( 
.A(n_172),
.Y(n_210)
);

INVx1_ASAP7_75t_L g211 ( 
.A(n_172),
.Y(n_211)
);

NOR2x1_ASAP7_75t_SL g212 ( 
.A(n_168),
.B(n_83),
.Y(n_212)
);

INVx2_ASAP7_75t_L g213 ( 
.A(n_181),
.Y(n_213)
);

INVx1_ASAP7_75t_L g214 ( 
.A(n_156),
.Y(n_214)
);

INVx2_ASAP7_75t_L g215 ( 
.A(n_181),
.Y(n_215)
);

NOR2xp33_ASAP7_75t_L g216 ( 
.A(n_155),
.B(n_12),
.Y(n_216)
);

INVx1_ASAP7_75t_SL g217 ( 
.A(n_208),
.Y(n_217)
);

INVx1_ASAP7_75t_L g218 ( 
.A(n_183),
.Y(n_218)
);

NOR2xp33_ASAP7_75t_R g219 ( 
.A(n_185),
.B(n_197),
.Y(n_219)
);

AOI21x1_ASAP7_75t_L g220 ( 
.A1(n_189),
.A2(n_178),
.B(n_180),
.Y(n_220)
);

NOR2xp67_ASAP7_75t_SL g221 ( 
.A(n_200),
.B(n_169),
.Y(n_221)
);

AOI211xp5_ASAP7_75t_L g222 ( 
.A1(n_216),
.A2(n_161),
.B(n_177),
.C(n_174),
.Y(n_222)
);

AOI221xp5_ASAP7_75t_L g223 ( 
.A1(n_195),
.A2(n_177),
.B1(n_153),
.B2(n_181),
.C(n_84),
.Y(n_223)
);

AOI211xp5_ASAP7_75t_L g224 ( 
.A1(n_191),
.A2(n_84),
.B(n_89),
.C(n_12),
.Y(n_224)
);

AOI211xp5_ASAP7_75t_L g225 ( 
.A1(n_184),
.A2(n_84),
.B(n_14),
.C(n_13),
.Y(n_225)
);

BUFx6f_ASAP7_75t_SL g226 ( 
.A(n_204),
.Y(n_226)
);

AOI211xp5_ASAP7_75t_L g227 ( 
.A1(n_207),
.A2(n_84),
.B(n_15),
.C(n_13),
.Y(n_227)
);

NOR2xp33_ASAP7_75t_L g228 ( 
.A(n_214),
.B(n_15),
.Y(n_228)
);

NOR4xp75_ASAP7_75t_L g229 ( 
.A(n_203),
.B(n_193),
.C(n_198),
.D(n_186),
.Y(n_229)
);

INVx1_ASAP7_75t_SL g230 ( 
.A(n_202),
.Y(n_230)
);

AOI211xp5_ASAP7_75t_L g231 ( 
.A1(n_214),
.A2(n_84),
.B(n_90),
.C(n_86),
.Y(n_231)
);

BUFx2_ASAP7_75t_L g232 ( 
.A(n_206),
.Y(n_232)
);

INVx1_ASAP7_75t_L g233 ( 
.A(n_183),
.Y(n_233)
);

AOI221xp5_ASAP7_75t_SL g234 ( 
.A1(n_204),
.A2(n_90),
.B1(n_83),
.B2(n_60),
.C(n_33),
.Y(n_234)
);

AOI221xp5_ASAP7_75t_L g235 ( 
.A1(n_190),
.A2(n_94),
.B1(n_60),
.B2(n_56),
.C(n_83),
.Y(n_235)
);

AOI221xp5_ASAP7_75t_L g236 ( 
.A1(n_192),
.A2(n_94),
.B1(n_60),
.B2(n_67),
.C(n_95),
.Y(n_236)
);

A2O1A1Ixp33_ASAP7_75t_L g237 ( 
.A1(n_193),
.A2(n_95),
.B(n_94),
.C(n_60),
.Y(n_237)
);

OAI211xp5_ASAP7_75t_L g238 ( 
.A1(n_213),
.A2(n_95),
.B(n_94),
.C(n_60),
.Y(n_238)
);

AOI221xp5_ASAP7_75t_L g239 ( 
.A1(n_211),
.A2(n_94),
.B1(n_95),
.B2(n_205),
.C(n_194),
.Y(n_239)
);

OAI21xp5_ASAP7_75t_SL g240 ( 
.A1(n_209),
.A2(n_95),
.B(n_94),
.Y(n_240)
);

AOI21xp5_ASAP7_75t_SL g241 ( 
.A1(n_226),
.A2(n_212),
.B(n_213),
.Y(n_241)
);

INVxp33_ASAP7_75t_L g242 ( 
.A(n_219),
.Y(n_242)
);

NAND2xp5_ASAP7_75t_L g243 ( 
.A(n_218),
.B(n_211),
.Y(n_243)
);

AND2x4_ASAP7_75t_L g244 ( 
.A(n_217),
.B(n_215),
.Y(n_244)
);

OAI211xp5_ASAP7_75t_L g245 ( 
.A1(n_222),
.A2(n_215),
.B(n_205),
.C(n_187),
.Y(n_245)
);

AOI221x1_ASAP7_75t_L g246 ( 
.A1(n_228),
.A2(n_194),
.B1(n_188),
.B2(n_187),
.C(n_201),
.Y(n_246)
);

NAND2xp5_ASAP7_75t_L g247 ( 
.A(n_233),
.B(n_201),
.Y(n_247)
);

NOR3xp33_ASAP7_75t_L g248 ( 
.A(n_220),
.B(n_188),
.C(n_196),
.Y(n_248)
);

AOI21xp5_ASAP7_75t_L g249 ( 
.A1(n_227),
.A2(n_212),
.B(n_209),
.Y(n_249)
);

OAI321xp33_ASAP7_75t_L g250 ( 
.A1(n_223),
.A2(n_225),
.A3(n_239),
.B1(n_224),
.B2(n_228),
.C(n_231),
.Y(n_250)
);

AOI22xp5_ASAP7_75t_L g251 ( 
.A1(n_221),
.A2(n_206),
.B1(n_210),
.B2(n_202),
.Y(n_251)
);

OAI211xp5_ASAP7_75t_L g252 ( 
.A1(n_240),
.A2(n_210),
.B(n_199),
.C(n_196),
.Y(n_252)
);

AND2x2_ASAP7_75t_L g253 ( 
.A(n_232),
.B(n_199),
.Y(n_253)
);

AOI221xp5_ASAP7_75t_L g254 ( 
.A1(n_226),
.A2(n_230),
.B1(n_236),
.B2(n_238),
.C(n_235),
.Y(n_254)
);

INVx1_ASAP7_75t_L g255 ( 
.A(n_243),
.Y(n_255)
);

CKINVDCx20_ASAP7_75t_R g256 ( 
.A(n_251),
.Y(n_256)
);

BUFx2_ASAP7_75t_L g257 ( 
.A(n_244),
.Y(n_257)
);

BUFx3_ASAP7_75t_L g258 ( 
.A(n_244),
.Y(n_258)
);

INVx1_ASAP7_75t_L g259 ( 
.A(n_247),
.Y(n_259)
);

INVx1_ASAP7_75t_L g260 ( 
.A(n_253),
.Y(n_260)
);

NAND2xp5_ASAP7_75t_L g261 ( 
.A(n_246),
.B(n_238),
.Y(n_261)
);

INVx2_ASAP7_75t_L g262 ( 
.A(n_257),
.Y(n_262)
);

NAND2xp33_ASAP7_75t_SL g263 ( 
.A(n_256),
.B(n_242),
.Y(n_263)
);

AO21x2_ASAP7_75t_L g264 ( 
.A1(n_261),
.A2(n_248),
.B(n_245),
.Y(n_264)
);

O2A1O1Ixp5_ASAP7_75t_L g265 ( 
.A1(n_259),
.A2(n_252),
.B(n_255),
.C(n_249),
.Y(n_265)
);

OAI22xp5_ASAP7_75t_SL g266 ( 
.A1(n_263),
.A2(n_256),
.B1(n_257),
.B2(n_258),
.Y(n_266)
);

OAI22xp33_ASAP7_75t_L g267 ( 
.A1(n_262),
.A2(n_258),
.B1(n_250),
.B2(n_260),
.Y(n_267)
);

NAND5xp2_ASAP7_75t_L g268 ( 
.A(n_266),
.B(n_254),
.C(n_234),
.D(n_265),
.E(n_264),
.Y(n_268)
);

AOI22xp33_ASAP7_75t_L g269 ( 
.A1(n_268),
.A2(n_267),
.B1(n_264),
.B2(n_265),
.Y(n_269)
);

AOI22xp5_ASAP7_75t_L g270 ( 
.A1(n_269),
.A2(n_229),
.B1(n_237),
.B2(n_241),
.Y(n_270)
);


endmodule