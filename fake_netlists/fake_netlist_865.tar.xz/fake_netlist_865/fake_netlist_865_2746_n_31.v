module fake_netlist_865_2746_n_31 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_31);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_31;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

NAND2xp33_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_2),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_4),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_1),
.B(n_0),
.Y(n_18)
);

AO21x2_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_4),
.B(n_3),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_3),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_14),
.B(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_13),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_16),
.B1(n_11),
.B2(n_13),
.C(n_12),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_21),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_21),
.Y(n_27)
);

OAI211xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_16),
.B(n_23),
.C(n_18),
.Y(n_28)
);

AOI211xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.B(n_17),
.C(n_20),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_6),
.B1(n_19),
.B2(n_25),
.C1(n_11),
.C2(n_26),
.Y(n_31)
);


endmodule