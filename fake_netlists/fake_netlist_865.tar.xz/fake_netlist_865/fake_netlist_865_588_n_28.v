module fake_netlist_865_588_n_28 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_28);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_7),
.B(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_4),
.B(n_8),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_1),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_3),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_5),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_20),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_16),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_20),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OAI22x1_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_17),
.B1(n_9),
.B2(n_21),
.Y(n_26)
);

AOI22x1_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_22),
.B1(n_14),
.B2(n_12),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_6),
.B1(n_26),
.B2(n_11),
.Y(n_28)
);


endmodule