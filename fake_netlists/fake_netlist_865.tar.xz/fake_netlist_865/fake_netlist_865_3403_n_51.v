module fake_netlist_865_3403_n_51 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_51);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_51;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_1),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_14),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_11),
.B(n_0),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_15),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

CKINVDCx14_ASAP7_75t_R g28 ( 
.A(n_21),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_0),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_3),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AO21x2_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_22),
.B(n_24),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_29),
.B1(n_28),
.B2(n_20),
.C(n_19),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_19),
.B1(n_20),
.B2(n_21),
.Y(n_36)
);

OAI211xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_19),
.B(n_26),
.C(n_23),
.Y(n_37)
);

NOR3xp33_ASAP7_75t_SL g38 ( 
.A(n_37),
.B(n_33),
.C(n_32),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_34),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

NAND2xp33_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_19),
.Y(n_41)
);

NAND2x1_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_32),
.Y(n_42)
);

OAI21xp5_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_34),
.B(n_32),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_42),
.B1(n_41),
.B2(n_33),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_33),
.Y(n_45)
);

AOI322xp5_ASAP7_75t_L g46 ( 
.A1(n_41),
.A2(n_5),
.A3(n_3),
.B1(n_16),
.B2(n_18),
.C1(n_17),
.C2(n_33),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_17),
.A3(n_16),
.B1(n_5),
.B2(n_33),
.C1(n_6),
.C2(n_8),
.Y(n_48)
);

XNOR2xp5_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_33),
.Y(n_49)
);

NAND4xp25_ASAP7_75t_SL g50 ( 
.A(n_48),
.B(n_12),
.C(n_10),
.D(n_9),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_49),
.B1(n_47),
.B2(n_13),
.Y(n_51)
);


endmodule