module fake_netlist_865_3066_n_13 (n_4, n_2, n_3, n_0, n_1, n_13);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_13;

wire n_6;
wire n_10;
wire n_7;
wire n_5;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

OAI22x1_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_2),
.Y(n_9)
);

AOI21xp33_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_3),
.B(n_2),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.C(n_3),
.Y(n_11)
);

AOI31xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_3),
.A3(n_4),
.B(n_10),
.Y(n_12)
);

NAND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_4),
.Y(n_13)
);


endmodule