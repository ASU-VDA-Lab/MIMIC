module fake_netlist_865_3086_n_243 (n_48, n_49, n_25, n_20, n_60, n_15, n_13, n_2, n_36, n_47, n_17, n_57, n_14, n_70, n_50, n_22, n_41, n_62, n_4, n_7, n_23, n_34, n_40, n_28, n_39, n_44, n_9, n_53, n_31, n_32, n_58, n_68, n_26, n_24, n_43, n_37, n_19, n_42, n_3, n_54, n_69, n_33, n_12, n_0, n_56, n_29, n_59, n_63, n_6, n_30, n_18, n_64, n_66, n_10, n_55, n_65, n_16, n_21, n_5, n_35, n_38, n_11, n_52, n_61, n_27, n_67, n_1, n_45, n_8, n_46, n_51, n_243);

input n_48;
input n_49;
input n_25;
input n_20;
input n_60;
input n_15;
input n_13;
input n_2;
input n_36;
input n_47;
input n_17;
input n_57;
input n_14;
input n_70;
input n_50;
input n_22;
input n_41;
input n_62;
input n_4;
input n_7;
input n_23;
input n_34;
input n_40;
input n_28;
input n_39;
input n_44;
input n_9;
input n_53;
input n_31;
input n_32;
input n_58;
input n_68;
input n_26;
input n_24;
input n_43;
input n_37;
input n_19;
input n_42;
input n_3;
input n_54;
input n_69;
input n_33;
input n_12;
input n_0;
input n_56;
input n_29;
input n_59;
input n_63;
input n_6;
input n_30;
input n_18;
input n_64;
input n_66;
input n_10;
input n_55;
input n_65;
input n_16;
input n_21;
input n_5;
input n_35;
input n_38;
input n_11;
input n_52;
input n_61;
input n_27;
input n_67;
input n_1;
input n_45;
input n_8;
input n_46;
input n_51;

output n_243;

wire n_132;
wire n_97;
wire n_219;
wire n_221;
wire n_194;
wire n_81;
wire n_182;
wire n_114;
wire n_130;
wire n_80;
wire n_239;
wire n_166;
wire n_123;
wire n_173;
wire n_240;
wire n_156;
wire n_222;
wire n_126;
wire n_154;
wire n_78;
wire n_153;
wire n_195;
wire n_210;
wire n_187;
wire n_87;
wire n_167;
wire n_122;
wire n_96;
wire n_95;
wire n_232;
wire n_94;
wire n_74;
wire n_79;
wire n_177;
wire n_110;
wire n_184;
wire n_86;
wire n_108;
wire n_192;
wire n_163;
wire n_162;
wire n_209;
wire n_196;
wire n_230;
wire n_158;
wire n_135;
wire n_171;
wire n_118;
wire n_214;
wire n_127;
wire n_202;
wire n_90;
wire n_213;
wire n_76;
wire n_189;
wire n_160;
wire n_107;
wire n_125;
wire n_99;
wire n_151;
wire n_178;
wire n_72;
wire n_121;
wire n_73;
wire n_235;
wire n_211;
wire n_207;
wire n_120;
wire n_103;
wire n_155;
wire n_145;
wire n_227;
wire n_200;
wire n_175;
wire n_199;
wire n_185;
wire n_143;
wire n_170;
wire n_77;
wire n_161;
wire n_190;
wire n_224;
wire n_229;
wire n_137;
wire n_138;
wire n_116;
wire n_136;
wire n_179;
wire n_102;
wire n_226;
wire n_119;
wire n_217;
wire n_89;
wire n_152;
wire n_172;
wire n_238;
wire n_131;
wire n_128;
wire n_133;
wire n_139;
wire n_142;
wire n_115;
wire n_109;
wire n_223;
wire n_144;
wire n_117;
wire n_84;
wire n_183;
wire n_146;
wire n_104;
wire n_105;
wire n_168;
wire n_225;
wire n_106;
wire n_215;
wire n_149;
wire n_188;
wire n_85;
wire n_237;
wire n_205;
wire n_164;
wire n_159;
wire n_75;
wire n_140;
wire n_176;
wire n_101;
wire n_98;
wire n_91;
wire n_233;
wire n_242;
wire n_204;
wire n_203;
wire n_191;
wire n_112;
wire n_129;
wire n_181;
wire n_157;
wire n_198;
wire n_201;
wire n_83;
wire n_228;
wire n_111;
wire n_169;
wire n_180;
wire n_93;
wire n_174;
wire n_220;
wire n_150;
wire n_216;
wire n_71;
wire n_208;
wire n_92;
wire n_82;
wire n_186;
wire n_100;
wire n_218;
wire n_193;
wire n_234;
wire n_212;
wire n_165;
wire n_88;
wire n_124;
wire n_197;
wire n_241;
wire n_113;
wire n_236;
wire n_206;
wire n_147;
wire n_231;
wire n_141;
wire n_134;
wire n_148;

NOR2xp67_ASAP7_75t_L g71 ( 
.A(n_35),
.B(n_12),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_58),
.Y(n_72)
);

INVxp67_ASAP7_75t_SL g73 ( 
.A(n_54),
.Y(n_73)
);

CKINVDCx5p33_ASAP7_75t_R g74 ( 
.A(n_9),
.Y(n_74)
);

BUFx6f_ASAP7_75t_L g75 ( 
.A(n_47),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_29),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_33),
.Y(n_77)
);

OR2x2_ASAP7_75t_L g78 ( 
.A(n_53),
.B(n_69),
.Y(n_78)
);

CKINVDCx16_ASAP7_75t_R g79 ( 
.A(n_17),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_55),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_22),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_64),
.Y(n_82)
);

BUFx3_ASAP7_75t_L g83 ( 
.A(n_19),
.Y(n_83)
);

CKINVDCx5p33_ASAP7_75t_R g84 ( 
.A(n_4),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_59),
.Y(n_85)
);

CKINVDCx16_ASAP7_75t_R g86 ( 
.A(n_15),
.Y(n_86)
);

CKINVDCx5p33_ASAP7_75t_R g87 ( 
.A(n_26),
.Y(n_87)
);

BUFx3_ASAP7_75t_L g88 ( 
.A(n_70),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_14),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_57),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_3),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_48),
.Y(n_92)
);

HB1xp67_ASAP7_75t_L g93 ( 
.A(n_32),
.Y(n_93)
);

INVx1_ASAP7_75t_L g94 ( 
.A(n_67),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_8),
.Y(n_95)
);

INVx1_ASAP7_75t_L g96 ( 
.A(n_3),
.Y(n_96)
);

INVxp67_ASAP7_75t_SL g97 ( 
.A(n_46),
.Y(n_97)
);

INVxp67_ASAP7_75t_SL g98 ( 
.A(n_45),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_34),
.Y(n_99)
);

INVx1_ASAP7_75t_L g100 ( 
.A(n_36),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_49),
.Y(n_101)
);

BUFx3_ASAP7_75t_L g102 ( 
.A(n_6),
.Y(n_102)
);

INVxp67_ASAP7_75t_L g103 ( 
.A(n_41),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_20),
.Y(n_104)
);

CKINVDCx16_ASAP7_75t_R g105 ( 
.A(n_31),
.Y(n_105)
);

CKINVDCx20_ASAP7_75t_R g106 ( 
.A(n_39),
.Y(n_106)
);

NOR2x1_ASAP7_75t_L g107 ( 
.A(n_102),
.B(n_7),
.Y(n_107)
);

AND2x2_ASAP7_75t_L g108 ( 
.A(n_93),
.B(n_0),
.Y(n_108)
);

BUFx6f_ASAP7_75t_L g109 ( 
.A(n_75),
.Y(n_109)
);

NAND2xp5_ASAP7_75t_L g110 ( 
.A(n_93),
.B(n_0),
.Y(n_110)
);

INVx2_ASAP7_75t_L g111 ( 
.A(n_72),
.Y(n_111)
);

AND2x4_ASAP7_75t_L g112 ( 
.A(n_91),
.B(n_1),
.Y(n_112)
);

OAI22xp5_ASAP7_75t_SL g113 ( 
.A1(n_96),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_113)
);

AND2x4_ASAP7_75t_L g114 ( 
.A(n_83),
.B(n_2),
.Y(n_114)
);

BUFx6f_ASAP7_75t_L g115 ( 
.A(n_109),
.Y(n_115)
);

INVx2_ASAP7_75t_L g116 ( 
.A(n_109),
.Y(n_116)
);

BUFx3_ASAP7_75t_L g117 ( 
.A(n_114),
.Y(n_117)
);

AND2x4_ASAP7_75t_L g118 ( 
.A(n_108),
.B(n_73),
.Y(n_118)
);

AND2x4_ASAP7_75t_L g119 ( 
.A(n_114),
.B(n_73),
.Y(n_119)
);

NAND2xp5_ASAP7_75t_SL g120 ( 
.A(n_111),
.B(n_76),
.Y(n_120)
);

OAI22xp5_ASAP7_75t_L g121 ( 
.A1(n_119),
.A2(n_118),
.B1(n_117),
.B2(n_106),
.Y(n_121)
);

NAND2xp5_ASAP7_75t_L g122 ( 
.A(n_118),
.B(n_110),
.Y(n_122)
);

NAND2xp5_ASAP7_75t_L g123 ( 
.A(n_119),
.B(n_110),
.Y(n_123)
);

NOR2xp33_ASAP7_75t_L g124 ( 
.A(n_117),
.B(n_112),
.Y(n_124)
);

INVx2_ASAP7_75t_L g125 ( 
.A(n_116),
.Y(n_125)
);

INVx1_ASAP7_75t_L g126 ( 
.A(n_123),
.Y(n_126)
);

BUFx3_ASAP7_75t_L g127 ( 
.A(n_122),
.Y(n_127)
);

A2O1A1Ixp33_ASAP7_75t_L g128 ( 
.A1(n_124),
.A2(n_112),
.B(n_98),
.C(n_97),
.Y(n_128)
);

AND2x4_ASAP7_75t_L g129 ( 
.A(n_125),
.B(n_120),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_121),
.Y(n_130)
);

BUFx4f_ASAP7_75t_SL g131 ( 
.A(n_127),
.Y(n_131)
);

AND2x4_ASAP7_75t_L g132 ( 
.A(n_127),
.B(n_120),
.Y(n_132)
);

OAI21x1_ASAP7_75t_L g133 ( 
.A1(n_130),
.A2(n_107),
.B(n_78),
.Y(n_133)
);

OAI21x1_ASAP7_75t_L g134 ( 
.A1(n_126),
.A2(n_80),
.B(n_77),
.Y(n_134)
);

BUFx2_ASAP7_75t_L g135 ( 
.A(n_129),
.Y(n_135)
);

OAI21x1_ASAP7_75t_L g136 ( 
.A1(n_129),
.A2(n_82),
.B(n_81),
.Y(n_136)
);

OAI21x1_ASAP7_75t_L g137 ( 
.A1(n_129),
.A2(n_89),
.B(n_85),
.Y(n_137)
);

NAND2x1p5_ASAP7_75t_L g138 ( 
.A(n_128),
.B(n_83),
.Y(n_138)
);

A2O1A1Ixp33_ASAP7_75t_L g139 ( 
.A1(n_134),
.A2(n_128),
.B(n_98),
.C(n_97),
.Y(n_139)
);

AOI21xp5_ASAP7_75t_L g140 ( 
.A1(n_133),
.A2(n_71),
.B(n_90),
.Y(n_140)
);

OA21x2_ASAP7_75t_L g141 ( 
.A1(n_133),
.A2(n_94),
.B(n_92),
.Y(n_141)
);

INVx3_ASAP7_75t_L g142 ( 
.A(n_131),
.Y(n_142)
);

AO21x2_ASAP7_75t_L g143 ( 
.A1(n_136),
.A2(n_99),
.B(n_95),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_132),
.Y(n_144)
);

OAI21x1_ASAP7_75t_L g145 ( 
.A1(n_137),
.A2(n_136),
.B(n_134),
.Y(n_145)
);

OAI21x1_ASAP7_75t_L g146 ( 
.A1(n_137),
.A2(n_101),
.B(n_100),
.Y(n_146)
);

OAI22xp33_ASAP7_75t_L g147 ( 
.A1(n_138),
.A2(n_105),
.B1(n_86),
.B2(n_79),
.Y(n_147)
);

AOI222xp33_ASAP7_75t_L g148 ( 
.A1(n_135),
.A2(n_113),
.B1(n_84),
.B2(n_103),
.C1(n_104),
.C2(n_88),
.Y(n_148)
);

AND2x2_ASAP7_75t_L g149 ( 
.A(n_132),
.B(n_103),
.Y(n_149)
);

AOI21xp5_ASAP7_75t_L g150 ( 
.A1(n_138),
.A2(n_116),
.B(n_88),
.Y(n_150)
);

AND2x2_ASAP7_75t_L g151 ( 
.A(n_132),
.B(n_5),
.Y(n_151)
);

OR2x2_ASAP7_75t_L g152 ( 
.A(n_132),
.B(n_113),
.Y(n_152)
);

AOI22xp33_ASAP7_75t_L g153 ( 
.A1(n_138),
.A2(n_75),
.B1(n_109),
.B2(n_74),
.Y(n_153)
);

INVx2_ASAP7_75t_L g154 ( 
.A(n_145),
.Y(n_154)
);

INVxp67_ASAP7_75t_SL g155 ( 
.A(n_146),
.Y(n_155)
);

INVxp67_ASAP7_75t_SL g156 ( 
.A(n_146),
.Y(n_156)
);

INVx2_ASAP7_75t_L g157 ( 
.A(n_144),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_151),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_152),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_149),
.Y(n_160)
);

OR2x2_ASAP7_75t_L g161 ( 
.A(n_147),
.B(n_5),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_139),
.Y(n_162)
);

OR2x2_ASAP7_75t_L g163 ( 
.A(n_147),
.B(n_6),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_141),
.Y(n_164)
);

INVx1_ASAP7_75t_L g165 ( 
.A(n_139),
.Y(n_165)
);

INVx1_ASAP7_75t_L g166 ( 
.A(n_143),
.Y(n_166)
);

INVx3_ASAP7_75t_L g167 ( 
.A(n_143),
.Y(n_167)
);

AND2x2_ASAP7_75t_L g168 ( 
.A(n_141),
.B(n_75),
.Y(n_168)
);

NAND2xp5_ASAP7_75t_L g169 ( 
.A(n_148),
.B(n_87),
.Y(n_169)
);

BUFx2_ASAP7_75t_L g170 ( 
.A(n_141),
.Y(n_170)
);

BUFx3_ASAP7_75t_L g171 ( 
.A(n_142),
.Y(n_171)
);

OAI321xp33_ASAP7_75t_L g172 ( 
.A1(n_153),
.A2(n_115),
.A3(n_13),
.B1(n_10),
.B2(n_16),
.C(n_11),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_140),
.Y(n_173)
);

HB1xp67_ASAP7_75t_L g174 ( 
.A(n_142),
.Y(n_174)
);

AND2x2_ASAP7_75t_L g175 ( 
.A(n_153),
.B(n_18),
.Y(n_175)
);

BUFx2_ASAP7_75t_L g176 ( 
.A(n_171),
.Y(n_176)
);

OA332x1_ASAP7_75t_L g177 ( 
.A1(n_159),
.A2(n_163),
.A3(n_161),
.B1(n_160),
.B2(n_174),
.B3(n_158),
.C1(n_171),
.C2(n_162),
.Y(n_177)
);

OAI33xp33_ASAP7_75t_L g178 ( 
.A1(n_163),
.A2(n_150),
.A3(n_24),
.B1(n_21),
.B2(n_25),
.B3(n_23),
.Y(n_178)
);

AND2x2_ASAP7_75t_SL g179 ( 
.A(n_170),
.B(n_27),
.Y(n_179)
);

OR2x2_ASAP7_75t_L g180 ( 
.A(n_161),
.B(n_28),
.Y(n_180)
);

AND2x2_ASAP7_75t_L g181 ( 
.A(n_157),
.B(n_30),
.Y(n_181)
);

INVx4_ASAP7_75t_L g182 ( 
.A(n_175),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_157),
.Y(n_183)
);

OR2x2_ASAP7_75t_L g184 ( 
.A(n_170),
.B(n_37),
.Y(n_184)
);

AOI221xp5_ASAP7_75t_L g185 ( 
.A1(n_169),
.A2(n_115),
.B1(n_42),
.B2(n_38),
.C(n_40),
.Y(n_185)
);

INVx1_ASAP7_75t_L g186 ( 
.A(n_166),
.Y(n_186)
);

AND2x2_ASAP7_75t_L g187 ( 
.A(n_165),
.B(n_43),
.Y(n_187)
);

NOR3xp33_ASAP7_75t_L g188 ( 
.A(n_173),
.B(n_50),
.C(n_44),
.Y(n_188)
);

INVx2_ASAP7_75t_L g189 ( 
.A(n_164),
.Y(n_189)
);

NAND2xp5_ASAP7_75t_L g190 ( 
.A(n_173),
.B(n_51),
.Y(n_190)
);

INVx1_ASAP7_75t_L g191 ( 
.A(n_164),
.Y(n_191)
);

INVxp67_ASAP7_75t_SL g192 ( 
.A(n_167),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_175),
.B(n_52),
.Y(n_193)
);

NOR2x1_ASAP7_75t_L g194 ( 
.A(n_167),
.B(n_56),
.Y(n_194)
);

AND2x2_ASAP7_75t_L g195 ( 
.A(n_168),
.B(n_167),
.Y(n_195)
);

AND2x2_ASAP7_75t_L g196 ( 
.A(n_176),
.B(n_155),
.Y(n_196)
);

HB1xp67_ASAP7_75t_L g197 ( 
.A(n_189),
.Y(n_197)
);

AOI31xp33_ASAP7_75t_L g198 ( 
.A1(n_177),
.A2(n_156),
.A3(n_154),
.B(n_172),
.Y(n_198)
);

INVx2_ASAP7_75t_L g199 ( 
.A(n_189),
.Y(n_199)
);

NAND2xp5_ASAP7_75t_L g200 ( 
.A(n_191),
.B(n_154),
.Y(n_200)
);

NAND2x1p5_ASAP7_75t_L g201 ( 
.A(n_179),
.B(n_60),
.Y(n_201)
);

INVx1_ASAP7_75t_L g202 ( 
.A(n_183),
.Y(n_202)
);

OR2x2_ASAP7_75t_L g203 ( 
.A(n_182),
.B(n_61),
.Y(n_203)
);

OR2x2_ASAP7_75t_L g204 ( 
.A(n_182),
.B(n_62),
.Y(n_204)
);

INVx1_ASAP7_75t_L g205 ( 
.A(n_186),
.Y(n_205)
);

AND2x2_ASAP7_75t_L g206 ( 
.A(n_179),
.B(n_63),
.Y(n_206)
);

AND2x2_ASAP7_75t_L g207 ( 
.A(n_195),
.B(n_65),
.Y(n_207)
);

OR2x2_ASAP7_75t_L g208 ( 
.A(n_184),
.B(n_66),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_192),
.Y(n_209)
);

INVx2_ASAP7_75t_L g210 ( 
.A(n_181),
.Y(n_210)
);

AND2x2_ASAP7_75t_L g211 ( 
.A(n_180),
.B(n_68),
.Y(n_211)
);

INVxp67_ASAP7_75t_L g212 ( 
.A(n_197),
.Y(n_212)
);

HB1xp67_ASAP7_75t_L g213 ( 
.A(n_197),
.Y(n_213)
);

INVx1_ASAP7_75t_SL g214 ( 
.A(n_196),
.Y(n_214)
);

AND2x2_ASAP7_75t_L g215 ( 
.A(n_205),
.B(n_192),
.Y(n_215)
);

NAND2xp5_ASAP7_75t_L g216 ( 
.A(n_202),
.B(n_177),
.Y(n_216)
);

OR2x2_ASAP7_75t_L g217 ( 
.A(n_199),
.B(n_190),
.Y(n_217)
);

INVx1_ASAP7_75t_L g218 ( 
.A(n_199),
.Y(n_218)
);

NAND2xp5_ASAP7_75t_L g219 ( 
.A(n_210),
.B(n_187),
.Y(n_219)
);

INVx2_ASAP7_75t_L g220 ( 
.A(n_209),
.Y(n_220)
);

NAND2xp5_ASAP7_75t_L g221 ( 
.A(n_198),
.B(n_193),
.Y(n_221)
);

AND2x2_ASAP7_75t_L g222 ( 
.A(n_214),
.B(n_200),
.Y(n_222)
);

INVx1_ASAP7_75t_L g223 ( 
.A(n_213),
.Y(n_223)
);

INVx1_ASAP7_75t_L g224 ( 
.A(n_220),
.Y(n_224)
);

O2A1O1Ixp33_ASAP7_75t_L g225 ( 
.A1(n_216),
.A2(n_198),
.B(n_201),
.C(n_206),
.Y(n_225)
);

OAI21xp5_ASAP7_75t_L g226 ( 
.A1(n_221),
.A2(n_201),
.B(n_204),
.Y(n_226)
);

NAND2xp5_ASAP7_75t_L g227 ( 
.A(n_212),
.B(n_200),
.Y(n_227)
);

AND2x2_ASAP7_75t_L g228 ( 
.A(n_222),
.B(n_214),
.Y(n_228)
);

NAND2xp5_ASAP7_75t_SL g229 ( 
.A(n_225),
.B(n_226),
.Y(n_229)
);

AND2x2_ASAP7_75t_L g230 ( 
.A(n_222),
.B(n_223),
.Y(n_230)
);

INVx2_ASAP7_75t_L g231 ( 
.A(n_224),
.Y(n_231)
);

INVx1_ASAP7_75t_L g232 ( 
.A(n_231),
.Y(n_232)
);

O2A1O1Ixp33_ASAP7_75t_L g233 ( 
.A1(n_229),
.A2(n_227),
.B(n_203),
.C(n_208),
.Y(n_233)
);

NAND3xp33_ASAP7_75t_L g234 ( 
.A(n_233),
.B(n_188),
.C(n_185),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_232),
.Y(n_235)
);

INVx1_ASAP7_75t_SL g236 ( 
.A(n_235),
.Y(n_236)
);

HB1xp67_ASAP7_75t_L g237 ( 
.A(n_236),
.Y(n_237)
);

BUFx2_ASAP7_75t_L g238 ( 
.A(n_237),
.Y(n_238)
);

INVxp33_ASAP7_75t_L g239 ( 
.A(n_238),
.Y(n_239)
);

O2A1O1Ixp5_ASAP7_75t_SL g240 ( 
.A1(n_239),
.A2(n_234),
.B(n_218),
.C(n_219),
.Y(n_240)
);

NAND4xp25_ASAP7_75t_L g241 ( 
.A(n_240),
.B(n_211),
.C(n_188),
.D(n_207),
.Y(n_241)
);

AOI22xp33_ASAP7_75t_L g242 ( 
.A1(n_241),
.A2(n_230),
.B1(n_228),
.B2(n_215),
.Y(n_242)
);

AOI22xp33_ASAP7_75t_L g243 ( 
.A1(n_242),
.A2(n_178),
.B1(n_194),
.B2(n_217),
.Y(n_243)
);


endmodule