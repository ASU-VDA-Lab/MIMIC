module fake_netlist_865_38_n_15 (n_2, n_0, n_1, n_15);

input n_2;
input n_0;
input n_1;

output n_15;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_1),
.Y(n_5)
);

AO21x2_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_6)
);

AO21x2_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OR2x6_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_1),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_7),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_6),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_6),
.B(n_10),
.Y(n_13)
);

AOI21x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B(n_0),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);


endmodule