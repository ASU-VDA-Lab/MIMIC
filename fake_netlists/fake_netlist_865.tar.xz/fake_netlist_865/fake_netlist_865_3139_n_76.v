module fake_netlist_865_3139_n_76 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_76);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_76;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_70;
wire n_50;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_68;
wire n_26;
wire n_72;
wire n_71;
wire n_73;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_69;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_74;
wire n_55;
wire n_65;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_75;
wire n_27;
wire n_67;
wire n_45;
wire n_46;
wire n_51;

AND2x2_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_10),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_11),
.B(n_14),
.Y(n_27)
);

BUFx8_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_21),
.A2(n_5),
.B1(n_4),
.B2(n_22),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_13),
.B(n_6),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_20),
.B(n_1),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_22),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_17),
.B(n_3),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_19),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_12),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_21),
.B(n_7),
.Y(n_36)
);

BUFx3_ASAP7_75t_L g37 ( 
.A(n_26),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_16),
.Y(n_38)
);

O2A1O1Ixp5_ASAP7_75t_L g39 ( 
.A1(n_27),
.A2(n_8),
.B(n_2),
.C(n_0),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_26),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_32),
.B(n_16),
.Y(n_42)
);

OAI22x1_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_29),
.B1(n_28),
.B2(n_34),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_37),
.A2(n_27),
.B(n_35),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_37),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_40),
.B(n_26),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_43),
.A2(n_40),
.B1(n_41),
.B2(n_42),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_29),
.B1(n_28),
.B2(n_38),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_44),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_51),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_41),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_50),
.B(n_28),
.Y(n_57)
);

XNOR2x1_ASAP7_75t_L g58 ( 
.A(n_57),
.B(n_17),
.Y(n_58)
);

OAI221xp5_ASAP7_75t_L g59 ( 
.A1(n_54),
.A2(n_53),
.B1(n_56),
.B2(n_55),
.C(n_39),
.Y(n_59)
);

AOI22xp5_ASAP7_75t_L g60 ( 
.A1(n_56),
.A2(n_28),
.B1(n_27),
.B2(n_33),
.Y(n_60)
);

AOI21xp5_ASAP7_75t_L g61 ( 
.A1(n_55),
.A2(n_27),
.B(n_31),
.Y(n_61)
);

OAI21xp33_ASAP7_75t_L g62 ( 
.A1(n_57),
.A2(n_33),
.B(n_31),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_58),
.Y(n_63)
);

AOI322xp5_ASAP7_75t_L g64 ( 
.A1(n_62),
.A2(n_35),
.A3(n_26),
.B1(n_36),
.B2(n_23),
.C1(n_18),
.C2(n_24),
.Y(n_64)
);

NOR5xp2_ASAP7_75t_L g65 ( 
.A(n_59),
.B(n_24),
.C(n_23),
.D(n_18),
.E(n_25),
.Y(n_65)
);

NOR2x1_ASAP7_75t_L g66 ( 
.A(n_61),
.B(n_25),
.Y(n_66)
);

AOI21xp5_ASAP7_75t_L g67 ( 
.A1(n_60),
.A2(n_30),
.B(n_59),
.Y(n_67)
);

AND2x4_ASAP7_75t_L g68 ( 
.A(n_67),
.B(n_30),
.Y(n_68)
);

XNOR2xp5_ASAP7_75t_L g69 ( 
.A(n_63),
.B(n_66),
.Y(n_69)
);

INVx3_ASAP7_75t_L g70 ( 
.A(n_65),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_64),
.Y(n_71)
);

XNOR2xp5_ASAP7_75t_L g72 ( 
.A(n_69),
.B(n_71),
.Y(n_72)
);

AOI22xp5_ASAP7_75t_L g73 ( 
.A1(n_71),
.A2(n_68),
.B1(n_69),
.B2(n_70),
.Y(n_73)
);

INVx2_ASAP7_75t_L g74 ( 
.A(n_70),
.Y(n_74)
);

AOI21xp5_ASAP7_75t_L g75 ( 
.A1(n_74),
.A2(n_68),
.B(n_70),
.Y(n_75)
);

AO221x2_ASAP7_75t_L g76 ( 
.A1(n_75),
.A2(n_72),
.B1(n_73),
.B2(n_68),
.C(n_70),
.Y(n_76)
);


endmodule