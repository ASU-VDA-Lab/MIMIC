module fake_netlist_865_3216_n_59 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_59);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_59;

wire n_48;
wire n_49;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_30;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx3_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_5),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_4),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_11),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_SL g33 ( 
.A(n_26),
.B(n_3),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_12),
.A2(n_0),
.B(n_24),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_25),
.B(n_6),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_SL g36 ( 
.A1(n_1),
.A2(n_14),
.B1(n_22),
.B2(n_10),
.Y(n_36)
);

OA21x2_ASAP7_75t_L g37 ( 
.A1(n_7),
.A2(n_19),
.B(n_23),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_31),
.Y(n_39)
);

CKINVDCx16_ASAP7_75t_R g40 ( 
.A(n_32),
.Y(n_40)
);

AND2x6_ASAP7_75t_L g41 ( 
.A(n_27),
.B(n_2),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_28),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

BUFx8_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_40),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_34),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_44),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_24),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

AOI21xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_35),
.B(n_37),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_36),
.B1(n_30),
.B2(n_29),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_44),
.Y(n_54)
);

CKINVDCx5p33_ASAP7_75t_R g55 ( 
.A(n_51),
.Y(n_55)
);

HB1xp67_ASAP7_75t_L g56 ( 
.A(n_55),
.Y(n_56)
);

AO22x2_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_33),
.B1(n_37),
.B2(n_8),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_54),
.B1(n_15),
.B2(n_13),
.Y(n_58)
);

AO221x2_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_56),
.B1(n_18),
.B2(n_16),
.C(n_17),
.Y(n_59)
);


endmodule