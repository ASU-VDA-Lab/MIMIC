module fake_netlist_865_225_n_66 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_66);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_66;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_55;
wire n_65;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx2_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_3),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_1),
.B(n_15),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_0),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_10),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_11),
.B(n_7),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_14),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_8),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_6),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_8),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_18),
.Y(n_31)
);

AND3x2_ASAP7_75t_L g32 ( 
.A(n_2),
.B(n_9),
.C(n_13),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_22),
.B(n_0),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_26),
.A2(n_12),
.B(n_4),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

INVxp67_ASAP7_75t_L g36 ( 
.A(n_23),
.Y(n_36)
);

NAND2x1p5_ASAP7_75t_L g37 ( 
.A(n_22),
.B(n_1),
.Y(n_37)
);

OAI22x1_ASAP7_75t_L g38 ( 
.A1(n_23),
.A2(n_9),
.B1(n_5),
.B2(n_3),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_20),
.B(n_5),
.Y(n_39)
);

AOI21xp5_ASAP7_75t_L g40 ( 
.A1(n_26),
.A2(n_13),
.B(n_11),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_24),
.B(n_16),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_19),
.A2(n_17),
.B(n_16),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_SL g43 ( 
.A(n_27),
.B(n_17),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_36),
.B(n_19),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_35),
.B(n_19),
.Y(n_45)
);

NOR3xp33_ASAP7_75t_SL g46 ( 
.A(n_43),
.B(n_28),
.C(n_25),
.Y(n_46)
);

AO31x2_ASAP7_75t_L g47 ( 
.A1(n_38),
.A2(n_42),
.A3(n_40),
.B(n_41),
.Y(n_47)
);

AO31x2_ASAP7_75t_L g48 ( 
.A1(n_39),
.A2(n_34),
.A3(n_37),
.B(n_32),
.Y(n_48)
);

NAND2xp33_ASAP7_75t_R g49 ( 
.A(n_37),
.B(n_21),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_SL g50 ( 
.A1(n_43),
.A2(n_31),
.B1(n_30),
.B2(n_21),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_33),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_44),
.B(n_33),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_45),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_45),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_47),
.B(n_32),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_51),
.A2(n_52),
.B1(n_55),
.B2(n_49),
.Y(n_56)
);

INVxp67_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

AOI211xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_52),
.B(n_51),
.C(n_54),
.Y(n_59)
);

OAI221xp5_ASAP7_75t_SL g60 ( 
.A1(n_56),
.A2(n_50),
.B1(n_55),
.B2(n_30),
.C(n_31),
.Y(n_60)
);

NOR4xp25_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_55),
.C(n_47),
.D(n_46),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_59),
.Y(n_62)
);

NOR2x1_ASAP7_75t_L g63 ( 
.A(n_60),
.B(n_58),
.Y(n_63)
);

OAI22xp5_ASAP7_75t_L g64 ( 
.A1(n_62),
.A2(n_59),
.B1(n_61),
.B2(n_29),
.Y(n_64)
);

AOI22xp5_ASAP7_75t_L g65 ( 
.A1(n_63),
.A2(n_47),
.B1(n_48),
.B2(n_62),
.Y(n_65)
);

AOI22xp5_ASAP7_75t_L g66 ( 
.A1(n_64),
.A2(n_48),
.B1(n_65),
.B2(n_62),
.Y(n_66)
);


endmodule