module fake_netlist_865_2138_n_17 (n_2, n_0, n_1, n_17);

input n_2;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_3;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx4_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

A2O1A1Ixp33_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_7)
);

BUFx3_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_5),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_5),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B1(n_7),
.B2(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_SL g12 ( 
.A(n_10),
.Y(n_12)
);

XNOR2x1_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_1),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_6),
.B1(n_3),
.B2(n_5),
.C(n_4),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_5),
.B1(n_8),
.B2(n_9),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_2),
.B(n_11),
.Y(n_16)
);

AOI21xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_2),
.B(n_15),
.Y(n_17)
);


endmodule