module fake_netlist_770_1655_n_26 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_26);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_26;

wire n_20;
wire n_17;
wire n_25;
wire n_24;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx3_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_12),
.B(n_2),
.C(n_1),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_16),
.B(n_14),
.Y(n_22)
);

AOI211xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B(n_17),
.C(n_12),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AO22x2_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_7),
.B1(n_5),
.B2(n_3),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_R g26 ( 
.A1(n_25),
.A2(n_13),
.B1(n_11),
.B2(n_10),
.Y(n_26)
);


endmodule