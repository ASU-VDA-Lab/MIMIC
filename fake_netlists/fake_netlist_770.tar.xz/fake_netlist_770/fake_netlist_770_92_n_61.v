module fake_netlist_770_92_n_61 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_14, n_61);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_14;

output n_61;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_48;
wire n_43;
wire n_49;
wire n_56;
wire n_38;
wire n_54;
wire n_60;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_59;
wire n_53;
wire n_41;
wire n_51;
wire n_32;
wire n_22;

INVx2_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_3),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_7),
.B(n_13),
.Y(n_29)
);

CKINVDCx16_ASAP7_75t_R g30 ( 
.A(n_8),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_4),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_2),
.B(n_9),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_19),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_14),
.B(n_13),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_30),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_29),
.B(n_15),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_24),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_29),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_28),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_29),
.B(n_15),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_31),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_27),
.A2(n_21),
.B1(n_20),
.B2(n_17),
.Y(n_42)
);

OAI21x1_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_22),
.B(n_32),
.Y(n_43)
);

OAI21x1_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_41),
.B(n_36),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_35),
.Y(n_45)
);

OAI21x1_ASAP7_75t_L g46 ( 
.A1(n_41),
.A2(n_26),
.B(n_34),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_36),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_37),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_36),
.Y(n_49)
);

INVx2_ASAP7_75t_SL g50 ( 
.A(n_48),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_43),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_52),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_25),
.B1(n_40),
.B2(n_49),
.Y(n_54)
);

OAI22xp33_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_38),
.B1(n_23),
.B2(n_40),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

NOR2xp33_ASAP7_75t_L g57 ( 
.A(n_56),
.B(n_17),
.Y(n_57)
);

AND2x4_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_33),
.Y(n_58)
);

OR3x1_ASAP7_75t_L g59 ( 
.A(n_57),
.B(n_6),
.C(n_5),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_58),
.B1(n_12),
.B2(n_10),
.Y(n_60)
);

INVxp67_ASAP7_75t_L g61 ( 
.A(n_60),
.Y(n_61)
);


endmodule