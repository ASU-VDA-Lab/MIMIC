module fake_netlist_770_799_n_16 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_16);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_16;

wire n_15;
wire n_11;
wire n_12;
wire n_9;
wire n_8;
wire n_10;
wire n_13;
wire n_14;

AND2x6_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_7),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx5_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

OAI322xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.A3(n_6),
.B1(n_7),
.B2(n_4),
.C1(n_8),
.C2(n_11),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B(n_1),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_6),
.B1(n_5),
.B2(n_2),
.Y(n_16)
);


endmodule