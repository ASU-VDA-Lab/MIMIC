module fake_netlist_770_1144_n_11 (n_1, n_2, n_3, n_0, n_11);

input n_1;
input n_2;
input n_3;
input n_0;

output n_11;

wire n_7;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_4;
wire n_8;

AND2x2_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_3),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

AOI21xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

OAI322xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.A3(n_2),
.B1(n_3),
.B2(n_4),
.C1(n_5),
.C2(n_6),
.Y(n_8)
);

NAND4xp25_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_4),
.C(n_5),
.D(n_1),
.Y(n_9)
);

AO21x2_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_2),
.B(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);


endmodule