module fake_netlist_770_163_n_45 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_45);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_45;

wire n_37;
wire n_44;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_18;
wire n_43;
wire n_15;
wire n_16;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_41;
wire n_32;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_0),
.B(n_10),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_0),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_12),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_11),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_15),
.B(n_19),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_15),
.B(n_1),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_2),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

NAND3xp33_ASAP7_75t_SL g27 ( 
.A(n_14),
.B(n_4),
.C(n_3),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_20),
.B1(n_19),
.B2(n_22),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_17),
.Y(n_30)
);

OAI211xp5_ASAP7_75t_SL g31 ( 
.A1(n_28),
.A2(n_25),
.B(n_24),
.C(n_20),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_19),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_SL g33 ( 
.A1(n_29),
.A2(n_16),
.B1(n_27),
.B2(n_21),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_30),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_SL g38 ( 
.A1(n_35),
.A2(n_29),
.B1(n_31),
.B2(n_3),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

XOR2xp5_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_39),
.Y(n_42)
);

NAND4xp25_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_9),
.C(n_7),
.D(n_5),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

AOI222xp33_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_13),
.B1(n_42),
.B2(n_39),
.C1(n_38),
.C2(n_20),
.Y(n_45)
);


endmodule