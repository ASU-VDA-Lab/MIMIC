module fake_netlist_770_476_n_38 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_38);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_38;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_18;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

INVx1_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

AND3x1_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_2),
.C(n_0),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx4_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_23),
.Y(n_27)
);

INVx4_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

OA222x2_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_24),
.B1(n_22),
.B2(n_20),
.C1(n_18),
.C2(n_5),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_28),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_8),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_9),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_10),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI222xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_36),
.B1(n_15),
.B2(n_11),
.C1(n_16),
.C2(n_12),
.Y(n_38)
);


endmodule