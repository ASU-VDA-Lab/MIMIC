module fake_netlist_770_1005_n_19 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_19);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_19;

wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_10;
wire n_14;

INVx1_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

NOR2xp67_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_4),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.B1(n_1),
.B2(n_0),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_9),
.C(n_11),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_4),
.B2(n_2),
.C(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

OAI22x1_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_15),
.B1(n_3),
.B2(n_2),
.Y(n_18)
);

AOI322xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_5),
.A3(n_6),
.B1(n_8),
.B2(n_17),
.C1(n_10),
.C2(n_9),
.Y(n_19)
);


endmodule