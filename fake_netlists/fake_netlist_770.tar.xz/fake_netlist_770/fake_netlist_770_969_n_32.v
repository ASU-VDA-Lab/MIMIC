module fake_netlist_770_969_n_32 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_32);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_32;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_31;
wire n_27;
wire n_26;
wire n_24;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_22;

CKINVDCx16_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

NAND2xp33_ASAP7_75t_R g16 ( 
.A(n_0),
.B(n_5),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

OR2x6_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_6),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_12),
.Y(n_21)
);

O2A1O1Ixp5_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_10),
.B(n_9),
.C(n_2),
.Y(n_22)
);

AND2x6_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_11),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_15),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_19),
.Y(n_26)
);

NAND3xp33_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.C(n_24),
.Y(n_27)
);

AOI221x1_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_22),
.B1(n_16),
.B2(n_18),
.C(n_20),
.Y(n_28)
);

CKINVDCx6p67_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

OAI21xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_18),
.B(n_4),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_29),
.B1(n_7),
.B2(n_4),
.Y(n_32)
);


endmodule