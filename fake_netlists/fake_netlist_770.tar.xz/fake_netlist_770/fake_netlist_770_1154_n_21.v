module fake_netlist_770_1154_n_21 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_21);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_21;

wire n_20;
wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_8;
wire n_9;
wire n_10;
wire n_19;
wire n_14;

CKINVDCx20_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_2),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_3),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

INVx4_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_11),
.B(n_0),
.Y(n_13)
);

OAI22xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_8),
.B2(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_9),
.B(n_12),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.C(n_1),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AOI22x1_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_19),
.B1(n_6),
.B2(n_4),
.Y(n_21)
);


endmodule