module fake_netlist_770_119_n_54 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_24, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_54);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_24;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_54;

wire n_37;
wire n_45;
wire n_44;
wire n_52;
wire n_36;
wire n_29;
wire n_50;
wire n_35;
wire n_25;
wire n_40;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_42;
wire n_26;
wire n_48;
wire n_43;
wire n_49;
wire n_38;
wire n_28;
wire n_30;
wire n_53;
wire n_41;
wire n_51;
wire n_32;
wire n_47;

INVx2_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_16),
.B(n_0),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_5),
.Y(n_27)
);

OA21x2_ASAP7_75t_L g28 ( 
.A1(n_11),
.A2(n_10),
.B(n_15),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_6),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_19),
.B(n_23),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_8),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_18),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_13),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

INVx2_ASAP7_75t_SL g36 ( 
.A(n_33),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_25),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_30),
.B(n_24),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

INVx4_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

OAI31xp33_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_38),
.A3(n_26),
.B(n_40),
.Y(n_44)
);

OAI22xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_32),
.B1(n_31),
.B2(n_33),
.Y(n_45)
);

INVxp67_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

OAI221xp5_ASAP7_75t_SL g47 ( 
.A1(n_44),
.A2(n_28),
.B1(n_29),
.B2(n_27),
.C(n_1),
.Y(n_47)
);

INVx1_ASAP7_75t_SL g48 ( 
.A(n_46),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

NOR3xp33_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_28),
.C(n_3),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_49),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_51),
.B(n_4),
.Y(n_52)
);

AOI221xp5_ASAP7_75t_SL g53 ( 
.A1(n_50),
.A2(n_9),
.B1(n_7),
.B2(n_12),
.C(n_14),
.Y(n_53)
);

AOI222xp33_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_17),
.B1(n_20),
.B2(n_21),
.C1(n_22),
.C2(n_53),
.Y(n_54)
);


endmodule