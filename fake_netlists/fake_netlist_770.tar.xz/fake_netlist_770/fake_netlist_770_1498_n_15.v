module fake_netlist_770_1498_n_15 (n_1, n_2, n_3, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_0;

output n_15;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_14;
wire n_8;
wire n_12;
wire n_13;
wire n_4;
wire n_9;

AND2x6_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

OAI22xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_2),
.Y(n_11)
);

OAI211xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B(n_9),
.C(n_3),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_9),
.B(n_3),
.C(n_2),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_10),
.B2(n_3),
.Y(n_14)
);

AOI31xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_9),
.A3(n_12),
.B(n_13),
.Y(n_15)
);


endmodule