module fake_netlist_770_24_n_29 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_4, n_8, n_29);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_4;
input n_8;

output n_29;

wire n_20;
wire n_17;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_10),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_7),
.B(n_11),
.C(n_8),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_6),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_6),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_19),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_20),
.Y(n_24)
);

XOR2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_17),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_25),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_R g28 ( 
.A1(n_27),
.A2(n_16),
.B1(n_15),
.B2(n_17),
.Y(n_28)
);

AOI322xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.A3(n_18),
.B1(n_3),
.B2(n_4),
.C1(n_1),
.C2(n_2),
.Y(n_29)
);


endmodule