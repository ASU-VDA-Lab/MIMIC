module fake_netlist_770_1341_n_15 (n_1, n_2, n_3, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_0;

output n_15;

wire n_7;
wire n_10;
wire n_13;
wire n_11;
wire n_5;
wire n_6;
wire n_9;
wire n_12;
wire n_14;
wire n_4;
wire n_8;

BUFx3_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

NOR2xp67_ASAP7_75t_SL g6 ( 
.A(n_5),
.B(n_1),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_4),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AOI321xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.A3(n_3),
.B1(n_0),
.B2(n_2),
.C(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

OA22x2_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_1),
.B1(n_0),
.B2(n_5),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_5),
.B1(n_13),
.B2(n_11),
.Y(n_15)
);


endmodule