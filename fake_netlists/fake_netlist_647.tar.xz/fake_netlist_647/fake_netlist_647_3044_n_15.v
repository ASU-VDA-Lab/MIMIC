module fake_netlist_647_3044_n_15 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_15);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_15;

wire n_9;
wire n_7;
wire n_14;
wire n_13;
wire n_10;
wire n_12;
wire n_8;
wire n_11;

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_3),
.B1(n_5),
.B2(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_4),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

INVx4_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND4xp25_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_9),
.C(n_11),
.D(n_8),
.Y(n_13)
);

AO22x2_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_6),
.B1(n_11),
.B2(n_12),
.Y(n_15)
);


endmodule