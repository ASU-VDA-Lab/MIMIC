module fake_netlist_647_2957_n_6 (n_1, n_0, n_6);

input n_1;
input n_0;

output n_6;

wire n_4;
wire n_2;
wire n_5;
wire n_3;

INVx1_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

OR2x2_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

AOI22xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_4)
);

AOI221xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_3),
.Y(n_5)
);

OAI221xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_4),
.C(n_3),
.Y(n_6)
);


endmodule