module fake_netlist_647_2194_n_22 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_22);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_22;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

INVx5_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_4),
.B(n_8),
.Y(n_11)
);

AOI21x1_ASAP7_75t_L g12 ( 
.A1(n_0),
.A2(n_9),
.B(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_2),
.B(n_1),
.Y(n_16)
);

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_15),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_13),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_11),
.B1(n_16),
.B2(n_10),
.Y(n_19)
);

NOR2x1p5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI21x1_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_3),
.B(n_16),
.Y(n_22)
);


endmodule