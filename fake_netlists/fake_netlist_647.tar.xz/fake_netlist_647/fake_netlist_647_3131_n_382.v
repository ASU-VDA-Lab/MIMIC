module fake_netlist_647_3131_n_382 (n_18, n_62, n_70, n_90, n_38, n_58, n_57, n_84, n_35, n_89, n_7, n_96, n_45, n_78, n_66, n_23, n_60, n_22, n_39, n_63, n_31, n_9, n_81, n_37, n_71, n_91, n_92, n_5, n_10, n_40, n_28, n_15, n_49, n_53, n_77, n_75, n_48, n_12, n_4, n_17, n_93, n_41, n_65, n_33, n_13, n_43, n_82, n_85, n_61, n_72, n_51, n_25, n_54, n_86, n_68, n_20, n_16, n_3, n_14, n_21, n_27, n_67, n_29, n_52, n_50, n_26, n_76, n_83, n_8, n_6, n_36, n_59, n_19, n_97, n_34, n_1, n_64, n_0, n_44, n_24, n_87, n_11, n_79, n_30, n_73, n_56, n_98, n_69, n_94, n_46, n_42, n_2, n_55, n_95, n_74, n_32, n_47, n_80, n_88, n_382);

input n_18;
input n_62;
input n_70;
input n_90;
input n_38;
input n_58;
input n_57;
input n_84;
input n_35;
input n_89;
input n_7;
input n_96;
input n_45;
input n_78;
input n_66;
input n_23;
input n_60;
input n_22;
input n_39;
input n_63;
input n_31;
input n_9;
input n_81;
input n_37;
input n_71;
input n_91;
input n_92;
input n_5;
input n_10;
input n_40;
input n_28;
input n_15;
input n_49;
input n_53;
input n_77;
input n_75;
input n_48;
input n_12;
input n_4;
input n_17;
input n_93;
input n_41;
input n_65;
input n_33;
input n_13;
input n_43;
input n_82;
input n_85;
input n_61;
input n_72;
input n_51;
input n_25;
input n_54;
input n_86;
input n_68;
input n_20;
input n_16;
input n_3;
input n_14;
input n_21;
input n_27;
input n_67;
input n_29;
input n_52;
input n_50;
input n_26;
input n_76;
input n_83;
input n_8;
input n_6;
input n_36;
input n_59;
input n_19;
input n_97;
input n_34;
input n_1;
input n_64;
input n_0;
input n_44;
input n_24;
input n_87;
input n_11;
input n_79;
input n_30;
input n_73;
input n_56;
input n_98;
input n_69;
input n_94;
input n_46;
input n_42;
input n_2;
input n_55;
input n_95;
input n_74;
input n_32;
input n_47;
input n_80;
input n_88;

output n_382;

wire n_326;
wire n_101;
wire n_313;
wire n_209;
wire n_321;
wire n_245;
wire n_164;
wire n_118;
wire n_189;
wire n_306;
wire n_275;
wire n_183;
wire n_173;
wire n_260;
wire n_190;
wire n_362;
wire n_187;
wire n_238;
wire n_201;
wire n_294;
wire n_331;
wire n_217;
wire n_300;
wire n_241;
wire n_345;
wire n_161;
wire n_234;
wire n_259;
wire n_312;
wire n_180;
wire n_142;
wire n_232;
wire n_379;
wire n_143;
wire n_122;
wire n_323;
wire n_250;
wire n_227;
wire n_365;
wire n_176;
wire n_160;
wire n_156;
wire n_317;
wire n_174;
wire n_349;
wire n_175;
wire n_368;
wire n_195;
wire n_112;
wire n_303;
wire n_169;
wire n_322;
wire n_103;
wire n_162;
wire n_228;
wire n_343;
wire n_265;
wire n_145;
wire n_215;
wire n_205;
wire n_361;
wire n_171;
wire n_337;
wire n_222;
wire n_158;
wire n_354;
wire n_285;
wire n_350;
wire n_114;
wire n_272;
wire n_99;
wire n_318;
wire n_144;
wire n_155;
wire n_270;
wire n_377;
wire n_214;
wire n_116;
wire n_218;
wire n_235;
wire n_191;
wire n_256;
wire n_369;
wire n_177;
wire n_269;
wire n_286;
wire n_357;
wire n_266;
wire n_163;
wire n_105;
wire n_329;
wire n_230;
wire n_223;
wire n_371;
wire n_278;
wire n_282;
wire n_283;
wire n_336;
wire n_151;
wire n_346;
wire n_199;
wire n_364;
wire n_372;
wire n_219;
wire n_119;
wire n_310;
wire n_182;
wire n_149;
wire n_341;
wire n_359;
wire n_281;
wire n_202;
wire n_298;
wire n_167;
wire n_237;
wire n_104;
wire n_284;
wire n_291;
wire n_146;
wire n_325;
wire n_196;
wire n_200;
wire n_106;
wire n_355;
wire n_258;
wire n_115;
wire n_307;
wire n_128;
wire n_126;
wire n_339;
wire n_147;
wire n_352;
wire n_267;
wire n_186;
wire n_297;
wire n_316;
wire n_293;
wire n_166;
wire n_247;
wire n_344;
wire n_327;
wire n_220;
wire n_358;
wire n_296;
wire n_347;
wire n_154;
wire n_194;
wire n_184;
wire n_376;
wire n_288;
wire n_121;
wire n_381;
wire n_157;
wire n_290;
wire n_117;
wire n_360;
wire n_136;
wire n_276;
wire n_170;
wire n_314;
wire n_207;
wire n_279;
wire n_338;
wire n_181;
wire n_213;
wire n_240;
wire n_208;
wire n_273;
wire n_320;
wire n_308;
wire n_229;
wire n_301;
wire n_380;
wire n_198;
wire n_248;
wire n_253;
wire n_335;
wire n_179;
wire n_254;
wire n_150;
wire n_374;
wire n_305;
wire n_148;
wire n_159;
wire n_141;
wire n_123;
wire n_309;
wire n_353;
wire n_185;
wire n_328;
wire n_132;
wire n_367;
wire n_224;
wire n_264;
wire n_366;
wire n_138;
wire n_239;
wire n_274;
wire n_315;
wire n_287;
wire n_102;
wire n_135;
wire n_178;
wire n_324;
wire n_255;
wire n_334;
wire n_311;
wire n_375;
wire n_168;
wire n_348;
wire n_139;
wire n_252;
wire n_152;
wire n_172;
wire n_107;
wire n_342;
wire n_261;
wire n_137;
wire n_197;
wire n_363;
wire n_243;
wire n_211;
wire n_206;
wire n_192;
wire n_124;
wire n_165;
wire n_263;
wire n_302;
wire n_244;
wire n_125;
wire n_333;
wire n_304;
wire n_110;
wire n_378;
wire n_203;
wire n_109;
wire n_340;
wire n_277;
wire n_204;
wire n_120;
wire n_246;
wire n_242;
wire n_257;
wire n_231;
wire n_226;
wire n_280;
wire n_130;
wire n_233;
wire n_210;
wire n_140;
wire n_262;
wire n_299;
wire n_249;
wire n_292;
wire n_251;
wire n_332;
wire n_113;
wire n_127;
wire n_236;
wire n_100;
wire n_129;
wire n_134;
wire n_330;
wire n_319;
wire n_133;
wire n_225;
wire n_131;
wire n_295;
wire n_108;
wire n_268;
wire n_212;
wire n_221;
wire n_271;
wire n_356;
wire n_193;
wire n_289;
wire n_153;
wire n_216;
wire n_373;
wire n_351;
wire n_188;
wire n_370;
wire n_111;

BUFx6f_ASAP7_75t_L g99 ( 
.A(n_98),
.Y(n_99)
);

INVx2_ASAP7_75t_SL g100 ( 
.A(n_11),
.Y(n_100)
);

INVx2_ASAP7_75t_L g101 ( 
.A(n_81),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_97),
.Y(n_102)
);

CKINVDCx5p33_ASAP7_75t_R g103 ( 
.A(n_87),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_71),
.Y(n_104)
);

CKINVDCx20_ASAP7_75t_R g105 ( 
.A(n_83),
.Y(n_105)
);

CKINVDCx5p33_ASAP7_75t_R g106 ( 
.A(n_96),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_82),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_41),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_15),
.Y(n_109)
);

CKINVDCx5p33_ASAP7_75t_R g110 ( 
.A(n_17),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_52),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_90),
.Y(n_112)
);

INVx2_ASAP7_75t_SL g113 ( 
.A(n_88),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_80),
.Y(n_114)
);

CKINVDCx5p33_ASAP7_75t_R g115 ( 
.A(n_64),
.Y(n_115)
);

HB1xp67_ASAP7_75t_L g116 ( 
.A(n_1),
.Y(n_116)
);

CKINVDCx5p33_ASAP7_75t_R g117 ( 
.A(n_13),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_53),
.Y(n_118)
);

BUFx3_ASAP7_75t_L g119 ( 
.A(n_29),
.Y(n_119)
);

INVx1_ASAP7_75t_L g120 ( 
.A(n_94),
.Y(n_120)
);

INVx2_ASAP7_75t_L g121 ( 
.A(n_2),
.Y(n_121)
);

BUFx6f_ASAP7_75t_L g122 ( 
.A(n_32),
.Y(n_122)
);

INVx4_ASAP7_75t_R g123 ( 
.A(n_42),
.Y(n_123)
);

HB1xp67_ASAP7_75t_L g124 ( 
.A(n_95),
.Y(n_124)
);

CKINVDCx5p33_ASAP7_75t_R g125 ( 
.A(n_54),
.Y(n_125)
);

CKINVDCx5p33_ASAP7_75t_R g126 ( 
.A(n_56),
.Y(n_126)
);

CKINVDCx16_ASAP7_75t_R g127 ( 
.A(n_72),
.Y(n_127)
);

CKINVDCx20_ASAP7_75t_R g128 ( 
.A(n_91),
.Y(n_128)
);

BUFx2_ASAP7_75t_L g129 ( 
.A(n_66),
.Y(n_129)
);

CKINVDCx5p33_ASAP7_75t_R g130 ( 
.A(n_35),
.Y(n_130)
);

BUFx6f_ASAP7_75t_L g131 ( 
.A(n_89),
.Y(n_131)
);

INVx1_ASAP7_75t_SL g132 ( 
.A(n_23),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_18),
.Y(n_133)
);

CKINVDCx5p33_ASAP7_75t_R g134 ( 
.A(n_79),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_45),
.Y(n_135)
);

CKINVDCx5p33_ASAP7_75t_R g136 ( 
.A(n_73),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_67),
.Y(n_137)
);

CKINVDCx5p33_ASAP7_75t_R g138 ( 
.A(n_92),
.Y(n_138)
);

HB1xp67_ASAP7_75t_L g139 ( 
.A(n_65),
.Y(n_139)
);

INVx1_ASAP7_75t_L g140 ( 
.A(n_61),
.Y(n_140)
);

INVx1_ASAP7_75t_SL g141 ( 
.A(n_28),
.Y(n_141)
);

BUFx6f_ASAP7_75t_L g142 ( 
.A(n_22),
.Y(n_142)
);

BUFx3_ASAP7_75t_L g143 ( 
.A(n_93),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_69),
.Y(n_144)
);

INVx1_ASAP7_75t_L g145 ( 
.A(n_60),
.Y(n_145)
);

CKINVDCx5p33_ASAP7_75t_R g146 ( 
.A(n_76),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_86),
.Y(n_147)
);

CKINVDCx5p33_ASAP7_75t_R g148 ( 
.A(n_78),
.Y(n_148)
);

CKINVDCx5p33_ASAP7_75t_R g149 ( 
.A(n_85),
.Y(n_149)
);

BUFx2_ASAP7_75t_SL g150 ( 
.A(n_49),
.Y(n_150)
);

CKINVDCx5p33_ASAP7_75t_R g151 ( 
.A(n_84),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_5),
.Y(n_152)
);

INVx2_ASAP7_75t_L g153 ( 
.A(n_16),
.Y(n_153)
);

CKINVDCx16_ASAP7_75t_R g154 ( 
.A(n_7),
.Y(n_154)
);

CKINVDCx5p33_ASAP7_75t_R g155 ( 
.A(n_55),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_12),
.Y(n_156)
);

INVx3_ASAP7_75t_L g157 ( 
.A(n_121),
.Y(n_157)
);

INVx2_ASAP7_75t_L g158 ( 
.A(n_99),
.Y(n_158)
);

INVx4_ASAP7_75t_L g159 ( 
.A(n_99),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_102),
.Y(n_160)
);

OAI22xp5_ASAP7_75t_L g161 ( 
.A1(n_116),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_161)
);

BUFx2_ASAP7_75t_L g162 ( 
.A(n_129),
.Y(n_162)
);

INVx4_ASAP7_75t_L g163 ( 
.A(n_99),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_104),
.Y(n_164)
);

CKINVDCx6p67_ASAP7_75t_R g165 ( 
.A(n_127),
.Y(n_165)
);

NAND2xp5_ASAP7_75t_SL g166 ( 
.A(n_154),
.B(n_0),
.Y(n_166)
);

OA21x2_ASAP7_75t_L g167 ( 
.A1(n_107),
.A2(n_4),
.B(n_3),
.Y(n_167)
);

NOR2x1_ASAP7_75t_L g168 ( 
.A(n_119),
.B(n_3),
.Y(n_168)
);

INVx2_ASAP7_75t_L g169 ( 
.A(n_122),
.Y(n_169)
);

AND2x4_ASAP7_75t_L g170 ( 
.A(n_143),
.B(n_6),
.Y(n_170)
);

NAND2xp5_ASAP7_75t_SL g171 ( 
.A(n_166),
.B(n_124),
.Y(n_171)
);

INVx2_ASAP7_75t_L g172 ( 
.A(n_158),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_169),
.Y(n_173)
);

NAND2xp5_ASAP7_75t_L g174 ( 
.A(n_170),
.B(n_100),
.Y(n_174)
);

INVx2_ASAP7_75t_L g175 ( 
.A(n_169),
.Y(n_175)
);

INVx2_ASAP7_75t_L g176 ( 
.A(n_159),
.Y(n_176)
);

INVx4_ASAP7_75t_L g177 ( 
.A(n_159),
.Y(n_177)
);

BUFx6f_ASAP7_75t_L g178 ( 
.A(n_163),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_160),
.Y(n_179)
);

NAND2xp5_ASAP7_75t_L g180 ( 
.A(n_170),
.B(n_113),
.Y(n_180)
);

NAND2xp5_ASAP7_75t_L g181 ( 
.A(n_174),
.B(n_163),
.Y(n_181)
);

NOR3xp33_ASAP7_75t_L g182 ( 
.A(n_171),
.B(n_166),
.C(n_161),
.Y(n_182)
);

NAND2xp5_ASAP7_75t_L g183 ( 
.A(n_180),
.B(n_164),
.Y(n_183)
);

BUFx6f_ASAP7_75t_SL g184 ( 
.A(n_179),
.Y(n_184)
);

NAND2xp5_ASAP7_75t_L g185 ( 
.A(n_176),
.B(n_139),
.Y(n_185)
);

NOR2xp33_ASAP7_75t_L g186 ( 
.A(n_177),
.B(n_165),
.Y(n_186)
);

AND2x2_ASAP7_75t_L g187 ( 
.A(n_178),
.B(n_162),
.Y(n_187)
);

CKINVDCx5p33_ASAP7_75t_R g188 ( 
.A(n_178),
.Y(n_188)
);

NOR2x1_ASAP7_75t_L g189 ( 
.A(n_186),
.B(n_105),
.Y(n_189)
);

AO21x1_ASAP7_75t_L g190 ( 
.A1(n_182),
.A2(n_161),
.B(n_108),
.Y(n_190)
);

AOI22x1_ASAP7_75t_L g191 ( 
.A1(n_187),
.A2(n_153),
.B1(n_101),
.B2(n_109),
.Y(n_191)
);

OAI21x1_ASAP7_75t_L g192 ( 
.A1(n_181),
.A2(n_175),
.B(n_172),
.Y(n_192)
);

AOI22xp33_ASAP7_75t_L g193 ( 
.A1(n_183),
.A2(n_167),
.B1(n_112),
.B2(n_111),
.Y(n_193)
);

AOI21x1_ASAP7_75t_L g194 ( 
.A1(n_185),
.A2(n_173),
.B(n_114),
.Y(n_194)
);

INVx2_ASAP7_75t_L g195 ( 
.A(n_188),
.Y(n_195)
);

INVx2_ASAP7_75t_L g196 ( 
.A(n_184),
.Y(n_196)
);

INVx3_ASAP7_75t_L g197 ( 
.A(n_184),
.Y(n_197)
);

OAI21x1_ASAP7_75t_L g198 ( 
.A1(n_192),
.A2(n_173),
.B(n_118),
.Y(n_198)
);

OAI21x1_ASAP7_75t_L g199 ( 
.A1(n_194),
.A2(n_133),
.B(n_120),
.Y(n_199)
);

AOI21xp5_ASAP7_75t_L g200 ( 
.A1(n_193),
.A2(n_141),
.B(n_132),
.Y(n_200)
);

NOR2xp33_ASAP7_75t_L g201 ( 
.A(n_195),
.B(n_128),
.Y(n_201)
);

AND2x4_ASAP7_75t_L g202 ( 
.A(n_197),
.B(n_168),
.Y(n_202)
);

AOI21xp5_ASAP7_75t_L g203 ( 
.A1(n_189),
.A2(n_167),
.B(n_135),
.Y(n_203)
);

AO31x2_ASAP7_75t_L g204 ( 
.A1(n_190),
.A2(n_144),
.A3(n_140),
.B(n_137),
.Y(n_204)
);

INVx1_ASAP7_75t_L g205 ( 
.A(n_191),
.Y(n_205)
);

HB1xp67_ASAP7_75t_L g206 ( 
.A(n_197),
.Y(n_206)
);

AOI21xp5_ASAP7_75t_L g207 ( 
.A1(n_191),
.A2(n_147),
.B(n_145),
.Y(n_207)
);

NAND2xp5_ASAP7_75t_L g208 ( 
.A(n_196),
.B(n_152),
.Y(n_208)
);

AOI31xp67_ASAP7_75t_L g209 ( 
.A1(n_192),
.A2(n_123),
.A3(n_150),
.B(n_122),
.Y(n_209)
);

OAI21x1_ASAP7_75t_L g210 ( 
.A1(n_192),
.A2(n_156),
.B(n_157),
.Y(n_210)
);

AO31x2_ASAP7_75t_L g211 ( 
.A1(n_203),
.A2(n_142),
.A3(n_131),
.B(n_122),
.Y(n_211)
);

NAND2xp5_ASAP7_75t_L g212 ( 
.A(n_201),
.B(n_103),
.Y(n_212)
);

INVx2_ASAP7_75t_SL g213 ( 
.A(n_206),
.Y(n_213)
);

AO31x2_ASAP7_75t_L g214 ( 
.A1(n_205),
.A2(n_142),
.A3(n_131),
.B(n_4),
.Y(n_214)
);

OR2x6_ASAP7_75t_L g215 ( 
.A(n_202),
.B(n_208),
.Y(n_215)
);

AND2x4_ASAP7_75t_L g216 ( 
.A(n_202),
.B(n_8),
.Y(n_216)
);

AND2x4_ASAP7_75t_L g217 ( 
.A(n_204),
.B(n_9),
.Y(n_217)
);

INVx1_ASAP7_75t_L g218 ( 
.A(n_204),
.Y(n_218)
);

OAI21x1_ASAP7_75t_L g219 ( 
.A1(n_198),
.A2(n_157),
.B(n_10),
.Y(n_219)
);

INVx1_ASAP7_75t_L g220 ( 
.A(n_199),
.Y(n_220)
);

NOR2xp33_ASAP7_75t_L g221 ( 
.A(n_200),
.B(n_106),
.Y(n_221)
);

INVx1_ASAP7_75t_L g222 ( 
.A(n_210),
.Y(n_222)
);

INVx3_ASAP7_75t_L g223 ( 
.A(n_209),
.Y(n_223)
);

INVx3_ASAP7_75t_L g224 ( 
.A(n_207),
.Y(n_224)
);

HB1xp67_ASAP7_75t_L g225 ( 
.A(n_206),
.Y(n_225)
);

OAI21x1_ASAP7_75t_L g226 ( 
.A1(n_198),
.A2(n_19),
.B(n_14),
.Y(n_226)
);

INVx1_ASAP7_75t_L g227 ( 
.A(n_208),
.Y(n_227)
);

OAI21x1_ASAP7_75t_L g228 ( 
.A1(n_198),
.A2(n_21),
.B(n_20),
.Y(n_228)
);

OA21x2_ASAP7_75t_L g229 ( 
.A1(n_210),
.A2(n_115),
.B(n_110),
.Y(n_229)
);

NAND2xp5_ASAP7_75t_L g230 ( 
.A(n_201),
.B(n_117),
.Y(n_230)
);

AOI21x1_ASAP7_75t_L g231 ( 
.A1(n_198),
.A2(n_142),
.B(n_131),
.Y(n_231)
);

INVx1_ASAP7_75t_L g232 ( 
.A(n_208),
.Y(n_232)
);

OR3x4_ASAP7_75t_SL g233 ( 
.A(n_201),
.B(n_126),
.C(n_125),
.Y(n_233)
);

NAND2xp5_ASAP7_75t_L g234 ( 
.A(n_201),
.B(n_130),
.Y(n_234)
);

AND2x2_ASAP7_75t_L g235 ( 
.A(n_201),
.B(n_134),
.Y(n_235)
);

INVx1_ASAP7_75t_L g236 ( 
.A(n_218),
.Y(n_236)
);

INVx1_ASAP7_75t_L g237 ( 
.A(n_214),
.Y(n_237)
);

AO21x2_ASAP7_75t_L g238 ( 
.A1(n_222),
.A2(n_138),
.B(n_136),
.Y(n_238)
);

OAI221xp5_ASAP7_75t_L g239 ( 
.A1(n_227),
.A2(n_148),
.B1(n_146),
.B2(n_149),
.C(n_151),
.Y(n_239)
);

INVx1_ASAP7_75t_L g240 ( 
.A(n_214),
.Y(n_240)
);

BUFx3_ASAP7_75t_L g241 ( 
.A(n_213),
.Y(n_241)
);

OA21x2_ASAP7_75t_L g242 ( 
.A1(n_220),
.A2(n_219),
.B(n_231),
.Y(n_242)
);

INVx1_ASAP7_75t_L g243 ( 
.A(n_214),
.Y(n_243)
);

AND2x2_ASAP7_75t_L g244 ( 
.A(n_232),
.B(n_155),
.Y(n_244)
);

INVx1_ASAP7_75t_L g245 ( 
.A(n_224),
.Y(n_245)
);

OR2x6_ASAP7_75t_L g246 ( 
.A(n_216),
.B(n_24),
.Y(n_246)
);

AND2x2_ASAP7_75t_L g247 ( 
.A(n_235),
.B(n_25),
.Y(n_247)
);

OAI21x1_ASAP7_75t_SL g248 ( 
.A1(n_212),
.A2(n_27),
.B(n_26),
.Y(n_248)
);

AND2x2_ASAP7_75t_L g249 ( 
.A(n_216),
.B(n_30),
.Y(n_249)
);

INVx1_ASAP7_75t_L g250 ( 
.A(n_211),
.Y(n_250)
);

BUFx2_ASAP7_75t_L g251 ( 
.A(n_225),
.Y(n_251)
);

AO21x2_ASAP7_75t_L g252 ( 
.A1(n_234),
.A2(n_33),
.B(n_31),
.Y(n_252)
);

INVx1_ASAP7_75t_L g253 ( 
.A(n_211),
.Y(n_253)
);

INVx2_ASAP7_75t_L g254 ( 
.A(n_215),
.Y(n_254)
);

AO21x2_ASAP7_75t_L g255 ( 
.A1(n_230),
.A2(n_36),
.B(n_34),
.Y(n_255)
);

INVx2_ASAP7_75t_L g256 ( 
.A(n_215),
.Y(n_256)
);

OR2x2_ASAP7_75t_L g257 ( 
.A(n_221),
.B(n_37),
.Y(n_257)
);

AND2x4_ASAP7_75t_SL g258 ( 
.A(n_217),
.B(n_38),
.Y(n_258)
);

BUFx3_ASAP7_75t_L g259 ( 
.A(n_217),
.Y(n_259)
);

INVx2_ASAP7_75t_L g260 ( 
.A(n_223),
.Y(n_260)
);

HB1xp67_ASAP7_75t_L g261 ( 
.A(n_228),
.Y(n_261)
);

INVx4_ASAP7_75t_SL g262 ( 
.A(n_233),
.Y(n_262)
);

INVx1_ASAP7_75t_L g263 ( 
.A(n_226),
.Y(n_263)
);

INVx2_ASAP7_75t_L g264 ( 
.A(n_229),
.Y(n_264)
);

INVx2_ASAP7_75t_L g265 ( 
.A(n_229),
.Y(n_265)
);

INVxp67_ASAP7_75t_L g266 ( 
.A(n_225),
.Y(n_266)
);

INVx1_ASAP7_75t_L g267 ( 
.A(n_227),
.Y(n_267)
);

INVx1_ASAP7_75t_L g268 ( 
.A(n_227),
.Y(n_268)
);

INVx2_ASAP7_75t_L g269 ( 
.A(n_227),
.Y(n_269)
);

INVx2_ASAP7_75t_L g270 ( 
.A(n_227),
.Y(n_270)
);

AO21x1_ASAP7_75t_SL g271 ( 
.A1(n_218),
.A2(n_40),
.B(n_39),
.Y(n_271)
);

AND2x4_ASAP7_75t_L g272 ( 
.A(n_254),
.B(n_43),
.Y(n_272)
);

INVx2_ASAP7_75t_L g273 ( 
.A(n_269),
.Y(n_273)
);

AND2x2_ASAP7_75t_L g274 ( 
.A(n_244),
.B(n_44),
.Y(n_274)
);

AND2x2_ASAP7_75t_L g275 ( 
.A(n_270),
.B(n_46),
.Y(n_275)
);

INVx2_ASAP7_75t_L g276 ( 
.A(n_267),
.Y(n_276)
);

AND2x2_ASAP7_75t_L g277 ( 
.A(n_268),
.B(n_47),
.Y(n_277)
);

NAND2xp5_ASAP7_75t_L g278 ( 
.A(n_259),
.B(n_48),
.Y(n_278)
);

INVx2_ASAP7_75t_SL g279 ( 
.A(n_241),
.Y(n_279)
);

INVx2_ASAP7_75t_L g280 ( 
.A(n_236),
.Y(n_280)
);

INVxp67_ASAP7_75t_SL g281 ( 
.A(n_236),
.Y(n_281)
);

AND2x4_ASAP7_75t_L g282 ( 
.A(n_256),
.B(n_50),
.Y(n_282)
);

AND2x2_ASAP7_75t_L g283 ( 
.A(n_249),
.B(n_262),
.Y(n_283)
);

INVx3_ASAP7_75t_L g284 ( 
.A(n_246),
.Y(n_284)
);

INVx2_ASAP7_75t_SL g285 ( 
.A(n_251),
.Y(n_285)
);

AND2x2_ASAP7_75t_L g286 ( 
.A(n_262),
.B(n_51),
.Y(n_286)
);

BUFx3_ASAP7_75t_L g287 ( 
.A(n_246),
.Y(n_287)
);

INVx1_ASAP7_75t_L g288 ( 
.A(n_237),
.Y(n_288)
);

INVx1_ASAP7_75t_L g289 ( 
.A(n_237),
.Y(n_289)
);

HB1xp67_ASAP7_75t_L g290 ( 
.A(n_245),
.Y(n_290)
);

CKINVDCx20_ASAP7_75t_R g291 ( 
.A(n_266),
.Y(n_291)
);

INVx1_ASAP7_75t_SL g292 ( 
.A(n_257),
.Y(n_292)
);

AND2x2_ASAP7_75t_L g293 ( 
.A(n_247),
.B(n_57),
.Y(n_293)
);

OR2x2_ASAP7_75t_L g294 ( 
.A(n_239),
.B(n_58),
.Y(n_294)
);

INVxp67_ASAP7_75t_SL g295 ( 
.A(n_240),
.Y(n_295)
);

AND2x2_ASAP7_75t_L g296 ( 
.A(n_258),
.B(n_59),
.Y(n_296)
);

INVx1_ASAP7_75t_L g297 ( 
.A(n_240),
.Y(n_297)
);

NAND3xp33_ASAP7_75t_L g298 ( 
.A(n_245),
.B(n_63),
.C(n_62),
.Y(n_298)
);

BUFx2_ASAP7_75t_L g299 ( 
.A(n_243),
.Y(n_299)
);

OR2x2_ASAP7_75t_L g300 ( 
.A(n_238),
.B(n_68),
.Y(n_300)
);

NAND2xp5_ASAP7_75t_L g301 ( 
.A(n_243),
.B(n_70),
.Y(n_301)
);

AND2x2_ASAP7_75t_L g302 ( 
.A(n_271),
.B(n_74),
.Y(n_302)
);

INVx2_ASAP7_75t_L g303 ( 
.A(n_260),
.Y(n_303)
);

INVx1_ASAP7_75t_L g304 ( 
.A(n_250),
.Y(n_304)
);

NAND2xp5_ASAP7_75t_L g305 ( 
.A(n_238),
.B(n_75),
.Y(n_305)
);

BUFx3_ASAP7_75t_L g306 ( 
.A(n_248),
.Y(n_306)
);

AND2x2_ASAP7_75t_L g307 ( 
.A(n_292),
.B(n_252),
.Y(n_307)
);

AND2x2_ASAP7_75t_L g308 ( 
.A(n_292),
.B(n_252),
.Y(n_308)
);

AND2x2_ASAP7_75t_L g309 ( 
.A(n_273),
.B(n_255),
.Y(n_309)
);

HB1xp67_ASAP7_75t_L g310 ( 
.A(n_276),
.Y(n_310)
);

NAND2xp5_ASAP7_75t_L g311 ( 
.A(n_273),
.B(n_255),
.Y(n_311)
);

INVx2_ASAP7_75t_L g312 ( 
.A(n_280),
.Y(n_312)
);

AND2x4_ASAP7_75t_L g313 ( 
.A(n_284),
.B(n_250),
.Y(n_313)
);

INVx1_ASAP7_75t_L g314 ( 
.A(n_281),
.Y(n_314)
);

INVx1_ASAP7_75t_L g315 ( 
.A(n_281),
.Y(n_315)
);

BUFx2_ASAP7_75t_L g316 ( 
.A(n_287),
.Y(n_316)
);

NAND2xp5_ASAP7_75t_L g317 ( 
.A(n_285),
.B(n_284),
.Y(n_317)
);

NAND2x1p5_ASAP7_75t_L g318 ( 
.A(n_287),
.B(n_263),
.Y(n_318)
);

INVx2_ASAP7_75t_L g319 ( 
.A(n_303),
.Y(n_319)
);

AND2x2_ASAP7_75t_L g320 ( 
.A(n_277),
.B(n_253),
.Y(n_320)
);

NAND3xp33_ASAP7_75t_L g321 ( 
.A(n_294),
.B(n_265),
.C(n_264),
.Y(n_321)
);

INVx4_ASAP7_75t_L g322 ( 
.A(n_279),
.Y(n_322)
);

NOR2x1_ASAP7_75t_SL g323 ( 
.A(n_306),
.B(n_253),
.Y(n_323)
);

INVx1_ASAP7_75t_SL g324 ( 
.A(n_291),
.Y(n_324)
);

NAND2xp5_ASAP7_75t_L g325 ( 
.A(n_274),
.B(n_275),
.Y(n_325)
);

INVx1_ASAP7_75t_L g326 ( 
.A(n_288),
.Y(n_326)
);

INVx1_ASAP7_75t_L g327 ( 
.A(n_289),
.Y(n_327)
);

AND2x2_ASAP7_75t_L g328 ( 
.A(n_272),
.B(n_263),
.Y(n_328)
);

INVx1_ASAP7_75t_L g329 ( 
.A(n_297),
.Y(n_329)
);

AND2x4_ASAP7_75t_L g330 ( 
.A(n_306),
.B(n_261),
.Y(n_330)
);

INVx2_ASAP7_75t_L g331 ( 
.A(n_290),
.Y(n_331)
);

INVx1_ASAP7_75t_L g332 ( 
.A(n_304),
.Y(n_332)
);

BUFx2_ASAP7_75t_SL g333 ( 
.A(n_322),
.Y(n_333)
);

NAND2xp5_ASAP7_75t_L g334 ( 
.A(n_310),
.B(n_290),
.Y(n_334)
);

INVx2_ASAP7_75t_SL g335 ( 
.A(n_322),
.Y(n_335)
);

NAND2xp5_ASAP7_75t_L g336 ( 
.A(n_312),
.B(n_331),
.Y(n_336)
);

INVx1_ASAP7_75t_L g337 ( 
.A(n_326),
.Y(n_337)
);

AND2x4_ASAP7_75t_L g338 ( 
.A(n_313),
.B(n_299),
.Y(n_338)
);

INVx2_ASAP7_75t_L g339 ( 
.A(n_319),
.Y(n_339)
);

OR2x2_ASAP7_75t_L g340 ( 
.A(n_329),
.B(n_295),
.Y(n_340)
);

INVx1_ASAP7_75t_L g341 ( 
.A(n_326),
.Y(n_341)
);

INVxp67_ASAP7_75t_L g342 ( 
.A(n_317),
.Y(n_342)
);

OR2x2_ASAP7_75t_L g343 ( 
.A(n_314),
.B(n_295),
.Y(n_343)
);

INVx1_ASAP7_75t_L g344 ( 
.A(n_332),
.Y(n_344)
);

AND2x2_ASAP7_75t_L g345 ( 
.A(n_307),
.B(n_283),
.Y(n_345)
);

OAI332xp33_ASAP7_75t_L g346 ( 
.A1(n_324),
.A2(n_305),
.A3(n_300),
.B1(n_301),
.B2(n_278),
.B3(n_291),
.C1(n_286),
.C2(n_272),
.Y(n_346)
);

AND2x2_ASAP7_75t_L g347 ( 
.A(n_308),
.B(n_282),
.Y(n_347)
);

NAND2xp5_ASAP7_75t_L g348 ( 
.A(n_328),
.B(n_301),
.Y(n_348)
);

INVx3_ASAP7_75t_L g349 ( 
.A(n_318),
.Y(n_349)
);

NAND2xp5_ASAP7_75t_L g350 ( 
.A(n_337),
.B(n_315),
.Y(n_350)
);

OR2x2_ASAP7_75t_L g351 ( 
.A(n_334),
.B(n_311),
.Y(n_351)
);

INVx1_ASAP7_75t_L g352 ( 
.A(n_344),
.Y(n_352)
);

INVx1_ASAP7_75t_L g353 ( 
.A(n_344),
.Y(n_353)
);

AND2x2_ASAP7_75t_L g354 ( 
.A(n_345),
.B(n_316),
.Y(n_354)
);

INVx2_ASAP7_75t_L g355 ( 
.A(n_341),
.Y(n_355)
);

INVx1_ASAP7_75t_L g356 ( 
.A(n_336),
.Y(n_356)
);

INVx1_ASAP7_75t_L g357 ( 
.A(n_340),
.Y(n_357)
);

NAND2xp5_ASAP7_75t_L g358 ( 
.A(n_342),
.B(n_332),
.Y(n_358)
);

HB1xp67_ASAP7_75t_L g359 ( 
.A(n_343),
.Y(n_359)
);

NAND2xp5_ASAP7_75t_L g360 ( 
.A(n_356),
.B(n_351),
.Y(n_360)
);

INVx2_ASAP7_75t_L g361 ( 
.A(n_355),
.Y(n_361)
);

INVx2_ASAP7_75t_L g362 ( 
.A(n_352),
.Y(n_362)
);

INVxp33_ASAP7_75t_L g363 ( 
.A(n_354),
.Y(n_363)
);

OAI332xp33_ASAP7_75t_L g364 ( 
.A1(n_358),
.A2(n_346),
.A3(n_325),
.B1(n_335),
.B2(n_348),
.B3(n_305),
.C1(n_339),
.C2(n_327),
.Y(n_364)
);

NOR2xp33_ASAP7_75t_L g365 ( 
.A(n_357),
.B(n_333),
.Y(n_365)
);

INVx1_ASAP7_75t_L g366 ( 
.A(n_362),
.Y(n_366)
);

NAND4xp25_ASAP7_75t_L g367 ( 
.A(n_365),
.B(n_321),
.C(n_350),
.D(n_347),
.Y(n_367)
);

OAI221xp5_ASAP7_75t_L g368 ( 
.A1(n_360),
.A2(n_350),
.B1(n_359),
.B2(n_353),
.C(n_349),
.Y(n_368)
);

OAI21xp33_ASAP7_75t_SL g369 ( 
.A1(n_363),
.A2(n_349),
.B(n_309),
.Y(n_369)
);

AOI221xp5_ASAP7_75t_L g370 ( 
.A1(n_368),
.A2(n_364),
.B1(n_367),
.B2(n_369),
.C(n_366),
.Y(n_370)
);

NOR3xp33_ASAP7_75t_L g371 ( 
.A(n_367),
.B(n_278),
.C(n_302),
.Y(n_371)
);

INVx1_ASAP7_75t_L g372 ( 
.A(n_371),
.Y(n_372)
);

NOR4xp75_ASAP7_75t_L g373 ( 
.A(n_370),
.B(n_320),
.C(n_293),
.D(n_296),
.Y(n_373)
);

NOR2x1_ASAP7_75t_L g374 ( 
.A(n_372),
.B(n_361),
.Y(n_374)
);

NAND3xp33_ASAP7_75t_L g375 ( 
.A(n_374),
.B(n_373),
.C(n_313),
.Y(n_375)
);

BUFx2_ASAP7_75t_L g376 ( 
.A(n_375),
.Y(n_376)
);

INVx1_ASAP7_75t_L g377 ( 
.A(n_376),
.Y(n_377)
);

INVx1_ASAP7_75t_L g378 ( 
.A(n_377),
.Y(n_378)
);

AOI21xp5_ASAP7_75t_L g379 ( 
.A1(n_378),
.A2(n_282),
.B(n_298),
.Y(n_379)
);

OAI21xp5_ASAP7_75t_SL g380 ( 
.A1(n_379),
.A2(n_330),
.B(n_338),
.Y(n_380)
);

AOI22xp5_ASAP7_75t_L g381 ( 
.A1(n_380),
.A2(n_330),
.B1(n_338),
.B2(n_327),
.Y(n_381)
);

AOI22xp33_ASAP7_75t_L g382 ( 
.A1(n_381),
.A2(n_242),
.B1(n_323),
.B2(n_77),
.Y(n_382)
);


endmodule