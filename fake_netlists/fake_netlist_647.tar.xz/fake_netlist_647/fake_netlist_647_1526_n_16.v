module fake_netlist_647_1526_n_16 (n_4, n_1, n_2, n_0, n_5, n_3, n_16);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_16;

wire n_7;
wire n_14;
wire n_13;
wire n_10;
wire n_12;
wire n_6;
wire n_8;
wire n_15;
wire n_11;
wire n_9;

CKINVDCx20_ASAP7_75t_R g6 ( 
.A(n_2),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVxp67_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

OAI21xp33_ASAP7_75t_SL g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_6),
.B1(n_8),
.B2(n_7),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_11),
.B(n_10),
.C(n_1),
.Y(n_13)
);

AOI21xp33_ASAP7_75t_R g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_1),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_3),
.B1(n_5),
.B2(n_12),
.Y(n_16)
);


endmodule