module fake_netlist_647_738_n_25 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_25);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_25;

wire n_18;
wire n_19;
wire n_24;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

INVx3_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_8),
.B1(n_0),
.B2(n_1),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_7),
.Y(n_18)
);

AO32x2_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_3),
.A3(n_2),
.B1(n_4),
.B2(n_5),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_14),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI211xp5_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_16),
.B(n_19),
.C(n_12),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_15),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_15),
.Y(n_25)
);


endmodule