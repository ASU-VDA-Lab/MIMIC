module fake_netlist_647_318_n_16 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_16);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_16;

wire n_9;
wire n_14;
wire n_13;
wire n_10;
wire n_15;
wire n_11;
wire n_12;

BUFx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_6),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_2),
.A2(n_4),
.B1(n_7),
.B2(n_0),
.Y(n_12)
);

BUFx4f_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_12),
.B2(n_11),
.C1(n_3),
.C2(n_10),
.Y(n_16)
);


endmodule