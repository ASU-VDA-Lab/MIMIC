module fake_netlist_647_2473_n_26 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_26);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_26;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_15;
wire n_11;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

NOR2x1_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_5),
.Y(n_11)
);

CKINVDCx16_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_3),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_12),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_11),
.B1(n_9),
.B2(n_12),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND2xp33_ASAP7_75t_R g18 ( 
.A(n_17),
.B(n_13),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_14),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_SL g22 ( 
.A(n_20),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_6),
.C(n_5),
.D(n_4),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_21),
.B1(n_6),
.B2(n_4),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_7),
.B1(n_8),
.B2(n_24),
.Y(n_26)
);


endmodule