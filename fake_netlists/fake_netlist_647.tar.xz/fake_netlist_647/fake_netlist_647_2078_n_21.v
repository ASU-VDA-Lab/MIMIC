module fake_netlist_647_2078_n_21 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_21);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_10;
wire n_15;
wire n_11;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVxp67_ASAP7_75t_SL g12 ( 
.A(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

INVxp67_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AO31x2_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_6),
.A3(n_5),
.B(n_4),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_13),
.B1(n_11),
.B2(n_10),
.C(n_15),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.B1(n_1),
.B2(n_0),
.Y(n_19)
);

OAI31xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.A3(n_6),
.B(n_4),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_9),
.B(n_3),
.Y(n_21)
);


endmodule