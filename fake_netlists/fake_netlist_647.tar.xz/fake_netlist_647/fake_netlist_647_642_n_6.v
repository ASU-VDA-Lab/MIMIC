module fake_netlist_647_642_n_6 (n_1, n_0, n_6);

input n_1;
input n_0;

output n_6;

wire n_4;
wire n_2;
wire n_5;
wire n_3;

INVx1_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

AND2x4_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

OAI21xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_4)
);

AOI211x1_ASAP7_75t_SL g5 ( 
.A1(n_4),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_5)
);

OAI22xp33_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);


endmodule