module fake_netlist_647_2740_n_385 (n_18, n_36, n_19, n_34, n_1, n_38, n_51, n_0, n_5, n_10, n_44, n_25, n_40, n_54, n_24, n_35, n_57, n_28, n_11, n_15, n_7, n_30, n_20, n_45, n_49, n_53, n_56, n_23, n_48, n_16, n_12, n_3, n_22, n_4, n_17, n_39, n_14, n_21, n_27, n_46, n_42, n_2, n_29, n_55, n_52, n_50, n_31, n_41, n_26, n_33, n_9, n_32, n_37, n_13, n_43, n_47, n_8, n_6, n_385);

input n_18;
input n_36;
input n_19;
input n_34;
input n_1;
input n_38;
input n_51;
input n_0;
input n_5;
input n_10;
input n_44;
input n_25;
input n_40;
input n_54;
input n_24;
input n_35;
input n_57;
input n_28;
input n_11;
input n_15;
input n_7;
input n_30;
input n_20;
input n_45;
input n_49;
input n_53;
input n_56;
input n_23;
input n_48;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_39;
input n_14;
input n_21;
input n_27;
input n_46;
input n_42;
input n_2;
input n_29;
input n_55;
input n_52;
input n_50;
input n_31;
input n_41;
input n_26;
input n_33;
input n_9;
input n_32;
input n_37;
input n_13;
input n_43;
input n_47;
input n_8;
input n_6;

output n_385;

wire n_326;
wire n_101;
wire n_313;
wire n_209;
wire n_321;
wire n_245;
wire n_164;
wire n_118;
wire n_189;
wire n_306;
wire n_275;
wire n_173;
wire n_183;
wire n_260;
wire n_63;
wire n_190;
wire n_362;
wire n_187;
wire n_238;
wire n_71;
wire n_201;
wire n_294;
wire n_331;
wire n_217;
wire n_300;
wire n_241;
wire n_345;
wire n_161;
wire n_234;
wire n_259;
wire n_312;
wire n_180;
wire n_142;
wire n_232;
wire n_379;
wire n_143;
wire n_122;
wire n_323;
wire n_250;
wire n_227;
wire n_365;
wire n_85;
wire n_176;
wire n_160;
wire n_156;
wire n_317;
wire n_174;
wire n_349;
wire n_175;
wire n_368;
wire n_195;
wire n_67;
wire n_112;
wire n_303;
wire n_169;
wire n_322;
wire n_103;
wire n_162;
wire n_64;
wire n_228;
wire n_343;
wire n_265;
wire n_145;
wire n_215;
wire n_205;
wire n_361;
wire n_171;
wire n_337;
wire n_222;
wire n_158;
wire n_354;
wire n_285;
wire n_350;
wire n_114;
wire n_272;
wire n_99;
wire n_318;
wire n_144;
wire n_155;
wire n_270;
wire n_377;
wire n_214;
wire n_84;
wire n_116;
wire n_218;
wire n_78;
wire n_235;
wire n_191;
wire n_60;
wire n_256;
wire n_384;
wire n_369;
wire n_177;
wire n_269;
wire n_286;
wire n_81;
wire n_357;
wire n_266;
wire n_163;
wire n_91;
wire n_105;
wire n_329;
wire n_230;
wire n_223;
wire n_371;
wire n_278;
wire n_282;
wire n_283;
wire n_336;
wire n_151;
wire n_77;
wire n_346;
wire n_199;
wire n_364;
wire n_372;
wire n_382;
wire n_219;
wire n_119;
wire n_310;
wire n_149;
wire n_182;
wire n_341;
wire n_359;
wire n_281;
wire n_202;
wire n_298;
wire n_167;
wire n_237;
wire n_104;
wire n_284;
wire n_291;
wire n_146;
wire n_325;
wire n_196;
wire n_200;
wire n_106;
wire n_355;
wire n_258;
wire n_87;
wire n_115;
wire n_79;
wire n_307;
wire n_128;
wire n_126;
wire n_339;
wire n_147;
wire n_352;
wire n_267;
wire n_95;
wire n_186;
wire n_297;
wire n_316;
wire n_293;
wire n_62;
wire n_90;
wire n_70;
wire n_58;
wire n_166;
wire n_247;
wire n_327;
wire n_344;
wire n_220;
wire n_358;
wire n_296;
wire n_347;
wire n_154;
wire n_194;
wire n_184;
wire n_376;
wire n_288;
wire n_121;
wire n_381;
wire n_157;
wire n_290;
wire n_92;
wire n_117;
wire n_360;
wire n_136;
wire n_276;
wire n_170;
wire n_314;
wire n_207;
wire n_75;
wire n_93;
wire n_279;
wire n_338;
wire n_181;
wire n_213;
wire n_65;
wire n_240;
wire n_208;
wire n_273;
wire n_320;
wire n_308;
wire n_72;
wire n_229;
wire n_301;
wire n_383;
wire n_68;
wire n_380;
wire n_198;
wire n_248;
wire n_253;
wire n_335;
wire n_179;
wire n_254;
wire n_150;
wire n_374;
wire n_305;
wire n_148;
wire n_159;
wire n_123;
wire n_141;
wire n_309;
wire n_353;
wire n_185;
wire n_73;
wire n_328;
wire n_132;
wire n_367;
wire n_224;
wire n_264;
wire n_366;
wire n_138;
wire n_239;
wire n_274;
wire n_315;
wire n_287;
wire n_102;
wire n_135;
wire n_178;
wire n_324;
wire n_255;
wire n_334;
wire n_311;
wire n_80;
wire n_88;
wire n_375;
wire n_168;
wire n_348;
wire n_139;
wire n_252;
wire n_89;
wire n_152;
wire n_96;
wire n_172;
wire n_107;
wire n_342;
wire n_66;
wire n_261;
wire n_137;
wire n_197;
wire n_363;
wire n_243;
wire n_211;
wire n_206;
wire n_192;
wire n_124;
wire n_165;
wire n_263;
wire n_302;
wire n_244;
wire n_125;
wire n_333;
wire n_304;
wire n_110;
wire n_378;
wire n_203;
wire n_109;
wire n_340;
wire n_82;
wire n_277;
wire n_204;
wire n_120;
wire n_61;
wire n_246;
wire n_242;
wire n_257;
wire n_231;
wire n_226;
wire n_86;
wire n_280;
wire n_130;
wire n_233;
wire n_210;
wire n_140;
wire n_262;
wire n_299;
wire n_249;
wire n_292;
wire n_251;
wire n_332;
wire n_113;
wire n_127;
wire n_236;
wire n_100;
wire n_129;
wire n_83;
wire n_76;
wire n_134;
wire n_330;
wire n_319;
wire n_133;
wire n_225;
wire n_59;
wire n_131;
wire n_97;
wire n_295;
wire n_108;
wire n_98;
wire n_69;
wire n_94;
wire n_268;
wire n_221;
wire n_212;
wire n_271;
wire n_356;
wire n_193;
wire n_289;
wire n_153;
wire n_216;
wire n_373;
wire n_74;
wire n_351;
wire n_188;
wire n_370;
wire n_111;

INVx1_ASAP7_75t_L g58 ( 
.A(n_37),
.Y(n_58)
);

CKINVDCx20_ASAP7_75t_R g59 ( 
.A(n_22),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_38),
.Y(n_60)
);

INVxp67_ASAP7_75t_L g61 ( 
.A(n_35),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_10),
.Y(n_62)
);

BUFx6f_ASAP7_75t_L g63 ( 
.A(n_27),
.Y(n_63)
);

INVxp67_ASAP7_75t_SL g64 ( 
.A(n_56),
.Y(n_64)
);

BUFx6f_ASAP7_75t_L g65 ( 
.A(n_42),
.Y(n_65)
);

INVxp67_ASAP7_75t_SL g66 ( 
.A(n_34),
.Y(n_66)
);

BUFx5_ASAP7_75t_L g67 ( 
.A(n_1),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_53),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_49),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_36),
.Y(n_70)
);

INVxp67_ASAP7_75t_L g71 ( 
.A(n_29),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_54),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_39),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_7),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_55),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_21),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_23),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_8),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_2),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_44),
.Y(n_80)
);

BUFx3_ASAP7_75t_L g81 ( 
.A(n_28),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_67),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_67),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_67),
.Y(n_84)
);

BUFx6f_ASAP7_75t_L g85 ( 
.A(n_63),
.Y(n_85)
);

AND2x2_ASAP7_75t_L g86 ( 
.A(n_81),
.B(n_0),
.Y(n_86)
);

BUFx6f_ASAP7_75t_L g87 ( 
.A(n_63),
.Y(n_87)
);

BUFx6f_ASAP7_75t_L g88 ( 
.A(n_63),
.Y(n_88)
);

INVx2_ASAP7_75t_L g89 ( 
.A(n_67),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_67),
.Y(n_90)
);

INVx3_ASAP7_75t_L g91 ( 
.A(n_63),
.Y(n_91)
);

INVxp67_ASAP7_75t_L g92 ( 
.A(n_86),
.Y(n_92)
);

CKINVDCx5p33_ASAP7_75t_R g93 ( 
.A(n_86),
.Y(n_93)
);

NAND2xp5_ASAP7_75t_SL g94 ( 
.A(n_82),
.B(n_67),
.Y(n_94)
);

BUFx6f_ASAP7_75t_L g95 ( 
.A(n_85),
.Y(n_95)
);

NAND2xp5_ASAP7_75t_L g96 ( 
.A(n_91),
.B(n_64),
.Y(n_96)
);

INVx4_ASAP7_75t_L g97 ( 
.A(n_85),
.Y(n_97)
);

NOR2xp33_ASAP7_75t_L g98 ( 
.A(n_82),
.B(n_61),
.Y(n_98)
);

AOI22xp33_ASAP7_75t_L g99 ( 
.A1(n_83),
.A2(n_78),
.B1(n_74),
.B2(n_62),
.Y(n_99)
);

INVx3_ASAP7_75t_L g100 ( 
.A(n_85),
.Y(n_100)
);

AND2x4_ASAP7_75t_L g101 ( 
.A(n_91),
.B(n_64),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_91),
.Y(n_102)
);

INVx2_ASAP7_75t_L g103 ( 
.A(n_84),
.Y(n_103)
);

CKINVDCx5p33_ASAP7_75t_R g104 ( 
.A(n_83),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_SL g105 ( 
.A(n_84),
.B(n_65),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_102),
.Y(n_106)
);

NAND2xp5_ASAP7_75t_L g107 ( 
.A(n_104),
.B(n_91),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_102),
.Y(n_108)
);

NAND2xp5_ASAP7_75t_SL g109 ( 
.A(n_101),
.B(n_65),
.Y(n_109)
);

OR2x2_ASAP7_75t_SL g110 ( 
.A(n_96),
.B(n_79),
.Y(n_110)
);

AOI21xp5_ASAP7_75t_L g111 ( 
.A1(n_92),
.A2(n_90),
.B(n_89),
.Y(n_111)
);

NAND2xp5_ASAP7_75t_SL g112 ( 
.A(n_101),
.B(n_65),
.Y(n_112)
);

NAND2xp5_ASAP7_75t_SL g113 ( 
.A(n_101),
.B(n_65),
.Y(n_113)
);

INVx2_ASAP7_75t_L g114 ( 
.A(n_103),
.Y(n_114)
);

BUFx8_ASAP7_75t_L g115 ( 
.A(n_101),
.Y(n_115)
);

INVx5_ASAP7_75t_L g116 ( 
.A(n_95),
.Y(n_116)
);

NAND2xp5_ASAP7_75t_L g117 ( 
.A(n_101),
.B(n_66),
.Y(n_117)
);

NAND2xp5_ASAP7_75t_SL g118 ( 
.A(n_96),
.B(n_58),
.Y(n_118)
);

BUFx6f_ASAP7_75t_SL g119 ( 
.A(n_99),
.Y(n_119)
);

NAND2xp5_ASAP7_75t_SL g120 ( 
.A(n_93),
.B(n_60),
.Y(n_120)
);

BUFx2_ASAP7_75t_L g121 ( 
.A(n_92),
.Y(n_121)
);

NAND2xp5_ASAP7_75t_L g122 ( 
.A(n_98),
.B(n_66),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_94),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_123),
.B(n_98),
.Y(n_124)
);

BUFx2_ASAP7_75t_L g125 ( 
.A(n_121),
.Y(n_125)
);

INVx3_ASAP7_75t_L g126 ( 
.A(n_114),
.Y(n_126)
);

BUFx3_ASAP7_75t_L g127 ( 
.A(n_115),
.Y(n_127)
);

AOI22xp5_ASAP7_75t_L g128 ( 
.A1(n_119),
.A2(n_94),
.B1(n_59),
.B2(n_61),
.Y(n_128)
);

INVx2_ASAP7_75t_SL g129 ( 
.A(n_107),
.Y(n_129)
);

AOI222xp33_ASAP7_75t_L g130 ( 
.A1(n_119),
.A2(n_99),
.B1(n_71),
.B2(n_70),
.C1(n_69),
.C2(n_68),
.Y(n_130)
);

INVx1_ASAP7_75t_L g131 ( 
.A(n_106),
.Y(n_131)
);

BUFx2_ASAP7_75t_L g132 ( 
.A(n_110),
.Y(n_132)
);

OAI221xp5_ASAP7_75t_L g133 ( 
.A1(n_122),
.A2(n_71),
.B1(n_75),
.B2(n_72),
.C(n_73),
.Y(n_133)
);

INVx2_ASAP7_75t_SL g134 ( 
.A(n_117),
.Y(n_134)
);

OAI22xp5_ASAP7_75t_L g135 ( 
.A1(n_118),
.A2(n_80),
.B1(n_77),
.B2(n_76),
.Y(n_135)
);

OAI22xp5_ASAP7_75t_SL g136 ( 
.A1(n_120),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_108),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_112),
.Y(n_138)
);

BUFx2_ASAP7_75t_L g139 ( 
.A(n_115),
.Y(n_139)
);

INVx3_ASAP7_75t_L g140 ( 
.A(n_126),
.Y(n_140)
);

AND2x2_ASAP7_75t_L g141 ( 
.A(n_134),
.B(n_120),
.Y(n_141)
);

AOI22xp33_ASAP7_75t_L g142 ( 
.A1(n_134),
.A2(n_118),
.B1(n_113),
.B2(n_112),
.Y(n_142)
);

AOI21xp5_ASAP7_75t_L g143 ( 
.A1(n_138),
.A2(n_109),
.B(n_113),
.Y(n_143)
);

O2A1O1Ixp33_ASAP7_75t_L g144 ( 
.A1(n_124),
.A2(n_109),
.B(n_111),
.C(n_105),
.Y(n_144)
);

INVx4_ASAP7_75t_SL g145 ( 
.A(n_136),
.Y(n_145)
);

BUFx2_ASAP7_75t_L g146 ( 
.A(n_125),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_131),
.Y(n_147)
);

AOI21xp5_ASAP7_75t_L g148 ( 
.A1(n_138),
.A2(n_97),
.B(n_116),
.Y(n_148)
);

NAND2xp5_ASAP7_75t_L g149 ( 
.A(n_129),
.B(n_103),
.Y(n_149)
);

AOI22xp33_ASAP7_75t_L g150 ( 
.A1(n_130),
.A2(n_105),
.B1(n_90),
.B2(n_89),
.Y(n_150)
);

AND2x2_ASAP7_75t_L g151 ( 
.A(n_129),
.B(n_89),
.Y(n_151)
);

AOI21xp5_ASAP7_75t_L g152 ( 
.A1(n_131),
.A2(n_97),
.B(n_116),
.Y(n_152)
);

AOI22xp33_ASAP7_75t_L g153 ( 
.A1(n_145),
.A2(n_130),
.B1(n_136),
.B2(n_135),
.Y(n_153)
);

INVx2_ASAP7_75t_L g154 ( 
.A(n_147),
.Y(n_154)
);

AO31x2_ASAP7_75t_L g155 ( 
.A1(n_143),
.A2(n_135),
.A3(n_137),
.B(n_132),
.Y(n_155)
);

NAND2xp5_ASAP7_75t_L g156 ( 
.A(n_141),
.B(n_137),
.Y(n_156)
);

AOI221xp5_ASAP7_75t_L g157 ( 
.A1(n_141),
.A2(n_132),
.B1(n_128),
.B2(n_133),
.C(n_125),
.Y(n_157)
);

AOI22xp33_ASAP7_75t_L g158 ( 
.A1(n_145),
.A2(n_128),
.B1(n_126),
.B2(n_90),
.Y(n_158)
);

OR2x2_ASAP7_75t_L g159 ( 
.A(n_146),
.B(n_139),
.Y(n_159)
);

OAI22xp33_ASAP7_75t_L g160 ( 
.A1(n_147),
.A2(n_146),
.B1(n_127),
.B2(n_139),
.Y(n_160)
);

HB1xp67_ASAP7_75t_L g161 ( 
.A(n_151),
.Y(n_161)
);

AND2x2_ASAP7_75t_L g162 ( 
.A(n_151),
.B(n_145),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_149),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_154),
.Y(n_164)
);

HB1xp67_ASAP7_75t_L g165 ( 
.A(n_159),
.Y(n_165)
);

INVx2_ASAP7_75t_L g166 ( 
.A(n_154),
.Y(n_166)
);

INVx4_ASAP7_75t_L g167 ( 
.A(n_162),
.Y(n_167)
);

INVx1_ASAP7_75t_L g168 ( 
.A(n_161),
.Y(n_168)
);

BUFx2_ASAP7_75t_L g169 ( 
.A(n_155),
.Y(n_169)
);

BUFx3_ASAP7_75t_L g170 ( 
.A(n_155),
.Y(n_170)
);

INVx1_ASAP7_75t_L g171 ( 
.A(n_156),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_163),
.Y(n_172)
);

INVx2_ASAP7_75t_L g173 ( 
.A(n_155),
.Y(n_173)
);

OR2x2_ASAP7_75t_L g174 ( 
.A(n_155),
.B(n_142),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_158),
.Y(n_175)
);

HB1xp67_ASAP7_75t_L g176 ( 
.A(n_157),
.Y(n_176)
);

AND2x4_ASAP7_75t_L g177 ( 
.A(n_158),
.B(n_140),
.Y(n_177)
);

OR2x2_ASAP7_75t_L g178 ( 
.A(n_174),
.B(n_169),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_172),
.Y(n_179)
);

OAI22xp5_ASAP7_75t_L g180 ( 
.A1(n_176),
.A2(n_153),
.B1(n_160),
.B2(n_127),
.Y(n_180)
);

INVx1_ASAP7_75t_L g181 ( 
.A(n_173),
.Y(n_181)
);

OAI31xp33_ASAP7_75t_L g182 ( 
.A1(n_171),
.A2(n_153),
.A3(n_127),
.B(n_145),
.Y(n_182)
);

AND2x2_ASAP7_75t_L g183 ( 
.A(n_171),
.B(n_150),
.Y(n_183)
);

INVx1_ASAP7_75t_L g184 ( 
.A(n_173),
.Y(n_184)
);

HB1xp67_ASAP7_75t_L g185 ( 
.A(n_165),
.Y(n_185)
);

AND2x4_ASAP7_75t_L g186 ( 
.A(n_167),
.B(n_140),
.Y(n_186)
);

HB1xp67_ASAP7_75t_L g187 ( 
.A(n_168),
.Y(n_187)
);

INVx2_ASAP7_75t_L g188 ( 
.A(n_164),
.Y(n_188)
);

INVx1_ASAP7_75t_L g189 ( 
.A(n_164),
.Y(n_189)
);

INVx1_ASAP7_75t_L g190 ( 
.A(n_166),
.Y(n_190)
);

BUFx2_ASAP7_75t_SL g191 ( 
.A(n_167),
.Y(n_191)
);

AND2x2_ASAP7_75t_L g192 ( 
.A(n_166),
.B(n_140),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_167),
.B(n_144),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_169),
.Y(n_194)
);

INVx2_ASAP7_75t_L g195 ( 
.A(n_172),
.Y(n_195)
);

INVx2_ASAP7_75t_L g196 ( 
.A(n_177),
.Y(n_196)
);

INVxp67_ASAP7_75t_L g197 ( 
.A(n_168),
.Y(n_197)
);

INVx1_ASAP7_75t_L g198 ( 
.A(n_170),
.Y(n_198)
);

INVx1_ASAP7_75t_L g199 ( 
.A(n_170),
.Y(n_199)
);

INVx1_ASAP7_75t_L g200 ( 
.A(n_170),
.Y(n_200)
);

AND2x2_ASAP7_75t_L g201 ( 
.A(n_196),
.B(n_174),
.Y(n_201)
);

NAND2x1p5_ASAP7_75t_L g202 ( 
.A(n_193),
.B(n_177),
.Y(n_202)
);

AND2x2_ASAP7_75t_L g203 ( 
.A(n_196),
.B(n_175),
.Y(n_203)
);

INVx2_ASAP7_75t_L g204 ( 
.A(n_181),
.Y(n_204)
);

OR2x2_ASAP7_75t_L g205 ( 
.A(n_178),
.B(n_175),
.Y(n_205)
);

AND2x4_ASAP7_75t_L g206 ( 
.A(n_195),
.B(n_167),
.Y(n_206)
);

HB1xp67_ASAP7_75t_L g207 ( 
.A(n_185),
.Y(n_207)
);

BUFx2_ASAP7_75t_L g208 ( 
.A(n_198),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_181),
.Y(n_209)
);

INVx3_ASAP7_75t_L g210 ( 
.A(n_184),
.Y(n_210)
);

NAND2xp5_ASAP7_75t_L g211 ( 
.A(n_183),
.B(n_177),
.Y(n_211)
);

INVx1_ASAP7_75t_L g212 ( 
.A(n_184),
.Y(n_212)
);

INVx1_ASAP7_75t_L g213 ( 
.A(n_198),
.Y(n_213)
);

AND2x2_ASAP7_75t_L g214 ( 
.A(n_178),
.B(n_177),
.Y(n_214)
);

NOR2xp67_ASAP7_75t_L g215 ( 
.A(n_195),
.B(n_148),
.Y(n_215)
);

INVx1_ASAP7_75t_L g216 ( 
.A(n_199),
.Y(n_216)
);

AND2x2_ASAP7_75t_L g217 ( 
.A(n_199),
.B(n_16),
.Y(n_217)
);

OR2x2_ASAP7_75t_L g218 ( 
.A(n_194),
.B(n_126),
.Y(n_218)
);

AND2x2_ASAP7_75t_L g219 ( 
.A(n_200),
.B(n_17),
.Y(n_219)
);

NAND2xp5_ASAP7_75t_L g220 ( 
.A(n_183),
.B(n_126),
.Y(n_220)
);

INVx2_ASAP7_75t_L g221 ( 
.A(n_179),
.Y(n_221)
);

NAND2xp5_ASAP7_75t_L g222 ( 
.A(n_180),
.B(n_3),
.Y(n_222)
);

NOR2xp33_ASAP7_75t_L g223 ( 
.A(n_197),
.B(n_18),
.Y(n_223)
);

NAND3xp33_ASAP7_75t_L g224 ( 
.A(n_182),
.B(n_152),
.C(n_85),
.Y(n_224)
);

AND2x2_ASAP7_75t_L g225 ( 
.A(n_200),
.B(n_19),
.Y(n_225)
);

INVx3_ASAP7_75t_L g226 ( 
.A(n_193),
.Y(n_226)
);

INVx3_ASAP7_75t_L g227 ( 
.A(n_188),
.Y(n_227)
);

AND2x4_ASAP7_75t_SL g228 ( 
.A(n_187),
.B(n_103),
.Y(n_228)
);

INVx1_ASAP7_75t_L g229 ( 
.A(n_194),
.Y(n_229)
);

INVx1_ASAP7_75t_SL g230 ( 
.A(n_191),
.Y(n_230)
);

INVx1_ASAP7_75t_L g231 ( 
.A(n_189),
.Y(n_231)
);

NAND2xp5_ASAP7_75t_L g232 ( 
.A(n_189),
.B(n_3),
.Y(n_232)
);

INVx2_ASAP7_75t_L g233 ( 
.A(n_190),
.Y(n_233)
);

NAND2xp5_ASAP7_75t_SL g234 ( 
.A(n_186),
.B(n_85),
.Y(n_234)
);

AND2x2_ASAP7_75t_L g235 ( 
.A(n_190),
.B(n_20),
.Y(n_235)
);

INVx2_ASAP7_75t_SL g236 ( 
.A(n_188),
.Y(n_236)
);

INVx2_ASAP7_75t_L g237 ( 
.A(n_221),
.Y(n_237)
);

INVx1_ASAP7_75t_L g238 ( 
.A(n_229),
.Y(n_238)
);

HB1xp67_ASAP7_75t_L g239 ( 
.A(n_207),
.Y(n_239)
);

OR2x2_ASAP7_75t_L g240 ( 
.A(n_205),
.B(n_191),
.Y(n_240)
);

INVx1_ASAP7_75t_L g241 ( 
.A(n_229),
.Y(n_241)
);

OAI31xp33_ASAP7_75t_L g242 ( 
.A1(n_222),
.A2(n_186),
.A3(n_192),
.B(n_4),
.Y(n_242)
);

NAND2xp67_ASAP7_75t_L g243 ( 
.A(n_232),
.B(n_192),
.Y(n_243)
);

AND2x2_ASAP7_75t_L g244 ( 
.A(n_226),
.B(n_186),
.Y(n_244)
);

NAND2x1_ASAP7_75t_L g245 ( 
.A(n_226),
.B(n_100),
.Y(n_245)
);

INVx2_ASAP7_75t_SL g246 ( 
.A(n_221),
.Y(n_246)
);

INVx1_ASAP7_75t_L g247 ( 
.A(n_221),
.Y(n_247)
);

OR2x2_ASAP7_75t_L g248 ( 
.A(n_205),
.B(n_85),
.Y(n_248)
);

OAI22xp5_ASAP7_75t_L g249 ( 
.A1(n_211),
.A2(n_88),
.B1(n_87),
.B2(n_4),
.Y(n_249)
);

OAI21xp5_ASAP7_75t_L g250 ( 
.A1(n_223),
.A2(n_100),
.B(n_97),
.Y(n_250)
);

INVx1_ASAP7_75t_L g251 ( 
.A(n_213),
.Y(n_251)
);

INVx2_ASAP7_75t_L g252 ( 
.A(n_204),
.Y(n_252)
);

NAND2xp5_ASAP7_75t_L g253 ( 
.A(n_214),
.B(n_5),
.Y(n_253)
);

HB1xp67_ASAP7_75t_L g254 ( 
.A(n_226),
.Y(n_254)
);

OR2x2_ASAP7_75t_L g255 ( 
.A(n_226),
.B(n_87),
.Y(n_255)
);

NAND2xp5_ASAP7_75t_L g256 ( 
.A(n_214),
.B(n_5),
.Y(n_256)
);

NOR2xp33_ASAP7_75t_L g257 ( 
.A(n_211),
.B(n_6),
.Y(n_257)
);

NAND2xp5_ASAP7_75t_SL g258 ( 
.A(n_230),
.B(n_87),
.Y(n_258)
);

OR2x2_ASAP7_75t_L g259 ( 
.A(n_208),
.B(n_87),
.Y(n_259)
);

AND2x2_ASAP7_75t_L g260 ( 
.A(n_201),
.B(n_6),
.Y(n_260)
);

NAND2xp5_ASAP7_75t_L g261 ( 
.A(n_203),
.B(n_7),
.Y(n_261)
);

INVx1_ASAP7_75t_SL g262 ( 
.A(n_230),
.Y(n_262)
);

HB1xp67_ASAP7_75t_L g263 ( 
.A(n_208),
.Y(n_263)
);

INVx1_ASAP7_75t_L g264 ( 
.A(n_213),
.Y(n_264)
);

NAND2xp5_ASAP7_75t_L g265 ( 
.A(n_203),
.B(n_201),
.Y(n_265)
);

INVx1_ASAP7_75t_SL g266 ( 
.A(n_206),
.Y(n_266)
);

AND2x4_ASAP7_75t_L g267 ( 
.A(n_216),
.B(n_24),
.Y(n_267)
);

HB1xp67_ASAP7_75t_L g268 ( 
.A(n_216),
.Y(n_268)
);

AND2x2_ASAP7_75t_L g269 ( 
.A(n_202),
.B(n_8),
.Y(n_269)
);

INVx1_ASAP7_75t_L g270 ( 
.A(n_209),
.Y(n_270)
);

INVx1_ASAP7_75t_SL g271 ( 
.A(n_206),
.Y(n_271)
);

OR2x2_ASAP7_75t_L g272 ( 
.A(n_202),
.B(n_87),
.Y(n_272)
);

NAND2xp5_ASAP7_75t_L g273 ( 
.A(n_236),
.B(n_9),
.Y(n_273)
);

OAI22xp5_ASAP7_75t_L g274 ( 
.A1(n_224),
.A2(n_88),
.B1(n_87),
.B2(n_9),
.Y(n_274)
);

INVx1_ASAP7_75t_L g275 ( 
.A(n_209),
.Y(n_275)
);

INVx1_ASAP7_75t_L g276 ( 
.A(n_212),
.Y(n_276)
);

INVx2_ASAP7_75t_L g277 ( 
.A(n_204),
.Y(n_277)
);

NOR2xp33_ASAP7_75t_SL g278 ( 
.A(n_235),
.B(n_97),
.Y(n_278)
);

HB1xp67_ASAP7_75t_L g279 ( 
.A(n_236),
.Y(n_279)
);

OR2x2_ASAP7_75t_L g280 ( 
.A(n_202),
.B(n_204),
.Y(n_280)
);

INVx2_ASAP7_75t_L g281 ( 
.A(n_233),
.Y(n_281)
);

NAND2xp5_ASAP7_75t_SL g282 ( 
.A(n_242),
.B(n_206),
.Y(n_282)
);

O2A1O1Ixp5_ASAP7_75t_L g283 ( 
.A1(n_249),
.A2(n_234),
.B(n_220),
.C(n_206),
.Y(n_283)
);

INVx1_ASAP7_75t_L g284 ( 
.A(n_238),
.Y(n_284)
);

AND2x2_ASAP7_75t_L g285 ( 
.A(n_254),
.B(n_212),
.Y(n_285)
);

NAND2xp5_ASAP7_75t_L g286 ( 
.A(n_239),
.B(n_231),
.Y(n_286)
);

AND2x2_ASAP7_75t_L g287 ( 
.A(n_265),
.B(n_233),
.Y(n_287)
);

O2A1O1Ixp33_ASAP7_75t_L g288 ( 
.A1(n_274),
.A2(n_220),
.B(n_219),
.C(n_217),
.Y(n_288)
);

INVx1_ASAP7_75t_L g289 ( 
.A(n_241),
.Y(n_289)
);

INVx1_ASAP7_75t_SL g290 ( 
.A(n_262),
.Y(n_290)
);

AND2x2_ASAP7_75t_L g291 ( 
.A(n_266),
.B(n_233),
.Y(n_291)
);

AO21x1_ASAP7_75t_L g292 ( 
.A1(n_257),
.A2(n_273),
.B(n_258),
.Y(n_292)
);

NAND2xp5_ASAP7_75t_L g293 ( 
.A(n_257),
.B(n_231),
.Y(n_293)
);

NAND2xp5_ASAP7_75t_L g294 ( 
.A(n_279),
.B(n_263),
.Y(n_294)
);

AOI22xp33_ASAP7_75t_L g295 ( 
.A1(n_256),
.A2(n_224),
.B1(n_235),
.B2(n_215),
.Y(n_295)
);

INVx1_ASAP7_75t_SL g296 ( 
.A(n_271),
.Y(n_296)
);

INVx1_ASAP7_75t_SL g297 ( 
.A(n_244),
.Y(n_297)
);

NOR3xp33_ASAP7_75t_L g298 ( 
.A(n_253),
.B(n_219),
.C(n_217),
.Y(n_298)
);

AOI22xp5_ASAP7_75t_L g299 ( 
.A1(n_278),
.A2(n_215),
.B1(n_225),
.B2(n_228),
.Y(n_299)
);

NAND2xp5_ASAP7_75t_L g300 ( 
.A(n_280),
.B(n_210),
.Y(n_300)
);

INVx1_ASAP7_75t_L g301 ( 
.A(n_251),
.Y(n_301)
);

AOI221xp5_ASAP7_75t_L g302 ( 
.A1(n_261),
.A2(n_225),
.B1(n_210),
.B2(n_227),
.C(n_228),
.Y(n_302)
);

NAND2xp5_ASAP7_75t_L g303 ( 
.A(n_264),
.B(n_210),
.Y(n_303)
);

NAND2xp5_ASAP7_75t_SL g304 ( 
.A(n_267),
.B(n_227),
.Y(n_304)
);

AOI32xp33_ASAP7_75t_L g305 ( 
.A1(n_269),
.A2(n_228),
.A3(n_210),
.B1(n_227),
.B2(n_10),
.Y(n_305)
);

NAND2xp5_ASAP7_75t_L g306 ( 
.A(n_268),
.B(n_227),
.Y(n_306)
);

INVx2_ASAP7_75t_L g307 ( 
.A(n_237),
.Y(n_307)
);

INVx1_ASAP7_75t_L g308 ( 
.A(n_270),
.Y(n_308)
);

AOI21xp33_ASAP7_75t_SL g309 ( 
.A1(n_269),
.A2(n_12),
.B(n_11),
.Y(n_309)
);

INVx1_ASAP7_75t_L g310 ( 
.A(n_275),
.Y(n_310)
);

NAND2xp5_ASAP7_75t_L g311 ( 
.A(n_243),
.B(n_218),
.Y(n_311)
);

NAND2xp5_ASAP7_75t_L g312 ( 
.A(n_260),
.B(n_218),
.Y(n_312)
);

AOI22xp5_ASAP7_75t_L g313 ( 
.A1(n_267),
.A2(n_88),
.B1(n_100),
.B2(n_11),
.Y(n_313)
);

INVx1_ASAP7_75t_L g314 ( 
.A(n_276),
.Y(n_314)
);

INVx1_ASAP7_75t_L g315 ( 
.A(n_247),
.Y(n_315)
);

A2O1A1Ixp33_ASAP7_75t_L g316 ( 
.A1(n_267),
.A2(n_14),
.B(n_13),
.C(n_12),
.Y(n_316)
);

NOR2xp33_ASAP7_75t_L g317 ( 
.A(n_260),
.B(n_240),
.Y(n_317)
);

INVx2_ASAP7_75t_L g318 ( 
.A(n_237),
.Y(n_318)
);

INVx1_ASAP7_75t_L g319 ( 
.A(n_246),
.Y(n_319)
);

INVx1_ASAP7_75t_L g320 ( 
.A(n_246),
.Y(n_320)
);

NAND2xp5_ASAP7_75t_L g321 ( 
.A(n_240),
.B(n_13),
.Y(n_321)
);

INVx1_ASAP7_75t_L g322 ( 
.A(n_252),
.Y(n_322)
);

OAI22xp33_ASAP7_75t_L g323 ( 
.A1(n_313),
.A2(n_299),
.B1(n_282),
.B2(n_293),
.Y(n_323)
);

INVx3_ASAP7_75t_L g324 ( 
.A(n_307),
.Y(n_324)
);

INVx1_ASAP7_75t_L g325 ( 
.A(n_284),
.Y(n_325)
);

NAND2xp5_ASAP7_75t_L g326 ( 
.A(n_317),
.B(n_244),
.Y(n_326)
);

INVx1_ASAP7_75t_L g327 ( 
.A(n_289),
.Y(n_327)
);

AOI22xp5_ASAP7_75t_L g328 ( 
.A1(n_282),
.A2(n_250),
.B1(n_258),
.B2(n_245),
.Y(n_328)
);

AND2x2_ASAP7_75t_L g329 ( 
.A(n_297),
.B(n_252),
.Y(n_329)
);

OR2x2_ASAP7_75t_L g330 ( 
.A(n_294),
.B(n_277),
.Y(n_330)
);

INVx1_ASAP7_75t_SL g331 ( 
.A(n_290),
.Y(n_331)
);

CKINVDCx6p67_ASAP7_75t_R g332 ( 
.A(n_321),
.Y(n_332)
);

INVx1_ASAP7_75t_L g333 ( 
.A(n_301),
.Y(n_333)
);

AOI21xp33_ASAP7_75t_L g334 ( 
.A1(n_292),
.A2(n_248),
.B(n_272),
.Y(n_334)
);

INVx2_ASAP7_75t_L g335 ( 
.A(n_307),
.Y(n_335)
);

INVxp67_ASAP7_75t_L g336 ( 
.A(n_317),
.Y(n_336)
);

AOI22xp5_ASAP7_75t_L g337 ( 
.A1(n_298),
.A2(n_272),
.B1(n_248),
.B2(n_277),
.Y(n_337)
);

AOI22xp5_ASAP7_75t_L g338 ( 
.A1(n_302),
.A2(n_281),
.B1(n_259),
.B2(n_255),
.Y(n_338)
);

NAND2xp5_ASAP7_75t_L g339 ( 
.A(n_287),
.B(n_281),
.Y(n_339)
);

INVx1_ASAP7_75t_L g340 ( 
.A(n_308),
.Y(n_340)
);

AOI21xp5_ASAP7_75t_L g341 ( 
.A1(n_316),
.A2(n_255),
.B(n_259),
.Y(n_341)
);

NAND2xp5_ASAP7_75t_L g342 ( 
.A(n_286),
.B(n_14),
.Y(n_342)
);

AOI221xp5_ASAP7_75t_L g343 ( 
.A1(n_309),
.A2(n_15),
.B1(n_88),
.B2(n_100),
.C(n_95),
.Y(n_343)
);

NOR2x1_ASAP7_75t_L g344 ( 
.A(n_319),
.B(n_88),
.Y(n_344)
);

INVx1_ASAP7_75t_L g345 ( 
.A(n_310),
.Y(n_345)
);

NAND2xp5_ASAP7_75t_L g346 ( 
.A(n_300),
.B(n_312),
.Y(n_346)
);

INVx1_ASAP7_75t_L g347 ( 
.A(n_314),
.Y(n_347)
);

NAND2xp5_ASAP7_75t_L g348 ( 
.A(n_291),
.B(n_15),
.Y(n_348)
);

INVx1_ASAP7_75t_L g349 ( 
.A(n_315),
.Y(n_349)
);

INVx1_ASAP7_75t_L g350 ( 
.A(n_349),
.Y(n_350)
);

OAI21xp5_ASAP7_75t_SL g351 ( 
.A1(n_323),
.A2(n_343),
.B(n_305),
.Y(n_351)
);

AOI21xp5_ASAP7_75t_L g352 ( 
.A1(n_334),
.A2(n_316),
.B(n_288),
.Y(n_352)
);

AOI21xp33_ASAP7_75t_L g353 ( 
.A1(n_334),
.A2(n_311),
.B(n_283),
.Y(n_353)
);

INVx1_ASAP7_75t_L g354 ( 
.A(n_325),
.Y(n_354)
);

INVxp67_ASAP7_75t_L g355 ( 
.A(n_342),
.Y(n_355)
);

AOI21xp33_ASAP7_75t_L g356 ( 
.A1(n_337),
.A2(n_295),
.B(n_304),
.Y(n_356)
);

AOI221x1_ASAP7_75t_SL g357 ( 
.A1(n_348),
.A2(n_320),
.B1(n_322),
.B2(n_306),
.C(n_303),
.Y(n_357)
);

OAI322xp33_ASAP7_75t_L g358 ( 
.A1(n_336),
.A2(n_304),
.A3(n_318),
.B1(n_296),
.B2(n_285),
.C1(n_88),
.C2(n_295),
.Y(n_358)
);

AOI22xp5_ASAP7_75t_L g359 ( 
.A1(n_328),
.A2(n_285),
.B1(n_318),
.B2(n_100),
.Y(n_359)
);

OAI311xp33_ASAP7_75t_L g360 ( 
.A1(n_338),
.A2(n_26),
.A3(n_25),
.B1(n_30),
.C1(n_31),
.Y(n_360)
);

OAI221xp5_ASAP7_75t_SL g361 ( 
.A1(n_341),
.A2(n_33),
.B1(n_32),
.B2(n_40),
.C(n_41),
.Y(n_361)
);

INVx1_ASAP7_75t_L g362 ( 
.A(n_327),
.Y(n_362)
);

AOI21xp33_ASAP7_75t_L g363 ( 
.A1(n_344),
.A2(n_45),
.B(n_43),
.Y(n_363)
);

OAI211xp5_ASAP7_75t_L g364 ( 
.A1(n_331),
.A2(n_48),
.B(n_47),
.C(n_46),
.Y(n_364)
);

NAND2xp5_ASAP7_75t_L g365 ( 
.A(n_357),
.B(n_331),
.Y(n_365)
);

INVx1_ASAP7_75t_L g366 ( 
.A(n_350),
.Y(n_366)
);

OAI211xp5_ASAP7_75t_SL g367 ( 
.A1(n_351),
.A2(n_345),
.B(n_340),
.C(n_333),
.Y(n_367)
);

OAI221xp5_ASAP7_75t_SL g368 ( 
.A1(n_352),
.A2(n_332),
.B1(n_326),
.B2(n_330),
.C(n_346),
.Y(n_368)
);

NAND2xp5_ASAP7_75t_L g369 ( 
.A(n_355),
.B(n_347),
.Y(n_369)
);

INVx1_ASAP7_75t_L g370 ( 
.A(n_354),
.Y(n_370)
);

AOI221xp5_ASAP7_75t_L g371 ( 
.A1(n_353),
.A2(n_339),
.B1(n_329),
.B2(n_324),
.C(n_335),
.Y(n_371)
);

NAND3xp33_ASAP7_75t_L g372 ( 
.A(n_361),
.B(n_324),
.C(n_50),
.Y(n_372)
);

NOR3xp33_ASAP7_75t_SL g373 ( 
.A(n_368),
.B(n_358),
.C(n_361),
.Y(n_373)
);

NAND5xp2_ASAP7_75t_L g374 ( 
.A(n_371),
.B(n_359),
.C(n_356),
.D(n_364),
.E(n_363),
.Y(n_374)
);

NAND2x1p5_ASAP7_75t_L g375 ( 
.A(n_366),
.B(n_362),
.Y(n_375)
);

NAND2xp5_ASAP7_75t_L g376 ( 
.A(n_365),
.B(n_360),
.Y(n_376)
);

NOR4xp25_ASAP7_75t_L g377 ( 
.A(n_376),
.B(n_367),
.C(n_372),
.D(n_369),
.Y(n_377)
);

NOR3xp33_ASAP7_75t_SL g378 ( 
.A(n_374),
.B(n_370),
.C(n_51),
.Y(n_378)
);

AND2x2_ASAP7_75t_L g379 ( 
.A(n_377),
.B(n_375),
.Y(n_379)
);

NOR2x1p5_ASAP7_75t_L g380 ( 
.A(n_378),
.B(n_373),
.Y(n_380)
);

INVx1_ASAP7_75t_L g381 ( 
.A(n_379),
.Y(n_381)
);

OAI21x1_ASAP7_75t_L g382 ( 
.A1(n_381),
.A2(n_379),
.B(n_380),
.Y(n_382)
);

AOI21xp5_ASAP7_75t_L g383 ( 
.A1(n_382),
.A2(n_57),
.B(n_52),
.Y(n_383)
);

AOI22xp5_ASAP7_75t_L g384 ( 
.A1(n_383),
.A2(n_95),
.B1(n_97),
.B2(n_116),
.Y(n_384)
);

AOI222xp33_ASAP7_75t_L g385 ( 
.A1(n_384),
.A2(n_95),
.B1(n_116),
.B2(n_379),
.C1(n_381),
.C2(n_380),
.Y(n_385)
);


endmodule