module fake_netlist_647_662_n_27 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_27);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_27;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_11;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_26;
wire n_9;
wire n_13;
wire n_8;

CKINVDCx20_ASAP7_75t_R g8 ( 
.A(n_2),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_6),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_6),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_11),
.B(n_1),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_12),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_13),
.Y(n_19)
);

OAI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_18),
.A2(n_14),
.B1(n_17),
.B2(n_11),
.Y(n_20)
);

INVxp33_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_14),
.B1(n_13),
.B2(n_8),
.C1(n_19),
.C2(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

AOI211xp5_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_8),
.B(n_19),
.C(n_4),
.Y(n_24)
);

AND4x1_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_7),
.C(n_5),
.D(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_25),
.A2(n_0),
.B1(n_3),
.B2(n_26),
.Y(n_27)
);


endmodule