module fake_netlist_647_1866_n_17 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_17);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_17;

wire n_14;
wire n_10;
wire n_11;
wire n_15;
wire n_9;
wire n_13;
wire n_8;
wire n_16;
wire n_12;

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_1),
.A2(n_2),
.B1(n_3),
.B2(n_5),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_7),
.B(n_1),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_6),
.B(n_4),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

OAI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B1(n_9),
.B2(n_10),
.Y(n_14)
);

OAI31xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_12),
.A3(n_6),
.B(n_4),
.Y(n_15)
);

AND3x1_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_7),
.C(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);


endmodule