module fake_netlist_647_1670_n_16 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_16);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_16;

wire n_14;
wire n_10;
wire n_11;
wire n_15;
wire n_9;
wire n_13;
wire n_8;
wire n_12;

NOR2xp33_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_4),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_2),
.Y(n_9)
);

BUFx10_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_7),
.B(n_6),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_8),
.C(n_6),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.Y(n_16)
);


endmodule