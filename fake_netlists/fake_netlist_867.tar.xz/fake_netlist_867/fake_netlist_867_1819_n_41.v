module fake_netlist_867_1819_n_41 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_41);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_41;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_9),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_6),
.B(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

BUFx8_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_19),
.A2(n_12),
.B1(n_13),
.B2(n_14),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_13),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

OAI22xp33_ASAP7_75t_SL g27 ( 
.A1(n_24),
.A2(n_20),
.B1(n_12),
.B2(n_19),
.Y(n_27)
);

INVxp67_ASAP7_75t_SL g28 ( 
.A(n_26),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_24),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_28),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_25),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_18),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_R g34 ( 
.A(n_31),
.B(n_1),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_22),
.B(n_13),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_1),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_34),
.Y(n_37)
);

OAI221xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_22),
.B1(n_7),
.B2(n_4),
.C(n_5),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_SL g39 ( 
.A1(n_37),
.A2(n_22),
.B1(n_7),
.B2(n_5),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_3),
.B1(n_8),
.B2(n_22),
.C1(n_38),
.C2(n_39),
.Y(n_41)
);


endmodule