module fake_netlist_867_2023_n_50 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_50);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_50;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_17;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

INVx1_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_3),
.B1(n_11),
.B2(n_1),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_6),
.A2(n_2),
.B1(n_8),
.B2(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_10),
.B(n_7),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_3),
.Y(n_22)
);

INVx4_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

OAI21xp33_ASAP7_75t_L g24 ( 
.A1(n_16),
.A2(n_12),
.B(n_9),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx6_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_27),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_23),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_SL g33 ( 
.A(n_31),
.B(n_24),
.C(n_20),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_22),
.B1(n_23),
.B2(n_21),
.C(n_18),
.Y(n_34)
);

OAI321xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_19),
.A3(n_17),
.B1(n_29),
.B2(n_1),
.C(n_0),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_SL g37 ( 
.A1(n_33),
.A2(n_2),
.B(n_0),
.Y(n_37)
);

AOI21xp5_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_26),
.B(n_4),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_R g39 ( 
.A(n_36),
.B(n_5),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_6),
.Y(n_40)
);

CKINVDCx6p67_ASAP7_75t_R g41 ( 
.A(n_35),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_7),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_SL g48 ( 
.A1(n_46),
.A2(n_39),
.B1(n_41),
.B2(n_10),
.Y(n_48)
);

OAI22x1_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_11),
.B1(n_41),
.B2(n_45),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_44),
.B1(n_47),
.B2(n_49),
.Y(n_50)
);


endmodule