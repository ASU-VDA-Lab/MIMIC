module fake_netlist_867_1978_n_7 (n_2, n_0, n_3, n_1, n_7);

input n_2;
input n_0;
input n_3;
input n_1;

output n_7;

wire n_6;
wire n_4;
wire n_5;

BUFx2_ASAP7_75t_R g4 ( 
.A(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_4),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);


endmodule