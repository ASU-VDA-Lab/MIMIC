module fake_netlist_867_1976_n_52 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_52);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_52;

wire n_49;
wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_7),
.B(n_1),
.Y(n_25)
);

OA21x2_ASAP7_75t_L g26 ( 
.A1(n_8),
.A2(n_11),
.B(n_19),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_17),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_10),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_6),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_18),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_15),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_0),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

AND2x2_ASAP7_75t_SL g35 ( 
.A(n_32),
.B(n_2),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_23),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_35),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_22),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_34),
.B1(n_31),
.B2(n_28),
.C(n_33),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_30),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_27),
.Y(n_42)
);

AOI21xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_25),
.B(n_26),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_27),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_3),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_4),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_47),
.Y(n_49)
);

NOR2xp67_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_46),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_48),
.Y(n_51)
);

AOI222xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_51),
.B1(n_13),
.B2(n_5),
.C1(n_16),
.C2(n_12),
.Y(n_52)
);


endmodule