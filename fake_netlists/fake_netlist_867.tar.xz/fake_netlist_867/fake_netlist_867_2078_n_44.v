module fake_netlist_867_2078_n_44 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_44);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_44;

wire n_25;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

BUFx10_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_8),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_13),
.B(n_5),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_14),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_10),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_L g29 ( 
.A(n_21),
.B(n_0),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_16),
.Y(n_31)
);

AO32x2_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_22),
.A3(n_25),
.B1(n_28),
.B2(n_17),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

NOR2x1p5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_24),
.Y(n_34)
);

NAND2x1_ASAP7_75t_SL g35 ( 
.A(n_32),
.B(n_22),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_33),
.B1(n_30),
.B2(n_23),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_26),
.B1(n_25),
.B2(n_19),
.C(n_20),
.Y(n_37)
);

AOI211xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_35),
.B(n_20),
.C(n_1),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_6),
.B(n_4),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_39),
.Y(n_40)
);

CKINVDCx20_ASAP7_75t_R g41 ( 
.A(n_38),
.Y(n_41)
);

AO21x1_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_9),
.B(n_7),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_11),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_R g44 ( 
.A1(n_42),
.A2(n_12),
.B1(n_15),
.B2(n_43),
.Y(n_44)
);


endmodule