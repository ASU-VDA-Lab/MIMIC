module fake_netlist_867_1588_n_52 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_52);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_52;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

INVx2_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_10),
.B(n_8),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_9),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_3),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_20),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_21),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_24),
.B(n_0),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_31),
.Y(n_36)
);

INVx4_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_SL g39 ( 
.A(n_33),
.B(n_30),
.C(n_29),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_34),
.B1(n_35),
.B2(n_23),
.Y(n_40)
);

NAND4xp25_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_32),
.C(n_28),
.D(n_25),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_39),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_SL g43 ( 
.A(n_41),
.B(n_26),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_27),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_46),
.B1(n_45),
.B2(n_1),
.C(n_4),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_R g48 ( 
.A(n_45),
.B(n_6),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

OAI221xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_12),
.B1(n_11),
.B2(n_13),
.C(n_15),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_SL g52 ( 
.A1(n_51),
.A2(n_50),
.B1(n_18),
.B2(n_16),
.Y(n_52)
);


endmodule