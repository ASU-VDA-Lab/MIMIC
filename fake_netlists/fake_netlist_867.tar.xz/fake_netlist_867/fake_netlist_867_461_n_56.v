module fake_netlist_867_461_n_56 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_56);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_56;

wire n_49;
wire n_48;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_39;
wire n_28;
wire n_53;
wire n_31;
wire n_32;
wire n_43;
wire n_37;
wire n_54;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

AND2x4_ASAP7_75t_L g27 ( 
.A(n_4),
.B(n_17),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_23),
.B(n_21),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_16),
.B(n_1),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_25),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_8),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_0),
.Y(n_34)
);

OA21x2_ASAP7_75t_L g35 ( 
.A1(n_2),
.A2(n_7),
.B(n_25),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_6),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_29),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

BUFx6f_ASAP7_75t_L g39 ( 
.A(n_31),
.Y(n_39)
);

AOI211xp5_ASAP7_75t_L g40 ( 
.A1(n_33),
.A2(n_9),
.B(n_5),
.C(n_3),
.Y(n_40)
);

CKINVDCx10_ASAP7_75t_R g41 ( 
.A(n_38),
.Y(n_41)
);

INVx4_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_37),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_41),
.Y(n_44)
);

OAI31xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_36),
.A3(n_34),
.B(n_27),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_42),
.Y(n_46)
);

INVx3_ASAP7_75t_SL g47 ( 
.A(n_44),
.Y(n_47)
);

INVxp67_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

CKINVDCx20_ASAP7_75t_R g50 ( 
.A(n_49),
.Y(n_50)
);

OAI322xp33_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_30),
.A3(n_31),
.B1(n_40),
.B2(n_28),
.C1(n_35),
.C2(n_10),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_50),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);

OAI222xp33_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_12),
.B1(n_11),
.B2(n_13),
.C1(n_18),
.C2(n_14),
.Y(n_55)
);

AOI222xp33_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_55),
.B1(n_22),
.B2(n_19),
.C1(n_26),
.C2(n_20),
.Y(n_56)
);


endmodule