module fake_netlist_867_2106_n_12 (n_2, n_0, n_1, n_12);

input n_2;
input n_0;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_8;

AND2x4_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

NAND3xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_2),
.C(n_0),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_3),
.Y(n_9)
);

OAI211xp5_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_3),
.C(n_2),
.Y(n_10)
);

AOI211x1_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B(n_1),
.C(n_4),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_4),
.B(n_8),
.Y(n_12)
);


endmodule