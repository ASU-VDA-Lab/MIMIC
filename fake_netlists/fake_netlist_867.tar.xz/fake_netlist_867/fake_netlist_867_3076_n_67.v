module fake_netlist_867_3076_n_67 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_67);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_67;

wire n_49;
wire n_48;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_35;
wire n_52;
wire n_38;
wire n_61;
wire n_45;
wire n_46;
wire n_51;

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_11),
.A2(n_10),
.B1(n_27),
.B2(n_4),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_23),
.A2(n_13),
.B1(n_15),
.B2(n_21),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_3),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_17),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_2),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_9),
.Y(n_35)
);

BUFx3_ASAP7_75t_L g36 ( 
.A(n_14),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_0),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_5),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_19),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_22),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_29),
.B(n_24),
.Y(n_41)
);

OAI21xp33_ASAP7_75t_L g42 ( 
.A1(n_36),
.A2(n_6),
.B(n_1),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_29),
.B(n_24),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_33),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_31),
.A2(n_27),
.B1(n_26),
.B2(n_25),
.Y(n_45)
);

OA21x2_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_32),
.B(n_30),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

OAI21x1_ASAP7_75t_L g48 ( 
.A1(n_42),
.A2(n_32),
.B(n_30),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_41),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_45),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_28),
.B1(n_34),
.B2(n_35),
.Y(n_51)
);

INVx2_ASAP7_75t_SL g52 ( 
.A(n_50),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

AO21x2_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_48),
.B(n_37),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_54),
.Y(n_55)
);

NOR2xp67_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_25),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_57),
.Y(n_58)
);

NOR3xp33_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_53),
.C(n_39),
.Y(n_59)
);

OAI222xp33_ASAP7_75t_L g60 ( 
.A1(n_55),
.A2(n_40),
.B1(n_38),
.B2(n_36),
.C1(n_54),
.C2(n_46),
.Y(n_60)
);

AND2x4_ASAP7_75t_L g61 ( 
.A(n_59),
.B(n_55),
.Y(n_61)
);

AO22x2_ASAP7_75t_L g62 ( 
.A1(n_58),
.A2(n_38),
.B1(n_48),
.B2(n_46),
.Y(n_62)
);

NAND4xp25_ASAP7_75t_SL g63 ( 
.A(n_58),
.B(n_12),
.C(n_8),
.D(n_7),
.Y(n_63)
);

OAI22xp5_ASAP7_75t_L g64 ( 
.A1(n_61),
.A2(n_46),
.B1(n_60),
.B2(n_48),
.Y(n_64)
);

NAND2x1_ASAP7_75t_L g65 ( 
.A(n_62),
.B(n_16),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_65),
.Y(n_66)
);

AOI22x1_ASAP7_75t_L g67 ( 
.A1(n_66),
.A2(n_62),
.B1(n_63),
.B2(n_64),
.Y(n_67)
);


endmodule