module fake_netlist_867_1244_n_38 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_38);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_38;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_27;

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_4),
.Y(n_25)
);

OAI21xp33_ASAP7_75t_SL g26 ( 
.A1(n_24),
.A2(n_16),
.B(n_5),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_27),
.B(n_23),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_21),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_25),
.Y(n_30)
);

OAI31xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_25),
.A3(n_19),
.B(n_26),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_28),
.B1(n_19),
.B2(n_22),
.C1(n_20),
.C2(n_5),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_17),
.B(n_16),
.C(n_1),
.Y(n_33)
);

XNOR2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_17),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_3),
.B(n_2),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_10),
.B1(n_9),
.B2(n_6),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_12),
.B1(n_14),
.B2(n_36),
.Y(n_38)
);


endmodule