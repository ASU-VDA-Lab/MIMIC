module fake_netlist_867_2743_n_40 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_40);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_40;

wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_17;
wire n_22;
wire n_34;
wire n_23;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

INVx1_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_12),
.B(n_11),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_1),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_4),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_5),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_19),
.B(n_6),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_18),
.Y(n_27)
);

OAI21x1_ASAP7_75t_SL g28 ( 
.A1(n_23),
.A2(n_16),
.B(n_15),
.Y(n_28)
);

AO21x2_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_17),
.B(n_26),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_24),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_25),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_32),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_31),
.Y(n_34)
);

XNOR2x1_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_18),
.Y(n_35)
);

NOR4xp25_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_21),
.C(n_7),
.D(n_6),
.Y(n_36)
);

AO22x2_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_36),
.B1(n_25),
.B2(n_29),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVx1_ASAP7_75t_SL g39 ( 
.A(n_38),
.Y(n_39)
);

AOI222xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_37),
.B1(n_7),
.B2(n_9),
.C1(n_8),
.C2(n_3),
.Y(n_40)
);


endmodule