module fake_netlist_867_993_n_55 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_55);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_55;

wire n_49;
wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_26;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx3_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_20),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_10),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_13),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_6),
.Y(n_32)
);

NAND2x1p5_ASAP7_75t_L g33 ( 
.A(n_0),
.B(n_1),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_15),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_8),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_2),
.B(n_18),
.Y(n_36)
);

AND2x6_ASAP7_75t_L g37 ( 
.A(n_25),
.B(n_3),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_27),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_30),
.Y(n_39)
);

BUFx6f_ASAP7_75t_L g40 ( 
.A(n_29),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_SL g41 ( 
.A(n_38),
.B(n_34),
.Y(n_41)
);

BUFx3_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_37),
.A2(n_32),
.B1(n_31),
.B2(n_26),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_28),
.B(n_25),
.Y(n_45)
);

AOI222xp33_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_41),
.B1(n_39),
.B2(n_35),
.C1(n_29),
.C2(n_40),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_22),
.Y(n_47)
);

AOI311xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_23),
.A3(n_22),
.B(n_33),
.C(n_40),
.Y(n_48)
);

OR2x6_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_29),
.Y(n_49)
);

OAI22xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_36),
.B1(n_5),
.B2(n_4),
.Y(n_50)
);

NOR2xp33_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_7),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_9),
.Y(n_53)
);

BUFx2_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);

AOI222xp33_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_52),
.B1(n_17),
.B2(n_11),
.C1(n_24),
.C2(n_14),
.Y(n_55)
);


endmodule