module fake_netlist_867_1155_n_33 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_33);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_33;

wire n_25;
wire n_20;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_27;

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_0),
.B(n_15),
.Y(n_18)
);

AO22x2_ASAP7_75t_L g19 ( 
.A1(n_8),
.A2(n_16),
.B1(n_4),
.B2(n_11),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_7),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_2),
.B(n_6),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_14),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_1),
.Y(n_25)
);

OAI21x1_ASAP7_75t_L g26 ( 
.A1(n_18),
.A2(n_5),
.B(n_3),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_9),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_28),
.B(n_20),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AO22x2_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_19),
.B1(n_24),
.B2(n_22),
.Y(n_32)
);

AOI222xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_29),
.B1(n_19),
.B2(n_26),
.C1(n_17),
.C2(n_12),
.Y(n_33)
);


endmodule