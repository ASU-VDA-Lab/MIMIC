module fake_netlist_867_2499_n_81 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_81);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_81;

wire n_49;
wire n_80;
wire n_78;
wire n_24;
wire n_54;
wire n_56;
wire n_59;
wire n_63;
wire n_74;
wire n_64;
wire n_79;
wire n_61;
wire n_43;
wire n_45;
wire n_48;
wire n_47;
wire n_76;
wire n_72;
wire n_73;
wire n_37;
wire n_42;
wire n_52;
wire n_77;
wire n_27;
wire n_57;
wire n_51;
wire n_25;
wire n_70;
wire n_41;
wire n_62;
wire n_44;
wire n_34;
wire n_40;
wire n_28;
wire n_53;
wire n_58;
wire n_68;
wire n_33;
wire n_55;
wire n_65;
wire n_75;
wire n_67;
wire n_66;
wire n_36;
wire n_50;
wire n_60;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_71;
wire n_69;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_46;

INVx3_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_14),
.B(n_13),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_10),
.Y(n_30)
);

CKINVDCx11_ASAP7_75t_R g31 ( 
.A(n_19),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_2),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_7),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_9),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_11),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_21),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_29),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_24),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_24),
.B(n_16),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_L g40 ( 
.A(n_29),
.B(n_1),
.C(n_0),
.Y(n_40)
);

BUFx8_ASAP7_75t_L g41 ( 
.A(n_35),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_36),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_35),
.B(n_17),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_36),
.A2(n_21),
.B1(n_20),
.B2(n_18),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_24),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_38),
.Y(n_46)
);

OAI21x1_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_32),
.B(n_27),
.Y(n_47)
);

OAI21x1_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_32),
.B(n_28),
.Y(n_48)
);

AO31x2_ASAP7_75t_L g49 ( 
.A1(n_37),
.A2(n_26),
.A3(n_39),
.B(n_44),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_34),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_41),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_46),
.B(n_36),
.Y(n_53)
);

AND2x4_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_48),
.Y(n_54)
);

OR2x2_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_46),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_49),
.Y(n_56)
);

INVx1_ASAP7_75t_SL g57 ( 
.A(n_50),
.Y(n_57)
);

INVx1_ASAP7_75t_SL g58 ( 
.A(n_55),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_L g60 ( 
.A1(n_54),
.A2(n_34),
.B1(n_52),
.B2(n_53),
.Y(n_60)
);

NOR2x1_ASAP7_75t_R g61 ( 
.A(n_54),
.B(n_31),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_57),
.B(n_49),
.Y(n_62)
);

AOI322xp5_ASAP7_75t_L g63 ( 
.A1(n_58),
.A2(n_42),
.A3(n_36),
.B1(n_31),
.B2(n_20),
.C1(n_25),
.C2(n_30),
.Y(n_63)
);

AOI22xp33_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_25),
.B1(n_33),
.B2(n_30),
.Y(n_64)
);

NAND2xp5_ASAP7_75t_L g65 ( 
.A(n_59),
.B(n_49),
.Y(n_65)
);

NOR2xp33_ASAP7_75t_L g66 ( 
.A(n_61),
.B(n_40),
.Y(n_66)
);

OAI21xp5_ASAP7_75t_SL g67 ( 
.A1(n_59),
.A2(n_33),
.B(n_30),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_62),
.Y(n_68)
);

INVxp67_ASAP7_75t_SL g69 ( 
.A(n_67),
.Y(n_69)
);

NOR3xp33_ASAP7_75t_SL g70 ( 
.A(n_66),
.B(n_49),
.C(n_30),
.Y(n_70)
);

NAND2x1p5_ASAP7_75t_L g71 ( 
.A(n_68),
.B(n_33),
.Y(n_71)
);

NAND3xp33_ASAP7_75t_L g72 ( 
.A(n_63),
.B(n_33),
.C(n_3),
.Y(n_72)
);

OR2x2_ASAP7_75t_L g73 ( 
.A(n_68),
.B(n_5),
.Y(n_73)
);

AO22x2_ASAP7_75t_SL g74 ( 
.A1(n_64),
.A2(n_22),
.B1(n_15),
.B2(n_8),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_73),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_69),
.Y(n_76)
);

INVx2_ASAP7_75t_L g77 ( 
.A(n_71),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_72),
.Y(n_78)
);

BUFx2_ASAP7_75t_L g79 ( 
.A(n_77),
.Y(n_79)
);

OAI221xp5_ASAP7_75t_L g80 ( 
.A1(n_76),
.A2(n_65),
.B1(n_70),
.B2(n_74),
.C(n_78),
.Y(n_80)
);

AOI22xp33_ASAP7_75t_L g81 ( 
.A1(n_80),
.A2(n_75),
.B1(n_79),
.B2(n_77),
.Y(n_81)
);


endmodule