module fake_netlist_780_987_n_27 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_27);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_27;

wire n_20;
wire n_17;
wire n_12;
wire n_25;
wire n_26;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_2),
.Y(n_12)
);

AND2x6_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_11),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

CKINVDCx16_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_9),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_SL g18 ( 
.A(n_15),
.B(n_0),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_3),
.B(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_16),
.Y(n_22)
);

AOI222xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_17),
.B1(n_13),
.B2(n_12),
.C1(n_6),
.C2(n_5),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

NOR2xp67_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_5),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.B(n_13),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B1(n_13),
.B2(n_4),
.Y(n_27)
);


endmodule