module fake_netlist_780_448_n_36 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_36);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_36;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_28;
wire n_8;
wire n_9;
wire n_30;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

AND2x4_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_4),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_6),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVxp67_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_1),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_7),
.B(n_1),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_14),
.B(n_8),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_SL g19 ( 
.A(n_15),
.B(n_11),
.C(n_7),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_17),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_22),
.B(n_21),
.Y(n_27)
);

AOI222xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_19),
.B1(n_23),
.B2(n_11),
.C1(n_7),
.C2(n_16),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_25),
.B(n_23),
.Y(n_29)
);

A2O1A1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_26),
.A2(n_16),
.B(n_3),
.C(n_2),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx5_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_32),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_16),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_SL g36 ( 
.A1(n_34),
.A2(n_31),
.B1(n_33),
.B2(n_35),
.Y(n_36)
);


endmodule