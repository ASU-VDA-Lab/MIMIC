module fake_netlist_780_1949_n_32 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_32);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_32;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_31;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_22;

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_12),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_8),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_2),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_10),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_16),
.A2(n_15),
.B1(n_4),
.B2(n_1),
.Y(n_23)
);

INVx4_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_19),
.Y(n_25)
);

NAND2xp33_ASAP7_75t_SL g26 ( 
.A(n_23),
.B(n_22),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_20),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_17),
.B(n_21),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B1(n_17),
.B2(n_15),
.C(n_5),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

AND3x4_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_9),
.C(n_7),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_R g32 ( 
.A1(n_31),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_32)
);


endmodule