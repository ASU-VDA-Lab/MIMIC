module fake_netlist_780_2850_n_25 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_25);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_25;

wire n_20;
wire n_17;
wire n_24;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_4),
.B(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_2),
.B(n_6),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_16),
.B(n_15),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_SL g19 ( 
.A1(n_17),
.A2(n_1),
.B(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

OR2x6_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_17),
.B1(n_18),
.B2(n_4),
.C(n_6),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_7),
.Y(n_23)
);

OAI22x1_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_9),
.B1(n_8),
.B2(n_3),
.Y(n_24)
);

AOI31xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_12),
.A3(n_11),
.B(n_10),
.Y(n_25)
);


endmodule