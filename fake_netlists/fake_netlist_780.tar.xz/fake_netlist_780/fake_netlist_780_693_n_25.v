module fake_netlist_780_693_n_25 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_25);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_25;

wire n_20;
wire n_17;
wire n_24;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx4_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_3),
.B(n_0),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_9),
.B(n_8),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_14),
.Y(n_20)
);

OAI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.B1(n_16),
.B2(n_19),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_5),
.C(n_4),
.Y(n_22)
);

NAND4xp75_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_6),
.C(n_5),
.D(n_4),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.C(n_6),
.D(n_10),
.Y(n_24)
);

AOI21x1_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_7),
.B(n_13),
.Y(n_25)
);


endmodule