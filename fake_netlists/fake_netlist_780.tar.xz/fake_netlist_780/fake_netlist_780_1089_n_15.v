module fake_netlist_780_1089_n_15 (n_1, n_2, n_0, n_15);

input n_1;
input n_2;
input n_0;

output n_15;

wire n_7;
wire n_10;
wire n_13;
wire n_11;
wire n_5;
wire n_6;
wire n_3;
wire n_9;
wire n_12;
wire n_14;
wire n_4;
wire n_8;

CKINVDCx20_ASAP7_75t_R g3 ( 
.A(n_2),
.Y(n_3)
);

INVx5_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_4),
.Y(n_8)
);

INVxp67_ASAP7_75t_SL g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_8),
.B(n_3),
.Y(n_11)
);

OAI211xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_9),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B1(n_10),
.B2(n_0),
.Y(n_15)
);


endmodule