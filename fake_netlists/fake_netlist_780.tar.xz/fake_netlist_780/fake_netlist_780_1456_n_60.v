module fake_netlist_780_1456_n_60 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_60);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_60;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_49;
wire n_43;
wire n_48;
wire n_56;
wire n_38;
wire n_54;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_59;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_13),
.B(n_17),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_10),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_15),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_1),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_24),
.B(n_15),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_21),
.A2(n_19),
.B1(n_17),
.B2(n_16),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_25),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_32),
.A2(n_30),
.B(n_26),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

AO32x2_ASAP7_75t_L g39 ( 
.A1(n_33),
.A2(n_21),
.A3(n_31),
.B1(n_22),
.B2(n_23),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_34),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_35),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_28),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_SL g46 ( 
.A(n_43),
.B(n_44),
.Y(n_46)
);

OAI211xp5_ASAP7_75t_SL g47 ( 
.A1(n_42),
.A2(n_28),
.B(n_27),
.C(n_24),
.Y(n_47)
);

AOI21xp33_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_23),
.B(n_22),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_29),
.B1(n_24),
.B2(n_31),
.Y(n_49)
);

NAND2xp33_ASAP7_75t_SL g50 ( 
.A(n_46),
.B(n_25),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

XOR2xp5_ASAP7_75t_L g52 ( 
.A(n_51),
.B(n_16),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

NAND4xp25_ASAP7_75t_L g54 ( 
.A(n_48),
.B(n_29),
.C(n_26),
.D(n_39),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_SL g55 ( 
.A(n_50),
.B(n_25),
.Y(n_55)
);

OR5x1_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_20),
.C(n_39),
.D(n_25),
.E(n_2),
.Y(n_56)
);

INVxp67_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_53),
.A2(n_36),
.B1(n_5),
.B2(n_3),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_57),
.B(n_55),
.Y(n_59)
);

AOI322xp5_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_56),
.A3(n_58),
.B1(n_36),
.B2(n_9),
.C1(n_7),
.C2(n_11),
.Y(n_60)
);


endmodule