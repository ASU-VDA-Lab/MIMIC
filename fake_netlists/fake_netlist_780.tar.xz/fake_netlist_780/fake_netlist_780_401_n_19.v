module fake_netlist_780_401_n_19 (n_1, n_0, n_5, n_3, n_2, n_4, n_19);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_19;

wire n_6;
wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_14;

CKINVDCx20_ASAP7_75t_R g6 ( 
.A(n_5),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_2),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_3),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_8),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_7),
.B(n_4),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_6),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_12),
.Y(n_13)
);

XNOR2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_17),
.B1(n_1),
.B2(n_0),
.Y(n_19)
);


endmodule