module fake_netlist_780_1258_n_31 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_31);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_31;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_4),
.B(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_13),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx2_ASAP7_75t_SL g21 ( 
.A(n_19),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_15),
.B(n_11),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_23),
.B(n_13),
.Y(n_25)
);

AOI211xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_15),
.B(n_14),
.C(n_16),
.Y(n_26)
);

NOR2x1_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_24),
.Y(n_27)
);

INVx2_ASAP7_75t_SL g28 ( 
.A(n_26),
.Y(n_28)
);

NAND4xp25_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_14),
.C(n_28),
.D(n_7),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_9),
.B1(n_8),
.B2(n_0),
.Y(n_31)
);


endmodule