module fake_netlist_780_963_n_38 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_38);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_38;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_18;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_1),
.B(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_8),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

AO22x1_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_20),
.B1(n_18),
.B2(n_19),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_16),
.B(n_18),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_24),
.B1(n_25),
.B2(n_18),
.C(n_20),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_27),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_28),
.B(n_18),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_6),
.C(n_4),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_29),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_4),
.Y(n_33)
);

INVx3_ASAP7_75t_SL g34 ( 
.A(n_31),
.Y(n_34)
);

OA21x2_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_16),
.B(n_20),
.Y(n_35)
);

NAND5xp2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_6),
.C(n_20),
.D(n_0),
.E(n_2),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_36),
.Y(n_37)
);

AOI222xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_35),
.B1(n_13),
.B2(n_9),
.C1(n_15),
.C2(n_11),
.Y(n_38)
);


endmodule