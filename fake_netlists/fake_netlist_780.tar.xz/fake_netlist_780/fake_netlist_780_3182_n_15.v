module fake_netlist_780_3182_n_15 (n_1, n_2, n_3, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_0;

output n_15;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_14;
wire n_9;
wire n_12;
wire n_13;
wire n_4;
wire n_8;

HB1xp67_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_SL g6 ( 
.A(n_1),
.Y(n_6)
);

INVx6_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

O2A1O1Ixp33_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_8),
.B(n_6),
.C(n_5),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_5),
.B1(n_6),
.B2(n_7),
.C(n_0),
.Y(n_12)
);

OAI311xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_1),
.A3(n_2),
.B1(n_3),
.C1(n_12),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_3),
.B(n_2),
.Y(n_15)
);


endmodule