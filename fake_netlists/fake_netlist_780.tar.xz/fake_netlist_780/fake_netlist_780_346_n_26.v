module fake_netlist_780_346_n_26 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_26);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_26;

wire n_20;
wire n_17;
wire n_12;
wire n_25;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_9;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

INVxp67_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_3),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_4),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_12),
.B(n_8),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_11),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_10),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_13),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_13),
.Y(n_20)
);

OAI22xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_9),
.B1(n_1),
.B2(n_0),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_18),
.B(n_4),
.C(n_2),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_5),
.Y(n_23)
);

NOR2x1p5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_6),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_24),
.B1(n_22),
.B2(n_7),
.Y(n_26)
);


endmodule