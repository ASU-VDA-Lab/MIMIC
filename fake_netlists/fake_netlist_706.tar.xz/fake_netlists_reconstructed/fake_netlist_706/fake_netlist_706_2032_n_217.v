module fake_netlist_706_2032_n_217 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_31, n_29, n_8, n_0, n_4, n_28, n_3, n_11, n_19, n_30, n_25, n_10, n_13, n_14, n_12, n_217);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_31;
input n_29;
input n_8;
input n_0;
input n_4;
input n_28;
input n_3;
input n_11;
input n_19;
input n_30;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_217;

wire n_61;
wire n_99;
wire n_210;
wire n_115;
wire n_110;
wire n_148;
wire n_86;
wire n_147;
wire n_171;
wire n_102;
wire n_40;
wire n_66;
wire n_165;
wire n_88;
wire n_47;
wire n_119;
wire n_175;
wire n_35;
wire n_196;
wire n_52;
wire n_213;
wire n_71;
wire n_150;
wire n_162;
wire n_157;
wire n_179;
wire n_121;
wire n_182;
wire n_60;
wire n_189;
wire n_33;
wire n_89;
wire n_114;
wire n_181;
wire n_194;
wire n_211;
wire n_212;
wire n_112;
wire n_197;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_83;
wire n_113;
wire n_131;
wire n_45;
wire n_204;
wire n_124;
wire n_158;
wire n_163;
wire n_130;
wire n_156;
wire n_64;
wire n_190;
wire n_146;
wire n_85;
wire n_136;
wire n_58;
wire n_62;
wire n_200;
wire n_76;
wire n_63;
wire n_184;
wire n_70;
wire n_69;
wire n_101;
wire n_141;
wire n_123;
wire n_53;
wire n_109;
wire n_168;
wire n_173;
wire n_74;
wire n_188;
wire n_160;
wire n_176;
wire n_209;
wire n_144;
wire n_170;
wire n_187;
wire n_208;
wire n_164;
wire n_94;
wire n_149;
wire n_81;
wire n_75;
wire n_161;
wire n_55;
wire n_192;
wire n_111;
wire n_54;
wire n_78;
wire n_207;
wire n_44;
wire n_38;
wire n_174;
wire n_203;
wire n_199;
wire n_91;
wire n_167;
wire n_42;
wire n_106;
wire n_116;
wire n_127;
wire n_34;
wire n_100;
wire n_145;
wire n_43;
wire n_84;
wire n_177;
wire n_37;
wire n_51;
wire n_191;
wire n_68;
wire n_140;
wire n_92;
wire n_195;
wire n_129;
wire n_90;
wire n_143;
wire n_169;
wire n_32;
wire n_77;
wire n_117;
wire n_134;
wire n_82;
wire n_152;
wire n_180;
wire n_128;
wire n_202;
wire n_172;
wire n_93;
wire n_193;
wire n_118;
wire n_97;
wire n_186;
wire n_214;
wire n_216;
wire n_95;
wire n_98;
wire n_103;
wire n_135;
wire n_125;
wire n_122;
wire n_79;
wire n_178;
wire n_154;
wire n_104;
wire n_105;
wire n_215;
wire n_139;
wire n_133;
wire n_183;
wire n_155;
wire n_120;
wire n_137;
wire n_46;
wire n_73;
wire n_41;
wire n_87;
wire n_205;
wire n_56;
wire n_159;
wire n_185;
wire n_72;
wire n_65;
wire n_80;
wire n_107;
wire n_132;
wire n_138;
wire n_151;
wire n_153;
wire n_201;
wire n_36;
wire n_142;
wire n_126;
wire n_206;
wire n_49;
wire n_57;
wire n_96;
wire n_166;
wire n_198;
wire n_108;

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_18),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_12),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_30),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_28),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_24),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_23),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_23),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_8),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_3),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_2),
.Y(n_42)
);

CKINVDCx16_ASAP7_75t_R g43 ( 
.A(n_20),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_30),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_20),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_9),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_13),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_11),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_40),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_35),
.B(n_6),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_35),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_42),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_43),
.B(n_6),
.Y(n_53)
);

BUFx6f_ASAP7_75t_L g54 ( 
.A(n_33),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_42),
.Y(n_55)
);

NAND2x1_ASAP7_75t_L g56 ( 
.A(n_36),
.B(n_7),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_40),
.Y(n_57)
);

INVx2_ASAP7_75t_SL g58 ( 
.A(n_49),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_SL g59 ( 
.A(n_49),
.B(n_46),
.Y(n_59)
);

NOR2xp33_ASAP7_75t_L g60 ( 
.A(n_51),
.B(n_41),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_52),
.Y(n_61)
);

BUFx2_ASAP7_75t_L g62 ( 
.A(n_50),
.Y(n_62)
);

NOR2x1p5_ASAP7_75t_L g63 ( 
.A(n_56),
.B(n_53),
.Y(n_63)
);

BUFx8_ASAP7_75t_L g64 ( 
.A(n_50),
.Y(n_64)
);

NAND2xp5_ASAP7_75t_L g65 ( 
.A(n_57),
.B(n_41),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_52),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_55),
.Y(n_67)
);

BUFx2_ASAP7_75t_L g68 ( 
.A(n_64),
.Y(n_68)
);

AOI22x1_ASAP7_75t_L g69 ( 
.A1(n_63),
.A2(n_57),
.B1(n_55),
.B2(n_50),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_58),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_58),
.B(n_56),
.Y(n_71)
);

NAND2xp5_ASAP7_75t_L g72 ( 
.A(n_62),
.B(n_47),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_61),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_SL g74 ( 
.A(n_64),
.B(n_47),
.Y(n_74)
);

NAND2xp5_ASAP7_75t_L g75 ( 
.A(n_62),
.B(n_64),
.Y(n_75)
);

BUFx12f_ASAP7_75t_L g76 ( 
.A(n_64),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_61),
.Y(n_77)
);

INVx2_ASAP7_75t_L g78 ( 
.A(n_66),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_66),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_67),
.Y(n_80)
);

AOI21xp5_ASAP7_75t_L g81 ( 
.A1(n_70),
.A2(n_59),
.B(n_65),
.Y(n_81)
);

NAND2xp5_ASAP7_75t_L g82 ( 
.A(n_78),
.B(n_63),
.Y(n_82)
);

AND2x2_ASAP7_75t_L g83 ( 
.A(n_68),
.B(n_67),
.Y(n_83)
);

AOI21xp5_ASAP7_75t_L g84 ( 
.A1(n_70),
.A2(n_65),
.B(n_60),
.Y(n_84)
);

INVx1_ASAP7_75t_SL g85 ( 
.A(n_68),
.Y(n_85)
);

BUFx10_ASAP7_75t_L g86 ( 
.A(n_76),
.Y(n_86)
);

AND2x2_ASAP7_75t_L g87 ( 
.A(n_78),
.B(n_36),
.Y(n_87)
);

AND2x4_ASAP7_75t_L g88 ( 
.A(n_75),
.B(n_38),
.Y(n_88)
);

NAND2xp5_ASAP7_75t_L g89 ( 
.A(n_78),
.B(n_32),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_73),
.Y(n_90)
);

AND2x4_ASAP7_75t_L g91 ( 
.A(n_74),
.B(n_38),
.Y(n_91)
);

AND2x2_ASAP7_75t_L g92 ( 
.A(n_76),
.B(n_39),
.Y(n_92)
);

OR2x2_ASAP7_75t_L g93 ( 
.A(n_72),
.B(n_34),
.Y(n_93)
);

O2A1O1Ixp33_ASAP7_75t_L g94 ( 
.A1(n_89),
.A2(n_71),
.B(n_72),
.C(n_73),
.Y(n_94)
);

NAND4xp25_ASAP7_75t_L g95 ( 
.A(n_92),
.B(n_45),
.C(n_39),
.D(n_48),
.Y(n_95)
);

INVx2_ASAP7_75t_L g96 ( 
.A(n_90),
.Y(n_96)
);

AO32x2_ASAP7_75t_L g97 ( 
.A1(n_91),
.A2(n_69),
.A3(n_54),
.B1(n_77),
.B2(n_79),
.Y(n_97)
);

AND2x2_ASAP7_75t_L g98 ( 
.A(n_93),
.B(n_76),
.Y(n_98)
);

AOI21xp5_ASAP7_75t_L g99 ( 
.A1(n_84),
.A2(n_79),
.B(n_77),
.Y(n_99)
);

OAI22xp5_ASAP7_75t_L g100 ( 
.A1(n_90),
.A2(n_80),
.B1(n_69),
.B2(n_37),
.Y(n_100)
);

AOI22xp5_ASAP7_75t_L g101 ( 
.A1(n_88),
.A2(n_80),
.B1(n_44),
.B2(n_45),
.Y(n_101)
);

BUFx3_ASAP7_75t_L g102 ( 
.A(n_86),
.Y(n_102)
);

NAND2xp5_ASAP7_75t_L g103 ( 
.A(n_83),
.B(n_48),
.Y(n_103)
);

AOI22xp5_ASAP7_75t_L g104 ( 
.A1(n_85),
.A2(n_33),
.B1(n_54),
.B2(n_7),
.Y(n_104)
);

A2O1A1Ixp33_ASAP7_75t_L g105 ( 
.A1(n_94),
.A2(n_84),
.B(n_81),
.C(n_90),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_96),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_99),
.Y(n_107)
);

AND2x4_ASAP7_75t_L g108 ( 
.A(n_102),
.B(n_83),
.Y(n_108)
);

NAND2xp5_ASAP7_75t_L g109 ( 
.A(n_101),
.B(n_93),
.Y(n_109)
);

HB1xp67_ASAP7_75t_L g110 ( 
.A(n_98),
.Y(n_110)
);

AOI21xp5_ASAP7_75t_L g111 ( 
.A1(n_100),
.A2(n_81),
.B(n_89),
.Y(n_111)
);

BUFx2_ASAP7_75t_L g112 ( 
.A(n_101),
.Y(n_112)
);

BUFx2_ASAP7_75t_L g113 ( 
.A(n_95),
.Y(n_113)
);

INVx2_ASAP7_75t_L g114 ( 
.A(n_107),
.Y(n_114)
);

AND2x2_ASAP7_75t_L g115 ( 
.A(n_106),
.B(n_87),
.Y(n_115)
);

BUFx2_ASAP7_75t_L g116 ( 
.A(n_108),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_106),
.Y(n_117)
);

OA21x2_ASAP7_75t_L g118 ( 
.A1(n_107),
.A2(n_104),
.B(n_103),
.Y(n_118)
);

OAI21xp5_ASAP7_75t_L g119 ( 
.A1(n_105),
.A2(n_92),
.B(n_88),
.Y(n_119)
);

NAND4xp25_ASAP7_75t_L g120 ( 
.A(n_113),
.B(n_92),
.C(n_88),
.D(n_91),
.Y(n_120)
);

AOI22xp5_ASAP7_75t_L g121 ( 
.A1(n_112),
.A2(n_83),
.B1(n_88),
.B2(n_91),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_112),
.Y(n_122)
);

AOI22xp5_ASAP7_75t_L g123 ( 
.A1(n_120),
.A2(n_113),
.B1(n_109),
.B2(n_108),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_115),
.B(n_110),
.Y(n_124)
);

AND2x2_ASAP7_75t_L g125 ( 
.A(n_122),
.B(n_108),
.Y(n_125)
);

AND2x2_ASAP7_75t_L g126 ( 
.A(n_122),
.B(n_108),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_114),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_117),
.Y(n_128)
);

INVx1_ASAP7_75t_L g129 ( 
.A(n_114),
.Y(n_129)
);

INVx4_ASAP7_75t_L g130 ( 
.A(n_116),
.Y(n_130)
);

OAI22xp5_ASAP7_75t_L g131 ( 
.A1(n_121),
.A2(n_85),
.B1(n_88),
.B2(n_91),
.Y(n_131)
);

INVx2_ASAP7_75t_L g132 ( 
.A(n_114),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_117),
.Y(n_133)
);

INVx2_ASAP7_75t_L g134 ( 
.A(n_115),
.Y(n_134)
);

NOR2xp33_ASAP7_75t_SL g135 ( 
.A(n_130),
.B(n_86),
.Y(n_135)
);

NAND2xp5_ASAP7_75t_L g136 ( 
.A(n_134),
.B(n_121),
.Y(n_136)
);

NAND2x1_ASAP7_75t_SL g137 ( 
.A(n_130),
.B(n_123),
.Y(n_137)
);

INVxp67_ASAP7_75t_SL g138 ( 
.A(n_132),
.Y(n_138)
);

AND2x2_ASAP7_75t_SL g139 ( 
.A(n_130),
.B(n_116),
.Y(n_139)
);

AOI22xp33_ASAP7_75t_L g140 ( 
.A1(n_131),
.A2(n_119),
.B1(n_118),
.B2(n_91),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_133),
.Y(n_141)
);

AND2x2_ASAP7_75t_L g142 ( 
.A(n_127),
.B(n_33),
.Y(n_142)
);

INVxp67_ASAP7_75t_L g143 ( 
.A(n_124),
.Y(n_143)
);

OR2x2_ASAP7_75t_L g144 ( 
.A(n_127),
.B(n_118),
.Y(n_144)
);

NAND2xp5_ASAP7_75t_L g145 ( 
.A(n_134),
.B(n_87),
.Y(n_145)
);

OAI222xp33_ASAP7_75t_L g146 ( 
.A1(n_133),
.A2(n_87),
.B1(n_111),
.B2(n_82),
.C1(n_17),
.C2(n_16),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_129),
.Y(n_147)
);

OAI21xp33_ASAP7_75t_SL g148 ( 
.A1(n_128),
.A2(n_97),
.B(n_82),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_129),
.Y(n_149)
);

NAND2xp5_ASAP7_75t_L g150 ( 
.A(n_126),
.B(n_118),
.Y(n_150)
);

NOR2xp33_ASAP7_75t_L g151 ( 
.A(n_126),
.B(n_86),
.Y(n_151)
);

AND2x2_ASAP7_75t_L g152 ( 
.A(n_150),
.B(n_132),
.Y(n_152)
);

NAND2xp5_ASAP7_75t_SL g153 ( 
.A(n_139),
.B(n_125),
.Y(n_153)
);

INVx2_ASAP7_75t_L g154 ( 
.A(n_141),
.Y(n_154)
);

OAI21xp33_ASAP7_75t_L g155 ( 
.A1(n_137),
.A2(n_125),
.B(n_33),
.Y(n_155)
);

OR2x2_ASAP7_75t_L g156 ( 
.A(n_143),
.B(n_118),
.Y(n_156)
);

NAND2xp5_ASAP7_75t_L g157 ( 
.A(n_141),
.B(n_16),
.Y(n_157)
);

NAND2xp5_ASAP7_75t_L g158 ( 
.A(n_136),
.B(n_17),
.Y(n_158)
);

AND2x2_ASAP7_75t_L g159 ( 
.A(n_147),
.B(n_33),
.Y(n_159)
);

INVxp67_ASAP7_75t_L g160 ( 
.A(n_135),
.Y(n_160)
);

BUFx3_ASAP7_75t_L g161 ( 
.A(n_139),
.Y(n_161)
);

NOR2xp33_ASAP7_75t_L g162 ( 
.A(n_151),
.B(n_18),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_147),
.Y(n_163)
);

NAND2xp5_ASAP7_75t_L g164 ( 
.A(n_149),
.B(n_19),
.Y(n_164)
);

AOI222xp33_ASAP7_75t_L g165 ( 
.A1(n_139),
.A2(n_33),
.B1(n_86),
.B2(n_22),
.C1(n_21),
.C2(n_19),
.Y(n_165)
);

NOR2xp33_ASAP7_75t_L g166 ( 
.A(n_137),
.B(n_21),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_SL g167 ( 
.A(n_142),
.B(n_54),
.Y(n_167)
);

NOR2x1p5_ASAP7_75t_L g168 ( 
.A(n_138),
.B(n_54),
.Y(n_168)
);

OAI211xp5_ASAP7_75t_L g169 ( 
.A1(n_140),
.A2(n_54),
.B(n_24),
.C(n_22),
.Y(n_169)
);

NAND2xp5_ASAP7_75t_L g170 ( 
.A(n_149),
.B(n_25),
.Y(n_170)
);

AOI22xp33_ASAP7_75t_L g171 ( 
.A1(n_142),
.A2(n_97),
.B1(n_26),
.B2(n_25),
.Y(n_171)
);

AND2x4_ASAP7_75t_L g172 ( 
.A(n_144),
.B(n_0),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_163),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_154),
.Y(n_174)
);

NAND2xp5_ASAP7_75t_L g175 ( 
.A(n_156),
.B(n_144),
.Y(n_175)
);

BUFx4f_ASAP7_75t_SL g176 ( 
.A(n_161),
.Y(n_176)
);

INVx2_ASAP7_75t_L g177 ( 
.A(n_154),
.Y(n_177)
);

NOR2xp33_ASAP7_75t_L g178 ( 
.A(n_160),
.B(n_146),
.Y(n_178)
);

NOR2xp33_ASAP7_75t_SL g179 ( 
.A(n_155),
.B(n_145),
.Y(n_179)
);

NAND2xp5_ASAP7_75t_SL g180 ( 
.A(n_155),
.B(n_148),
.Y(n_180)
);

NAND2xp5_ASAP7_75t_L g181 ( 
.A(n_156),
.B(n_148),
.Y(n_181)
);

NAND3xp33_ASAP7_75t_L g182 ( 
.A(n_165),
.B(n_97),
.C(n_26),
.Y(n_182)
);

INVxp67_ASAP7_75t_SL g183 ( 
.A(n_168),
.Y(n_183)
);

NAND2xp33_ASAP7_75t_SL g184 ( 
.A(n_168),
.B(n_27),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_163),
.Y(n_185)
);

NAND2xp5_ASAP7_75t_L g186 ( 
.A(n_152),
.B(n_27),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_152),
.Y(n_187)
);

AND2x4_ASAP7_75t_SL g188 ( 
.A(n_172),
.B(n_28),
.Y(n_188)
);

INVx1_ASAP7_75t_SL g189 ( 
.A(n_161),
.Y(n_189)
);

NAND2xp5_ASAP7_75t_L g190 ( 
.A(n_159),
.B(n_29),
.Y(n_190)
);

BUFx2_ASAP7_75t_L g191 ( 
.A(n_176),
.Y(n_191)
);

OR2x2_ASAP7_75t_L g192 ( 
.A(n_175),
.B(n_161),
.Y(n_192)
);

NOR2x1p5_ASAP7_75t_L g193 ( 
.A(n_183),
.B(n_158),
.Y(n_193)
);

AND2x2_ASAP7_75t_L g194 ( 
.A(n_187),
.B(n_159),
.Y(n_194)
);

NAND2xp5_ASAP7_75t_L g195 ( 
.A(n_187),
.B(n_172),
.Y(n_195)
);

BUFx3_ASAP7_75t_L g196 ( 
.A(n_188),
.Y(n_196)
);

NOR2x2_ASAP7_75t_L g197 ( 
.A(n_184),
.B(n_165),
.Y(n_197)
);

NAND2xp5_ASAP7_75t_SL g198 ( 
.A(n_179),
.B(n_172),
.Y(n_198)
);

AOI221x1_ASAP7_75t_L g199 ( 
.A1(n_184),
.A2(n_166),
.B1(n_157),
.B2(n_170),
.C(n_164),
.Y(n_199)
);

NAND2xp5_ASAP7_75t_SL g200 ( 
.A(n_180),
.B(n_172),
.Y(n_200)
);

NAND3xp33_ASAP7_75t_L g201 ( 
.A(n_178),
.B(n_162),
.C(n_169),
.Y(n_201)
);

NOR3xp33_ASAP7_75t_SL g202 ( 
.A(n_182),
.B(n_153),
.C(n_167),
.Y(n_202)
);

OAI22xp5_ASAP7_75t_L g203 ( 
.A1(n_196),
.A2(n_188),
.B1(n_189),
.B2(n_181),
.Y(n_203)
);

A2O1A1Ixp33_ASAP7_75t_L g204 ( 
.A1(n_196),
.A2(n_186),
.B(n_190),
.C(n_173),
.Y(n_204)
);

OAI221xp5_ASAP7_75t_L g205 ( 
.A1(n_201),
.A2(n_185),
.B1(n_171),
.B2(n_174),
.C(n_177),
.Y(n_205)
);

AOI21xp33_ASAP7_75t_L g206 ( 
.A1(n_200),
.A2(n_185),
.B(n_174),
.Y(n_206)
);

INVx1_ASAP7_75t_L g207 ( 
.A(n_194),
.Y(n_207)
);

XOR2xp5_ASAP7_75t_L g208 ( 
.A(n_191),
.B(n_29),
.Y(n_208)
);

OAI22xp5_ASAP7_75t_L g209 ( 
.A1(n_198),
.A2(n_177),
.B1(n_31),
.B2(n_1),
.Y(n_209)
);

AOI22xp5_ASAP7_75t_L g210 ( 
.A1(n_203),
.A2(n_200),
.B1(n_193),
.B2(n_198),
.Y(n_210)
);

AOI22xp5_ASAP7_75t_L g211 ( 
.A1(n_209),
.A2(n_202),
.B1(n_195),
.B2(n_192),
.Y(n_211)
);

XNOR2xp5_ASAP7_75t_L g212 ( 
.A(n_208),
.B(n_199),
.Y(n_212)
);

NOR3xp33_ASAP7_75t_L g213 ( 
.A(n_205),
.B(n_197),
.C(n_4),
.Y(n_213)
);

O2A1O1Ixp33_ASAP7_75t_L g214 ( 
.A1(n_213),
.A2(n_204),
.B(n_206),
.C(n_207),
.Y(n_214)
);

OAI22xp5_ASAP7_75t_L g215 ( 
.A1(n_210),
.A2(n_14),
.B1(n_10),
.B2(n_5),
.Y(n_215)
);

HB1xp67_ASAP7_75t_L g216 ( 
.A(n_215),
.Y(n_216)
);

AOI221xp5_ASAP7_75t_L g217 ( 
.A1(n_216),
.A2(n_212),
.B1(n_214),
.B2(n_211),
.C(n_15),
.Y(n_217)
);


endmodule