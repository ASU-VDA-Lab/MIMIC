module fake_netlist_706_1575_n_19 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_19);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_19;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVxp33_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_3),
.B(n_0),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_10),
.B2(n_7),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_7),
.Y(n_17)
);

NAND2xp33_ASAP7_75t_R g18 ( 
.A(n_17),
.B(n_4),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_17),
.B(n_6),
.Y(n_19)
);


endmodule