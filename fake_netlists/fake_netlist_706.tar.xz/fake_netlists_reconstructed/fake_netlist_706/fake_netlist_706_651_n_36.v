module fake_netlist_706_651_n_36 (n_9, n_4, n_2, n_7, n_14, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_36);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_36;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_2),
.B(n_6),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_28),
.Y(n_29)
);

AOI211xp5_ASAP7_75t_SL g30 ( 
.A1(n_28),
.A2(n_18),
.B(n_27),
.C(n_16),
.Y(n_30)
);

OAI221xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_24),
.B1(n_21),
.B2(n_19),
.C(n_17),
.Y(n_31)
);

AND4x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_24),
.C(n_4),
.D(n_0),
.Y(n_32)
);

OAI221xp5_ASAP7_75t_R g33 ( 
.A1(n_32),
.A2(n_18),
.B1(n_14),
.B2(n_5),
.C(n_29),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_31),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_33),
.B1(n_15),
.B2(n_20),
.Y(n_35)
);

AOI222xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_9),
.B1(n_7),
.B2(n_10),
.C1(n_13),
.C2(n_12),
.Y(n_36)
);


endmodule