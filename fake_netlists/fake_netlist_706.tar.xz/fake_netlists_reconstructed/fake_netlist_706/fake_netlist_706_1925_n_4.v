module fake_netlist_706_1925_n_4 (n_0, n_2, n_1, n_4);

input n_0;
input n_2;
input n_1;

output n_4;

wire n_3;

AND2x4_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

OA21x2_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_0),
.B(n_2),
.Y(n_4)
);


endmodule