module fake_netlist_706_2235_n_110 (n_2, n_21, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_110);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_110;

wire n_24;
wire n_61;
wire n_99;
wire n_27;
wire n_86;
wire n_102;
wire n_40;
wire n_66;
wire n_88;
wire n_47;
wire n_35;
wire n_52;
wire n_71;
wire n_60;
wire n_33;
wire n_89;
wire n_30;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_83;
wire n_45;
wire n_64;
wire n_85;
wire n_58;
wire n_62;
wire n_76;
wire n_63;
wire n_70;
wire n_69;
wire n_101;
wire n_53;
wire n_109;
wire n_74;
wire n_28;
wire n_94;
wire n_75;
wire n_81;
wire n_55;
wire n_54;
wire n_78;
wire n_44;
wire n_38;
wire n_91;
wire n_42;
wire n_106;
wire n_34;
wire n_100;
wire n_26;
wire n_43;
wire n_84;
wire n_37;
wire n_51;
wire n_23;
wire n_68;
wire n_92;
wire n_90;
wire n_32;
wire n_77;
wire n_82;
wire n_93;
wire n_97;
wire n_95;
wire n_98;
wire n_103;
wire n_79;
wire n_22;
wire n_104;
wire n_105;
wire n_46;
wire n_31;
wire n_73;
wire n_41;
wire n_87;
wire n_29;
wire n_56;
wire n_72;
wire n_65;
wire n_80;
wire n_107;
wire n_36;
wire n_25;
wire n_49;
wire n_57;
wire n_96;
wire n_108;

INVx3_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_7),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_16),
.Y(n_31)
);

BUFx3_ASAP7_75t_L g32 ( 
.A(n_20),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_11),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_22),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_33),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_30),
.Y(n_40)
);

INVx6_ASAP7_75t_L g41 ( 
.A(n_32),
.Y(n_41)
);

INVx3_ASAP7_75t_L g42 ( 
.A(n_26),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_35),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_36),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_34),
.B(n_40),
.Y(n_45)
);

AND2x6_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_23),
.Y(n_46)
);

BUFx6f_ASAP7_75t_L g47 ( 
.A(n_37),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

BUFx6f_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_46),
.A2(n_41),
.B1(n_24),
.B2(n_25),
.Y(n_52)
);

BUFx6f_ASAP7_75t_L g53 ( 
.A(n_46),
.Y(n_53)
);

CKINVDCx5p33_ASAP7_75t_R g54 ( 
.A(n_46),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

INVx5_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

BUFx6f_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_48),
.B(n_38),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_48),
.B(n_39),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_49),
.B(n_39),
.Y(n_60)
);

OAI22xp5_ASAP7_75t_L g61 ( 
.A1(n_52),
.A2(n_27),
.B1(n_31),
.B2(n_29),
.Y(n_61)
);

INVx4_ASAP7_75t_SL g62 ( 
.A(n_50),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_55),
.Y(n_63)
);

OAI21x1_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_9),
.B(n_8),
.Y(n_64)
);

OAI21x1_ASAP7_75t_L g65 ( 
.A1(n_58),
.A2(n_13),
.B(n_12),
.Y(n_65)
);

OAI21x1_ASAP7_75t_L g66 ( 
.A1(n_59),
.A2(n_15),
.B(n_14),
.Y(n_66)
);

INVx5_ASAP7_75t_L g67 ( 
.A(n_56),
.Y(n_67)
);

AO31x2_ASAP7_75t_L g68 ( 
.A1(n_61),
.A2(n_3),
.A3(n_2),
.B(n_1),
.Y(n_68)
);

INVx6_ASAP7_75t_L g69 ( 
.A(n_62),
.Y(n_69)
);

BUFx12f_ASAP7_75t_L g70 ( 
.A(n_57),
.Y(n_70)
);

NOR2xp33_ASAP7_75t_R g71 ( 
.A(n_57),
.B(n_19),
.Y(n_71)
);

HB1xp67_ASAP7_75t_L g72 ( 
.A(n_67),
.Y(n_72)
);

NOR2x1_ASAP7_75t_SL g73 ( 
.A(n_67),
.B(n_70),
.Y(n_73)
);

OA21x2_ASAP7_75t_L g74 ( 
.A1(n_65),
.A2(n_66),
.B(n_64),
.Y(n_74)
);

CKINVDCx20_ASAP7_75t_R g75 ( 
.A(n_71),
.Y(n_75)
);

HB1xp67_ASAP7_75t_L g76 ( 
.A(n_67),
.Y(n_76)
);

INVx4_ASAP7_75t_L g77 ( 
.A(n_69),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_68),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_63),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_78),
.Y(n_80)
);

AND2x4_ASAP7_75t_SL g81 ( 
.A(n_75),
.B(n_72),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_79),
.Y(n_82)
);

INVxp67_ASAP7_75t_L g83 ( 
.A(n_73),
.Y(n_83)
);

BUFx2_ASAP7_75t_L g84 ( 
.A(n_76),
.Y(n_84)
);

INVx2_ASAP7_75t_L g85 ( 
.A(n_74),
.Y(n_85)
);

INVx3_ASAP7_75t_L g86 ( 
.A(n_77),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_80),
.Y(n_87)
);

BUFx2_ASAP7_75t_L g88 ( 
.A(n_84),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_85),
.Y(n_89)
);

INVx5_ASAP7_75t_SL g90 ( 
.A(n_83),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_82),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_82),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_87),
.Y(n_93)
);

INVx1_ASAP7_75t_SL g94 ( 
.A(n_88),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_89),
.Y(n_95)
);

INVx2_ASAP7_75t_L g96 ( 
.A(n_95),
.Y(n_96)
);

INVx1_ASAP7_75t_L g97 ( 
.A(n_93),
.Y(n_97)
);

INVx1_ASAP7_75t_L g98 ( 
.A(n_93),
.Y(n_98)
);

INVx2_ASAP7_75t_L g99 ( 
.A(n_96),
.Y(n_99)
);

INVx2_ASAP7_75t_SL g100 ( 
.A(n_99),
.Y(n_100)
);

INVx2_ASAP7_75t_SL g101 ( 
.A(n_100),
.Y(n_101)
);

XNOR2xp5_ASAP7_75t_L g102 ( 
.A(n_101),
.B(n_81),
.Y(n_102)
);

INVxp67_ASAP7_75t_SL g103 ( 
.A(n_102),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_103),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_104),
.Y(n_105)
);

INVx3_ASAP7_75t_L g106 ( 
.A(n_105),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_106),
.Y(n_107)
);

AOI222xp33_ASAP7_75t_L g108 ( 
.A1(n_107),
.A2(n_90),
.B1(n_92),
.B2(n_91),
.C1(n_94),
.C2(n_97),
.Y(n_108)
);

NAND2xp5_ASAP7_75t_L g109 ( 
.A(n_108),
.B(n_97),
.Y(n_109)
);

AOI21xp5_ASAP7_75t_L g110 ( 
.A1(n_109),
.A2(n_86),
.B(n_98),
.Y(n_110)
);


endmodule