module fake_netlist_706_817_n_42 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_42);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_42;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_7),
.B(n_3),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_1),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_11),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_15),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_14),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_8),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_0),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_14),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_11),
.Y(n_27)
);

OR2x6_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_12),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_12),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_18),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_30),
.B(n_20),
.Y(n_31)
);

NAND2xp33_ASAP7_75t_R g32 ( 
.A(n_28),
.B(n_17),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_28),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_27),
.Y(n_34)
);

OAI22xp33_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_29),
.B1(n_22),
.B2(n_21),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_R g37 ( 
.A(n_36),
.B(n_24),
.Y(n_37)
);

AOI211xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_17),
.B(n_25),
.C(n_13),
.Y(n_38)
);

NAND4xp75_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_16),
.C(n_13),
.D(n_2),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_5),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_41),
.A2(n_9),
.B1(n_10),
.B2(n_40),
.Y(n_42)
);


endmodule