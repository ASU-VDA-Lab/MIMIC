module fake_netlist_706_1114_n_21 (n_4, n_2, n_3, n_1, n_5, n_0, n_21);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_21;

wire n_17;
wire n_6;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_7;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx3_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx4_ASAP7_75t_SL g7 ( 
.A(n_1),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_3),
.B(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_8),
.Y(n_12)
);

A2O1A1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_9),
.B(n_10),
.C(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

OAI21xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_9),
.B(n_12),
.Y(n_15)
);

AND3x1_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_7),
.C(n_2),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

NAND2x1_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_2),
.Y(n_18)
);

XNOR2x1_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_4),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_4),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_5),
.B1(n_17),
.B2(n_19),
.Y(n_21)
);


endmodule