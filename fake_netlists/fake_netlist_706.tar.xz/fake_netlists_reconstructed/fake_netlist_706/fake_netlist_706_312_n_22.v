module fake_netlist_706_312_n_22 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_22);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_22;

wire n_21;
wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_13;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

NOR2xp33_ASAP7_75t_SL g9 ( 
.A(n_0),
.B(n_3),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_2),
.B(n_1),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.B(n_9),
.Y(n_19)
);

OR4x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_13),
.C(n_12),
.D(n_10),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

XNOR2x1_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_7),
.Y(n_22)
);


endmodule