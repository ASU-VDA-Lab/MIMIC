module fake_netlist_706_1698_n_247 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_31, n_29, n_33, n_8, n_0, n_4, n_32, n_28, n_3, n_11, n_19, n_30, n_25, n_10, n_13, n_14, n_12, n_247);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_31;
input n_29;
input n_33;
input n_8;
input n_0;
input n_4;
input n_32;
input n_28;
input n_3;
input n_11;
input n_19;
input n_30;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_247;

wire n_61;
wire n_99;
wire n_210;
wire n_115;
wire n_233;
wire n_219;
wire n_110;
wire n_148;
wire n_86;
wire n_147;
wire n_171;
wire n_230;
wire n_165;
wire n_40;
wire n_66;
wire n_102;
wire n_235;
wire n_88;
wire n_119;
wire n_47;
wire n_175;
wire n_196;
wire n_35;
wire n_243;
wire n_52;
wire n_220;
wire n_213;
wire n_71;
wire n_150;
wire n_162;
wire n_234;
wire n_157;
wire n_179;
wire n_121;
wire n_182;
wire n_60;
wire n_189;
wire n_89;
wire n_114;
wire n_181;
wire n_194;
wire n_211;
wire n_212;
wire n_112;
wire n_197;
wire n_59;
wire n_48;
wire n_246;
wire n_67;
wire n_39;
wire n_50;
wire n_113;
wire n_83;
wire n_229;
wire n_131;
wire n_45;
wire n_204;
wire n_124;
wire n_158;
wire n_163;
wire n_130;
wire n_156;
wire n_64;
wire n_190;
wire n_146;
wire n_85;
wire n_136;
wire n_58;
wire n_218;
wire n_62;
wire n_200;
wire n_76;
wire n_63;
wire n_184;
wire n_70;
wire n_224;
wire n_101;
wire n_141;
wire n_69;
wire n_123;
wire n_53;
wire n_109;
wire n_231;
wire n_173;
wire n_168;
wire n_74;
wire n_188;
wire n_160;
wire n_176;
wire n_209;
wire n_226;
wire n_144;
wire n_244;
wire n_170;
wire n_187;
wire n_208;
wire n_164;
wire n_94;
wire n_149;
wire n_75;
wire n_81;
wire n_161;
wire n_55;
wire n_192;
wire n_111;
wire n_245;
wire n_54;
wire n_78;
wire n_207;
wire n_44;
wire n_38;
wire n_174;
wire n_203;
wire n_199;
wire n_91;
wire n_167;
wire n_42;
wire n_106;
wire n_236;
wire n_116;
wire n_127;
wire n_34;
wire n_225;
wire n_238;
wire n_100;
wire n_145;
wire n_43;
wire n_84;
wire n_177;
wire n_37;
wire n_51;
wire n_240;
wire n_191;
wire n_68;
wire n_140;
wire n_92;
wire n_241;
wire n_195;
wire n_129;
wire n_90;
wire n_143;
wire n_169;
wire n_77;
wire n_82;
wire n_134;
wire n_152;
wire n_117;
wire n_180;
wire n_228;
wire n_128;
wire n_202;
wire n_172;
wire n_93;
wire n_193;
wire n_118;
wire n_97;
wire n_186;
wire n_214;
wire n_216;
wire n_95;
wire n_98;
wire n_103;
wire n_135;
wire n_222;
wire n_125;
wire n_122;
wire n_79;
wire n_178;
wire n_154;
wire n_237;
wire n_104;
wire n_105;
wire n_215;
wire n_139;
wire n_133;
wire n_183;
wire n_155;
wire n_120;
wire n_242;
wire n_217;
wire n_137;
wire n_46;
wire n_73;
wire n_87;
wire n_41;
wire n_205;
wire n_56;
wire n_159;
wire n_185;
wire n_72;
wire n_65;
wire n_107;
wire n_132;
wire n_232;
wire n_227;
wire n_80;
wire n_138;
wire n_151;
wire n_153;
wire n_201;
wire n_36;
wire n_142;
wire n_126;
wire n_223;
wire n_221;
wire n_206;
wire n_57;
wire n_49;
wire n_96;
wire n_239;
wire n_166;
wire n_198;
wire n_108;

INVx1_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_17),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_2),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_24),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_16),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_21),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_5),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_3),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_22),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_15),
.Y(n_44)
);

CKINVDCx20_ASAP7_75t_R g45 ( 
.A(n_9),
.Y(n_45)
);

BUFx5_ASAP7_75t_L g46 ( 
.A(n_2),
.Y(n_46)
);

BUFx6f_ASAP7_75t_L g47 ( 
.A(n_14),
.Y(n_47)
);

INVxp67_ASAP7_75t_SL g48 ( 
.A(n_4),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_1),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_11),
.Y(n_50)
);

INVxp67_ASAP7_75t_SL g51 ( 
.A(n_1),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_19),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_23),
.Y(n_53)
);

CKINVDCx20_ASAP7_75t_R g54 ( 
.A(n_33),
.Y(n_54)
);

INVxp33_ASAP7_75t_L g55 ( 
.A(n_8),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_6),
.Y(n_56)
);

INVxp67_ASAP7_75t_SL g57 ( 
.A(n_7),
.Y(n_57)
);

BUFx6f_ASAP7_75t_L g58 ( 
.A(n_28),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_46),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_35),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_46),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_46),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_L g63 ( 
.A(n_37),
.B(n_0),
.Y(n_63)
);

AND2x2_ASAP7_75t_L g64 ( 
.A(n_55),
.B(n_46),
.Y(n_64)
);

AND2x4_ASAP7_75t_L g65 ( 
.A(n_56),
.B(n_36),
.Y(n_65)
);

BUFx6f_ASAP7_75t_L g66 ( 
.A(n_35),
.Y(n_66)
);

OAI21x1_ASAP7_75t_L g67 ( 
.A1(n_36),
.A2(n_12),
.B(n_10),
.Y(n_67)
);

INVx1_ASAP7_75t_SL g68 ( 
.A(n_54),
.Y(n_68)
);

BUFx6f_ASAP7_75t_L g69 ( 
.A(n_35),
.Y(n_69)
);

INVx4_ASAP7_75t_L g70 ( 
.A(n_46),
.Y(n_70)
);

INVx3_ASAP7_75t_L g71 ( 
.A(n_46),
.Y(n_71)
);

INVx3_ASAP7_75t_L g72 ( 
.A(n_70),
.Y(n_72)
);

AND2x6_ASAP7_75t_L g73 ( 
.A(n_64),
.B(n_34),
.Y(n_73)
);

AND2x4_ASAP7_75t_L g74 ( 
.A(n_64),
.B(n_56),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_71),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_64),
.B(n_44),
.Y(n_76)
);

AND2x4_ASAP7_75t_L g77 ( 
.A(n_64),
.B(n_41),
.Y(n_77)
);

NAND2xp5_ASAP7_75t_SL g78 ( 
.A(n_65),
.B(n_44),
.Y(n_78)
);

AND2x4_ASAP7_75t_L g79 ( 
.A(n_65),
.B(n_42),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_71),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_71),
.Y(n_81)
);

INVx4_ASAP7_75t_L g82 ( 
.A(n_70),
.Y(n_82)
);

NAND2xp5_ASAP7_75t_SL g83 ( 
.A(n_65),
.B(n_52),
.Y(n_83)
);

NAND2xp5_ASAP7_75t_L g84 ( 
.A(n_65),
.B(n_53),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_70),
.Y(n_85)
);

INVxp67_ASAP7_75t_L g86 ( 
.A(n_68),
.Y(n_86)
);

AO22x2_ASAP7_75t_L g87 ( 
.A1(n_70),
.A2(n_40),
.B1(n_39),
.B2(n_38),
.Y(n_87)
);

INVx3_ASAP7_75t_L g88 ( 
.A(n_70),
.Y(n_88)
);

BUFx6f_ASAP7_75t_L g89 ( 
.A(n_82),
.Y(n_89)
);

AND2x6_ASAP7_75t_L g90 ( 
.A(n_79),
.B(n_38),
.Y(n_90)
);

NOR2xp33_ASAP7_75t_L g91 ( 
.A(n_76),
.B(n_68),
.Y(n_91)
);

OAI22xp5_ASAP7_75t_L g92 ( 
.A1(n_87),
.A2(n_63),
.B1(n_45),
.B2(n_42),
.Y(n_92)
);

INVx2_ASAP7_75t_L g93 ( 
.A(n_81),
.Y(n_93)
);

INVx3_ASAP7_75t_SL g94 ( 
.A(n_87),
.Y(n_94)
);

OR2x2_ASAP7_75t_L g95 ( 
.A(n_86),
.B(n_63),
.Y(n_95)
);

AND2x6_ASAP7_75t_SL g96 ( 
.A(n_79),
.B(n_45),
.Y(n_96)
);

NAND2xp5_ASAP7_75t_L g97 ( 
.A(n_77),
.B(n_59),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_77),
.B(n_59),
.Y(n_98)
);

INVx3_ASAP7_75t_L g99 ( 
.A(n_79),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_81),
.Y(n_100)
);

INVx3_ASAP7_75t_L g101 ( 
.A(n_79),
.Y(n_101)
);

INVx2_ASAP7_75t_L g102 ( 
.A(n_72),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_87),
.Y(n_103)
);

AND2x2_ASAP7_75t_L g104 ( 
.A(n_87),
.B(n_46),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_77),
.B(n_59),
.Y(n_105)
);

NAND2xp5_ASAP7_75t_L g106 ( 
.A(n_77),
.B(n_61),
.Y(n_106)
);

OR2x6_ASAP7_75t_L g107 ( 
.A(n_87),
.B(n_67),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_73),
.Y(n_108)
);

BUFx2_ASAP7_75t_L g109 ( 
.A(n_73),
.Y(n_109)
);

BUFx3_ASAP7_75t_L g110 ( 
.A(n_73),
.Y(n_110)
);

CKINVDCx14_ASAP7_75t_R g111 ( 
.A(n_73),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_73),
.Y(n_112)
);

AND2x4_ASAP7_75t_L g113 ( 
.A(n_74),
.B(n_67),
.Y(n_113)
);

INVx2_ASAP7_75t_L g114 ( 
.A(n_72),
.Y(n_114)
);

BUFx3_ASAP7_75t_L g115 ( 
.A(n_73),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_73),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_72),
.Y(n_117)
);

INVx1_ASAP7_75t_SL g118 ( 
.A(n_94),
.Y(n_118)
);

INVx2_ASAP7_75t_L g119 ( 
.A(n_93),
.Y(n_119)
);

AOI21xp5_ASAP7_75t_L g120 ( 
.A1(n_113),
.A2(n_85),
.B(n_75),
.Y(n_120)
);

OAI22xp5_ASAP7_75t_L g121 ( 
.A1(n_94),
.A2(n_84),
.B1(n_74),
.B2(n_83),
.Y(n_121)
);

INVx2_ASAP7_75t_L g122 ( 
.A(n_93),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_93),
.Y(n_123)
);

HB1xp67_ASAP7_75t_L g124 ( 
.A(n_110),
.Y(n_124)
);

AOI22xp33_ASAP7_75t_L g125 ( 
.A1(n_103),
.A2(n_104),
.B1(n_92),
.B2(n_90),
.Y(n_125)
);

NOR2xp33_ASAP7_75t_L g126 ( 
.A(n_95),
.B(n_78),
.Y(n_126)
);

NAND2xp5_ASAP7_75t_L g127 ( 
.A(n_95),
.B(n_74),
.Y(n_127)
);

AOI22xp5_ASAP7_75t_L g128 ( 
.A1(n_92),
.A2(n_74),
.B1(n_51),
.B2(n_48),
.Y(n_128)
);

BUFx3_ASAP7_75t_L g129 ( 
.A(n_110),
.Y(n_129)
);

BUFx6f_ASAP7_75t_L g130 ( 
.A(n_89),
.Y(n_130)
);

OR2x6_ASAP7_75t_L g131 ( 
.A(n_115),
.B(n_82),
.Y(n_131)
);

INVx2_ASAP7_75t_SL g132 ( 
.A(n_115),
.Y(n_132)
);

HB1xp67_ASAP7_75t_L g133 ( 
.A(n_115),
.Y(n_133)
);

AOI22xp5_ASAP7_75t_L g134 ( 
.A1(n_104),
.A2(n_57),
.B1(n_62),
.B2(n_61),
.Y(n_134)
);

NAND3x1_ASAP7_75t_L g135 ( 
.A(n_128),
.B(n_104),
.C(n_91),
.Y(n_135)
);

INVx2_ASAP7_75t_L g136 ( 
.A(n_119),
.Y(n_136)
);

NAND3xp33_ASAP7_75t_L g137 ( 
.A(n_125),
.B(n_107),
.C(n_113),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_123),
.Y(n_138)
);

AND2x2_ASAP7_75t_SL g139 ( 
.A(n_125),
.B(n_113),
.Y(n_139)
);

CKINVDCx6p67_ASAP7_75t_R g140 ( 
.A(n_131),
.Y(n_140)
);

BUFx3_ASAP7_75t_L g141 ( 
.A(n_130),
.Y(n_141)
);

AND2x2_ASAP7_75t_L g142 ( 
.A(n_127),
.B(n_113),
.Y(n_142)
);

AND2x4_ASAP7_75t_L g143 ( 
.A(n_131),
.B(n_108),
.Y(n_143)
);

BUFx6f_ASAP7_75t_L g144 ( 
.A(n_130),
.Y(n_144)
);

AND2x2_ASAP7_75t_L g145 ( 
.A(n_127),
.B(n_109),
.Y(n_145)
);

INVx2_ASAP7_75t_L g146 ( 
.A(n_119),
.Y(n_146)
);

NAND2xp5_ASAP7_75t_SL g147 ( 
.A(n_118),
.B(n_89),
.Y(n_147)
);

AOI22xp33_ASAP7_75t_L g148 ( 
.A1(n_126),
.A2(n_90),
.B1(n_101),
.B2(n_99),
.Y(n_148)
);

INVx2_ASAP7_75t_L g149 ( 
.A(n_119),
.Y(n_149)
);

AOI22xp5_ASAP7_75t_L g150 ( 
.A1(n_121),
.A2(n_90),
.B1(n_111),
.B2(n_107),
.Y(n_150)
);

INVx2_ASAP7_75t_L g151 ( 
.A(n_136),
.Y(n_151)
);

INVx4_ASAP7_75t_L g152 ( 
.A(n_140),
.Y(n_152)
);

NAND2xp5_ASAP7_75t_L g153 ( 
.A(n_142),
.B(n_134),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_138),
.Y(n_154)
);

OAI211xp5_ASAP7_75t_L g155 ( 
.A1(n_150),
.A2(n_148),
.B(n_137),
.C(n_49),
.Y(n_155)
);

NOR2x1_ASAP7_75t_SL g156 ( 
.A(n_138),
.B(n_131),
.Y(n_156)
);

INVx2_ASAP7_75t_L g157 ( 
.A(n_136),
.Y(n_157)
);

AOI21xp33_ASAP7_75t_L g158 ( 
.A1(n_135),
.A2(n_116),
.B(n_112),
.Y(n_158)
);

AOI222xp33_ASAP7_75t_L g159 ( 
.A1(n_139),
.A2(n_96),
.B1(n_90),
.B2(n_105),
.C1(n_98),
.C2(n_97),
.Y(n_159)
);

OAI21x1_ASAP7_75t_L g160 ( 
.A1(n_136),
.A2(n_67),
.B(n_120),
.Y(n_160)
);

AOI222xp33_ASAP7_75t_L g161 ( 
.A1(n_139),
.A2(n_96),
.B1(n_90),
.B2(n_105),
.C1(n_106),
.C2(n_123),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_146),
.Y(n_162)
);

OR2x2_ASAP7_75t_L g163 ( 
.A(n_162),
.B(n_146),
.Y(n_163)
);

AOI21xp5_ASAP7_75t_L g164 ( 
.A1(n_162),
.A2(n_107),
.B(n_137),
.Y(n_164)
);

AND2x2_ASAP7_75t_L g165 ( 
.A(n_154),
.B(n_142),
.Y(n_165)
);

AOI22xp33_ASAP7_75t_L g166 ( 
.A1(n_161),
.A2(n_140),
.B1(n_142),
.B2(n_145),
.Y(n_166)
);

INVx2_ASAP7_75t_L g167 ( 
.A(n_151),
.Y(n_167)
);

OAI21x1_ASAP7_75t_L g168 ( 
.A1(n_160),
.A2(n_67),
.B(n_149),
.Y(n_168)
);

NAND3xp33_ASAP7_75t_L g169 ( 
.A(n_161),
.B(n_149),
.C(n_147),
.Y(n_169)
);

OAI31xp33_ASAP7_75t_L g170 ( 
.A1(n_155),
.A2(n_50),
.A3(n_43),
.B(n_40),
.Y(n_170)
);

NAND3xp33_ASAP7_75t_L g171 ( 
.A(n_159),
.B(n_58),
.C(n_47),
.Y(n_171)
);

NOR2xp33_ASAP7_75t_L g172 ( 
.A(n_152),
.B(n_143),
.Y(n_172)
);

AND2x2_ASAP7_75t_L g173 ( 
.A(n_151),
.B(n_122),
.Y(n_173)
);

AOI22xp33_ASAP7_75t_L g174 ( 
.A1(n_153),
.A2(n_143),
.B1(n_133),
.B2(n_124),
.Y(n_174)
);

AOI22xp33_ASAP7_75t_L g175 ( 
.A1(n_166),
.A2(n_152),
.B1(n_143),
.B2(n_158),
.Y(n_175)
);

NAND2xp5_ASAP7_75t_L g176 ( 
.A(n_165),
.B(n_157),
.Y(n_176)
);

AO21x2_ASAP7_75t_L g177 ( 
.A1(n_164),
.A2(n_160),
.B(n_156),
.Y(n_177)
);

INVx2_ASAP7_75t_L g178 ( 
.A(n_167),
.Y(n_178)
);

INVx2_ASAP7_75t_L g179 ( 
.A(n_173),
.Y(n_179)
);

AND2x2_ASAP7_75t_L g180 ( 
.A(n_172),
.B(n_171),
.Y(n_180)
);

INVx2_ASAP7_75t_L g181 ( 
.A(n_168),
.Y(n_181)
);

BUFx3_ASAP7_75t_L g182 ( 
.A(n_169),
.Y(n_182)
);

OR2x2_ASAP7_75t_L g183 ( 
.A(n_170),
.B(n_122),
.Y(n_183)
);

AND2x2_ASAP7_75t_L g184 ( 
.A(n_174),
.B(n_141),
.Y(n_184)
);

INVx1_ASAP7_75t_SL g185 ( 
.A(n_163),
.Y(n_185)
);

BUFx6f_ASAP7_75t_L g186 ( 
.A(n_163),
.Y(n_186)
);

OR2x2_ASAP7_75t_L g187 ( 
.A(n_185),
.B(n_60),
.Y(n_187)
);

AND2x2_ASAP7_75t_L g188 ( 
.A(n_186),
.B(n_47),
.Y(n_188)
);

INVx2_ASAP7_75t_L g189 ( 
.A(n_178),
.Y(n_189)
);

OR2x4_ASAP7_75t_L g190 ( 
.A(n_186),
.B(n_47),
.Y(n_190)
);

OR2x2_ASAP7_75t_L g191 ( 
.A(n_185),
.B(n_58),
.Y(n_191)
);

OR2x2_ASAP7_75t_L g192 ( 
.A(n_186),
.B(n_58),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_179),
.B(n_66),
.Y(n_193)
);

AND2x4_ASAP7_75t_L g194 ( 
.A(n_177),
.B(n_66),
.Y(n_194)
);

AND2x2_ASAP7_75t_L g195 ( 
.A(n_179),
.B(n_66),
.Y(n_195)
);

AND2x2_ASAP7_75t_L g196 ( 
.A(n_179),
.B(n_66),
.Y(n_196)
);

AND2x2_ASAP7_75t_L g197 ( 
.A(n_177),
.B(n_66),
.Y(n_197)
);

AND2x2_ASAP7_75t_L g198 ( 
.A(n_177),
.B(n_176),
.Y(n_198)
);

AND2x4_ASAP7_75t_L g199 ( 
.A(n_181),
.B(n_69),
.Y(n_199)
);

INVx1_ASAP7_75t_L g200 ( 
.A(n_181),
.Y(n_200)
);

AND2x2_ASAP7_75t_L g201 ( 
.A(n_182),
.B(n_69),
.Y(n_201)
);

NOR2x1_ASAP7_75t_L g202 ( 
.A(n_180),
.B(n_144),
.Y(n_202)
);

INVx2_ASAP7_75t_L g203 ( 
.A(n_189),
.Y(n_203)
);

AND2x2_ASAP7_75t_L g204 ( 
.A(n_198),
.B(n_184),
.Y(n_204)
);

OR2x2_ASAP7_75t_L g205 ( 
.A(n_191),
.B(n_183),
.Y(n_205)
);

AND2x4_ASAP7_75t_L g206 ( 
.A(n_202),
.B(n_175),
.Y(n_206)
);

INVxp67_ASAP7_75t_L g207 ( 
.A(n_188),
.Y(n_207)
);

BUFx2_ASAP7_75t_L g208 ( 
.A(n_190),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_187),
.Y(n_209)
);

NOR2xp67_ASAP7_75t_L g210 ( 
.A(n_194),
.B(n_8),
.Y(n_210)
);

INVxp67_ASAP7_75t_L g211 ( 
.A(n_201),
.Y(n_211)
);

BUFx3_ASAP7_75t_L g212 ( 
.A(n_192),
.Y(n_212)
);

INVx2_ASAP7_75t_L g213 ( 
.A(n_189),
.Y(n_213)
);

INVx2_ASAP7_75t_SL g214 ( 
.A(n_208),
.Y(n_214)
);

AND2x2_ASAP7_75t_L g215 ( 
.A(n_204),
.B(n_197),
.Y(n_215)
);

INVxp67_ASAP7_75t_L g216 ( 
.A(n_212),
.Y(n_216)
);

A2O1A1Ixp33_ASAP7_75t_L g217 ( 
.A1(n_210),
.A2(n_194),
.B(n_201),
.C(n_199),
.Y(n_217)
);

AOI321xp33_ASAP7_75t_L g218 ( 
.A1(n_206),
.A2(n_193),
.A3(n_196),
.B1(n_195),
.B2(n_200),
.C(n_199),
.Y(n_218)
);

AND2x2_ASAP7_75t_SL g219 ( 
.A(n_206),
.B(n_130),
.Y(n_219)
);

NAND2xp5_ASAP7_75t_L g220 ( 
.A(n_209),
.B(n_13),
.Y(n_220)
);

AND2x2_ASAP7_75t_L g221 ( 
.A(n_211),
.B(n_207),
.Y(n_221)
);

OR2x2_ASAP7_75t_L g222 ( 
.A(n_205),
.B(n_130),
.Y(n_222)
);

NAND2xp5_ASAP7_75t_L g223 ( 
.A(n_206),
.B(n_18),
.Y(n_223)
);

INVx1_ASAP7_75t_L g224 ( 
.A(n_203),
.Y(n_224)
);

AND2x2_ASAP7_75t_L g225 ( 
.A(n_214),
.B(n_213),
.Y(n_225)
);

AND2x2_ASAP7_75t_L g226 ( 
.A(n_221),
.B(n_20),
.Y(n_226)
);

INVx2_ASAP7_75t_L g227 ( 
.A(n_224),
.Y(n_227)
);

OAI22xp5_ASAP7_75t_L g228 ( 
.A1(n_219),
.A2(n_132),
.B1(n_129),
.B2(n_100),
.Y(n_228)
);

OAI22xp5_ASAP7_75t_L g229 ( 
.A1(n_217),
.A2(n_89),
.B1(n_26),
.B2(n_25),
.Y(n_229)
);

INVxp67_ASAP7_75t_SL g230 ( 
.A(n_216),
.Y(n_230)
);

INVx1_ASAP7_75t_L g231 ( 
.A(n_230),
.Y(n_231)
);

INVx2_ASAP7_75t_L g232 ( 
.A(n_227),
.Y(n_232)
);

OAI22xp33_ASAP7_75t_L g233 ( 
.A1(n_229),
.A2(n_215),
.B1(n_218),
.B2(n_223),
.Y(n_233)
);

XNOR2x1_ASAP7_75t_L g234 ( 
.A(n_226),
.B(n_222),
.Y(n_234)
);

AND2x2_ASAP7_75t_L g235 ( 
.A(n_225),
.B(n_220),
.Y(n_235)
);

OAI22xp33_ASAP7_75t_L g236 ( 
.A1(n_228),
.A2(n_32),
.B1(n_31),
.B2(n_30),
.Y(n_236)
);

INVx1_ASAP7_75t_L g237 ( 
.A(n_231),
.Y(n_237)
);

AOI22xp5_ASAP7_75t_L g238 ( 
.A1(n_233),
.A2(n_117),
.B1(n_114),
.B2(n_102),
.Y(n_238)
);

INVxp67_ASAP7_75t_SL g239 ( 
.A(n_238),
.Y(n_239)
);

AND2x4_ASAP7_75t_L g240 ( 
.A(n_237),
.B(n_235),
.Y(n_240)
);

INVx1_ASAP7_75t_L g241 ( 
.A(n_240),
.Y(n_241)
);

INVxp67_ASAP7_75t_L g242 ( 
.A(n_239),
.Y(n_242)
);

INVx1_ASAP7_75t_L g243 ( 
.A(n_241),
.Y(n_243)
);

BUFx3_ASAP7_75t_L g244 ( 
.A(n_243),
.Y(n_244)
);

AOI22xp5_ASAP7_75t_SL g245 ( 
.A1(n_244),
.A2(n_242),
.B1(n_232),
.B2(n_236),
.Y(n_245)
);

INVx1_ASAP7_75t_L g246 ( 
.A(n_245),
.Y(n_246)
);

AOI221xp5_ASAP7_75t_L g247 ( 
.A1(n_246),
.A2(n_234),
.B1(n_88),
.B2(n_72),
.C(n_80),
.Y(n_247)
);


endmodule