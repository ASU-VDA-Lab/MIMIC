module fake_netlist_706_16_n_46 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_46);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_46;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

INVx1_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_4),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_8),
.C(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_13),
.A2(n_2),
.B1(n_10),
.B2(n_12),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_17),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_21),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

OR2x6_ASAP7_75t_L g32 ( 
.A(n_23),
.B(n_19),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_27),
.B1(n_26),
.B2(n_24),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_30),
.Y(n_34)
);

AOI21xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_32),
.B(n_29),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_31),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_36),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_19),
.Y(n_38)
);

NAND2xp33_ASAP7_75t_SL g39 ( 
.A(n_38),
.B(n_22),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_37),
.B1(n_28),
.B2(n_25),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_0),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_3),
.Y(n_45)
);

AOI322xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_44),
.A3(n_43),
.B1(n_11),
.B2(n_18),
.C1(n_5),
.C2(n_9),
.Y(n_46)
);


endmodule