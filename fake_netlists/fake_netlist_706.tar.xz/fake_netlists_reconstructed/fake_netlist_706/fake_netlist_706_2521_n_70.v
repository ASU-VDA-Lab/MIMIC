module fake_netlist_706_2521_n_70 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_70);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_70;

wire n_54;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_64;
wire n_40;
wire n_42;
wire n_66;
wire n_47;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_46;
wire n_41;
wire n_31;
wire n_69;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_68;
wire n_33;
wire n_65;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_67;
wire n_39;
wire n_55;

INVx2_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_0),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_5),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_16),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_10),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_23),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_1),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_2),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_7),
.Y(n_38)
);

OA21x2_ASAP7_75t_L g39 ( 
.A1(n_21),
.A2(n_14),
.B(n_15),
.Y(n_39)
);

XNOR2x2_ASAP7_75t_R g40 ( 
.A(n_8),
.B(n_27),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_33),
.B(n_24),
.Y(n_41)
);

INVx2_ASAP7_75t_SL g42 ( 
.A(n_34),
.Y(n_42)
);

HB1xp67_ASAP7_75t_L g43 ( 
.A(n_28),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_30),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_35),
.A2(n_25),
.B1(n_24),
.B2(n_3),
.Y(n_45)
);

INVx1_ASAP7_75t_SL g46 ( 
.A(n_41),
.Y(n_46)
);

OAI21x1_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_39),
.B(n_32),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_42),
.Y(n_48)
);

AND2x4_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_43),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_43),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_45),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_47),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_40),
.Y(n_54)
);

OA21x2_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_37),
.B(n_36),
.Y(n_55)
);

INVx1_ASAP7_75t_SL g56 ( 
.A(n_52),
.Y(n_56)
);

INVx1_ASAP7_75t_SL g57 ( 
.A(n_56),
.Y(n_57)
);

INVx2_ASAP7_75t_SL g58 ( 
.A(n_54),
.Y(n_58)
);

OAI22x1_ASAP7_75t_L g59 ( 
.A1(n_55),
.A2(n_31),
.B1(n_38),
.B2(n_25),
.Y(n_59)
);

O2A1O1Ixp33_ASAP7_75t_L g60 ( 
.A1(n_55),
.A2(n_29),
.B(n_9),
.C(n_4),
.Y(n_60)
);

NOR2xp67_ASAP7_75t_SL g61 ( 
.A(n_58),
.B(n_29),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_57),
.Y(n_62)
);

NOR2xp33_ASAP7_75t_L g63 ( 
.A(n_60),
.B(n_11),
.Y(n_63)
);

XNOR2xp5_ASAP7_75t_L g64 ( 
.A(n_59),
.B(n_12),
.Y(n_64)
);

XNOR2xp5_ASAP7_75t_L g65 ( 
.A(n_64),
.B(n_18),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_62),
.Y(n_66)
);

XOR2xp5_ASAP7_75t_L g67 ( 
.A(n_61),
.B(n_19),
.Y(n_67)
);

AOI22xp5_ASAP7_75t_L g68 ( 
.A1(n_65),
.A2(n_63),
.B1(n_22),
.B2(n_20),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_66),
.Y(n_69)
);

AOI22xp5_ASAP7_75t_SL g70 ( 
.A1(n_69),
.A2(n_26),
.B1(n_67),
.B2(n_68),
.Y(n_70)
);


endmodule