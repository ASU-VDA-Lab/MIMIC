module fake_netlist_706_397_n_43 (n_9, n_4, n_2, n_7, n_14, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_43);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_43;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_5),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_5),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_2),
.A2(n_4),
.B(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_10),
.B(n_12),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_0),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_1),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_16),
.B(n_3),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_21),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_16),
.B(n_17),
.Y(n_27)
);

OAI21x1_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_17),
.B(n_15),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_22),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_28),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_27),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_30),
.Y(n_33)
);

OAI21xp33_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_28),
.B(n_7),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

NOR3xp33_ASAP7_75t_SL g38 ( 
.A(n_36),
.B(n_10),
.C(n_9),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_37),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_40),
.A2(n_11),
.B1(n_38),
.B2(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);


endmodule