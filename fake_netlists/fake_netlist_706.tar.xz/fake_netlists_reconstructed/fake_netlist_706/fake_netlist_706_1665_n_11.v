module fake_netlist_706_1665_n_11 (n_3, n_0, n_2, n_1, n_11);

input n_3;
input n_0;
input n_2;
input n_1;

output n_11;

wire n_9;
wire n_4;
wire n_7;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

BUFx10_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

BUFx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

INVxp67_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AOI221x1_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_2),
.B(n_1),
.Y(n_11)
);


endmodule