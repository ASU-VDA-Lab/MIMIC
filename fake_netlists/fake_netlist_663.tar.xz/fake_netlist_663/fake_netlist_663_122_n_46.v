module fake_netlist_663_122_n_46 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_46);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_46;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

INVx1_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_18),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_R g27 ( 
.A(n_11),
.B(n_19),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_13),
.B(n_20),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_0),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_10),
.B(n_16),
.Y(n_30)
);

AND2x6_ASAP7_75t_SL g31 ( 
.A(n_26),
.B(n_19),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

BUFx3_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_23),
.B1(n_25),
.B2(n_29),
.C(n_24),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_29),
.B1(n_28),
.B2(n_30),
.Y(n_35)
);

OAI332xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_31),
.A3(n_28),
.B1(n_27),
.B2(n_32),
.B3(n_1),
.C1(n_3),
.C2(n_2),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_6),
.Y(n_39)
);

AND3x2_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_38),
.C(n_7),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_8),
.Y(n_41)
);

AOI22x1_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_14),
.B1(n_12),
.B2(n_9),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_17),
.C(n_15),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_42),
.Y(n_44)
);

CKINVDCx14_ASAP7_75t_R g45 ( 
.A(n_44),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_45),
.Y(n_46)
);


endmodule