module fake_netlist_663_32_n_16 (n_4, n_1, n_2, n_0, n_3, n_16);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_16;

wire n_9;
wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_12;
wire n_10;
wire n_11;
wire n_8;
wire n_15;
wire n_6;

NAND3xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.C(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OAI221xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_7),
.B1(n_1),
.B2(n_0),
.C(n_2),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_8),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

OAI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B1(n_4),
.B2(n_2),
.C(n_3),
.Y(n_13)
);

NOR4xp25_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_1),
.C(n_0),
.D(n_2),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_3),
.B1(n_4),
.B2(n_14),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);


endmodule