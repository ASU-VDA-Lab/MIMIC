module fake_netlist_663_837_n_15 (n_3, n_1, n_2, n_0, n_15);

input n_3;
input n_1;
input n_2;
input n_0;

output n_15;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;

INVx4_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_1),
.Y(n_5)
);

NAND2x1p5_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

OAI221xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.C(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_4),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_7),
.B1(n_2),
.B2(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NOR2xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_9),
.B(n_3),
.C(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_9),
.B1(n_13),
.B2(n_3),
.Y(n_15)
);


endmodule