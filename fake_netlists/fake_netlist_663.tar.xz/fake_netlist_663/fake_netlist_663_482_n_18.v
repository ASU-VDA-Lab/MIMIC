module fake_netlist_663_482_n_18 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_18);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_18;

wire n_17;
wire n_14;
wire n_10;
wire n_11;
wire n_15;
wire n_9;
wire n_13;
wire n_16;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_8),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

OAI22x1_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_6),
.B1(n_2),
.B2(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_SL g13 ( 
.A(n_12),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B(n_3),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_6),
.C(n_4),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

XNOR2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_5),
.Y(n_18)
);


endmodule