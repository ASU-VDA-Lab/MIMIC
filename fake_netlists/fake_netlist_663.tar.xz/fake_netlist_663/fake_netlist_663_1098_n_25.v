module fake_netlist_663_1098_n_25 (n_4, n_1, n_2, n_0, n_3, n_25);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_25;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_24;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

OR2x2_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_1),
.B(n_4),
.Y(n_8)
);

NAND2xp33_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_1),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

CKINVDCx6p67_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_SL g12 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.C(n_2),
.Y(n_12)
);

INVx2_ASAP7_75t_SL g13 ( 
.A(n_7),
.Y(n_13)
);

AO21x2_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_9),
.B(n_5),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_0),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_10),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_10),
.B1(n_9),
.B2(n_13),
.C(n_12),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_15),
.B(n_16),
.C(n_13),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_13),
.B1(n_14),
.B2(n_19),
.C(n_11),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_14),
.B1(n_11),
.B2(n_0),
.C(n_1),
.Y(n_22)
);

AOI21xp33_ASAP7_75t_SL g23 ( 
.A1(n_20),
.A2(n_3),
.B(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

AOI222xp33_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_2),
.B1(n_11),
.B2(n_22),
.C1(n_23),
.C2(n_10),
.Y(n_25)
);


endmodule