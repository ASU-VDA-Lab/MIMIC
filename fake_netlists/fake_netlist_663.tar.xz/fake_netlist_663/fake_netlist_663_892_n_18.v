module fake_netlist_663_892_n_18 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_18);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_18;

wire n_17;
wire n_14;
wire n_10;
wire n_11;
wire n_15;
wire n_9;
wire n_13;
wire n_16;
wire n_12;

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

NAND2x1p5_ASAP7_75t_L g10 ( 
.A(n_2),
.B(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_7),
.B(n_5),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_6),
.B(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_SL g13 ( 
.A(n_9),
.Y(n_13)
);

BUFx3_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI332xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.A3(n_6),
.B1(n_7),
.B2(n_4),
.B3(n_11),
.C1(n_12),
.C2(n_10),
.Y(n_15)
);

AOI211x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B(n_4),
.C(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);


endmodule