module fake_netlist_663_1163_n_35 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_35);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_35;

wire n_18;
wire n_19;
wire n_34;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_11;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_9;
wire n_32;
wire n_13;

NOR2xp33_ASAP7_75t_R g9 ( 
.A(n_5),
.B(n_6),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_4),
.A2(n_8),
.B(n_0),
.Y(n_10)
);

NOR2xp67_ASAP7_75t_L g11 ( 
.A(n_0),
.B(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_7),
.B(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_7),
.C(n_3),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_14),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_18),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_18),
.C(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_11),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_16),
.B1(n_10),
.B2(n_9),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_29),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_30),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_31),
.B1(n_33),
.B2(n_25),
.Y(n_35)
);


endmodule