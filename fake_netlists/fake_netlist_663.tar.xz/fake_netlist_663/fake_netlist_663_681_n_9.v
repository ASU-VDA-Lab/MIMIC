module fake_netlist_663_681_n_9 (n_1, n_2, n_0, n_9);

input n_1;
input n_2;
input n_0;

output n_9;

wire n_4;
wire n_7;
wire n_5;
wire n_8;
wire n_6;
wire n_3;

NOR2xp33_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

OR2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

NAND3xp33_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_3),
.C(n_1),
.Y(n_7)
);

NOR2x1_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_2),
.Y(n_8)
);

AOI211xp5_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_0),
.B(n_2),
.C(n_3),
.Y(n_9)
);


endmodule