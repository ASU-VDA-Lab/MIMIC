module fake_netlist_663_956_n_59 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_59);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_59;

wire n_36;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_2),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_18),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_22),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_12),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_R g31 ( 
.A(n_17),
.B(n_6),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_8),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_17),
.B(n_0),
.Y(n_34)
);

INVxp67_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

NOR3xp33_ASAP7_75t_SL g36 ( 
.A(n_26),
.B(n_18),
.C(n_16),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_24),
.Y(n_37)
);

NAND2xp33_ASAP7_75t_SL g38 ( 
.A(n_31),
.B(n_19),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_29),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_27),
.Y(n_40)
);

INVx6_ASAP7_75t_L g41 ( 
.A(n_35),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_27),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_39),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

NAND2x1_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_33),
.Y(n_45)
);

AOI22x1_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_32),
.B1(n_25),
.B2(n_27),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_41),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_41),
.Y(n_50)
);

AOI222xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_38),
.B1(n_34),
.B2(n_23),
.C1(n_28),
.C2(n_36),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_R g53 ( 
.A(n_48),
.B(n_1),
.Y(n_53)
);

OR3x2_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_19),
.C(n_28),
.Y(n_54)
);

OR2x2_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_4),
.Y(n_55)
);

OAI222xp33_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_7),
.B1(n_5),
.B2(n_9),
.C1(n_13),
.C2(n_10),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_55),
.Y(n_57)
);

INVx1_ASAP7_75t_SL g58 ( 
.A(n_54),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_14),
.B1(n_56),
.B2(n_57),
.Y(n_59)
);


endmodule