module fake_netlist_761_2425_n_25 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_25);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_25;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_24;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;

BUFx2_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_3),
.B(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_12),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_13),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

NOR5xp2_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_16),
.C(n_1),
.D(n_3),
.E(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

AOI221x1_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_18),
.B1(n_14),
.B2(n_15),
.C(n_1),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

AND3x1_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_18),
.C(n_2),
.Y(n_24)
);

AOI322xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_2),
.A3(n_0),
.B1(n_6),
.B2(n_4),
.C1(n_9),
.C2(n_7),
.Y(n_25)
);


endmodule