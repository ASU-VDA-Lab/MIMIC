module fake_netlist_761_1556_n_12 (n_0, n_2, n_1, n_3, n_12);

input n_0;
input n_2;
input n_1;
input n_3;

output n_12;

wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_2),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

O2A1O1Ixp5_ASAP7_75t_SL g7 ( 
.A1(n_4),
.A2(n_0),
.B(n_1),
.C(n_3),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

A2O1A1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.B(n_7),
.C(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_3),
.B2(n_0),
.Y(n_12)
);


endmodule