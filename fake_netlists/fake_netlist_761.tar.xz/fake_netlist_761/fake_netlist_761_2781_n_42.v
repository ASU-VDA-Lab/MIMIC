module fake_netlist_761_2781_n_42 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_42);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_42;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_R g25 ( 
.A(n_13),
.B(n_5),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_10),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

AND2x6_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_25),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_28),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_27),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_27),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_32),
.B(n_22),
.Y(n_35)
);

NAND4xp75_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_21),
.C(n_20),
.D(n_18),
.Y(n_36)
);

NOR3xp33_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_26),
.C(n_21),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_14),
.B1(n_11),
.B2(n_12),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_R g39 ( 
.A(n_37),
.B(n_2),
.Y(n_39)
);

OAI22x1_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_17),
.B1(n_9),
.B2(n_15),
.Y(n_40)
);

INVx2_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

AOI222xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_1),
.B1(n_6),
.B2(n_7),
.C1(n_8),
.C2(n_41),
.Y(n_42)
);


endmodule