module fake_netlist_761_145_n_49 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_49);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_49;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

OA21x2_ASAP7_75t_L g25 ( 
.A1(n_11),
.A2(n_10),
.B(n_3),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_19),
.B(n_7),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_1),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_12),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_20),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_22),
.B(n_19),
.Y(n_32)
);

BUFx4f_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_28),
.B1(n_31),
.B2(n_26),
.C(n_29),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OAI222xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_23),
.B1(n_30),
.B2(n_27),
.C1(n_26),
.C2(n_25),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_33),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_21),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_SL g41 ( 
.A1(n_40),
.A2(n_25),
.B(n_33),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_11),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_21),
.B(n_16),
.C(n_15),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

XNOR2xp5_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_4),
.Y(n_45)
);

NAND3xp33_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_18),
.C(n_17),
.Y(n_46)
);

INVx4_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_43),
.B1(n_9),
.B2(n_13),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_0),
.B1(n_6),
.B2(n_48),
.Y(n_49)
);


endmodule