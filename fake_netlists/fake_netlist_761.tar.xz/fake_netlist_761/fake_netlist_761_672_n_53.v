module fake_netlist_761_672_n_53 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_53);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_53;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_52;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_2),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_7),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_1),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

CKINVDCx16_ASAP7_75t_R g26 ( 
.A(n_8),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_25),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_20),
.A2(n_13),
.B1(n_14),
.B2(n_15),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

AOI221xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_23),
.B1(n_26),
.B2(n_22),
.C(n_19),
.Y(n_31)
);

AOI211xp5_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_23),
.B(n_19),
.C(n_22),
.Y(n_32)
);

OAI21xp5_ASAP7_75t_L g33 ( 
.A1(n_27),
.A2(n_24),
.B(n_21),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_26),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_29),
.B1(n_26),
.B2(n_21),
.Y(n_35)
);

OAI33xp33_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_30),
.A3(n_14),
.B1(n_12),
.B2(n_13),
.B3(n_11),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_3),
.B(n_11),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_16),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_36),
.B(n_16),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_38),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_10),
.B1(n_9),
.B2(n_4),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_18),
.Y(n_46)
);

OAI322xp33_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_42),
.A3(n_12),
.B1(n_18),
.B2(n_17),
.C1(n_15),
.C2(n_8),
.Y(n_47)
);

OAI221xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_5),
.B1(n_10),
.B2(n_7),
.C(n_0),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

NAND4xp25_ASAP7_75t_SL g50 ( 
.A(n_43),
.B(n_0),
.C(n_5),
.D(n_17),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_46),
.B1(n_49),
.B2(n_48),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

AOI22xp33_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_46),
.B1(n_51),
.B2(n_34),
.Y(n_53)
);


endmodule