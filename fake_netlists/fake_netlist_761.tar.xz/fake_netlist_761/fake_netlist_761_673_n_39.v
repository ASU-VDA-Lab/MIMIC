module fake_netlist_761_673_n_39 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_39);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_39;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_0),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_16),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

OAI21x1_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_18),
.B(n_14),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_18),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_19),
.B1(n_15),
.B2(n_17),
.C(n_21),
.Y(n_29)
);

OAI21xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_24),
.B(n_26),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_18),
.B1(n_14),
.B2(n_25),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_25),
.B1(n_17),
.B2(n_20),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_25),
.Y(n_33)
);

NOR4xp75_ASAP7_75t_SL g34 ( 
.A(n_32),
.B(n_1),
.C(n_0),
.D(n_3),
.Y(n_34)
);

OAI221xp5_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_20),
.B1(n_2),
.B2(n_1),
.C(n_3),
.Y(n_35)
);

OA21x2_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_6),
.B(n_11),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_2),
.B(n_12),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_34),
.B1(n_36),
.B2(n_10),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_36),
.B1(n_7),
.B2(n_8),
.Y(n_39)
);


endmodule