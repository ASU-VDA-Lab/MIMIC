module fake_netlist_761_1067_n_12 (n_0, n_2, n_1, n_3, n_12);

input n_0;
input n_2;
input n_1;
input n_3;

output n_12;

wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

AND2x6_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

CKINVDCx6p67_ASAP7_75t_R g6 ( 
.A(n_4),
.Y(n_6)
);

OA21x2_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_7),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OR3x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_0),
.C(n_4),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_4),
.B1(n_6),
.B2(n_7),
.Y(n_12)
);


endmodule