module fake_netlist_761_1277_n_32 (n_12, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_32);

input n_12;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_32;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_16;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_15;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_9),
.B(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_13),
.Y(n_18)
);

NOR2xp67_ASAP7_75t_L g19 ( 
.A(n_1),
.B(n_11),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_3),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

O2A1O1Ixp33_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_20),
.B(n_23),
.C(n_18),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_22),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_19),
.Y(n_26)
);

OAI22xp33_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_25),
.B1(n_15),
.B2(n_16),
.Y(n_27)
);

XNOR2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_26),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

AO22x1_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_21),
.B2(n_0),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_0),
.B1(n_10),
.B2(n_8),
.C1(n_6),
.C2(n_5),
.Y(n_32)
);


endmodule