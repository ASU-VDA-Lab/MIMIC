module fake_netlist_761_2224_n_12 (n_1, n_2, n_3, n_4, n_0, n_12);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_12;

wire n_9;
wire n_11;
wire n_10;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

A2O1A1Ixp33_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_2),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_3),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_1),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_3),
.Y(n_9)
);

OAI221xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_6),
.B1(n_5),
.B2(n_9),
.C(n_7),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_8),
.C(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule