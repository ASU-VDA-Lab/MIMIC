module fake_netlist_761_1221_n_15 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_11;
wire n_9;
wire n_10;
wire n_7;
wire n_13;
wire n_8;

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_1),
.Y(n_7)
);

NAND2xp33_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_1),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_0),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_8),
.Y(n_12)
);

NOR3xp33_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.C(n_11),
.Y(n_13)
);

NOR4xp25_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_2),
.C(n_4),
.D(n_6),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_2),
.Y(n_15)
);


endmodule