module fake_netlist_761_515_n_48 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_48);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_48;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_2),
.B(n_6),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_1),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_12),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_14),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_19),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_L g30 ( 
.A(n_8),
.B(n_11),
.Y(n_30)
);

BUFx8_ASAP7_75t_SL g31 ( 
.A(n_23),
.Y(n_31)
);

A2O1A1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_21),
.A2(n_25),
.B(n_24),
.C(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_22),
.B(n_19),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_29),
.B1(n_26),
.B2(n_27),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_R g37 ( 
.A(n_36),
.B(n_34),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_SL g38 ( 
.A1(n_35),
.A2(n_28),
.B1(n_31),
.B2(n_33),
.Y(n_38)
);

NAND4xp25_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_38),
.C(n_10),
.D(n_20),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_18),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_40),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

BUFx6f_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

NOR2x1_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_13),
.Y(n_45)
);

OAI22xp33_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_10),
.B1(n_20),
.B2(n_15),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_43),
.A3(n_45),
.B1(n_9),
.B2(n_4),
.C1(n_3),
.C2(n_0),
.Y(n_48)
);


endmodule