module fake_netlist_761_696_n_11 (n_0, n_2, n_1, n_3, n_11);

input n_0;
input n_2;
input n_1;
input n_3;

output n_11;

wire n_9;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_1),
.Y(n_4)
);

INVx2_ASAP7_75t_SL g5 ( 
.A(n_2),
.Y(n_5)
);

INVxp33_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);

NOR3xp33_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_0),
.C(n_3),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);


endmodule