module fake_netlist_761_301_n_44 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_44);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_44;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_39;
wire n_11;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_12;
wire n_19;
wire n_15;
wire n_41;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx6_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_9),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

AND2x6_ASAP7_75t_L g15 ( 
.A(n_6),
.B(n_5),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_4),
.B(n_8),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_7),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

NOR2xp67_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_7),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_6),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_13),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_18),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_18),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

AOI211xp5_ASAP7_75t_SL g28 ( 
.A1(n_24),
.A2(n_19),
.B(n_20),
.C(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

A2O1A1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_28),
.B(n_26),
.C(n_23),
.Y(n_32)
);

O2A1O1Ixp33_ASAP7_75t_SL g33 ( 
.A1(n_29),
.A2(n_28),
.B(n_17),
.C(n_21),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_13),
.B(n_21),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_31),
.B1(n_33),
.B2(n_34),
.Y(n_35)
);

AND3x4_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_12),
.C(n_15),
.Y(n_36)
);

OAI311xp33_ASAP7_75t_L g37 ( 
.A1(n_32),
.A2(n_12),
.A3(n_15),
.B1(n_1),
.C1(n_8),
.Y(n_37)
);

OAI221xp5_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_12),
.B1(n_15),
.B2(n_1),
.C(n_5),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_15),
.B1(n_2),
.B2(n_0),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_15),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_40),
.A2(n_38),
.B1(n_3),
.B2(n_2),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_41),
.B1(n_43),
.B2(n_3),
.Y(n_44)
);


endmodule