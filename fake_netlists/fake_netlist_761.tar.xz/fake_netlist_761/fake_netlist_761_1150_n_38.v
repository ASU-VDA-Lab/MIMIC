module fake_netlist_761_1150_n_38 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_38);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_38;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_13;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

INVx2_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_3),
.B(n_0),
.Y(n_14)
);

BUFx6f_ASAP7_75t_SL g15 ( 
.A(n_4),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_SL g21 ( 
.A(n_14),
.B(n_18),
.C(n_13),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_15),
.B1(n_18),
.B2(n_2),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

OR2x6_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_20),
.Y(n_27)
);

AOI32xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_22),
.A3(n_19),
.B1(n_15),
.B2(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_25),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_22),
.B2(n_19),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_4),
.C(n_1),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_31),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_R g37 ( 
.A1(n_33),
.A2(n_3),
.B1(n_9),
.B2(n_8),
.Y(n_37)
);

AOI222xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_35),
.B1(n_37),
.B2(n_10),
.C1(n_5),
.C2(n_6),
.Y(n_38)
);


endmodule