module fake_netlist_761_2769_n_20 (n_0, n_2, n_1, n_20);

input n_0;
input n_2;
input n_1;

output n_20;

wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_3;
wire n_9;
wire n_4;
wire n_7;
wire n_17;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

INVx3_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

AND2x4_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_1),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_4),
.B1(n_5),
.B2(n_3),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_1),
.B(n_2),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_6),
.Y(n_10)
);

INVx5_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_5),
.B(n_3),
.C(n_4),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_10),
.Y(n_15)
);

AOI211x1_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_13),
.B(n_7),
.C(n_6),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_3),
.B1(n_6),
.B2(n_9),
.C(n_1),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_16),
.C(n_8),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_11),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_19),
.B(n_11),
.Y(n_20)
);


endmodule