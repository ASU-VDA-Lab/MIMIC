module fake_netlist_761_2020_n_12 (n_0, n_2, n_1, n_3, n_12);

input n_0;
input n_2;
input n_1;
input n_3;

output n_12;

wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

BUFx3_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx2_ASAP7_75t_SL g5 ( 
.A(n_0),
.Y(n_5)
);

AO31x2_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.A3(n_2),
.B(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

OAI211xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B(n_4),
.C(n_0),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_1),
.B1(n_2),
.B2(n_4),
.C(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_4),
.Y(n_12)
);


endmodule