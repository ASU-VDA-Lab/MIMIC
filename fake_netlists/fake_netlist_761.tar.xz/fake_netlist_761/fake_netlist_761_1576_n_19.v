module fake_netlist_761_1576_n_19 (n_1, n_2, n_3, n_4, n_5, n_0, n_19);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_19;

wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_12;
wire n_15;
wire n_8;

INVx3_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_0),
.B(n_4),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_0),
.B(n_1),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B1(n_6),
.B2(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_SL g12 ( 
.A(n_9),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI222xp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_7),
.B1(n_8),
.B2(n_6),
.C1(n_9),
.C2(n_5),
.Y(n_14)
);

AOI22x1_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_7),
.B1(n_6),
.B2(n_8),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_7),
.C(n_6),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI322xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_6),
.A3(n_14),
.B1(n_4),
.B2(n_1),
.C1(n_3),
.C2(n_2),
.Y(n_18)
);

NAND2x1_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_18),
.Y(n_19)
);


endmodule