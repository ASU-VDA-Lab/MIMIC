module fake_netlist_652_1740_n_24 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_24);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_24;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;

AND2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_3),
.Y(n_10)
);

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_SL g12 ( 
.A(n_9),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_0),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_SL g14 ( 
.A(n_12),
.B(n_8),
.C(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

O2A1O1Ixp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_14),
.B(n_11),
.C(n_10),
.Y(n_18)
);

NOR2x1_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_11),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_11),
.B1(n_1),
.B2(n_0),
.Y(n_20)
);

NAND4xp25_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_5),
.C(n_4),
.D(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

XNOR2xp5_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_6),
.Y(n_23)
);

AOI322xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_7),
.A3(n_11),
.B1(n_19),
.B2(n_22),
.C1(n_14),
.C2(n_12),
.Y(n_24)
);


endmodule