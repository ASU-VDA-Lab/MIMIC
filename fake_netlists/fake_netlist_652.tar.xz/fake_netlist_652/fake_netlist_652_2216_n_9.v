module fake_netlist_652_2216_n_9 (n_3, n_1, n_2, n_0, n_9);

input n_3;
input n_1;
input n_2;
input n_0;

output n_9;

wire n_4;
wire n_7;
wire n_5;
wire n_8;
wire n_6;

AO21x1_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_3),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_1),
.Y(n_6)
);

BUFx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);


endmodule