module fake_netlist_652_743_n_39 (n_9, n_4, n_7, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_39);

input n_9;
input n_4;
input n_7;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_39;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_12),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_5),
.B(n_8),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_4),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_9),
.A2(n_6),
.B(n_11),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_3),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_SL g23 ( 
.A(n_15),
.B(n_3),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_4),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_22),
.B(n_18),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_20),
.Y(n_27)
);

OAI22xp33_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_17),
.B1(n_16),
.B2(n_14),
.Y(n_28)
);

OAI31xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_23),
.A3(n_27),
.B(n_26),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_29),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_16),
.B(n_18),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_32),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_0),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_7),
.B1(n_18),
.B2(n_37),
.Y(n_39)
);


endmodule