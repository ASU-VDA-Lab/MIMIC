module fake_netlist_652_2027_n_8 (n_4, n_1, n_2, n_0, n_5, n_3, n_8);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_8;

wire n_7;
wire n_6;

OA21x2_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_0),
.B(n_2),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_1),
.Y(n_7)
);

NOR3x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_3),
.C(n_7),
.Y(n_8)
);


endmodule