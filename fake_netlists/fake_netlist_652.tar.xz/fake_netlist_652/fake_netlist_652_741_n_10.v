module fake_netlist_652_741_n_10 (n_1, n_2, n_0, n_10);

input n_1;
input n_2;
input n_0;

output n_10;

wire n_9;
wire n_4;
wire n_7;
wire n_5;
wire n_8;
wire n_6;
wire n_3;

INVx1_ASAP7_75t_SL g3 ( 
.A(n_0),
.Y(n_3)
);

NOR2xp33_ASAP7_75t_SL g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

AOI211xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_4),
.B(n_2),
.C(n_1),
.Y(n_8)
);

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule