module fake_netlist_652_2457_n_15 (n_3, n_1, n_2, n_0, n_15);

input n_3;
input n_1;
input n_2;
input n_0;

output n_15;

wire n_4;
wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_10;
wire n_6;
wire n_12;
wire n_11;
wire n_8;
wire n_9;

OR2x2_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_3),
.Y(n_4)
);

INVx4_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AOI33xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_4),
.A3(n_3),
.B1(n_0),
.B2(n_2),
.B3(n_1),
.Y(n_8)
);

OAI221xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.C(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_6),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_9),
.B1(n_6),
.B2(n_0),
.C(n_2),
.Y(n_12)
);

OAI221xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_6),
.B1(n_3),
.B2(n_0),
.C(n_2),
.Y(n_13)
);

AND4x1_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_11),
.C(n_3),
.D(n_0),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_1),
.B1(n_13),
.B2(n_12),
.C1(n_9),
.C2(n_10),
.Y(n_15)
);


endmodule