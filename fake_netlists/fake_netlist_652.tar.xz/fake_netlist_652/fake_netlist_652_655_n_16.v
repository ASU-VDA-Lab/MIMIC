module fake_netlist_652_655_n_16 (n_3, n_1, n_2, n_0, n_16);

input n_3;
input n_1;
input n_2;
input n_0;

output n_16;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_15;
wire n_6;

AND2x4_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

OAI221xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.C(n_3),
.Y(n_6)
);

INVxp67_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_5),
.Y(n_9)
);

NAND3x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_4),
.C(n_5),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_5),
.B(n_4),
.C(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_SL g13 ( 
.A1(n_11),
.A2(n_5),
.B(n_2),
.C(n_1),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_10),
.B(n_4),
.C(n_5),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_14),
.A2(n_4),
.B1(n_15),
.B2(n_6),
.Y(n_16)
);


endmodule