module fake_netlist_652_1874_n_28 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_28);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_28;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_21;
wire n_27;
wire n_26;

INVx1_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

AOI21x1_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_14),
.B(n_8),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_7),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_7),
.Y(n_21)
);

AO31x2_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_15),
.A3(n_19),
.B(n_16),
.Y(n_22)
);

AND2x4_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_21),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_1),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_6),
.B1(n_5),
.B2(n_3),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_13),
.B1(n_11),
.B2(n_9),
.Y(n_28)
);


endmodule