module fake_netlist_652_930_n_20 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_20);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_20;

wire n_18;
wire n_19;
wire n_11;
wire n_15;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_1),
.C(n_10),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_6),
.Y(n_13)
);

INVx4_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

AO31x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_7),
.A3(n_3),
.B(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_11),
.B(n_13),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B(n_12),
.Y(n_19)
);

AOI222xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_14),
.B2(n_15),
.C1(n_9),
.C2(n_5),
.Y(n_20)
);


endmodule