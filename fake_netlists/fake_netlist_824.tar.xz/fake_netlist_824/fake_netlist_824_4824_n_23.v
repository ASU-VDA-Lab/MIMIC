module fake_netlist_824_4824_n_23 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_23);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

NAND3xp33_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_1),
.C(n_2),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_5),
.B(n_4),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_1),
.B(n_7),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

AOI31xp67_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_4),
.A3(n_3),
.B(n_0),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_15),
.Y(n_19)
);

AOI222xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_12),
.B1(n_13),
.B2(n_14),
.C1(n_10),
.C2(n_16),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_14),
.C(n_0),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_6),
.Y(n_22)
);

NOR2xp67_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_6),
.Y(n_23)
);


endmodule