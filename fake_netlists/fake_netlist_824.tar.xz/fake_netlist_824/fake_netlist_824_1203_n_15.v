module fake_netlist_824_1203_n_15 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_15);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_15;

wire n_10;
wire n_13;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_1),
.A2(n_7),
.B1(n_5),
.B2(n_3),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

BUFx8_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_SL g13 ( 
.A(n_12),
.B(n_8),
.C(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OA21x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_4),
.B(n_2),
.Y(n_15)
);


endmodule