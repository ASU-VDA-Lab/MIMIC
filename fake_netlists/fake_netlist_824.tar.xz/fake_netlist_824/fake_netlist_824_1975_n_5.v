module fake_netlist_824_1975_n_5 (n_0, n_5);

input n_0;

output n_5;

wire n_4;
wire n_2;
wire n_3;
wire n_1;

INVx5_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

INVx2_ASAP7_75t_SL g2 ( 
.A(n_1),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_3),
.Y(n_4)
);

INVx4_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);


endmodule