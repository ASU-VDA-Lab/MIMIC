module fake_netlist_824_4591_n_23 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_23);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

AO22x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_5),
.B1(n_2),
.B2(n_1),
.Y(n_11)
);

O2A1O1Ixp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_6),
.B(n_1),
.C(n_0),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_8),
.B1(n_10),
.B2(n_7),
.Y(n_14)
);

NAND2x1_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_10),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_9),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_10),
.B(n_7),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_R g23 ( 
.A1(n_22),
.A2(n_3),
.B1(n_6),
.B2(n_19),
.C(n_21),
.Y(n_23)
);


endmodule