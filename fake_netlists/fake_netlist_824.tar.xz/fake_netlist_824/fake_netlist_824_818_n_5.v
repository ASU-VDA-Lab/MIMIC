module fake_netlist_824_818_n_5 (n_0, n_5);

input n_0;

output n_5;

wire n_4;
wire n_2;
wire n_3;
wire n_1;

INVx1_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

AND2x2_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

OAI21xp5_ASAP7_75t_SL g4 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_4)
);

OAI22xp33_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B1(n_3),
.B2(n_1),
.Y(n_5)
);


endmodule