module fake_netlist_824_409_n_10 (n_2, n_0, n_1, n_10);

input n_2;
input n_0;
input n_1;

output n_10;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_8;

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

NAND3xp33_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.C(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVxp67_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

NAND4xp25_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.C(n_2),
.D(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.Y(n_10)
);


endmodule