module fake_netlist_824_891_n_20 (n_4, n_2, n_5, n_3, n_0, n_1, n_20);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_1),
.Y(n_7)
);

BUFx10_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

NAND2xp33_ASAP7_75t_SL g9 ( 
.A(n_5),
.B(n_1),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

O2A1O1Ixp33_ASAP7_75t_SL g11 ( 
.A1(n_8),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_11)
);

OAI21xp33_ASAP7_75t_SL g12 ( 
.A1(n_8),
.A2(n_4),
.B(n_0),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_9),
.B1(n_11),
.B2(n_0),
.Y(n_16)
);

NAND4xp75_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.C(n_15),
.D(n_11),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_3),
.B1(n_2),
.B2(n_5),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_5),
.B1(n_3),
.B2(n_2),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_15),
.B(n_18),
.Y(n_20)
);


endmodule