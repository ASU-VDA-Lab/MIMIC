module fake_netlist_824_1642_n_9 (n_2, n_0, n_1, n_9);

input n_2;
input n_0;
input n_1;

output n_9;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_1),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_1),
.Y(n_6)
);

AOI21xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_6),
.B(n_4),
.Y(n_7)
);

NAND5xp2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_1),
.C(n_2),
.D(n_6),
.E(n_4),
.Y(n_8)
);

XOR2xp5_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_2),
.Y(n_9)
);


endmodule