module fake_netlist_824_3558_n_16 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_16);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_15;
wire n_13;
wire n_14;
wire n_12;
wire n_10;
wire n_11;
wire n_9;
wire n_8;

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_2),
.A2(n_5),
.B1(n_0),
.B2(n_1),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

OAI21x1_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_6),
.B(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

OAI321xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.A3(n_8),
.B1(n_7),
.B2(n_6),
.C(n_3),
.Y(n_14)
);

OA21x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_7),
.B(n_12),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);


endmodule