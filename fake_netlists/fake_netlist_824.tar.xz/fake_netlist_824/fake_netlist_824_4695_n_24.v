module fake_netlist_824_4695_n_24 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_24);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_24;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;

AO22x2_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.B1(n_1),
.B2(n_9),
.Y(n_12)
);

INVx4_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_2),
.B(n_5),
.Y(n_14)
);

INVx5_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_0),
.Y(n_17)
);

AO22x1_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_5),
.B1(n_4),
.B2(n_0),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_SL g19 ( 
.A(n_17),
.B(n_14),
.C(n_16),
.Y(n_19)
);

AOI222xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_18),
.B1(n_12),
.B2(n_14),
.C1(n_15),
.C2(n_13),
.Y(n_20)
);

AOI221x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_12),
.B1(n_13),
.B2(n_3),
.C(n_8),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_12),
.B(n_15),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_15),
.B1(n_6),
.B2(n_4),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_6),
.Y(n_24)
);


endmodule