module fake_netlist_824_3954_n_27 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_27);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_0),
.B(n_3),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_1),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_4),
.B(n_1),
.Y(n_15)
);

BUFx2_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_12),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_10),
.B1(n_8),
.B2(n_12),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_10),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_7),
.Y(n_21)
);

O2A1O1Ixp33_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_18),
.B(n_7),
.C(n_19),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_20),
.C(n_16),
.D(n_18),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_20),
.C(n_6),
.D(n_0),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_3),
.B(n_2),
.Y(n_25)
);

OAI221xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_5),
.B1(n_3),
.B2(n_2),
.C(n_6),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_5),
.B1(n_6),
.B2(n_25),
.Y(n_27)
);


endmodule