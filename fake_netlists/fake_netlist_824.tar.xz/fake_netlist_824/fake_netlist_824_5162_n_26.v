module fake_netlist_824_5162_n_26 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_26);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

OA22x2_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_6),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B1(n_10),
.B2(n_14),
.Y(n_17)
);

NOR4xp25_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_15),
.C(n_11),
.D(n_10),
.Y(n_18)
);

AO22x1_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B1(n_15),
.B2(n_6),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_12),
.B1(n_18),
.B2(n_7),
.C(n_0),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_1),
.Y(n_21)
);

NAND4xp25_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_3),
.C(n_2),
.D(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

OAI22x1_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_5),
.B1(n_8),
.B2(n_24),
.Y(n_26)
);


endmodule