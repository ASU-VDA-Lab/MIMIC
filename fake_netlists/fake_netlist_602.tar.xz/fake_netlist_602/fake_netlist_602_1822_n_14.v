module fake_netlist_602_1822_n_14 (n_1, n_2, n_0, n_14);

input n_1;
input n_2;
input n_0;

output n_14;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;
wire n_3;

NOR2xp67_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_2),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_0),
.Y(n_5)
);

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_1),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

NOR4xp25_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_6),
.C(n_8),
.D(n_1),
.Y(n_11)
);

O2A1O1Ixp5_ASAP7_75t_SL g12 ( 
.A1(n_10),
.A2(n_8),
.B(n_4),
.C(n_5),
.Y(n_12)
);

INVxp33_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_12),
.Y(n_14)
);


endmodule