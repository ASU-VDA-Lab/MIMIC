module fake_netlist_602_2232_n_32 (n_7, n_9, n_11, n_8, n_5, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_32);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_32;

wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_13),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

NAND2xp33_ASAP7_75t_R g20 ( 
.A(n_2),
.B(n_8),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_13),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_19),
.B(n_15),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_21),
.B(n_14),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

NAND4xp75_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_23),
.C(n_26),
.D(n_20),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_25),
.B1(n_21),
.B2(n_16),
.C(n_1),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_7),
.B1(n_5),
.B2(n_4),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_32)
);


endmodule