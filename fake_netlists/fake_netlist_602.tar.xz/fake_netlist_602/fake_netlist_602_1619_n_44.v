module fake_netlist_602_1619_n_44 (n_7, n_9, n_11, n_8, n_5, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_44);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_44;

wire n_31;
wire n_15;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_42;
wire n_33;
wire n_14;
wire n_41;

AND2x2_ASAP7_75t_L g14 ( 
.A(n_6),
.B(n_0),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx16_ASAP7_75t_R g18 ( 
.A(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_4),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_7),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_18),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_19),
.A2(n_14),
.B(n_15),
.C(n_16),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_19),
.A2(n_3),
.B1(n_1),
.B2(n_5),
.C(n_8),
.Y(n_27)
);

A2O1A1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_14),
.A2(n_12),
.B(n_5),
.C(n_3),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_23),
.B(n_18),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_25),
.A2(n_15),
.B1(n_14),
.B2(n_20),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

BUFx3_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

NAND5xp2_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_26),
.C(n_27),
.D(n_28),
.E(n_13),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_13),
.Y(n_35)
);

O2A1O1Ixp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_32),
.B(n_31),
.C(n_29),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_31),
.B1(n_30),
.B2(n_35),
.C(n_21),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AO22x1_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_35),
.B1(n_37),
.B2(n_22),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_10),
.B1(n_43),
.B2(n_38),
.Y(n_44)
);


endmodule