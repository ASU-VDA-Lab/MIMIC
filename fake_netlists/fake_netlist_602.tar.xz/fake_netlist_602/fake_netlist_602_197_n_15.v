module fake_netlist_602_197_n_15 (n_0, n_4, n_1, n_2, n_3, n_15);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_15;

wire n_7;
wire n_11;
wire n_8;
wire n_5;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_0),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_1),
.Y(n_6)
);

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_1),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_6),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

OAI211xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B(n_7),
.C(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_12),
.Y(n_13)
);

AOI22x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_5),
.B1(n_2),
.B2(n_0),
.Y(n_14)
);

AOI322xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_2),
.A3(n_3),
.B1(n_4),
.B2(n_7),
.C1(n_5),
.C2(n_13),
.Y(n_15)
);


endmodule