module fake_netlist_602_1146_n_22 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_22);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_22;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_17;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

XOR2xp5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_1),
.Y(n_10)
);

AND2x2_ASAP7_75t_SL g11 ( 
.A(n_5),
.B(n_6),
.Y(n_11)
);

AND2x2_ASAP7_75t_SL g12 ( 
.A(n_9),
.B(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_3),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_10),
.A2(n_12),
.B(n_11),
.Y(n_16)
);

AO31x2_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_12),
.A3(n_13),
.B(n_3),
.Y(n_17)
);

NOR2x1p5_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_0),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_13),
.B(n_16),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_16),
.B1(n_17),
.B2(n_4),
.Y(n_20)
);

XNOR2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_4),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);


endmodule