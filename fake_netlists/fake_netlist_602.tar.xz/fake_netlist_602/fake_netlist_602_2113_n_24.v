module fake_netlist_602_2113_n_24 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_24);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_24;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

OAI22xp5_ASAP7_75t_SL g8 ( 
.A1(n_3),
.A2(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_7),
.B1(n_0),
.B2(n_4),
.Y(n_10)
);

BUFx10_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

CKINVDCx11_ASAP7_75t_R g15 ( 
.A(n_13),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI21xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_14),
.B(n_13),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.Y(n_18)
);

AOI21xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_12),
.B(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_18),
.Y(n_20)
);

INVxp33_ASAP7_75t_SL g21 ( 
.A(n_19),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_8),
.B1(n_12),
.B2(n_15),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_22),
.B1(n_12),
.B2(n_11),
.Y(n_24)
);


endmodule