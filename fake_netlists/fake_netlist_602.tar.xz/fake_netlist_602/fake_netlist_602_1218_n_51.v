module fake_netlist_602_1218_n_51 (n_11, n_8, n_15, n_3, n_21, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_51);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_51;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_15),
.B(n_1),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

NOR2xp67_ASAP7_75t_L g26 ( 
.A(n_11),
.B(n_5),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_4),
.B(n_15),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_L g30 ( 
.A(n_9),
.B(n_14),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_23),
.B(n_17),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_18),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_0),
.Y(n_34)
);

A2O1A1Ixp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_26),
.B(n_22),
.C(n_27),
.Y(n_35)
);

O2A1O1Ixp33_ASAP7_75t_SL g36 ( 
.A1(n_33),
.A2(n_30),
.B(n_25),
.C(n_28),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_SL g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVxp67_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_31),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_39),
.B1(n_29),
.B2(n_25),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_25),
.B1(n_28),
.B2(n_2),
.C(n_3),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AO22x2_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_10),
.B1(n_8),
.B2(n_7),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

OR3x1_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_13),
.C(n_12),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_49),
.Y(n_50)
);

AOI22x1_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_48),
.B1(n_47),
.B2(n_46),
.Y(n_51)
);


endmodule