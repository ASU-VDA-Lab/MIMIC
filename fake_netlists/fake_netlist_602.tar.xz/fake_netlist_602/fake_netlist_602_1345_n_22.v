module fake_netlist_602_1345_n_22 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_22);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_22;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_17;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

INVx3_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_1),
.C(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_6),
.B(n_3),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

BUFx8_ASAP7_75t_SL g15 ( 
.A(n_10),
.Y(n_15)
);

AO31x2_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_7),
.A3(n_6),
.B(n_8),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.B(n_11),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.B(n_10),
.C(n_16),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B1(n_16),
.B2(n_7),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_9),
.Y(n_22)
);


endmodule