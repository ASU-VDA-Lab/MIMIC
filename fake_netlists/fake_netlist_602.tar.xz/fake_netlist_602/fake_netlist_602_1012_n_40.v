module fake_netlist_602_1012_n_40 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_40);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_40;

wire n_31;
wire n_37;
wire n_39;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

BUFx3_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_15),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_16),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_9),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_11),
.Y(n_23)
);

NOR2xp67_ASAP7_75t_L g24 ( 
.A(n_0),
.B(n_1),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_3),
.B(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_17),
.A2(n_7),
.B(n_5),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_25),
.A2(n_20),
.B1(n_17),
.B2(n_23),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_28),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_23),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_30),
.B(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

XNOR2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_19),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_27),
.B(n_25),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI31xp33_ASAP7_75t_SL g37 ( 
.A1(n_35),
.A2(n_16),
.A3(n_6),
.B(n_4),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_22),
.B(n_10),
.Y(n_39)
);

AOI222xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_4),
.B1(n_6),
.B2(n_12),
.C1(n_36),
.C2(n_39),
.Y(n_40)
);


endmodule