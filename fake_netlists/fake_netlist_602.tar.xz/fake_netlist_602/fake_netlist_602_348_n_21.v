module fake_netlist_602_348_n_21 (n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_21);

input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_21;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_7;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

CKINVDCx16_ASAP7_75t_R g8 ( 
.A(n_0),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_1),
.B(n_2),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_2),
.B(n_1),
.Y(n_11)
);

O2A1O1Ixp5_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_4),
.B(n_2),
.C(n_1),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_9),
.B1(n_10),
.B2(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_12),
.B(n_8),
.C(n_14),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B1(n_10),
.B2(n_4),
.C(n_5),
.Y(n_17)
);

BUFx4f_ASAP7_75t_SL g18 ( 
.A(n_16),
.Y(n_18)
);

OAI22x1_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_6),
.B1(n_20),
.B2(n_18),
.Y(n_21)
);


endmodule