module fake_netlist_602_1248_n_18 (n_0, n_4, n_1, n_2, n_3, n_18);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_18;

wire n_7;
wire n_9;
wire n_11;
wire n_16;
wire n_8;
wire n_5;
wire n_15;
wire n_14;
wire n_17;
wire n_10;
wire n_13;
wire n_6;
wire n_12;

OR2x2_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_3),
.A2(n_0),
.B1(n_1),
.B2(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

A2O1A1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.C(n_2),
.Y(n_9)
);

AO21x2_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_0),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_7),
.B1(n_1),
.B2(n_2),
.C(n_3),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.C(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_12),
.B1(n_16),
.B2(n_13),
.Y(n_18)
);


endmodule