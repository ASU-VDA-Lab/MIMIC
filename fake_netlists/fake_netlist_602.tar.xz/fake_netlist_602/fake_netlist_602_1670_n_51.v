module fake_netlist_602_1670_n_51 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_51);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_51;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

INVx1_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_21),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_6),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_18),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_11),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_4),
.B(n_22),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_17),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_30),
.Y(n_35)
);

INVxp67_ASAP7_75t_SL g36 ( 
.A(n_24),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_26),
.B(n_17),
.Y(n_37)
);

A2O1A1Ixp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_37),
.B(n_34),
.C(n_29),
.Y(n_38)
);

NAND2x1_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_32),
.Y(n_39)
);

NOR2x1_ASAP7_75t_R g40 ( 
.A(n_38),
.B(n_35),
.Y(n_40)
);

AOI33xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_30),
.A3(n_23),
.B1(n_28),
.B2(n_27),
.B3(n_25),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_41),
.Y(n_42)
);

NOR2xp67_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_33),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_23),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_0),
.Y(n_45)
);

NAND4xp75_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_3),
.C(n_2),
.D(n_1),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_10),
.B1(n_7),
.B2(n_5),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

AOI222xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_48),
.B1(n_15),
.B2(n_13),
.C1(n_19),
.C2(n_14),
.Y(n_51)
);


endmodule