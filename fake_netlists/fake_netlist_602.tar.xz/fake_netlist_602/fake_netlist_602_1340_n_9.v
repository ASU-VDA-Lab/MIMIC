module fake_netlist_602_1340_n_9 (n_0, n_4, n_1, n_2, n_3, n_9);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_9;

wire n_7;
wire n_8;
wire n_5;
wire n_6;

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_2),
.Y(n_5)
);

INVx8_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_2),
.A2(n_1),
.B(n_4),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_0),
.Y(n_8)
);

OAI221xp5_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_6),
.B1(n_7),
.B2(n_5),
.C(n_0),
.Y(n_9)
);


endmodule