module fake_netlist_602_838_n_24 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_24);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_24;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_6),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx11_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_9),
.B(n_7),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_3),
.B(n_1),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_8),
.B(n_5),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B1(n_17),
.B2(n_14),
.C1(n_15),
.C2(n_4),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_14),
.B1(n_17),
.B2(n_19),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B(n_10),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_7),
.B1(n_4),
.B2(n_12),
.Y(n_24)
);


endmodule