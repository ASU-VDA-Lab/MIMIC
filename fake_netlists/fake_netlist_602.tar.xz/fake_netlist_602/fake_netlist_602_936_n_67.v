module fake_netlist_602_936_n_67 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_67);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_67;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_58;
wire n_27;
wire n_28;
wire n_62;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_65;
wire n_25;
wire n_63;
wire n_26;
wire n_60;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_66;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_64;
wire n_34;

INVx2_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_12),
.B(n_17),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_10),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_17),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_16),
.B(n_18),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_21),
.B(n_0),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_21),
.B(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_30),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_0),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

CKINVDCx16_ASAP7_75t_R g38 ( 
.A(n_35),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_32),
.Y(n_39)
);

BUFx3_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_35),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_37),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_37),
.Y(n_44)
);

BUFx3_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

OAI32xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_31),
.A3(n_25),
.B1(n_27),
.B2(n_28),
.Y(n_47)
);

OAI222xp33_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_38),
.B1(n_42),
.B2(n_22),
.C1(n_29),
.C2(n_28),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_43),
.B(n_44),
.Y(n_49)
);

XOR2x2_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_2),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

OAI21xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_41),
.B(n_40),
.Y(n_52)
);

OAI21xp5_ASAP7_75t_L g53 ( 
.A1(n_47),
.A2(n_41),
.B(n_40),
.Y(n_53)
);

A2O1A1Ixp33_ASAP7_75t_L g54 ( 
.A1(n_47),
.A2(n_41),
.B(n_45),
.C(n_29),
.Y(n_54)
);

NAND4xp25_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_22),
.C(n_41),
.D(n_2),
.Y(n_55)
);

OR4x2_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_18),
.C(n_16),
.D(n_3),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

NAND5xp2_ASAP7_75t_L g58 ( 
.A(n_54),
.B(n_20),
.C(n_19),
.D(n_3),
.E(n_23),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_53),
.Y(n_59)
);

BUFx2_ASAP7_75t_L g60 ( 
.A(n_55),
.Y(n_60)
);

BUFx2_ASAP7_75t_L g61 ( 
.A(n_57),
.Y(n_61)
);

OAI22xp5_ASAP7_75t_L g62 ( 
.A1(n_58),
.A2(n_50),
.B1(n_20),
.B2(n_1),
.Y(n_62)
);

AOI22xp5_ASAP7_75t_L g63 ( 
.A1(n_59),
.A2(n_9),
.B1(n_7),
.B2(n_5),
.Y(n_63)
);

INVx2_ASAP7_75t_L g64 ( 
.A(n_61),
.Y(n_64)
);

NAND2xp5_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_59),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_62),
.Y(n_66)
);

AOI322xp5_ASAP7_75t_L g67 ( 
.A1(n_66),
.A2(n_13),
.A3(n_56),
.B1(n_63),
.B2(n_60),
.C1(n_64),
.C2(n_65),
.Y(n_67)
);


endmodule