module fake_netlist_734_2589_n_38 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_38);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_38;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

INVx3_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_9),
.B(n_5),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_7),
.B(n_0),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_22),
.B(n_20),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_15),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_24),
.B(n_17),
.C(n_16),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_21),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_18),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

XNOR2x1_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_26),
.Y(n_32)
);

OAI211xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_28),
.B(n_19),
.C(n_21),
.Y(n_33)
);

A2O1A1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_20),
.B(n_23),
.C(n_16),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_34),
.A2(n_17),
.B1(n_3),
.B2(n_2),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OAI332xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_36),
.A3(n_11),
.B1(n_12),
.B2(n_6),
.B3(n_13),
.C1(n_4),
.C2(n_14),
.Y(n_38)
);


endmodule