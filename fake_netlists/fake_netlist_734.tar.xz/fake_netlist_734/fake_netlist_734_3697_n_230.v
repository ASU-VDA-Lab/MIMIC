module fake_netlist_734_3697_n_230 (n_20, n_23, n_14, n_22, n_36, n_16, n_18, n_34, n_13, n_11, n_1, n_28, n_27, n_24, n_10, n_5, n_26, n_6, n_33, n_31, n_30, n_2, n_3, n_9, n_35, n_4, n_25, n_7, n_17, n_21, n_12, n_15, n_19, n_29, n_32, n_0, n_8, n_230);

input n_20;
input n_23;
input n_14;
input n_22;
input n_36;
input n_16;
input n_18;
input n_34;
input n_13;
input n_11;
input n_1;
input n_28;
input n_27;
input n_24;
input n_10;
input n_5;
input n_26;
input n_6;
input n_33;
input n_31;
input n_30;
input n_2;
input n_3;
input n_9;
input n_35;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_29;
input n_32;
input n_0;
input n_8;

output n_230;

wire n_77;
wire n_71;
wire n_80;
wire n_62;
wire n_215;
wire n_186;
wire n_156;
wire n_175;
wire n_153;
wire n_81;
wire n_106;
wire n_200;
wire n_217;
wire n_104;
wire n_223;
wire n_68;
wire n_73;
wire n_192;
wire n_176;
wire n_173;
wire n_139;
wire n_127;
wire n_112;
wire n_182;
wire n_183;
wire n_155;
wire n_94;
wire n_189;
wire n_105;
wire n_60;
wire n_53;
wire n_57;
wire n_224;
wire n_218;
wire n_41;
wire n_157;
wire n_119;
wire n_84;
wire n_86;
wire n_195;
wire n_55;
wire n_131;
wire n_201;
wire n_191;
wire n_126;
wire n_151;
wire n_210;
wire n_140;
wire n_184;
wire n_46;
wire n_64;
wire n_82;
wire n_196;
wire n_76;
wire n_193;
wire n_194;
wire n_72;
wire n_108;
wire n_145;
wire n_51;
wire n_78;
wire n_102;
wire n_98;
wire n_97;
wire n_118;
wire n_75;
wire n_197;
wire n_42;
wire n_132;
wire n_85;
wire n_160;
wire n_147;
wire n_198;
wire n_95;
wire n_180;
wire n_149;
wire n_174;
wire n_70;
wire n_63;
wire n_69;
wire n_166;
wire n_144;
wire n_100;
wire n_56;
wire n_167;
wire n_204;
wire n_111;
wire n_125;
wire n_92;
wire n_52;
wire n_141;
wire n_214;
wire n_136;
wire n_61;
wire n_110;
wire n_222;
wire n_172;
wire n_207;
wire n_45;
wire n_190;
wire n_137;
wire n_90;
wire n_65;
wire n_148;
wire n_169;
wire n_226;
wire n_150;
wire n_227;
wire n_87;
wire n_187;
wire n_117;
wire n_133;
wire n_128;
wire n_50;
wire n_229;
wire n_96;
wire n_138;
wire n_203;
wire n_216;
wire n_79;
wire n_130;
wire n_225;
wire n_101;
wire n_122;
wire n_43;
wire n_165;
wire n_209;
wire n_58;
wire n_91;
wire n_188;
wire n_103;
wire n_123;
wire n_163;
wire n_115;
wire n_74;
wire n_220;
wire n_199;
wire n_121;
wire n_116;
wire n_44;
wire n_66;
wire n_159;
wire n_39;
wire n_99;
wire n_181;
wire n_205;
wire n_48;
wire n_211;
wire n_49;
wire n_170;
wire n_134;
wire n_114;
wire n_59;
wire n_37;
wire n_89;
wire n_161;
wire n_135;
wire n_162;
wire n_40;
wire n_109;
wire n_120;
wire n_158;
wire n_38;
wire n_124;
wire n_168;
wire n_107;
wire n_208;
wire n_228;
wire n_179;
wire n_212;
wire n_221;
wire n_154;
wire n_164;
wire n_143;
wire n_178;
wire n_129;
wire n_67;
wire n_171;
wire n_177;
wire n_206;
wire n_142;
wire n_47;
wire n_88;
wire n_152;
wire n_93;
wire n_146;
wire n_54;
wire n_185;
wire n_213;
wire n_83;
wire n_202;
wire n_113;
wire n_219;

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_27),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_19),
.Y(n_38)
);

CKINVDCx20_ASAP7_75t_R g39 ( 
.A(n_31),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_29),
.Y(n_40)
);

CKINVDCx14_ASAP7_75t_R g41 ( 
.A(n_22),
.Y(n_41)
);

CKINVDCx14_ASAP7_75t_R g42 ( 
.A(n_24),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_30),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_32),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_6),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_15),
.Y(n_46)
);

BUFx3_ASAP7_75t_L g47 ( 
.A(n_4),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_2),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_14),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_18),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_26),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_39),
.Y(n_52)
);

NAND2xp33_ASAP7_75t_R g53 ( 
.A(n_43),
.B(n_0),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_47),
.Y(n_54)
);

CKINVDCx5p33_ASAP7_75t_R g55 ( 
.A(n_41),
.Y(n_55)
);

NOR2xp33_ASAP7_75t_R g56 ( 
.A(n_41),
.B(n_16),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_39),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_47),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_44),
.B(n_42),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_40),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_40),
.Y(n_61)
);

CKINVDCx5p33_ASAP7_75t_R g62 ( 
.A(n_42),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_47),
.Y(n_63)
);

INVxp67_ASAP7_75t_L g64 ( 
.A(n_59),
.Y(n_64)
);

BUFx3_ASAP7_75t_L g65 ( 
.A(n_54),
.Y(n_65)
);

HB1xp67_ASAP7_75t_L g66 ( 
.A(n_59),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_60),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_60),
.Y(n_68)
);

NAND2x1p5_ASAP7_75t_L g69 ( 
.A(n_59),
.B(n_38),
.Y(n_69)
);

CKINVDCx5p33_ASAP7_75t_R g70 ( 
.A(n_52),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_54),
.B(n_44),
.Y(n_71)
);

AND2x4_ASAP7_75t_L g72 ( 
.A(n_58),
.B(n_45),
.Y(n_72)
);

OAI22xp5_ASAP7_75t_L g73 ( 
.A1(n_55),
.A2(n_48),
.B1(n_46),
.B2(n_45),
.Y(n_73)
);

INVxp67_ASAP7_75t_L g74 ( 
.A(n_55),
.Y(n_74)
);

INVx1_ASAP7_75t_SL g75 ( 
.A(n_62),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_58),
.B(n_38),
.Y(n_76)
);

INVx2_ASAP7_75t_L g77 ( 
.A(n_65),
.Y(n_77)
);

AOI22xp5_ASAP7_75t_L g78 ( 
.A1(n_64),
.A2(n_53),
.B1(n_63),
.B2(n_46),
.Y(n_78)
);

INVx4_ASAP7_75t_L g79 ( 
.A(n_72),
.Y(n_79)
);

NAND2xp5_ASAP7_75t_L g80 ( 
.A(n_69),
.B(n_62),
.Y(n_80)
);

AOI21xp5_ASAP7_75t_L g81 ( 
.A1(n_64),
.A2(n_71),
.B(n_76),
.Y(n_81)
);

NAND2xp5_ASAP7_75t_SL g82 ( 
.A(n_69),
.B(n_56),
.Y(n_82)
);

A2O1A1Ixp33_ASAP7_75t_L g83 ( 
.A1(n_67),
.A2(n_68),
.B(n_72),
.C(n_76),
.Y(n_83)
);

AOI21xp5_ASAP7_75t_L g84 ( 
.A1(n_71),
.A2(n_63),
.B(n_60),
.Y(n_84)
);

NOR2xp33_ASAP7_75t_L g85 ( 
.A(n_66),
.B(n_57),
.Y(n_85)
);

NAND2xp5_ASAP7_75t_L g86 ( 
.A(n_69),
.B(n_56),
.Y(n_86)
);

NAND2xp5_ASAP7_75t_L g87 ( 
.A(n_69),
.B(n_43),
.Y(n_87)
);

AOI21xp5_ASAP7_75t_L g88 ( 
.A1(n_66),
.A2(n_61),
.B(n_40),
.Y(n_88)
);

OAI21xp33_ASAP7_75t_L g89 ( 
.A1(n_67),
.A2(n_61),
.B(n_49),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_68),
.Y(n_90)
);

INVx2_ASAP7_75t_L g91 ( 
.A(n_65),
.Y(n_91)
);

NAND2xp5_ASAP7_75t_L g92 ( 
.A(n_72),
.B(n_37),
.Y(n_92)
);

AND2x2_ASAP7_75t_L g93 ( 
.A(n_79),
.B(n_75),
.Y(n_93)
);

NAND2xp5_ASAP7_75t_L g94 ( 
.A(n_81),
.B(n_72),
.Y(n_94)
);

BUFx4f_ASAP7_75t_L g95 ( 
.A(n_90),
.Y(n_95)
);

BUFx3_ASAP7_75t_L g96 ( 
.A(n_79),
.Y(n_96)
);

OAI21x1_ASAP7_75t_L g97 ( 
.A1(n_88),
.A2(n_51),
.B(n_61),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_79),
.B(n_72),
.Y(n_98)
);

OA21x2_ASAP7_75t_L g99 ( 
.A1(n_83),
.A2(n_51),
.B(n_49),
.Y(n_99)
);

OR2x2_ASAP7_75t_L g100 ( 
.A(n_78),
.B(n_75),
.Y(n_100)
);

NAND2x1p5_ASAP7_75t_L g101 ( 
.A(n_90),
.B(n_82),
.Y(n_101)
);

CKINVDCx5p33_ASAP7_75t_R g102 ( 
.A(n_78),
.Y(n_102)
);

BUFx12f_ASAP7_75t_L g103 ( 
.A(n_85),
.Y(n_103)
);

OAI21x1_ASAP7_75t_L g104 ( 
.A1(n_84),
.A2(n_73),
.B(n_53),
.Y(n_104)
);

AND2x2_ASAP7_75t_L g105 ( 
.A(n_87),
.B(n_74),
.Y(n_105)
);

HB1xp67_ASAP7_75t_L g106 ( 
.A(n_77),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_77),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_91),
.Y(n_108)
);

OR2x2_ASAP7_75t_L g109 ( 
.A(n_100),
.B(n_86),
.Y(n_109)
);

OAI211xp5_ASAP7_75t_L g110 ( 
.A1(n_100),
.A2(n_80),
.B(n_73),
.C(n_92),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_94),
.B(n_91),
.Y(n_111)
);

NAND2xp5_ASAP7_75t_L g112 ( 
.A(n_94),
.B(n_65),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_94),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_107),
.Y(n_114)
);

BUFx8_ASAP7_75t_SL g115 ( 
.A(n_103),
.Y(n_115)
);

INVx5_ASAP7_75t_L g116 ( 
.A(n_96),
.Y(n_116)
);

CKINVDCx16_ASAP7_75t_R g117 ( 
.A(n_103),
.Y(n_117)
);

INVx2_ASAP7_75t_L g118 ( 
.A(n_107),
.Y(n_118)
);

BUFx3_ASAP7_75t_L g119 ( 
.A(n_95),
.Y(n_119)
);

BUFx6f_ASAP7_75t_L g120 ( 
.A(n_95),
.Y(n_120)
);

NAND3xp33_ASAP7_75t_SL g121 ( 
.A(n_102),
.B(n_70),
.C(n_50),
.Y(n_121)
);

BUFx6f_ASAP7_75t_L g122 ( 
.A(n_116),
.Y(n_122)
);

AOI21x1_ASAP7_75t_L g123 ( 
.A1(n_113),
.A2(n_97),
.B(n_99),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_113),
.B(n_102),
.Y(n_124)
);

AO31x2_ASAP7_75t_L g125 ( 
.A1(n_118),
.A2(n_108),
.A3(n_107),
.B(n_98),
.Y(n_125)
);

OAI21x1_ASAP7_75t_L g126 ( 
.A1(n_111),
.A2(n_97),
.B(n_101),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_118),
.Y(n_127)
);

A2O1A1Ixp33_ASAP7_75t_L g128 ( 
.A1(n_110),
.A2(n_95),
.B(n_104),
.C(n_105),
.Y(n_128)
);

AOI22xp33_ASAP7_75t_SL g129 ( 
.A1(n_117),
.A2(n_103),
.B1(n_100),
.B2(n_95),
.Y(n_129)
);

AO31x2_ASAP7_75t_L g130 ( 
.A1(n_118),
.A2(n_108),
.A3(n_98),
.B(n_99),
.Y(n_130)
);

NAND2xp5_ASAP7_75t_L g131 ( 
.A(n_110),
.B(n_105),
.Y(n_131)
);

AND2x2_ASAP7_75t_L g132 ( 
.A(n_127),
.B(n_114),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_127),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_125),
.Y(n_134)
);

AND2x2_ASAP7_75t_L g135 ( 
.A(n_125),
.B(n_114),
.Y(n_135)
);

AND2x2_ASAP7_75t_L g136 ( 
.A(n_125),
.B(n_99),
.Y(n_136)
);

NAND2xp5_ASAP7_75t_L g137 ( 
.A(n_124),
.B(n_131),
.Y(n_137)
);

AND2x2_ASAP7_75t_L g138 ( 
.A(n_125),
.B(n_99),
.Y(n_138)
);

INVx2_ASAP7_75t_L g139 ( 
.A(n_125),
.Y(n_139)
);

INVx1_ASAP7_75t_L g140 ( 
.A(n_130),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_130),
.Y(n_141)
);

INVx2_ASAP7_75t_L g142 ( 
.A(n_123),
.Y(n_142)
);

OR2x2_ASAP7_75t_L g143 ( 
.A(n_135),
.B(n_130),
.Y(n_143)
);

AND2x2_ASAP7_75t_L g144 ( 
.A(n_135),
.B(n_130),
.Y(n_144)
);

NAND2xp5_ASAP7_75t_L g145 ( 
.A(n_133),
.B(n_130),
.Y(n_145)
);

AO21x2_ASAP7_75t_L g146 ( 
.A1(n_142),
.A2(n_128),
.B(n_123),
.Y(n_146)
);

AOI22xp5_ASAP7_75t_L g147 ( 
.A1(n_137),
.A2(n_129),
.B1(n_103),
.B2(n_109),
.Y(n_147)
);

AND2x2_ASAP7_75t_L g148 ( 
.A(n_138),
.B(n_126),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_134),
.Y(n_149)
);

OAI221xp5_ASAP7_75t_L g150 ( 
.A1(n_140),
.A2(n_121),
.B1(n_105),
.B2(n_109),
.C(n_101),
.Y(n_150)
);

INVx2_ASAP7_75t_L g151 ( 
.A(n_142),
.Y(n_151)
);

OR2x6_ASAP7_75t_L g152 ( 
.A(n_139),
.B(n_122),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_134),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_139),
.Y(n_154)
);

INVx3_ASAP7_75t_L g155 ( 
.A(n_139),
.Y(n_155)
);

AND2x2_ASAP7_75t_L g156 ( 
.A(n_138),
.B(n_126),
.Y(n_156)
);

NAND3xp33_ASAP7_75t_SL g157 ( 
.A(n_147),
.B(n_136),
.C(n_115),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_149),
.Y(n_158)
);

NAND2xp5_ASAP7_75t_SL g159 ( 
.A(n_147),
.B(n_141),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_149),
.Y(n_160)
);

AOI22xp5_ASAP7_75t_L g161 ( 
.A1(n_150),
.A2(n_103),
.B1(n_121),
.B2(n_136),
.Y(n_161)
);

INVxp67_ASAP7_75t_L g162 ( 
.A(n_145),
.Y(n_162)
);

OAI221xp5_ASAP7_75t_L g163 ( 
.A1(n_153),
.A2(n_89),
.B1(n_109),
.B2(n_99),
.C(n_101),
.Y(n_163)
);

OAI31xp33_ASAP7_75t_SL g164 ( 
.A1(n_144),
.A2(n_132),
.A3(n_104),
.B(n_89),
.Y(n_164)
);

AND2x2_ASAP7_75t_L g165 ( 
.A(n_144),
.B(n_132),
.Y(n_165)
);

NAND2xp5_ASAP7_75t_L g166 ( 
.A(n_143),
.B(n_99),
.Y(n_166)
);

INVxp67_ASAP7_75t_L g167 ( 
.A(n_143),
.Y(n_167)
);

AOI21xp33_ASAP7_75t_L g168 ( 
.A1(n_146),
.A2(n_99),
.B(n_104),
.Y(n_168)
);

NAND2xp5_ASAP7_75t_L g169 ( 
.A(n_148),
.B(n_122),
.Y(n_169)
);

NOR2xp33_ASAP7_75t_L g170 ( 
.A(n_148),
.B(n_0),
.Y(n_170)
);

OAI311xp33_ASAP7_75t_L g171 ( 
.A1(n_155),
.A2(n_111),
.A3(n_3),
.B1(n_1),
.C1(n_2),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_154),
.Y(n_172)
);

AND2x2_ASAP7_75t_L g173 ( 
.A(n_165),
.B(n_156),
.Y(n_173)
);

NAND2xp5_ASAP7_75t_L g174 ( 
.A(n_165),
.B(n_167),
.Y(n_174)
);

NAND2xp5_ASAP7_75t_L g175 ( 
.A(n_162),
.B(n_156),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_158),
.Y(n_176)
);

NAND2xp5_ASAP7_75t_L g177 ( 
.A(n_170),
.B(n_155),
.Y(n_177)
);

OAI21xp5_ASAP7_75t_SL g178 ( 
.A1(n_157),
.A2(n_155),
.B(n_122),
.Y(n_178)
);

NAND2xp5_ASAP7_75t_L g179 ( 
.A(n_170),
.B(n_160),
.Y(n_179)
);

INVx1_ASAP7_75t_L g180 ( 
.A(n_172),
.Y(n_180)
);

INVx2_ASAP7_75t_L g181 ( 
.A(n_172),
.Y(n_181)
);

INVx2_ASAP7_75t_SL g182 ( 
.A(n_169),
.Y(n_182)
);

INVxp67_ASAP7_75t_L g183 ( 
.A(n_159),
.Y(n_183)
);

NOR2xp33_ASAP7_75t_L g184 ( 
.A(n_161),
.B(n_1),
.Y(n_184)
);

NOR2xp33_ASAP7_75t_L g185 ( 
.A(n_159),
.B(n_3),
.Y(n_185)
);

NAND3xp33_ASAP7_75t_L g186 ( 
.A(n_164),
.B(n_152),
.C(n_151),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_166),
.Y(n_187)
);

INVx1_ASAP7_75t_L g188 ( 
.A(n_163),
.Y(n_188)
);

AND2x2_ASAP7_75t_L g189 ( 
.A(n_168),
.B(n_152),
.Y(n_189)
);

INVx1_ASAP7_75t_L g190 ( 
.A(n_171),
.Y(n_190)
);

NAND2xp5_ASAP7_75t_L g191 ( 
.A(n_165),
.B(n_151),
.Y(n_191)
);

INVxp67_ASAP7_75t_L g192 ( 
.A(n_185),
.Y(n_192)
);

NAND4xp25_ASAP7_75t_L g193 ( 
.A(n_190),
.B(n_93),
.C(n_119),
.D(n_4),
.Y(n_193)
);

OAI211xp5_ASAP7_75t_SL g194 ( 
.A1(n_190),
.A2(n_98),
.B(n_6),
.C(n_5),
.Y(n_194)
);

CKINVDCx5p33_ASAP7_75t_R g195 ( 
.A(n_179),
.Y(n_195)
);

OAI211xp5_ASAP7_75t_L g196 ( 
.A1(n_178),
.A2(n_116),
.B(n_122),
.C(n_119),
.Y(n_196)
);

AOI321xp33_ASAP7_75t_L g197 ( 
.A1(n_188),
.A2(n_8),
.A3(n_7),
.B1(n_9),
.B2(n_11),
.C(n_10),
.Y(n_197)
);

XNOR2xp5_ASAP7_75t_L g198 ( 
.A(n_174),
.B(n_7),
.Y(n_198)
);

AOI311xp33_ASAP7_75t_L g199 ( 
.A1(n_188),
.A2(n_9),
.A3(n_8),
.B(n_10),
.C(n_11),
.Y(n_199)
);

OAI21xp33_ASAP7_75t_L g200 ( 
.A1(n_183),
.A2(n_97),
.B(n_101),
.Y(n_200)
);

OAI321xp33_ASAP7_75t_L g201 ( 
.A1(n_186),
.A2(n_120),
.A3(n_112),
.B1(n_14),
.B2(n_13),
.C(n_12),
.Y(n_201)
);

AOI32xp33_ASAP7_75t_L g202 ( 
.A1(n_173),
.A2(n_97),
.A3(n_112),
.B1(n_12),
.B2(n_13),
.Y(n_202)
);

AOI221xp5_ASAP7_75t_L g203 ( 
.A1(n_175),
.A2(n_146),
.B1(n_120),
.B2(n_108),
.C(n_116),
.Y(n_203)
);

OAI22xp5_ASAP7_75t_SL g204 ( 
.A1(n_177),
.A2(n_116),
.B1(n_120),
.B2(n_96),
.Y(n_204)
);

AOI221xp5_ASAP7_75t_L g205 ( 
.A1(n_176),
.A2(n_146),
.B1(n_120),
.B2(n_95),
.C(n_116),
.Y(n_205)
);

AOI22xp5_ASAP7_75t_L g206 ( 
.A1(n_187),
.A2(n_116),
.B1(n_120),
.B2(n_95),
.Y(n_206)
);

AOI322xp5_ASAP7_75t_L g207 ( 
.A1(n_173),
.A2(n_116),
.A3(n_120),
.B1(n_106),
.B2(n_96),
.C1(n_17),
.C2(n_20),
.Y(n_207)
);

AOI322xp5_ASAP7_75t_L g208 ( 
.A1(n_191),
.A2(n_120),
.A3(n_106),
.B1(n_96),
.B2(n_23),
.C1(n_21),
.C2(n_25),
.Y(n_208)
);

O2A1O1Ixp33_ASAP7_75t_L g209 ( 
.A1(n_182),
.A2(n_96),
.B(n_33),
.C(n_28),
.Y(n_209)
);

AOI211xp5_ASAP7_75t_L g210 ( 
.A1(n_189),
.A2(n_36),
.B(n_35),
.C(n_34),
.Y(n_210)
);

O2A1O1Ixp33_ASAP7_75t_SL g211 ( 
.A1(n_198),
.A2(n_196),
.B(n_197),
.C(n_192),
.Y(n_211)
);

NAND3xp33_ASAP7_75t_L g212 ( 
.A(n_199),
.B(n_180),
.C(n_181),
.Y(n_212)
);

OAI211xp5_ASAP7_75t_SL g213 ( 
.A1(n_202),
.A2(n_207),
.B(n_208),
.C(n_210),
.Y(n_213)
);

NOR2xp33_ASAP7_75t_L g214 ( 
.A(n_193),
.B(n_194),
.Y(n_214)
);

NAND2x1p5_ASAP7_75t_L g215 ( 
.A(n_206),
.B(n_209),
.Y(n_215)
);

NAND4xp75_ASAP7_75t_L g216 ( 
.A(n_203),
.B(n_205),
.C(n_201),
.D(n_204),
.Y(n_216)
);

OAI22xp5_ASAP7_75t_L g217 ( 
.A1(n_200),
.A2(n_195),
.B1(n_178),
.B2(n_196),
.Y(n_217)
);

NAND4xp25_ASAP7_75t_L g218 ( 
.A(n_197),
.B(n_199),
.C(n_193),
.D(n_184),
.Y(n_218)
);

BUFx2_ASAP7_75t_L g219 ( 
.A(n_215),
.Y(n_219)
);

CKINVDCx5p33_ASAP7_75t_R g220 ( 
.A(n_214),
.Y(n_220)
);

INVx1_ASAP7_75t_SL g221 ( 
.A(n_217),
.Y(n_221)
);

BUFx12f_ASAP7_75t_L g222 ( 
.A(n_211),
.Y(n_222)
);

NOR3xp33_ASAP7_75t_SL g223 ( 
.A(n_218),
.B(n_213),
.C(n_216),
.Y(n_223)
);

AND2x4_ASAP7_75t_L g224 ( 
.A(n_219),
.B(n_212),
.Y(n_224)
);

INVx1_ASAP7_75t_SL g225 ( 
.A(n_219),
.Y(n_225)
);

NOR2xp33_ASAP7_75t_R g226 ( 
.A(n_225),
.B(n_220),
.Y(n_226)
);

BUFx2_ASAP7_75t_L g227 ( 
.A(n_224),
.Y(n_227)
);

OAI22xp5_ASAP7_75t_L g228 ( 
.A1(n_227),
.A2(n_222),
.B1(n_221),
.B2(n_224),
.Y(n_228)
);

AOI22xp33_ASAP7_75t_SL g229 ( 
.A1(n_228),
.A2(n_222),
.B1(n_224),
.B2(n_226),
.Y(n_229)
);

NAND3x2_ASAP7_75t_L g230 ( 
.A(n_229),
.B(n_223),
.C(n_222),
.Y(n_230)
);


endmodule