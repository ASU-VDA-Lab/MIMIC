module fake_netlist_734_258_n_23 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_23);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_23;

wire n_20;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_10;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_2),
.B(n_6),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_3),
.Y(n_11)
);

INVx5_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_10),
.B(n_7),
.Y(n_14)
);

O2A1O1Ixp5_ASAP7_75t_L g15 ( 
.A1(n_10),
.A2(n_9),
.B(n_7),
.C(n_11),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_8),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_12),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_20),
.B(n_17),
.Y(n_21)
);

XOR2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_14),
.Y(n_23)
);


endmodule