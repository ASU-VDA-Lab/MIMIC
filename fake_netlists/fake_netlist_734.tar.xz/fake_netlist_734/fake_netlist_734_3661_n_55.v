module fake_netlist_734_3661_n_55 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_55);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_55;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

BUFx3_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_6),
.B(n_5),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_17),
.A2(n_21),
.B(n_2),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_14),
.B(n_20),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_3),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_4),
.B(n_0),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_28),
.B(n_15),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_15),
.Y(n_34)
);

AO31x2_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_29),
.A3(n_25),
.B(n_22),
.Y(n_35)
);

NOR2xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_33),
.Y(n_36)
);

INVx3_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

NAND2x1_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_26),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_30),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_35),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_38),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_39),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

INVxp67_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

OAI21x1_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_23),
.B(n_35),
.Y(n_47)
);

OAI211xp5_ASAP7_75t_SL g48 ( 
.A1(n_46),
.A2(n_30),
.B(n_17),
.C(n_16),
.Y(n_48)
);

O2A1O1Ixp33_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_22),
.B(n_35),
.C(n_30),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

NAND4xp75_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_16),
.C(n_9),
.D(n_7),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

OAI21xp33_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_47),
.B(n_10),
.Y(n_53)
);

NOR3xp33_ASAP7_75t_SL g54 ( 
.A(n_52),
.B(n_12),
.C(n_11),
.Y(n_54)
);

OA21x2_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_53),
.B(n_13),
.Y(n_55)
);


endmodule