module fake_netlist_734_2217_n_31 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_31);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_31;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

NAND2xp33_ASAP7_75t_R g16 ( 
.A(n_10),
.B(n_4),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_2),
.B(n_0),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_3),
.B(n_1),
.Y(n_18)
);

OR2x6_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_1),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_19),
.B(n_14),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_15),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_15),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_11),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_21),
.Y(n_25)
);

OAI21xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_17),
.B(n_16),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_4),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_5),
.B1(n_26),
.B2(n_28),
.Y(n_31)
);


endmodule