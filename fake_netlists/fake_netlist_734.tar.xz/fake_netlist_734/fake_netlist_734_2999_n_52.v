module fake_netlist_734_2999_n_52 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_52);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_52;

wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_13),
.Y(n_28)
);

OA21x2_ASAP7_75t_L g29 ( 
.A1(n_6),
.A2(n_10),
.B(n_15),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_4),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_2),
.B(n_3),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_11),
.Y(n_32)
);

XNOR2x2_ASAP7_75t_L g33 ( 
.A(n_1),
.B(n_19),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_27),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_30),
.B(n_16),
.Y(n_36)
);

NOR3xp33_ASAP7_75t_SL g37 ( 
.A(n_32),
.B(n_18),
.C(n_16),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_34),
.B(n_28),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

OAI22xp33_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_28),
.B1(n_36),
.B2(n_37),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_39),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_37),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_18),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_24),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_29),
.B1(n_25),
.B2(n_31),
.Y(n_46)
);

OAI322xp33_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_33),
.A3(n_25),
.B1(n_24),
.B2(n_29),
.C1(n_0),
.C2(n_5),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_SL g48 ( 
.A(n_46),
.B(n_7),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_14),
.B1(n_12),
.B2(n_8),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_SL g52 ( 
.A1(n_50),
.A2(n_17),
.B1(n_21),
.B2(n_51),
.Y(n_52)
);


endmodule