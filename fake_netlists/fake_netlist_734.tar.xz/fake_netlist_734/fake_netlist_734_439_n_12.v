module fake_netlist_734_439_n_12 (n_1, n_2, n_3, n_4, n_0, n_12);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_12;

wire n_9;
wire n_11;
wire n_10;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

INVx2_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_SL g8 ( 
.A(n_3),
.Y(n_8)
);

NAND2xp33_ASAP7_75t_R g9 ( 
.A(n_6),
.B(n_5),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_1),
.B1(n_8),
.B2(n_9),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule