module fake_netlist_734_3044_n_10 (n_0, n_2, n_1, n_10);

input n_0;
input n_2;
input n_1;

output n_10;

wire n_3;
wire n_9;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

OAI21xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_4),
.B(n_2),
.Y(n_7)
);

OAI22xp5_ASAP7_75t_SL g8 ( 
.A1(n_7),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_8)
);

AOI21xp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_1),
.B1(n_2),
.B2(n_8),
.Y(n_10)
);


endmodule