module fake_netlist_734_82_n_31 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_31);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_31;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_15;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_0),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_12),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_16),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_21),
.B1(n_17),
.B2(n_14),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_18),
.C(n_15),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_SL g24 ( 
.A(n_22),
.B(n_17),
.C(n_6),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_7),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_7),
.B1(n_2),
.B2(n_1),
.Y(n_27)
);

INVx4_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

OR3x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_8),
.C(n_3),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_13),
.B2(n_11),
.Y(n_31)
);


endmodule