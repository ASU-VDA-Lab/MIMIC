module fake_netlist_734_3451_n_57 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_57);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_57;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx1_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_4),
.B(n_8),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_1),
.B(n_8),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_14),
.B(n_9),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_10),
.A2(n_6),
.B(n_2),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_18),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_18),
.B(n_0),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_26),
.B(n_0),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_SL g32 ( 
.A1(n_30),
.A2(n_24),
.B1(n_20),
.B2(n_21),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_27),
.A2(n_25),
.B(n_21),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_28),
.B(n_29),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVxp67_ASAP7_75t_SL g36 ( 
.A(n_33),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_32),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_28),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_23),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_37),
.B1(n_36),
.B2(n_30),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_37),
.B1(n_24),
.B2(n_20),
.C(n_22),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_35),
.B1(n_23),
.B2(n_22),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

OAI221xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_26),
.B1(n_25),
.B2(n_1),
.C(n_2),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_26),
.B1(n_5),
.B2(n_3),
.C(n_4),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

OAI322xp33_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_26),
.A3(n_7),
.B1(n_5),
.B2(n_3),
.C1(n_10),
.C2(n_9),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

OAI21xp5_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_25),
.B(n_7),
.Y(n_50)
);

AND2x2_ASAP7_75t_SL g51 ( 
.A(n_47),
.B(n_26),
.Y(n_51)
);

NOR3xp33_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_46),
.C(n_26),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_26),
.Y(n_54)
);

AOI22xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_52),
.B1(n_50),
.B2(n_26),
.Y(n_55)
);

AOI222xp33_ASAP7_75t_SL g56 ( 
.A1(n_53),
.A2(n_13),
.B1(n_11),
.B2(n_16),
.C1(n_17),
.C2(n_51),
.Y(n_56)
);

AOI322xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_16),
.A3(n_17),
.B1(n_54),
.B2(n_55),
.C1(n_51),
.C2(n_22),
.Y(n_57)
);


endmodule