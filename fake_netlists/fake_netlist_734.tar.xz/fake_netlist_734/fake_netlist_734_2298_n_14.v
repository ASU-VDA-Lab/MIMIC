module fake_netlist_734_2298_n_14 (n_0, n_2, n_1, n_14);

input n_0;
input n_2;
input n_1;

output n_14;

wire n_12;
wire n_3;
wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

NAND2x1p5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

OAI21xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AOI221xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_6),
.B1(n_4),
.B2(n_0),
.C(n_1),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B1(n_4),
.B2(n_0),
.C(n_1),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_1),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_2),
.B(n_13),
.Y(n_14)
);


endmodule