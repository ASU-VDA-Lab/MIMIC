module fake_netlist_734_3527_n_22 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_22);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_22;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_10),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_3),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_8),
.Y(n_14)
);

A2O1A1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_5),
.B(n_1),
.C(n_0),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_12),
.C(n_14),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_18),
.B(n_13),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_6),
.B1(n_4),
.B2(n_2),
.Y(n_22)
);


endmodule