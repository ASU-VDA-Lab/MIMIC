module fake_netlist_896_626_n_23 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_23);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_23;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

AND2x6_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_0),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_2),
.B(n_3),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVxp67_ASAP7_75t_SL g12 ( 
.A(n_7),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_2),
.C(n_1),
.Y(n_13)
);

BUFx3_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AND4x1_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.C(n_9),
.D(n_8),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_14),
.B(n_13),
.Y(n_18)
);

AOI211xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B(n_10),
.C(n_8),
.Y(n_19)
);

OAI21xp33_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_15),
.B(n_1),
.Y(n_20)
);

XNOR2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_4),
.Y(n_21)
);

OAI221xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_5),
.B1(n_6),
.B2(n_15),
.C(n_17),
.Y(n_22)
);

AOI222xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_5),
.B1(n_15),
.B2(n_22),
.C1(n_20),
.C2(n_12),
.Y(n_23)
);


endmodule