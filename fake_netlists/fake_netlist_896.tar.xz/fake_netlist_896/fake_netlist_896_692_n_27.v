module fake_netlist_896_692_n_27 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_27);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_27;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_SL g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_1),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_2),
.B(n_0),
.Y(n_19)
);

AOI22x1_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_14),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B1(n_15),
.B2(n_20),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_4),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.C(n_16),
.Y(n_25)
);

XNOR2x1_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_6),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_7),
.B1(n_13),
.B2(n_11),
.Y(n_27)
);


endmodule