module fake_netlist_896_2150_n_14 (n_0, n_1, n_3, n_2, n_14);

input n_0;
input n_1;
input n_3;
input n_2;

output n_14;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_0),
.Y(n_4)
);

BUFx2_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_0),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_2),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_2),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

OAI21xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_8),
.B(n_9),
.Y(n_12)
);

NAND4xp25_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.C(n_9),
.D(n_3),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B(n_9),
.Y(n_14)
);


endmodule