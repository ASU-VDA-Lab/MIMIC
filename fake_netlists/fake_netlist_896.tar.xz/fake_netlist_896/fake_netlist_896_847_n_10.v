module fake_netlist_896_847_n_10 (n_0, n_1, n_2, n_10);

input n_0;
input n_1;
input n_2;

output n_10;

wire n_5;
wire n_3;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

CKINVDCx5p33_ASAP7_75t_R g3 ( 
.A(n_2),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_SL g5 ( 
.A(n_3),
.B(n_2),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

AOI31xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_4),
.A3(n_1),
.B(n_0),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_1),
.B(n_2),
.Y(n_10)
);


endmodule