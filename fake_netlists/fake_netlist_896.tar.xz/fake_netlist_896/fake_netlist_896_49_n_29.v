module fake_netlist_896_49_n_29 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_29);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_29;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

INVx2_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

NAND2xp33_ASAP7_75t_R g18 ( 
.A(n_5),
.B(n_11),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_15),
.B(n_13),
.C(n_14),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_19),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_13),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_16),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI211xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_21),
.B(n_22),
.C(n_18),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_22),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_25),
.Y(n_27)
);

OAI322xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_4),
.A3(n_1),
.B1(n_6),
.B2(n_7),
.C1(n_3),
.C2(n_12),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.B1(n_7),
.B2(n_6),
.Y(n_29)
);


endmodule