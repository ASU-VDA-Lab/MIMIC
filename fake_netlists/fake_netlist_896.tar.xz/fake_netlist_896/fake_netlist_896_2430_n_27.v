module fake_netlist_896_2430_n_27 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_27);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_27;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_22;
wire n_25;
wire n_26;

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_12),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_1),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_7),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_18),
.B(n_0),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI322xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.A3(n_17),
.B1(n_16),
.B2(n_7),
.C1(n_3),
.C2(n_4),
.Y(n_23)
);

AOI211xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_20),
.B(n_6),
.C(n_5),
.Y(n_24)
);

NOR2x1_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_8),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_27)
);


endmodule