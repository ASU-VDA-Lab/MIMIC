module fake_netlist_896_3063_n_13 (n_0, n_1, n_3, n_2, n_13);

input n_0;
input n_1;
input n_3;
input n_2;

output n_13;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

AO21x2_ASAP7_75t_L g4 ( 
.A1(n_0),
.A2(n_3),
.B(n_1),
.Y(n_4)
);

AND2x6_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

OA21x2_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_7),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_2),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_1),
.B1(n_2),
.B2(n_5),
.C1(n_3),
.C2(n_0),
.Y(n_13)
);


endmodule