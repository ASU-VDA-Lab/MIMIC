module fake_netlist_896_2679_n_13 (n_0, n_1, n_2, n_13);

input n_0;
input n_1;
input n_2;

output n_13;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_SL g4 ( 
.A(n_2),
.Y(n_4)
);

AOI22xp33_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_5)
);

AO31x2_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_4),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OAI211xp5_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_3),
.B(n_7),
.C(n_4),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_8),
.B(n_6),
.C(n_0),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B1(n_6),
.B2(n_2),
.C1(n_1),
.C2(n_0),
.Y(n_13)
);


endmodule