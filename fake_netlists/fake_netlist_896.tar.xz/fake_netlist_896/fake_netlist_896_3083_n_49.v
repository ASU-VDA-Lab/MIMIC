module fake_netlist_896_3083_n_49 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_49);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_49;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_40;
wire n_9;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_13;
wire n_21;
wire n_25;
wire n_14;
wire n_22;
wire n_35;
wire n_32;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_10;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_3),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx11_ASAP7_75t_R g16 ( 
.A(n_1),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

BUFx10_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_1),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_12),
.B(n_14),
.Y(n_22)
);

AND3x1_ASAP7_75t_L g23 ( 
.A(n_14),
.B(n_7),
.C(n_6),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_13),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_18),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_17),
.B1(n_16),
.B2(n_7),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_18),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_21),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_26),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_25),
.Y(n_34)
);

OAI211xp5_ASAP7_75t_L g35 ( 
.A1(n_27),
.A2(n_16),
.B(n_19),
.C(n_22),
.Y(n_35)
);

NOR4xp25_ASAP7_75t_SL g36 ( 
.A(n_35),
.B(n_26),
.C(n_29),
.D(n_28),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_31),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_32),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NAND2xp33_ASAP7_75t_SL g41 ( 
.A(n_36),
.B(n_34),
.Y(n_41)
);

OAI221xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_38),
.B1(n_22),
.B2(n_19),
.C(n_31),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_37),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_20),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_42),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

AOI222xp33_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_45),
.B1(n_47),
.B2(n_46),
.C1(n_16),
.C2(n_28),
.Y(n_49)
);


endmodule