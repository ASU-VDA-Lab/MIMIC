module fake_netlist_611_1304_n_29 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_29);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_29;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

NOR2xp67_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_11),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_9),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_12),
.B(n_2),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_0),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_8),
.B(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_20),
.Y(n_22)
);

NOR2x1p5_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_17),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_22),
.B1(n_21),
.B2(n_14),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_16),
.B1(n_14),
.B2(n_15),
.C(n_18),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_26),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.B1(n_7),
.B2(n_6),
.Y(n_29)
);


endmodule