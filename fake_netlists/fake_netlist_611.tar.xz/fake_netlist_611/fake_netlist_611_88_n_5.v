module fake_netlist_611_88_n_5 (n_1, n_0, n_5);

input n_1;
input n_0;

output n_5;

wire n_4;
wire n_2;
wire n_3;

AND2x2_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

NAND3xp33_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.C(n_0),
.Y(n_3)
);

OAI211xp5_ASAP7_75t_SL g4 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_4)
);

OA22x2_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_5)
);


endmodule