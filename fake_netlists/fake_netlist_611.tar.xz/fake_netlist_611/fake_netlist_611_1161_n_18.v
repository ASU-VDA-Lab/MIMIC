module fake_netlist_611_1161_n_18 (n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_18);

input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_18;

wire n_7;
wire n_11;
wire n_9;
wire n_16;
wire n_8;
wire n_15;
wire n_14;
wire n_17;
wire n_10;
wire n_13;
wire n_12;

INVx2_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_3),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_5),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_6),
.B(n_5),
.C(n_0),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B(n_11),
.Y(n_14)
);

AOI321xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.A3(n_7),
.B1(n_9),
.B2(n_6),
.C(n_5),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_7),
.C(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_18)
);


endmodule