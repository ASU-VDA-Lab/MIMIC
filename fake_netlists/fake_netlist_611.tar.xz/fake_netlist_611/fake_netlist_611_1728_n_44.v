module fake_netlist_611_1728_n_44 (n_11, n_8, n_15, n_3, n_21, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_44);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_44;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_36;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_38;
wire n_43;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_12),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_14),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_10),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_19),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_17),
.B(n_15),
.Y(n_28)
);

AND3x2_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_8),
.C(n_9),
.Y(n_29)
);

NAND2x1p5_ASAP7_75t_L g30 ( 
.A(n_24),
.B(n_0),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_24),
.B(n_15),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_24),
.A2(n_18),
.B(n_17),
.C(n_16),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_27),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_22),
.Y(n_34)
);

AND2x4_ASAP7_75t_SL g35 ( 
.A(n_33),
.B(n_29),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_23),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_32),
.B1(n_26),
.B2(n_25),
.C(n_28),
.Y(n_37)
);

OAI321xp33_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_32),
.A3(n_29),
.B1(n_19),
.B2(n_18),
.C(n_16),
.Y(n_38)
);

AOI322xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_21),
.A3(n_20),
.B1(n_3),
.B2(n_4),
.C1(n_1),
.C2(n_2),
.Y(n_39)
);

AOI221x1_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_21),
.B1(n_11),
.B2(n_6),
.C(n_7),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_41),
.B1(n_42),
.B2(n_37),
.Y(n_44)
);


endmodule