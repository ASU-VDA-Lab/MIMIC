module fake_netlist_611_689_n_15 (n_1, n_2, n_3, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_0;

output n_15;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

AO21x2_ASAP7_75t_L g5 ( 
.A1(n_0),
.A2(n_1),
.B(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_SL g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_SL g7 ( 
.A(n_5),
.B(n_1),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OAI32xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_4),
.A3(n_6),
.B1(n_1),
.B2(n_0),
.Y(n_10)
);

OAI22xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_8),
.B(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_2),
.B1(n_3),
.B2(n_12),
.C1(n_6),
.C2(n_13),
.Y(n_15)
);


endmodule