module fake_netlist_611_1458_n_50 (n_11, n_8, n_15, n_3, n_21, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_50);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_50;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_11),
.Y(n_23)
);

BUFx8_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_2),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_0),
.B(n_7),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_6),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_22),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_26),
.A2(n_19),
.B(n_18),
.C(n_17),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_27),
.B(n_20),
.Y(n_33)
);

INVx5_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_23),
.C(n_30),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_23),
.B(n_29),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_34),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

OAI31xp33_ASAP7_75t_SL g40 ( 
.A1(n_38),
.A2(n_35),
.A3(n_33),
.B(n_25),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_25),
.B1(n_34),
.B2(n_39),
.C1(n_24),
.C2(n_28),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVxp67_ASAP7_75t_SL g43 ( 
.A(n_42),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_24),
.B1(n_34),
.B2(n_28),
.Y(n_44)
);

NOR3x1_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_21),
.C(n_20),
.Y(n_45)
);

NAND3xp33_ASAP7_75t_SL g46 ( 
.A(n_44),
.B(n_24),
.C(n_1),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_4),
.B(n_3),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_47),
.A2(n_9),
.B1(n_8),
.B2(n_5),
.Y(n_49)
);

AO221x1_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_48),
.B1(n_13),
.B2(n_10),
.C(n_12),
.Y(n_50)
);


endmodule