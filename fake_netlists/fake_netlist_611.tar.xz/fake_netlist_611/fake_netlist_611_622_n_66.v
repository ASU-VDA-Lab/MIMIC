module fake_netlist_611_622_n_66 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_66);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_66;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_58;
wire n_62;
wire n_52;
wire n_24;
wire n_51;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_65;
wire n_25;
wire n_63;
wire n_26;
wire n_60;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_64;

INVx3_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_1),
.B(n_4),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

OAI21x1_ASAP7_75t_L g26 ( 
.A1(n_11),
.A2(n_18),
.B(n_2),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_L g27 ( 
.A(n_17),
.B(n_10),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_5),
.B(n_3),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_20),
.B(n_0),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

BUFx8_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_L g33 ( 
.A(n_22),
.B(n_3),
.C(n_1),
.Y(n_33)
);

NOR4xp25_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_24),
.C(n_27),
.D(n_23),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

O2A1O1Ixp33_ASAP7_75t_L g36 ( 
.A1(n_30),
.A2(n_28),
.B(n_23),
.C(n_21),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVxp33_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AO21x2_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_26),
.B(n_21),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_33),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_26),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

AND2x4_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_39),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_38),
.Y(n_44)
);

OA21x2_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_25),
.B(n_28),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_40),
.B(n_36),
.Y(n_46)
);

INVxp67_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

O2A1O1Ixp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_41),
.B(n_39),
.C(n_25),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_43),
.B(n_31),
.Y(n_49)
);

OAI211xp5_ASAP7_75t_SL g50 ( 
.A1(n_43),
.A2(n_20),
.B(n_25),
.C(n_31),
.Y(n_50)
);

OAI21xp5_ASAP7_75t_L g51 ( 
.A1(n_43),
.A2(n_20),
.B(n_16),
.Y(n_51)
);

BUFx2_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

NOR4xp25_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_20),
.C(n_17),
.D(n_16),
.Y(n_53)
);

NAND4xp75_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_45),
.C(n_19),
.D(n_18),
.Y(n_54)
);

NOR2x1_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_45),
.Y(n_55)
);

NOR3x1_ASAP7_75t_L g56 ( 
.A(n_48),
.B(n_19),
.C(n_7),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_56),
.Y(n_57)
);

NOR2xp67_ASAP7_75t_L g58 ( 
.A(n_52),
.B(n_8),
.Y(n_58)
);

AND3x4_ASAP7_75t_L g59 ( 
.A(n_53),
.B(n_13),
.C(n_12),
.Y(n_59)
);

OR2x6_ASAP7_75t_L g60 ( 
.A(n_54),
.B(n_45),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_55),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_61),
.Y(n_62)
);

AOI22xp5_ASAP7_75t_L g63 ( 
.A1(n_59),
.A2(n_15),
.B1(n_45),
.B2(n_57),
.Y(n_63)
);

XNOR2x1_ASAP7_75t_L g64 ( 
.A(n_58),
.B(n_60),
.Y(n_64)
);

OAI21xp5_ASAP7_75t_L g65 ( 
.A1(n_63),
.A2(n_60),
.B(n_64),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_65),
.B(n_62),
.Y(n_66)
);


endmodule