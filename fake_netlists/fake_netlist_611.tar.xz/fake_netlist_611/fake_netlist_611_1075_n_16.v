module fake_netlist_611_1075_n_16 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_16);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_16;

wire n_11;
wire n_8;
wire n_15;
wire n_10;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

INVx2_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_6),
.Y(n_9)
);

AND2x2_ASAP7_75t_SL g10 ( 
.A(n_7),
.B(n_4),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B(n_8),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B1(n_6),
.B2(n_4),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_6),
.B(n_4),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_7),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_7),
.B(n_0),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_2),
.B1(n_3),
.B2(n_5),
.C1(n_11),
.C2(n_13),
.Y(n_16)
);


endmodule