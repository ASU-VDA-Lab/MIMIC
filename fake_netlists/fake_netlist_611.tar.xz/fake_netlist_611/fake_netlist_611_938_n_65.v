module fake_netlist_611_938_n_65 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_65);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_65;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_58;
wire n_62;
wire n_52;
wire n_24;
wire n_51;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_63;
wire n_26;
wire n_60;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_64;

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_9),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_8),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_7),
.A2(n_12),
.B1(n_0),
.B2(n_19),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

AOI22x1_ASAP7_75t_SL g27 ( 
.A1(n_19),
.A2(n_6),
.B1(n_2),
.B2(n_5),
.Y(n_27)
);

INVxp33_ASAP7_75t_SL g28 ( 
.A(n_16),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

OA21x2_ASAP7_75t_L g30 ( 
.A1(n_14),
.A2(n_20),
.B(n_18),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_16),
.B(n_2),
.C(n_0),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_24),
.B(n_17),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_24),
.B(n_18),
.Y(n_35)
);

AOI221x1_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_22),
.B1(n_24),
.B2(n_21),
.C(n_29),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

NAND3x1_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_25),
.C(n_27),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_33),
.Y(n_43)
);

NAND2x1_ASAP7_75t_SL g44 ( 
.A(n_41),
.B(n_25),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_40),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_32),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_22),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_38),
.B1(n_27),
.B2(n_29),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_29),
.B1(n_24),
.B2(n_30),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_45),
.Y(n_52)
);

NOR3xp33_ASAP7_75t_L g53 ( 
.A(n_46),
.B(n_32),
.C(n_30),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_46),
.B1(n_30),
.B2(n_26),
.Y(n_54)
);

NAND4xp25_ASAP7_75t_SL g55 ( 
.A(n_53),
.B(n_30),
.C(n_26),
.D(n_3),
.Y(n_55)
);

AOI21xp5_ASAP7_75t_L g56 ( 
.A1(n_51),
.A2(n_26),
.B(n_10),
.Y(n_56)
);

NOR3xp33_ASAP7_75t_L g57 ( 
.A(n_49),
.B(n_26),
.C(n_11),
.Y(n_57)
);

AOI221xp5_ASAP7_75t_L g58 ( 
.A1(n_52),
.A2(n_26),
.B1(n_50),
.B2(n_53),
.C(n_32),
.Y(n_58)
);

AND2x4_ASAP7_75t_L g59 ( 
.A(n_57),
.B(n_26),
.Y(n_59)
);

AND2x4_ASAP7_75t_L g60 ( 
.A(n_54),
.B(n_56),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_58),
.B(n_55),
.Y(n_61)
);

INVxp67_ASAP7_75t_SL g62 ( 
.A(n_60),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_61),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_62),
.Y(n_64)
);

AOI22xp33_ASAP7_75t_L g65 ( 
.A1(n_64),
.A2(n_59),
.B1(n_60),
.B2(n_63),
.Y(n_65)
);


endmodule