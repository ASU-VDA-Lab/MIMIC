module fake_netlist_611_1277_n_14 (n_1, n_2, n_3, n_0, n_14);

input n_1;
input n_2;
input n_3;
input n_0;

output n_14;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;

INVx3_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_2),
.Y(n_5)
);

BUFx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

NAND3xp33_ASAP7_75t_SL g9 ( 
.A(n_7),
.B(n_1),
.C(n_0),
.Y(n_9)
);

AOI211xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_4),
.B(n_3),
.C(n_2),
.Y(n_10)
);

AOI322xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_0),
.A3(n_1),
.B1(n_3),
.B2(n_4),
.C1(n_9),
.C2(n_6),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.C(n_4),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_0),
.B1(n_1),
.B2(n_4),
.C1(n_10),
.C2(n_9),
.Y(n_14)
);


endmodule