module fake_netlist_611_1285_n_17 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_17);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_17;

wire n_11;
wire n_8;
wire n_15;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_2),
.A2(n_0),
.B1(n_7),
.B2(n_4),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

OA21x2_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B(n_4),
.Y(n_11)
);

INVx4_ASAP7_75t_R g12 ( 
.A(n_11),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.C(n_6),
.Y(n_14)
);

XOR2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_1),
.Y(n_15)
);

XNOR2x1_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_9),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_3),
.Y(n_17)
);


endmodule