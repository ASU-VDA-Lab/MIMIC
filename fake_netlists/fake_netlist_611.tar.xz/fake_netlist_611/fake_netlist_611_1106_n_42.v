module fake_netlist_611_1106_n_42 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_42);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_42;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_36;
wire n_18;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_33;
wire n_41;

AND2x2_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_16),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_6),
.B(n_8),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

INVx4_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_22),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_26),
.A2(n_24),
.B1(n_19),
.B2(n_17),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_28),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_27),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

NOR2xp67_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_3),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_24),
.B1(n_21),
.B2(n_18),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_14),
.B1(n_5),
.B2(n_4),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_39),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_15),
.B1(n_13),
.B2(n_12),
.Y(n_42)
);


endmodule