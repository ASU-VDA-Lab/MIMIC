module fake_netlist_788_2732_n_62 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_62);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_62;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_20;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_17;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_18;
wire n_48;
wire n_43;
wire n_49;
wire n_15;
wire n_56;
wire n_16;
wire n_38;
wire n_54;
wire n_61;
wire n_60;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_19;
wire n_59;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;
wire n_14;

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_6),
.B(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_3),
.B(n_2),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

AND2x6_ASAP7_75t_L g22 ( 
.A(n_5),
.B(n_9),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_13),
.B(n_0),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

NAND2x1p5_ASAP7_75t_L g26 ( 
.A(n_17),
.B(n_1),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_17),
.B(n_2),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_SL g28 ( 
.A(n_20),
.B(n_4),
.C(n_3),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_14),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_14),
.B(n_4),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_23),
.B(n_7),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_15),
.B(n_18),
.Y(n_32)
);

AO21x2_ASAP7_75t_L g33 ( 
.A1(n_24),
.A2(n_15),
.B(n_16),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_22),
.Y(n_35)
);

O2A1O1Ixp33_ASAP7_75t_L g36 ( 
.A1(n_27),
.A2(n_21),
.B(n_19),
.C(n_22),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_31),
.A2(n_22),
.B(n_19),
.Y(n_37)
);

AND2x6_ASAP7_75t_L g38 ( 
.A(n_30),
.B(n_22),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_35),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_33),
.B(n_25),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_30),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_28),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_26),
.Y(n_44)
);

NOR2x1_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_36),
.Y(n_45)
);

AOI21xp33_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_36),
.B(n_40),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_42),
.Y(n_47)
);

AOI21xp33_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_42),
.B(n_33),
.Y(n_48)
);

INVx1_ASAP7_75t_SL g49 ( 
.A(n_47),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_26),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_42),
.B(n_26),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_25),
.Y(n_52)
);

AND2x4_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_38),
.Y(n_53)
);

NAND3x1_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_7),
.C(n_38),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_38),
.Y(n_55)
);

CKINVDCx5p33_ASAP7_75t_R g56 ( 
.A(n_51),
.Y(n_56)
);

HB1xp67_ASAP7_75t_L g57 ( 
.A(n_56),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

AOI21xp5_ASAP7_75t_L g59 ( 
.A1(n_55),
.A2(n_51),
.B(n_38),
.Y(n_59)
);

AOI21xp5_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_53),
.B(n_38),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_57),
.Y(n_61)
);

AOI22x1_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_53),
.B1(n_58),
.B2(n_60),
.Y(n_62)
);


endmodule