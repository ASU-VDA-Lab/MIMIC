module fake_netlist_788_189_n_16 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_16);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_16;

wire n_15;
wire n_11;
wire n_12;
wire n_8;
wire n_9;
wire n_10;
wire n_13;
wire n_14;

AO22x2_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_2),
.B1(n_7),
.B2(n_4),
.Y(n_8)
);

INVx4_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_4),
.Y(n_10)
);

OAI21x1_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_7),
.B(n_6),
.Y(n_11)
);

AND2x2_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

O2A1O1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_8),
.C(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_0),
.B1(n_3),
.B2(n_8),
.C1(n_9),
.C2(n_13),
.Y(n_16)
);


endmodule