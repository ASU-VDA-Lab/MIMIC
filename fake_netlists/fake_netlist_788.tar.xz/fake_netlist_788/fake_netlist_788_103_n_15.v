module fake_netlist_788_103_n_15 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_15);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_15;

wire n_7;
wire n_10;
wire n_11;
wire n_14;
wire n_9;
wire n_12;
wire n_13;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_9),
.B2(n_0),
.C(n_1),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B(n_3),
.Y(n_13)
);

AO21x2_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_5),
.B(n_2),
.Y(n_14)
);

OAI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_5),
.B1(n_6),
.B2(n_13),
.C(n_11),
.Y(n_15)
);


endmodule