module fake_netlist_788_1320_n_21 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_21);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_21;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_19;
wire n_14;

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

AND2x6_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_6),
.Y(n_13)
);

BUFx3_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.C(n_4),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B1(n_15),
.B2(n_12),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_14),
.B1(n_13),
.B2(n_5),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_13),
.B1(n_7),
.B2(n_11),
.C1(n_10),
.C2(n_9),
.Y(n_21)
);


endmodule