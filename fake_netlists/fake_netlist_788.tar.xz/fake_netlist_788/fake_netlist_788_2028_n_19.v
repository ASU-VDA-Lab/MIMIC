module fake_netlist_788_2028_n_19 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_19);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_19;

wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_10;
wire n_14;

AND2x2_ASAP7_75t_SL g10 ( 
.A(n_2),
.B(n_7),
.Y(n_10)
);

BUFx3_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

BUFx4f_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_SL g14 ( 
.A(n_10),
.B(n_12),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B1(n_13),
.B2(n_12),
.Y(n_15)
);

AOI211xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_16)
);

OAI221xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_11),
.B1(n_7),
.B2(n_5),
.C(n_0),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_1),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_9),
.B(n_3),
.Y(n_19)
);


endmodule