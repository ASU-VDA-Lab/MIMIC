module fake_netlist_788_2468_n_10 (n_1, n_2, n_0, n_10);

input n_1;
input n_2;
input n_0;

output n_10;

wire n_7;
wire n_5;
wire n_6;
wire n_3;
wire n_9;
wire n_4;
wire n_8;

BUFx6f_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

BUFx3_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

BUFx3_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

OAI31xp33_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_4),
.A3(n_3),
.B(n_0),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_6),
.B(n_3),
.Y(n_7)
);

OAI211xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_5),
.B(n_3),
.C(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_2),
.B(n_1),
.Y(n_10)
);


endmodule