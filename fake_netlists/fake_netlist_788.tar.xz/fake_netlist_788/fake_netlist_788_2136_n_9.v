module fake_netlist_788_2136_n_9 (n_1, n_0, n_9);

input n_1;
input n_0;

output n_9;

wire n_7;
wire n_5;
wire n_6;
wire n_3;
wire n_2;
wire n_4;
wire n_8;

INVxp33_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

AND2x2_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

AND2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_3),
.Y(n_6)
);

AOI221xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_3),
.Y(n_7)
);

AO21x2_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B(n_6),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);


endmodule