module fake_netlist_788_83_n_9 (n_1, n_2, n_3, n_0, n_9);

input n_1;
input n_2;
input n_3;
input n_0;

output n_9;

wire n_7;
wire n_5;
wire n_6;
wire n_4;
wire n_8;

O2A1O1Ixp33_ASAP7_75t_SL g4 ( 
.A1(n_1),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

OAI21xp33_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_4),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_4),
.B1(n_8),
.B2(n_5),
.Y(n_9)
);


endmodule