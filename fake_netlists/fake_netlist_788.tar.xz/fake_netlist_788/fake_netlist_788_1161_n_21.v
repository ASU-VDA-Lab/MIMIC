module fake_netlist_788_1161_n_21 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_21);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_21;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

INVx4_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

O2A1O1Ixp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_3),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_9),
.Y(n_14)
);

XNOR2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_10),
.Y(n_15)
);

INVxp67_ASAP7_75t_SL g16 ( 
.A(n_15),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_14),
.B(n_13),
.Y(n_17)
);

XOR2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_5),
.B1(n_4),
.B2(n_6),
.Y(n_21)
);


endmodule