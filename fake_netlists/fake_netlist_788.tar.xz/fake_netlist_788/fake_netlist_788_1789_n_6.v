module fake_netlist_788_1789_n_6 (n_0, n_6);

input n_0;

output n_6;

wire n_1;
wire n_5;
wire n_3;
wire n_2;
wire n_4;

BUFx5_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

INVxp67_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

OR2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B1(n_3),
.B2(n_4),
.Y(n_6)
);


endmodule