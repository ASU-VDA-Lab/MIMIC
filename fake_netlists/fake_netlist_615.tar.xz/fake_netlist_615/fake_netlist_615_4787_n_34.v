module fake_netlist_615_4787_n_34 (n_7, n_9, n_11, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_34);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_34;

wire n_31;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_SL g20 ( 
.A(n_14),
.B(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_22),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_23),
.B1(n_19),
.B2(n_17),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_26),
.B1(n_17),
.B2(n_20),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_7),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_SL g30 ( 
.A(n_29),
.B(n_7),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.C(n_4),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_8),
.Y(n_33)
);

AOI321xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.A3(n_13),
.B1(n_9),
.B2(n_15),
.C(n_12),
.Y(n_34)
);


endmodule