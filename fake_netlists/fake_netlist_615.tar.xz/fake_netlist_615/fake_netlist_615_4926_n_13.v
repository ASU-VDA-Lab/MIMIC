module fake_netlist_615_4926_n_13 (n_1, n_2, n_3, n_0, n_13);

input n_1;
input n_2;
input n_3;
input n_0;

output n_13;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_12;

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

OR2x6_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_3),
.Y(n_5)
);

O2A1O1Ixp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_6),
.Y(n_11)
);

OAI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_12)
);

OA21x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_3),
.B(n_6),
.Y(n_13)
);


endmodule