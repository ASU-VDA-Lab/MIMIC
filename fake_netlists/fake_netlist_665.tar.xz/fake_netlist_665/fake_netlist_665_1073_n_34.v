module fake_netlist_665_1073_n_34 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_34);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_34;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_6),
.B(n_1),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_R g24 ( 
.A(n_22),
.B(n_16),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_16),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_18),
.B1(n_23),
.B2(n_20),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

NOR4xp25_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_17),
.C(n_25),
.D(n_0),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_18),
.B(n_3),
.Y(n_29)
);

NAND3xp33_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_1),
.C(n_0),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_15),
.B(n_5),
.C(n_2),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_31),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.A3(n_10),
.B1(n_9),
.B2(n_8),
.C1(n_13),
.C2(n_12),
.Y(n_34)
);


endmodule