module fake_netlist_665_1636_n_33 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_33);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_33;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_12;
wire n_17;
wire n_14;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_32;
wire n_13;

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_3),
.B(n_4),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_5),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

INVx8_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_11),
.B(n_1),
.Y(n_18)
);

AOI21xp33_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_8),
.B(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_16),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_14),
.A2(n_7),
.B(n_6),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_13),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_20),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_16),
.Y(n_27)
);

AOI221x1_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_19),
.B1(n_14),
.B2(n_10),
.C(n_22),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

AOI322xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_27),
.A3(n_26),
.B1(n_15),
.B2(n_12),
.C1(n_23),
.C2(n_6),
.Y(n_30)
);

CKINVDCx16_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_18),
.B(n_28),
.C(n_21),
.Y(n_32)
);

AOI31xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_7),
.A3(n_32),
.B(n_20),
.Y(n_33)
);


endmodule