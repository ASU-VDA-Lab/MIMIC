module fake_netlist_665_1256_n_77 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_77);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_77;

wire n_62;
wire n_70;
wire n_58;
wire n_38;
wire n_57;
wire n_35;
wire n_45;
wire n_66;
wire n_23;
wire n_60;
wire n_22;
wire n_39;
wire n_63;
wire n_31;
wire n_37;
wire n_71;
wire n_40;
wire n_28;
wire n_49;
wire n_53;
wire n_75;
wire n_48;
wire n_41;
wire n_65;
wire n_33;
wire n_43;
wire n_61;
wire n_72;
wire n_51;
wire n_25;
wire n_54;
wire n_68;
wire n_20;
wire n_27;
wire n_21;
wire n_67;
wire n_29;
wire n_52;
wire n_50;
wire n_26;
wire n_76;
wire n_36;
wire n_59;
wire n_19;
wire n_34;
wire n_64;
wire n_44;
wire n_24;
wire n_30;
wire n_73;
wire n_56;
wire n_69;
wire n_46;
wire n_42;
wire n_55;
wire n_74;
wire n_32;
wire n_47;

INVx1_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_11),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_15),
.B(n_7),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_1),
.B(n_12),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_4),
.B(n_5),
.Y(n_31)
);

INVx5_ASAP7_75t_L g32 ( 
.A(n_9),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_22),
.B(n_1),
.Y(n_34)
);

NAND2xp33_ASAP7_75t_SL g35 ( 
.A(n_26),
.B(n_16),
.Y(n_35)
);

AND2x2_ASAP7_75t_SL g36 ( 
.A(n_30),
.B(n_17),
.Y(n_36)
);

INVx3_ASAP7_75t_L g37 ( 
.A(n_24),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_24),
.Y(n_38)
);

BUFx4f_ASAP7_75t_L g39 ( 
.A(n_30),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_21),
.B(n_17),
.Y(n_40)
);

NAND2x1p5_ASAP7_75t_L g41 ( 
.A(n_32),
.B(n_0),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_25),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_25),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_26),
.Y(n_44)
);

CKINVDCx8_ASAP7_75t_R g45 ( 
.A(n_44),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_37),
.B(n_19),
.Y(n_46)
);

CKINVDCx6p67_ASAP7_75t_R g47 ( 
.A(n_36),
.Y(n_47)
);

NOR3xp33_ASAP7_75t_SL g48 ( 
.A(n_35),
.B(n_31),
.C(n_23),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_33),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_39),
.B(n_20),
.Y(n_50)
);

INVx3_ASAP7_75t_L g51 ( 
.A(n_34),
.Y(n_51)
);

OAI22xp33_ASAP7_75t_L g52 ( 
.A1(n_44),
.A2(n_31),
.B1(n_27),
.B2(n_32),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_46),
.Y(n_56)
);

OAI21xp33_ASAP7_75t_L g57 ( 
.A1(n_50),
.A2(n_40),
.B(n_48),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_50),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_54),
.B(n_47),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_55),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_52),
.Y(n_61)
);

INVx3_ASAP7_75t_L g62 ( 
.A(n_53),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_59),
.Y(n_63)
);

AOI32xp33_ASAP7_75t_L g64 ( 
.A1(n_59),
.A2(n_57),
.A3(n_45),
.B1(n_37),
.B2(n_38),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_60),
.Y(n_65)
);

AOI22xp5_ASAP7_75t_L g66 ( 
.A1(n_61),
.A2(n_48),
.B1(n_39),
.B2(n_42),
.Y(n_66)
);

INVxp67_ASAP7_75t_L g67 ( 
.A(n_63),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_65),
.Y(n_68)
);

AOI322xp5_ASAP7_75t_L g69 ( 
.A1(n_66),
.A2(n_43),
.A3(n_64),
.B1(n_32),
.B2(n_62),
.C1(n_28),
.C2(n_29),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_65),
.Y(n_70)
);

NAND5xp2_ASAP7_75t_L g71 ( 
.A(n_69),
.B(n_41),
.C(n_32),
.D(n_29),
.E(n_13),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_68),
.Y(n_72)
);

NAND5xp2_ASAP7_75t_L g73 ( 
.A(n_67),
.B(n_14),
.C(n_29),
.D(n_62),
.E(n_68),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_70),
.Y(n_74)
);

AND2x2_ASAP7_75t_SL g75 ( 
.A(n_73),
.B(n_29),
.Y(n_75)
);

HB1xp67_ASAP7_75t_L g76 ( 
.A(n_72),
.Y(n_76)
);

AOI22xp33_ASAP7_75t_L g77 ( 
.A1(n_75),
.A2(n_71),
.B1(n_74),
.B2(n_76),
.Y(n_77)
);


endmodule