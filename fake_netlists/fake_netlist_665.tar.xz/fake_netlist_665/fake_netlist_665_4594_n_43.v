module fake_netlist_665_4594_n_43 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_43);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_43;

wire n_36;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

OAI22xp5_ASAP7_75t_SL g20 ( 
.A1(n_17),
.A2(n_19),
.B1(n_15),
.B2(n_18),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_5),
.B(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_13),
.B(n_8),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_19),
.A2(n_2),
.B1(n_14),
.B2(n_0),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_21),
.B(n_18),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_23),
.B(n_6),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_26),
.B(n_24),
.C(n_22),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_34),
.B1(n_20),
.B2(n_27),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_R g39 ( 
.A(n_37),
.B(n_7),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_30),
.B1(n_22),
.B2(n_10),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_39),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_R g43 ( 
.A1(n_42),
.A2(n_40),
.B1(n_16),
.B2(n_11),
.Y(n_43)
);


endmodule