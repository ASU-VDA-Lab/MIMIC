module fake_netlist_665_3043_n_53 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_53);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_53;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_11),
.B(n_14),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_10),
.Y(n_27)
);

BUFx12f_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_12),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_4),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_25),
.B(n_23),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_32),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_30),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_27),
.B(n_24),
.Y(n_37)
);

OAI22xp33_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_28),
.B1(n_26),
.B2(n_29),
.Y(n_38)
);

AO21x2_ASAP7_75t_L g39 ( 
.A1(n_33),
.A2(n_31),
.B(n_29),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_34),
.Y(n_40)
);

NAND2x1p5_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_34),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_39),
.Y(n_43)
);

AOI322xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_36),
.A3(n_35),
.B1(n_31),
.B2(n_39),
.C1(n_0),
.C2(n_1),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

AOI31xp33_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_7),
.A3(n_5),
.B(n_2),
.Y(n_47)
);

OAI322xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_13),
.A3(n_8),
.B1(n_17),
.B2(n_18),
.C1(n_15),
.C2(n_16),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

AOI22xp33_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_51),
.B1(n_22),
.B2(n_20),
.Y(n_53)
);


endmodule