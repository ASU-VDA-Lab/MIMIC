module fake_netlist_665_254_n_20 (n_3, n_1, n_2, n_0, n_20);

input n_3;
input n_1;
input n_2;
input n_0;

output n_20;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_16;
wire n_12;
wire n_4;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

AND2x6_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

OR2x6_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

A2O1A1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_5),
.A2(n_6),
.B(n_7),
.C(n_4),
.Y(n_10)
);

NOR4xp25_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_4),
.C(n_2),
.D(n_1),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_5),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

OAI22x1_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_4),
.B1(n_6),
.B2(n_11),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_4),
.B1(n_6),
.B2(n_12),
.C(n_15),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_4),
.B(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AO21x2_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_18),
.B(n_17),
.Y(n_20)
);


endmodule