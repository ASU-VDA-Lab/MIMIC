module fake_netlist_665_3710_n_27 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_27);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_27;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_26;
wire n_13;

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_8),
.Y(n_14)
);

INVx4_ASAP7_75t_SL g15 ( 
.A(n_3),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_0),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_7),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

INVx4_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

CKINVDCx11_ASAP7_75t_R g21 ( 
.A(n_18),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_21),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_16),
.B(n_13),
.Y(n_24)
);

NOR2xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_2),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_17),
.B1(n_15),
.B2(n_4),
.Y(n_26)
);

AOI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_15),
.B1(n_9),
.B2(n_5),
.C1(n_10),
.C2(n_6),
.Y(n_27)
);


endmodule