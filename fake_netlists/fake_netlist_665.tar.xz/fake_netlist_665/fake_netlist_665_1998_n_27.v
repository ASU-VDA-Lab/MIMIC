module fake_netlist_665_1998_n_27 (n_4, n_1, n_2, n_0, n_3, n_27);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_27;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_25;
wire n_24;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_26;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx2_ASAP7_75t_SL g5 ( 
.A(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_2),
.B(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_5),
.A2(n_2),
.B(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_7),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_12),
.Y(n_18)
);

OAI221xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_6),
.B1(n_14),
.B2(n_9),
.C(n_5),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_6),
.B1(n_7),
.B2(n_8),
.C(n_1),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_10),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_SL g22 ( 
.A(n_20),
.B(n_8),
.C(n_2),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AND4x1_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_4),
.C(n_3),
.D(n_8),
.Y(n_24)
);

AO22x2_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_3),
.B1(n_4),
.B2(n_23),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_3),
.B1(n_4),
.B2(n_24),
.Y(n_26)
);

OAI22x1_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_3),
.B1(n_24),
.B2(n_26),
.Y(n_27)
);


endmodule