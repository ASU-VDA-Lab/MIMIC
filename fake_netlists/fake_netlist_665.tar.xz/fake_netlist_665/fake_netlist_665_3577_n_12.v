module fake_netlist_665_3577_n_12 (n_3, n_1, n_2, n_0, n_12);

input n_3;
input n_1;
input n_2;
input n_0;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_11;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AND2x2_ASAP7_75t_SL g6 ( 
.A(n_5),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

OAI211xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B(n_4),
.C(n_5),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_6),
.C(n_0),
.Y(n_10)
);

OAI332xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_3),
.B3(n_5),
.C1(n_4),
.C2(n_7),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_12)
);


endmodule