module fake_netlist_665_4472_n_5 (n_1, n_0, n_5);

input n_1;
input n_0;

output n_5;

wire n_4;
wire n_2;
wire n_3;

CKINVDCx5p33_ASAP7_75t_R g2 ( 
.A(n_0),
.Y(n_2)
);

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

AOI31xp33_ASAP7_75t_SL g4 ( 
.A1(n_3),
.A2(n_0),
.A3(n_1),
.B(n_2),
.Y(n_4)
);

OA22x2_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.Y(n_5)
);


endmodule