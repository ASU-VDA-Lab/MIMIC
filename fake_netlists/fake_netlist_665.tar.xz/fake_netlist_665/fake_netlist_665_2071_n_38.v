module fake_netlist_665_2071_n_38 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_38);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_38;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

XNOR2xp5_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_7),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_1),
.B(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_4),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_4),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_26),
.B1(n_25),
.B2(n_17),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_24),
.B(n_17),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_26),
.B1(n_25),
.B2(n_22),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_28),
.B1(n_19),
.B2(n_23),
.Y(n_33)
);

AOI211xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_23),
.B(n_21),
.C(n_6),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

NAND2x1p5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_16),
.Y(n_36)
);

OR3x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_3),
.C(n_0),
.Y(n_37)
);

AOI322xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_36),
.A3(n_12),
.B1(n_10),
.B2(n_8),
.C1(n_14),
.C2(n_13),
.Y(n_38)
);


endmodule