module fake_netlist_665_592_n_56 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_56);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_56;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_11),
.B(n_9),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_12),
.B(n_22),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_5),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_17),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_14),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_2),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_10),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_20),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_30),
.B(n_23),
.Y(n_34)
);

OAI21xp33_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_1),
.B(n_0),
.Y(n_35)
);

OR2x6_ASAP7_75t_L g36 ( 
.A(n_29),
.B(n_3),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_26),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_42),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_40),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_35),
.B(n_25),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

A2O1A1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_43),
.B(n_24),
.C(n_32),
.Y(n_47)
);

OAI31xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_27),
.A3(n_31),
.B(n_28),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

NAND4xp25_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_7),
.C(n_6),
.D(n_4),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

NAND4xp75_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_16),
.C(n_13),
.D(n_8),
.Y(n_52)
);

OAI21x1_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_19),
.B(n_18),
.Y(n_53)
);

AOI21xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_52),
.B(n_21),
.Y(n_54)
);

HB1xp67_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

XNOR2xp5_ASAP7_75t_L g56 ( 
.A(n_55),
.B(n_54),
.Y(n_56)
);


endmodule