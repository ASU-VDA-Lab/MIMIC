module fake_netlist_665_4087_n_24 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_24);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_24;

wire n_18;
wire n_19;
wire n_10;
wire n_15;
wire n_11;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;

CKINVDCx20_ASAP7_75t_R g8 ( 
.A(n_0),
.Y(n_8)
);

OR2x6_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_5),
.Y(n_9)
);

INVxp67_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

BUFx3_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_3),
.B(n_1),
.Y(n_14)
);

NOR2xp67_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_2),
.Y(n_15)
);

NAND2x1p5_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_13),
.Y(n_16)
);

AO31x2_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_5),
.A3(n_4),
.B(n_2),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_11),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_15),
.B1(n_9),
.B2(n_11),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_8),
.B1(n_13),
.B2(n_17),
.C(n_9),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_9),
.B2(n_13),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_9),
.B1(n_14),
.B2(n_17),
.Y(n_24)
);


endmodule