module fake_netlist_665_2811_n_36 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_36);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_36;

wire n_18;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_13),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_R g19 ( 
.A(n_8),
.B(n_11),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_5),
.B(n_4),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_0),
.Y(n_26)
);

A2O1A1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_21),
.A2(n_9),
.B(n_3),
.C(n_1),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_15),
.B1(n_12),
.B2(n_10),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_18),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AOI211xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_30),
.B(n_28),
.C(n_20),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_24),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_25),
.B1(n_19),
.B2(n_16),
.Y(n_36)
);


endmodule