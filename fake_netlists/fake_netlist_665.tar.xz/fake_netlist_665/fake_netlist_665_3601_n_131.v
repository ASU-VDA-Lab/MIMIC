module fake_netlist_665_3601_n_131 (n_18, n_36, n_19, n_34, n_1, n_38, n_0, n_5, n_10, n_25, n_24, n_35, n_28, n_11, n_15, n_7, n_30, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_39, n_14, n_21, n_27, n_2, n_29, n_31, n_26, n_33, n_9, n_32, n_37, n_13, n_8, n_6, n_131);

input n_18;
input n_36;
input n_19;
input n_34;
input n_1;
input n_38;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_35;
input n_28;
input n_11;
input n_15;
input n_7;
input n_30;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_39;
input n_14;
input n_21;
input n_27;
input n_2;
input n_29;
input n_31;
input n_26;
input n_33;
input n_9;
input n_32;
input n_37;
input n_13;
input n_8;
input n_6;

output n_131;

wire n_99;
wire n_62;
wire n_70;
wire n_90;
wire n_101;
wire n_58;
wire n_57;
wire n_84;
wire n_89;
wire n_116;
wire n_96;
wire n_45;
wire n_107;
wire n_78;
wire n_66;
wire n_118;
wire n_60;
wire n_63;
wire n_81;
wire n_124;
wire n_71;
wire n_91;
wire n_121;
wire n_105;
wire n_92;
wire n_125;
wire n_117;
wire n_40;
wire n_110;
wire n_49;
wire n_53;
wire n_77;
wire n_75;
wire n_48;
wire n_93;
wire n_41;
wire n_65;
wire n_109;
wire n_122;
wire n_119;
wire n_43;
wire n_82;
wire n_120;
wire n_85;
wire n_61;
wire n_72;
wire n_51;
wire n_54;
wire n_86;
wire n_68;
wire n_130;
wire n_67;
wire n_112;
wire n_52;
wire n_50;
wire n_113;
wire n_103;
wire n_104;
wire n_127;
wire n_100;
wire n_129;
wire n_76;
wire n_83;
wire n_106;
wire n_59;
wire n_97;
wire n_64;
wire n_44;
wire n_123;
wire n_87;
wire n_115;
wire n_79;
wire n_128;
wire n_108;
wire n_126;
wire n_73;
wire n_56;
wire n_98;
wire n_69;
wire n_94;
wire n_46;
wire n_42;
wire n_55;
wire n_102;
wire n_95;
wire n_74;
wire n_47;
wire n_80;
wire n_88;
wire n_114;
wire n_111;

INVx1_ASAP7_75t_L g40 ( 
.A(n_20),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_15),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_6),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

BUFx5_ASAP7_75t_L g44 ( 
.A(n_22),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_7),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_18),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_39),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_4),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_11),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_23),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_29),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_14),
.Y(n_52)
);

BUFx10_ASAP7_75t_L g53 ( 
.A(n_19),
.Y(n_53)
);

BUFx6f_ASAP7_75t_L g54 ( 
.A(n_5),
.Y(n_54)
);

BUFx5_ASAP7_75t_L g55 ( 
.A(n_17),
.Y(n_55)
);

INVx3_ASAP7_75t_L g56 ( 
.A(n_21),
.Y(n_56)
);

BUFx6f_ASAP7_75t_L g57 ( 
.A(n_13),
.Y(n_57)
);

INVx2_ASAP7_75t_SL g58 ( 
.A(n_1),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_42),
.Y(n_59)
);

INVx5_ASAP7_75t_L g60 ( 
.A(n_56),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_44),
.Y(n_62)
);

INVx3_ASAP7_75t_L g63 ( 
.A(n_53),
.Y(n_63)
);

OA21x2_ASAP7_75t_L g64 ( 
.A1(n_40),
.A2(n_3),
.B(n_2),
.Y(n_64)
);

AND2x4_ASAP7_75t_L g65 ( 
.A(n_59),
.B(n_41),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_62),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_61),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_60),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_60),
.Y(n_69)
);

NAND2xp5_ASAP7_75t_L g70 ( 
.A(n_65),
.B(n_63),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_67),
.Y(n_71)
);

BUFx5_ASAP7_75t_L g72 ( 
.A(n_68),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_69),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_66),
.Y(n_74)
);

INVx2_ASAP7_75t_L g75 ( 
.A(n_73),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_74),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_70),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_72),
.Y(n_78)
);

AOI22xp5_ASAP7_75t_L g79 ( 
.A1(n_71),
.A2(n_46),
.B1(n_45),
.B2(n_43),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_77),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_75),
.B(n_49),
.Y(n_81)
);

INVx2_ASAP7_75t_L g82 ( 
.A(n_76),
.Y(n_82)
);

AOI21xp5_ASAP7_75t_L g83 ( 
.A1(n_78),
.A2(n_64),
.B(n_51),
.Y(n_83)
);

NAND3xp33_ASAP7_75t_SL g84 ( 
.A(n_79),
.B(n_52),
.C(n_50),
.Y(n_84)
);

INVx2_ASAP7_75t_L g85 ( 
.A(n_75),
.Y(n_85)
);

OAI21x1_ASAP7_75t_L g86 ( 
.A1(n_83),
.A2(n_48),
.B(n_47),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_80),
.Y(n_87)
);

INVx2_ASAP7_75t_L g88 ( 
.A(n_85),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_81),
.Y(n_89)
);

INVx2_ASAP7_75t_SL g90 ( 
.A(n_84),
.Y(n_90)
);

INVx2_ASAP7_75t_L g91 ( 
.A(n_82),
.Y(n_91)
);

INVx2_ASAP7_75t_L g92 ( 
.A(n_91),
.Y(n_92)
);

INVx2_ASAP7_75t_L g93 ( 
.A(n_88),
.Y(n_93)
);

AOI22xp33_ASAP7_75t_L g94 ( 
.A1(n_90),
.A2(n_55),
.B1(n_57),
.B2(n_54),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_89),
.Y(n_95)
);

INVx1_ASAP7_75t_L g96 ( 
.A(n_86),
.Y(n_96)
);

INVx1_ASAP7_75t_L g97 ( 
.A(n_87),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_95),
.B(n_0),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_97),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_93),
.Y(n_100)
);

AO31x2_ASAP7_75t_L g101 ( 
.A1(n_96),
.A2(n_10),
.A3(n_9),
.B(n_8),
.Y(n_101)
);

AND2x2_ASAP7_75t_L g102 ( 
.A(n_94),
.B(n_12),
.Y(n_102)
);

INVx2_ASAP7_75t_L g103 ( 
.A(n_92),
.Y(n_103)
);

NAND2xp5_ASAP7_75t_L g104 ( 
.A(n_99),
.B(n_16),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_100),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_103),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_101),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_98),
.Y(n_108)
);

AND2x2_ASAP7_75t_L g109 ( 
.A(n_105),
.B(n_102),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_106),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_108),
.Y(n_111)
);

NAND2xp5_ASAP7_75t_L g112 ( 
.A(n_111),
.B(n_107),
.Y(n_112)
);

INVx2_ASAP7_75t_L g113 ( 
.A(n_110),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_113),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_112),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_115),
.Y(n_116)
);

NAND2xp5_ASAP7_75t_L g117 ( 
.A(n_116),
.B(n_114),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_117),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_118),
.Y(n_119)
);

AND2x2_ASAP7_75t_L g120 ( 
.A(n_119),
.B(n_109),
.Y(n_120)
);

INVx2_ASAP7_75t_L g121 ( 
.A(n_120),
.Y(n_121)
);

AND2x2_ASAP7_75t_L g122 ( 
.A(n_121),
.B(n_104),
.Y(n_122)
);

HB1xp67_ASAP7_75t_L g123 ( 
.A(n_122),
.Y(n_123)
);

INVx1_ASAP7_75t_L g124 ( 
.A(n_123),
.Y(n_124)
);

HB1xp67_ASAP7_75t_L g125 ( 
.A(n_124),
.Y(n_125)
);

INVx1_ASAP7_75t_L g126 ( 
.A(n_125),
.Y(n_126)
);

OAI22xp5_ASAP7_75t_L g127 ( 
.A1(n_126),
.A2(n_26),
.B1(n_25),
.B2(n_24),
.Y(n_127)
);

AOI21xp33_ASAP7_75t_SL g128 ( 
.A1(n_127),
.A2(n_28),
.B(n_27),
.Y(n_128)
);

OAI221xp5_ASAP7_75t_R g129 ( 
.A1(n_128),
.A2(n_31),
.B1(n_30),
.B2(n_32),
.C(n_33),
.Y(n_129)
);

OR2x6_ASAP7_75t_L g130 ( 
.A(n_129),
.B(n_34),
.Y(n_130)
);

AOI22xp33_ASAP7_75t_L g131 ( 
.A1(n_130),
.A2(n_37),
.B1(n_36),
.B2(n_35),
.Y(n_131)
);


endmodule