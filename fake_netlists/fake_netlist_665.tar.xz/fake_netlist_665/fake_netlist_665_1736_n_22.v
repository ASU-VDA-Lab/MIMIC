module fake_netlist_665_1736_n_22 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_22);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_22;

wire n_18;
wire n_19;
wire n_10;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.Y(n_12)
);

OAI21x1_ASAP7_75t_SL g13 ( 
.A1(n_7),
.A2(n_4),
.B(n_1),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_4),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_11),
.B1(n_10),
.B2(n_5),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_11),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_13),
.Y(n_19)
);

NAND4xp75_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.C(n_13),
.D(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NOR2x1_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_6),
.Y(n_22)
);


endmodule