module fake_netlist_604_1948_n_53 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_25, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_53);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_25;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_53;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_27;
wire n_28;
wire n_52;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_51;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

INVx2_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_7),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_10),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_5),
.Y(n_30)
);

NOR2xp67_ASAP7_75t_L g31 ( 
.A(n_1),
.B(n_14),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_16),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_SL g35 ( 
.A(n_33),
.B(n_25),
.C(n_0),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_30),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_26),
.B(n_2),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_34),
.B1(n_29),
.B2(n_28),
.Y(n_39)
);

INVx4_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

NAND2x1p5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_38),
.Y(n_42)
);

AND2x4_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_35),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI221x1_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_27),
.B1(n_31),
.B2(n_3),
.C(n_4),
.Y(n_45)
);

XOR2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_6),
.Y(n_46)
);

OAI322xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_27),
.A3(n_11),
.B1(n_9),
.B2(n_8),
.C1(n_13),
.C2(n_12),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

NOR2xp67_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_17),
.Y(n_49)
);

NOR4xp25_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_20),
.C(n_19),
.D(n_18),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_50),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_SL g53 ( 
.A1(n_51),
.A2(n_21),
.B1(n_23),
.B2(n_52),
.Y(n_53)
);


endmodule