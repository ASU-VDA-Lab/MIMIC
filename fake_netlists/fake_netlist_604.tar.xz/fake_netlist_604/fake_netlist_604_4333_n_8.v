module fake_netlist_604_4333_n_8 (n_1, n_2, n_0, n_8);

input n_1;
input n_2;
input n_0;

output n_8;

wire n_7;
wire n_5;
wire n_6;
wire n_4;
wire n_3;

AND2x4_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

INVx3_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_3),
.Y(n_6)
);

XOR2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_2),
.B(n_6),
.Y(n_8)
);


endmodule