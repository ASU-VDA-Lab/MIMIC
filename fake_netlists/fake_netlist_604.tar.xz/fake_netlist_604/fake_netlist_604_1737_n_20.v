module fake_netlist_604_1737_n_20 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_20);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_20;

wire n_11;
wire n_15;
wire n_18;
wire n_17;
wire n_19;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

INVx2_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_3),
.A2(n_9),
.B1(n_5),
.B2(n_1),
.Y(n_11)
);

OAI22xp33_ASAP7_75t_SL g12 ( 
.A1(n_4),
.A2(n_6),
.B1(n_1),
.B2(n_5),
.Y(n_12)
);

AND2x2_ASAP7_75t_SL g13 ( 
.A(n_0),
.B(n_2),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_0),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_12),
.Y(n_16)
);

NOR4xp25_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.C(n_6),
.D(n_4),
.Y(n_17)
);

NOR4xp25_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_11),
.C(n_7),
.D(n_8),
.Y(n_18)
);

XNOR2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_7),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_13),
.Y(n_20)
);


endmodule