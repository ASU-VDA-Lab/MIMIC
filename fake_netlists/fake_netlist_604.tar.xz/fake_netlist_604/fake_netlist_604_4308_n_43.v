module fake_netlist_604_4308_n_43 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_43);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_43;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;

AND3x2_ASAP7_75t_L g20 ( 
.A(n_9),
.B(n_10),
.C(n_14),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_12),
.B(n_19),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_0),
.B(n_7),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

INVxp33_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_6),
.B(n_13),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_1),
.B(n_19),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_17),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_3),
.C(n_2),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_8),
.B(n_5),
.Y(n_30)
);

AND2x6_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_20),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_27),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_26),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_32),
.B1(n_30),
.B2(n_31),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_34),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_21),
.B1(n_22),
.B2(n_18),
.C(n_15),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_37),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_38),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_16),
.B1(n_18),
.B2(n_41),
.Y(n_43)
);


endmodule