module fake_netlist_604_4197_n_19 (n_7, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_19);

input n_7;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_19;

wire n_11;
wire n_15;
wire n_18;
wire n_17;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_8),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_3),
.B(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_5),
.B(n_4),
.C(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_10),
.B1(n_7),
.B2(n_6),
.Y(n_19)
);


endmodule