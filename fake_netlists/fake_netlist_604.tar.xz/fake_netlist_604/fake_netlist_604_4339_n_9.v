module fake_netlist_604_4339_n_9 (n_1, n_2, n_3, n_0, n_9);

input n_1;
input n_2;
input n_3;
input n_0;

output n_9;

wire n_7;
wire n_8;
wire n_5;
wire n_6;
wire n_4;

INVx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_6),
.B1(n_2),
.B2(n_0),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_3),
.B(n_0),
.Y(n_9)
);


endmodule