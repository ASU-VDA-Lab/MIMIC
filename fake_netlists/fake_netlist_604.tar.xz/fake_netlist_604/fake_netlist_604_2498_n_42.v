module fake_netlist_604_2498_n_42 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_42);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_42;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_36;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_33;
wire n_41;
wire n_34;

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

AND2x6_ASAP7_75t_L g20 ( 
.A(n_3),
.B(n_17),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_8),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_12),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_10),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_17),
.B(n_11),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_19),
.A2(n_16),
.B1(n_5),
.B2(n_1),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_21),
.B(n_1),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_26),
.B1(n_24),
.B2(n_23),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_29),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_25),
.B1(n_20),
.B2(n_5),
.C(n_16),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_32),
.B1(n_20),
.B2(n_18),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_20),
.B1(n_18),
.B2(n_2),
.Y(n_37)
);

CKINVDCx16_ASAP7_75t_R g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_20),
.Y(n_40)
);

OAI22x1_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_9),
.B1(n_6),
.B2(n_4),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_13),
.B1(n_14),
.B2(n_41),
.Y(n_42)
);


endmodule