module fake_netlist_604_529_n_69 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_69);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_69;

wire n_31;
wire n_37;
wire n_39;
wire n_54;
wire n_53;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_18;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_58;
wire n_62;
wire n_67;
wire n_52;
wire n_24;
wire n_51;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_65;
wire n_25;
wire n_63;
wire n_26;
wire n_60;
wire n_19;
wire n_46;
wire n_38;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_66;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_64;
wire n_68;

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_7),
.B(n_1),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_6),
.B(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_14),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_R g23 ( 
.A(n_4),
.B(n_2),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_4),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_11),
.B(n_1),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_8),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_3),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_17),
.B(n_5),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_0),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_9),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_10),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_18),
.B(n_13),
.Y(n_35)
);

INVx5_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_18),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_27),
.Y(n_38)
);

AO31x2_ASAP7_75t_L g39 ( 
.A1(n_29),
.A2(n_23),
.A3(n_20),
.B(n_19),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_30),
.A2(n_22),
.B1(n_25),
.B2(n_15),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_32),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_32),
.Y(n_42)
);

BUFx3_ASAP7_75t_L g43 ( 
.A(n_34),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_37),
.A2(n_35),
.B1(n_33),
.B2(n_34),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_33),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_44),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

OAI31xp33_ASAP7_75t_L g48 ( 
.A1(n_40),
.A2(n_35),
.A3(n_31),
.B(n_32),
.Y(n_48)
);

BUFx2_ASAP7_75t_L g49 ( 
.A(n_39),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_R g50 ( 
.A(n_46),
.B(n_38),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_45),
.B(n_39),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

OAI31xp33_ASAP7_75t_SL g53 ( 
.A1(n_48),
.A2(n_42),
.A3(n_39),
.B(n_36),
.Y(n_53)
);

INVx2_ASAP7_75t_SL g54 ( 
.A(n_50),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_50),
.Y(n_57)
);

BUFx12f_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

NOR2xp33_ASAP7_75t_L g59 ( 
.A(n_57),
.B(n_49),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_54),
.B(n_48),
.Y(n_60)
);

HB1xp67_ASAP7_75t_L g61 ( 
.A(n_55),
.Y(n_61)
);

NOR2x1_ASAP7_75t_L g62 ( 
.A(n_55),
.B(n_38),
.Y(n_62)
);

BUFx2_ASAP7_75t_L g63 ( 
.A(n_58),
.Y(n_63)
);

OAI211xp5_ASAP7_75t_SL g64 ( 
.A1(n_60),
.A2(n_53),
.B(n_56),
.C(n_36),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_61),
.Y(n_65)
);

INVx2_ASAP7_75t_SL g66 ( 
.A(n_62),
.Y(n_66)
);

AOI22xp33_ASAP7_75t_SL g67 ( 
.A1(n_66),
.A2(n_36),
.B1(n_59),
.B2(n_63),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_64),
.B(n_65),
.Y(n_68)
);

OAI21xp5_ASAP7_75t_L g69 ( 
.A1(n_67),
.A2(n_64),
.B(n_68),
.Y(n_69)
);


endmodule