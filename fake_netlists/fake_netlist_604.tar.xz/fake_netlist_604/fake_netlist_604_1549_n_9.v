module fake_netlist_604_1549_n_9 (n_0, n_4, n_1, n_2, n_3, n_9);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_9;

wire n_7;
wire n_8;
wire n_5;
wire n_6;

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_3),
.B(n_4),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_2),
.B(n_4),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_SL g8 ( 
.A1(n_7),
.A2(n_6),
.B(n_0),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_1),
.Y(n_9)
);


endmodule