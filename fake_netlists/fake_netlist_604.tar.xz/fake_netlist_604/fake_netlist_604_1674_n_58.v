module fake_netlist_604_1674_n_58 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_58);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_58;

wire n_31;
wire n_15;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_50;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_42;
wire n_33;
wire n_14;
wire n_41;
wire n_55;
wire n_13;

INVx1_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_R g14 ( 
.A(n_10),
.B(n_1),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_9),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_4),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

BUFx12f_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

O2A1O1Ixp5_ASAP7_75t_L g25 ( 
.A1(n_17),
.A2(n_12),
.B(n_1),
.C(n_0),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_17),
.A2(n_2),
.B(n_0),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_17),
.A2(n_4),
.B(n_3),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_16),
.B(n_5),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_16),
.B(n_6),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_14),
.Y(n_31)
);

BUFx4f_ASAP7_75t_L g32 ( 
.A(n_13),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

AND2x4_ASAP7_75t_SL g37 ( 
.A(n_24),
.B(n_19),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_13),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_31),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_32),
.Y(n_40)
);

NOR2x1_ASAP7_75t_L g41 ( 
.A(n_34),
.B(n_29),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_33),
.Y(n_42)
);

OAI321xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_33),
.A3(n_27),
.B1(n_26),
.B2(n_15),
.C(n_35),
.Y(n_43)
);

INVxp67_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_39),
.B(n_31),
.Y(n_45)
);

OAI322xp33_ASAP7_75t_L g46 ( 
.A1(n_39),
.A2(n_14),
.A3(n_22),
.B1(n_20),
.B2(n_23),
.C1(n_21),
.C2(n_15),
.Y(n_46)
);

NAND2xp33_ASAP7_75t_SL g47 ( 
.A(n_45),
.B(n_40),
.Y(n_47)
);

OAI322xp33_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_36),
.A3(n_35),
.B1(n_41),
.B2(n_37),
.C1(n_25),
.C2(n_11),
.Y(n_48)
);

AOI21xp5_ASAP7_75t_L g49 ( 
.A1(n_43),
.A2(n_37),
.B(n_46),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

BUFx6f_ASAP7_75t_L g51 ( 
.A(n_50),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_49),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_47),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_48),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_53),
.B(n_51),
.Y(n_55)
);

OAI22xp33_ASAP7_75t_SL g56 ( 
.A1(n_53),
.A2(n_54),
.B1(n_49),
.B2(n_50),
.Y(n_56)
);

INVxp67_ASAP7_75t_SL g57 ( 
.A(n_51),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_51),
.B1(n_57),
.B2(n_55),
.Y(n_58)
);


endmodule