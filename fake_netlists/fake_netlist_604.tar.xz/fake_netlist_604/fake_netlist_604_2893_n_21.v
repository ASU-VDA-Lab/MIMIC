module fake_netlist_604_2893_n_21 (n_1, n_2, n_3, n_0, n_21);

input n_1;
input n_2;
input n_3;
input n_0;

output n_21;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_4;
wire n_7;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_5;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

INVx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_2),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_0),
.Y(n_8)
);

AO21x2_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OA21x2_ASAP7_75t_L g10 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_5),
.Y(n_12)
);

AO21x2_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_7),
.B(n_6),
.Y(n_13)
);

OAI22xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_10),
.B1(n_9),
.B2(n_1),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_10),
.B(n_9),
.C(n_1),
.Y(n_15)
);

NOR2x1_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_11),
.Y(n_16)
);

OAI311xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_9),
.A3(n_10),
.B1(n_2),
.C1(n_3),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_13),
.C(n_10),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_SL g19 ( 
.A1(n_16),
.A2(n_3),
.B(n_2),
.C(n_13),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_10),
.B1(n_13),
.B2(n_18),
.C1(n_20),
.C2(n_11),
.Y(n_21)
);


endmodule