module fake_netlist_604_1374_n_54 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_54);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_54;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_27;
wire n_28;
wire n_52;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_51;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_19),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_10),
.Y(n_29)
);

OAI21x1_ASAP7_75t_L g30 ( 
.A1(n_23),
.A2(n_18),
.B(n_14),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_21),
.B(n_8),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_15),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_26),
.B(n_16),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_32),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_25),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_32),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

A2O1A1Ixp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_35),
.B(n_30),
.C(n_36),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_35),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_39),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_28),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_38),
.B1(n_27),
.B2(n_25),
.Y(n_45)
);

OAI211xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_27),
.B(n_25),
.C(n_29),
.Y(n_46)
);

AOI211xp5_ASAP7_75t_SL g47 ( 
.A1(n_46),
.A2(n_24),
.B(n_27),
.C(n_29),
.Y(n_47)
);

OAI22x1_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_34),
.B1(n_33),
.B2(n_29),
.Y(n_48)
);

OAI221xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_34),
.B1(n_33),
.B2(n_0),
.C(n_1),
.Y(n_49)
);

NOR3xp33_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_34),
.C(n_33),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_52),
.B(n_5),
.Y(n_53)
);

AOI322xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_51),
.A3(n_11),
.B1(n_9),
.B2(n_7),
.C1(n_13),
.C2(n_12),
.Y(n_54)
);


endmodule