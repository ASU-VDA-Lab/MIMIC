module fake_netlist_604_1420_n_17 (n_1, n_2, n_0, n_17);

input n_1;
input n_2;
input n_0;

output n_17;

wire n_7;
wire n_11;
wire n_9;
wire n_16;
wire n_8;
wire n_5;
wire n_15;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;
wire n_3;

INVx1_ASAP7_75t_SL g3 ( 
.A(n_2),
.Y(n_3)
);

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

INVx4_ASAP7_75t_SL g7 ( 
.A(n_4),
.Y(n_7)
);

NAND2xp33_ASAP7_75t_L g8 ( 
.A(n_4),
.B(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_5),
.Y(n_10)
);

INVxp67_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

OA22x2_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_3),
.B1(n_1),
.B2(n_6),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_1),
.B1(n_5),
.B2(n_8),
.C1(n_9),
.C2(n_16),
.Y(n_17)
);


endmodule