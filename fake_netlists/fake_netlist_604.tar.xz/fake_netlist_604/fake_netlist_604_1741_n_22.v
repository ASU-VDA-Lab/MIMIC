module fake_netlist_604_1741_n_22 (n_7, n_9, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_22);

input n_7;
input n_9;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_22;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_17;
wire n_19;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_4),
.B(n_8),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_3),
.Y(n_12)
);

INVxp33_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

AOI21x1_ASAP7_75t_L g14 ( 
.A1(n_6),
.A2(n_1),
.B(n_7),
.Y(n_14)
);

NAND3x1_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_6),
.C(n_4),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AND4x1_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_15),
.C(n_7),
.D(n_11),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_11),
.B1(n_12),
.B2(n_2),
.Y(n_21)
);

AO21x2_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_10),
.B(n_9),
.Y(n_22)
);


endmodule