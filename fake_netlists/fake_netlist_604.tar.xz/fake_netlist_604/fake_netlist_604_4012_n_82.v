module fake_netlist_604_4012_n_82 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_27, n_28, n_17, n_4, n_1, n_24, n_7, n_25, n_26, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_82);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_27;
input n_28;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_25;
input n_26;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_82;

wire n_75;
wire n_37;
wire n_54;
wire n_44;
wire n_36;
wire n_65;
wire n_63;
wire n_47;
wire n_57;
wire n_55;
wire n_76;
wire n_64;
wire n_68;
wire n_81;
wire n_53;
wire n_39;
wire n_77;
wire n_29;
wire n_35;
wire n_80;
wire n_69;
wire n_78;
wire n_71;
wire n_42;
wire n_59;
wire n_50;
wire n_58;
wire n_52;
wire n_49;
wire n_51;
wire n_45;
wire n_73;
wire n_56;
wire n_66;
wire n_32;
wire n_33;
wire n_41;
wire n_34;
wire n_31;
wire n_79;
wire n_40;
wire n_30;
wire n_61;
wire n_62;
wire n_70;
wire n_67;
wire n_48;
wire n_60;
wire n_46;
wire n_38;
wire n_43;
wire n_74;
wire n_72;

INVx2_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_18),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_16),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_1),
.Y(n_34)
);

NOR2x1_ASAP7_75t_L g35 ( 
.A(n_9),
.B(n_17),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_2),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_28),
.B(n_8),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_24),
.B(n_19),
.Y(n_38)
);

XNOR2xp5_ASAP7_75t_L g39 ( 
.A(n_27),
.B(n_28),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_26),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_4),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_L g42 ( 
.A1(n_0),
.A2(n_12),
.B1(n_21),
.B2(n_10),
.Y(n_42)
);

OA21x2_ASAP7_75t_L g43 ( 
.A1(n_25),
.A2(n_21),
.B(n_27),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_11),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_SL g45 ( 
.A(n_32),
.B(n_23),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_30),
.A2(n_25),
.B1(n_24),
.B2(n_23),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_L g47 ( 
.A1(n_29),
.A2(n_6),
.B1(n_5),
.B2(n_3),
.Y(n_47)
);

INVx4_ASAP7_75t_L g48 ( 
.A(n_32),
.Y(n_48)
);

INVxp67_ASAP7_75t_L g49 ( 
.A(n_33),
.Y(n_49)
);

NOR3xp33_ASAP7_75t_SL g50 ( 
.A(n_42),
.B(n_13),
.C(n_7),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_49),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_40),
.Y(n_52)
);

OAI21x1_ASAP7_75t_SL g53 ( 
.A1(n_46),
.A2(n_42),
.B(n_43),
.Y(n_53)
);

INVx6_ASAP7_75t_L g54 ( 
.A(n_49),
.Y(n_54)
);

OAI21x1_ASAP7_75t_L g55 ( 
.A1(n_47),
.A2(n_41),
.B(n_34),
.Y(n_55)
);

OR2x6_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_45),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_51),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

HB1xp67_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_58),
.B(n_54),
.Y(n_61)
);

INVx6_ASAP7_75t_L g62 ( 
.A(n_56),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_57),
.B(n_39),
.Y(n_63)
);

O2A1O1Ixp33_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_59),
.B(n_31),
.C(n_38),
.Y(n_64)
);

OAI21xp5_ASAP7_75t_L g65 ( 
.A1(n_61),
.A2(n_55),
.B(n_37),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_62),
.Y(n_66)
);

NOR2xp67_ASAP7_75t_SL g67 ( 
.A(n_62),
.B(n_43),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_66),
.Y(n_68)
);

AOI211xp5_ASAP7_75t_L g69 ( 
.A1(n_64),
.A2(n_63),
.B(n_39),
.C(n_44),
.Y(n_69)
);

AND2x2_ASAP7_75t_L g70 ( 
.A(n_66),
.B(n_43),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_65),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_71),
.Y(n_72)
);

NAND5xp2_ASAP7_75t_L g73 ( 
.A(n_69),
.B(n_67),
.C(n_35),
.D(n_55),
.E(n_41),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_L g74 ( 
.A(n_68),
.B(n_36),
.Y(n_74)
);

AND2x2_ASAP7_75t_L g75 ( 
.A(n_70),
.B(n_36),
.Y(n_75)
);

HB1xp67_ASAP7_75t_L g76 ( 
.A(n_75),
.Y(n_76)
);

OR2x2_ASAP7_75t_L g77 ( 
.A(n_72),
.B(n_36),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_74),
.Y(n_78)
);

AO22x2_ASAP7_75t_L g79 ( 
.A1(n_72),
.A2(n_20),
.B1(n_15),
.B2(n_14),
.Y(n_79)
);

INVx2_ASAP7_75t_L g80 ( 
.A(n_77),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_76),
.Y(n_81)
);

AOI322xp5_ASAP7_75t_L g82 ( 
.A1(n_80),
.A2(n_73),
.A3(n_75),
.B1(n_78),
.B2(n_79),
.C1(n_81),
.C2(n_50),
.Y(n_82)
);


endmodule