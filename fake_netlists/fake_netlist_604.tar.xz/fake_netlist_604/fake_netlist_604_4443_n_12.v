module fake_netlist_604_4443_n_12 (n_1, n_2, n_0, n_12);

input n_1;
input n_2;
input n_0;

output n_12;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_3;

INVx2_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

OAI222xp33_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_4),
.C2(n_6),
.Y(n_7)
);

AOI211xp5_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_4),
.B(n_2),
.C(n_0),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_SL g9 ( 
.A1(n_7),
.A2(n_6),
.B(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

XOR2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.Y(n_11)
);

AO21x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B(n_8),
.Y(n_12)
);


endmodule