module fake_netlist_604_4326_n_35 (n_7, n_9, n_11, n_8, n_5, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_35);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_35;

wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

CKINVDCx6p67_ASAP7_75t_R g16 ( 
.A(n_9),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_4),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

AND2x6_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_8),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_8),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_24),
.B(n_15),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_26),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_21),
.B1(n_27),
.B2(n_16),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_11),
.B(n_10),
.C(n_1),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_10),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_35)
);


endmodule