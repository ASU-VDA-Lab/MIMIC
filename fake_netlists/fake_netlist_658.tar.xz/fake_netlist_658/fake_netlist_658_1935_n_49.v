module fake_netlist_658_1935_n_49 (n_9, n_4, n_7, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_49);

input n_9;
input n_4;
input n_7;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_49;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_45;
wire n_23;
wire n_48;
wire n_16;
wire n_22;
wire n_17;
wire n_39;
wire n_14;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_7),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_1),
.B(n_5),
.Y(n_15)
);

NOR2xp67_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

CKINVDCx16_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_9),
.Y(n_22)
);

OR2x6_ASAP7_75t_SL g23 ( 
.A(n_14),
.B(n_19),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_17),
.A2(n_8),
.B(n_2),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_18),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_18),
.A2(n_5),
.B1(n_4),
.B2(n_0),
.Y(n_28)
);

O2A1O1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_20),
.A2(n_7),
.B(n_4),
.C(n_0),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_22),
.Y(n_30)
);

AND2x4_ASAP7_75t_SL g31 ( 
.A(n_27),
.B(n_17),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_24),
.B(n_16),
.Y(n_32)
);

CKINVDCx8_ASAP7_75t_R g33 ( 
.A(n_27),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_24),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_24),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_33),
.B1(n_34),
.B2(n_32),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_36),
.B(n_35),
.Y(n_39)
);

AO221x1_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_28),
.B1(n_15),
.B2(n_29),
.C(n_26),
.Y(n_40)
);

AOI211xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_13),
.B(n_35),
.C(n_39),
.Y(n_41)
);

AOI211xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_38),
.B(n_28),
.C(n_34),
.Y(n_42)
);

AOI211xp5_ASAP7_75t_L g43 ( 
.A1(n_38),
.A2(n_28),
.B(n_34),
.C(n_39),
.Y(n_43)
);

OA21x2_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_42),
.B(n_43),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_43),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_35),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_46),
.B1(n_44),
.B2(n_47),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);


endmodule