module fake_netlist_658_291_n_60 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_27, n_2, n_26, n_9, n_13, n_8, n_6, n_60);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_27;
input n_2;
input n_26;
input n_9;
input n_13;
input n_8;
input n_6;

output n_60;

wire n_36;
wire n_59;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_57;
wire n_40;
wire n_54;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_48;
wire n_39;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVxp67_ASAP7_75t_L g28 ( 
.A(n_11),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_0),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_7),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_8),
.B(n_23),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_9),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_18),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_17),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

AND2x4_ASAP7_75t_SL g36 ( 
.A(n_22),
.B(n_5),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_20),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_13),
.B(n_16),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_34),
.B(n_30),
.Y(n_39)
);

BUFx4f_ASAP7_75t_L g40 ( 
.A(n_33),
.Y(n_40)
);

AND2x6_ASAP7_75t_SL g41 ( 
.A(n_38),
.B(n_31),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_35),
.Y(n_42)
);

AO32x2_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_36),
.A3(n_28),
.B1(n_37),
.B2(n_27),
.Y(n_43)
);

INVx3_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_39),
.A2(n_29),
.B1(n_32),
.B2(n_27),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_40),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

OR2x6_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_29),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_45),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

OAI211xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_52),
.Y(n_54)
);

AND3x4_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_6),
.C(n_4),
.Y(n_55)
);

NOR3xp33_ASAP7_75t_SL g56 ( 
.A(n_52),
.B(n_12),
.C(n_10),
.Y(n_56)
);

BUFx2_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

OAI22xp5_ASAP7_75t_SL g58 ( 
.A1(n_55),
.A2(n_56),
.B1(n_15),
.B2(n_14),
.Y(n_58)
);

AOI221xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_21),
.B1(n_19),
.B2(n_25),
.C(n_26),
.Y(n_59)
);

XNOR2xp5_ASAP7_75t_L g60 ( 
.A(n_59),
.B(n_58),
.Y(n_60)
);


endmodule