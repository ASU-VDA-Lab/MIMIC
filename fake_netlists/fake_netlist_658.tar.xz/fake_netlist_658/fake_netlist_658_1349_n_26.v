module fake_netlist_658_1349_n_26 (n_4, n_1, n_2, n_0, n_3, n_26);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_26;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_25;
wire n_24;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

OAI22xp33_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_1),
.B1(n_0),
.B2(n_3),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_2),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_7),
.B(n_1),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_2),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_5),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_5),
.A2(n_3),
.B(n_2),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_4),
.B(n_7),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_7),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_7),
.B1(n_8),
.B2(n_4),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_12),
.B1(n_7),
.B2(n_10),
.Y(n_17)
);

NOR2x1_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_14),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_13),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_14),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.B(n_16),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_16),
.B1(n_8),
.B2(n_11),
.C1(n_6),
.C2(n_12),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_19),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_19),
.C(n_20),
.Y(n_24)
);

AND2x4_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_19),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.Y(n_26)
);


endmodule