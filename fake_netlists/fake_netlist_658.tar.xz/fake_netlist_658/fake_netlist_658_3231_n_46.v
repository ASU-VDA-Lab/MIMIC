module fake_netlist_658_3231_n_46 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_46);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_46;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_23;
wire n_39;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_6),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_8),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_2),
.B(n_12),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_19),
.B1(n_1),
.B2(n_0),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_3),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_4),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

OAI33xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_27),
.A3(n_24),
.B1(n_29),
.B2(n_31),
.B3(n_25),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_27),
.B1(n_28),
.B2(n_5),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_36),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_28),
.Y(n_40)
);

INVxp67_ASAP7_75t_SL g41 ( 
.A(n_40),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_7),
.Y(n_42)
);

NAND5xp2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_10),
.C(n_9),
.D(n_11),
.E(n_13),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_15),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

AOI222xp33_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_42),
.B1(n_43),
.B2(n_20),
.C1(n_17),
.C2(n_16),
.Y(n_46)
);


endmodule