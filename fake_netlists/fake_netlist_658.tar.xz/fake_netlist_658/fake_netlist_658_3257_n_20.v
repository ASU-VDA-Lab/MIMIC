module fake_netlist_658_3257_n_20 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_20);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_20;

wire n_18;
wire n_19;
wire n_10;
wire n_15;
wire n_11;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;

INVx1_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_7),
.Y(n_9)
);

OA21x2_ASAP7_75t_L g10 ( 
.A1(n_3),
.A2(n_1),
.B(n_2),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.C(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_15),
.B(n_4),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

OAI211xp5_ASAP7_75t_SL g18 ( 
.A1(n_16),
.A2(n_6),
.B(n_5),
.C(n_10),
.Y(n_18)
);

OR3x1_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_6),
.C(n_10),
.Y(n_19)
);

XNOR2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);


endmodule