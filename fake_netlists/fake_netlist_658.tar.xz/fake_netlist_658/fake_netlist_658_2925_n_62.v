module fake_netlist_658_2925_n_62 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_62);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_62;

wire n_18;
wire n_36;
wire n_59;
wire n_19;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_60;
wire n_22;
wire n_17;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;
wire n_61;

INVxp67_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_16),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_9),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_10),
.B(n_13),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_1),
.B(n_12),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_7),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_1),
.Y(n_28)
);

AND3x1_ASAP7_75t_SL g29 ( 
.A(n_26),
.B(n_14),
.C(n_0),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_20),
.B(n_0),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_19),
.B(n_15),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_17),
.B(n_15),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_4),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_20),
.B(n_6),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_20),
.B(n_8),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_18),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

INVx4_ASAP7_75t_L g38 ( 
.A(n_30),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_36),
.B(n_21),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_22),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_34),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_29),
.A2(n_28),
.B1(n_24),
.B2(n_25),
.Y(n_42)
);

INVx3_ASAP7_75t_R g43 ( 
.A(n_40),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_38),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_38),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_SL g46 ( 
.A(n_41),
.B(n_32),
.Y(n_46)
);

INVx8_ASAP7_75t_L g47 ( 
.A(n_40),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_37),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

CKINVDCx16_ASAP7_75t_R g51 ( 
.A(n_43),
.Y(n_51)
);

OA22x2_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_42),
.B1(n_47),
.B2(n_31),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_42),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_48),
.Y(n_54)
);

AO21x1_ASAP7_75t_L g55 ( 
.A1(n_48),
.A2(n_35),
.B(n_33),
.Y(n_55)
);

OAI211xp5_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_39),
.B(n_23),
.C(n_24),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

XNOR2xp5_ASAP7_75t_L g58 ( 
.A(n_52),
.B(n_44),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

NOR3xp33_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_51),
.C(n_27),
.Y(n_60)
);

NOR3xp33_ASAP7_75t_L g61 ( 
.A(n_60),
.B(n_59),
.C(n_57),
.Y(n_61)
);

AOI22xp5_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_11),
.B1(n_52),
.B2(n_58),
.Y(n_62)
);


endmodule