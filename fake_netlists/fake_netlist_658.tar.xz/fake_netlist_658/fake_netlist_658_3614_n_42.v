module fake_netlist_658_3614_n_42 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_42);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_42;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_5),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_12),
.Y(n_20)
);

AO21x2_ASAP7_75t_L g21 ( 
.A1(n_2),
.A2(n_0),
.B(n_18),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_15),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_25),
.B(n_5),
.Y(n_27)
);

O2A1O1Ixp5_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_26),
.B(n_24),
.C(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_19),
.B(n_17),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_28),
.B(n_20),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_21),
.Y(n_32)
);

NOR2xp67_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_29),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_20),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_SL g35 ( 
.A1(n_32),
.A2(n_22),
.B1(n_18),
.B2(n_1),
.Y(n_35)
);

NAND2xp33_ASAP7_75t_SL g36 ( 
.A(n_34),
.B(n_33),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_4),
.B1(n_3),
.B2(n_6),
.C(n_8),
.Y(n_37)
);

CKINVDCx16_ASAP7_75t_R g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_SL g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_13),
.B1(n_14),
.B2(n_41),
.Y(n_42)
);


endmodule