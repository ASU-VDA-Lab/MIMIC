module fake_netlist_658_1431_n_18 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_18);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_18;

wire n_17;
wire n_14;
wire n_10;
wire n_15;
wire n_11;
wire n_13;
wire n_16;
wire n_12;

NOR2x1p5_ASAP7_75t_L g10 ( 
.A(n_3),
.B(n_7),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_9),
.Y(n_11)
);

OAI22xp33_ASAP7_75t_L g12 ( 
.A1(n_4),
.A2(n_5),
.B1(n_2),
.B2(n_0),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B1(n_10),
.B2(n_12),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B1(n_10),
.B2(n_11),
.C1(n_1),
.C2(n_0),
.Y(n_16)
);

OR3x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_5),
.C(n_4),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_6),
.B1(n_7),
.B2(n_8),
.C1(n_13),
.C2(n_12),
.Y(n_18)
);


endmodule