module fake_netlist_658_791_n_247 (n_72, n_18, n_36, n_59, n_19, n_62, n_70, n_34, n_1, n_38, n_58, n_51, n_0, n_5, n_10, n_44, n_64, n_25, n_40, n_54, n_24, n_35, n_57, n_28, n_11, n_15, n_68, n_7, n_30, n_20, n_45, n_49, n_73, n_53, n_56, n_66, n_23, n_69, n_48, n_16, n_60, n_12, n_3, n_22, n_4, n_17, n_39, n_14, n_21, n_27, n_67, n_46, n_42, n_2, n_63, n_29, n_55, n_52, n_50, n_31, n_41, n_26, n_65, n_33, n_9, n_32, n_37, n_71, n_13, n_43, n_47, n_61, n_8, n_6, n_247);

input n_72;
input n_18;
input n_36;
input n_59;
input n_19;
input n_62;
input n_70;
input n_34;
input n_1;
input n_38;
input n_58;
input n_51;
input n_0;
input n_5;
input n_10;
input n_44;
input n_64;
input n_25;
input n_40;
input n_54;
input n_24;
input n_35;
input n_57;
input n_28;
input n_11;
input n_15;
input n_68;
input n_7;
input n_30;
input n_20;
input n_45;
input n_49;
input n_73;
input n_53;
input n_56;
input n_66;
input n_23;
input n_69;
input n_48;
input n_16;
input n_60;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_39;
input n_14;
input n_21;
input n_27;
input n_67;
input n_46;
input n_42;
input n_2;
input n_63;
input n_29;
input n_55;
input n_52;
input n_50;
input n_31;
input n_41;
input n_26;
input n_65;
input n_33;
input n_9;
input n_32;
input n_37;
input n_71;
input n_13;
input n_43;
input n_47;
input n_61;
input n_8;
input n_6;

output n_247;

wire n_168;
wire n_99;
wire n_90;
wire n_101;
wire n_144;
wire n_155;
wire n_166;
wire n_139;
wire n_84;
wire n_214;
wire n_89;
wire n_209;
wire n_152;
wire n_116;
wire n_96;
wire n_172;
wire n_107;
wire n_220;
wire n_218;
wire n_78;
wire n_235;
wire n_245;
wire n_191;
wire n_154;
wire n_164;
wire n_118;
wire n_137;
wire n_189;
wire n_197;
wire n_243;
wire n_173;
wire n_183;
wire n_190;
wire n_211;
wire n_206;
wire n_177;
wire n_192;
wire n_194;
wire n_184;
wire n_187;
wire n_238;
wire n_81;
wire n_124;
wire n_163;
wire n_91;
wire n_165;
wire n_121;
wire n_157;
wire n_201;
wire n_105;
wire n_92;
wire n_244;
wire n_125;
wire n_117;
wire n_230;
wire n_136;
wire n_217;
wire n_223;
wire n_110;
wire n_170;
wire n_241;
wire n_207;
wire n_151;
wire n_161;
wire n_77;
wire n_234;
wire n_75;
wire n_180;
wire n_142;
wire n_232;
wire n_93;
wire n_203;
wire n_199;
wire n_181;
wire n_143;
wire n_213;
wire n_109;
wire n_208;
wire n_122;
wire n_219;
wire n_240;
wire n_119;
wire n_149;
wire n_182;
wire n_227;
wire n_82;
wire n_204;
wire n_120;
wire n_85;
wire n_176;
wire n_246;
wire n_229;
wire n_242;
wire n_160;
wire n_231;
wire n_226;
wire n_86;
wire n_156;
wire n_198;
wire n_130;
wire n_210;
wire n_140;
wire n_174;
wire n_233;
wire n_202;
wire n_167;
wire n_175;
wire n_195;
wire n_112;
wire n_179;
wire n_113;
wire n_169;
wire n_237;
wire n_103;
wire n_104;
wire n_127;
wire n_162;
wire n_100;
wire n_150;
wire n_236;
wire n_129;
wire n_146;
wire n_76;
wire n_134;
wire n_83;
wire n_200;
wire n_196;
wire n_106;
wire n_133;
wire n_225;
wire n_97;
wire n_131;
wire n_148;
wire n_159;
wire n_228;
wire n_123;
wire n_141;
wire n_87;
wire n_145;
wire n_115;
wire n_79;
wire n_215;
wire n_128;
wire n_205;
wire n_108;
wire n_126;
wire n_185;
wire n_132;
wire n_98;
wire n_224;
wire n_147;
wire n_171;
wire n_94;
wire n_221;
wire n_212;
wire n_222;
wire n_193;
wire n_138;
wire n_153;
wire n_158;
wire n_239;
wire n_216;
wire n_102;
wire n_135;
wire n_95;
wire n_178;
wire n_74;
wire n_186;
wire n_188;
wire n_80;
wire n_88;
wire n_114;
wire n_111;

CKINVDCx20_ASAP7_75t_R g74 ( 
.A(n_20),
.Y(n_74)
);

CKINVDCx5p33_ASAP7_75t_R g75 ( 
.A(n_43),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_41),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_44),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_42),
.Y(n_78)
);

CKINVDCx5p33_ASAP7_75t_R g79 ( 
.A(n_59),
.Y(n_79)
);

NOR2xp67_ASAP7_75t_L g80 ( 
.A(n_52),
.B(n_45),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_60),
.Y(n_81)
);

BUFx6f_ASAP7_75t_L g82 ( 
.A(n_6),
.Y(n_82)
);

BUFx6f_ASAP7_75t_L g83 ( 
.A(n_65),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_28),
.Y(n_84)
);

CKINVDCx5p33_ASAP7_75t_R g85 ( 
.A(n_32),
.Y(n_85)
);

CKINVDCx5p33_ASAP7_75t_R g86 ( 
.A(n_17),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_63),
.Y(n_87)
);

CKINVDCx16_ASAP7_75t_R g88 ( 
.A(n_62),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_40),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_73),
.Y(n_90)
);

CKINVDCx5p33_ASAP7_75t_R g91 ( 
.A(n_15),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_61),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_19),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_71),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_53),
.Y(n_95)
);

BUFx8_ASAP7_75t_SL g96 ( 
.A(n_72),
.Y(n_96)
);

INVx1_ASAP7_75t_L g97 ( 
.A(n_4),
.Y(n_97)
);

INVx1_ASAP7_75t_L g98 ( 
.A(n_34),
.Y(n_98)
);

CKINVDCx20_ASAP7_75t_R g99 ( 
.A(n_12),
.Y(n_99)
);

INVxp67_ASAP7_75t_SL g100 ( 
.A(n_14),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_0),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_64),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_56),
.Y(n_103)
);

BUFx3_ASAP7_75t_L g104 ( 
.A(n_39),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_0),
.Y(n_105)
);

INVxp33_ASAP7_75t_SL g106 ( 
.A(n_24),
.Y(n_106)
);

INVxp33_ASAP7_75t_L g107 ( 
.A(n_35),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_3),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_13),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_70),
.Y(n_110)
);

CKINVDCx5p33_ASAP7_75t_R g111 ( 
.A(n_2),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_46),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_57),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_5),
.Y(n_114)
);

INVx4_ASAP7_75t_L g115 ( 
.A(n_75),
.Y(n_115)
);

INVx3_ASAP7_75t_L g116 ( 
.A(n_97),
.Y(n_116)
);

CKINVDCx5p33_ASAP7_75t_R g117 ( 
.A(n_96),
.Y(n_117)
);

AND2x4_ASAP7_75t_L g118 ( 
.A(n_101),
.B(n_1),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_105),
.Y(n_119)
);

CKINVDCx5p33_ASAP7_75t_R g120 ( 
.A(n_96),
.Y(n_120)
);

BUFx2_ASAP7_75t_L g121 ( 
.A(n_111),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_108),
.Y(n_122)
);

AND2x4_ASAP7_75t_L g123 ( 
.A(n_118),
.B(n_116),
.Y(n_123)
);

NOR2xp33_ASAP7_75t_L g124 ( 
.A(n_115),
.B(n_107),
.Y(n_124)
);

CKINVDCx5p33_ASAP7_75t_R g125 ( 
.A(n_117),
.Y(n_125)
);

INVx1_ASAP7_75t_L g126 ( 
.A(n_118),
.Y(n_126)
);

NAND2xp5_ASAP7_75t_L g127 ( 
.A(n_115),
.B(n_107),
.Y(n_127)
);

AOI22xp33_ASAP7_75t_L g128 ( 
.A1(n_123),
.A2(n_118),
.B1(n_116),
.B2(n_119),
.Y(n_128)
);

NAND2xp5_ASAP7_75t_L g129 ( 
.A(n_124),
.B(n_115),
.Y(n_129)
);

NAND2xp5_ASAP7_75t_SL g130 ( 
.A(n_123),
.B(n_88),
.Y(n_130)
);

AOI22xp33_ASAP7_75t_L g131 ( 
.A1(n_126),
.A2(n_116),
.B1(n_122),
.B2(n_114),
.Y(n_131)
);

AND2x4_ASAP7_75t_L g132 ( 
.A(n_127),
.B(n_121),
.Y(n_132)
);

INVx3_ASAP7_75t_L g133 ( 
.A(n_132),
.Y(n_133)
);

AND2x4_ASAP7_75t_L g134 ( 
.A(n_132),
.B(n_124),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_128),
.Y(n_135)
);

HB1xp67_ASAP7_75t_L g136 ( 
.A(n_130),
.Y(n_136)
);

INVx2_ASAP7_75t_L g137 ( 
.A(n_129),
.Y(n_137)
);

OAI21x1_ASAP7_75t_L g138 ( 
.A1(n_137),
.A2(n_77),
.B(n_76),
.Y(n_138)
);

OAI21x1_ASAP7_75t_L g139 ( 
.A1(n_137),
.A2(n_81),
.B(n_78),
.Y(n_139)
);

BUFx2_ASAP7_75t_SL g140 ( 
.A(n_133),
.Y(n_140)
);

NOR2xp33_ASAP7_75t_L g141 ( 
.A(n_134),
.B(n_131),
.Y(n_141)
);

OAI21x1_ASAP7_75t_L g142 ( 
.A1(n_135),
.A2(n_87),
.B(n_84),
.Y(n_142)
);

OA21x2_ASAP7_75t_L g143 ( 
.A1(n_134),
.A2(n_90),
.B(n_89),
.Y(n_143)
);

BUFx3_ASAP7_75t_L g144 ( 
.A(n_133),
.Y(n_144)
);

O2A1O1Ixp33_ASAP7_75t_L g145 ( 
.A1(n_141),
.A2(n_136),
.B(n_100),
.C(n_92),
.Y(n_145)
);

OAI21xp5_ASAP7_75t_L g146 ( 
.A1(n_141),
.A2(n_139),
.B(n_138),
.Y(n_146)
);

AOI221xp5_ASAP7_75t_L g147 ( 
.A1(n_140),
.A2(n_136),
.B1(n_125),
.B2(n_117),
.C(n_120),
.Y(n_147)
);

OAI22xp33_ASAP7_75t_L g148 ( 
.A1(n_143),
.A2(n_120),
.B1(n_99),
.B2(n_74),
.Y(n_148)
);

AND2x2_ASAP7_75t_L g149 ( 
.A(n_144),
.B(n_100),
.Y(n_149)
);

NAND2xp5_ASAP7_75t_L g150 ( 
.A(n_144),
.B(n_106),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_143),
.Y(n_151)
);

AND2x4_ASAP7_75t_L g152 ( 
.A(n_142),
.B(n_1),
.Y(n_152)
);

NAND2xp5_ASAP7_75t_L g153 ( 
.A(n_141),
.B(n_2),
.Y(n_153)
);

AOI22xp33_ASAP7_75t_L g154 ( 
.A1(n_141),
.A2(n_102),
.B1(n_98),
.B2(n_93),
.Y(n_154)
);

OR2x6_ASAP7_75t_L g155 ( 
.A(n_140),
.B(n_80),
.Y(n_155)
);

OR2x2_ASAP7_75t_L g156 ( 
.A(n_141),
.B(n_3),
.Y(n_156)
);

AOI222xp33_ASAP7_75t_L g157 ( 
.A1(n_141),
.A2(n_109),
.B1(n_103),
.B2(n_110),
.C1(n_113),
.C2(n_112),
.Y(n_157)
);

AO31x2_ASAP7_75t_L g158 ( 
.A1(n_141),
.A2(n_95),
.A3(n_94),
.B(n_82),
.Y(n_158)
);

INVx2_ASAP7_75t_L g159 ( 
.A(n_151),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_156),
.Y(n_160)
);

AND2x2_ASAP7_75t_L g161 ( 
.A(n_149),
.B(n_4),
.Y(n_161)
);

AO22x1_ASAP7_75t_L g162 ( 
.A1(n_152),
.A2(n_86),
.B1(n_85),
.B2(n_79),
.Y(n_162)
);

INVx2_ASAP7_75t_L g163 ( 
.A(n_158),
.Y(n_163)
);

AND2x2_ASAP7_75t_L g164 ( 
.A(n_157),
.B(n_5),
.Y(n_164)
);

AND2x2_ASAP7_75t_L g165 ( 
.A(n_154),
.B(n_91),
.Y(n_165)
);

INVx2_ASAP7_75t_L g166 ( 
.A(n_158),
.Y(n_166)
);

AND2x2_ASAP7_75t_L g167 ( 
.A(n_153),
.B(n_104),
.Y(n_167)
);

HB1xp67_ASAP7_75t_L g168 ( 
.A(n_146),
.Y(n_168)
);

NAND2xp5_ASAP7_75t_L g169 ( 
.A(n_145),
.B(n_82),
.Y(n_169)
);

INVx2_ASAP7_75t_L g170 ( 
.A(n_155),
.Y(n_170)
);

AND2x2_ASAP7_75t_L g171 ( 
.A(n_155),
.B(n_82),
.Y(n_171)
);

OR2x2_ASAP7_75t_L g172 ( 
.A(n_148),
.B(n_83),
.Y(n_172)
);

INVx2_ASAP7_75t_SL g173 ( 
.A(n_150),
.Y(n_173)
);

AND2x2_ASAP7_75t_L g174 ( 
.A(n_147),
.B(n_83),
.Y(n_174)
);

INVx2_ASAP7_75t_L g175 ( 
.A(n_151),
.Y(n_175)
);

NAND2xp5_ASAP7_75t_L g176 ( 
.A(n_151),
.B(n_7),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_156),
.Y(n_177)
);

INVxp67_ASAP7_75t_SL g178 ( 
.A(n_151),
.Y(n_178)
);

OAI221xp5_ASAP7_75t_SL g179 ( 
.A1(n_148),
.A2(n_9),
.B1(n_8),
.B2(n_10),
.C(n_11),
.Y(n_179)
);

AND2x4_ASAP7_75t_L g180 ( 
.A(n_152),
.B(n_16),
.Y(n_180)
);

NOR2x1_ASAP7_75t_SL g181 ( 
.A(n_172),
.B(n_18),
.Y(n_181)
);

OAI221xp5_ASAP7_75t_L g182 ( 
.A1(n_179),
.A2(n_22),
.B1(n_21),
.B2(n_23),
.C(n_25),
.Y(n_182)
);

INVx2_ASAP7_75t_L g183 ( 
.A(n_175),
.Y(n_183)
);

INVx2_ASAP7_75t_SL g184 ( 
.A(n_173),
.Y(n_184)
);

INVx3_ASAP7_75t_L g185 ( 
.A(n_180),
.Y(n_185)
);

AND2x2_ASAP7_75t_L g186 ( 
.A(n_161),
.B(n_26),
.Y(n_186)
);

AND2x2_ASAP7_75t_L g187 ( 
.A(n_160),
.B(n_27),
.Y(n_187)
);

OAI33xp33_ASAP7_75t_L g188 ( 
.A1(n_177),
.A2(n_30),
.A3(n_29),
.B1(n_31),
.B2(n_36),
.B3(n_33),
.Y(n_188)
);

INVx1_ASAP7_75t_L g189 ( 
.A(n_175),
.Y(n_189)
);

INVx5_ASAP7_75t_L g190 ( 
.A(n_180),
.Y(n_190)
);

INVx2_ASAP7_75t_L g191 ( 
.A(n_159),
.Y(n_191)
);

OAI21xp33_ASAP7_75t_SL g192 ( 
.A1(n_178),
.A2(n_38),
.B(n_37),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_178),
.Y(n_193)
);

AND2x2_ASAP7_75t_L g194 ( 
.A(n_164),
.B(n_47),
.Y(n_194)
);

AOI21xp5_ASAP7_75t_L g195 ( 
.A1(n_176),
.A2(n_49),
.B(n_48),
.Y(n_195)
);

AND2x2_ASAP7_75t_L g196 ( 
.A(n_171),
.B(n_50),
.Y(n_196)
);

INVx2_ASAP7_75t_L g197 ( 
.A(n_166),
.Y(n_197)
);

AND2x4_ASAP7_75t_L g198 ( 
.A(n_170),
.B(n_51),
.Y(n_198)
);

AND2x2_ASAP7_75t_L g199 ( 
.A(n_170),
.B(n_54),
.Y(n_199)
);

OAI22xp5_ASAP7_75t_L g200 ( 
.A1(n_179),
.A2(n_176),
.B1(n_169),
.B2(n_168),
.Y(n_200)
);

AND2x2_ASAP7_75t_L g201 ( 
.A(n_167),
.B(n_55),
.Y(n_201)
);

AND2x2_ASAP7_75t_L g202 ( 
.A(n_184),
.B(n_174),
.Y(n_202)
);

INVx1_ASAP7_75t_L g203 ( 
.A(n_189),
.Y(n_203)
);

HB1xp67_ASAP7_75t_L g204 ( 
.A(n_193),
.Y(n_204)
);

AND2x2_ASAP7_75t_L g205 ( 
.A(n_185),
.B(n_163),
.Y(n_205)
);

NAND2xp5_ASAP7_75t_L g206 ( 
.A(n_191),
.B(n_169),
.Y(n_206)
);

BUFx3_ASAP7_75t_L g207 ( 
.A(n_185),
.Y(n_207)
);

HB1xp67_ASAP7_75t_L g208 ( 
.A(n_191),
.Y(n_208)
);

NAND2xp5_ASAP7_75t_L g209 ( 
.A(n_183),
.B(n_162),
.Y(n_209)
);

INVx3_ASAP7_75t_L g210 ( 
.A(n_190),
.Y(n_210)
);

OR2x2_ASAP7_75t_L g211 ( 
.A(n_183),
.B(n_165),
.Y(n_211)
);

AND2x2_ASAP7_75t_L g212 ( 
.A(n_190),
.B(n_58),
.Y(n_212)
);

NAND2xp5_ASAP7_75t_L g213 ( 
.A(n_200),
.B(n_66),
.Y(n_213)
);

AND2x2_ASAP7_75t_L g214 ( 
.A(n_190),
.B(n_67),
.Y(n_214)
);

OR2x2_ASAP7_75t_L g215 ( 
.A(n_197),
.B(n_68),
.Y(n_215)
);

OR2x2_ASAP7_75t_L g216 ( 
.A(n_197),
.B(n_69),
.Y(n_216)
);

INVx2_ASAP7_75t_L g217 ( 
.A(n_208),
.Y(n_217)
);

AND2x2_ASAP7_75t_L g218 ( 
.A(n_205),
.B(n_190),
.Y(n_218)
);

AND2x2_ASAP7_75t_L g219 ( 
.A(n_204),
.B(n_198),
.Y(n_219)
);

NAND2xp5_ASAP7_75t_L g220 ( 
.A(n_203),
.B(n_200),
.Y(n_220)
);

NOR2xp67_ASAP7_75t_SL g221 ( 
.A(n_213),
.B(n_182),
.Y(n_221)
);

NAND2xp5_ASAP7_75t_L g222 ( 
.A(n_211),
.B(n_187),
.Y(n_222)
);

NAND2xp5_ASAP7_75t_L g223 ( 
.A(n_202),
.B(n_194),
.Y(n_223)
);

OAI31xp33_ASAP7_75t_L g224 ( 
.A1(n_213),
.A2(n_182),
.A3(n_186),
.B(n_201),
.Y(n_224)
);

NAND2xp5_ASAP7_75t_L g225 ( 
.A(n_206),
.B(n_209),
.Y(n_225)
);

NOR2xp67_ASAP7_75t_L g226 ( 
.A(n_217),
.B(n_210),
.Y(n_226)
);

INVx1_ASAP7_75t_L g227 ( 
.A(n_225),
.Y(n_227)
);

INVx1_ASAP7_75t_L g228 ( 
.A(n_220),
.Y(n_228)
);

INVx2_ASAP7_75t_L g229 ( 
.A(n_219),
.Y(n_229)
);

INVx2_ASAP7_75t_L g230 ( 
.A(n_218),
.Y(n_230)
);

NAND2xp5_ASAP7_75t_L g231 ( 
.A(n_228),
.B(n_223),
.Y(n_231)
);

INVx1_ASAP7_75t_L g232 ( 
.A(n_227),
.Y(n_232)
);

INVxp67_ASAP7_75t_L g233 ( 
.A(n_227),
.Y(n_233)
);

AOI22x1_ASAP7_75t_L g234 ( 
.A1(n_230),
.A2(n_210),
.B1(n_224),
.B2(n_221),
.Y(n_234)
);

INVxp67_ASAP7_75t_L g235 ( 
.A(n_232),
.Y(n_235)
);

INVx3_ASAP7_75t_L g236 ( 
.A(n_231),
.Y(n_236)
);

NOR2x1_ASAP7_75t_L g237 ( 
.A(n_234),
.B(n_226),
.Y(n_237)
);

NAND3xp33_ASAP7_75t_SL g238 ( 
.A(n_237),
.B(n_224),
.C(n_233),
.Y(n_238)
);

NAND2xp33_ASAP7_75t_R g239 ( 
.A(n_236),
.B(n_214),
.Y(n_239)
);

OAI21xp5_ASAP7_75t_SL g240 ( 
.A1(n_238),
.A2(n_235),
.B(n_209),
.Y(n_240)
);

INVx2_ASAP7_75t_SL g241 ( 
.A(n_240),
.Y(n_241)
);

OAI22x1_ASAP7_75t_L g242 ( 
.A1(n_241),
.A2(n_239),
.B1(n_212),
.B2(n_196),
.Y(n_242)
);

XNOR2xp5_ASAP7_75t_L g243 ( 
.A(n_242),
.B(n_229),
.Y(n_243)
);

INVx1_ASAP7_75t_L g244 ( 
.A(n_243),
.Y(n_244)
);

AOI222xp33_ASAP7_75t_L g245 ( 
.A1(n_244),
.A2(n_192),
.B1(n_181),
.B2(n_188),
.C1(n_199),
.C2(n_207),
.Y(n_245)
);

INVx1_ASAP7_75t_L g246 ( 
.A(n_245),
.Y(n_246)
);

AOI221xp5_ASAP7_75t_SL g247 ( 
.A1(n_246),
.A2(n_195),
.B1(n_222),
.B2(n_216),
.C(n_215),
.Y(n_247)
);


endmodule