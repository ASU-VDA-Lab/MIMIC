module fake_netlist_658_3637_n_40 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_40);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_40;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

INVx1_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

OAI21xp33_ASAP7_75t_L g19 ( 
.A1(n_2),
.A2(n_9),
.B(n_6),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_16),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_5),
.B(n_8),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_13),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_18),
.A2(n_1),
.B(n_0),
.Y(n_26)
);

INVx2_ASAP7_75t_SL g27 ( 
.A(n_20),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_21),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_SL g29 ( 
.A(n_28),
.B(n_25),
.C(n_24),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_27),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

CKINVDCx16_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_15),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_31),
.B1(n_22),
.B2(n_19),
.C(n_20),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_26),
.Y(n_37)
);

BUFx4f_ASAP7_75t_SL g38 ( 
.A(n_35),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_23),
.Y(n_39)
);

AOI222xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_7),
.B1(n_10),
.B2(n_11),
.C1(n_17),
.C2(n_38),
.Y(n_40)
);


endmodule