module fake_netlist_658_2704_n_91 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_91);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_91;

wire n_62;
wire n_70;
wire n_90;
wire n_38;
wire n_58;
wire n_57;
wire n_84;
wire n_35;
wire n_89;
wire n_45;
wire n_78;
wire n_66;
wire n_23;
wire n_60;
wire n_22;
wire n_39;
wire n_63;
wire n_31;
wire n_81;
wire n_37;
wire n_71;
wire n_40;
wire n_28;
wire n_49;
wire n_53;
wire n_77;
wire n_75;
wire n_48;
wire n_41;
wire n_65;
wire n_33;
wire n_43;
wire n_82;
wire n_85;
wire n_61;
wire n_72;
wire n_51;
wire n_25;
wire n_54;
wire n_86;
wire n_68;
wire n_27;
wire n_67;
wire n_29;
wire n_52;
wire n_50;
wire n_26;
wire n_76;
wire n_83;
wire n_36;
wire n_59;
wire n_34;
wire n_64;
wire n_44;
wire n_24;
wire n_87;
wire n_79;
wire n_30;
wire n_73;
wire n_56;
wire n_69;
wire n_46;
wire n_42;
wire n_55;
wire n_74;
wire n_32;
wire n_47;
wire n_80;
wire n_88;

INVx4_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_0),
.B(n_15),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_19),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_17),
.A2(n_9),
.B1(n_6),
.B2(n_1),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_12),
.B(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

AND2x2_ASAP7_75t_SL g30 ( 
.A(n_21),
.B(n_14),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_13),
.B(n_2),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_18),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_18),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_19),
.Y(n_34)
);

AOI22x1_ASAP7_75t_SL g35 ( 
.A1(n_7),
.A2(n_21),
.B1(n_5),
.B2(n_20),
.Y(n_35)
);

BUFx3_ASAP7_75t_L g36 ( 
.A(n_11),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_16),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_10),
.B(n_16),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_29),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_22),
.B(n_29),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_30),
.A2(n_28),
.B1(n_32),
.B2(n_24),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_24),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_32),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_SL g44 ( 
.A(n_25),
.B(n_22),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_34),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_SL g46 ( 
.A(n_28),
.B(n_23),
.Y(n_46)
);

BUFx3_ASAP7_75t_L g47 ( 
.A(n_36),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_34),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_SL g49 ( 
.A(n_36),
.B(n_30),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_26),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_38),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_38),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_47),
.Y(n_53)
);

CKINVDCx5p33_ASAP7_75t_R g54 ( 
.A(n_41),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_33),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_47),
.Y(n_56)
);

AO31x2_ASAP7_75t_L g57 ( 
.A1(n_40),
.A2(n_31),
.A3(n_35),
.B(n_27),
.Y(n_57)
);

INVx3_ASAP7_75t_L g58 ( 
.A(n_45),
.Y(n_58)
);

OAI21xp5_ASAP7_75t_L g59 ( 
.A1(n_46),
.A2(n_31),
.B(n_40),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_42),
.Y(n_60)
);

NOR2xp33_ASAP7_75t_L g61 ( 
.A(n_46),
.B(n_39),
.Y(n_61)
);

HB1xp67_ASAP7_75t_L g62 ( 
.A(n_55),
.Y(n_62)
);

BUFx2_ASAP7_75t_L g63 ( 
.A(n_59),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_58),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_58),
.Y(n_65)
);

AND2x2_ASAP7_75t_SL g66 ( 
.A(n_61),
.B(n_44),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_60),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_63),
.B(n_61),
.Y(n_68)
);

AND2x4_ASAP7_75t_L g69 ( 
.A(n_62),
.B(n_49),
.Y(n_69)
);

NAND2xp5_ASAP7_75t_L g70 ( 
.A(n_67),
.B(n_49),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_64),
.Y(n_71)
);

OR2x2_ASAP7_75t_L g72 ( 
.A(n_62),
.B(n_54),
.Y(n_72)
);

A2O1A1Ixp33_ASAP7_75t_L g73 ( 
.A1(n_68),
.A2(n_66),
.B(n_43),
.C(n_48),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_71),
.Y(n_74)
);

HB1xp67_ASAP7_75t_L g75 ( 
.A(n_72),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_70),
.Y(n_76)
);

NAND2xp5_ASAP7_75t_L g77 ( 
.A(n_69),
.B(n_54),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_74),
.Y(n_78)
);

A2O1A1Ixp33_ASAP7_75t_L g79 ( 
.A1(n_73),
.A2(n_66),
.B(n_69),
.C(n_53),
.Y(n_79)
);

A2O1A1Ixp33_ASAP7_75t_L g80 ( 
.A1(n_73),
.A2(n_65),
.B(n_51),
.C(n_53),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_76),
.Y(n_81)
);

AND2x2_ASAP7_75t_L g82 ( 
.A(n_75),
.B(n_57),
.Y(n_82)
);

NOR2xp33_ASAP7_75t_L g83 ( 
.A(n_82),
.B(n_77),
.Y(n_83)
);

OR2x2_ASAP7_75t_L g84 ( 
.A(n_81),
.B(n_57),
.Y(n_84)
);

NAND3xp33_ASAP7_75t_L g85 ( 
.A(n_79),
.B(n_56),
.C(n_52),
.Y(n_85)
);

CKINVDCx5p33_ASAP7_75t_R g86 ( 
.A(n_78),
.Y(n_86)
);

OAI22xp33_ASAP7_75t_SL g87 ( 
.A1(n_86),
.A2(n_57),
.B1(n_79),
.B2(n_56),
.Y(n_87)
);

INVx3_ASAP7_75t_L g88 ( 
.A(n_84),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_83),
.Y(n_89)
);

AO21x2_ASAP7_75t_L g90 ( 
.A1(n_89),
.A2(n_85),
.B(n_80),
.Y(n_90)
);

AOI222xp33_ASAP7_75t_L g91 ( 
.A1(n_90),
.A2(n_57),
.B1(n_87),
.B2(n_88),
.C1(n_89),
.C2(n_82),
.Y(n_91)
);


endmodule