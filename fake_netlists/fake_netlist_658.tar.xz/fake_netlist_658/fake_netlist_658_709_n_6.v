module fake_netlist_658_709_n_6 (n_1, n_0, n_6);

input n_1;
input n_0;

output n_6;

wire n_4;
wire n_2;
wire n_5;
wire n_3;

INVx1_ASAP7_75t_SL g2 ( 
.A(n_1),
.Y(n_2)
);

HB1xp67_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AO221x1_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_SL g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_6)
);


endmodule