module fake_netlist_904_2607_n_42 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_42);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_42;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_41;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

AND3x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_8),
.C(n_5),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_1),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_19),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_21),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_4),
.B(n_0),
.Y(n_30)
);

OAI21x1_ASAP7_75t_L g31 ( 
.A1(n_22),
.A2(n_24),
.B(n_23),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_26),
.Y(n_32)
);

AO31x2_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_27),
.A3(n_7),
.B(n_6),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVxp67_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

NOR3xp33_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_31),
.C(n_33),
.Y(n_36)
);

AOI21xp33_ASAP7_75t_SL g37 ( 
.A1(n_35),
.A2(n_10),
.B(n_9),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

XNOR2x1_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_11),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_SL g41 ( 
.A1(n_39),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_41)
);

AOI222xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_40),
.B1(n_17),
.B2(n_15),
.C1(n_18),
.C2(n_16),
.Y(n_42)
);


endmodule