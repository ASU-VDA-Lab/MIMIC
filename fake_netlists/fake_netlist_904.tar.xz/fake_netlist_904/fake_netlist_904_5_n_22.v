module fake_netlist_904_5_n_22 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_22);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_22;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_14;
wire n_10;

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

AO22x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_7),
.B1(n_5),
.B2(n_4),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_2),
.B(n_1),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI222xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_10),
.B1(n_14),
.B2(n_12),
.C1(n_15),
.C2(n_5),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OA21x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_10),
.B(n_15),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_8),
.B(n_3),
.Y(n_22)
);


endmodule