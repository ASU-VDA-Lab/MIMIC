module fake_netlist_904_961_n_19 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_19);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_19;

wire n_15;
wire n_11;
wire n_16;
wire n_12;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_14;
wire n_10;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_3),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

BUFx10_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

BUFx3_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_12)
);

AO31x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.A3(n_9),
.B(n_8),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_5),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OR3x1_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.C(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

OAI21xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_1),
.B(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);


endmodule