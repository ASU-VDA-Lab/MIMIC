module fake_netlist_904_405_n_43 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_43);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_43;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_41;
wire n_42;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_2),
.B(n_12),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_16),
.B(n_19),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_18),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_22),
.B(n_18),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_26),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_20),
.B1(n_25),
.B2(n_24),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OAI22xp33_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_20),
.B1(n_29),
.B2(n_19),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_31),
.Y(n_36)
);

OAI21xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_29),
.B(n_1),
.Y(n_37)
);

OAI21xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_6),
.B(n_5),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_11),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_39),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_40),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_43)
);


endmodule