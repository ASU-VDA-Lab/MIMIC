module fake_netlist_904_2008_n_65 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_65);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_65;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_63;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_42;
wire n_22;
wire n_25;
wire n_35;
wire n_41;
wire n_21;
wire n_32;
wire n_57;
wire n_43;
wire n_62;
wire n_26;
wire n_29;
wire n_45;
wire n_44;
wire n_48;
wire n_36;
wire n_38;
wire n_56;

AND2x4_ASAP7_75t_L g20 ( 
.A(n_6),
.B(n_2),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_16),
.A2(n_18),
.B1(n_2),
.B2(n_3),
.Y(n_23)
);

INVx6_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_12),
.B(n_7),
.Y(n_25)
);

INVx6_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_10),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_24),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

INVx5_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_26),
.Y(n_34)
);

OA21x2_ASAP7_75t_L g35 ( 
.A1(n_30),
.A2(n_29),
.B(n_25),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

INVxp67_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

INVx3_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_31),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_35),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_35),
.Y(n_44)
);

NAND2xp33_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_25),
.Y(n_45)
);

A2O1A1Ixp33_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_27),
.B(n_20),
.C(n_30),
.Y(n_46)
);

AOI222xp33_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_23),
.B1(n_28),
.B2(n_20),
.C1(n_27),
.C2(n_21),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_23),
.B1(n_44),
.B2(n_35),
.Y(n_48)
);

AOI21xp33_ASAP7_75t_L g49 ( 
.A1(n_42),
.A2(n_34),
.B(n_40),
.Y(n_49)
);

OAI21xp33_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_34),
.B(n_22),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

OA21x2_ASAP7_75t_SL g52 ( 
.A1(n_46),
.A2(n_1),
.B(n_0),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_0),
.Y(n_53)
);

OAI211xp5_ASAP7_75t_SL g54 ( 
.A1(n_47),
.A2(n_38),
.B(n_36),
.C(n_26),
.Y(n_54)
);

AND2x4_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_22),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_50),
.B(n_1),
.Y(n_58)
);

NAND2x1p5_ASAP7_75t_L g59 ( 
.A(n_54),
.B(n_32),
.Y(n_59)
);

AND2x4_ASAP7_75t_L g60 ( 
.A(n_55),
.B(n_57),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_56),
.Y(n_61)
);

OAI22xp5_ASAP7_75t_SL g62 ( 
.A1(n_58),
.A2(n_26),
.B1(n_18),
.B2(n_17),
.Y(n_62)
);

NAND5xp2_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_19),
.C(n_17),
.D(n_32),
.E(n_5),
.Y(n_63)
);

AOI222xp33_ASAP7_75t_L g64 ( 
.A1(n_62),
.A2(n_61),
.B1(n_60),
.B2(n_55),
.C1(n_63),
.C2(n_32),
.Y(n_64)
);

AOI322xp5_ASAP7_75t_L g65 ( 
.A1(n_64),
.A2(n_33),
.A3(n_32),
.B1(n_36),
.B2(n_59),
.C1(n_8),
.C2(n_14),
.Y(n_65)
);


endmodule