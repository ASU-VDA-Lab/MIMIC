module fake_netlist_904_1386_n_25 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_25;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_SL g12 ( 
.A(n_6),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_10),
.B1(n_1),
.B2(n_6),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_5),
.B(n_4),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_4),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

AO21x2_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_7),
.B(n_0),
.Y(n_17)
);

AOI21x1_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_3),
.B(n_2),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_20),
.B1(n_15),
.B2(n_13),
.C(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_16),
.Y(n_24)
);

AO21x2_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_18),
.B(n_8),
.Y(n_25)
);


endmodule