module fake_netlist_904_1417_n_53 (n_3, n_15, n_11, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_53);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_53;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_28;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_35;
wire n_41;
wire n_25;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_45;
wire n_44;
wire n_48;
wire n_38;

OR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_14),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_19),
.B(n_20),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_11),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_4),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_17),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_18),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_21),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_0),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_3),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_23),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_29),
.B(n_23),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_30),
.A2(n_5),
.B(n_1),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_34),
.B(n_6),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_24),
.Y(n_39)
);

AO21x2_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_38),
.B(n_37),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_35),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_32),
.B1(n_31),
.B2(n_26),
.C(n_28),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_33),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_39),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_40),
.B1(n_25),
.B2(n_7),
.C(n_9),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

INVxp67_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

NOR2xp67_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_10),
.Y(n_49)
);

INVxp67_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

NOR4xp25_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_25),
.C(n_13),
.D(n_12),
.Y(n_51)
);

BUFx2_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_51),
.B1(n_16),
.B2(n_15),
.Y(n_53)
);


endmodule