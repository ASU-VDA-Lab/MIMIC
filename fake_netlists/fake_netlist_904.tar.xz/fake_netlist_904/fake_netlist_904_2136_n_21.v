module fake_netlist_904_2136_n_21 (n_0, n_2, n_5, n_3, n_4, n_1, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_21;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

INVx2_ASAP7_75t_SL g6 ( 
.A(n_3),
.Y(n_6)
);

INVx5_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_5),
.Y(n_8)
);

AO21x1_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

A2O1A1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_10)
);

INVxp67_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_7),
.B1(n_9),
.B2(n_2),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_7),
.Y(n_15)
);

AOI321xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_5),
.A3(n_4),
.B1(n_2),
.B2(n_3),
.C(n_7),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_13),
.C(n_4),
.Y(n_17)
);

NAND5xp2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_4),
.C(n_5),
.D(n_7),
.E(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_7),
.B(n_19),
.Y(n_21)
);


endmodule