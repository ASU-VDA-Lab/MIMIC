module fake_netlist_904_2290_n_19 (n_0, n_2, n_3, n_4, n_1, n_19);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_19;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_12;
wire n_5;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

AND2x2_ASAP7_75t_SL g5 ( 
.A(n_2),
.B(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_3),
.B(n_4),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AO21x2_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_8),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_8),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_11),
.B1(n_5),
.B2(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

NOR4xp25_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_14),
.C(n_12),
.D(n_10),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_17),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B1(n_4),
.B2(n_1),
.C1(n_2),
.C2(n_10),
.Y(n_19)
);


endmodule