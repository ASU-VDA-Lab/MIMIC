module fake_netlist_904_2976_n_21 (n_0, n_2, n_5, n_3, n_4, n_1, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_21;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

BUFx4f_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

AOI221x1_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.C(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

OAI21xp33_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_8),
.B1(n_1),
.B2(n_4),
.C1(n_3),
.C2(n_2),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_12),
.B(n_8),
.C(n_13),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_SL g17 ( 
.A(n_15),
.B(n_8),
.C(n_9),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_12),
.B(n_8),
.C(n_9),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_SL g20 ( 
.A1(n_18),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_5),
.B1(n_18),
.B2(n_19),
.C1(n_8),
.C2(n_11),
.Y(n_21)
);


endmodule