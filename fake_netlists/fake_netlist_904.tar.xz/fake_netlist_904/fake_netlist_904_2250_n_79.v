module fake_netlist_904_2250_n_79 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_79);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_79;

wire n_60;
wire n_52;
wire n_30;
wire n_23;
wire n_64;
wire n_66;
wire n_65;
wire n_27;
wire n_20;
wire n_71;
wire n_29;
wire n_69;
wire n_51;
wire n_50;
wire n_55;
wire n_46;
wire n_54;
wire n_28;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_62;
wire n_26;
wire n_44;
wire n_33;
wire n_24;
wire n_77;
wire n_53;
wire n_61;
wire n_21;
wire n_22;
wire n_43;
wire n_48;
wire n_72;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_34;
wire n_37;
wire n_75;
wire n_47;
wire n_68;
wire n_63;
wire n_49;
wire n_58;
wire n_67;
wire n_25;
wire n_35;
wire n_57;
wire n_36;
wire n_45;
wire n_73;
wire n_78;

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_8),
.B(n_4),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_2),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_0),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_26),
.Y(n_33)
);

AND2x6_ASAP7_75t_L g34 ( 
.A(n_24),
.B(n_3),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

INVx5_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_23),
.Y(n_38)
);

INVx4_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

BUFx4f_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

INVx5_ASAP7_75t_L g41 ( 
.A(n_34),
.Y(n_41)
);

AND2x6_ASAP7_75t_L g42 ( 
.A(n_29),
.B(n_25),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_37),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_38),
.B(n_31),
.Y(n_44)
);

INVx5_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_SL g46 ( 
.A(n_39),
.B(n_27),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_SL g47 ( 
.A(n_39),
.B(n_40),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_SL g49 ( 
.A(n_45),
.B(n_36),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_44),
.B(n_41),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_SL g51 ( 
.A(n_45),
.B(n_41),
.Y(n_51)
);

AOI21xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_46),
.B(n_47),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_51),
.B(n_49),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

OA21x2_ASAP7_75t_L g57 ( 
.A1(n_55),
.A2(n_35),
.B(n_33),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_57),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_59),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_60),
.Y(n_62)
);

HB1xp67_ASAP7_75t_L g63 ( 
.A(n_61),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_62),
.Y(n_64)
);

INVxp67_ASAP7_75t_SL g65 ( 
.A(n_63),
.Y(n_65)
);

HB1xp67_ASAP7_75t_L g66 ( 
.A(n_65),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_64),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_67),
.Y(n_68)
);

INVxp67_ASAP7_75t_L g69 ( 
.A(n_66),
.Y(n_69)
);

HB1xp67_ASAP7_75t_L g70 ( 
.A(n_69),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_70),
.B(n_68),
.Y(n_71)
);

HB1xp67_ASAP7_75t_L g72 ( 
.A(n_71),
.Y(n_72)
);

INVx2_ASAP7_75t_L g73 ( 
.A(n_72),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_73),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_74),
.Y(n_75)
);

AOI21xp5_ASAP7_75t_L g76 ( 
.A1(n_75),
.A2(n_11),
.B(n_10),
.Y(n_76)
);

AOI21x1_ASAP7_75t_L g77 ( 
.A1(n_76),
.A2(n_13),
.B(n_12),
.Y(n_77)
);

OAI21xp5_ASAP7_75t_SL g78 ( 
.A1(n_77),
.A2(n_17),
.B(n_16),
.Y(n_78)
);

AOI21xp5_ASAP7_75t_L g79 ( 
.A1(n_78),
.A2(n_19),
.B(n_18),
.Y(n_79)
);


endmodule