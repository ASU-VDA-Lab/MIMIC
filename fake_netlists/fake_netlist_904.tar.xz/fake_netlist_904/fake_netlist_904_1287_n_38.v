module fake_netlist_904_1287_n_38 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_38);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_38;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_20;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

INVx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_13),
.B(n_3),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_6),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_16),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_19),
.B(n_11),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_19),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_21),
.B(n_0),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_24),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_25),
.B1(n_26),
.B2(n_23),
.C1(n_2),
.C2(n_1),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_29),
.Y(n_32)
);

NAND4xp25_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_31),
.C(n_5),
.D(n_4),
.Y(n_33)
);

NAND3x1_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_8),
.C(n_7),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

CKINVDCx16_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

XNOR2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_9),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_R g38 ( 
.A1(n_37),
.A2(n_36),
.B1(n_15),
.B2(n_12),
.C(n_14),
.Y(n_38)
);


endmodule