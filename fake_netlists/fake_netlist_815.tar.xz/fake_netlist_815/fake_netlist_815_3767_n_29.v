module fake_netlist_815_3767_n_29 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_29);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_29;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_12),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_7),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_15),
.B1(n_18),
.B2(n_16),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_14),
.B2(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

XNOR2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_6),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_14),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_11),
.B1(n_10),
.B2(n_8),
.Y(n_29)
);


endmodule