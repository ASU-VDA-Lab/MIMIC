module fake_netlist_815_3136_n_11 (n_4, n_2, n_3, n_0, n_1, n_11);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_11;

wire n_6;
wire n_10;
wire n_7;
wire n_5;
wire n_9;
wire n_8;

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

AOI21xp5_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_4),
.B(n_0),
.Y(n_6)
);

O2A1O1Ixp33_ASAP7_75t_L g7 ( 
.A1(n_2),
.A2(n_1),
.B(n_3),
.C(n_4),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_0),
.Y(n_9)
);

OAI211xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_7),
.B(n_9),
.C(n_6),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B(n_1),
.Y(n_11)
);


endmodule