module fake_netlist_815_3031_n_30 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_30);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

INVxp33_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

XNOR2xp5_ASAP7_75t_L g17 ( 
.A(n_4),
.B(n_10),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_4),
.Y(n_20)
);

OR2x6_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_5),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_18),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.B1(n_16),
.B2(n_17),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_21),
.B1(n_19),
.B2(n_16),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_23),
.B(n_16),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.B1(n_7),
.B2(n_6),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_2),
.B1(n_0),
.B2(n_8),
.C(n_9),
.Y(n_27)
);

NOR2xp67_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_11),
.Y(n_28)
);

OR3x1_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_13),
.C(n_12),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);


endmodule