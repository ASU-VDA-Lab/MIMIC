module fake_netlist_815_2457_n_37 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_37);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_37;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_11;
wire n_27;

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_0),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_9),
.B(n_2),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_4),
.B(n_1),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_SL g19 ( 
.A1(n_11),
.A2(n_3),
.B(n_1),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_5),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_12),
.B(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_13),
.A2(n_7),
.B1(n_18),
.B2(n_14),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_17),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_20),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_24),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_SL g32 ( 
.A1(n_30),
.A2(n_25),
.B1(n_26),
.B2(n_24),
.Y(n_32)
);

AOI222xp33_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_15),
.B1(n_23),
.B2(n_26),
.C1(n_28),
.C2(n_30),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_31),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

XNOR2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_28),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_34),
.B(n_15),
.Y(n_37)
);


endmodule