module fake_netlist_815_4987_n_8 (n_2, n_0, n_1, n_8);

input n_2;
input n_0;
input n_1;

output n_8;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;

AOI21xp5_ASAP7_75t_L g3 ( 
.A1(n_2),
.A2(n_0),
.B(n_1),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

NAND3xp33_ASAP7_75t_SL g6 ( 
.A(n_5),
.B(n_3),
.C(n_0),
.Y(n_6)
);

OAI322xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_4),
.C1(n_5),
.C2(n_3),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);


endmodule