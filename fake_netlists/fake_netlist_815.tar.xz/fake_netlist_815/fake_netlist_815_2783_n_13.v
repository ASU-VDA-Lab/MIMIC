module fake_netlist_815_2783_n_13 (n_0, n_1, n_13);

input n_0;
input n_1;

output n_13;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

INVx5_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

HB1xp67_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_3),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_3),
.Y(n_9)
);

NAND4xp25_ASAP7_75t_SL g10 ( 
.A(n_8),
.B(n_5),
.C(n_1),
.D(n_0),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.B(n_11),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);


endmodule