module fake_netlist_815_4848_n_32 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

INVx2_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

INVx5_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_6),
.B(n_2),
.Y(n_17)
);

BUFx12f_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

AND2x6_ASAP7_75t_SL g19 ( 
.A(n_15),
.B(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_14),
.B(n_17),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_14),
.B(n_13),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_18),
.Y(n_24)
);

OAI211xp5_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_19),
.B(n_18),
.C(n_6),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_23),
.B1(n_16),
.B2(n_7),
.Y(n_26)
);

NOR3x1_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_7),
.C(n_1),
.Y(n_27)
);

OAI31xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_23),
.A3(n_16),
.B(n_3),
.Y(n_28)
);

NOR3xp33_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_16),
.C(n_8),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_16),
.B(n_9),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

AOI31xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_29),
.A3(n_11),
.B(n_10),
.Y(n_32)
);


endmodule