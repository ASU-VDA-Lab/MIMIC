module fake_netlist_815_1816_n_30 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_30);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_3),
.A2(n_7),
.B1(n_4),
.B2(n_1),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AND2x6_ASAP7_75t_L g11 ( 
.A(n_4),
.B(n_7),
.Y(n_11)
);

OAI22xp33_ASAP7_75t_SL g12 ( 
.A1(n_0),
.A2(n_2),
.B1(n_5),
.B2(n_6),
.Y(n_12)
);

OR2x6_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_1),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_11),
.B(n_12),
.Y(n_16)
);

AO31x2_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_11),
.A3(n_13),
.B(n_9),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

AOI21xp33_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_20),
.B(n_21),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_17),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_16),
.B1(n_17),
.B2(n_21),
.C(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_23),
.B(n_21),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_25),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_27),
.B(n_28),
.Y(n_30)
);


endmodule