module fake_netlist_815_1729_n_16 (n_2, n_0, n_1, n_16);

input n_2;
input n_0;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

AND2x4_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

NAND2x1p5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

INVxp67_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_0),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

NAND2x1_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_4),
.Y(n_8)
);

OAI221xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_7),
.B1(n_8),
.B2(n_4),
.C(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_3),
.Y(n_10)
);

OAI32xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.A3(n_3),
.B1(n_0),
.B2(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AOI221x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_11),
.Y(n_13)
);

OAI222xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_1),
.B1(n_2),
.B2(n_9),
.C1(n_4),
.C2(n_8),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_11),
.B1(n_14),
.B2(n_13),
.Y(n_16)
);


endmodule