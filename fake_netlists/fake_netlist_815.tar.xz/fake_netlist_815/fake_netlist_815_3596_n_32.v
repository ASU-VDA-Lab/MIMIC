module fake_netlist_815_3596_n_32 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

CKINVDCx16_ASAP7_75t_R g14 ( 
.A(n_11),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_13),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_1),
.B(n_10),
.Y(n_17)
);

BUFx10_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_7),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_14),
.B1(n_18),
.B2(n_15),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_23),
.B1(n_16),
.B2(n_17),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

OAI21x1_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_7),
.B(n_0),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AOI322xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_30),
.A3(n_8),
.B1(n_5),
.B2(n_3),
.C1(n_12),
.C2(n_9),
.Y(n_32)
);


endmodule