module fake_netlist_815_760_n_45 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_45);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_45;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_44;
wire n_39;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_7),
.B(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_1),
.B(n_4),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_15),
.A2(n_22),
.B1(n_20),
.B2(n_13),
.Y(n_23)
);

AO21x2_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_4),
.B(n_2),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_6),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_16),
.B(n_3),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_15),
.B(n_8),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_SL g28 ( 
.A(n_22),
.B(n_10),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_17),
.A2(n_11),
.B1(n_12),
.B2(n_19),
.Y(n_29)
);

O2A1O1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_18),
.A2(n_22),
.B(n_15),
.C(n_20),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_23),
.B(n_21),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_27),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_30),
.B(n_14),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_25),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_25),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_27),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_37),
.B1(n_36),
.B2(n_33),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

NOR2x1_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_26),
.Y(n_40)
);

NAND4xp25_ASAP7_75t_SL g41 ( 
.A(n_38),
.B(n_29),
.C(n_34),
.D(n_24),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

BUFx6f_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_24),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_42),
.B1(n_43),
.B2(n_28),
.Y(n_45)
);


endmodule