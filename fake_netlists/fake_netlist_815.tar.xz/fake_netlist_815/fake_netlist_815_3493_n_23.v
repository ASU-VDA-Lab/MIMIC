module fake_netlist_815_3493_n_23 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_23);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_19;
wire n_12;
wire n_18;
wire n_21;
wire n_16;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_5),
.B(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

INVx6_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_6),
.B(n_1),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_3),
.A2(n_9),
.B1(n_6),
.B2(n_10),
.C(n_4),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_7),
.B(n_4),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_2),
.B(n_7),
.Y(n_18)
);

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_15),
.B(n_17),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

NOR4xp25_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.C(n_16),
.D(n_14),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);


endmodule