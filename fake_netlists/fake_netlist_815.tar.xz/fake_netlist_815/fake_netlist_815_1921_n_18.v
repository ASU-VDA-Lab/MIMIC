module fake_netlist_815_1921_n_18 (n_2, n_0, n_3, n_1, n_18);

input n_2;
input n_0;
input n_3;
input n_1;

output n_18;

wire n_6;
wire n_15;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_17;
wire n_9;
wire n_14;
wire n_11;
wire n_12;
wire n_8;

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

AO31x2_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_6),
.A3(n_4),
.B(n_0),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_9),
.Y(n_10)
);

NOR2x1_ASAP7_75t_SL g11 ( 
.A(n_7),
.B(n_0),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_8),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_13),
.B(n_14),
.Y(n_15)
);

NOR4xp75_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.C(n_11),
.D(n_1),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_2),
.B1(n_3),
.B2(n_10),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_3),
.B(n_2),
.Y(n_18)
);


endmodule