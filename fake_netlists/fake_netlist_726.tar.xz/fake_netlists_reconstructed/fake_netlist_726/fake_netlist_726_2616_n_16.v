module fake_netlist_726_2616_n_16 (n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_16);

input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_16;

wire n_12;
wire n_8;
wire n_10;
wire n_15;
wire n_14;
wire n_13;
wire n_9;
wire n_11;

AND2x4_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

AND2x6_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_2),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_1),
.Y(n_13)
);

OAI21xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_7),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_7),
.Y(n_15)
);

OAI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B(n_3),
.Y(n_16)
);


endmodule