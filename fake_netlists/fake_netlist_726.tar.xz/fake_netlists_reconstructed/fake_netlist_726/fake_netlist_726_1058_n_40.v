module fake_netlist_726_1058_n_40 (n_8, n_1, n_2, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_40);

input n_8;
input n_1;
input n_2;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_40;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_39;
wire n_11;
wire n_25;
wire n_12;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_38;
wire n_34;
wire n_16;
wire n_22;
wire n_19;

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_1),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

NOR4xp25_ASAP7_75t_SL g18 ( 
.A(n_13),
.B(n_16),
.C(n_15),
.D(n_12),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_0),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

AOI21x1_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_1),
.B(n_0),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_11),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_22)
);

INVx3_ASAP7_75t_SL g23 ( 
.A(n_18),
.Y(n_23)
);

NOR2x1_ASAP7_75t_R g24 ( 
.A(n_20),
.B(n_17),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_21),
.B(n_14),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_23),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_20),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_22),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_SL g29 ( 
.A(n_26),
.B(n_19),
.Y(n_29)
);

OAI211xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_11),
.B(n_17),
.C(n_21),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_24),
.B1(n_28),
.B2(n_14),
.C1(n_3),
.C2(n_2),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_29),
.B(n_25),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_14),
.B1(n_6),
.B2(n_4),
.Y(n_33)
);

CKINVDCx16_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

CKINVDCx16_ASAP7_75t_R g35 ( 
.A(n_31),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_14),
.C(n_6),
.Y(n_36)
);

OAI22xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_8),
.B1(n_10),
.B2(n_34),
.Y(n_37)
);

INVxp33_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_10),
.B1(n_39),
.B2(n_37),
.Y(n_40)
);


endmodule