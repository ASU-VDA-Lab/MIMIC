module fake_netlist_726_1309_n_25 (n_1, n_2, n_6, n_0, n_3, n_4, n_5, n_25);

input n_1;
input n_2;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_25;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_7;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_8;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_1),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_8),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_7),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_11),
.Y(n_16)
);

OAI31xp33_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_12),
.A3(n_4),
.B(n_1),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

O2A1O1Ixp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B(n_15),
.C(n_17),
.Y(n_19)
);

NAND4xp25_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_17),
.C(n_16),
.D(n_4),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_6),
.B1(n_2),
.B2(n_0),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_6),
.B1(n_5),
.B2(n_3),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_6),
.B1(n_21),
.B2(n_23),
.Y(n_25)
);


endmodule