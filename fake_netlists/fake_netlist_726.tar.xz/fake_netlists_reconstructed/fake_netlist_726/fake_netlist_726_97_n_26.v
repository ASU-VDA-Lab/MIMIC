module fake_netlist_726_97_n_26 (n_12, n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_26);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_26;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_25;
wire n_23;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_3),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_6),
.A2(n_7),
.B1(n_8),
.B2(n_2),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

OAI21x1_ASAP7_75t_SL g18 ( 
.A1(n_16),
.A2(n_7),
.B(n_6),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_13),
.B1(n_17),
.B2(n_15),
.C(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

O2A1O1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B(n_21),
.C(n_0),
.Y(n_23)
);

OA21x2_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_5),
.B(n_4),
.Y(n_24)
);

INVxp33_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_25),
.B(n_10),
.Y(n_26)
);


endmodule