module fake_netlist_726_823_n_20 (n_8, n_1, n_2, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_20);

input n_8;
input n_1;
input n_2;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_20;

wire n_14;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_15;
wire n_16;
wire n_19;

INVx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_2),
.B(n_8),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_5),
.B(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

OA21x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_9),
.B(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B(n_12),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_12),
.B1(n_13),
.B2(n_11),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI222xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_6),
.B1(n_7),
.B2(n_10),
.C1(n_14),
.C2(n_11),
.Y(n_20)
);


endmodule