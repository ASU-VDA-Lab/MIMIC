module fake_netlist_726_4125_n_11 (n_1, n_2, n_0, n_3, n_4, n_5, n_11);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;
input n_5;

output n_11;

wire n_8;
wire n_7;
wire n_10;
wire n_9;
wire n_6;

INVx3_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_3),
.A2(n_2),
.B1(n_0),
.B2(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_6),
.B1(n_7),
.B2(n_0),
.C(n_4),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_5),
.B1(n_6),
.B2(n_7),
.Y(n_11)
);


endmodule