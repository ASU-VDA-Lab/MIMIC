module fake_netlist_726_28_n_17 (n_1, n_2, n_0, n_3, n_4, n_5, n_17);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;
input n_5;

output n_17;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_15;
wire n_16;
wire n_6;
wire n_14;

NOR2xp33_ASAP7_75t_R g6 ( 
.A(n_1),
.B(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_0),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_4),
.B(n_2),
.Y(n_10)
);

NAND2xp33_ASAP7_75t_R g11 ( 
.A(n_9),
.B(n_6),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OA211x2_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_5),
.B(n_4),
.C(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AO22x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_5),
.B1(n_10),
.B2(n_12),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);


endmodule