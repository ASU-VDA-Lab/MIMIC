module fake_netlist_726_1620_n_5 (n_0, n_5);

input n_0;

output n_5;

wire n_1;
wire n_2;
wire n_3;
wire n_4;

BUFx4f_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

INVx2_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

OAI21xp5_ASAP7_75t_L g3 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_3)
);

NOR3xp33_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.C(n_2),
.Y(n_4)
);

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B1(n_3),
.B2(n_2),
.Y(n_5)
);


endmodule