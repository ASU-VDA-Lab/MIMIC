module fake_netlist_726_2315_n_18 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_18);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_18;

wire n_12;
wire n_10;
wire n_15;
wire n_14;
wire n_17;
wire n_13;
wire n_16;
wire n_11;

NOR2x1p5_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

OR2x6_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_9),
.Y(n_12)
);

OAI21x1_ASAP7_75t_SL g13 ( 
.A1(n_11),
.A2(n_7),
.B(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_12),
.B1(n_10),
.B2(n_2),
.Y(n_15)
);

NOR4xp75_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_12),
.C(n_6),
.D(n_3),
.Y(n_16)
);

XOR2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_8),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);


endmodule