module fake_netlist_726_3665_n_5 (n_0, n_1, n_5);

input n_0;
input n_1;

output n_5;

wire n_2;
wire n_3;
wire n_4;

INVx3_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

AOI211xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_2),
.C(n_0),
.Y(n_4)
);

CKINVDCx16_ASAP7_75t_R g5 ( 
.A(n_4),
.Y(n_5)
);


endmodule