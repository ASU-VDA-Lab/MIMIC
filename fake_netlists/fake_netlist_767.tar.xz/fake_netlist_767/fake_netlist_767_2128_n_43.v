module fake_netlist_767_2128_n_43 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_43);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_43;

wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_41;
wire n_29;
wire n_32;

INVxp67_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_7),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_10),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_19),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_18),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_19),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_32)
);

XOR2x2_ASAP7_75t_SL g33 ( 
.A(n_31),
.B(n_29),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_30),
.Y(n_34)
);

NOR2x1_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_27),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_33),
.B1(n_22),
.B2(n_23),
.Y(n_36)
);

O2A1O1Ixp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_32),
.B(n_28),
.C(n_24),
.Y(n_37)
);

NAND4xp75_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_6),
.C(n_5),
.D(n_4),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_8),
.Y(n_39)
);

AOI222xp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_12),
.B1(n_11),
.B2(n_13),
.C1(n_16),
.C2(n_14),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx5_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_17),
.B1(n_20),
.B2(n_41),
.Y(n_43)
);


endmodule