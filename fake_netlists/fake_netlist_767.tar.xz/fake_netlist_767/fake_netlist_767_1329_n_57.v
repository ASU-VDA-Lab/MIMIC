module fake_netlist_767_1329_n_57 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_57);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_57;

wire n_20;
wire n_23;
wire n_46;
wire n_14;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_42;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_56;
wire n_19;
wire n_15;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_10),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_5),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_18),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_24)
);

BUFx12f_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

INVx5_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_17),
.B(n_3),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

BUFx3_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_18),
.B(n_4),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_21),
.B1(n_19),
.B2(n_16),
.C(n_22),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_25),
.A2(n_22),
.B1(n_16),
.B2(n_23),
.Y(n_33)
);

BUFx12f_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_19),
.B1(n_23),
.B2(n_15),
.C(n_20),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_29),
.Y(n_36)
);

OR2x6_ASAP7_75t_SL g37 ( 
.A(n_28),
.B(n_4),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_26),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_32),
.A2(n_30),
.B1(n_29),
.B2(n_27),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_26),
.B(n_29),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_35),
.Y(n_42)
);

NAND2xp33_ASAP7_75t_SL g43 ( 
.A(n_39),
.B(n_29),
.Y(n_43)
);

INVx2_ASAP7_75t_SL g44 ( 
.A(n_40),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_38),
.A2(n_25),
.B1(n_29),
.B2(n_26),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_28),
.Y(n_46)
);

O2A1O1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_27),
.B(n_30),
.C(n_24),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_37),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_43),
.B(n_34),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

OAI22xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_37),
.B1(n_48),
.B2(n_46),
.Y(n_51)
);

OAI221xp5_ASAP7_75t_L g52 ( 
.A1(n_46),
.A2(n_43),
.B1(n_24),
.B2(n_30),
.C(n_41),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_38),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_6),
.Y(n_54)
);

AOI221xp5_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_52),
.B1(n_23),
.B2(n_26),
.C(n_36),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_23),
.Y(n_56)
);

AOI222xp33_ASAP7_75t_L g57 ( 
.A1(n_55),
.A2(n_7),
.B1(n_8),
.B2(n_26),
.C1(n_36),
.C2(n_56),
.Y(n_57)
);


endmodule