module fake_netlist_767_1583_n_27 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_27);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_27;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_24;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

INVx3_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_SL g15 ( 
.A1(n_0),
.A2(n_8),
.B1(n_4),
.B2(n_10),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_13),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B1(n_19),
.B2(n_17),
.Y(n_23)
);

OAI211xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_14),
.B(n_16),
.C(n_18),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OAI22x1_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_16),
.B1(n_7),
.B2(n_2),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_11),
.C(n_9),
.Y(n_27)
);


endmodule