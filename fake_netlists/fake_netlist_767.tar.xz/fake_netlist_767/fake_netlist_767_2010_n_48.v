module fake_netlist_767_2010_n_48 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_48);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_48;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVx2_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_1),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

AND3x1_ASAP7_75t_L g22 ( 
.A(n_1),
.B(n_6),
.C(n_2),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_0),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_16),
.A2(n_12),
.B(n_8),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_16),
.B(n_0),
.Y(n_26)
);

INVx2_ASAP7_75t_SL g27 ( 
.A(n_16),
.Y(n_27)
);

BUFx8_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_22),
.A2(n_24),
.B1(n_19),
.B2(n_17),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_23),
.B(n_18),
.Y(n_30)
);

AO21x1_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_23),
.B(n_22),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_20),
.Y(n_32)
);

AOI322xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_21),
.A3(n_28),
.B1(n_4),
.B2(n_5),
.C1(n_2),
.C2(n_3),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_32),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_28),
.Y(n_38)
);

OAI21xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_33),
.B(n_25),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_36),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_3),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

CKINVDCx14_ASAP7_75t_R g43 ( 
.A(n_41),
.Y(n_43)
);

INVxp67_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

OAI211xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_7),
.B(n_5),
.C(n_14),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_42),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_R g48 ( 
.A1(n_47),
.A2(n_44),
.B1(n_45),
.B2(n_15),
.Y(n_48)
);


endmodule