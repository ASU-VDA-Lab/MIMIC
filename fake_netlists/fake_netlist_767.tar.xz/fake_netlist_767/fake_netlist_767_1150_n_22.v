module fake_netlist_767_1150_n_22 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_22);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;

output n_22;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_9;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_R g9 ( 
.A(n_4),
.B(n_5),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_2),
.B(n_0),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_2),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_8),
.B(n_6),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_7),
.B(n_6),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

OA21x2_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_9),
.B(n_10),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_6),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_14),
.B1(n_15),
.B2(n_12),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B(n_15),
.C(n_7),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_15),
.B1(n_7),
.B2(n_0),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_20),
.B1(n_3),
.B2(n_1),
.Y(n_22)
);


endmodule