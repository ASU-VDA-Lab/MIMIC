module fake_netlist_767_713_n_57 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_57);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_57;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_42;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_41;
wire n_19;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_5),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_2),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_11),
.B(n_10),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_4),
.B(n_8),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_13),
.B(n_12),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_1),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

BUFx4f_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_20),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_33)
);

BUFx12f_ASAP7_75t_L g34 ( 
.A(n_21),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_24),
.B(n_16),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_22),
.B(n_25),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_L g37 ( 
.A1(n_32),
.A2(n_22),
.B(n_23),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_31),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_34),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_34),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_32),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_30),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_43),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_39),
.B1(n_32),
.B2(n_40),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_39),
.Y(n_47)
);

OAI21xp33_ASAP7_75t_SL g48 ( 
.A1(n_46),
.A2(n_36),
.B(n_26),
.Y(n_48)
);

AOI321xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_33),
.A3(n_27),
.B1(n_31),
.B2(n_38),
.C(n_19),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_45),
.Y(n_50)
);

OA22x2_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_21),
.B1(n_17),
.B2(n_16),
.Y(n_51)
);

NAND4xp75_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_51),
.C(n_49),
.D(n_50),
.Y(n_52)
);

XOR2xp5_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_17),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);

AND3x4_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_28),
.C(n_0),
.Y(n_55)
);

AOI21xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_7),
.B(n_3),
.Y(n_56)
);

XNOR2xp5_ASAP7_75t_L g57 ( 
.A(n_56),
.B(n_54),
.Y(n_57)
);


endmodule