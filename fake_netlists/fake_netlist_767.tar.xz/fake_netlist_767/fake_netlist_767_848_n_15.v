module fake_netlist_767_848_n_15 (n_1, n_2, n_3, n_4, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

AND2x2_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_4),
.Y(n_6)
);

AO31x2_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_7)
);

O2A1O1Ixp5_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_2),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

OAI31xp33_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_8),
.A3(n_7),
.B(n_4),
.Y(n_11)
);

OA21x2_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_7),
.B(n_4),
.Y(n_12)
);

OAI221xp5_ASAP7_75t_SL g13 ( 
.A1(n_11),
.A2(n_3),
.B1(n_9),
.B2(n_10),
.C(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_10),
.B1(n_13),
.B2(n_2),
.C1(n_0),
.C2(n_1),
.Y(n_15)
);


endmodule