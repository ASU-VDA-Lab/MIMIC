module fake_netlist_767_1331_n_25 (n_1, n_2, n_3, n_4, n_0, n_25);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_25;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_24;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

AO21x2_ASAP7_75t_L g5 ( 
.A1(n_0),
.A2(n_2),
.B(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVxp67_ASAP7_75t_SL g8 ( 
.A(n_1),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

OA21x2_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_3),
.B(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_11),
.Y(n_12)
);

AO31x2_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_7),
.A3(n_8),
.B(n_3),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

NAND2x1_ASAP7_75t_SL g15 ( 
.A(n_12),
.B(n_9),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_9),
.C(n_10),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.C(n_9),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_9),
.B1(n_10),
.B2(n_13),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_9),
.C(n_10),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_13),
.Y(n_20)
);

O2A1O1Ixp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_19),
.B(n_13),
.C(n_10),
.Y(n_21)
);

NOR2xp67_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_4),
.Y(n_22)
);

AO22x2_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_10),
.B1(n_13),
.B2(n_22),
.Y(n_23)
);

XNOR2x1_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_10),
.Y(n_24)
);

AO21x2_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_24),
.B(n_21),
.Y(n_25)
);


endmodule