module fake_netlist_767_1512_n_21 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_21);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;

output n_21;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_9;
wire n_17;
wire n_15;
wire n_12;
wire n_19;
wire n_8;

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_0),
.B(n_1),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_5),
.B(n_4),
.C(n_0),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_3),
.B(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B1(n_13),
.B2(n_12),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI21xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_15),
.B(n_11),
.Y(n_18)
);

XOR2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_6),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI22x1_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_7),
.B1(n_19),
.B2(n_8),
.Y(n_21)
);


endmodule