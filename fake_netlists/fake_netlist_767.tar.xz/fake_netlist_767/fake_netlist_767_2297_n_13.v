module fake_netlist_767_2297_n_13 (n_0, n_2, n_1, n_13);

input n_0;
input n_2;
input n_1;

output n_13;

wire n_12;
wire n_3;
wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_2),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

OAI21xp33_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_5),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.Y(n_9)
);

NOR3xp33_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_7),
.C(n_0),
.Y(n_10)
);

OAI221xp5_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_8),
.B1(n_6),
.B2(n_1),
.C(n_2),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_2),
.B2(n_10),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_11),
.B1(n_1),
.B2(n_2),
.Y(n_13)
);


endmodule