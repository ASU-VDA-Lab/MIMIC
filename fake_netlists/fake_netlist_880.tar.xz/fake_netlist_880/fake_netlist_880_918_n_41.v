module fake_netlist_880_918_n_41 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_41);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_41;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_25;
wire n_35;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_16),
.B(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_17),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_6),
.B(n_12),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_9),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_10),
.Y(n_29)
);

A2O1A1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_11),
.B(n_22),
.C(n_21),
.Y(n_30)
);

AO32x1_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_11),
.A3(n_21),
.B1(n_8),
.B2(n_0),
.Y(n_31)
);

BUFx3_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_28),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_33),
.B1(n_28),
.B2(n_26),
.Y(n_35)
);

OAI211xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_24),
.B(n_27),
.C(n_29),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

AOI21xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_13),
.B(n_5),
.Y(n_38)
);

AO22x2_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_19),
.B1(n_14),
.B2(n_15),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_20),
.B1(n_4),
.B2(n_3),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_40),
.B1(n_2),
.B2(n_1),
.Y(n_41)
);


endmodule