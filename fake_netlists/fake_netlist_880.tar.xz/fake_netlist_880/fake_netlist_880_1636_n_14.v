module fake_netlist_880_1636_n_14 (n_0, n_2, n_3, n_4, n_1, n_14);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_14;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_2),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_7),
.B1(n_9),
.B2(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_0),
.B1(n_3),
.B2(n_4),
.Y(n_14)
);


endmodule