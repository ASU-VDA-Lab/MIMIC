module fake_netlist_880_2015_n_29 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_29);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_29;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_4),
.A2(n_1),
.B(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_5),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_18),
.B(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_20),
.B(n_18),
.Y(n_22)
);

OAI332xp33_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_21),
.A3(n_2),
.B1(n_0),
.B2(n_3),
.B3(n_16),
.C1(n_15),
.C2(n_17),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_R g24 ( 
.A(n_23),
.B(n_14),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AO22x1_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_3),
.B1(n_0),
.B2(n_14),
.Y(n_27)
);

INVx8_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

OAI221xp5_ASAP7_75t_R g29 ( 
.A1(n_28),
.A2(n_12),
.B1(n_13),
.B2(n_9),
.C(n_10),
.Y(n_29)
);


endmodule