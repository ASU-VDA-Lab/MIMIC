module fake_netlist_880_866_n_46 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_46);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_46;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_42;
wire n_41;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_45;
wire n_44;
wire n_38;

INVx3_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

OA21x2_ASAP7_75t_L g24 ( 
.A1(n_9),
.A2(n_19),
.B(n_14),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_8),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_12),
.B(n_20),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_20),
.Y(n_30)
);

INVx4_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_21),
.B(n_25),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_22),
.B1(n_27),
.B2(n_24),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_30),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_32),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

XOR2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_23),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_27),
.B1(n_29),
.B2(n_26),
.C(n_10),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_24),
.B(n_18),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_16),
.B1(n_11),
.B2(n_7),
.Y(n_45)
);

AOI322xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_44),
.A3(n_6),
.B1(n_0),
.B2(n_2),
.C1(n_1),
.C2(n_17),
.Y(n_46)
);


endmodule