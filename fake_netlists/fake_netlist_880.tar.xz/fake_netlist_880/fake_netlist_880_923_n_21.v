module fake_netlist_880_923_n_21 (n_0, n_2, n_3, n_4, n_1, n_21);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_21;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_19;
wire n_12;
wire n_5;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_4),
.B1(n_0),
.B2(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_2),
.Y(n_8)
);

OAI22x1_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_7),
.B1(n_6),
.B2(n_1),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_SL g10 ( 
.A1(n_7),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.C(n_2),
.Y(n_10)
);

INVxp67_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_3),
.B1(n_4),
.B2(n_2),
.C(n_0),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_1),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_10),
.C(n_8),
.Y(n_14)
);

OAI21xp33_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_4),
.B(n_3),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B(n_13),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_13),
.B(n_4),
.Y(n_17)
);

NOR4xp75_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_3),
.C(n_4),
.D(n_2),
.Y(n_18)
);

NOR2x1_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_0),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_16),
.B1(n_0),
.B2(n_1),
.Y(n_20)
);

OAI222xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_0),
.B1(n_1),
.B2(n_19),
.C1(n_5),
.C2(n_18),
.Y(n_21)
);


endmodule