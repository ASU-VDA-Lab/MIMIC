module fake_netlist_880_2136_n_37 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_37);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_37;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_31;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_32;
wire n_35;
wire n_26;
wire n_10;
wire n_29;
wire n_36;

INVx1_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_1),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

INVxp33_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_6),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_6),
.B1(n_5),
.B2(n_8),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_10),
.A2(n_8),
.B1(n_2),
.B2(n_4),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_15),
.B(n_11),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_9),
.B(n_13),
.C(n_12),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NOR2x1p5_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_9),
.Y(n_23)
);

AND2x2_ASAP7_75t_SL g24 ( 
.A(n_18),
.B(n_12),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_21),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_27),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_24),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_19),
.B1(n_17),
.B2(n_10),
.C(n_23),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_0),
.C(n_1),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AO22x2_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_0),
.B1(n_4),
.B2(n_17),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVxp67_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_33),
.B1(n_34),
.B2(n_35),
.Y(n_37)
);


endmodule