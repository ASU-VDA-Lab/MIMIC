module fake_netlist_880_1579_n_22 (n_0, n_2, n_5, n_3, n_4, n_1, n_22);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_22;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_21;
wire n_14;
wire n_10;
wire n_8;

NAND3xp33_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_0),
.C(n_4),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

A2O1A1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_3),
.C(n_0),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_10),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_11),
.C(n_9),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_12),
.B(n_13),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_13),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_8),
.B1(n_4),
.B2(n_5),
.Y(n_18)
);

NAND4xp25_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_8),
.C(n_2),
.D(n_0),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_17),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_20),
.B1(n_19),
.B2(n_5),
.C(n_4),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_2),
.B1(n_3),
.B2(n_20),
.Y(n_22)
);


endmodule