module fake_netlist_880_1637_n_65 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_65);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_65;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_63;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_21;
wire n_42;
wire n_32;
wire n_35;
wire n_41;
wire n_22;
wire n_25;
wire n_57;
wire n_43;
wire n_62;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;
wire n_56;

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_16),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

INVx4_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

CKINVDCx11_ASAP7_75t_R g25 ( 
.A(n_19),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

BUFx8_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

BUFx8_ASAP7_75t_L g28 ( 
.A(n_10),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_13),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_12),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_8),
.B(n_6),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_24),
.A2(n_18),
.B1(n_10),
.B2(n_16),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

INVx5_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_28),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_26),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

O2A1O1Ixp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_21),
.B(n_29),
.C(n_30),
.Y(n_40)
);

AO31x2_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_31),
.A3(n_28),
.B(n_27),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx3_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_38),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_41),
.Y(n_46)
);

AO21x2_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_40),
.B(n_41),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_43),
.B1(n_32),
.B2(n_22),
.Y(n_48)
);

AOI21xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_45),
.B(n_46),
.Y(n_49)
);

OR3x2_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_32),
.C(n_25),
.Y(n_50)
);

OAI321xp33_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_34),
.A3(n_28),
.B1(n_41),
.B2(n_19),
.C(n_20),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

A2O1A1Ixp33_ASAP7_75t_L g53 ( 
.A1(n_48),
.A2(n_46),
.B(n_36),
.C(n_34),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_49),
.A2(n_46),
.B(n_47),
.Y(n_55)
);

OR5x1_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_47),
.C(n_34),
.D(n_27),
.E(n_22),
.Y(n_56)
);

NOR5xp2_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_46),
.C(n_27),
.D(n_23),
.E(n_36),
.Y(n_57)
);

CKINVDCx5p33_ASAP7_75t_R g58 ( 
.A(n_52),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_54),
.B(n_23),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_59),
.B(n_55),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_L g61 ( 
.A1(n_58),
.A2(n_14),
.B1(n_9),
.B2(n_7),
.Y(n_61)
);

AOI22xp5_ASAP7_75t_L g62 ( 
.A1(n_56),
.A2(n_57),
.B1(n_15),
.B2(n_4),
.Y(n_62)
);

CKINVDCx20_ASAP7_75t_R g63 ( 
.A(n_61),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_60),
.Y(n_64)
);

AOI322xp5_ASAP7_75t_L g65 ( 
.A1(n_63),
.A2(n_0),
.A3(n_2),
.B1(n_3),
.B2(n_57),
.C1(n_62),
.C2(n_64),
.Y(n_65)
);


endmodule