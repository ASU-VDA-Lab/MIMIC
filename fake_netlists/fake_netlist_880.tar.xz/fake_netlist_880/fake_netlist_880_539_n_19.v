module fake_netlist_880_539_n_19 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_19);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_19;

wire n_15;
wire n_11;
wire n_16;
wire n_12;
wire n_17;
wire n_18;
wire n_13;
wire n_14;

INVx4_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_6),
.B(n_10),
.Y(n_13)
);

OA21x2_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_1),
.B(n_4),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_13),
.B(n_11),
.Y(n_15)
);

OAI33xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.A3(n_1),
.B1(n_4),
.B2(n_2),
.B3(n_0),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B1(n_11),
.B2(n_3),
.C(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_3),
.B1(n_8),
.B2(n_9),
.C(n_7),
.Y(n_19)
);


endmodule