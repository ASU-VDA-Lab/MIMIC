module fake_netlist_880_1786_n_33 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_33);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_33;

wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_22;
wire n_25;
wire n_32;
wire n_26;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_6),
.B(n_5),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_9),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_12),
.B(n_13),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_15),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_17),
.A2(n_15),
.B1(n_14),
.B2(n_8),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_24),
.B(n_18),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_23),
.Y(n_28)
);

OAI33xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.A3(n_25),
.B1(n_16),
.B2(n_20),
.B3(n_19),
.Y(n_29)
);

O2A1O1Ixp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_21),
.B(n_10),
.C(n_7),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_33)
);


endmodule