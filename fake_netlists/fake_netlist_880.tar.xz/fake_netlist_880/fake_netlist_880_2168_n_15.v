module fake_netlist_880_2168_n_15 (n_0, n_1, n_2, n_15);

input n_0;
input n_1;
input n_2;

output n_15;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

BUFx6f_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

CKINVDCx11_ASAP7_75t_R g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

OAI33xp33_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_4),
.A3(n_3),
.B1(n_0),
.B2(n_2),
.B3(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_3),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_5),
.C(n_2),
.Y(n_11)
);

AOI221x1_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_5),
.B1(n_2),
.B2(n_1),
.C(n_0),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_10),
.B1(n_11),
.B2(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_1),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_0),
.B1(n_2),
.B2(n_13),
.C1(n_8),
.C2(n_4),
.Y(n_15)
);


endmodule