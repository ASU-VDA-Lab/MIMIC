module fake_netlist_880_1403_n_33 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_33);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_33;

wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_25;
wire n_22;
wire n_32;
wire n_26;
wire n_29;

INVx3_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_8),
.B(n_1),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_7),
.B(n_13),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_4),
.B(n_12),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

INVx6_ASAP7_75t_L g22 ( 
.A(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

INVx5_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_11),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_19),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_21),
.B1(n_25),
.B2(n_23),
.Y(n_27)
);

AND2x2_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_20),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_18),
.Y(n_29)
);

NAND5xp2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_3),
.C(n_9),
.D(n_2),
.E(n_6),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_10),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);


endmodule