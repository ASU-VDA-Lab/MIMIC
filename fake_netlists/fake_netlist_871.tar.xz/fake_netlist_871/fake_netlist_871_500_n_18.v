module fake_netlist_871_500_n_18 (n_0, n_2, n_3, n_4, n_1, n_18);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_18;

wire n_5;
wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_17;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_3),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

BUFx2_ASAP7_75t_SL g8 ( 
.A(n_5),
.Y(n_8)
);

OAI21x1_ASAP7_75t_SL g9 ( 
.A1(n_5),
.A2(n_7),
.B(n_0),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_SL g10 ( 
.A(n_8),
.B(n_6),
.C(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI211xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_9),
.B(n_3),
.C(n_2),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_11),
.B(n_9),
.C(n_0),
.Y(n_14)
);

OA22x2_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_12),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_1),
.B1(n_11),
.B2(n_17),
.Y(n_18)
);


endmodule