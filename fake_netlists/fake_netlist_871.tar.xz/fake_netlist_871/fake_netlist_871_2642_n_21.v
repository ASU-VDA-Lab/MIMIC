module fake_netlist_871_2642_n_21 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_21;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

CKINVDCx16_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_6),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_0),
.Y(n_11)
);

OAI22x1_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_9),
.Y(n_13)
);

NOR4xp25_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.C(n_12),
.D(n_8),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

CKINVDCx14_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

OAI32xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_15),
.A3(n_10),
.B1(n_13),
.B2(n_2),
.Y(n_18)
);

OA22x2_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_13),
.B1(n_18),
.B2(n_4),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_5),
.B1(n_6),
.B2(n_20),
.Y(n_21)
);


endmodule