module fake_netlist_871_2536_n_11 (n_0, n_1, n_3, n_2, n_11);

input n_0;
input n_1;
input n_3;
input n_2;

output n_11;

wire n_5;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

NOR2xp33_ASAP7_75t_SL g4 ( 
.A(n_2),
.B(n_3),
.Y(n_4)
);

BUFx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

AOI221xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.C(n_0),
.Y(n_7)
);

NOR5xp2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_4),
.C(n_6),
.D(n_0),
.E(n_2),
.Y(n_8)
);

AOI221xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_1),
.B1(n_3),
.B2(n_9),
.Y(n_11)
);


endmodule