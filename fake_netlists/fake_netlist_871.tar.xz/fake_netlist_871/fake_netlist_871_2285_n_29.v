module fake_netlist_871_2285_n_29 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_29);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_29;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

INVx1_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_7),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_17),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_20),
.B1(n_15),
.B2(n_14),
.C(n_18),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

NOR2xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_21),
.Y(n_25)
);

OA22x2_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_18),
.B1(n_7),
.B2(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI322xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_25),
.A3(n_6),
.B1(n_5),
.B2(n_1),
.C1(n_9),
.C2(n_8),
.Y(n_29)
);


endmodule