module fake_netlist_871_539_n_21 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_21;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_14;
wire n_10;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_2),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_5),
.B(n_4),
.C(n_1),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI32xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.A3(n_13),
.B1(n_10),
.B2(n_12),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_8),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_17),
.A2(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_6),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_0),
.B1(n_7),
.B2(n_19),
.Y(n_21)
);


endmodule