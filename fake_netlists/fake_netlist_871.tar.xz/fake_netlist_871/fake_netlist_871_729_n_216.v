module fake_netlist_871_729_n_216 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_26, n_10, n_8, n_216);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_26;
input n_10;
input n_8;

output n_216;

wire n_118;
wire n_100;
wire n_60;
wire n_104;
wire n_101;
wire n_52;
wire n_99;
wire n_127;
wire n_152;
wire n_151;
wire n_111;
wire n_154;
wire n_185;
wire n_153;
wire n_193;
wire n_30;
wire n_116;
wire n_164;
wire n_64;
wire n_102;
wire n_93;
wire n_157;
wire n_66;
wire n_65;
wire n_143;
wire n_88;
wire n_186;
wire n_195;
wire n_169;
wire n_192;
wire n_197;
wire n_212;
wire n_94;
wire n_198;
wire n_182;
wire n_206;
wire n_214;
wire n_91;
wire n_71;
wire n_135;
wire n_174;
wire n_80;
wire n_149;
wire n_29;
wire n_201;
wire n_196;
wire n_69;
wire n_83;
wire n_207;
wire n_210;
wire n_134;
wire n_96;
wire n_128;
wire n_117;
wire n_131;
wire n_165;
wire n_190;
wire n_51;
wire n_50;
wire n_162;
wire n_55;
wire n_123;
wire n_110;
wire n_46;
wire n_183;
wire n_144;
wire n_54;
wire n_211;
wire n_59;
wire n_189;
wire n_177;
wire n_173;
wire n_166;
wire n_70;
wire n_40;
wire n_39;
wire n_132;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_126;
wire n_62;
wire n_120;
wire n_148;
wire n_141;
wire n_150;
wire n_188;
wire n_44;
wire n_79;
wire n_187;
wire n_87;
wire n_142;
wire n_159;
wire n_115;
wire n_155;
wire n_33;
wire n_184;
wire n_113;
wire n_200;
wire n_129;
wire n_191;
wire n_208;
wire n_209;
wire n_172;
wire n_77;
wire n_107;
wire n_199;
wire n_95;
wire n_204;
wire n_53;
wire n_161;
wire n_180;
wire n_106;
wire n_137;
wire n_90;
wire n_167;
wire n_146;
wire n_81;
wire n_84;
wire n_171;
wire n_140;
wire n_61;
wire n_130;
wire n_122;
wire n_43;
wire n_138;
wire n_170;
wire n_136;
wire n_139;
wire n_48;
wire n_72;
wire n_176;
wire n_181;
wire n_133;
wire n_76;
wire n_38;
wire n_56;
wire n_175;
wire n_213;
wire n_74;
wire n_125;
wire n_34;
wire n_179;
wire n_103;
wire n_37;
wire n_160;
wire n_108;
wire n_75;
wire n_47;
wire n_68;
wire n_158;
wire n_86;
wire n_63;
wire n_163;
wire n_105;
wire n_215;
wire n_114;
wire n_124;
wire n_145;
wire n_85;
wire n_112;
wire n_156;
wire n_205;
wire n_49;
wire n_58;
wire n_109;
wire n_147;
wire n_168;
wire n_67;
wire n_202;
wire n_35;
wire n_57;
wire n_121;
wire n_98;
wire n_97;
wire n_119;
wire n_178;
wire n_203;
wire n_36;
wire n_194;
wire n_45;
wire n_73;
wire n_89;
wire n_92;
wire n_82;
wire n_78;

CKINVDCx14_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_14),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_8),
.Y(n_32)
);

CKINVDCx16_ASAP7_75t_R g33 ( 
.A(n_6),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_5),
.Y(n_35)
);

INVxp33_ASAP7_75t_L g36 ( 
.A(n_4),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_12),
.Y(n_37)
);

INVxp33_ASAP7_75t_L g38 ( 
.A(n_13),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_11),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_4),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_18),
.Y(n_41)
);

BUFx6f_ASAP7_75t_L g42 ( 
.A(n_31),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_31),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_33),
.B(n_0),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_36),
.B(n_29),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_30),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_30),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_35),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_42),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

CKINVDCx14_ASAP7_75t_R g52 ( 
.A(n_45),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_43),
.B(n_34),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_43),
.B(n_34),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_SL g55 ( 
.A(n_44),
.B(n_38),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_SL g56 ( 
.A(n_44),
.B(n_32),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_42),
.B(n_37),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_42),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_52),
.B(n_48),
.Y(n_59)
);

INVx3_ASAP7_75t_SL g60 ( 
.A(n_56),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_53),
.Y(n_61)
);

AND3x1_ASAP7_75t_L g62 ( 
.A(n_54),
.B(n_40),
.C(n_35),
.Y(n_62)
);

INVx4_ASAP7_75t_L g63 ( 
.A(n_50),
.Y(n_63)
);

AOI21xp5_ASAP7_75t_L g64 ( 
.A1(n_57),
.A2(n_41),
.B(n_37),
.Y(n_64)
);

BUFx6f_ASAP7_75t_L g65 ( 
.A(n_50),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_49),
.Y(n_66)
);

NAND2xp5_ASAP7_75t_L g67 ( 
.A(n_58),
.B(n_41),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_55),
.B(n_56),
.Y(n_68)
);

AOI22xp33_ASAP7_75t_L g69 ( 
.A1(n_55),
.A2(n_32),
.B1(n_40),
.B2(n_39),
.Y(n_69)
);

HB1xp67_ASAP7_75t_L g70 ( 
.A(n_51),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_52),
.B(n_0),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_53),
.Y(n_72)
);

BUFx4f_ASAP7_75t_L g73 ( 
.A(n_60),
.Y(n_73)
);

AND2x2_ASAP7_75t_L g74 ( 
.A(n_61),
.B(n_72),
.Y(n_74)
);

INVx1_ASAP7_75t_SL g75 ( 
.A(n_60),
.Y(n_75)
);

BUFx2_ASAP7_75t_L g76 ( 
.A(n_60),
.Y(n_76)
);

NAND2xp5_ASAP7_75t_L g77 ( 
.A(n_61),
.B(n_1),
.Y(n_77)
);

AOI21xp5_ASAP7_75t_L g78 ( 
.A1(n_68),
.A2(n_72),
.B(n_64),
.Y(n_78)
);

INVx2_ASAP7_75t_SL g79 ( 
.A(n_65),
.Y(n_79)
);

OAI22xp5_ASAP7_75t_L g80 ( 
.A1(n_69),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_66),
.Y(n_81)
);

BUFx6f_ASAP7_75t_L g82 ( 
.A(n_65),
.Y(n_82)
);

AND2x2_ASAP7_75t_L g83 ( 
.A(n_70),
.B(n_2),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_66),
.Y(n_84)
);

OA21x2_ASAP7_75t_L g85 ( 
.A1(n_78),
.A2(n_67),
.B(n_66),
.Y(n_85)
);

OAI21xp5_ASAP7_75t_L g86 ( 
.A1(n_77),
.A2(n_59),
.B(n_71),
.Y(n_86)
);

INVx2_ASAP7_75t_L g87 ( 
.A(n_81),
.Y(n_87)
);

INVx2_ASAP7_75t_L g88 ( 
.A(n_81),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_84),
.Y(n_89)
);

AND2x2_ASAP7_75t_L g90 ( 
.A(n_74),
.B(n_62),
.Y(n_90)
);

OAI21x1_ASAP7_75t_L g91 ( 
.A1(n_77),
.A2(n_62),
.B(n_65),
.Y(n_91)
);

INVx2_ASAP7_75t_L g92 ( 
.A(n_81),
.Y(n_92)
);

AOI21xp5_ASAP7_75t_L g93 ( 
.A1(n_85),
.A2(n_74),
.B(n_73),
.Y(n_93)
);

HB1xp67_ASAP7_75t_L g94 ( 
.A(n_90),
.Y(n_94)
);

AND2x2_ASAP7_75t_L g95 ( 
.A(n_90),
.B(n_86),
.Y(n_95)
);

AND2x2_ASAP7_75t_L g96 ( 
.A(n_86),
.B(n_83),
.Y(n_96)
);

AND2x2_ASAP7_75t_L g97 ( 
.A(n_89),
.B(n_83),
.Y(n_97)
);

INVx3_ASAP7_75t_L g98 ( 
.A(n_91),
.Y(n_98)
);

INVx5_ASAP7_75t_L g99 ( 
.A(n_87),
.Y(n_99)
);

INVx1_ASAP7_75t_L g100 ( 
.A(n_89),
.Y(n_100)
);

OAI21xp33_ASAP7_75t_SL g101 ( 
.A1(n_100),
.A2(n_91),
.B(n_80),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_100),
.Y(n_102)
);

INVx5_ASAP7_75t_L g103 ( 
.A(n_98),
.Y(n_103)
);

HB1xp67_ASAP7_75t_L g104 ( 
.A(n_94),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_95),
.B(n_75),
.Y(n_105)
);

INVxp67_ASAP7_75t_SL g106 ( 
.A(n_93),
.Y(n_106)
);

AO21x2_ASAP7_75t_L g107 ( 
.A1(n_93),
.A2(n_88),
.B(n_87),
.Y(n_107)
);

HB1xp67_ASAP7_75t_L g108 ( 
.A(n_99),
.Y(n_108)
);

INVx2_ASAP7_75t_L g109 ( 
.A(n_98),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_97),
.Y(n_110)
);

BUFx3_ASAP7_75t_L g111 ( 
.A(n_99),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_102),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_102),
.Y(n_113)
);

NAND2xp5_ASAP7_75t_L g114 ( 
.A(n_105),
.B(n_95),
.Y(n_114)
);

NAND2xp5_ASAP7_75t_L g115 ( 
.A(n_105),
.B(n_104),
.Y(n_115)
);

INVx2_ASAP7_75t_L g116 ( 
.A(n_107),
.Y(n_116)
);

NAND2xp5_ASAP7_75t_L g117 ( 
.A(n_104),
.B(n_96),
.Y(n_117)
);

NAND2xp33_ASAP7_75t_L g118 ( 
.A(n_108),
.B(n_99),
.Y(n_118)
);

OR2x6_ASAP7_75t_L g119 ( 
.A(n_111),
.B(n_96),
.Y(n_119)
);

INVx1_ASAP7_75t_L g120 ( 
.A(n_110),
.Y(n_120)
);

AND2x2_ASAP7_75t_L g121 ( 
.A(n_109),
.B(n_97),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_108),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_106),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_106),
.B(n_75),
.Y(n_124)
);

AND2x2_ASAP7_75t_L g125 ( 
.A(n_109),
.B(n_98),
.Y(n_125)
);

INVx1_ASAP7_75t_L g126 ( 
.A(n_107),
.Y(n_126)
);

OR2x2_ASAP7_75t_L g127 ( 
.A(n_107),
.B(n_76),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_115),
.B(n_101),
.Y(n_128)
);

OR2x2_ASAP7_75t_L g129 ( 
.A(n_117),
.B(n_107),
.Y(n_129)
);

AND2x2_ASAP7_75t_L g130 ( 
.A(n_121),
.B(n_101),
.Y(n_130)
);

OR2x2_ASAP7_75t_L g131 ( 
.A(n_114),
.B(n_88),
.Y(n_131)
);

OR2x2_ASAP7_75t_L g132 ( 
.A(n_127),
.B(n_120),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_112),
.Y(n_133)
);

INVx2_ASAP7_75t_L g134 ( 
.A(n_113),
.Y(n_134)
);

AND2x2_ASAP7_75t_L g135 ( 
.A(n_125),
.B(n_103),
.Y(n_135)
);

AND2x2_ASAP7_75t_L g136 ( 
.A(n_125),
.B(n_103),
.Y(n_136)
);

OR2x2_ASAP7_75t_L g137 ( 
.A(n_124),
.B(n_92),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_122),
.Y(n_138)
);

AND2x2_ASAP7_75t_L g139 ( 
.A(n_119),
.B(n_103),
.Y(n_139)
);

OAI22x1_ASAP7_75t_L g140 ( 
.A1(n_126),
.A2(n_103),
.B1(n_99),
.B2(n_85),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_123),
.Y(n_141)
);

AND2x2_ASAP7_75t_L g142 ( 
.A(n_119),
.B(n_103),
.Y(n_142)
);

OR2x2_ASAP7_75t_L g143 ( 
.A(n_116),
.B(n_92),
.Y(n_143)
);

OR2x2_ASAP7_75t_L g144 ( 
.A(n_116),
.B(n_84),
.Y(n_144)
);

OR2x2_ASAP7_75t_L g145 ( 
.A(n_118),
.B(n_111),
.Y(n_145)
);

INVx2_ASAP7_75t_L g146 ( 
.A(n_118),
.Y(n_146)
);

AND2x4_ASAP7_75t_L g147 ( 
.A(n_119),
.B(n_103),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_112),
.Y(n_148)
);

OR2x2_ASAP7_75t_L g149 ( 
.A(n_115),
.B(n_85),
.Y(n_149)
);

INVx1_ASAP7_75t_SL g150 ( 
.A(n_132),
.Y(n_150)
);

OR2x2_ASAP7_75t_L g151 ( 
.A(n_129),
.B(n_128),
.Y(n_151)
);

NAND2xp5_ASAP7_75t_L g152 ( 
.A(n_138),
.B(n_3),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_133),
.Y(n_153)
);

AND2x2_ASAP7_75t_L g154 ( 
.A(n_130),
.B(n_111),
.Y(n_154)
);

OR2x2_ASAP7_75t_L g155 ( 
.A(n_130),
.B(n_85),
.Y(n_155)
);

OR2x2_ASAP7_75t_L g156 ( 
.A(n_149),
.B(n_134),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_148),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_141),
.Y(n_158)
);

NAND2xp5_ASAP7_75t_L g159 ( 
.A(n_137),
.B(n_6),
.Y(n_159)
);

AND2x2_ASAP7_75t_L g160 ( 
.A(n_135),
.B(n_7),
.Y(n_160)
);

HB1xp67_ASAP7_75t_L g161 ( 
.A(n_149),
.Y(n_161)
);

NAND2xp5_ASAP7_75t_L g162 ( 
.A(n_131),
.B(n_7),
.Y(n_162)
);

AOI22xp33_ASAP7_75t_L g163 ( 
.A1(n_147),
.A2(n_65),
.B1(n_63),
.B2(n_99),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_144),
.Y(n_164)
);

NAND2xp5_ASAP7_75t_L g165 ( 
.A(n_136),
.B(n_9),
.Y(n_165)
);

INVx2_ASAP7_75t_L g166 ( 
.A(n_143),
.Y(n_166)
);

AND2x2_ASAP7_75t_L g167 ( 
.A(n_135),
.B(n_9),
.Y(n_167)
);

NAND2xp33_ASAP7_75t_L g168 ( 
.A(n_146),
.B(n_99),
.Y(n_168)
);

AND2x2_ASAP7_75t_L g169 ( 
.A(n_139),
.B(n_10),
.Y(n_169)
);

INVx1_ASAP7_75t_L g170 ( 
.A(n_146),
.Y(n_170)
);

NAND2xp5_ASAP7_75t_L g171 ( 
.A(n_139),
.B(n_142),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_140),
.Y(n_172)
);

AOI22xp5_ASAP7_75t_L g173 ( 
.A1(n_169),
.A2(n_147),
.B1(n_145),
.B2(n_140),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_153),
.Y(n_174)
);

OR2x2_ASAP7_75t_L g175 ( 
.A(n_151),
.B(n_10),
.Y(n_175)
);

NOR3xp33_ASAP7_75t_L g176 ( 
.A(n_165),
.B(n_63),
.C(n_11),
.Y(n_176)
);

NAND3xp33_ASAP7_75t_L g177 ( 
.A(n_172),
.B(n_65),
.C(n_63),
.Y(n_177)
);

NOR2xp33_ASAP7_75t_L g178 ( 
.A(n_150),
.B(n_15),
.Y(n_178)
);

OAI21xp5_ASAP7_75t_L g179 ( 
.A1(n_152),
.A2(n_79),
.B(n_63),
.Y(n_179)
);

CKINVDCx20_ASAP7_75t_R g180 ( 
.A(n_171),
.Y(n_180)
);

NOR3xp33_ASAP7_75t_L g181 ( 
.A(n_162),
.B(n_17),
.C(n_16),
.Y(n_181)
);

INVx1_ASAP7_75t_L g182 ( 
.A(n_153),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_157),
.Y(n_183)
);

INVx1_ASAP7_75t_L g184 ( 
.A(n_157),
.Y(n_184)
);

OAI21xp5_ASAP7_75t_L g185 ( 
.A1(n_172),
.A2(n_20),
.B(n_19),
.Y(n_185)
);

INVxp67_ASAP7_75t_L g186 ( 
.A(n_158),
.Y(n_186)
);

NOR3x1_ASAP7_75t_L g187 ( 
.A(n_159),
.B(n_22),
.C(n_21),
.Y(n_187)
);

NOR3xp33_ASAP7_75t_L g188 ( 
.A(n_169),
.B(n_24),
.C(n_23),
.Y(n_188)
);

AND2x2_ASAP7_75t_L g189 ( 
.A(n_154),
.B(n_25),
.Y(n_189)
);

NOR2x1_ASAP7_75t_L g190 ( 
.A(n_174),
.B(n_170),
.Y(n_190)
);

O2A1O1Ixp33_ASAP7_75t_L g191 ( 
.A1(n_176),
.A2(n_167),
.B(n_160),
.C(n_168),
.Y(n_191)
);

INVx1_ASAP7_75t_L g192 ( 
.A(n_182),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_183),
.Y(n_193)
);

AOI22xp5_ASAP7_75t_L g194 ( 
.A1(n_176),
.A2(n_154),
.B1(n_164),
.B2(n_161),
.Y(n_194)
);

INVx1_ASAP7_75t_L g195 ( 
.A(n_184),
.Y(n_195)
);

NAND2xp33_ASAP7_75t_SL g196 ( 
.A(n_180),
.B(n_175),
.Y(n_196)
);

NAND4xp75_ASAP7_75t_L g197 ( 
.A(n_187),
.B(n_166),
.C(n_155),
.D(n_156),
.Y(n_197)
);

XNOR2x1_ASAP7_75t_L g198 ( 
.A(n_189),
.B(n_166),
.Y(n_198)
);

AOI221xp5_ASAP7_75t_L g199 ( 
.A1(n_186),
.A2(n_26),
.B1(n_82),
.B2(n_163),
.C(n_181),
.Y(n_199)
);

AOI21xp33_ASAP7_75t_L g200 ( 
.A1(n_185),
.A2(n_82),
.B(n_173),
.Y(n_200)
);

INVx1_ASAP7_75t_L g201 ( 
.A(n_192),
.Y(n_201)
);

AND2x4_ASAP7_75t_L g202 ( 
.A(n_193),
.B(n_186),
.Y(n_202)
);

INVx1_ASAP7_75t_L g203 ( 
.A(n_195),
.Y(n_203)
);

NOR2xp33_ASAP7_75t_SL g204 ( 
.A(n_197),
.B(n_188),
.Y(n_204)
);

NAND4xp25_ASAP7_75t_L g205 ( 
.A(n_191),
.B(n_181),
.C(n_179),
.D(n_178),
.Y(n_205)
);

AND2x2_ASAP7_75t_L g206 ( 
.A(n_190),
.B(n_177),
.Y(n_206)
);

INVx1_ASAP7_75t_L g207 ( 
.A(n_201),
.Y(n_207)
);

NAND2xp5_ASAP7_75t_L g208 ( 
.A(n_203),
.B(n_194),
.Y(n_208)
);

INVx2_ASAP7_75t_L g209 ( 
.A(n_202),
.Y(n_209)
);

INVx2_ASAP7_75t_L g210 ( 
.A(n_202),
.Y(n_210)
);

OAI221xp5_ASAP7_75t_L g211 ( 
.A1(n_208),
.A2(n_204),
.B1(n_205),
.B2(n_209),
.C(n_210),
.Y(n_211)
);

XOR2xp5_ASAP7_75t_L g212 ( 
.A(n_208),
.B(n_198),
.Y(n_212)
);

AOI21xp33_ASAP7_75t_L g213 ( 
.A1(n_211),
.A2(n_207),
.B(n_206),
.Y(n_213)
);

NAND2xp5_ASAP7_75t_L g214 ( 
.A(n_213),
.B(n_212),
.Y(n_214)
);

BUFx2_ASAP7_75t_L g215 ( 
.A(n_214),
.Y(n_215)
);

AOI221xp5_ASAP7_75t_L g216 ( 
.A1(n_215),
.A2(n_205),
.B1(n_196),
.B2(n_199),
.C(n_200),
.Y(n_216)
);


endmodule