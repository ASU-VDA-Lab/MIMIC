module fake_netlist_871_1342_n_63 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_63);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_63;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_42;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_41;
wire n_21;
wire n_57;
wire n_43;
wire n_62;
wire n_44;
wire n_36;
wire n_45;
wire n_48;
wire n_29;
wire n_26;
wire n_38;
wire n_56;

BUFx8_ASAP7_75t_SL g21 ( 
.A(n_5),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_20),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_12),
.B(n_19),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_8),
.B(n_14),
.Y(n_26)
);

INVx6_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_18),
.A2(n_13),
.B1(n_3),
.B2(n_0),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_1),
.B(n_0),
.Y(n_29)
);

OAI21x1_ASAP7_75t_L g30 ( 
.A1(n_11),
.A2(n_20),
.B(n_2),
.Y(n_30)
);

NAND2x1p5_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_4),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_22),
.B(n_3),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_22),
.B(n_10),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_24),
.B(n_10),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_23),
.B(n_11),
.Y(n_35)
);

A2O1A1Ixp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_30),
.B(n_25),
.C(n_23),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_27),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_33),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_37),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_40),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

AO221x1_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_28),
.B1(n_37),
.B2(n_41),
.C(n_36),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_SL g50 ( 
.A(n_47),
.B(n_43),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

AOI221x1_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_34),
.B1(n_28),
.B2(n_33),
.C(n_43),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_24),
.Y(n_53)
);

NAND4xp25_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_29),
.C(n_25),
.D(n_26),
.Y(n_54)
);

AO22x2_ASAP7_75t_L g55 ( 
.A1(n_50),
.A2(n_25),
.B1(n_30),
.B2(n_16),
.Y(n_55)
);

NOR2x1_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_53),
.Y(n_56)
);

NOR2xp33_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_21),
.Y(n_57)
);

NAND3x1_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_49),
.C(n_16),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_L g59 ( 
.A1(n_54),
.A2(n_27),
.B1(n_18),
.B2(n_17),
.Y(n_59)
);

OAI22x1_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_17),
.B1(n_27),
.B2(n_6),
.Y(n_60)
);

INVx2_ASAP7_75t_SL g61 ( 
.A(n_56),
.Y(n_61)
);

AOI222xp33_ASAP7_75t_SL g62 ( 
.A1(n_60),
.A2(n_58),
.B1(n_57),
.B2(n_27),
.C1(n_15),
.C2(n_7),
.Y(n_62)
);

OAI21xp5_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_61),
.B(n_27),
.Y(n_63)
);


endmodule