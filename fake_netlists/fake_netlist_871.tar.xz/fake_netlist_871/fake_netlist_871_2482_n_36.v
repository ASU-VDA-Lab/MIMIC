module fake_netlist_871_2482_n_36 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_36);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_36;

wire n_33;
wire n_34;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_26;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_8),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_13),
.B(n_11),
.Y(n_22)
);

OAI21x1_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_1),
.B(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_6),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_24),
.B(n_2),
.C(n_0),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_25),
.B(n_3),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_23),
.B1(n_22),
.B2(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_30),
.Y(n_32)
);

AOI221x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_26),
.B1(n_10),
.B2(n_4),
.C(n_7),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_19),
.B1(n_17),
.B2(n_16),
.Y(n_36)
);


endmodule