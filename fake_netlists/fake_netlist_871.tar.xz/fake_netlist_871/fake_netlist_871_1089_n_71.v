module fake_netlist_871_1089_n_71 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_71);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_71;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_68;
wire n_46;
wire n_63;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_66;
wire n_65;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_70;
wire n_67;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_42;
wire n_22;
wire n_35;
wire n_25;
wire n_41;
wire n_57;
wire n_32;
wire n_43;
wire n_62;
wire n_44;
wire n_36;
wire n_29;
wire n_45;
wire n_48;
wire n_26;
wire n_69;
wire n_38;
wire n_56;

INVx3_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_3),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_10),
.B(n_14),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_7),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

OA21x2_ASAP7_75t_L g30 ( 
.A1(n_1),
.A2(n_11),
.B(n_17),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_6),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_28),
.A2(n_11),
.B1(n_10),
.B2(n_2),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_22),
.B(n_2),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_22),
.B(n_23),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_36),
.Y(n_38)
);

AOI221x1_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_23),
.B1(n_27),
.B2(n_24),
.C(n_25),
.Y(n_39)
);

AOI21xp5_ASAP7_75t_L g40 ( 
.A1(n_34),
.A2(n_27),
.B(n_22),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_35),
.B(n_29),
.Y(n_41)
);

INVx4_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_37),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_39),
.Y(n_46)
);

AND3x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_24),
.C(n_29),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

NOR2x1_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_42),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

NOR2x2_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_31),
.Y(n_52)
);

AOI21xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_48),
.B(n_46),
.Y(n_53)
);

AOI211x1_ASAP7_75t_L g54 ( 
.A1(n_49),
.A2(n_46),
.B(n_40),
.C(n_37),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

NOR2xp33_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_42),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

NOR2x1_ASAP7_75t_L g58 ( 
.A(n_57),
.B(n_42),
.Y(n_58)
);

OAI321xp33_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_33),
.A3(n_55),
.B1(n_31),
.B2(n_43),
.C(n_53),
.Y(n_59)
);

NOR3x1_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_26),
.C(n_39),
.Y(n_60)
);

AOI221xp5_ASAP7_75t_L g61 ( 
.A1(n_54),
.A2(n_42),
.B1(n_22),
.B2(n_32),
.C(n_16),
.Y(n_61)
);

NOR4xp25_ASAP7_75t_L g62 ( 
.A(n_57),
.B(n_18),
.C(n_17),
.D(n_16),
.Y(n_62)
);

NAND4xp75_ASAP7_75t_L g63 ( 
.A(n_60),
.B(n_30),
.C(n_19),
.D(n_18),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_58),
.B(n_19),
.Y(n_64)
);

NAND3x1_ASAP7_75t_L g65 ( 
.A(n_61),
.B(n_20),
.C(n_30),
.Y(n_65)
);

AND2x2_ASAP7_75t_L g66 ( 
.A(n_62),
.B(n_30),
.Y(n_66)
);

OAI22xp5_ASAP7_75t_SL g67 ( 
.A1(n_64),
.A2(n_30),
.B1(n_59),
.B2(n_32),
.Y(n_67)
);

OAI22xp5_ASAP7_75t_L g68 ( 
.A1(n_65),
.A2(n_32),
.B1(n_4),
.B2(n_0),
.Y(n_68)
);

OAI22xp5_ASAP7_75t_L g69 ( 
.A1(n_63),
.A2(n_32),
.B1(n_12),
.B2(n_9),
.Y(n_69)
);

AOI22xp5_ASAP7_75t_L g70 ( 
.A1(n_69),
.A2(n_66),
.B1(n_32),
.B2(n_13),
.Y(n_70)
);

OA22x2_ASAP7_75t_L g71 ( 
.A1(n_70),
.A2(n_68),
.B1(n_67),
.B2(n_15),
.Y(n_71)
);


endmodule