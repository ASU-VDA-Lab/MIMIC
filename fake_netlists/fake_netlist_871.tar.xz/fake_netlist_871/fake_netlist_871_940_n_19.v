module fake_netlist_871_940_n_19 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_19);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_19;

wire n_15;
wire n_11;
wire n_16;
wire n_12;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_14;
wire n_10;
wire n_8;

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_3),
.B(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVxp67_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_7),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_7),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_9),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_10),
.Y(n_16)
);

XNOR2x1_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_1),
.Y(n_17)
);

OAI211xp5_ASAP7_75t_SL g18 ( 
.A1(n_16),
.A2(n_8),
.B(n_15),
.C(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);


endmodule