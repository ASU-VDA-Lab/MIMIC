module fake_netlist_871_122_n_37 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_37);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_37;

wire n_33;
wire n_34;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_13),
.B(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_15),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_5),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_19),
.B(n_18),
.Y(n_25)
);

OAI21x1_ASAP7_75t_L g26 ( 
.A1(n_20),
.A2(n_22),
.B(n_21),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_R g27 ( 
.A(n_26),
.B(n_23),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_29),
.Y(n_30)
);

A2O1A1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B(n_25),
.C(n_27),
.Y(n_31)
);

OAI32xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_16),
.A3(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_32),
.Y(n_34)
);

AOI22x1_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_16),
.B1(n_6),
.B2(n_3),
.Y(n_35)
);

OAI31xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_10),
.A3(n_9),
.B(n_7),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_R g37 ( 
.A1(n_35),
.A2(n_11),
.B1(n_12),
.B2(n_36),
.Y(n_37)
);


endmodule