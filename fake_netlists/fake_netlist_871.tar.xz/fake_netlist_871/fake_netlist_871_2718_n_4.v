module fake_netlist_871_2718_n_4 (n_0, n_1, n_2, n_4);

input n_0;
input n_1;
input n_2;

output n_4;

wire n_3;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

NAND4xp25_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.C(n_2),
.D(n_1),
.Y(n_4)
);


endmodule