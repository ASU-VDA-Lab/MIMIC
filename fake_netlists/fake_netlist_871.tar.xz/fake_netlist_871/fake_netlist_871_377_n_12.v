module fake_netlist_871_377_n_12 (n_0, n_1, n_3, n_2, n_12);

input n_0;
input n_1;
input n_3;
input n_2;

output n_12;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

INVx2_ASAP7_75t_SL g4 ( 
.A(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AOI211xp5_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_5),
.B(n_7),
.C(n_4),
.Y(n_9)
);

NAND5xp2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_1),
.C(n_0),
.D(n_2),
.E(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

OA22x2_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_12)
);


endmodule