module fake_netlist_871_1768_n_40 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_40);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_40;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_32;
wire n_35;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_SL g15 ( 
.A1(n_6),
.A2(n_1),
.B1(n_0),
.B2(n_9),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

AOI21xp33_ASAP7_75t_L g22 ( 
.A1(n_13),
.A2(n_4),
.B(n_3),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_14),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_14),
.A2(n_12),
.B(n_17),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_18),
.B(n_15),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_15),
.Y(n_28)
);

OAI221xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_19),
.B1(n_22),
.B2(n_25),
.C(n_27),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_22),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_28),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

NAND4xp25_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_28),
.C(n_26),
.D(n_29),
.Y(n_35)
);

OAI21xp33_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_26),
.B(n_30),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_30),
.Y(n_38)
);

XOR2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_35),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_36),
.B1(n_38),
.B2(n_35),
.Y(n_40)
);


endmodule