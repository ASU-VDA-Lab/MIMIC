module fake_netlist_871_790_n_29 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_29);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_29;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_25;
wire n_22;
wire n_14;
wire n_26;

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_2),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_3),
.B(n_13),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_6),
.B(n_5),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_8),
.B(n_11),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_4),
.B1(n_3),
.B2(n_1),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_5),
.B(n_4),
.C(n_1),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

A2O1A1O1Ixp25_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_23),
.B(n_16),
.C(n_6),
.D(n_14),
.Y(n_26)
);

NAND4xp25_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_23),
.C(n_19),
.D(n_17),
.Y(n_27)
);

BUFx2_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_12),
.B1(n_9),
.B2(n_7),
.Y(n_29)
);


endmodule