module fake_netlist_617_1587_n_4 (n_1, n_2, n_0, n_4);

input n_1;
input n_2;
input n_0;

output n_4;

wire n_3;

BUFx3_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

NAND3x1_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.C(n_1),
.Y(n_4)
);


endmodule