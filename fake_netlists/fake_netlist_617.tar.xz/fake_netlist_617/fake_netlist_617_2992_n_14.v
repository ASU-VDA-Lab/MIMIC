module fake_netlist_617_2992_n_14 (n_1, n_2, n_3, n_0, n_14);

input n_1;
input n_2;
input n_3;
input n_0;

output n_14;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;

BUFx3_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_3),
.B(n_1),
.Y(n_5)
);

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B(n_9),
.C(n_7),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_12)
);

OAI21xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_1),
.B(n_2),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_1),
.B2(n_3),
.Y(n_14)
);


endmodule