module fake_netlist_617_90_n_14 (n_1, n_2, n_3, n_0, n_14);

input n_1;
input n_2;
input n_3;
input n_0;

output n_14;

wire n_7;
wire n_11;
wire n_9;
wire n_8;
wire n_5;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;

HB1xp67_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

NAND3xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_1),
.C(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

AOI22x1_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_6),
.B1(n_5),
.B2(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_8),
.C(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_3),
.B1(n_9),
.B2(n_4),
.C1(n_6),
.C2(n_7),
.Y(n_14)
);


endmodule