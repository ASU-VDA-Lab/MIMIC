module fake_netlist_617_1101_n_14 (n_5, n_0, n_4, n_1, n_2, n_3, n_14);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_14;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_10;
wire n_13;
wire n_6;
wire n_12;

OAI22xp5_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_1),
.B1(n_4),
.B2(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_1),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_0),
.A2(n_5),
.B(n_2),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_4),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_6),
.B1(n_8),
.B2(n_13),
.Y(n_14)
);


endmodule