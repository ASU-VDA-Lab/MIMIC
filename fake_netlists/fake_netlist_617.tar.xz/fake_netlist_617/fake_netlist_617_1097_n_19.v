module fake_netlist_617_1097_n_19 (n_1, n_2, n_3, n_0, n_19);

input n_1;
input n_2;
input n_3;
input n_0;

output n_19;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_4;
wire n_7;
wire n_10;
wire n_16;
wire n_5;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

AOI22xp5_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_0),
.B1(n_3),
.B2(n_1),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AOI221x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.C(n_2),
.Y(n_7)
);

AO31x2_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.A3(n_2),
.B(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

OAI22xp33_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_4),
.B1(n_7),
.B2(n_8),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_7),
.B1(n_8),
.B2(n_1),
.Y(n_12)
);

AOI211xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_10),
.B(n_2),
.C(n_0),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_10),
.B1(n_8),
.B2(n_0),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_8),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_8),
.B1(n_3),
.B2(n_1),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_1),
.B(n_15),
.Y(n_17)
);

XOR2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_4),
.Y(n_18)
);

OR2x6_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_18),
.Y(n_19)
);


endmodule