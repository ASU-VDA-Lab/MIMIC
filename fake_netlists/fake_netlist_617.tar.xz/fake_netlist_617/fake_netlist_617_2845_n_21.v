module fake_netlist_617_2845_n_21 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_21);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_21;

wire n_11;
wire n_15;
wire n_18;
wire n_17;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

INVx2_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

NAND2xp33_ASAP7_75t_L g11 ( 
.A(n_2),
.B(n_5),
.Y(n_11)
);

AND2x6_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_0),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_6),
.B(n_1),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_5),
.B(n_4),
.Y(n_15)
);

NOR4xp25_ASAP7_75t_SL g16 ( 
.A(n_14),
.B(n_12),
.C(n_6),
.D(n_4),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI211xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_15),
.B(n_16),
.C(n_10),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_12),
.B1(n_7),
.B2(n_8),
.C(n_9),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_7),
.B(n_12),
.C(n_18),
.Y(n_21)
);


endmodule