module fake_netlist_617_945_n_22 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_22);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_22;

wire n_15;
wire n_21;
wire n_18;
wire n_17;
wire n_19;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_3),
.B(n_5),
.Y(n_13)
);

BUFx6f_ASAP7_75t_SL g14 ( 
.A(n_4),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_11),
.Y(n_15)
);

AO31x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.A3(n_14),
.B(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

AOI221x1_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B1(n_7),
.B2(n_6),
.C(n_0),
.Y(n_19)
);

NAND4xp75_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_7),
.C(n_2),
.D(n_1),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_9),
.B(n_8),
.Y(n_22)
);


endmodule