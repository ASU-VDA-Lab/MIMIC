module fake_netlist_617_134_n_12 (n_1, n_2, n_0, n_12);

input n_1;
input n_2;
input n_0;

output n_12;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_3;

BUFx3_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

BUFx3_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

O2A1O1Ixp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_5)
);

OAI221xp5_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_4),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NAND4xp25_ASAP7_75t_SL g9 ( 
.A(n_8),
.B(n_1),
.C(n_2),
.D(n_7),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_9),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule