module fake_netlist_617_3236_n_30 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_30);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_30;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_5),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_SL g14 ( 
.A1(n_6),
.A2(n_2),
.B1(n_9),
.B2(n_8),
.Y(n_14)
);

CKINVDCx8_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_6),
.B(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_13),
.Y(n_19)
);

OAI21x1_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_13),
.B(n_7),
.Y(n_20)
);

INVxp67_ASAP7_75t_SL g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_15),
.Y(n_23)
);

AOI32xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_14),
.A3(n_20),
.B1(n_7),
.B2(n_1),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

XOR2x1_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_3),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_11),
.B(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);


endmodule