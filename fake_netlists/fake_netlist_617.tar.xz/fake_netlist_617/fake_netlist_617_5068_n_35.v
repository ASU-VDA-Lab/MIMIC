module fake_netlist_617_5068_n_35 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_35);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_35;

wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;
wire n_14;
wire n_13;
wire n_12;

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_8),
.B(n_1),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_2),
.B(n_7),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_10),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

NOR2xp67_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_11),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_3),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_5),
.B1(n_4),
.B2(n_0),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_5),
.B(n_4),
.C(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_15),
.B1(n_13),
.B2(n_12),
.Y(n_23)
);

CKINVDCx6p67_ASAP7_75t_R g24 ( 
.A(n_19),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

OAI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_20),
.B1(n_14),
.B2(n_16),
.Y(n_27)
);

AOI21xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_23),
.B(n_21),
.Y(n_28)
);

O2A1O1Ixp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_25),
.B(n_21),
.C(n_26),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_6),
.B1(n_17),
.B2(n_25),
.C1(n_26),
.C2(n_19),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_29),
.Y(n_31)
);

BUFx12f_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_31),
.B1(n_25),
.B2(n_6),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_25),
.B1(n_32),
.B2(n_33),
.Y(n_35)
);


endmodule