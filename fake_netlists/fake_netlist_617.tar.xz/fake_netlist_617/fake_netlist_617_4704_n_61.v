module fake_netlist_617_4704_n_61 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_61);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_61;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_29;
wire n_58;
wire n_27;
wire n_28;
wire n_52;
wire n_51;
wire n_24;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_60;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_34;

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_17),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_6),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_8),
.B(n_18),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_14),
.B(n_11),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_9),
.B(n_5),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_10),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_22),
.A2(n_16),
.B1(n_15),
.B2(n_13),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_19),
.B(n_13),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_20),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

BUFx3_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

NAND2x1p5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_27),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_36),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_36),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_35),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_37),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_40),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_39),
.Y(n_44)
);

NOR2x1_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_41),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_40),
.B1(n_38),
.B2(n_30),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_38),
.B(n_37),
.Y(n_47)
);

OAI21xp33_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_41),
.B(n_31),
.Y(n_48)
);

OAI21xp33_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_34),
.B(n_37),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

AOI211xp5_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_33),
.B(n_21),
.C(n_22),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_50),
.Y(n_52)
);

NOR3xp33_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_26),
.C(n_24),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_48),
.Y(n_54)
);

OAI22xp5_ASAP7_75t_L g55 ( 
.A1(n_49),
.A2(n_20),
.B1(n_22),
.B2(n_27),
.Y(n_55)
);

NOR2xp67_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_54),
.Y(n_56)
);

AOI221xp5_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_27),
.B1(n_24),
.B2(n_29),
.C(n_28),
.Y(n_57)
);

AOI22xp33_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_24),
.B1(n_28),
.B2(n_23),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_23),
.B1(n_3),
.B2(n_2),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_SL g60 ( 
.A1(n_56),
.A2(n_7),
.B1(n_23),
.B2(n_57),
.Y(n_60)
);

AOI21xp33_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_23),
.B(n_59),
.Y(n_61)
);


endmodule