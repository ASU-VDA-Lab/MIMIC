module fake_netlist_910_2119_n_21 (n_0, n_2, n_3, n_4, n_1, n_21);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_21;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_19;
wire n_12;
wire n_5;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_1),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_R g6 ( 
.A(n_4),
.B(n_2),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

INVx3_ASAP7_75t_SL g8 ( 
.A(n_5),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_11),
.B1(n_7),
.B2(n_9),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_7),
.B1(n_11),
.B2(n_6),
.C1(n_1),
.C2(n_0),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_6),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

OAI221xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_2),
.B1(n_0),
.B2(n_3),
.C(n_4),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_3),
.B1(n_4),
.B2(n_19),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_3),
.B1(n_18),
.B2(n_19),
.Y(n_21)
);


endmodule