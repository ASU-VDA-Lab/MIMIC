module fake_netlist_910_1386_n_21 (n_0, n_1, n_3, n_2, n_21);

input n_0;
input n_1;
input n_3;
input n_2;

output n_21;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_4;
wire n_19;
wire n_12;
wire n_5;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_0),
.Y(n_5)
);

AND2x2_ASAP7_75t_SL g6 ( 
.A(n_1),
.B(n_0),
.Y(n_6)
);

INVx5_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

OAI22xp33_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_1),
.B1(n_2),
.B2(n_7),
.Y(n_8)
);

NOR2xp67_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_2),
.Y(n_9)
);

OR2x6_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_4),
.Y(n_10)
);

NOR2x1_ASAP7_75t_SL g11 ( 
.A(n_7),
.B(n_5),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_5),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_5),
.Y(n_13)
);

INVxp67_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

NAND2x1_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_12),
.Y(n_16)
);

NAND4xp25_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_13),
.C(n_6),
.D(n_8),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_14),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_11),
.B(n_6),
.Y(n_19)
);

OR3x1_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_6),
.C(n_7),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_SL g21 ( 
.A1(n_19),
.A2(n_7),
.B1(n_20),
.B2(n_6),
.Y(n_21)
);


endmodule