module fake_netlist_910_1170_n_29 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_29);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_29;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_25;
wire n_22;
wire n_14;
wire n_26;

INVx3_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_10),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_4),
.B(n_8),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_14),
.Y(n_22)
);

NOR5xp2_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_7),
.C(n_20),
.D(n_19),
.E(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_20),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_18),
.B1(n_16),
.B2(n_7),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_5),
.Y(n_27)
);

AND3x1_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_9),
.C(n_6),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);


endmodule