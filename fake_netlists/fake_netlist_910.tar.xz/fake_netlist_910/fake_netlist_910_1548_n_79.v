module fake_netlist_910_1548_n_79 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_10, n_8, n_79);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_10;
input n_8;

output n_79;

wire n_60;
wire n_52;
wire n_30;
wire n_64;
wire n_66;
wire n_65;
wire n_27;
wire n_71;
wire n_29;
wire n_69;
wire n_51;
wire n_50;
wire n_55;
wire n_46;
wire n_54;
wire n_28;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_62;
wire n_44;
wire n_26;
wire n_33;
wire n_77;
wire n_53;
wire n_61;
wire n_43;
wire n_48;
wire n_72;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_34;
wire n_37;
wire n_75;
wire n_47;
wire n_68;
wire n_63;
wire n_49;
wire n_58;
wire n_67;
wire n_57;
wire n_35;
wire n_36;
wire n_45;
wire n_73;
wire n_78;

OA21x2_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_21),
.B(n_20),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_18),
.B(n_16),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_14),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_13),
.B(n_20),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_10),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_17),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_5),
.B(n_15),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_24),
.Y(n_34)
);

NAND2xp33_ASAP7_75t_L g35 ( 
.A(n_0),
.B(n_2),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_4),
.A2(n_3),
.B1(n_11),
.B2(n_16),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_19),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_23),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_25),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_29),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_31),
.B(n_19),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_31),
.A2(n_6),
.B(n_1),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_L g43 ( 
.A(n_29),
.B(n_32),
.Y(n_43)
);

BUFx3_ASAP7_75t_L g44 ( 
.A(n_29),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_29),
.B(n_21),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_39),
.Y(n_46)
);

OAI21x1_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_27),
.B(n_39),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_37),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_43),
.B(n_28),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_47),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_48),
.B(n_44),
.Y(n_54)
);

AOI31xp33_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_36),
.A3(n_38),
.B(n_34),
.Y(n_55)
);

O2A1O1Ixp33_ASAP7_75t_L g56 ( 
.A1(n_51),
.A2(n_45),
.B(n_50),
.C(n_41),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

OR2x2_ASAP7_75t_L g58 ( 
.A(n_51),
.B(n_40),
.Y(n_58)
);

HB1xp67_ASAP7_75t_L g59 ( 
.A(n_57),
.Y(n_59)
);

AND2x2_ASAP7_75t_L g60 ( 
.A(n_58),
.B(n_41),
.Y(n_60)
);

NOR4xp25_ASAP7_75t_SL g61 ( 
.A(n_55),
.B(n_53),
.C(n_36),
.D(n_35),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_58),
.Y(n_62)
);

AOI222xp33_ASAP7_75t_L g63 ( 
.A1(n_60),
.A2(n_39),
.B1(n_53),
.B2(n_27),
.C1(n_52),
.C2(n_30),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_SL g64 ( 
.A(n_59),
.B(n_56),
.Y(n_64)
);

INVxp33_ASAP7_75t_SL g65 ( 
.A(n_59),
.Y(n_65)
);

AOI22xp5_ASAP7_75t_L g66 ( 
.A1(n_62),
.A2(n_49),
.B1(n_26),
.B2(n_30),
.Y(n_66)
);

AND2x2_ASAP7_75t_L g67 ( 
.A(n_61),
.B(n_26),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_65),
.B(n_46),
.Y(n_68)
);

NOR2xp33_ASAP7_75t_R g69 ( 
.A(n_67),
.B(n_22),
.Y(n_69)
);

AOI22xp33_ASAP7_75t_L g70 ( 
.A1(n_64),
.A2(n_26),
.B1(n_47),
.B2(n_33),
.Y(n_70)
);

NAND5xp2_ASAP7_75t_L g71 ( 
.A(n_63),
.B(n_26),
.C(n_25),
.D(n_22),
.E(n_23),
.Y(n_71)
);

NOR2xp33_ASAP7_75t_R g72 ( 
.A(n_64),
.B(n_7),
.Y(n_72)
);

AO22x2_ASAP7_75t_SL g73 ( 
.A1(n_71),
.A2(n_66),
.B1(n_9),
.B2(n_8),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_68),
.Y(n_74)
);

AOI21xp5_ASAP7_75t_L g75 ( 
.A1(n_70),
.A2(n_72),
.B(n_69),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_68),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_74),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_76),
.Y(n_78)
);

OAI221xp5_ASAP7_75t_R g79 ( 
.A1(n_77),
.A2(n_73),
.B1(n_75),
.B2(n_78),
.C(n_12),
.Y(n_79)
);


endmodule