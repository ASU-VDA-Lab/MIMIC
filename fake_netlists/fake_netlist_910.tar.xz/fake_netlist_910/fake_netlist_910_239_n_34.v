module fake_netlist_910_239_n_34 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_34);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_34;

wire n_33;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_26;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_14),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_11),
.B(n_9),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_16),
.Y(n_24)
);

O2A1O1Ixp5_ASAP7_75t_L g25 ( 
.A1(n_17),
.A2(n_4),
.B(n_2),
.C(n_1),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_21),
.A2(n_7),
.B(n_6),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_R g27 ( 
.A(n_24),
.B(n_18),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_22),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_23),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_20),
.Y(n_30)
);

A2O1A1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_25),
.B(n_27),
.C(n_16),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_R g34 ( 
.A1(n_33),
.A2(n_15),
.B1(n_13),
.B2(n_12),
.Y(n_34)
);


endmodule