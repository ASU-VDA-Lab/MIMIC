module fake_netlist_910_1188_n_34 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_34);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_34;

wire n_33;
wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_13;
wire n_32;
wire n_22;
wire n_25;
wire n_14;
wire n_26;
wire n_29;

BUFx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_5),
.B(n_2),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_1),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

O2A1O1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_4),
.B(n_2),
.C(n_1),
.Y(n_18)
);

OR2x6_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_4),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_11),
.B(n_6),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_19),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_11),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_SL g28 ( 
.A1(n_25),
.A2(n_22),
.B1(n_14),
.B2(n_12),
.Y(n_28)
);

OAI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_20),
.B1(n_26),
.B2(n_18),
.C(n_15),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_13),
.B1(n_15),
.B2(n_17),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

XNOR2x1_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_6),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_7),
.B2(n_3),
.Y(n_34)
);


endmodule