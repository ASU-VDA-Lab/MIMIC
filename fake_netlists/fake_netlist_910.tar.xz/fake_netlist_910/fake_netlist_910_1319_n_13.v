module fake_netlist_910_1319_n_13 (n_0, n_1, n_2, n_13);

input n_0;
input n_1;
input n_2;

output n_13;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

INVx2_ASAP7_75t_SL g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_SL g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_3),
.Y(n_7)
);

OAI221xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_5),
.Y(n_8)
);

NAND3xp33_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.C(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_7),
.Y(n_10)
);

NAND4xp25_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_8),
.C(n_9),
.D(n_0),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);


endmodule