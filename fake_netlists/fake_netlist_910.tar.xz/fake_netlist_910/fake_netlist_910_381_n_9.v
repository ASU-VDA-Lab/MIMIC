module fake_netlist_910_381_n_9 (n_0, n_1, n_2, n_9);

input n_0;
input n_1;
input n_2;

output n_9;

wire n_5;
wire n_3;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

O2A1O1Ixp33_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_1),
.Y(n_5)
);

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

OAI211xp5_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_1),
.B(n_2),
.C(n_4),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);


endmodule