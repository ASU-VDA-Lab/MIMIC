module fake_netlist_910_2076_n_17 (n_0, n_1, n_3, n_2, n_17);

input n_0;
input n_1;
input n_3;
input n_2;

output n_17;

wire n_5;
wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

BUFx10_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AND2x4_ASAP7_75t_SL g5 ( 
.A(n_2),
.B(n_0),
.Y(n_5)
);

AO22x2_ASAP7_75t_L g6 ( 
.A1(n_1),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_5),
.B(n_4),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B1(n_6),
.B2(n_4),
.Y(n_9)
);

AOI33xp33_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_4),
.A3(n_6),
.B1(n_2),
.B2(n_1),
.B3(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_9),
.B(n_8),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_1),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_2),
.B(n_11),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_12),
.B1(n_11),
.B2(n_16),
.Y(n_17)
);


endmodule