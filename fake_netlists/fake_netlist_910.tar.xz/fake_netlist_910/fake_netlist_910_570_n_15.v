module fake_netlist_910_570_n_15 (n_0, n_2, n_3, n_4, n_1, n_15);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_15;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_1),
.B(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_SL g7 ( 
.A(n_1),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI33xp33_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_6),
.A3(n_0),
.B1(n_4),
.B2(n_3),
.B3(n_2),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_8),
.Y(n_12)
);

OAI21xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_11),
.B(n_8),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B(n_3),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_8),
.B1(n_4),
.B2(n_3),
.Y(n_15)
);


endmodule