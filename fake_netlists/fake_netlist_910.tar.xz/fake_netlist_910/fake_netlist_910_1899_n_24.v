module fake_netlist_910_1899_n_24 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_24);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_24;

wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_22;
wire n_14;

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_13),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_12),
.C(n_0),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_9),
.B(n_3),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_6),
.A2(n_2),
.B1(n_4),
.B2(n_11),
.Y(n_17)
);

AO31x2_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_6),
.A3(n_5),
.B(n_4),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_15),
.B(n_16),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.B(n_18),
.C(n_5),
.Y(n_21)
);

AND3x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_7),
.C(n_1),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_7),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_21),
.Y(n_24)
);


endmodule