module fake_netlist_910_1440_n_20 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_20);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_20;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_6),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_2),
.B(n_1),
.Y(n_11)
);

O2A1O1Ixp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_4),
.B(n_2),
.C(n_1),
.Y(n_12)
);

AO32x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.A3(n_5),
.B1(n_2),
.B2(n_4),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

O2A1O1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B(n_7),
.C(n_13),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B(n_9),
.C(n_7),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_5),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_17),
.A2(n_6),
.B1(n_5),
.B2(n_0),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_3),
.B1(n_6),
.B2(n_19),
.Y(n_20)
);


endmodule