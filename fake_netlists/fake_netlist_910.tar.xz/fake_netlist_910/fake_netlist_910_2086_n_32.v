module fake_netlist_910_2086_n_32 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_32);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_32;

wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_31;
wire n_21;
wire n_22;
wire n_25;
wire n_26;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_11),
.Y(n_18)
);

AND3x2_ASAP7_75t_L g19 ( 
.A(n_1),
.B(n_10),
.C(n_12),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_9),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_7),
.B(n_5),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_18),
.A2(n_3),
.B(n_2),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

AO31x2_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.A3(n_23),
.B(n_22),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_16),
.Y(n_27)
);

AOI32xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_20),
.A3(n_16),
.B1(n_19),
.B2(n_24),
.Y(n_28)
);

AOI211xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_8),
.B(n_6),
.C(n_4),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_29),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_17),
.B1(n_15),
.B2(n_13),
.Y(n_32)
);


endmodule