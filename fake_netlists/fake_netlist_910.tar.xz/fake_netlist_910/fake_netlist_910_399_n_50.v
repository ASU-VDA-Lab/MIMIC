module fake_netlist_910_399_n_50 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_50);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_50;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_25;
wire n_41;
wire n_35;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_45;
wire n_44;
wire n_48;
wire n_38;

BUFx3_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_19),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_17),
.B(n_2),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

CKINVDCx6p67_ASAP7_75t_R g30 ( 
.A(n_20),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_8),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_11),
.B(n_7),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_5),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

BUFx8_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_23),
.B(n_0),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_28),
.B(n_3),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

OAI21xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_32),
.B(n_27),
.Y(n_39)
);

OAI221xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_33),
.B1(n_24),
.B2(n_36),
.C(n_31),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_30),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_35),
.Y(n_42)
);

AND2x4_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_26),
.Y(n_43)
);

NOR3xp33_ASAP7_75t_SL g44 ( 
.A(n_42),
.B(n_9),
.C(n_6),
.Y(n_44)
);

INVx3_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AOI322xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_44),
.A3(n_31),
.B1(n_13),
.B2(n_14),
.C1(n_10),
.C2(n_12),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_47),
.Y(n_48)
);

CKINVDCx20_ASAP7_75t_R g49 ( 
.A(n_48),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_49),
.A2(n_46),
.B1(n_18),
.B2(n_16),
.Y(n_50)
);


endmodule