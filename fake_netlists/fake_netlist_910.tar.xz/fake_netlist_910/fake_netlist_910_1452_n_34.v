module fake_netlist_910_1452_n_34 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_34);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_34;

wire n_33;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_25;
wire n_22;
wire n_32;
wire n_26;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_5),
.Y(n_20)
);

AOI21x1_ASAP7_75t_L g21 ( 
.A1(n_2),
.A2(n_8),
.B(n_7),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_4),
.Y(n_22)
);

NOR2x1p5_ASAP7_75t_L g23 ( 
.A(n_1),
.B(n_11),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_18),
.B(n_13),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_13),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_25),
.B(n_20),
.Y(n_26)
);

OR2x6_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_19),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_17),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_22),
.B1(n_17),
.B2(n_26),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_29),
.Y(n_30)
);

NOR4xp25_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_22),
.C(n_23),
.D(n_21),
.Y(n_31)
);

XNOR2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_15),
.Y(n_32)
);

OAI22x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_16),
.B2(n_15),
.Y(n_33)
);

AOI222xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_9),
.B1(n_6),
.B2(n_10),
.C1(n_14),
.C2(n_12),
.Y(n_34)
);


endmodule