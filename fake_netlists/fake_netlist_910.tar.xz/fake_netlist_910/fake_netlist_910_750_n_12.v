module fake_netlist_910_750_n_12 (n_0, n_1, n_2, n_12);

input n_0;
input n_1;
input n_2;

output n_12;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

AND2x4_ASAP7_75t_SL g4 ( 
.A(n_2),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

INVx5_ASAP7_75t_SL g8 ( 
.A(n_6),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_SL g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_6),
.B(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI321xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.A3(n_2),
.B1(n_6),
.B2(n_8),
.C(n_3),
.Y(n_12)
);


endmodule