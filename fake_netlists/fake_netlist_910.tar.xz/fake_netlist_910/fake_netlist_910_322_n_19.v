module fake_netlist_910_322_n_19 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_19);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_19;

wire n_15;
wire n_11;
wire n_16;
wire n_12;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_2),
.B(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_14),
.B1(n_5),
.B2(n_2),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_17),
.B1(n_6),
.B2(n_5),
.Y(n_19)
);


endmodule