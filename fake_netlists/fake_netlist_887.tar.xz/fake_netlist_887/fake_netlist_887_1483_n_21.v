module fake_netlist_887_1483_n_21 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_21;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

BUFx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_1),
.B(n_5),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_0),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_4),
.B(n_3),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

INVxp67_ASAP7_75t_SL g14 ( 
.A(n_13),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B(n_10),
.C(n_9),
.Y(n_16)
);

AOI211xp5_ASAP7_75t_SL g17 ( 
.A1(n_15),
.A2(n_11),
.B(n_6),
.C(n_3),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_2),
.B1(n_9),
.B2(n_19),
.Y(n_21)
);


endmodule