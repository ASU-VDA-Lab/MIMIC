module fake_netlist_887_2247_n_23 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_23);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_23;

wire n_15;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_18;
wire n_17;
wire n_13;
wire n_21;
wire n_22;
wire n_14;

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_0),
.A2(n_1),
.B1(n_7),
.B2(n_10),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_3),
.B(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

OA21x2_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_13),
.B(n_15),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI211xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.B(n_6),
.C(n_2),
.Y(n_20)
);

OAI22xp33_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_17),
.B1(n_9),
.B2(n_8),
.Y(n_21)
);

INVxp67_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_11),
.Y(n_23)
);


endmodule