module fake_netlist_887_1415_n_21 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_21;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_14;
wire n_10;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

AND3x2_ASAP7_75t_L g11 ( 
.A(n_2),
.B(n_3),
.C(n_4),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_4),
.B(n_6),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_5),
.B(n_1),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B(n_0),
.Y(n_14)
);

O2A1O1Ixp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_7),
.B(n_6),
.C(n_9),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

NOR2x1_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.Y(n_17)
);

NAND4xp25_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.C(n_10),
.D(n_11),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_7),
.Y(n_21)
);


endmodule