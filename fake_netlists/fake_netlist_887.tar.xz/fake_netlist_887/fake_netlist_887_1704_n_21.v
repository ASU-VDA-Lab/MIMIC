module fake_netlist_887_1704_n_21 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_21;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

BUFx10_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_4),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_SL g11 ( 
.A(n_8),
.B(n_4),
.C(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_15),
.B(n_8),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_9),
.B1(n_7),
.B2(n_10),
.Y(n_17)
);

OAI21xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_7),
.B(n_1),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_16),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_18),
.B1(n_6),
.B2(n_2),
.Y(n_21)
);


endmodule