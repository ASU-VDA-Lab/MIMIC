module fake_netlist_887_4174_n_24 (n_0, n_2, n_5, n_3, n_4, n_1, n_24);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_24;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

NAND3xp33_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_4),
.C(n_3),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

NAND2xp33_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_3),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_7),
.B(n_6),
.Y(n_11)
);

O2A1O1Ixp5_ASAP7_75t_SL g12 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_0),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_12),
.B(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_16),
.B(n_15),
.C(n_14),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_SL g20 ( 
.A1(n_17),
.A2(n_18),
.B(n_16),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_18),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_16),
.Y(n_22)
);

AOI22x1_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_10),
.B1(n_22),
.B2(n_18),
.Y(n_23)
);

OA21x2_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_21),
.B(n_22),
.Y(n_24)
);


endmodule