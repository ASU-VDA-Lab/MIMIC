module fake_netlist_887_1150_n_19 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_19);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_19;

wire n_15;
wire n_11;
wire n_16;
wire n_12;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_3),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_5),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_1),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND4xp25_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_7),
.C(n_9),
.D(n_10),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI31xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_6),
.A3(n_4),
.B(n_8),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_17),
.A2(n_2),
.B1(n_4),
.B2(n_18),
.Y(n_19)
);


endmodule