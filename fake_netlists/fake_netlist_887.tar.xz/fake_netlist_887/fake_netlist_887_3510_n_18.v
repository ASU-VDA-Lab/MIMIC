module fake_netlist_887_3510_n_18 (n_0, n_2, n_3, n_4, n_1, n_18);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_18;

wire n_5;
wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_17;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

NAND2x1_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_2),
.Y(n_7)
);

NOR2xp67_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_4),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_1),
.B(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

OAI21xp33_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_1),
.B(n_3),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_6),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

XNOR2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_6),
.Y(n_15)
);

AOI211x1_ASAP7_75t_SL g16 ( 
.A1(n_14),
.A2(n_11),
.B(n_12),
.C(n_10),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_13),
.B1(n_15),
.B2(n_16),
.Y(n_18)
);


endmodule