module fake_netlist_887_2114_n_15 (n_0, n_1, n_2, n_15);

input n_0;
input n_1;
input n_2;

output n_15;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

BUFx3_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

AO31x2_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_3),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_0),
.B1(n_2),
.B2(n_4),
.C(n_3),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B(n_10),
.C(n_8),
.Y(n_12)
);

INVxp33_ASAP7_75t_SL g13 ( 
.A(n_12),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B(n_0),
.Y(n_14)
);

OR2x6_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);


endmodule