module fake_netlist_887_361_n_21 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_21;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_14;
wire n_10;
wire n_8;

INVx1_ASAP7_75t_SL g8 ( 
.A(n_5),
.Y(n_8)
);

AOI21x1_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_2),
.B(n_6),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

NOR2xp67_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_1),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_8),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_8),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_9),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_10),
.B1(n_12),
.B2(n_9),
.C(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_16),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_19),
.B(n_16),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_7),
.B1(n_6),
.B2(n_3),
.Y(n_21)
);


endmodule