module fake_netlist_887_583_n_20 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_20);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_20;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_6),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

O2A1O1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_5),
.B(n_4),
.C(n_1),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

NAND2xp33_ASAP7_75t_R g13 ( 
.A(n_11),
.B(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_12),
.B(n_10),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_12),
.Y(n_18)
);

OAI22x1_ASAP7_75t_SL g19 ( 
.A1(n_17),
.A2(n_9),
.B1(n_5),
.B2(n_0),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_18),
.B1(n_3),
.B2(n_2),
.Y(n_20)
);


endmodule