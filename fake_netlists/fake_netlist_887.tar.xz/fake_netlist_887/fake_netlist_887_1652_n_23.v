module fake_netlist_887_1652_n_23 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_23);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_23;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

AND2x4_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_3),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

BUFx10_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_10),
.B(n_2),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_9),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_8),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.Y(n_17)
);

NAND3x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_8),
.C(n_13),
.Y(n_18)
);

NOR2xp67_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_SL g22 ( 
.A(n_20),
.B(n_1),
.Y(n_22)
);

AOI322xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_5),
.A3(n_6),
.B1(n_7),
.B2(n_21),
.C1(n_15),
.C2(n_10),
.Y(n_23)
);


endmodule