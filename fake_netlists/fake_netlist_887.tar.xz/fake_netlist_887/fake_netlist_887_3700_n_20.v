module fake_netlist_887_3700_n_20 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_20);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_20;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_14;
wire n_10;

INVx2_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

NOR2xp67_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_8),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_1),
.A2(n_6),
.B1(n_4),
.B2(n_5),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_5),
.B(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B(n_13),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_11),
.Y(n_18)
);

OA22x2_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.B1(n_7),
.B2(n_2),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_3),
.B(n_7),
.Y(n_20)
);


endmodule