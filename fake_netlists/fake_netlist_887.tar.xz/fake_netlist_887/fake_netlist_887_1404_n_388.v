module fake_netlist_887_1404_n_388 (n_3, n_33, n_50, n_15, n_11, n_34, n_24, n_6, n_37, n_16, n_47, n_0, n_46, n_30, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_49, n_20, n_40, n_9, n_39, n_17, n_18, n_31, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_32, n_35, n_41, n_42, n_43, n_26, n_10, n_29, n_36, n_44, n_45, n_8, n_48, n_38, n_388);

input n_3;
input n_33;
input n_50;
input n_15;
input n_11;
input n_34;
input n_24;
input n_6;
input n_37;
input n_16;
input n_47;
input n_0;
input n_46;
input n_30;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_49;
input n_20;
input n_40;
input n_9;
input n_39;
input n_17;
input n_18;
input n_31;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_32;
input n_35;
input n_41;
input n_42;
input n_43;
input n_26;
input n_10;
input n_29;
input n_36;
input n_44;
input n_45;
input n_8;
input n_48;
input n_38;

output n_388;

wire n_104;
wire n_337;
wire n_240;
wire n_341;
wire n_154;
wire n_193;
wire n_294;
wire n_164;
wire n_345;
wire n_143;
wire n_195;
wire n_169;
wire n_292;
wire n_192;
wire n_289;
wire n_94;
wire n_182;
wire n_308;
wire n_224;
wire n_80;
wire n_229;
wire n_351;
wire n_288;
wire n_83;
wire n_207;
wire n_210;
wire n_369;
wire n_354;
wire n_190;
wire n_51;
wire n_217;
wire n_387;
wire n_242;
wire n_270;
wire n_296;
wire n_183;
wire n_144;
wire n_54;
wire n_356;
wire n_238;
wire n_189;
wire n_381;
wire n_245;
wire n_325;
wire n_363;
wire n_141;
wire n_150;
wire n_226;
wire n_335;
wire n_142;
wire n_383;
wire n_256;
wire n_159;
wire n_297;
wire n_184;
wire n_293;
wire n_303;
wire n_113;
wire n_350;
wire n_208;
wire n_266;
wire n_172;
wire n_77;
wire n_204;
wire n_274;
wire n_106;
wire n_81;
wire n_84;
wire n_300;
wire n_346;
wire n_283;
wire n_130;
wire n_72;
wire n_76;
wire n_278;
wire n_179;
wire n_310;
wire n_103;
wire n_160;
wire n_108;
wire n_163;
wire n_385;
wire n_105;
wire n_215;
wire n_362;
wire n_232;
wire n_58;
wire n_328;
wire n_231;
wire n_98;
wire n_267;
wire n_89;
wire n_82;
wire n_117;
wire n_146;
wire n_78;
wire n_333;
wire n_118;
wire n_100;
wire n_60;
wire n_358;
wire n_216;
wire n_101;
wire n_127;
wire n_111;
wire n_314;
wire n_153;
wire n_371;
wire n_244;
wire n_102;
wire n_360;
wire n_306;
wire n_197;
wire n_212;
wire n_316;
wire n_264;
wire n_214;
wire n_91;
wire n_273;
wire n_149;
wire n_284;
wire n_196;
wire n_69;
wire n_165;
wire n_131;
wire n_55;
wire n_365;
wire n_247;
wire n_285;
wire n_286;
wire n_366;
wire n_344;
wire n_386;
wire n_237;
wire n_312;
wire n_132;
wire n_225;
wire n_120;
wire n_188;
wire n_252;
wire n_230;
wire n_200;
wire n_280;
wire n_53;
wire n_161;
wire n_90;
wire n_376;
wire n_277;
wire n_221;
wire n_140;
wire n_324;
wire n_301;
wire n_138;
wire n_122;
wire n_269;
wire n_139;
wire n_263;
wire n_181;
wire n_74;
wire n_331;
wire n_158;
wire n_380;
wire n_86;
wire n_63;
wire n_241;
wire n_114;
wire n_156;
wire n_205;
wire n_109;
wire n_168;
wire n_315;
wire n_97;
wire n_178;
wire n_194;
wire n_249;
wire n_92;
wire n_287;
wire n_262;
wire n_235;
wire n_379;
wire n_52;
wire n_355;
wire n_152;
wire n_151;
wire n_185;
wire n_349;
wire n_116;
wire n_334;
wire n_64;
wire n_65;
wire n_88;
wire n_253;
wire n_268;
wire n_305;
wire n_71;
wire n_135;
wire n_302;
wire n_311;
wire n_134;
wire n_276;
wire n_162;
wire n_223;
wire n_248;
wire n_320;
wire n_384;
wire n_211;
wire n_59;
wire n_227;
wire n_347;
wire n_220;
wire n_373;
wire n_222;
wire n_364;
wire n_255;
wire n_271;
wire n_148;
wire n_375;
wire n_257;
wire n_342;
wire n_115;
wire n_155;
wire n_233;
wire n_129;
wire n_372;
wire n_272;
wire n_95;
wire n_258;
wire n_378;
wire n_327;
wire n_279;
wire n_251;
wire n_322;
wire n_56;
wire n_175;
wire n_213;
wire n_125;
wire n_275;
wire n_336;
wire n_75;
wire n_236;
wire n_124;
wire n_265;
wire n_147;
wire n_219;
wire n_239;
wire n_254;
wire n_57;
wire n_121;
wire n_261;
wire n_73;
wire n_202;
wire n_250;
wire n_298;
wire n_357;
wire n_99;
wire n_377;
wire n_93;
wire n_157;
wire n_66;
wire n_338;
wire n_186;
wire n_198;
wire n_206;
wire n_174;
wire n_339;
wire n_374;
wire n_228;
wire n_321;
wire n_299;
wire n_318;
wire n_96;
wire n_128;
wire n_323;
wire n_368;
wire n_123;
wire n_234;
wire n_329;
wire n_110;
wire n_295;
wire n_177;
wire n_173;
wire n_166;
wire n_370;
wire n_313;
wire n_70;
wire n_243;
wire n_282;
wire n_317;
wire n_126;
wire n_353;
wire n_62;
wire n_79;
wire n_187;
wire n_87;
wire n_361;
wire n_307;
wire n_191;
wire n_209;
wire n_340;
wire n_107;
wire n_199;
wire n_309;
wire n_180;
wire n_137;
wire n_167;
wire n_291;
wire n_343;
wire n_367;
wire n_171;
wire n_61;
wire n_330;
wire n_170;
wire n_136;
wire n_246;
wire n_304;
wire n_176;
wire n_133;
wire n_352;
wire n_326;
wire n_218;
wire n_290;
wire n_281;
wire n_68;
wire n_382;
wire n_359;
wire n_145;
wire n_85;
wire n_112;
wire n_67;
wire n_259;
wire n_119;
wire n_260;
wire n_319;
wire n_203;
wire n_348;
wire n_332;
wire n_201;

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_21),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_0),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_33),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_23),
.Y(n_54)
);

CKINVDCx16_ASAP7_75t_R g55 ( 
.A(n_3),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_4),
.Y(n_56)
);

INVxp33_ASAP7_75t_SL g57 ( 
.A(n_43),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_1),
.Y(n_58)
);

BUFx3_ASAP7_75t_L g59 ( 
.A(n_16),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_49),
.Y(n_60)
);

CKINVDCx5p33_ASAP7_75t_R g61 ( 
.A(n_2),
.Y(n_61)
);

INVxp67_ASAP7_75t_SL g62 ( 
.A(n_30),
.Y(n_62)
);

HB1xp67_ASAP7_75t_L g63 ( 
.A(n_7),
.Y(n_63)
);

CKINVDCx16_ASAP7_75t_R g64 ( 
.A(n_24),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_34),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_36),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_4),
.Y(n_67)
);

INVxp33_ASAP7_75t_SL g68 ( 
.A(n_2),
.Y(n_68)
);

BUFx3_ASAP7_75t_L g69 ( 
.A(n_12),
.Y(n_69)
);

BUFx3_ASAP7_75t_L g70 ( 
.A(n_39),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_70),
.Y(n_71)
);

NAND2x1p5_ASAP7_75t_L g72 ( 
.A(n_70),
.B(n_0),
.Y(n_72)
);

CKINVDCx5p33_ASAP7_75t_R g73 ( 
.A(n_64),
.Y(n_73)
);

OA21x2_ASAP7_75t_L g74 ( 
.A1(n_52),
.A2(n_3),
.B(n_1),
.Y(n_74)
);

BUFx6f_ASAP7_75t_L g75 ( 
.A(n_70),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_59),
.Y(n_76)
);

INVx2_ASAP7_75t_L g77 ( 
.A(n_70),
.Y(n_77)
);

NAND3xp33_ASAP7_75t_L g78 ( 
.A(n_63),
.B(n_6),
.C(n_5),
.Y(n_78)
);

CKINVDCx20_ASAP7_75t_R g79 ( 
.A(n_55),
.Y(n_79)
);

NAND2xp5_ASAP7_75t_L g80 ( 
.A(n_59),
.B(n_5),
.Y(n_80)
);

OAI22xp5_ASAP7_75t_L g81 ( 
.A1(n_78),
.A2(n_55),
.B1(n_63),
.B2(n_68),
.Y(n_81)
);

NAND2xp33_ASAP7_75t_SL g82 ( 
.A(n_80),
.B(n_51),
.Y(n_82)
);

AOI22xp33_ASAP7_75t_L g83 ( 
.A1(n_78),
.A2(n_69),
.B1(n_59),
.B2(n_68),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_75),
.Y(n_84)
);

INVx2_ASAP7_75t_L g85 ( 
.A(n_75),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_75),
.Y(n_86)
);

NAND2xp5_ASAP7_75t_L g87 ( 
.A(n_71),
.B(n_51),
.Y(n_87)
);

OAI221xp5_ASAP7_75t_L g88 ( 
.A1(n_80),
.A2(n_56),
.B1(n_52),
.B2(n_58),
.C(n_67),
.Y(n_88)
);

BUFx3_ASAP7_75t_L g89 ( 
.A(n_75),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_75),
.Y(n_90)
);

NAND2x1p5_ASAP7_75t_L g91 ( 
.A(n_74),
.B(n_53),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_75),
.Y(n_92)
);

OAI22xp5_ASAP7_75t_L g93 ( 
.A1(n_72),
.A2(n_58),
.B1(n_56),
.B2(n_52),
.Y(n_93)
);

INVx2_ASAP7_75t_SL g94 ( 
.A(n_75),
.Y(n_94)
);

BUFx3_ASAP7_75t_L g95 ( 
.A(n_71),
.Y(n_95)
);

AO22x2_ASAP7_75t_L g96 ( 
.A1(n_71),
.A2(n_60),
.B1(n_54),
.B2(n_53),
.Y(n_96)
);

AND2x4_ASAP7_75t_L g97 ( 
.A(n_77),
.B(n_62),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_97),
.B(n_77),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_97),
.B(n_77),
.Y(n_99)
);

NOR2xp33_ASAP7_75t_R g100 ( 
.A(n_82),
.B(n_73),
.Y(n_100)
);

NOR2xp33_ASAP7_75t_L g101 ( 
.A(n_82),
.B(n_57),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_95),
.Y(n_102)
);

AND2x4_ASAP7_75t_L g103 ( 
.A(n_97),
.B(n_76),
.Y(n_103)
);

NAND2xp5_ASAP7_75t_SL g104 ( 
.A(n_81),
.B(n_64),
.Y(n_104)
);

NOR3xp33_ASAP7_75t_SL g105 ( 
.A(n_81),
.B(n_61),
.C(n_56),
.Y(n_105)
);

AOI22xp33_ASAP7_75t_L g106 ( 
.A1(n_93),
.A2(n_74),
.B1(n_72),
.B2(n_59),
.Y(n_106)
);

NOR3xp33_ASAP7_75t_SL g107 ( 
.A(n_88),
.B(n_67),
.C(n_58),
.Y(n_107)
);

CKINVDCx5p33_ASAP7_75t_R g108 ( 
.A(n_87),
.Y(n_108)
);

CKINVDCx14_ASAP7_75t_R g109 ( 
.A(n_93),
.Y(n_109)
);

INVx2_ASAP7_75t_L g110 ( 
.A(n_95),
.Y(n_110)
);

HB1xp67_ASAP7_75t_L g111 ( 
.A(n_87),
.Y(n_111)
);

NAND2xp5_ASAP7_75t_L g112 ( 
.A(n_97),
.B(n_76),
.Y(n_112)
);

NOR3xp33_ASAP7_75t_SL g113 ( 
.A(n_88),
.B(n_67),
.C(n_62),
.Y(n_113)
);

INVxp67_ASAP7_75t_L g114 ( 
.A(n_97),
.Y(n_114)
);

NOR2xp33_ASAP7_75t_R g115 ( 
.A(n_89),
.B(n_79),
.Y(n_115)
);

OAI22xp5_ASAP7_75t_L g116 ( 
.A1(n_83),
.A2(n_72),
.B1(n_79),
.B2(n_69),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_95),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_95),
.Y(n_118)
);

AND2x4_ASAP7_75t_L g119 ( 
.A(n_89),
.B(n_53),
.Y(n_119)
);

BUFx2_ASAP7_75t_L g120 ( 
.A(n_115),
.Y(n_120)
);

INVx4_ASAP7_75t_L g121 ( 
.A(n_103),
.Y(n_121)
);

INVx2_ASAP7_75t_L g122 ( 
.A(n_102),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_103),
.Y(n_123)
);

CKINVDCx16_ASAP7_75t_R g124 ( 
.A(n_100),
.Y(n_124)
);

BUFx10_ASAP7_75t_L g125 ( 
.A(n_103),
.Y(n_125)
);

BUFx4f_ASAP7_75t_L g126 ( 
.A(n_103),
.Y(n_126)
);

INVx3_ASAP7_75t_L g127 ( 
.A(n_110),
.Y(n_127)
);

BUFx6f_ASAP7_75t_L g128 ( 
.A(n_110),
.Y(n_128)
);

NAND3xp33_ASAP7_75t_L g129 ( 
.A(n_114),
.B(n_83),
.C(n_74),
.Y(n_129)
);

AOI21xp5_ASAP7_75t_L g130 ( 
.A1(n_98),
.A2(n_91),
.B(n_94),
.Y(n_130)
);

NAND2xp5_ASAP7_75t_SL g131 ( 
.A(n_108),
.B(n_57),
.Y(n_131)
);

NAND2xp5_ASAP7_75t_L g132 ( 
.A(n_114),
.B(n_91),
.Y(n_132)
);

AND2x4_ASAP7_75t_L g133 ( 
.A(n_119),
.B(n_112),
.Y(n_133)
);

AOI21xp5_ASAP7_75t_L g134 ( 
.A1(n_98),
.A2(n_91),
.B(n_94),
.Y(n_134)
);

AND2x2_ASAP7_75t_L g135 ( 
.A(n_111),
.B(n_91),
.Y(n_135)
);

BUFx6f_ASAP7_75t_L g136 ( 
.A(n_110),
.Y(n_136)
);

HB1xp67_ASAP7_75t_L g137 ( 
.A(n_111),
.Y(n_137)
);

AOI22xp33_ASAP7_75t_L g138 ( 
.A1(n_135),
.A2(n_104),
.B1(n_109),
.B2(n_101),
.Y(n_138)
);

NOR2xp33_ASAP7_75t_L g139 ( 
.A(n_131),
.B(n_116),
.Y(n_139)
);

AOI21xp5_ASAP7_75t_L g140 ( 
.A1(n_126),
.A2(n_99),
.B(n_112),
.Y(n_140)
);

OAI22xp33_ASAP7_75t_L g141 ( 
.A1(n_123),
.A2(n_116),
.B1(n_99),
.B2(n_72),
.Y(n_141)
);

AOI22xp33_ASAP7_75t_L g142 ( 
.A1(n_135),
.A2(n_106),
.B1(n_119),
.B2(n_102),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_123),
.Y(n_143)
);

BUFx2_ASAP7_75t_L g144 ( 
.A(n_137),
.Y(n_144)
);

NOR2xp33_ASAP7_75t_R g145 ( 
.A(n_124),
.B(n_118),
.Y(n_145)
);

AOI22xp33_ASAP7_75t_L g146 ( 
.A1(n_135),
.A2(n_119),
.B1(n_118),
.B2(n_117),
.Y(n_146)
);

AOI22xp33_ASAP7_75t_L g147 ( 
.A1(n_133),
.A2(n_119),
.B1(n_117),
.B2(n_74),
.Y(n_147)
);

AOI22xp33_ASAP7_75t_L g148 ( 
.A1(n_133),
.A2(n_117),
.B1(n_74),
.B2(n_54),
.Y(n_148)
);

BUFx6f_ASAP7_75t_L g149 ( 
.A(n_125),
.Y(n_149)
);

OAI22xp33_ASAP7_75t_L g150 ( 
.A1(n_139),
.A2(n_137),
.B1(n_129),
.B2(n_132),
.Y(n_150)
);

AOI22xp33_ASAP7_75t_L g151 ( 
.A1(n_141),
.A2(n_129),
.B1(n_133),
.B2(n_96),
.Y(n_151)
);

AND2x2_ASAP7_75t_L g152 ( 
.A(n_138),
.B(n_133),
.Y(n_152)
);

BUFx3_ASAP7_75t_L g153 ( 
.A(n_149),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_143),
.Y(n_154)
);

OAI21xp5_ASAP7_75t_L g155 ( 
.A1(n_140),
.A2(n_130),
.B(n_134),
.Y(n_155)
);

AOI222xp33_ASAP7_75t_L g156 ( 
.A1(n_144),
.A2(n_69),
.B1(n_105),
.B2(n_120),
.C1(n_60),
.C2(n_54),
.Y(n_156)
);

INVx2_ASAP7_75t_L g157 ( 
.A(n_149),
.Y(n_157)
);

CKINVDCx5p33_ASAP7_75t_R g158 ( 
.A(n_145),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_146),
.Y(n_159)
);

OAI22xp5_ASAP7_75t_L g160 ( 
.A1(n_142),
.A2(n_132),
.B1(n_126),
.B2(n_105),
.Y(n_160)
);

AND2x6_ASAP7_75t_L g161 ( 
.A(n_149),
.B(n_133),
.Y(n_161)
);

NAND3xp33_ASAP7_75t_SL g162 ( 
.A(n_156),
.B(n_120),
.C(n_152),
.Y(n_162)
);

OAI22xp5_ASAP7_75t_L g163 ( 
.A1(n_151),
.A2(n_148),
.B1(n_147),
.B2(n_113),
.Y(n_163)
);

BUFx3_ASAP7_75t_L g164 ( 
.A(n_153),
.Y(n_164)
);

BUFx3_ASAP7_75t_L g165 ( 
.A(n_153),
.Y(n_165)
);

OAI321xp33_ASAP7_75t_L g166 ( 
.A1(n_150),
.A2(n_151),
.A3(n_160),
.B1(n_159),
.B2(n_155),
.C(n_152),
.Y(n_166)
);

OAI332xp33_ASAP7_75t_L g167 ( 
.A1(n_150),
.A2(n_124),
.A3(n_65),
.B1(n_66),
.B2(n_60),
.B3(n_113),
.C1(n_107),
.C2(n_69),
.Y(n_167)
);

NAND2xp5_ASAP7_75t_L g168 ( 
.A(n_159),
.B(n_122),
.Y(n_168)
);

INVx2_ASAP7_75t_L g169 ( 
.A(n_154),
.Y(n_169)
);

OAI21x1_ASAP7_75t_L g170 ( 
.A1(n_155),
.A2(n_134),
.B(n_130),
.Y(n_170)
);

OAI222xp33_ASAP7_75t_L g171 ( 
.A1(n_160),
.A2(n_144),
.B1(n_66),
.B2(n_65),
.C1(n_107),
.C2(n_122),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_154),
.Y(n_172)
);

AO21x2_ASAP7_75t_L g173 ( 
.A1(n_152),
.A2(n_157),
.B(n_122),
.Y(n_173)
);

AND2x2_ASAP7_75t_L g174 ( 
.A(n_157),
.B(n_96),
.Y(n_174)
);

AND2x2_ASAP7_75t_L g175 ( 
.A(n_157),
.B(n_96),
.Y(n_175)
);

INVx2_ASAP7_75t_L g176 ( 
.A(n_161),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_161),
.Y(n_177)
);

OAI211xp5_ASAP7_75t_L g178 ( 
.A1(n_156),
.A2(n_66),
.B(n_65),
.C(n_121),
.Y(n_178)
);

AOI221xp5_ASAP7_75t_L g179 ( 
.A1(n_153),
.A2(n_96),
.B1(n_126),
.B2(n_121),
.C(n_127),
.Y(n_179)
);

OAI221xp5_ASAP7_75t_SL g180 ( 
.A1(n_178),
.A2(n_153),
.B1(n_158),
.B2(n_6),
.C(n_7),
.Y(n_180)
);

BUFx3_ASAP7_75t_L g181 ( 
.A(n_164),
.Y(n_181)
);

NOR2xp33_ASAP7_75t_L g182 ( 
.A(n_167),
.B(n_162),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_172),
.Y(n_183)
);

BUFx2_ASAP7_75t_L g184 ( 
.A(n_164),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_172),
.Y(n_185)
);

OAI221xp5_ASAP7_75t_L g186 ( 
.A1(n_178),
.A2(n_162),
.B1(n_163),
.B2(n_167),
.C(n_179),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_172),
.Y(n_187)
);

INVx1_ASAP7_75t_L g188 ( 
.A(n_169),
.Y(n_188)
);

NOR2xp33_ASAP7_75t_SL g189 ( 
.A(n_171),
.B(n_164),
.Y(n_189)
);

INVx1_ASAP7_75t_SL g190 ( 
.A(n_164),
.Y(n_190)
);

INVx1_ASAP7_75t_L g191 ( 
.A(n_169),
.Y(n_191)
);

OR2x2_ASAP7_75t_L g192 ( 
.A(n_173),
.B(n_168),
.Y(n_192)
);

NAND2xp5_ASAP7_75t_SL g193 ( 
.A(n_166),
.B(n_149),
.Y(n_193)
);

INVx1_ASAP7_75t_SL g194 ( 
.A(n_165),
.Y(n_194)
);

INVx1_ASAP7_75t_SL g195 ( 
.A(n_165),
.Y(n_195)
);

OAI33xp33_ASAP7_75t_L g196 ( 
.A1(n_168),
.A2(n_92),
.A3(n_90),
.B1(n_86),
.B2(n_96),
.B3(n_8),
.Y(n_196)
);

AND2x4_ASAP7_75t_L g197 ( 
.A(n_165),
.B(n_161),
.Y(n_197)
);

INVx1_ASAP7_75t_L g198 ( 
.A(n_169),
.Y(n_198)
);

INVx1_ASAP7_75t_L g199 ( 
.A(n_169),
.Y(n_199)
);

OR2x2_ASAP7_75t_L g200 ( 
.A(n_173),
.B(n_149),
.Y(n_200)
);

AND2x2_ASAP7_75t_L g201 ( 
.A(n_174),
.B(n_96),
.Y(n_201)
);

INVx4_ASAP7_75t_L g202 ( 
.A(n_165),
.Y(n_202)
);

INVxp67_ASAP7_75t_SL g203 ( 
.A(n_168),
.Y(n_203)
);

AOI22xp5_ASAP7_75t_L g204 ( 
.A1(n_163),
.A2(n_161),
.B1(n_126),
.B2(n_121),
.Y(n_204)
);

NOR3xp33_ASAP7_75t_L g205 ( 
.A(n_167),
.B(n_121),
.C(n_127),
.Y(n_205)
);

INVx1_ASAP7_75t_L g206 ( 
.A(n_174),
.Y(n_206)
);

INVx1_ASAP7_75t_L g207 ( 
.A(n_174),
.Y(n_207)
);

NAND2xp5_ASAP7_75t_L g208 ( 
.A(n_173),
.B(n_161),
.Y(n_208)
);

AO31x2_ASAP7_75t_L g209 ( 
.A1(n_163),
.A2(n_121),
.A3(n_85),
.B(n_84),
.Y(n_209)
);

AOI31xp33_ASAP7_75t_L g210 ( 
.A1(n_182),
.A2(n_177),
.A3(n_176),
.B(n_179),
.Y(n_210)
);

INVx1_ASAP7_75t_L g211 ( 
.A(n_183),
.Y(n_211)
);

INVx1_ASAP7_75t_L g212 ( 
.A(n_185),
.Y(n_212)
);

INVx1_ASAP7_75t_L g213 ( 
.A(n_187),
.Y(n_213)
);

CKINVDCx5p33_ASAP7_75t_R g214 ( 
.A(n_181),
.Y(n_214)
);

AND3x2_ASAP7_75t_L g215 ( 
.A(n_182),
.B(n_177),
.C(n_179),
.Y(n_215)
);

AND2x2_ASAP7_75t_L g216 ( 
.A(n_200),
.B(n_173),
.Y(n_216)
);

AND2x2_ASAP7_75t_L g217 ( 
.A(n_200),
.B(n_173),
.Y(n_217)
);

INVxp67_ASAP7_75t_L g218 ( 
.A(n_184),
.Y(n_218)
);

NAND2xp5_ASAP7_75t_L g219 ( 
.A(n_203),
.B(n_173),
.Y(n_219)
);

INVx1_ASAP7_75t_L g220 ( 
.A(n_192),
.Y(n_220)
);

NAND2xp5_ASAP7_75t_L g221 ( 
.A(n_206),
.B(n_174),
.Y(n_221)
);

AND2x2_ASAP7_75t_L g222 ( 
.A(n_188),
.B(n_175),
.Y(n_222)
);

INVx2_ASAP7_75t_SL g223 ( 
.A(n_181),
.Y(n_223)
);

OR2x2_ASAP7_75t_L g224 ( 
.A(n_192),
.B(n_170),
.Y(n_224)
);

NOR2x1p5_ASAP7_75t_L g225 ( 
.A(n_202),
.B(n_176),
.Y(n_225)
);

INVx1_ASAP7_75t_L g226 ( 
.A(n_191),
.Y(n_226)
);

HB1xp67_ASAP7_75t_L g227 ( 
.A(n_184),
.Y(n_227)
);

INVx4_ASAP7_75t_L g228 ( 
.A(n_202),
.Y(n_228)
);

INVx2_ASAP7_75t_SL g229 ( 
.A(n_202),
.Y(n_229)
);

INVx1_ASAP7_75t_L g230 ( 
.A(n_198),
.Y(n_230)
);

NAND2x1p5_ASAP7_75t_L g231 ( 
.A(n_193),
.B(n_177),
.Y(n_231)
);

INVx1_ASAP7_75t_L g232 ( 
.A(n_199),
.Y(n_232)
);

NOR2xp33_ASAP7_75t_L g233 ( 
.A(n_190),
.B(n_176),
.Y(n_233)
);

HB1xp67_ASAP7_75t_L g234 ( 
.A(n_194),
.Y(n_234)
);

NAND2xp5_ASAP7_75t_L g235 ( 
.A(n_207),
.B(n_175),
.Y(n_235)
);

INVx2_ASAP7_75t_L g236 ( 
.A(n_209),
.Y(n_236)
);

NOR2xp33_ASAP7_75t_L g237 ( 
.A(n_195),
.B(n_176),
.Y(n_237)
);

INVx1_ASAP7_75t_L g238 ( 
.A(n_209),
.Y(n_238)
);

INVx1_ASAP7_75t_L g239 ( 
.A(n_209),
.Y(n_239)
);

AOI31xp67_ASAP7_75t_SL g240 ( 
.A1(n_180),
.A2(n_166),
.A3(n_171),
.B(n_170),
.Y(n_240)
);

AND2x2_ASAP7_75t_L g241 ( 
.A(n_208),
.B(n_175),
.Y(n_241)
);

INVx2_ASAP7_75t_L g242 ( 
.A(n_209),
.Y(n_242)
);

NOR2xp33_ASAP7_75t_R g243 ( 
.A(n_189),
.B(n_175),
.Y(n_243)
);

NAND2xp5_ASAP7_75t_L g244 ( 
.A(n_201),
.B(n_161),
.Y(n_244)
);

AND2x2_ASAP7_75t_L g245 ( 
.A(n_197),
.B(n_170),
.Y(n_245)
);

NAND2xp5_ASAP7_75t_L g246 ( 
.A(n_201),
.B(n_205),
.Y(n_246)
);

AND2x2_ASAP7_75t_SL g247 ( 
.A(n_197),
.B(n_166),
.Y(n_247)
);

HB1xp67_ASAP7_75t_L g248 ( 
.A(n_197),
.Y(n_248)
);

INVx1_ASAP7_75t_SL g249 ( 
.A(n_193),
.Y(n_249)
);

INVx1_ASAP7_75t_L g250 ( 
.A(n_204),
.Y(n_250)
);

INVx1_ASAP7_75t_L g251 ( 
.A(n_186),
.Y(n_251)
);

INVx1_ASAP7_75t_SL g252 ( 
.A(n_196),
.Y(n_252)
);

AND2x2_ASAP7_75t_L g253 ( 
.A(n_200),
.B(n_170),
.Y(n_253)
);

OR2x2_ASAP7_75t_L g254 ( 
.A(n_220),
.B(n_84),
.Y(n_254)
);

OAI21xp5_ASAP7_75t_SL g255 ( 
.A1(n_215),
.A2(n_9),
.B(n_8),
.Y(n_255)
);

INVx1_ASAP7_75t_L g256 ( 
.A(n_211),
.Y(n_256)
);

OAI211xp5_ASAP7_75t_SL g257 ( 
.A1(n_251),
.A2(n_92),
.B(n_90),
.C(n_86),
.Y(n_257)
);

NAND2xp5_ASAP7_75t_L g258 ( 
.A(n_234),
.B(n_161),
.Y(n_258)
);

INVxp67_ASAP7_75t_SL g259 ( 
.A(n_218),
.Y(n_259)
);

INVx1_ASAP7_75t_L g260 ( 
.A(n_211),
.Y(n_260)
);

AOI32xp33_ASAP7_75t_L g261 ( 
.A1(n_251),
.A2(n_10),
.A3(n_9),
.B1(n_11),
.B2(n_12),
.Y(n_261)
);

NAND2xp5_ASAP7_75t_L g262 ( 
.A(n_241),
.B(n_161),
.Y(n_262)
);

INVxp67_ASAP7_75t_L g263 ( 
.A(n_227),
.Y(n_263)
);

INVx1_ASAP7_75t_L g264 ( 
.A(n_212),
.Y(n_264)
);

XNOR2xp5_ASAP7_75t_L g265 ( 
.A(n_248),
.B(n_10),
.Y(n_265)
);

NAND3xp33_ASAP7_75t_L g266 ( 
.A(n_250),
.B(n_246),
.C(n_210),
.Y(n_266)
);

A2O1A1Ixp33_ASAP7_75t_L g267 ( 
.A1(n_240),
.A2(n_127),
.B(n_161),
.C(n_128),
.Y(n_267)
);

INVx5_ASAP7_75t_L g268 ( 
.A(n_228),
.Y(n_268)
);

INVx1_ASAP7_75t_L g269 ( 
.A(n_212),
.Y(n_269)
);

INVx1_ASAP7_75t_L g270 ( 
.A(n_213),
.Y(n_270)
);

OR2x2_ASAP7_75t_L g271 ( 
.A(n_220),
.B(n_84),
.Y(n_271)
);

INVxp67_ASAP7_75t_L g272 ( 
.A(n_233),
.Y(n_272)
);

INVx1_ASAP7_75t_L g273 ( 
.A(n_213),
.Y(n_273)
);

INVx1_ASAP7_75t_L g274 ( 
.A(n_226),
.Y(n_274)
);

NOR2xp67_ASAP7_75t_L g275 ( 
.A(n_224),
.B(n_11),
.Y(n_275)
);

INVx1_ASAP7_75t_L g276 ( 
.A(n_226),
.Y(n_276)
);

AOI22xp5_ASAP7_75t_L g277 ( 
.A1(n_250),
.A2(n_161),
.B1(n_125),
.B2(n_128),
.Y(n_277)
);

XNOR2x1_ASAP7_75t_L g278 ( 
.A(n_214),
.B(n_13),
.Y(n_278)
);

AND2x2_ASAP7_75t_L g279 ( 
.A(n_241),
.B(n_245),
.Y(n_279)
);

OAI222xp33_ASAP7_75t_L g280 ( 
.A1(n_252),
.A2(n_14),
.B1(n_13),
.B2(n_15),
.C1(n_17),
.C2(n_16),
.Y(n_280)
);

CKINVDCx16_ASAP7_75t_R g281 ( 
.A(n_243),
.Y(n_281)
);

INVx3_ASAP7_75t_L g282 ( 
.A(n_214),
.Y(n_282)
);

AOI222xp33_ASAP7_75t_L g283 ( 
.A1(n_247),
.A2(n_15),
.B1(n_14),
.B2(n_17),
.C1(n_19),
.C2(n_18),
.Y(n_283)
);

INVx1_ASAP7_75t_L g284 ( 
.A(n_230),
.Y(n_284)
);

NOR3xp33_ASAP7_75t_L g285 ( 
.A(n_228),
.B(n_127),
.C(n_85),
.Y(n_285)
);

OR2x2_ASAP7_75t_L g286 ( 
.A(n_216),
.B(n_85),
.Y(n_286)
);

NAND2xp5_ASAP7_75t_L g287 ( 
.A(n_237),
.B(n_18),
.Y(n_287)
);

INVx2_ASAP7_75t_L g288 ( 
.A(n_230),
.Y(n_288)
);

NAND2xp5_ASAP7_75t_L g289 ( 
.A(n_216),
.B(n_19),
.Y(n_289)
);

AND2x2_ASAP7_75t_L g290 ( 
.A(n_245),
.B(n_20),
.Y(n_290)
);

INVx2_ASAP7_75t_L g291 ( 
.A(n_232),
.Y(n_291)
);

INVxp67_ASAP7_75t_L g292 ( 
.A(n_223),
.Y(n_292)
);

INVx1_ASAP7_75t_L g293 ( 
.A(n_232),
.Y(n_293)
);

OAI322xp33_ASAP7_75t_L g294 ( 
.A1(n_240),
.A2(n_20),
.A3(n_26),
.B1(n_25),
.B2(n_22),
.C1(n_28),
.C2(n_27),
.Y(n_294)
);

INVxp67_ASAP7_75t_L g295 ( 
.A(n_223),
.Y(n_295)
);

INVx1_ASAP7_75t_L g296 ( 
.A(n_231),
.Y(n_296)
);

AOI221xp5_ASAP7_75t_L g297 ( 
.A1(n_249),
.A2(n_94),
.B1(n_89),
.B2(n_128),
.C(n_136),
.Y(n_297)
);

INVx1_ASAP7_75t_L g298 ( 
.A(n_231),
.Y(n_298)
);

AOI22xp33_ASAP7_75t_L g299 ( 
.A1(n_247),
.A2(n_125),
.B1(n_136),
.B2(n_128),
.Y(n_299)
);

OAI21xp33_ASAP7_75t_SL g300 ( 
.A1(n_247),
.A2(n_225),
.B(n_240),
.Y(n_300)
);

INVx1_ASAP7_75t_L g301 ( 
.A(n_231),
.Y(n_301)
);

NAND3xp33_ASAP7_75t_L g302 ( 
.A(n_283),
.B(n_261),
.C(n_255),
.Y(n_302)
);

AND2x2_ASAP7_75t_L g303 ( 
.A(n_279),
.B(n_217),
.Y(n_303)
);

INVx1_ASAP7_75t_L g304 ( 
.A(n_256),
.Y(n_304)
);

OAI22xp33_ASAP7_75t_L g305 ( 
.A1(n_255),
.A2(n_244),
.B1(n_228),
.B2(n_219),
.Y(n_305)
);

INVx2_ASAP7_75t_L g306 ( 
.A(n_260),
.Y(n_306)
);

NOR2xp33_ASAP7_75t_L g307 ( 
.A(n_272),
.B(n_224),
.Y(n_307)
);

INVx1_ASAP7_75t_L g308 ( 
.A(n_264),
.Y(n_308)
);

AND2x2_ASAP7_75t_L g309 ( 
.A(n_296),
.B(n_217),
.Y(n_309)
);

NAND2xp5_ASAP7_75t_SL g310 ( 
.A(n_281),
.B(n_266),
.Y(n_310)
);

AND2x2_ASAP7_75t_L g311 ( 
.A(n_298),
.B(n_253),
.Y(n_311)
);

INVx1_ASAP7_75t_L g312 ( 
.A(n_269),
.Y(n_312)
);

NOR3xp33_ASAP7_75t_SL g313 ( 
.A(n_280),
.B(n_239),
.C(n_238),
.Y(n_313)
);

OR2x2_ASAP7_75t_L g314 ( 
.A(n_263),
.B(n_253),
.Y(n_314)
);

AND2x2_ASAP7_75t_L g315 ( 
.A(n_301),
.B(n_238),
.Y(n_315)
);

NAND2x1p5_ASAP7_75t_SL g316 ( 
.A(n_290),
.B(n_229),
.Y(n_316)
);

HB1xp67_ASAP7_75t_L g317 ( 
.A(n_292),
.Y(n_317)
);

INVxp67_ASAP7_75t_L g318 ( 
.A(n_259),
.Y(n_318)
);

AND2x2_ASAP7_75t_L g319 ( 
.A(n_270),
.B(n_273),
.Y(n_319)
);

INVx1_ASAP7_75t_L g320 ( 
.A(n_274),
.Y(n_320)
);

NOR2xp33_ASAP7_75t_SL g321 ( 
.A(n_294),
.B(n_229),
.Y(n_321)
);

INVx2_ASAP7_75t_SL g322 ( 
.A(n_268),
.Y(n_322)
);

INVx1_ASAP7_75t_L g323 ( 
.A(n_276),
.Y(n_323)
);

NOR2xp33_ASAP7_75t_R g324 ( 
.A(n_282),
.B(n_222),
.Y(n_324)
);

INVx1_ASAP7_75t_L g325 ( 
.A(n_284),
.Y(n_325)
);

NAND2xp33_ASAP7_75t_SL g326 ( 
.A(n_278),
.B(n_222),
.Y(n_326)
);

AND2x4_ASAP7_75t_L g327 ( 
.A(n_293),
.B(n_239),
.Y(n_327)
);

AOI21xp33_ASAP7_75t_SL g328 ( 
.A1(n_265),
.A2(n_235),
.B(n_221),
.Y(n_328)
);

OAI222xp33_ASAP7_75t_L g329 ( 
.A1(n_289),
.A2(n_242),
.B1(n_236),
.B2(n_32),
.C1(n_31),
.C2(n_29),
.Y(n_329)
);

NAND2xp5_ASAP7_75t_SL g330 ( 
.A(n_266),
.B(n_300),
.Y(n_330)
);

NOR4xp25_ASAP7_75t_SL g331 ( 
.A(n_267),
.B(n_242),
.C(n_236),
.D(n_35),
.Y(n_331)
);

OR2x2_ASAP7_75t_L g332 ( 
.A(n_286),
.B(n_37),
.Y(n_332)
);

INVx1_ASAP7_75t_L g333 ( 
.A(n_288),
.Y(n_333)
);

NOR4xp25_ASAP7_75t_L g334 ( 
.A(n_294),
.B(n_41),
.C(n_40),
.D(n_38),
.Y(n_334)
);

INVx1_ASAP7_75t_SL g335 ( 
.A(n_282),
.Y(n_335)
);

INVx1_ASAP7_75t_L g336 ( 
.A(n_291),
.Y(n_336)
);

INVx2_ASAP7_75t_L g337 ( 
.A(n_254),
.Y(n_337)
);

OR2x6_ASAP7_75t_L g338 ( 
.A(n_295),
.B(n_128),
.Y(n_338)
);

NAND2xp5_ASAP7_75t_L g339 ( 
.A(n_287),
.B(n_42),
.Y(n_339)
);

OAI22xp33_ASAP7_75t_L g340 ( 
.A1(n_302),
.A2(n_275),
.B1(n_283),
.B2(n_277),
.Y(n_340)
);

AOI22xp33_ASAP7_75t_L g341 ( 
.A1(n_330),
.A2(n_262),
.B1(n_258),
.B2(n_299),
.Y(n_341)
);

INVx2_ASAP7_75t_L g342 ( 
.A(n_306),
.Y(n_342)
);

NAND2xp5_ASAP7_75t_L g343 ( 
.A(n_307),
.B(n_318),
.Y(n_343)
);

AOI221xp5_ASAP7_75t_L g344 ( 
.A1(n_326),
.A2(n_297),
.B1(n_257),
.B2(n_271),
.C(n_285),
.Y(n_344)
);

AO22x1_ASAP7_75t_L g345 ( 
.A1(n_335),
.A2(n_268),
.B1(n_45),
.B2(n_44),
.Y(n_345)
);

INVx1_ASAP7_75t_L g346 ( 
.A(n_306),
.Y(n_346)
);

INVx1_ASAP7_75t_L g347 ( 
.A(n_304),
.Y(n_347)
);

XNOR2x1_ASAP7_75t_L g348 ( 
.A(n_317),
.B(n_326),
.Y(n_348)
);

AOI22xp33_ASAP7_75t_L g349 ( 
.A1(n_330),
.A2(n_268),
.B1(n_136),
.B2(n_128),
.Y(n_349)
);

AOI22xp5_ASAP7_75t_L g350 ( 
.A1(n_305),
.A2(n_268),
.B1(n_136),
.B2(n_128),
.Y(n_350)
);

AND2x4_ASAP7_75t_L g351 ( 
.A(n_327),
.B(n_46),
.Y(n_351)
);

NAND2xp5_ASAP7_75t_L g352 ( 
.A(n_303),
.B(n_47),
.Y(n_352)
);

INVx2_ASAP7_75t_L g353 ( 
.A(n_319),
.Y(n_353)
);

NAND2xp5_ASAP7_75t_L g354 ( 
.A(n_303),
.B(n_48),
.Y(n_354)
);

NAND3xp33_ASAP7_75t_L g355 ( 
.A(n_313),
.B(n_136),
.C(n_127),
.Y(n_355)
);

INVxp67_ASAP7_75t_SL g356 ( 
.A(n_327),
.Y(n_356)
);

OAI22xp33_ASAP7_75t_L g357 ( 
.A1(n_321),
.A2(n_50),
.B1(n_136),
.B2(n_125),
.Y(n_357)
);

AOI22xp33_ASAP7_75t_L g358 ( 
.A1(n_310),
.A2(n_125),
.B1(n_136),
.B2(n_339),
.Y(n_358)
);

NAND2xp5_ASAP7_75t_L g359 ( 
.A(n_314),
.B(n_309),
.Y(n_359)
);

NAND2xp5_ASAP7_75t_L g360 ( 
.A(n_309),
.B(n_337),
.Y(n_360)
);

AOI322xp5_ASAP7_75t_L g361 ( 
.A1(n_310),
.A2(n_334),
.A3(n_311),
.B1(n_320),
.B2(n_323),
.C1(n_308),
.C2(n_312),
.Y(n_361)
);

NAND2xp5_ASAP7_75t_L g362 ( 
.A(n_343),
.B(n_337),
.Y(n_362)
);

AOI321xp33_ASAP7_75t_L g363 ( 
.A1(n_340),
.A2(n_328),
.A3(n_332),
.B1(n_325),
.B2(n_311),
.C(n_327),
.Y(n_363)
);

CKINVDCx20_ASAP7_75t_R g364 ( 
.A(n_352),
.Y(n_364)
);

INVx1_ASAP7_75t_L g365 ( 
.A(n_347),
.Y(n_365)
);

AOI221xp5_ASAP7_75t_L g366 ( 
.A1(n_340),
.A2(n_329),
.B1(n_316),
.B2(n_333),
.C(n_336),
.Y(n_366)
);

AOI221xp5_ASAP7_75t_L g367 ( 
.A1(n_357),
.A2(n_316),
.B1(n_319),
.B2(n_315),
.C(n_324),
.Y(n_367)
);

NAND2xp5_ASAP7_75t_L g368 ( 
.A(n_360),
.B(n_315),
.Y(n_368)
);

INVx6_ASAP7_75t_L g369 ( 
.A(n_351),
.Y(n_369)
);

INVx2_ASAP7_75t_L g370 ( 
.A(n_342),
.Y(n_370)
);

AO22x2_ASAP7_75t_L g371 ( 
.A1(n_348),
.A2(n_322),
.B1(n_324),
.B2(n_331),
.Y(n_371)
);

AOI221xp5_ASAP7_75t_L g372 ( 
.A1(n_357),
.A2(n_322),
.B1(n_338),
.B2(n_355),
.C(n_358),
.Y(n_372)
);

INVx1_ASAP7_75t_L g373 ( 
.A(n_346),
.Y(n_373)
);

OAI22xp33_ASAP7_75t_L g374 ( 
.A1(n_367),
.A2(n_350),
.B1(n_354),
.B2(n_359),
.Y(n_374)
);

INVx1_ASAP7_75t_SL g375 ( 
.A(n_364),
.Y(n_375)
);

NAND4xp75_ASAP7_75t_L g376 ( 
.A(n_372),
.B(n_344),
.C(n_361),
.D(n_345),
.Y(n_376)
);

O2A1O1Ixp33_ASAP7_75t_L g377 ( 
.A1(n_366),
.A2(n_358),
.B(n_365),
.C(n_363),
.Y(n_377)
);

AOI221xp5_ASAP7_75t_L g378 ( 
.A1(n_371),
.A2(n_356),
.B1(n_341),
.B2(n_349),
.C(n_353),
.Y(n_378)
);

AOI322xp5_ASAP7_75t_L g379 ( 
.A1(n_368),
.A2(n_338),
.A3(n_351),
.B1(n_356),
.B2(n_362),
.C1(n_371),
.C2(n_373),
.Y(n_379)
);

INVx1_ASAP7_75t_L g380 ( 
.A(n_377),
.Y(n_380)
);

BUFx2_ASAP7_75t_SL g381 ( 
.A(n_375),
.Y(n_381)
);

NAND2xp5_ASAP7_75t_L g382 ( 
.A(n_376),
.B(n_370),
.Y(n_382)
);

NAND3xp33_ASAP7_75t_L g383 ( 
.A(n_380),
.B(n_379),
.C(n_378),
.Y(n_383)
);

AND2x2_ASAP7_75t_L g384 ( 
.A(n_381),
.B(n_382),
.Y(n_384)
);

HB1xp67_ASAP7_75t_L g385 ( 
.A(n_384),
.Y(n_385)
);

INVx1_ASAP7_75t_L g386 ( 
.A(n_385),
.Y(n_386)
);

AOI22xp5_ASAP7_75t_L g387 ( 
.A1(n_386),
.A2(n_383),
.B1(n_381),
.B2(n_374),
.Y(n_387)
);

AOI21xp5_ASAP7_75t_L g388 ( 
.A1(n_387),
.A2(n_338),
.B(n_369),
.Y(n_388)
);


endmodule