module fake_netlist_887_2029_n_24 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_24);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_24;

wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_13;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_SL g12 ( 
.A(n_9),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_4),
.B(n_8),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_0),
.B(n_11),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_6),
.B(n_4),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_15),
.C(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI211xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.B(n_16),
.C(n_14),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_16),
.B(n_15),
.C(n_12),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.C(n_5),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_10),
.B(n_7),
.Y(n_24)
);


endmodule