module fake_netlist_766_503_n_55 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_55);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_55;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_5),
.Y(n_18)
);

INVx5_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

NAND2xp33_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_3),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_1),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_1),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_21),
.B(n_4),
.Y(n_28)
);

OAI21x1_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_24),
.B(n_18),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_18),
.B1(n_20),
.B2(n_17),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_25),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_30),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

INVxp67_ASAP7_75t_SL g40 ( 
.A(n_36),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_37),
.B1(n_30),
.B2(n_32),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_32),
.B1(n_19),
.B2(n_17),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_17),
.B(n_19),
.Y(n_44)
);

INVx2_ASAP7_75t_SL g45 ( 
.A(n_43),
.Y(n_45)
);

NOR3xp33_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_38),
.C(n_4),
.Y(n_46)
);

AND2x4_ASAP7_75t_L g47 ( 
.A(n_41),
.B(n_6),
.Y(n_47)
);

NAND4xp25_ASAP7_75t_L g48 ( 
.A(n_42),
.B(n_6),
.C(n_2),
.D(n_0),
.Y(n_48)
);

OAI22x1_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_49)
);

INVxp67_ASAP7_75t_SL g50 ( 
.A(n_45),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_46),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

OAI22xp33_ASAP7_75t_SL g54 ( 
.A1(n_51),
.A2(n_15),
.B1(n_52),
.B2(n_49),
.Y(n_54)
);

AOI22x1_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_49),
.B1(n_51),
.B2(n_54),
.Y(n_55)
);


endmodule