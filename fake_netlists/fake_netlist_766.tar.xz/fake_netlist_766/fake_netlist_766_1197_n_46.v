module fake_netlist_766_1197_n_46 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_46);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_46;

wire n_20;
wire n_23;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

INVxp67_ASAP7_75t_SL g19 ( 
.A(n_0),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_1),
.B(n_10),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_4),
.B(n_3),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_20),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_11),
.B(n_6),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_26),
.A2(n_19),
.B1(n_17),
.B2(n_21),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_28),
.B(n_24),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_27),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_30),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_22),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_32),
.Y(n_36)
);

NOR2x1_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_23),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_21),
.B1(n_23),
.B2(n_1),
.C(n_5),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_14),
.Y(n_39)
);

AOI211xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_16),
.B(n_14),
.C(n_12),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

NOR2xp67_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_16),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_44),
.B1(n_42),
.B2(n_13),
.Y(n_46)
);


endmodule