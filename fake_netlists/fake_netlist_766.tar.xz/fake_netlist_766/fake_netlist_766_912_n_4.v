module fake_netlist_766_912_n_4 (n_0, n_1, n_4);

input n_0;
input n_1;

output n_4;

wire n_2;
wire n_3;

AND2x2_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

NAND2x1p5_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

AND2x4_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);


endmodule