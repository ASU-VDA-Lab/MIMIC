module fake_netlist_766_318_n_14 (n_0, n_2, n_1, n_3, n_14);

input n_0;
input n_2;
input n_1;
input n_3;

output n_14;

wire n_12;
wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

AND2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_SL g6 ( 
.A(n_4),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_5),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_9),
.B2(n_7),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_9),
.B2(n_6),
.Y(n_12)
);

NOR4xp25_ASAP7_75t_SL g13 ( 
.A(n_11),
.B(n_8),
.C(n_2),
.D(n_1),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_1),
.B1(n_8),
.B2(n_13),
.Y(n_14)
);


endmodule