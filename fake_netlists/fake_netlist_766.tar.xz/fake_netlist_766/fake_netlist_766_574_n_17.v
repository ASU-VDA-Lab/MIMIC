module fake_netlist_766_574_n_17 (n_1, n_2, n_3, n_4, n_0, n_17);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_17;

wire n_12;
wire n_15;
wire n_14;
wire n_11;
wire n_9;
wire n_10;
wire n_5;
wire n_7;
wire n_13;
wire n_16;
wire n_6;
wire n_8;

AND2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

INVx5_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_6),
.B(n_0),
.Y(n_7)
);

AO21x2_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_6),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_6),
.B2(n_1),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_8),
.B1(n_6),
.B2(n_1),
.C(n_2),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_8),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_9),
.B(n_6),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_6),
.B1(n_2),
.B2(n_3),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_2),
.B(n_4),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B(n_13),
.Y(n_17)
);


endmodule