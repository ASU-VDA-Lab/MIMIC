module fake_netlist_766_186_n_25 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_25);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_25;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_24;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

INVx1_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

BUFx10_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

INVx5_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_5),
.B(n_10),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_3),
.B(n_2),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_15),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_17),
.B(n_18),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B1(n_16),
.B2(n_4),
.C(n_6),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

OAI222xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_16),
.B1(n_12),
.B2(n_7),
.C1(n_13),
.C2(n_11),
.Y(n_25)
);


endmodule