module fake_netlist_766_1024_n_47 (n_20, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_47);

input n_20;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_47;

wire n_23;
wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

OA21x2_ASAP7_75t_L g28 ( 
.A1(n_12),
.A2(n_10),
.B(n_0),
.Y(n_28)
);

CKINVDCx16_ASAP7_75t_R g29 ( 
.A(n_20),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_3),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_8),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_24),
.B(n_16),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_26),
.A2(n_19),
.B1(n_17),
.B2(n_1),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_27),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_27),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_25),
.Y(n_37)
);

OAI221xp5_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_33),
.B1(n_24),
.B2(n_31),
.C(n_19),
.Y(n_38)
);

AOI21xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_36),
.B(n_23),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OAI211xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_31),
.B(n_28),
.C(n_30),
.Y(n_41)
);

OA22x2_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_28),
.B1(n_4),
.B2(n_2),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_R g44 ( 
.A(n_41),
.B(n_6),
.Y(n_44)
);

NOR2x1_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_28),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_13),
.B1(n_11),
.B2(n_7),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_SL g47 ( 
.A1(n_46),
.A2(n_14),
.B1(n_22),
.B2(n_45),
.Y(n_47)
);


endmodule