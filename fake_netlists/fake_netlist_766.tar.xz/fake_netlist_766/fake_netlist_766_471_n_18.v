module fake_netlist_766_471_n_18 (n_1, n_2, n_3, n_4, n_0, n_18);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_18;

wire n_12;
wire n_15;
wire n_14;
wire n_11;
wire n_9;
wire n_10;
wire n_5;
wire n_7;
wire n_13;
wire n_17;
wire n_16;
wire n_6;
wire n_8;

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_4),
.B(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_0),
.B(n_3),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_5),
.Y(n_11)
);

OA22x2_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_9),
.B2(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_9),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_10),
.C(n_9),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

OA22x2_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_9),
.B1(n_0),
.B2(n_3),
.Y(n_17)
);

AOI21xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_4),
.B(n_16),
.Y(n_18)
);


endmodule