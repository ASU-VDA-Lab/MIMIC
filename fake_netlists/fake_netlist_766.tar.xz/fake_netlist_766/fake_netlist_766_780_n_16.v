module fake_netlist_766_780_n_16 (n_1, n_2, n_3, n_4, n_5, n_0, n_16);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_16;

wire n_12;
wire n_15;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_13;
wire n_7;
wire n_6;
wire n_8;

CKINVDCx20_ASAP7_75t_R g6 ( 
.A(n_3),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

OR2x6_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B1(n_6),
.B2(n_1),
.Y(n_12)
);

OAI32xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_6),
.A3(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_1),
.B(n_3),
.C(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_4),
.B1(n_5),
.B2(n_12),
.Y(n_16)
);


endmodule