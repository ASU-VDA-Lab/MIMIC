module fake_netlist_766_1069_n_10 (n_1, n_2, n_3, n_4, n_0, n_10);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_10;

wire n_9;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

NOR3xp33_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_2),
.C(n_4),
.Y(n_5)
);

AND2x4_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_3),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_R g7 ( 
.A(n_2),
.B(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B1(n_7),
.B2(n_0),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule