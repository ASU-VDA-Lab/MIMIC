module fake_netlist_766_406_n_22 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_22);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_22;

wire n_20;
wire n_14;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_10;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_12;

INVx2_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_6),
.Y(n_11)
);

INVx5_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_6),
.B1(n_1),
.B2(n_7),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_0),
.B(n_5),
.Y(n_14)
);

BUFx4f_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_3),
.B(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_13),
.C(n_14),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_16),
.B1(n_7),
.B2(n_4),
.C(n_5),
.Y(n_20)
);

AOI211x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B(n_4),
.C(n_12),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_12),
.B(n_19),
.Y(n_22)
);


endmodule