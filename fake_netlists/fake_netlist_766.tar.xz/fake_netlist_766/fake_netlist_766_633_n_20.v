module fake_netlist_766_633_n_20 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_20);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_20;

wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_17;
wire n_12;
wire n_15;
wire n_19;

INVx2_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NAND2xp33_ASAP7_75t_R g12 ( 
.A(n_7),
.B(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_10),
.B(n_6),
.Y(n_14)
);

NOR4xp25_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_12),
.C(n_13),
.D(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_7),
.Y(n_18)
);

AOI21xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_2),
.B(n_0),
.Y(n_19)
);

OAI21x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_5),
.B(n_3),
.Y(n_20)
);


endmodule