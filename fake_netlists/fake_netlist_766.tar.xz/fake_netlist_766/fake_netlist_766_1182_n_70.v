module fake_netlist_766_1182_n_70 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_70);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_70;

wire n_46;
wire n_44;
wire n_61;
wire n_64;
wire n_62;
wire n_66;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_68;
wire n_49;
wire n_28;
wire n_65;
wire n_27;
wire n_37;
wire n_59;
wire n_24;
wire n_42;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_63;
wire n_25;
wire n_69;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_67;
wire n_55;
wire n_47;
wire n_29;
wire n_52;
wire n_54;
wire n_32;

OAI22xp33_ASAP7_75t_L g24 ( 
.A1(n_11),
.A2(n_14),
.B1(n_23),
.B2(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_10),
.B(n_4),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_17),
.Y(n_30)
);

NAND2x1p5_ASAP7_75t_L g31 ( 
.A(n_12),
.B(n_18),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_7),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_13),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_15),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_1),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_20),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_25),
.A2(n_16),
.B1(n_11),
.B2(n_10),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_24),
.A2(n_19),
.B1(n_18),
.B2(n_16),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_35),
.B(n_19),
.Y(n_40)
);

AOI21xp33_ASAP7_75t_L g41 ( 
.A1(n_28),
.A2(n_3),
.B(n_0),
.Y(n_41)
);

INVx5_ASAP7_75t_L g42 ( 
.A(n_27),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_27),
.B(n_20),
.Y(n_43)
);

OAI22xp33_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_24),
.B1(n_30),
.B2(n_31),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_33),
.B(n_32),
.Y(n_45)
);

BUFx4f_ASAP7_75t_SL g46 ( 
.A(n_40),
.Y(n_46)
);

OAI21x1_ASAP7_75t_SL g47 ( 
.A1(n_37),
.A2(n_34),
.B(n_32),
.Y(n_47)
);

BUFx2_ASAP7_75t_SL g48 ( 
.A(n_46),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_45),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_50),
.B(n_44),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_45),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_49),
.Y(n_55)
);

OR2x2_ASAP7_75t_L g56 ( 
.A(n_51),
.B(n_48),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_38),
.Y(n_57)
);

NAND4xp25_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_29),
.C(n_34),
.D(n_26),
.Y(n_58)
);

AOI22xp33_ASAP7_75t_SL g59 ( 
.A1(n_55),
.A2(n_48),
.B1(n_57),
.B2(n_31),
.Y(n_59)
);

AOI211xp5_ASAP7_75t_L g60 ( 
.A1(n_55),
.A2(n_41),
.B(n_29),
.C(n_36),
.Y(n_60)
);

OR2x2_ASAP7_75t_L g61 ( 
.A(n_54),
.B(n_21),
.Y(n_61)
);

CKINVDCx20_ASAP7_75t_R g62 ( 
.A(n_61),
.Y(n_62)
);

NAND4xp25_ASAP7_75t_L g63 ( 
.A(n_59),
.B(n_23),
.C(n_22),
.D(n_21),
.Y(n_63)
);

XOR2xp5_ASAP7_75t_L g64 ( 
.A(n_58),
.B(n_22),
.Y(n_64)
);

AND2x2_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_36),
.Y(n_65)
);

OAI22x1_ASAP7_75t_L g66 ( 
.A1(n_64),
.A2(n_8),
.B1(n_42),
.B2(n_62),
.Y(n_66)
);

INVx2_ASAP7_75t_L g67 ( 
.A(n_62),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_63),
.Y(n_68)
);

HB1xp67_ASAP7_75t_L g69 ( 
.A(n_67),
.Y(n_69)
);

AOI222xp33_ASAP7_75t_L g70 ( 
.A1(n_69),
.A2(n_66),
.B1(n_67),
.B2(n_68),
.C1(n_65),
.C2(n_24),
.Y(n_70)
);


endmodule