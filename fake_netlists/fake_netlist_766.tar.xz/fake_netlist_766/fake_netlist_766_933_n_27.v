module fake_netlist_766_933_n_27 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_27);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;

output n_27;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_24;
wire n_10;
wire n_26;
wire n_9;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

BUFx3_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_5),
.B(n_2),
.Y(n_9)
);

AO22x2_ASAP7_75t_L g10 ( 
.A1(n_0),
.A2(n_3),
.B1(n_7),
.B2(n_6),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_7),
.B(n_0),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_7),
.B(n_1),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_2),
.B(n_1),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_10),
.A2(n_5),
.B(n_4),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_8),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_8),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_18),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_12),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_13),
.B(n_16),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_SL g22 ( 
.A(n_20),
.B(n_9),
.C(n_11),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

NAND4xp75_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_10),
.C(n_14),
.D(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_10),
.B(n_26),
.Y(n_27)
);


endmodule