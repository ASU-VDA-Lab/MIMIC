module fake_netlist_766_458_n_14 (n_1, n_2, n_3, n_4, n_0, n_14);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_14;

wire n_12;
wire n_11;
wire n_9;
wire n_10;
wire n_13;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

BUFx3_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

OR2x2_ASAP7_75t_SL g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

NAND2x1_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

NOR4xp25_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_1),
.C(n_5),
.D(n_0),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_5),
.B1(n_3),
.B2(n_2),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_2),
.B1(n_4),
.B2(n_11),
.Y(n_14)
);


endmodule