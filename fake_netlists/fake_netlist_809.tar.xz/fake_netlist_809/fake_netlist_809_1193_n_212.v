module fake_netlist_809_1193_n_212 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_212);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_212;

wire n_49;
wire n_132;
wire n_97;
wire n_194;
wire n_81;
wire n_182;
wire n_114;
wire n_130;
wire n_80;
wire n_166;
wire n_123;
wire n_173;
wire n_156;
wire n_126;
wire n_154;
wire n_78;
wire n_153;
wire n_187;
wire n_195;
wire n_210;
wire n_87;
wire n_167;
wire n_122;
wire n_54;
wire n_96;
wire n_95;
wire n_56;
wire n_59;
wire n_63;
wire n_94;
wire n_74;
wire n_64;
wire n_79;
wire n_177;
wire n_110;
wire n_61;
wire n_184;
wire n_86;
wire n_43;
wire n_45;
wire n_108;
wire n_192;
wire n_48;
wire n_162;
wire n_163;
wire n_209;
wire n_196;
wire n_158;
wire n_135;
wire n_171;
wire n_47;
wire n_118;
wire n_127;
wire n_202;
wire n_90;
wire n_76;
wire n_189;
wire n_160;
wire n_107;
wire n_125;
wire n_99;
wire n_151;
wire n_178;
wire n_121;
wire n_72;
wire n_73;
wire n_211;
wire n_37;
wire n_207;
wire n_42;
wire n_120;
wire n_103;
wire n_155;
wire n_145;
wire n_200;
wire n_175;
wire n_185;
wire n_52;
wire n_199;
wire n_143;
wire n_170;
wire n_77;
wire n_161;
wire n_27;
wire n_190;
wire n_137;
wire n_57;
wire n_51;
wire n_138;
wire n_179;
wire n_136;
wire n_116;
wire n_102;
wire n_119;
wire n_89;
wire n_152;
wire n_70;
wire n_172;
wire n_131;
wire n_128;
wire n_133;
wire n_139;
wire n_142;
wire n_115;
wire n_109;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_144;
wire n_40;
wire n_28;
wire n_117;
wire n_53;
wire n_84;
wire n_58;
wire n_68;
wire n_183;
wire n_146;
wire n_104;
wire n_105;
wire n_168;
wire n_33;
wire n_106;
wire n_149;
wire n_188;
wire n_85;
wire n_205;
wire n_55;
wire n_164;
wire n_65;
wire n_159;
wire n_75;
wire n_140;
wire n_176;
wire n_67;
wire n_66;
wire n_101;
wire n_98;
wire n_91;
wire n_36;
wire n_204;
wire n_203;
wire n_50;
wire n_191;
wire n_112;
wire n_129;
wire n_181;
wire n_157;
wire n_201;
wire n_198;
wire n_83;
wire n_60;
wire n_39;
wire n_111;
wire n_32;
wire n_31;
wire n_169;
wire n_180;
wire n_93;
wire n_174;
wire n_150;
wire n_71;
wire n_208;
wire n_92;
wire n_82;
wire n_186;
wire n_100;
wire n_69;
wire n_193;
wire n_165;
wire n_88;
wire n_29;
wire n_124;
wire n_197;
wire n_113;
wire n_30;
wire n_206;
wire n_147;
wire n_141;
wire n_134;
wire n_35;
wire n_148;
wire n_38;
wire n_46;

INVx1_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_19),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_1),
.Y(n_29)
);

INVxp33_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

INVxp67_ASAP7_75t_SL g31 ( 
.A(n_23),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_9),
.Y(n_33)
);

CKINVDCx16_ASAP7_75t_R g34 ( 
.A(n_26),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_11),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_24),
.Y(n_36)
);

INVxp67_ASAP7_75t_SL g37 ( 
.A(n_6),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_21),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_21),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_9),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_14),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_15),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_34),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_32),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_35),
.Y(n_46)
);

BUFx10_ASAP7_75t_L g47 ( 
.A(n_35),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_35),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_32),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_32),
.Y(n_50)
);

BUFx10_ASAP7_75t_L g51 ( 
.A(n_41),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_32),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_27),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_27),
.B(n_0),
.Y(n_54)
);

INVx4_ASAP7_75t_L g55 ( 
.A(n_34),
.Y(n_55)
);

INVx2_ASAP7_75t_SL g56 ( 
.A(n_47),
.Y(n_56)
);

NOR2xp33_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_30),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_46),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_46),
.Y(n_59)
);

AOI22xp5_ASAP7_75t_L g60 ( 
.A1(n_55),
.A2(n_34),
.B1(n_36),
.B2(n_33),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_SL g61 ( 
.A(n_51),
.B(n_30),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_49),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_46),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_51),
.B(n_33),
.Y(n_64)
);

AO22x1_ASAP7_75t_L g65 ( 
.A1(n_55),
.A2(n_37),
.B1(n_31),
.B2(n_27),
.Y(n_65)
);

AND2x2_ASAP7_75t_L g66 ( 
.A(n_44),
.B(n_29),
.Y(n_66)
);

OR2x6_ASAP7_75t_L g67 ( 
.A(n_55),
.B(n_29),
.Y(n_67)
);

BUFx2_ASAP7_75t_L g68 ( 
.A(n_55),
.Y(n_68)
);

AOI22xp5_ASAP7_75t_L g69 ( 
.A1(n_44),
.A2(n_39),
.B1(n_36),
.B2(n_31),
.Y(n_69)
);

OAI22xp5_ASAP7_75t_SL g70 ( 
.A1(n_43),
.A2(n_28),
.B1(n_37),
.B2(n_39),
.Y(n_70)
);

INVx1_ASAP7_75t_SL g71 ( 
.A(n_68),
.Y(n_71)
);

AO31x2_ASAP7_75t_L g72 ( 
.A1(n_58),
.A2(n_48),
.A3(n_53),
.B(n_54),
.Y(n_72)
);

AOI21xp5_ASAP7_75t_L g73 ( 
.A1(n_56),
.A2(n_54),
.B(n_53),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_58),
.Y(n_74)
);

OAI21x1_ASAP7_75t_SL g75 ( 
.A1(n_60),
.A2(n_64),
.B(n_69),
.Y(n_75)
);

BUFx8_ASAP7_75t_L g76 ( 
.A(n_68),
.Y(n_76)
);

OAI21x1_ASAP7_75t_L g77 ( 
.A1(n_59),
.A2(n_48),
.B(n_49),
.Y(n_77)
);

AND2x2_ASAP7_75t_SL g78 ( 
.A(n_60),
.B(n_44),
.Y(n_78)
);

OAI21x1_ASAP7_75t_L g79 ( 
.A1(n_59),
.A2(n_48),
.B(n_49),
.Y(n_79)
);

NAND2xp5_ASAP7_75t_L g80 ( 
.A(n_57),
.B(n_51),
.Y(n_80)
);

AOI21x1_ASAP7_75t_SL g81 ( 
.A1(n_66),
.A2(n_47),
.B(n_51),
.Y(n_81)
);

NAND2xp33_ASAP7_75t_R g82 ( 
.A(n_67),
.B(n_43),
.Y(n_82)
);

NAND2xp5_ASAP7_75t_L g83 ( 
.A(n_66),
.B(n_51),
.Y(n_83)
);

AOI31xp67_ASAP7_75t_L g84 ( 
.A1(n_62),
.A2(n_47),
.A3(n_50),
.B(n_45),
.Y(n_84)
);

NAND2xp5_ASAP7_75t_L g85 ( 
.A(n_67),
.B(n_47),
.Y(n_85)
);

OAI21x1_ASAP7_75t_L g86 ( 
.A1(n_63),
.A2(n_62),
.B(n_61),
.Y(n_86)
);

AOI21xp33_ASAP7_75t_L g87 ( 
.A1(n_67),
.A2(n_50),
.B(n_45),
.Y(n_87)
);

CKINVDCx12_ASAP7_75t_R g88 ( 
.A(n_76),
.Y(n_88)
);

AOI21xp5_ASAP7_75t_L g89 ( 
.A1(n_73),
.A2(n_80),
.B(n_87),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_79),
.Y(n_90)
);

OAI22xp5_ASAP7_75t_L g91 ( 
.A1(n_78),
.A2(n_67),
.B1(n_63),
.B2(n_69),
.Y(n_91)
);

AND2x2_ASAP7_75t_L g92 ( 
.A(n_78),
.B(n_67),
.Y(n_92)
);

HB1xp67_ASAP7_75t_L g93 ( 
.A(n_76),
.Y(n_93)
);

AOI21xp5_ASAP7_75t_L g94 ( 
.A1(n_73),
.A2(n_56),
.B(n_65),
.Y(n_94)
);

AOI21x1_ASAP7_75t_SL g95 ( 
.A1(n_80),
.A2(n_85),
.B(n_84),
.Y(n_95)
);

AND2x2_ASAP7_75t_L g96 ( 
.A(n_78),
.B(n_65),
.Y(n_96)
);

O2A1O1Ixp5_ASAP7_75t_L g97 ( 
.A1(n_87),
.A2(n_74),
.B(n_62),
.C(n_52),
.Y(n_97)
);

AOI21xp5_ASAP7_75t_L g98 ( 
.A1(n_85),
.A2(n_52),
.B(n_29),
.Y(n_98)
);

INVx2_ASAP7_75t_L g99 ( 
.A(n_77),
.Y(n_99)
);

O2A1O1Ixp33_ASAP7_75t_L g100 ( 
.A1(n_75),
.A2(n_42),
.B(n_40),
.C(n_38),
.Y(n_100)
);

CKINVDCx5p33_ASAP7_75t_R g101 ( 
.A(n_82),
.Y(n_101)
);

AND2x2_ASAP7_75t_L g102 ( 
.A(n_92),
.B(n_83),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_90),
.Y(n_103)
);

AND2x2_ASAP7_75t_L g104 ( 
.A(n_92),
.B(n_96),
.Y(n_104)
);

AND2x2_ASAP7_75t_L g105 ( 
.A(n_92),
.B(n_83),
.Y(n_105)
);

HB1xp67_ASAP7_75t_L g106 ( 
.A(n_88),
.Y(n_106)
);

INVx2_ASAP7_75t_L g107 ( 
.A(n_99),
.Y(n_107)
);

INVx2_ASAP7_75t_SL g108 ( 
.A(n_99),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_90),
.Y(n_109)
);

BUFx2_ASAP7_75t_L g110 ( 
.A(n_93),
.Y(n_110)
);

OA21x2_ASAP7_75t_L g111 ( 
.A1(n_107),
.A2(n_99),
.B(n_97),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_103),
.Y(n_112)
);

BUFx2_ASAP7_75t_L g113 ( 
.A(n_108),
.Y(n_113)
);

INVx4_ASAP7_75t_L g114 ( 
.A(n_108),
.Y(n_114)
);

INVx2_ASAP7_75t_L g115 ( 
.A(n_107),
.Y(n_115)
);

INVx2_ASAP7_75t_L g116 ( 
.A(n_107),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_103),
.Y(n_117)
);

INVx2_ASAP7_75t_L g118 ( 
.A(n_107),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_103),
.Y(n_119)
);

NAND2x1p5_ASAP7_75t_L g120 ( 
.A(n_114),
.B(n_108),
.Y(n_120)
);

NAND2xp67_ASAP7_75t_L g121 ( 
.A(n_118),
.B(n_96),
.Y(n_121)
);

INVx2_ASAP7_75t_SL g122 ( 
.A(n_114),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_112),
.Y(n_123)
);

INVx2_ASAP7_75t_L g124 ( 
.A(n_118),
.Y(n_124)
);

OR2x2_ASAP7_75t_L g125 ( 
.A(n_118),
.B(n_109),
.Y(n_125)
);

CKINVDCx16_ASAP7_75t_R g126 ( 
.A(n_114),
.Y(n_126)
);

NAND2xp5_ASAP7_75t_L g127 ( 
.A(n_112),
.B(n_96),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_117),
.Y(n_128)
);

NOR2xp33_ASAP7_75t_L g129 ( 
.A(n_117),
.B(n_70),
.Y(n_129)
);

INVx2_ASAP7_75t_L g130 ( 
.A(n_118),
.Y(n_130)
);

AOI32xp33_ASAP7_75t_L g131 ( 
.A1(n_129),
.A2(n_91),
.A3(n_28),
.B1(n_110),
.B2(n_93),
.Y(n_131)
);

A2O1A1Ixp33_ASAP7_75t_L g132 ( 
.A1(n_122),
.A2(n_100),
.B(n_91),
.C(n_110),
.Y(n_132)
);

NAND2xp5_ASAP7_75t_L g133 ( 
.A(n_123),
.B(n_104),
.Y(n_133)
);

AOI211xp5_ASAP7_75t_L g134 ( 
.A1(n_123),
.A2(n_70),
.B(n_100),
.C(n_106),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_128),
.Y(n_135)
);

OAI21xp5_ASAP7_75t_L g136 ( 
.A1(n_125),
.A2(n_94),
.B(n_98),
.Y(n_136)
);

INVxp33_ASAP7_75t_L g137 ( 
.A(n_120),
.Y(n_137)
);

OAI21xp5_ASAP7_75t_L g138 ( 
.A1(n_125),
.A2(n_94),
.B(n_98),
.Y(n_138)
);

AOI221xp5_ASAP7_75t_SL g139 ( 
.A1(n_127),
.A2(n_42),
.B1(n_40),
.B2(n_38),
.C(n_110),
.Y(n_139)
);

AOI22xp33_ASAP7_75t_SL g140 ( 
.A1(n_126),
.A2(n_122),
.B1(n_75),
.B2(n_120),
.Y(n_140)
);

O2A1O1Ixp33_ASAP7_75t_L g141 ( 
.A1(n_128),
.A2(n_106),
.B(n_40),
.C(n_38),
.Y(n_141)
);

AOI222xp33_ASAP7_75t_L g142 ( 
.A1(n_124),
.A2(n_42),
.B1(n_104),
.B2(n_105),
.C1(n_102),
.C2(n_119),
.Y(n_142)
);

NAND3xp33_ASAP7_75t_L g143 ( 
.A(n_126),
.B(n_119),
.C(n_76),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_124),
.Y(n_144)
);

INVx1_ASAP7_75t_L g145 ( 
.A(n_124),
.Y(n_145)
);

INVx1_ASAP7_75t_L g146 ( 
.A(n_130),
.Y(n_146)
);

AOI211xp5_ASAP7_75t_SL g147 ( 
.A1(n_130),
.A2(n_109),
.B(n_105),
.C(n_102),
.Y(n_147)
);

NOR2xp33_ASAP7_75t_SL g148 ( 
.A(n_143),
.B(n_114),
.Y(n_148)
);

NAND2xp5_ASAP7_75t_SL g149 ( 
.A(n_140),
.B(n_120),
.Y(n_149)
);

O2A1O1Ixp5_ASAP7_75t_L g150 ( 
.A1(n_147),
.A2(n_114),
.B(n_130),
.C(n_115),
.Y(n_150)
);

OAI21xp5_ASAP7_75t_L g151 ( 
.A1(n_134),
.A2(n_79),
.B(n_77),
.Y(n_151)
);

OAI21xp5_ASAP7_75t_L g152 ( 
.A1(n_132),
.A2(n_79),
.B(n_115),
.Y(n_152)
);

INVxp33_ASAP7_75t_L g153 ( 
.A(n_137),
.Y(n_153)
);

AOI21xp5_ASAP7_75t_L g154 ( 
.A1(n_136),
.A2(n_113),
.B(n_108),
.Y(n_154)
);

NAND3xp33_ASAP7_75t_L g155 ( 
.A(n_131),
.B(n_76),
.C(n_109),
.Y(n_155)
);

NAND2xp5_ASAP7_75t_SL g156 ( 
.A(n_131),
.B(n_113),
.Y(n_156)
);

AOI21xp5_ASAP7_75t_L g157 ( 
.A1(n_138),
.A2(n_113),
.B(n_115),
.Y(n_157)
);

OAI31xp33_ASAP7_75t_L g158 ( 
.A1(n_141),
.A2(n_105),
.A3(n_102),
.B(n_71),
.Y(n_158)
);

OAI211xp5_ASAP7_75t_L g159 ( 
.A1(n_142),
.A2(n_101),
.B(n_104),
.C(n_105),
.Y(n_159)
);

NAND2xp5_ASAP7_75t_L g160 ( 
.A(n_135),
.B(n_121),
.Y(n_160)
);

NAND3x1_ASAP7_75t_L g161 ( 
.A(n_133),
.B(n_104),
.C(n_121),
.Y(n_161)
);

NAND2xp5_ASAP7_75t_L g162 ( 
.A(n_135),
.B(n_116),
.Y(n_162)
);

AOI221xp5_ASAP7_75t_L g163 ( 
.A1(n_139),
.A2(n_89),
.B1(n_74),
.B2(n_97),
.C(n_116),
.Y(n_163)
);

AOI21xp5_ASAP7_75t_L g164 ( 
.A1(n_144),
.A2(n_116),
.B(n_111),
.Y(n_164)
);

OAI21xp5_ASAP7_75t_L g165 ( 
.A1(n_144),
.A2(n_89),
.B(n_86),
.Y(n_165)
);

AOI21xp5_ASAP7_75t_L g166 ( 
.A1(n_145),
.A2(n_146),
.B(n_111),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_SL g167 ( 
.A(n_145),
.B(n_47),
.Y(n_167)
);

INVxp67_ASAP7_75t_L g168 ( 
.A(n_148),
.Y(n_168)
);

OR2x2_ASAP7_75t_L g169 ( 
.A(n_162),
.B(n_146),
.Y(n_169)
);

NAND2xp5_ASAP7_75t_L g170 ( 
.A(n_160),
.B(n_111),
.Y(n_170)
);

NOR2x1_ASAP7_75t_L g171 ( 
.A(n_155),
.B(n_111),
.Y(n_171)
);

OAI21xp5_ASAP7_75t_L g172 ( 
.A1(n_150),
.A2(n_86),
.B(n_71),
.Y(n_172)
);

INVxp67_ASAP7_75t_L g173 ( 
.A(n_149),
.Y(n_173)
);

NAND2xp33_ASAP7_75t_L g174 ( 
.A(n_161),
.B(n_111),
.Y(n_174)
);

NOR2xp33_ASAP7_75t_SL g175 ( 
.A(n_158),
.B(n_0),
.Y(n_175)
);

NOR2x1_ASAP7_75t_L g176 ( 
.A(n_149),
.B(n_1),
.Y(n_176)
);

NAND3xp33_ASAP7_75t_L g177 ( 
.A(n_156),
.B(n_84),
.C(n_95),
.Y(n_177)
);

INVx2_ASAP7_75t_L g178 ( 
.A(n_165),
.Y(n_178)
);

NOR3xp33_ASAP7_75t_L g179 ( 
.A(n_159),
.B(n_3),
.C(n_2),
.Y(n_179)
);

INVx1_ASAP7_75t_L g180 ( 
.A(n_166),
.Y(n_180)
);

NAND3xp33_ASAP7_75t_L g181 ( 
.A(n_156),
.B(n_95),
.C(n_2),
.Y(n_181)
);

NOR3xp33_ASAP7_75t_L g182 ( 
.A(n_151),
.B(n_4),
.C(n_3),
.Y(n_182)
);

AND2x2_ASAP7_75t_L g183 ( 
.A(n_164),
.B(n_157),
.Y(n_183)
);

NOR2xp33_ASAP7_75t_L g184 ( 
.A(n_153),
.B(n_4),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_154),
.Y(n_185)
);

INVx1_ASAP7_75t_L g186 ( 
.A(n_169),
.Y(n_186)
);

NOR2xp33_ASAP7_75t_L g187 ( 
.A(n_173),
.B(n_176),
.Y(n_187)
);

AND2x2_ASAP7_75t_L g188 ( 
.A(n_183),
.B(n_152),
.Y(n_188)
);

OAI211xp5_ASAP7_75t_L g189 ( 
.A1(n_179),
.A2(n_167),
.B(n_163),
.C(n_5),
.Y(n_189)
);

AND3x4_ASAP7_75t_L g190 ( 
.A(n_171),
.B(n_182),
.C(n_175),
.Y(n_190)
);

OAI222xp33_ASAP7_75t_L g191 ( 
.A1(n_168),
.A2(n_167),
.B1(n_7),
.B2(n_5),
.C1(n_12),
.C2(n_6),
.Y(n_191)
);

NAND4xp75_ASAP7_75t_L g192 ( 
.A(n_184),
.B(n_13),
.C(n_12),
.D(n_7),
.Y(n_192)
);

NOR2x1_ASAP7_75t_L g193 ( 
.A(n_174),
.B(n_13),
.Y(n_193)
);

NOR3xp33_ASAP7_75t_SL g194 ( 
.A(n_181),
.B(n_16),
.C(n_14),
.Y(n_194)
);

NOR2x1_ASAP7_75t_L g195 ( 
.A(n_174),
.B(n_16),
.Y(n_195)
);

NAND2xp5_ASAP7_75t_L g196 ( 
.A(n_170),
.B(n_17),
.Y(n_196)
);

BUFx2_ASAP7_75t_L g197 ( 
.A(n_169),
.Y(n_197)
);

O2A1O1Ixp33_ASAP7_75t_L g198 ( 
.A1(n_191),
.A2(n_185),
.B(n_180),
.C(n_178),
.Y(n_198)
);

AOI322xp5_ASAP7_75t_L g199 ( 
.A1(n_193),
.A2(n_183),
.A3(n_185),
.B1(n_178),
.B2(n_177),
.C1(n_17),
.C2(n_18),
.Y(n_199)
);

OAI322xp33_ASAP7_75t_SL g200 ( 
.A1(n_186),
.A2(n_19),
.A3(n_18),
.B1(n_23),
.B2(n_25),
.C1(n_20),
.C2(n_22),
.Y(n_200)
);

AOI322xp5_ASAP7_75t_L g201 ( 
.A1(n_187),
.A2(n_22),
.A3(n_20),
.B1(n_25),
.B2(n_26),
.C1(n_172),
.C2(n_72),
.Y(n_201)
);

AOI322xp5_ASAP7_75t_L g202 ( 
.A1(n_187),
.A2(n_10),
.A3(n_72),
.B1(n_81),
.B2(n_188),
.C1(n_197),
.C2(n_195),
.Y(n_202)
);

OAI22xp33_ASAP7_75t_L g203 ( 
.A1(n_197),
.A2(n_72),
.B1(n_196),
.B2(n_190),
.Y(n_203)
);

INVxp67_ASAP7_75t_SL g204 ( 
.A(n_188),
.Y(n_204)
);

NAND2xp5_ASAP7_75t_L g205 ( 
.A(n_204),
.B(n_189),
.Y(n_205)
);

OAI22xp5_ASAP7_75t_SL g206 ( 
.A1(n_200),
.A2(n_190),
.B1(n_194),
.B2(n_192),
.Y(n_206)
);

OAI22xp5_ASAP7_75t_SL g207 ( 
.A1(n_203),
.A2(n_72),
.B1(n_199),
.B2(n_202),
.Y(n_207)
);

AOI22xp5_ASAP7_75t_L g208 ( 
.A1(n_199),
.A2(n_72),
.B1(n_201),
.B2(n_198),
.Y(n_208)
);

CKINVDCx20_ASAP7_75t_R g209 ( 
.A(n_205),
.Y(n_209)
);

INVx2_ASAP7_75t_SL g210 ( 
.A(n_208),
.Y(n_210)
);

OAI21xp5_ASAP7_75t_L g211 ( 
.A1(n_210),
.A2(n_206),
.B(n_207),
.Y(n_211)
);

AOI31xp33_ASAP7_75t_L g212 ( 
.A1(n_211),
.A2(n_210),
.A3(n_209),
.B(n_72),
.Y(n_212)
);


endmodule