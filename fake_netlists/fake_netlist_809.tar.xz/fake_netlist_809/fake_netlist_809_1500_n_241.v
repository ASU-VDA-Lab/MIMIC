module fake_netlist_809_1500_n_241 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_34, n_28, n_9, n_31, n_32, n_26, n_24, n_19, n_3, n_33, n_12, n_0, n_29, n_6, n_30, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_241);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_34;
input n_28;
input n_9;
input n_31;
input n_32;
input n_26;
input n_24;
input n_19;
input n_3;
input n_33;
input n_12;
input n_0;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_241;

wire n_49;
wire n_132;
wire n_97;
wire n_194;
wire n_219;
wire n_221;
wire n_81;
wire n_182;
wire n_114;
wire n_130;
wire n_80;
wire n_239;
wire n_166;
wire n_123;
wire n_173;
wire n_240;
wire n_156;
wire n_222;
wire n_126;
wire n_154;
wire n_78;
wire n_153;
wire n_187;
wire n_210;
wire n_195;
wire n_87;
wire n_167;
wire n_122;
wire n_54;
wire n_96;
wire n_95;
wire n_56;
wire n_232;
wire n_59;
wire n_63;
wire n_94;
wire n_74;
wire n_64;
wire n_79;
wire n_177;
wire n_110;
wire n_61;
wire n_184;
wire n_86;
wire n_43;
wire n_45;
wire n_108;
wire n_192;
wire n_48;
wire n_163;
wire n_162;
wire n_209;
wire n_196;
wire n_230;
wire n_158;
wire n_135;
wire n_171;
wire n_47;
wire n_118;
wire n_214;
wire n_127;
wire n_202;
wire n_90;
wire n_213;
wire n_76;
wire n_189;
wire n_160;
wire n_107;
wire n_125;
wire n_99;
wire n_151;
wire n_178;
wire n_72;
wire n_121;
wire n_73;
wire n_211;
wire n_235;
wire n_37;
wire n_207;
wire n_42;
wire n_120;
wire n_103;
wire n_155;
wire n_145;
wire n_227;
wire n_200;
wire n_175;
wire n_185;
wire n_52;
wire n_199;
wire n_143;
wire n_170;
wire n_77;
wire n_161;
wire n_190;
wire n_224;
wire n_229;
wire n_138;
wire n_51;
wire n_57;
wire n_137;
wire n_179;
wire n_116;
wire n_136;
wire n_102;
wire n_217;
wire n_119;
wire n_226;
wire n_89;
wire n_152;
wire n_70;
wire n_172;
wire n_238;
wire n_131;
wire n_128;
wire n_133;
wire n_139;
wire n_142;
wire n_115;
wire n_109;
wire n_41;
wire n_62;
wire n_223;
wire n_144;
wire n_44;
wire n_40;
wire n_117;
wire n_53;
wire n_84;
wire n_58;
wire n_68;
wire n_183;
wire n_146;
wire n_104;
wire n_105;
wire n_168;
wire n_225;
wire n_106;
wire n_215;
wire n_149;
wire n_188;
wire n_85;
wire n_237;
wire n_205;
wire n_55;
wire n_164;
wire n_65;
wire n_159;
wire n_75;
wire n_140;
wire n_176;
wire n_67;
wire n_66;
wire n_101;
wire n_98;
wire n_91;
wire n_233;
wire n_36;
wire n_203;
wire n_204;
wire n_50;
wire n_191;
wire n_112;
wire n_129;
wire n_181;
wire n_201;
wire n_157;
wire n_198;
wire n_83;
wire n_228;
wire n_60;
wire n_39;
wire n_111;
wire n_169;
wire n_180;
wire n_93;
wire n_174;
wire n_220;
wire n_150;
wire n_216;
wire n_71;
wire n_208;
wire n_92;
wire n_82;
wire n_186;
wire n_100;
wire n_218;
wire n_69;
wire n_193;
wire n_234;
wire n_212;
wire n_165;
wire n_88;
wire n_124;
wire n_197;
wire n_113;
wire n_236;
wire n_206;
wire n_147;
wire n_231;
wire n_141;
wire n_134;
wire n_35;
wire n_148;
wire n_38;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_12),
.Y(n_35)
);

INVxp33_ASAP7_75t_SL g36 ( 
.A(n_17),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_18),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_23),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_0),
.Y(n_39)
);

INVxp33_ASAP7_75t_SL g40 ( 
.A(n_33),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_12),
.Y(n_41)
);

INVxp33_ASAP7_75t_SL g42 ( 
.A(n_8),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_17),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_1),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_21),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_2),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_0),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_24),
.Y(n_48)
);

BUFx6f_ASAP7_75t_L g49 ( 
.A(n_24),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_11),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_35),
.Y(n_51)
);

CKINVDCx20_ASAP7_75t_R g52 ( 
.A(n_35),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

CKINVDCx5p33_ASAP7_75t_R g54 ( 
.A(n_37),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_49),
.Y(n_55)
);

NOR2xp33_ASAP7_75t_L g56 ( 
.A(n_36),
.B(n_42),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_37),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_49),
.Y(n_58)
);

AOI21x1_ASAP7_75t_L g59 ( 
.A1(n_50),
.A2(n_27),
.B(n_26),
.Y(n_59)
);

CKINVDCx5p33_ASAP7_75t_R g60 ( 
.A(n_43),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_55),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_55),
.Y(n_62)
);

AND2x4_ASAP7_75t_L g63 ( 
.A(n_53),
.B(n_50),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_55),
.Y(n_64)
);

OAI22xp33_ASAP7_75t_L g65 ( 
.A1(n_52),
.A2(n_44),
.B1(n_43),
.B2(n_36),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_58),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_58),
.Y(n_67)
);

AOI22xp5_ASAP7_75t_SL g68 ( 
.A1(n_52),
.A2(n_57),
.B1(n_54),
.B2(n_51),
.Y(n_68)
);

OR2x2_ASAP7_75t_SL g69 ( 
.A(n_53),
.B(n_38),
.Y(n_69)
);

NOR2xp33_ASAP7_75t_L g70 ( 
.A(n_56),
.B(n_40),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_58),
.Y(n_71)
);

AND2x2_ASAP7_75t_L g72 ( 
.A(n_63),
.B(n_53),
.Y(n_72)
);

BUFx6f_ASAP7_75t_L g73 ( 
.A(n_63),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_SL g74 ( 
.A(n_63),
.B(n_51),
.Y(n_74)
);

OAI22xp5_ASAP7_75t_L g75 ( 
.A1(n_69),
.A2(n_56),
.B1(n_42),
.B2(n_54),
.Y(n_75)
);

INVxp67_ASAP7_75t_L g76 ( 
.A(n_68),
.Y(n_76)
);

NAND2xp5_ASAP7_75t_L g77 ( 
.A(n_63),
.B(n_57),
.Y(n_77)
);

NAND2xp5_ASAP7_75t_L g78 ( 
.A(n_70),
.B(n_60),
.Y(n_78)
);

OR2x6_ASAP7_75t_L g79 ( 
.A(n_69),
.B(n_38),
.Y(n_79)
);

NAND2xp5_ASAP7_75t_L g80 ( 
.A(n_65),
.B(n_60),
.Y(n_80)
);

O2A1O1Ixp33_ASAP7_75t_L g81 ( 
.A1(n_61),
.A2(n_45),
.B(n_41),
.C(n_39),
.Y(n_81)
);

O2A1O1Ixp33_ASAP7_75t_L g82 ( 
.A1(n_61),
.A2(n_45),
.B(n_41),
.C(n_39),
.Y(n_82)
);

A2O1A1Ixp33_ASAP7_75t_SL g83 ( 
.A1(n_64),
.A2(n_48),
.B(n_47),
.C(n_46),
.Y(n_83)
);

AOI21xp5_ASAP7_75t_L g84 ( 
.A1(n_64),
.A2(n_40),
.B(n_46),
.Y(n_84)
);

INVx2_ASAP7_75t_L g85 ( 
.A(n_62),
.Y(n_85)
);

A2O1A1Ixp33_ASAP7_75t_L g86 ( 
.A1(n_68),
.A2(n_48),
.B(n_47),
.C(n_49),
.Y(n_86)
);

OAI21x1_ASAP7_75t_L g87 ( 
.A1(n_82),
.A2(n_59),
.B(n_62),
.Y(n_87)
);

OAI21xp5_ASAP7_75t_L g88 ( 
.A1(n_86),
.A2(n_67),
.B(n_66),
.Y(n_88)
);

INVx2_ASAP7_75t_L g89 ( 
.A(n_85),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_73),
.Y(n_90)
);

INVx2_ASAP7_75t_L g91 ( 
.A(n_85),
.Y(n_91)
);

CKINVDCx5p33_ASAP7_75t_R g92 ( 
.A(n_72),
.Y(n_92)
);

XNOR2xp5_ASAP7_75t_L g93 ( 
.A(n_75),
.B(n_44),
.Y(n_93)
);

OAI221xp5_ASAP7_75t_L g94 ( 
.A1(n_79),
.A2(n_49),
.B1(n_71),
.B2(n_66),
.C(n_67),
.Y(n_94)
);

OAI21x1_ASAP7_75t_L g95 ( 
.A1(n_81),
.A2(n_59),
.B(n_62),
.Y(n_95)
);

O2A1O1Ixp33_ASAP7_75t_L g96 ( 
.A1(n_83),
.A2(n_71),
.B(n_49),
.C(n_59),
.Y(n_96)
);

AO21x2_ASAP7_75t_L g97 ( 
.A1(n_84),
.A2(n_59),
.B(n_1),
.Y(n_97)
);

AOI221xp5_ASAP7_75t_L g98 ( 
.A1(n_75),
.A2(n_49),
.B1(n_4),
.B2(n_2),
.C(n_3),
.Y(n_98)
);

OAI21x1_ASAP7_75t_L g99 ( 
.A1(n_85),
.A2(n_29),
.B(n_28),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_73),
.Y(n_100)
);

BUFx12f_ASAP7_75t_L g101 ( 
.A(n_73),
.Y(n_101)
);

AO31x2_ASAP7_75t_L g102 ( 
.A1(n_89),
.A2(n_77),
.A3(n_80),
.B(n_78),
.Y(n_102)
);

BUFx3_ASAP7_75t_L g103 ( 
.A(n_101),
.Y(n_103)
);

NAND2xp5_ASAP7_75t_L g104 ( 
.A(n_89),
.B(n_72),
.Y(n_104)
);

NOR3xp33_ASAP7_75t_SL g105 ( 
.A(n_93),
.B(n_80),
.C(n_74),
.Y(n_105)
);

NAND2xp33_ASAP7_75t_R g106 ( 
.A(n_92),
.B(n_79),
.Y(n_106)
);

AO31x2_ASAP7_75t_L g107 ( 
.A1(n_89),
.A2(n_77),
.A3(n_79),
.B(n_49),
.Y(n_107)
);

AND3x1_ASAP7_75t_L g108 ( 
.A(n_98),
.B(n_76),
.C(n_79),
.Y(n_108)
);

CKINVDCx6p67_ASAP7_75t_R g109 ( 
.A(n_101),
.Y(n_109)
);

OAI21xp33_ASAP7_75t_L g110 ( 
.A1(n_98),
.A2(n_79),
.B(n_92),
.Y(n_110)
);

NOR2xp33_ASAP7_75t_R g111 ( 
.A(n_93),
.B(n_73),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_89),
.Y(n_112)
);

INVx2_ASAP7_75t_SL g113 ( 
.A(n_101),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_112),
.Y(n_114)
);

OAI21x1_ASAP7_75t_L g115 ( 
.A1(n_112),
.A2(n_99),
.B(n_96),
.Y(n_115)
);

OAI21x1_ASAP7_75t_L g116 ( 
.A1(n_108),
.A2(n_99),
.B(n_96),
.Y(n_116)
);

AND2x2_ASAP7_75t_L g117 ( 
.A(n_104),
.B(n_89),
.Y(n_117)
);

A2O1A1Ixp33_ASAP7_75t_L g118 ( 
.A1(n_110),
.A2(n_98),
.B(n_94),
.C(n_89),
.Y(n_118)
);

CKINVDCx20_ASAP7_75t_R g119 ( 
.A(n_109),
.Y(n_119)
);

AOI221xp5_ASAP7_75t_L g120 ( 
.A1(n_110),
.A2(n_93),
.B1(n_94),
.B2(n_49),
.C(n_73),
.Y(n_120)
);

INVx2_ASAP7_75t_L g121 ( 
.A(n_103),
.Y(n_121)
);

INVx2_ASAP7_75t_L g122 ( 
.A(n_107),
.Y(n_122)
);

AOI22xp33_ASAP7_75t_L g123 ( 
.A1(n_111),
.A2(n_93),
.B1(n_94),
.B2(n_97),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_SL g124 ( 
.A(n_120),
.B(n_108),
.Y(n_124)
);

INVx2_ASAP7_75t_L g125 ( 
.A(n_114),
.Y(n_125)
);

AND2x2_ASAP7_75t_L g126 ( 
.A(n_117),
.B(n_105),
.Y(n_126)
);

OR2x6_ASAP7_75t_L g127 ( 
.A(n_122),
.B(n_113),
.Y(n_127)
);

AOI22xp5_ASAP7_75t_L g128 ( 
.A1(n_120),
.A2(n_106),
.B1(n_109),
.B2(n_113),
.Y(n_128)
);

AND2x2_ASAP7_75t_L g129 ( 
.A(n_117),
.B(n_114),
.Y(n_129)
);

HB1xp67_ASAP7_75t_L g130 ( 
.A(n_117),
.Y(n_130)
);

NAND2xp5_ASAP7_75t_L g131 ( 
.A(n_119),
.B(n_104),
.Y(n_131)
);

AND2x2_ASAP7_75t_L g132 ( 
.A(n_122),
.B(n_107),
.Y(n_132)
);

INVx2_ASAP7_75t_L g133 ( 
.A(n_122),
.Y(n_133)
);

INVx2_ASAP7_75t_SL g134 ( 
.A(n_127),
.Y(n_134)
);

AND2x2_ASAP7_75t_L g135 ( 
.A(n_132),
.B(n_122),
.Y(n_135)
);

AO21x1_ASAP7_75t_L g136 ( 
.A1(n_124),
.A2(n_116),
.B(n_121),
.Y(n_136)
);

NAND2x1p5_ASAP7_75t_L g137 ( 
.A(n_128),
.B(n_103),
.Y(n_137)
);

AND2x2_ASAP7_75t_L g138 ( 
.A(n_132),
.B(n_107),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_133),
.Y(n_139)
);

OR2x2_ASAP7_75t_L g140 ( 
.A(n_133),
.B(n_107),
.Y(n_140)
);

OR2x2_ASAP7_75t_L g141 ( 
.A(n_130),
.B(n_107),
.Y(n_141)
);

INVx1_ASAP7_75t_L g142 ( 
.A(n_125),
.Y(n_142)
);

AND2x2_ASAP7_75t_L g143 ( 
.A(n_127),
.B(n_116),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_125),
.Y(n_144)
);

INVx2_ASAP7_75t_L g145 ( 
.A(n_127),
.Y(n_145)
);

OR2x2_ASAP7_75t_L g146 ( 
.A(n_127),
.B(n_107),
.Y(n_146)
);

NAND2xp5_ASAP7_75t_L g147 ( 
.A(n_135),
.B(n_129),
.Y(n_147)
);

AOI22xp5_ASAP7_75t_L g148 ( 
.A1(n_138),
.A2(n_124),
.B1(n_119),
.B2(n_126),
.Y(n_148)
);

AOI21xp33_ASAP7_75t_L g149 ( 
.A1(n_146),
.A2(n_131),
.B(n_123),
.Y(n_149)
);

INVx2_ASAP7_75t_L g150 ( 
.A(n_139),
.Y(n_150)
);

AOI22xp5_ASAP7_75t_L g151 ( 
.A1(n_138),
.A2(n_123),
.B1(n_109),
.B2(n_113),
.Y(n_151)
);

AND2x2_ASAP7_75t_L g152 ( 
.A(n_135),
.B(n_116),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_142),
.Y(n_153)
);

AOI321xp33_ASAP7_75t_L g154 ( 
.A1(n_143),
.A2(n_118),
.A3(n_96),
.B1(n_121),
.B2(n_103),
.C(n_90),
.Y(n_154)
);

OAI22xp33_ASAP7_75t_L g155 ( 
.A1(n_146),
.A2(n_121),
.B1(n_101),
.B2(n_91),
.Y(n_155)
);

OAI21xp5_ASAP7_75t_L g156 ( 
.A1(n_141),
.A2(n_118),
.B(n_99),
.Y(n_156)
);

A2O1A1Ixp33_ASAP7_75t_L g157 ( 
.A1(n_134),
.A2(n_99),
.B(n_115),
.C(n_91),
.Y(n_157)
);

AOI22xp5_ASAP7_75t_L g158 ( 
.A1(n_137),
.A2(n_101),
.B1(n_97),
.B2(n_91),
.Y(n_158)
);

AOI221x1_ASAP7_75t_L g159 ( 
.A1(n_139),
.A2(n_88),
.B1(n_90),
.B2(n_99),
.C(n_91),
.Y(n_159)
);

NOR2xp33_ASAP7_75t_L g160 ( 
.A(n_137),
.B(n_3),
.Y(n_160)
);

AOI21xp5_ASAP7_75t_SL g161 ( 
.A1(n_141),
.A2(n_91),
.B(n_73),
.Y(n_161)
);

NAND2xp5_ASAP7_75t_L g162 ( 
.A(n_142),
.B(n_102),
.Y(n_162)
);

XNOR2x1_ASAP7_75t_L g163 ( 
.A(n_137),
.B(n_4),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_144),
.Y(n_164)
);

NOR3xp33_ASAP7_75t_L g165 ( 
.A(n_134),
.B(n_88),
.C(n_115),
.Y(n_165)
);

INVx1_ASAP7_75t_L g166 ( 
.A(n_144),
.Y(n_166)
);

NOR2xp33_ASAP7_75t_L g167 ( 
.A(n_163),
.B(n_5),
.Y(n_167)
);

OR2x2_ASAP7_75t_L g168 ( 
.A(n_147),
.B(n_140),
.Y(n_168)
);

INVxp67_ASAP7_75t_SL g169 ( 
.A(n_150),
.Y(n_169)
);

NAND2x1_ASAP7_75t_L g170 ( 
.A(n_161),
.B(n_134),
.Y(n_170)
);

INVx1_ASAP7_75t_L g171 ( 
.A(n_153),
.Y(n_171)
);

INVx2_ASAP7_75t_L g172 ( 
.A(n_164),
.Y(n_172)
);

OR2x2_ASAP7_75t_L g173 ( 
.A(n_164),
.B(n_140),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_153),
.Y(n_174)
);

NAND2xp5_ASAP7_75t_SL g175 ( 
.A(n_155),
.B(n_145),
.Y(n_175)
);

INVx1_ASAP7_75t_SL g176 ( 
.A(n_163),
.Y(n_176)
);

NAND2xp5_ASAP7_75t_L g177 ( 
.A(n_148),
.B(n_145),
.Y(n_177)
);

CKINVDCx20_ASAP7_75t_L g178 ( 
.A(n_161),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_166),
.Y(n_179)
);

NOR2xp33_ASAP7_75t_L g180 ( 
.A(n_160),
.B(n_5),
.Y(n_180)
);

NAND2xp5_ASAP7_75t_L g181 ( 
.A(n_166),
.B(n_145),
.Y(n_181)
);

OR2x2_ASAP7_75t_L g182 ( 
.A(n_150),
.B(n_143),
.Y(n_182)
);

AND2x2_ASAP7_75t_L g183 ( 
.A(n_152),
.B(n_143),
.Y(n_183)
);

INVx1_ASAP7_75t_L g184 ( 
.A(n_162),
.Y(n_184)
);

NAND2x1_ASAP7_75t_L g185 ( 
.A(n_158),
.B(n_136),
.Y(n_185)
);

NAND2xp5_ASAP7_75t_L g186 ( 
.A(n_149),
.B(n_102),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_152),
.Y(n_187)
);

INVx1_ASAP7_75t_L g188 ( 
.A(n_151),
.Y(n_188)
);

AND2x2_ASAP7_75t_L g189 ( 
.A(n_165),
.B(n_136),
.Y(n_189)
);

AO22x1_ASAP7_75t_L g190 ( 
.A1(n_156),
.A2(n_91),
.B1(n_115),
.B2(n_6),
.Y(n_190)
);

AOI211xp5_ASAP7_75t_L g191 ( 
.A1(n_167),
.A2(n_157),
.B(n_154),
.C(n_87),
.Y(n_191)
);

AOI321xp33_ASAP7_75t_L g192 ( 
.A1(n_189),
.A2(n_7),
.A3(n_6),
.B1(n_8),
.B2(n_10),
.C(n_9),
.Y(n_192)
);

NAND3xp33_ASAP7_75t_L g193 ( 
.A(n_189),
.B(n_159),
.C(n_88),
.Y(n_193)
);

AOI221xp5_ASAP7_75t_L g194 ( 
.A1(n_176),
.A2(n_97),
.B1(n_90),
.B2(n_100),
.C(n_7),
.Y(n_194)
);

AOI22xp33_ASAP7_75t_L g195 ( 
.A1(n_188),
.A2(n_97),
.B1(n_101),
.B2(n_90),
.Y(n_195)
);

AOI221xp5_ASAP7_75t_L g196 ( 
.A1(n_180),
.A2(n_97),
.B1(n_100),
.B2(n_9),
.C(n_10),
.Y(n_196)
);

OAI22xp5_ASAP7_75t_L g197 ( 
.A1(n_170),
.A2(n_159),
.B1(n_100),
.B2(n_102),
.Y(n_197)
);

AOI221xp5_ASAP7_75t_L g198 ( 
.A1(n_184),
.A2(n_97),
.B1(n_100),
.B2(n_11),
.C(n_13),
.Y(n_198)
);

AOI221xp5_ASAP7_75t_L g199 ( 
.A1(n_187),
.A2(n_186),
.B1(n_177),
.B2(n_185),
.C(n_190),
.Y(n_199)
);

NOR3xp33_ASAP7_75t_SL g200 ( 
.A(n_175),
.B(n_14),
.C(n_13),
.Y(n_200)
);

AOI211xp5_ASAP7_75t_L g201 ( 
.A1(n_190),
.A2(n_178),
.B(n_168),
.C(n_182),
.Y(n_201)
);

OAI211xp5_ASAP7_75t_SL g202 ( 
.A1(n_168),
.A2(n_16),
.B(n_15),
.C(n_14),
.Y(n_202)
);

NOR2xp33_ASAP7_75t_R g203 ( 
.A(n_178),
.B(n_15),
.Y(n_203)
);

AOI21xp5_ASAP7_75t_L g204 ( 
.A1(n_170),
.A2(n_97),
.B(n_87),
.Y(n_204)
);

AOI221xp5_ASAP7_75t_L g205 ( 
.A1(n_185),
.A2(n_97),
.B1(n_100),
.B2(n_16),
.C(n_18),
.Y(n_205)
);

AOI21xp33_ASAP7_75t_L g206 ( 
.A1(n_181),
.A2(n_20),
.B(n_19),
.Y(n_206)
);

O2A1O1Ixp5_ASAP7_75t_L g207 ( 
.A1(n_169),
.A2(n_179),
.B(n_174),
.C(n_171),
.Y(n_207)
);

AOI22xp5_ASAP7_75t_L g208 ( 
.A1(n_183),
.A2(n_87),
.B1(n_95),
.B2(n_100),
.Y(n_208)
);

O2A1O1Ixp33_ASAP7_75t_L g209 ( 
.A1(n_171),
.A2(n_21),
.B(n_20),
.C(n_19),
.Y(n_209)
);

INVx1_ASAP7_75t_L g210 ( 
.A(n_174),
.Y(n_210)
);

NAND2xp5_ASAP7_75t_L g211 ( 
.A(n_199),
.B(n_183),
.Y(n_211)
);

OAI221xp5_ASAP7_75t_L g212 ( 
.A1(n_201),
.A2(n_182),
.B1(n_173),
.B2(n_172),
.C(n_22),
.Y(n_212)
);

AOI22xp5_ASAP7_75t_L g213 ( 
.A1(n_200),
.A2(n_172),
.B1(n_173),
.B2(n_87),
.Y(n_213)
);

AOI211xp5_ASAP7_75t_L g214 ( 
.A1(n_203),
.A2(n_95),
.B(n_87),
.C(n_22),
.Y(n_214)
);

NOR3xp33_ASAP7_75t_L g215 ( 
.A(n_202),
.B(n_95),
.C(n_23),
.Y(n_215)
);

AOI211xp5_ASAP7_75t_L g216 ( 
.A1(n_191),
.A2(n_95),
.B(n_25),
.C(n_102),
.Y(n_216)
);

INVx1_ASAP7_75t_L g217 ( 
.A(n_210),
.Y(n_217)
);

AOI221xp5_ASAP7_75t_L g218 ( 
.A1(n_207),
.A2(n_25),
.B1(n_102),
.B2(n_30),
.C(n_31),
.Y(n_218)
);

NAND3xp33_ASAP7_75t_L g219 ( 
.A(n_200),
.B(n_102),
.C(n_32),
.Y(n_219)
);

NAND2xp5_ASAP7_75t_L g220 ( 
.A(n_193),
.B(n_95),
.Y(n_220)
);

A2O1A1Ixp33_ASAP7_75t_L g221 ( 
.A1(n_192),
.A2(n_34),
.B(n_209),
.C(n_206),
.Y(n_221)
);

NAND3xp33_ASAP7_75t_L g222 ( 
.A(n_205),
.B(n_194),
.C(n_196),
.Y(n_222)
);

NAND2xp5_ASAP7_75t_L g223 ( 
.A(n_195),
.B(n_208),
.Y(n_223)
);

NAND3x1_ASAP7_75t_L g224 ( 
.A(n_204),
.B(n_198),
.C(n_197),
.Y(n_224)
);

INVx1_ASAP7_75t_L g225 ( 
.A(n_217),
.Y(n_225)
);

INVx1_ASAP7_75t_L g226 ( 
.A(n_211),
.Y(n_226)
);

CKINVDCx5p33_ASAP7_75t_R g227 ( 
.A(n_213),
.Y(n_227)
);

INVxp67_ASAP7_75t_L g228 ( 
.A(n_212),
.Y(n_228)
);

INVx1_ASAP7_75t_L g229 ( 
.A(n_223),
.Y(n_229)
);

XOR2xp5_ASAP7_75t_L g230 ( 
.A(n_222),
.B(n_219),
.Y(n_230)
);

INVxp67_ASAP7_75t_L g231 ( 
.A(n_220),
.Y(n_231)
);

OAI22x1_ASAP7_75t_L g232 ( 
.A1(n_224),
.A2(n_216),
.B1(n_221),
.B2(n_214),
.Y(n_232)
);

NAND2xp5_ASAP7_75t_L g233 ( 
.A(n_229),
.B(n_218),
.Y(n_233)
);

INVx1_ASAP7_75t_L g234 ( 
.A(n_225),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_231),
.Y(n_235)
);

AOI21xp5_ASAP7_75t_L g236 ( 
.A1(n_232),
.A2(n_215),
.B(n_230),
.Y(n_236)
);

CKINVDCx20_ASAP7_75t_R g237 ( 
.A(n_236),
.Y(n_237)
);

OAI22xp5_ASAP7_75t_SL g238 ( 
.A1(n_233),
.A2(n_228),
.B1(n_232),
.B2(n_227),
.Y(n_238)
);

INVx1_ASAP7_75t_L g239 ( 
.A(n_237),
.Y(n_239)
);

OAI221xp5_ASAP7_75t_R g240 ( 
.A1(n_239),
.A2(n_238),
.B1(n_227),
.B2(n_226),
.C(n_235),
.Y(n_240)
);

AOI21xp5_ASAP7_75t_L g241 ( 
.A1(n_240),
.A2(n_234),
.B(n_238),
.Y(n_241)
);


endmodule