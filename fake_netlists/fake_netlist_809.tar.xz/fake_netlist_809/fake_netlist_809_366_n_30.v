module fake_netlist_809_366_n_30 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_30);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_6),
.B(n_10),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_9),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_7),
.B(n_4),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_17),
.B(n_16),
.C(n_15),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_4),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_1),
.B(n_0),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_21),
.B1(n_18),
.B2(n_22),
.C(n_13),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_5),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AO22x2_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI22x1_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_29),
.B1(n_12),
.B2(n_8),
.Y(n_30)
);


endmodule