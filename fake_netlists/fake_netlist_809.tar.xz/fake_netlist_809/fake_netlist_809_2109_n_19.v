module fake_netlist_809_2109_n_19 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_19);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

AND2x2_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_6),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_4),
.A2(n_1),
.B1(n_8),
.B2(n_5),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B(n_12),
.Y(n_16)
);

AOI211xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_13),
.B(n_10),
.C(n_15),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_15),
.B1(n_10),
.B2(n_2),
.Y(n_18)
);

AOI322xp5_ASAP7_75t_R g19 ( 
.A1(n_18),
.A2(n_3),
.A3(n_5),
.B1(n_6),
.B2(n_7),
.C1(n_8),
.C2(n_17),
.Y(n_19)
);


endmodule