module fake_netlist_809_1773_n_26 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_26);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

INVx1_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_11),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_3),
.B(n_4),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_1),
.B(n_0),
.Y(n_19)
);

AO31x2_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_7),
.A3(n_6),
.B(n_4),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_14),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_13),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_17),
.B(n_15),
.Y(n_23)
);

NOR4xp75_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.C(n_6),
.D(n_20),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_18),
.B(n_20),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_12),
.B(n_9),
.Y(n_26)
);


endmodule