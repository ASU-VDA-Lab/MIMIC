module fake_netlist_809_1501_n_65 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_65);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_65;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

OAI22xp5_ASAP7_75t_SL g22 ( 
.A1(n_15),
.A2(n_8),
.B1(n_20),
.B2(n_17),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_7),
.B(n_5),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

AND2x6_ASAP7_75t_L g27 ( 
.A(n_4),
.B(n_16),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_8),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_9),
.B(n_18),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_2),
.Y(n_30)
);

INVx5_ASAP7_75t_L g31 ( 
.A(n_12),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_10),
.B(n_15),
.Y(n_32)
);

INVx4_ASAP7_75t_L g33 ( 
.A(n_17),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_28),
.B(n_3),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_31),
.B(n_3),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_23),
.B(n_9),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_28),
.B(n_10),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_33),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_33),
.Y(n_39)
);

AOI21xp5_ASAP7_75t_L g40 ( 
.A1(n_34),
.A2(n_26),
.B(n_23),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_26),
.B(n_25),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_33),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_36),
.Y(n_44)
);

NAND2xp33_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_27),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_36),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_29),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_46),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_44),
.Y(n_50)
);

AOI33xp33_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_24),
.A3(n_29),
.B1(n_42),
.B2(n_22),
.B3(n_25),
.Y(n_51)
);

OAI221xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_22),
.B1(n_42),
.B2(n_32),
.C(n_24),
.Y(n_52)
);

O2A1O1Ixp33_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_35),
.B(n_27),
.C(n_11),
.Y(n_53)
);

OAI221xp5_ASAP7_75t_L g54 ( 
.A1(n_48),
.A2(n_30),
.B1(n_31),
.B2(n_27),
.C(n_11),
.Y(n_54)
);

NAND4xp25_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_19),
.C(n_18),
.D(n_16),
.Y(n_55)
);

A2O1A1Ixp33_ASAP7_75t_L g56 ( 
.A1(n_51),
.A2(n_31),
.B(n_30),
.C(n_27),
.Y(n_56)
);

OAI211xp5_ASAP7_75t_SL g57 ( 
.A1(n_54),
.A2(n_27),
.B(n_21),
.C(n_19),
.Y(n_57)
);

NAND4xp25_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_21),
.C(n_27),
.D(n_31),
.Y(n_58)
);

OR2x2_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_30),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_56),
.Y(n_60)
);

INVxp67_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

OAI22xp5_ASAP7_75t_SL g62 ( 
.A1(n_61),
.A2(n_57),
.B1(n_31),
.B2(n_30),
.Y(n_62)
);

AOI21xp5_ASAP7_75t_L g63 ( 
.A1(n_60),
.A2(n_30),
.B(n_0),
.Y(n_63)
);

AOI22x1_ASAP7_75t_L g64 ( 
.A1(n_63),
.A2(n_59),
.B1(n_14),
.B2(n_6),
.Y(n_64)
);

OR2x2_ASAP7_75t_L g65 ( 
.A(n_64),
.B(n_62),
.Y(n_65)
);


endmodule