module fake_netlist_809_1553_n_61 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_61);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_61;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

AND2x4_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_13),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_14),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_12),
.B(n_11),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_6),
.B(n_1),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_24),
.B(n_23),
.Y(n_31)
);

BUFx4f_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_21),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_32),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_24),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_33),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_31),
.Y(n_38)
);

INVx3_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_37),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_35),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

O2A1O1Ixp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_39),
.B(n_29),
.C(n_21),
.Y(n_49)
);

OAI22xp33_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_22),
.B1(n_30),
.B2(n_25),
.Y(n_50)
);

NAND5xp2_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_30),
.C(n_27),
.D(n_26),
.E(n_28),
.Y(n_51)
);

AOI221xp5_ASAP7_75t_SL g52 ( 
.A1(n_51),
.A2(n_25),
.B1(n_26),
.B2(n_23),
.C(n_29),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

OR2x6_ASAP7_75t_L g54 ( 
.A(n_48),
.B(n_38),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_49),
.A2(n_22),
.B(n_2),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_16),
.Y(n_56)
);

NAND3xp33_ASAP7_75t_SL g57 ( 
.A(n_56),
.B(n_18),
.C(n_3),
.Y(n_57)
);

NAND3x1_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_7),
.C(n_5),
.Y(n_58)
);

NOR3xp33_ASAP7_75t_L g59 ( 
.A(n_52),
.B(n_9),
.C(n_8),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_SL g60 ( 
.A1(n_58),
.A2(n_54),
.B1(n_55),
.B2(n_10),
.Y(n_60)
);

AOI21xp5_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_59),
.B(n_57),
.Y(n_61)
);


endmodule