module fake_netlist_809_367_n_49 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_49);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_49;

wire n_48;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_17;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_2),
.A2(n_0),
.B(n_8),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_5),
.B(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_5),
.B(n_13),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_18),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_4),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_16),
.B(n_22),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_21),
.B1(n_20),
.B2(n_19),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_25),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_23),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_28),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

AOI322xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_18),
.A3(n_19),
.B1(n_21),
.B2(n_22),
.C1(n_23),
.C2(n_26),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_23),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_34),
.B1(n_33),
.B2(n_26),
.C(n_18),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_26),
.B(n_27),
.C(n_21),
.Y(n_39)
);

AO21x1_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_16),
.B(n_37),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_27),
.B(n_16),
.Y(n_41)
);

AND3x4_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_18),
.C(n_35),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_17),
.C(n_6),
.Y(n_43)
);

NOR4xp25_ASAP7_75t_L g44 ( 
.A(n_38),
.B(n_10),
.C(n_9),
.D(n_6),
.Y(n_44)
);

AND4x1_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_15),
.C(n_10),
.D(n_9),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_44),
.B(n_45),
.Y(n_46)
);

XNOR2xp5_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_11),
.Y(n_47)
);

NAND5xp2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_12),
.C(n_14),
.D(n_17),
.E(n_35),
.Y(n_48)
);

AOI22x1_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_17),
.B1(n_47),
.B2(n_46),
.Y(n_49)
);


endmodule