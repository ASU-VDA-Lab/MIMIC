module fake_netlist_809_400_n_37 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_37);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_37;

wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_27;

INVx3_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_5),
.B(n_2),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_14),
.B(n_1),
.Y(n_18)
);

INVx6_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_1),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

INVx5_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

OAI21x1_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_16),
.B(n_18),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_20),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_24),
.B(n_18),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_17),
.Y(n_32)
);

NAND5xp2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_2),
.C(n_0),
.D(n_3),
.E(n_4),
.Y(n_33)
);

OR3x1_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_7),
.C(n_6),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_19),
.C(n_6),
.Y(n_35)
);

AOI222xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_19),
.B1(n_7),
.B2(n_11),
.C1(n_10),
.C2(n_8),
.Y(n_36)
);

AOI22x1_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_34),
.B1(n_35),
.B2(n_19),
.Y(n_37)
);


endmodule