module fake_netlist_809_2451_n_33 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_33);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_33;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_12),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_SL g19 ( 
.A1(n_3),
.A2(n_9),
.B1(n_8),
.B2(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_20),
.B(n_17),
.C(n_16),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_0),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_19),
.B(n_4),
.Y(n_25)
);

CKINVDCx14_ASAP7_75t_R g26 ( 
.A(n_23),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_19),
.B1(n_22),
.B2(n_4),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_24),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

O2A1O1Ixp33_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_28),
.B(n_26),
.C(n_2),
.Y(n_30)
);

NOR2x1p5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_14),
.Y(n_31)
);

XNOR2x1_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_15),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_15),
.B1(n_7),
.B2(n_6),
.Y(n_33)
);


endmodule