module fake_netlist_809_1843_n_9 (n_0, n_1, n_9);

input n_0;
input n_1;

output n_9;

wire n_6;
wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_3;
wire n_8;

AND2x2_ASAP7_75t_SL g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

INVxp67_ASAP7_75t_SL g3 ( 
.A(n_0),
.Y(n_3)
);

OA21x2_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B1(n_3),
.B2(n_4),
.Y(n_6)
);

A2O1A1O1Ixp25_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_0),
.B(n_1),
.C(n_2),
.D(n_3),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AOI31xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.A3(n_2),
.B(n_1),
.Y(n_9)
);


endmodule