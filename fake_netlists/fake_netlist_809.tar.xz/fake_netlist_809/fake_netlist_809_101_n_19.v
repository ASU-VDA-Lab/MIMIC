module fake_netlist_809_101_n_19 (n_4, n_2, n_5, n_3, n_0, n_1, n_19);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

BUFx3_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_3),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

NAND2x1p5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_0),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_8),
.C(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_4),
.C(n_2),
.Y(n_15)
);

NAND2xp33_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_4),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B(n_17),
.Y(n_19)
);


endmodule