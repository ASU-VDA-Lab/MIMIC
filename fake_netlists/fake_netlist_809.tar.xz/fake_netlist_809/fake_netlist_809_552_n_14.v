module fake_netlist_809_552_n_14 (n_4, n_2, n_3, n_0, n_1, n_14);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_2),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

OAI32xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_5),
.A3(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_1),
.C(n_0),
.Y(n_11)
);

XNOR2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_1),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_3),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_4),
.B1(n_12),
.B2(n_11),
.Y(n_14)
);


endmodule