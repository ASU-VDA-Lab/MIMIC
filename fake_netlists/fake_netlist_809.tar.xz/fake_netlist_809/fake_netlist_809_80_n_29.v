module fake_netlist_809_80_n_29 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_29);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_29;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

BUFx3_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_2),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

BUFx10_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_12),
.B(n_1),
.C(n_0),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

CKINVDCx9p33_ASAP7_75t_R g22 ( 
.A(n_20),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

INVx4_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.B(n_14),
.C(n_22),
.Y(n_26)
);

AND4x1_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_12),
.C(n_18),
.D(n_15),
.Y(n_27)
);

OAI22x1_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_6),
.B1(n_5),
.B2(n_3),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_13),
.B1(n_10),
.B2(n_7),
.Y(n_29)
);


endmodule