module fake_netlist_809_1994_n_17 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_17);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_17;

wire n_15;
wire n_13;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;
wire n_9;

INVx3_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_8),
.Y(n_10)
);

INVx5_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

NOR3xp33_ASAP7_75t_SL g13 ( 
.A(n_12),
.B(n_10),
.C(n_9),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B1(n_6),
.B2(n_4),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B1(n_7),
.B2(n_4),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B1(n_7),
.B2(n_0),
.Y(n_16)
);

AO211x2_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_17)
);


endmodule