module fake_netlist_809_2219_n_20 (n_4, n_2, n_3, n_0, n_1, n_20);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_5;
wire n_11;
wire n_8;

OAI22xp5_ASAP7_75t_L g5 ( 
.A1(n_1),
.A2(n_0),
.B1(n_4),
.B2(n_3),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

OAI21x1_ASAP7_75t_SL g9 ( 
.A1(n_5),
.A2(n_2),
.B(n_1),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_6),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_10),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_10),
.B(n_6),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_10),
.B1(n_11),
.B2(n_6),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_11),
.B1(n_10),
.B2(n_2),
.C(n_4),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_SL g17 ( 
.A(n_14),
.B(n_4),
.C(n_3),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_17),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_16),
.Y(n_19)
);

NOR2x1_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);


endmodule