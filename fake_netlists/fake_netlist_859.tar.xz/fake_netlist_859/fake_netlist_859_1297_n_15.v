module fake_netlist_859_1297_n_15 (n_2, n_0, n_3, n_1, n_15);

input n_2;
input n_0;
input n_3;
input n_1;

output n_15;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_1),
.Y(n_4)
);

INVxp67_ASAP7_75t_SL g5 ( 
.A(n_3),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_1),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

OR2x6_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_4),
.Y(n_11)
);

NAND2x1_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_5),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_SL g13 ( 
.A1(n_11),
.A2(n_10),
.B(n_8),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B(n_12),
.C(n_0),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_15)
);


endmodule