module fake_netlist_859_1523_n_26 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_26);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_18;
wire n_21;
wire n_16;

INVx2_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

NOR2x1p5_ASAP7_75t_L g17 ( 
.A(n_7),
.B(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

AOI221x1_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_4),
.B1(n_1),
.B2(n_5),
.C(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_17),
.B1(n_16),
.B2(n_13),
.Y(n_23)
);

NAND4xp75_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_19),
.C(n_15),
.D(n_14),
.Y(n_24)
);

AOI31xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_19),
.A3(n_5),
.B(n_1),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_12),
.B1(n_10),
.B2(n_9),
.Y(n_26)
);


endmodule