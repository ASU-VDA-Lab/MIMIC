module fake_netlist_859_1443_n_11 (n_4, n_2, n_5, n_3, n_0, n_1, n_11);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_11;

wire n_6;
wire n_10;
wire n_7;
wire n_9;
wire n_8;

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_5),
.B(n_1),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_1),
.A2(n_5),
.B1(n_0),
.B2(n_2),
.Y(n_7)
);

OAI22xp5_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_0),
.B1(n_2),
.B2(n_1),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

AND4x1_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.C(n_7),
.D(n_4),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_3),
.B1(n_9),
.B2(n_6),
.Y(n_11)
);


endmodule