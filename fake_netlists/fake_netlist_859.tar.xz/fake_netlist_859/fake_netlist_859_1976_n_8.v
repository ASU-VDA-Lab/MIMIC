module fake_netlist_859_1976_n_8 (n_0, n_1, n_8);

input n_0;
input n_1;

output n_8;

wire n_6;
wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_3;

NAND2xp5_ASAP7_75t_L g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

AND2x2_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

HB1xp67_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_3),
.Y(n_5)
);

NAND3xp33_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_3),
.C(n_0),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_0),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B1(n_6),
.B2(n_4),
.Y(n_8)
);


endmodule