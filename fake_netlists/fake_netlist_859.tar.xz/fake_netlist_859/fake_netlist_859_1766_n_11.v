module fake_netlist_859_1766_n_11 (n_2, n_0, n_1, n_11);

input n_2;
input n_0;
input n_1;

output n_11;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_8;

NAND3xp33_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.C(n_2),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NOR2xp67_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_3),
.Y(n_7)
);

NAND3xp33_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.C(n_1),
.Y(n_8)
);

NOR3x1_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_0),
.C(n_2),
.Y(n_9)
);

AO22x2_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_2),
.B1(n_5),
.B2(n_8),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_10),
.Y(n_11)
);


endmodule