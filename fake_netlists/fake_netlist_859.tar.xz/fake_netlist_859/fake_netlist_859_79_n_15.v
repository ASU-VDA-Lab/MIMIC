module fake_netlist_859_79_n_15 (n_4, n_2, n_5, n_3, n_0, n_1, n_15);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_15;

wire n_6;
wire n_10;
wire n_7;
wire n_13;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_7),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NAND4xp25_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_3),
.C(n_1),
.D(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OR2x2_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_5),
.Y(n_15)
);


endmodule