module fake_netlist_859_1361_n_20 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_20);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_3),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_SL g11 ( 
.A(n_7),
.B(n_4),
.C(n_1),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_6),
.B1(n_5),
.B2(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_SL g13 ( 
.A(n_12),
.Y(n_13)
);

BUFx3_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

OAI322xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.A3(n_10),
.B1(n_14),
.B2(n_11),
.C1(n_6),
.C2(n_2),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_10),
.C(n_11),
.Y(n_17)
);

INVx3_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

XNOR2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_10),
.Y(n_20)
);


endmodule