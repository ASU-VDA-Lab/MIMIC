module fake_netlist_859_2119_n_21 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_21);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_21;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_16;

INVx2_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_4),
.B(n_2),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_11),
.Y(n_14)
);

AND2x6_ASAP7_75t_L g15 ( 
.A(n_1),
.B(n_6),
.Y(n_15)
);

CKINVDCx6p67_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI33xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_12),
.A3(n_15),
.B1(n_7),
.B2(n_6),
.B3(n_4),
.Y(n_18)
);

AOI211xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B(n_14),
.C(n_3),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_5),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_21)
);


endmodule