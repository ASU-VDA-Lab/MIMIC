module fake_netlist_859_1108_n_27 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_27);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_1),
.B(n_0),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_9),
.B(n_2),
.Y(n_19)
);

AOI21xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_16),
.B(n_13),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_17),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_12),
.Y(n_22)
);

OAI31xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.A3(n_5),
.B(n_4),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_4),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_23),
.B(n_6),
.Y(n_25)
);

OAI22x1_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_25),
.B1(n_7),
.B2(n_12),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_7),
.B1(n_12),
.B2(n_24),
.Y(n_27)
);


endmodule