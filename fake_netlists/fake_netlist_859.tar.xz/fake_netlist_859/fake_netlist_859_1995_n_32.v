module fake_netlist_859_1995_n_32 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

INVx1_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_8),
.B(n_3),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_10),
.B(n_9),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_16),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_18),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_13),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_12),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_15),
.B1(n_11),
.B2(n_14),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_15),
.Y(n_25)
);

NAND4xp25_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_14),
.C(n_19),
.D(n_1),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_1),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_4),
.Y(n_28)
);

XNOR2x1_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_4),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_29),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_6),
.B1(n_29),
.B2(n_30),
.Y(n_32)
);


endmodule