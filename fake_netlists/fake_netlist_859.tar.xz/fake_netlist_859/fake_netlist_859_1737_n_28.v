module fake_netlist_859_1737_n_28 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_28);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_5),
.B(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_18),
.C(n_17),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_22),
.B(n_15),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_20),
.B1(n_21),
.B2(n_19),
.C(n_7),
.Y(n_24)
);

NAND4xp75_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_19),
.C(n_7),
.D(n_0),
.Y(n_25)
);

XNOR2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_1),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_8),
.B1(n_3),
.B2(n_2),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_13),
.B1(n_11),
.B2(n_9),
.Y(n_28)
);


endmodule