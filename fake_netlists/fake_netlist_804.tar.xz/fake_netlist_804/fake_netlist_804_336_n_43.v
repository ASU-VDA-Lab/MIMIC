module fake_netlist_804_336_n_43 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_43);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_43;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

AND2x4_ASAP7_75t_L g19 ( 
.A(n_4),
.B(n_18),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_0),
.B(n_14),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_7),
.B(n_2),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_11),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_13),
.B(n_17),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_10),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_1),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_19),
.B(n_5),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_24),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_26),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_27),
.C(n_21),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_34),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_20),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_R g39 ( 
.A(n_37),
.B(n_6),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_39),
.Y(n_40)
);

NAND3xp33_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_9),
.C(n_8),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_41),
.B1(n_15),
.B2(n_12),
.Y(n_43)
);


endmodule