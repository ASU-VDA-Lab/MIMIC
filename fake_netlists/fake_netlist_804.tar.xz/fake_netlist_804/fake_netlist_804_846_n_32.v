module fake_netlist_804_846_n_32 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_32);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_32;

wire n_25;
wire n_20;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_21;
wire n_27;

INVx2_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_1),
.A2(n_16),
.B1(n_3),
.B2(n_2),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

INVx4_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

INVx2_ASAP7_75t_SL g24 ( 
.A(n_0),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_8),
.Y(n_25)
);

NAND2x1p5_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_18),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_SL g27 ( 
.A1(n_23),
.A2(n_18),
.B1(n_5),
.B2(n_4),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_24),
.Y(n_28)
);

XNOR2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_27),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_25),
.B1(n_21),
.B2(n_20),
.C(n_19),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_22),
.C(n_6),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_12),
.B1(n_9),
.B2(n_13),
.C1(n_15),
.C2(n_14),
.Y(n_32)
);


endmodule