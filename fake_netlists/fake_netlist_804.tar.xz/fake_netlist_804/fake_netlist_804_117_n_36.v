module fake_netlist_804_117_n_36 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_36);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_36;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_27;

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_6),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_3),
.B(n_6),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_7),
.B(n_4),
.C(n_1),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_16),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_24),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_24),
.A2(n_18),
.B1(n_16),
.B2(n_15),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_26),
.B(n_22),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_15),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_15),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_SL g32 ( 
.A1(n_29),
.A2(n_21),
.B1(n_17),
.B2(n_19),
.C(n_20),
.Y(n_32)
);

OAI221xp5_ASAP7_75t_R g33 ( 
.A1(n_32),
.A2(n_7),
.B1(n_4),
.B2(n_1),
.C(n_0),
.Y(n_33)
);

XNOR2x1_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_21),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_34),
.B(n_31),
.Y(n_35)
);

AOI222xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_33),
.B1(n_10),
.B2(n_2),
.C1(n_11),
.C2(n_8),
.Y(n_36)
);


endmodule