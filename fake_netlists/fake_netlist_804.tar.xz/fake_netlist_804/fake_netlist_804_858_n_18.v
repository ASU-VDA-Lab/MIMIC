module fake_netlist_804_858_n_18 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_18);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_18;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;
wire n_9;

INVx2_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_2),
.B(n_7),
.Y(n_10)
);

XOR2xp5_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_5),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

AO21x2_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

AOI33xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.A3(n_12),
.B1(n_11),
.B2(n_1),
.B3(n_0),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_12),
.B(n_13),
.C(n_3),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OAI31xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_5),
.A3(n_4),
.B(n_3),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_6),
.B1(n_8),
.B2(n_16),
.C1(n_12),
.C2(n_9),
.Y(n_18)
);


endmodule