module fake_netlist_804_369_n_14 (n_4, n_2, n_3, n_0, n_1, n_14);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_7;
wire n_13;
wire n_5;
wire n_11;
wire n_9;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

BUFx6f_ASAP7_75t_SL g6 ( 
.A(n_2),
.Y(n_6)
);

INVxp67_ASAP7_75t_SL g7 ( 
.A(n_5),
.Y(n_7)
);

INVxp67_ASAP7_75t_SL g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B1(n_8),
.B2(n_6),
.C(n_0),
.Y(n_11)
);

NOR3xp33_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.C(n_0),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_3),
.B1(n_4),
.B2(n_12),
.Y(n_14)
);


endmodule