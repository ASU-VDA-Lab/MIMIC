module fake_netlist_804_544_n_28 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_28);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_6),
.B(n_3),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

NOR2xp67_ASAP7_75t_L g17 ( 
.A(n_1),
.B(n_9),
.Y(n_17)
);

BUFx10_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_11),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_5),
.B(n_4),
.C(n_2),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_13),
.B(n_2),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_20),
.Y(n_24)
);

NAND4xp25_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_17),
.C(n_18),
.D(n_14),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

OAI22x1_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_19),
.B1(n_16),
.B2(n_18),
.Y(n_27)
);

OAI21xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_10),
.B(n_7),
.Y(n_28)
);


endmodule