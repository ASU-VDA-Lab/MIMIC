module fake_netlist_804_623_n_15 (n_4, n_2, n_3, n_0, n_1, n_15);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_15;

wire n_6;
wire n_10;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

NOR2xp33_ASAP7_75t_R g5 ( 
.A(n_2),
.B(n_4),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_3),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_1),
.Y(n_8)
);

CKINVDCx16_ASAP7_75t_R g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI221x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_6),
.B1(n_10),
.B2(n_8),
.C(n_5),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_6),
.B1(n_1),
.B2(n_0),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.Y(n_15)
);


endmodule