module fake_netlist_804_331_n_11 (n_4, n_2, n_3, n_0, n_1, n_11);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_11;

wire n_6;
wire n_10;
wire n_7;
wire n_5;
wire n_9;
wire n_8;

AOI21xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_1),
.B(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

A2O1A1Ixp33_ASAP7_75t_L g7 ( 
.A1(n_1),
.A2(n_2),
.B(n_0),
.C(n_3),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B1(n_5),
.B2(n_0),
.Y(n_10)
);

OAI31xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_3),
.A3(n_8),
.B(n_7),
.Y(n_11)
);


endmodule