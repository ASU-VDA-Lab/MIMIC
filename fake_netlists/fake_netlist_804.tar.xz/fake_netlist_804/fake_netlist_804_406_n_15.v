module fake_netlist_804_406_n_15 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_15);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_15;

wire n_10;
wire n_7;
wire n_13;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

INVxp67_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx5_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B1(n_7),
.B2(n_8),
.Y(n_11)
);

OAI22xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_9),
.B1(n_8),
.B2(n_1),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_8),
.B1(n_2),
.B2(n_1),
.Y(n_13)
);

OAI22x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B1(n_5),
.B2(n_4),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_3),
.B1(n_4),
.B2(n_5),
.C1(n_6),
.C2(n_7),
.Y(n_15)
);


endmodule