module fake_netlist_804_219_n_248 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_34, n_28, n_9, n_31, n_32, n_26, n_24, n_19, n_3, n_33, n_12, n_0, n_29, n_6, n_30, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_248);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_34;
input n_28;
input n_9;
input n_31;
input n_32;
input n_26;
input n_24;
input n_19;
input n_3;
input n_33;
input n_12;
input n_0;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_248;

wire n_49;
wire n_132;
wire n_97;
wire n_194;
wire n_221;
wire n_219;
wire n_81;
wire n_182;
wire n_114;
wire n_130;
wire n_80;
wire n_239;
wire n_166;
wire n_123;
wire n_173;
wire n_240;
wire n_156;
wire n_222;
wire n_126;
wire n_154;
wire n_78;
wire n_153;
wire n_187;
wire n_195;
wire n_210;
wire n_87;
wire n_167;
wire n_122;
wire n_54;
wire n_96;
wire n_95;
wire n_56;
wire n_232;
wire n_59;
wire n_63;
wire n_94;
wire n_74;
wire n_64;
wire n_79;
wire n_177;
wire n_110;
wire n_61;
wire n_184;
wire n_86;
wire n_43;
wire n_45;
wire n_108;
wire n_192;
wire n_244;
wire n_48;
wire n_162;
wire n_163;
wire n_209;
wire n_196;
wire n_230;
wire n_158;
wire n_135;
wire n_171;
wire n_47;
wire n_118;
wire n_214;
wire n_127;
wire n_202;
wire n_90;
wire n_213;
wire n_76;
wire n_189;
wire n_160;
wire n_107;
wire n_125;
wire n_99;
wire n_151;
wire n_178;
wire n_72;
wire n_121;
wire n_73;
wire n_211;
wire n_235;
wire n_37;
wire n_207;
wire n_42;
wire n_120;
wire n_103;
wire n_155;
wire n_145;
wire n_227;
wire n_200;
wire n_246;
wire n_175;
wire n_185;
wire n_52;
wire n_199;
wire n_143;
wire n_170;
wire n_77;
wire n_161;
wire n_190;
wire n_224;
wire n_229;
wire n_137;
wire n_51;
wire n_57;
wire n_138;
wire n_116;
wire n_136;
wire n_179;
wire n_102;
wire n_217;
wire n_119;
wire n_226;
wire n_89;
wire n_152;
wire n_70;
wire n_172;
wire n_238;
wire n_131;
wire n_128;
wire n_133;
wire n_139;
wire n_142;
wire n_115;
wire n_109;
wire n_41;
wire n_62;
wire n_223;
wire n_44;
wire n_144;
wire n_40;
wire n_117;
wire n_53;
wire n_84;
wire n_58;
wire n_68;
wire n_183;
wire n_146;
wire n_104;
wire n_105;
wire n_168;
wire n_225;
wire n_106;
wire n_215;
wire n_149;
wire n_188;
wire n_85;
wire n_237;
wire n_205;
wire n_55;
wire n_164;
wire n_65;
wire n_159;
wire n_247;
wire n_75;
wire n_140;
wire n_176;
wire n_67;
wire n_66;
wire n_101;
wire n_98;
wire n_91;
wire n_233;
wire n_36;
wire n_242;
wire n_204;
wire n_203;
wire n_50;
wire n_191;
wire n_112;
wire n_129;
wire n_181;
wire n_157;
wire n_201;
wire n_198;
wire n_83;
wire n_228;
wire n_60;
wire n_39;
wire n_111;
wire n_169;
wire n_180;
wire n_93;
wire n_174;
wire n_220;
wire n_150;
wire n_216;
wire n_71;
wire n_208;
wire n_92;
wire n_82;
wire n_186;
wire n_100;
wire n_218;
wire n_69;
wire n_193;
wire n_234;
wire n_212;
wire n_165;
wire n_88;
wire n_124;
wire n_197;
wire n_241;
wire n_113;
wire n_236;
wire n_206;
wire n_243;
wire n_147;
wire n_231;
wire n_141;
wire n_134;
wire n_35;
wire n_148;
wire n_38;
wire n_245;
wire n_46;

INVx1_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_15),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_4),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_0),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_30),
.Y(n_40)
);

INVxp33_ASAP7_75t_SL g41 ( 
.A(n_25),
.Y(n_41)
);

INVx2_ASAP7_75t_SL g42 ( 
.A(n_31),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_20),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_15),
.Y(n_44)
);

CKINVDCx20_ASAP7_75t_R g45 ( 
.A(n_23),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_29),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_18),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_13),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_7),
.Y(n_49)
);

BUFx5_ASAP7_75t_L g50 ( 
.A(n_21),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_19),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_4),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_35),
.Y(n_53)
);

AND2x4_ASAP7_75t_L g54 ( 
.A(n_42),
.B(n_0),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_36),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_40),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_50),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_50),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_37),
.B(n_1),
.Y(n_59)
);

BUFx6f_ASAP7_75t_L g60 ( 
.A(n_46),
.Y(n_60)
);

BUFx2_ASAP7_75t_L g61 ( 
.A(n_38),
.Y(n_61)
);

AND2x4_ASAP7_75t_L g62 ( 
.A(n_54),
.B(n_39),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_57),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_53),
.B(n_47),
.Y(n_64)
);

AOI22xp5_ASAP7_75t_L g65 ( 
.A1(n_54),
.A2(n_45),
.B1(n_48),
.B2(n_41),
.Y(n_65)
);

NOR2x1p5_ASAP7_75t_L g66 ( 
.A(n_59),
.B(n_44),
.Y(n_66)
);

AND2x2_ASAP7_75t_L g67 ( 
.A(n_61),
.B(n_49),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_53),
.B(n_51),
.Y(n_68)
);

INVx2_ASAP7_75t_SL g69 ( 
.A(n_54),
.Y(n_69)
);

NAND2xp5_ASAP7_75t_L g70 ( 
.A(n_55),
.B(n_50),
.Y(n_70)
);

NOR2xp67_ASAP7_75t_L g71 ( 
.A(n_57),
.B(n_58),
.Y(n_71)
);

OAI22xp5_ASAP7_75t_L g72 ( 
.A1(n_55),
.A2(n_48),
.B1(n_45),
.B2(n_52),
.Y(n_72)
);

NAND2xp5_ASAP7_75t_L g73 ( 
.A(n_56),
.B(n_50),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_L g74 ( 
.A(n_56),
.B(n_50),
.Y(n_74)
);

CKINVDCx5p33_ASAP7_75t_R g75 ( 
.A(n_61),
.Y(n_75)
);

BUFx3_ASAP7_75t_L g76 ( 
.A(n_60),
.Y(n_76)
);

INVx2_ASAP7_75t_L g77 ( 
.A(n_76),
.Y(n_77)
);

INVx2_ASAP7_75t_L g78 ( 
.A(n_76),
.Y(n_78)
);

OR2x2_ASAP7_75t_L g79 ( 
.A(n_72),
.B(n_1),
.Y(n_79)
);

NOR2x1p5_ASAP7_75t_SL g80 ( 
.A(n_63),
.B(n_50),
.Y(n_80)
);

BUFx6f_ASAP7_75t_L g81 ( 
.A(n_76),
.Y(n_81)
);

OA22x2_ASAP7_75t_L g82 ( 
.A1(n_65),
.A2(n_58),
.B1(n_57),
.B2(n_43),
.Y(n_82)
);

OAI22xp5_ASAP7_75t_SL g83 ( 
.A1(n_72),
.A2(n_60),
.B1(n_58),
.B2(n_2),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_63),
.Y(n_84)
);

OR2x6_ASAP7_75t_L g85 ( 
.A(n_62),
.B(n_60),
.Y(n_85)
);

BUFx6f_ASAP7_75t_L g86 ( 
.A(n_69),
.Y(n_86)
);

NAND2xp5_ASAP7_75t_L g87 ( 
.A(n_66),
.B(n_50),
.Y(n_87)
);

A2O1A1Ixp33_ASAP7_75t_L g88 ( 
.A1(n_69),
.A2(n_5),
.B(n_3),
.C(n_2),
.Y(n_88)
);

NAND2xp5_ASAP7_75t_L g89 ( 
.A(n_67),
.B(n_68),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_69),
.Y(n_90)
);

NAND2xp5_ASAP7_75t_L g91 ( 
.A(n_67),
.B(n_3),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_74),
.Y(n_92)
);

NAND2xp5_ASAP7_75t_L g93 ( 
.A(n_89),
.B(n_92),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_84),
.Y(n_94)
);

CKINVDCx20_ASAP7_75t_R g95 ( 
.A(n_79),
.Y(n_95)
);

NAND2xp5_ASAP7_75t_L g96 ( 
.A(n_92),
.B(n_67),
.Y(n_96)
);

AOI22xp5_ASAP7_75t_L g97 ( 
.A1(n_82),
.A2(n_65),
.B1(n_75),
.B2(n_68),
.Y(n_97)
);

AND2x2_ASAP7_75t_L g98 ( 
.A(n_79),
.B(n_64),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_84),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_86),
.Y(n_100)
);

AOI22xp5_ASAP7_75t_L g101 ( 
.A1(n_82),
.A2(n_64),
.B1(n_74),
.B2(n_70),
.Y(n_101)
);

OR2x2_ASAP7_75t_L g102 ( 
.A(n_91),
.B(n_73),
.Y(n_102)
);

AND2x2_ASAP7_75t_L g103 ( 
.A(n_82),
.B(n_71),
.Y(n_103)
);

HB1xp67_ASAP7_75t_L g104 ( 
.A(n_85),
.Y(n_104)
);

AOI22xp5_ASAP7_75t_L g105 ( 
.A1(n_83),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_105)
);

BUFx3_ASAP7_75t_L g106 ( 
.A(n_93),
.Y(n_106)
);

INVx2_ASAP7_75t_L g107 ( 
.A(n_94),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_94),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_99),
.Y(n_109)
);

INVx2_ASAP7_75t_L g110 ( 
.A(n_100),
.Y(n_110)
);

INVx2_ASAP7_75t_L g111 ( 
.A(n_100),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_96),
.Y(n_112)
);

NOR2xp33_ASAP7_75t_L g113 ( 
.A(n_98),
.B(n_87),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_102),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_102),
.Y(n_115)
);

INVx3_ASAP7_75t_L g116 ( 
.A(n_103),
.Y(n_116)
);

OR2x2_ASAP7_75t_L g117 ( 
.A(n_98),
.B(n_85),
.Y(n_117)
);

CKINVDCx20_ASAP7_75t_R g118 ( 
.A(n_106),
.Y(n_118)
);

AND2x2_ASAP7_75t_L g119 ( 
.A(n_106),
.B(n_95),
.Y(n_119)
);

INVx2_ASAP7_75t_L g120 ( 
.A(n_107),
.Y(n_120)
);

INVx1_ASAP7_75t_L g121 ( 
.A(n_108),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_108),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_107),
.Y(n_123)
);

AND2x2_ASAP7_75t_L g124 ( 
.A(n_106),
.B(n_114),
.Y(n_124)
);

BUFx3_ASAP7_75t_L g125 ( 
.A(n_107),
.Y(n_125)
);

BUFx3_ASAP7_75t_L g126 ( 
.A(n_114),
.Y(n_126)
);

INVx2_ASAP7_75t_L g127 ( 
.A(n_110),
.Y(n_127)
);

AND2x2_ASAP7_75t_L g128 ( 
.A(n_115),
.B(n_95),
.Y(n_128)
);

INVx2_ASAP7_75t_L g129 ( 
.A(n_110),
.Y(n_129)
);

HB1xp67_ASAP7_75t_L g130 ( 
.A(n_119),
.Y(n_130)
);

OR2x2_ASAP7_75t_L g131 ( 
.A(n_126),
.B(n_124),
.Y(n_131)
);

INVx1_ASAP7_75t_L g132 ( 
.A(n_121),
.Y(n_132)
);

OR2x6_ASAP7_75t_L g133 ( 
.A(n_125),
.B(n_116),
.Y(n_133)
);

OAI31xp33_ASAP7_75t_L g134 ( 
.A1(n_119),
.A2(n_115),
.A3(n_112),
.B(n_113),
.Y(n_134)
);

AND2x2_ASAP7_75t_L g135 ( 
.A(n_124),
.B(n_109),
.Y(n_135)
);

OR2x2_ASAP7_75t_L g136 ( 
.A(n_126),
.B(n_109),
.Y(n_136)
);

NAND2xp5_ASAP7_75t_L g137 ( 
.A(n_128),
.B(n_112),
.Y(n_137)
);

INVx3_ASAP7_75t_L g138 ( 
.A(n_125),
.Y(n_138)
);

INVx2_ASAP7_75t_L g139 ( 
.A(n_120),
.Y(n_139)
);

OR2x2_ASAP7_75t_L g140 ( 
.A(n_126),
.B(n_116),
.Y(n_140)
);

AOI22xp33_ASAP7_75t_L g141 ( 
.A1(n_128),
.A2(n_116),
.B1(n_117),
.B2(n_97),
.Y(n_141)
);

AND2x2_ASAP7_75t_L g142 ( 
.A(n_126),
.B(n_122),
.Y(n_142)
);

NAND4xp25_ASAP7_75t_SL g143 ( 
.A(n_118),
.B(n_105),
.C(n_88),
.D(n_101),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_123),
.Y(n_144)
);

INVx1_ASAP7_75t_L g145 ( 
.A(n_132),
.Y(n_145)
);

INVx1_ASAP7_75t_L g146 ( 
.A(n_132),
.Y(n_146)
);

AND2x2_ASAP7_75t_L g147 ( 
.A(n_142),
.B(n_123),
.Y(n_147)
);

NAND2xp5_ASAP7_75t_L g148 ( 
.A(n_137),
.B(n_118),
.Y(n_148)
);

OR2x2_ASAP7_75t_L g149 ( 
.A(n_131),
.B(n_120),
.Y(n_149)
);

AND2x4_ASAP7_75t_L g150 ( 
.A(n_142),
.B(n_144),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_144),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_135),
.Y(n_152)
);

NOR2xp33_ASAP7_75t_SL g153 ( 
.A(n_134),
.B(n_125),
.Y(n_153)
);

INVx2_ASAP7_75t_L g154 ( 
.A(n_139),
.Y(n_154)
);

NAND2xp5_ASAP7_75t_L g155 ( 
.A(n_130),
.B(n_120),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_139),
.Y(n_156)
);

AND2x4_ASAP7_75t_L g157 ( 
.A(n_138),
.B(n_127),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_136),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_139),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_131),
.Y(n_160)
);

NOR2xp33_ASAP7_75t_L g161 ( 
.A(n_143),
.B(n_104),
.Y(n_161)
);

OR2x2_ASAP7_75t_L g162 ( 
.A(n_140),
.B(n_127),
.Y(n_162)
);

INVx2_ASAP7_75t_L g163 ( 
.A(n_138),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_145),
.Y(n_164)
);

AND2x2_ASAP7_75t_L g165 ( 
.A(n_150),
.B(n_138),
.Y(n_165)
);

INVx1_ASAP7_75t_L g166 ( 
.A(n_146),
.Y(n_166)
);

CKINVDCx16_ASAP7_75t_R g167 ( 
.A(n_147),
.Y(n_167)
);

AOI21xp33_ASAP7_75t_L g168 ( 
.A1(n_161),
.A2(n_141),
.B(n_133),
.Y(n_168)
);

NOR2xp33_ASAP7_75t_L g169 ( 
.A(n_148),
.B(n_9),
.Y(n_169)
);

AND2x2_ASAP7_75t_L g170 ( 
.A(n_150),
.B(n_133),
.Y(n_170)
);

NAND2xp5_ASAP7_75t_L g171 ( 
.A(n_152),
.B(n_127),
.Y(n_171)
);

CKINVDCx16_ASAP7_75t_R g172 ( 
.A(n_147),
.Y(n_172)
);

INVx1_ASAP7_75t_SL g173 ( 
.A(n_149),
.Y(n_173)
);

NOR2x1_ASAP7_75t_L g174 ( 
.A(n_151),
.B(n_133),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_160),
.Y(n_175)
);

BUFx4f_ASAP7_75t_SL g176 ( 
.A(n_162),
.Y(n_176)
);

INVx2_ASAP7_75t_L g177 ( 
.A(n_154),
.Y(n_177)
);

INVx1_ASAP7_75t_L g178 ( 
.A(n_160),
.Y(n_178)
);

NAND2xp5_ASAP7_75t_L g179 ( 
.A(n_158),
.B(n_129),
.Y(n_179)
);

INVx1_ASAP7_75t_L g180 ( 
.A(n_155),
.Y(n_180)
);

INVx2_ASAP7_75t_L g181 ( 
.A(n_156),
.Y(n_181)
);

AND2x2_ASAP7_75t_L g182 ( 
.A(n_159),
.B(n_10),
.Y(n_182)
);

INVx4_ASAP7_75t_L g183 ( 
.A(n_157),
.Y(n_183)
);

OR2x2_ASAP7_75t_L g184 ( 
.A(n_163),
.B(n_11),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_153),
.Y(n_185)
);

INVx1_ASAP7_75t_L g186 ( 
.A(n_151),
.Y(n_186)
);

INVx2_ASAP7_75t_L g187 ( 
.A(n_154),
.Y(n_187)
);

NAND2xp5_ASAP7_75t_L g188 ( 
.A(n_167),
.B(n_12),
.Y(n_188)
);

NAND2xp5_ASAP7_75t_L g189 ( 
.A(n_172),
.B(n_12),
.Y(n_189)
);

OR2x6_ASAP7_75t_L g190 ( 
.A(n_183),
.B(n_80),
.Y(n_190)
);

OR2x2_ASAP7_75t_L g191 ( 
.A(n_173),
.B(n_13),
.Y(n_191)
);

NOR2xp33_ASAP7_75t_L g192 ( 
.A(n_169),
.B(n_14),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_165),
.B(n_14),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_164),
.Y(n_194)
);

INVx2_ASAP7_75t_L g195 ( 
.A(n_181),
.Y(n_195)
);

CKINVDCx20_ASAP7_75t_R g196 ( 
.A(n_176),
.Y(n_196)
);

INVx2_ASAP7_75t_L g197 ( 
.A(n_181),
.Y(n_197)
);

NAND2xp5_ASAP7_75t_SL g198 ( 
.A(n_183),
.B(n_110),
.Y(n_198)
);

INVx2_ASAP7_75t_SL g199 ( 
.A(n_183),
.Y(n_199)
);

INVx1_ASAP7_75t_L g200 ( 
.A(n_166),
.Y(n_200)
);

NAND2xp5_ASAP7_75t_L g201 ( 
.A(n_180),
.B(n_16),
.Y(n_201)
);

AND2x2_ASAP7_75t_L g202 ( 
.A(n_165),
.B(n_17),
.Y(n_202)
);

NAND2xp5_ASAP7_75t_SL g203 ( 
.A(n_174),
.B(n_111),
.Y(n_203)
);

NAND2xp5_ASAP7_75t_L g204 ( 
.A(n_175),
.B(n_80),
.Y(n_204)
);

NAND2xp5_ASAP7_75t_L g205 ( 
.A(n_178),
.B(n_186),
.Y(n_205)
);

NAND2xp5_ASAP7_75t_SL g206 ( 
.A(n_182),
.B(n_86),
.Y(n_206)
);

NAND2xp5_ASAP7_75t_L g207 ( 
.A(n_171),
.B(n_22),
.Y(n_207)
);

NAND2xp5_ASAP7_75t_SL g208 ( 
.A(n_185),
.B(n_86),
.Y(n_208)
);

NAND4xp75_ASAP7_75t_L g209 ( 
.A(n_188),
.B(n_168),
.C(n_170),
.D(n_179),
.Y(n_209)
);

INVx1_ASAP7_75t_L g210 ( 
.A(n_205),
.Y(n_210)
);

NAND2xp33_ASAP7_75t_SL g211 ( 
.A(n_196),
.B(n_170),
.Y(n_211)
);

NOR2x1_ASAP7_75t_L g212 ( 
.A(n_196),
.B(n_184),
.Y(n_212)
);

NAND4xp25_ASAP7_75t_L g213 ( 
.A(n_192),
.B(n_187),
.C(n_177),
.D(n_90),
.Y(n_213)
);

NAND4xp25_ASAP7_75t_L g214 ( 
.A(n_189),
.B(n_187),
.C(n_177),
.D(n_90),
.Y(n_214)
);

NOR2xp33_ASAP7_75t_L g215 ( 
.A(n_191),
.B(n_26),
.Y(n_215)
);

INVx1_ASAP7_75t_L g216 ( 
.A(n_194),
.Y(n_216)
);

OAI211xp5_ASAP7_75t_SL g217 ( 
.A1(n_201),
.A2(n_78),
.B(n_77),
.C(n_27),
.Y(n_217)
);

AOI211xp5_ASAP7_75t_L g218 ( 
.A1(n_199),
.A2(n_193),
.B(n_202),
.C(n_191),
.Y(n_218)
);

INVx1_ASAP7_75t_L g219 ( 
.A(n_200),
.Y(n_219)
);

OAI211xp5_ASAP7_75t_L g220 ( 
.A1(n_202),
.A2(n_34),
.B(n_33),
.C(n_32),
.Y(n_220)
);

NAND3xp33_ASAP7_75t_L g221 ( 
.A(n_198),
.B(n_81),
.C(n_204),
.Y(n_221)
);

OAI21xp5_ASAP7_75t_L g222 ( 
.A1(n_198),
.A2(n_206),
.B(n_208),
.Y(n_222)
);

NOR2x1_ASAP7_75t_L g223 ( 
.A(n_203),
.B(n_208),
.Y(n_223)
);

NAND2xp5_ASAP7_75t_SL g224 ( 
.A(n_195),
.B(n_197),
.Y(n_224)
);

INVxp67_ASAP7_75t_L g225 ( 
.A(n_223),
.Y(n_225)
);

XNOR2xp5_ASAP7_75t_L g226 ( 
.A(n_218),
.B(n_207),
.Y(n_226)
);

AOI21xp5_ASAP7_75t_L g227 ( 
.A1(n_222),
.A2(n_213),
.B(n_221),
.Y(n_227)
);

AOI21xp5_ASAP7_75t_L g228 ( 
.A1(n_214),
.A2(n_190),
.B(n_211),
.Y(n_228)
);

AND2x4_ASAP7_75t_L g229 ( 
.A(n_210),
.B(n_212),
.Y(n_229)
);

NOR2x1_ASAP7_75t_L g230 ( 
.A(n_209),
.B(n_220),
.Y(n_230)
);

INVxp67_ASAP7_75t_SL g231 ( 
.A(n_224),
.Y(n_231)
);

NAND2xp33_ASAP7_75t_SL g232 ( 
.A(n_216),
.B(n_219),
.Y(n_232)
);

NOR2x1_ASAP7_75t_L g233 ( 
.A(n_217),
.B(n_215),
.Y(n_233)
);

AND3x4_ASAP7_75t_L g234 ( 
.A(n_230),
.B(n_233),
.C(n_229),
.Y(n_234)
);

NOR2x1_ASAP7_75t_L g235 ( 
.A(n_228),
.B(n_229),
.Y(n_235)
);

OAI221xp5_ASAP7_75t_L g236 ( 
.A1(n_225),
.A2(n_226),
.B1(n_227),
.B2(n_232),
.C(n_231),
.Y(n_236)
);

AND2x4_ASAP7_75t_L g237 ( 
.A(n_225),
.B(n_227),
.Y(n_237)
);

NAND2xp33_ASAP7_75t_R g238 ( 
.A(n_228),
.B(n_229),
.Y(n_238)
);

CKINVDCx16_ASAP7_75t_R g239 ( 
.A(n_238),
.Y(n_239)
);

HB1xp67_ASAP7_75t_L g240 ( 
.A(n_237),
.Y(n_240)
);

INVx4_ASAP7_75t_L g241 ( 
.A(n_234),
.Y(n_241)
);

AOI21xp5_ASAP7_75t_L g242 ( 
.A1(n_241),
.A2(n_236),
.B(n_235),
.Y(n_242)
);

BUFx2_ASAP7_75t_L g243 ( 
.A(n_240),
.Y(n_243)
);

XOR2xp5_ASAP7_75t_L g244 ( 
.A(n_242),
.B(n_239),
.Y(n_244)
);

XNOR2xp5_ASAP7_75t_L g245 ( 
.A(n_243),
.B(n_240),
.Y(n_245)
);

INVx1_ASAP7_75t_L g246 ( 
.A(n_245),
.Y(n_246)
);

INVxp67_ASAP7_75t_SL g247 ( 
.A(n_246),
.Y(n_247)
);

AOI21xp5_ASAP7_75t_L g248 ( 
.A1(n_247),
.A2(n_244),
.B(n_241),
.Y(n_248)
);


endmodule