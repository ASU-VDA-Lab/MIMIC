module fake_netlist_804_69_n_17 (n_4, n_2, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

AND2x6_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_4),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_6),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_8),
.Y(n_10)
);

O2A1O1Ixp33_ASAP7_75t_R g11 ( 
.A1(n_9),
.A2(n_6),
.B(n_1),
.C(n_7),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_7),
.Y(n_12)
);

OA22x2_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_6),
.B1(n_1),
.B2(n_0),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_7),
.B(n_6),
.C(n_1),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

NOR2xp67_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_2),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_3),
.B1(n_16),
.B2(n_13),
.Y(n_17)
);


endmodule