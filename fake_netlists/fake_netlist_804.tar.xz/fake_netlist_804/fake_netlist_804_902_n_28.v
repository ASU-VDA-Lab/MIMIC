module fake_netlist_804_902_n_28 (n_4, n_2, n_5, n_3, n_0, n_1, n_28);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;
wire n_8;

BUFx2_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_4),
.B(n_5),
.Y(n_7)
);

NAND2xp33_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_8),
.Y(n_15)
);

NAND2x1p5_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_12),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_12),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_18),
.A2(n_15),
.B1(n_11),
.B2(n_16),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_18),
.B(n_1),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_16),
.B1(n_4),
.B2(n_2),
.C(n_3),
.Y(n_22)
);

NAND2x1p5_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_17),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_20),
.B(n_2),
.Y(n_24)
);

AND3x4_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_16),
.C(n_3),
.Y(n_25)
);

AO22x2_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_5),
.B1(n_24),
.B2(n_23),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_27),
.Y(n_28)
);


endmodule