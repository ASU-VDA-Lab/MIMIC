module fake_netlist_803_2934_n_23 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_23);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

OR2x6_ASAP7_75t_SL g13 ( 
.A(n_7),
.B(n_5),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_1),
.B1(n_6),
.B2(n_7),
.C(n_9),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_11),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_8),
.A2(n_12),
.B(n_13),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_8),
.Y(n_19)
);

CKINVDCx16_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

INVx2_ASAP7_75t_SL g21 ( 
.A(n_19),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B1(n_20),
.B2(n_14),
.Y(n_23)
);


endmodule