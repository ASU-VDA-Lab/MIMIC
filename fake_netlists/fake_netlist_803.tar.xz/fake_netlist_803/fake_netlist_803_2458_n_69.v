module fake_netlist_803_2458_n_69 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_69);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_69;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_68;
wire n_26;
wire n_24;
wire n_37;
wire n_54;
wire n_42;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_35;
wire n_52;
wire n_38;
wire n_61;
wire n_27;
wire n_67;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_7),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_10),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_11),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_2),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_13),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

CKINVDCx16_ASAP7_75t_R g30 ( 
.A(n_11),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_10),
.B(n_2),
.Y(n_31)
);

A2O1A1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_12),
.B(n_8),
.C(n_3),
.Y(n_32)
);

BUFx6f_ASAP7_75t_SL g33 ( 
.A(n_25),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_30),
.Y(n_34)
);

BUFx4f_ASAP7_75t_L g35 ( 
.A(n_27),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_28),
.Y(n_36)
);

AO32x2_ASAP7_75t_L g37 ( 
.A1(n_32),
.A2(n_35),
.A3(n_22),
.B1(n_36),
.B2(n_31),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_29),
.B(n_28),
.Y(n_38)
);

BUFx4f_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NOR3xp33_ASAP7_75t_SL g40 ( 
.A(n_34),
.B(n_26),
.C(n_24),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_35),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_34),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_37),
.Y(n_44)
);

INVx2_ASAP7_75t_SL g45 ( 
.A(n_42),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_37),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_22),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_33),
.B1(n_23),
.B2(n_29),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_33),
.B1(n_23),
.B2(n_36),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_33),
.B1(n_36),
.B2(n_39),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_46),
.B1(n_45),
.B2(n_44),
.Y(n_52)
);

AOI21xp33_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_45),
.B(n_44),
.Y(n_53)
);

OAI211xp5_ASAP7_75t_SL g54 ( 
.A1(n_49),
.A2(n_37),
.B(n_8),
.C(n_3),
.Y(n_54)
);

OAI221xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_39),
.B1(n_37),
.B2(n_12),
.C(n_13),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

NOR2xp33_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_14),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_56),
.Y(n_58)
);

O2A1O1Ixp33_ASAP7_75t_L g59 ( 
.A1(n_54),
.A2(n_17),
.B(n_16),
.C(n_14),
.Y(n_59)
);

AOI21xp5_ASAP7_75t_L g60 ( 
.A1(n_53),
.A2(n_39),
.B(n_0),
.Y(n_60)
);

NOR3xp33_ASAP7_75t_SL g61 ( 
.A(n_55),
.B(n_17),
.C(n_16),
.Y(n_61)
);

BUFx2_ASAP7_75t_L g62 ( 
.A(n_58),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_57),
.B(n_18),
.Y(n_63)
);

AOI22xp5_ASAP7_75t_L g64 ( 
.A1(n_57),
.A2(n_20),
.B1(n_19),
.B2(n_18),
.Y(n_64)
);

INVxp67_ASAP7_75t_L g65 ( 
.A(n_61),
.Y(n_65)
);

OAI221xp5_ASAP7_75t_L g66 ( 
.A1(n_65),
.A2(n_59),
.B1(n_60),
.B2(n_19),
.C(n_20),
.Y(n_66)
);

NAND5xp2_ASAP7_75t_L g67 ( 
.A(n_65),
.B(n_21),
.C(n_6),
.D(n_1),
.E(n_5),
.Y(n_67)
);

OAI22x1_ASAP7_75t_L g68 ( 
.A1(n_62),
.A2(n_64),
.B1(n_63),
.B2(n_21),
.Y(n_68)
);

AOI22x1_ASAP7_75t_L g69 ( 
.A1(n_68),
.A2(n_15),
.B1(n_67),
.B2(n_66),
.Y(n_69)
);


endmodule