module fake_netlist_803_1435_n_40 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_40);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_40;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_34;
wire n_23;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_11;
wire n_27;

OR2x6_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_5),
.B(n_9),
.Y(n_14)
);

BUFx10_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

BUFx3_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_12),
.B(n_13),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_0),
.Y(n_21)
);

O2A1O1Ixp5_ASAP7_75t_L g22 ( 
.A1(n_16),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_14),
.A2(n_4),
.B(n_3),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_19),
.A2(n_11),
.B1(n_14),
.B2(n_15),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_26),
.Y(n_31)
);

NAND2xp67_ASAP7_75t_L g32 ( 
.A(n_27),
.B(n_24),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

OAI22xp33_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_11),
.B1(n_21),
.B2(n_25),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_11),
.B(n_21),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_31),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_22),
.B1(n_25),
.B2(n_32),
.C(n_29),
.Y(n_37)
);

A2O1A1Ixp33_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_35),
.B(n_15),
.C(n_4),
.Y(n_38)
);

NOR2x1_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_6),
.Y(n_39)
);

OAI21xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_7),
.B(n_39),
.Y(n_40)
);


endmodule