module fake_netlist_803_3080_n_44 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_44);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_44;

wire n_25;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_18),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_5),
.B(n_9),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_20),
.B(n_6),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_16),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_10),
.B(n_13),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_3),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_14),
.B(n_11),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_SL g31 ( 
.A(n_25),
.B(n_17),
.C(n_2),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_R g33 ( 
.A(n_21),
.B(n_4),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_23),
.B1(n_29),
.B2(n_22),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_34),
.B2(n_24),
.C(n_30),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_33),
.Y(n_38)
);

NOR2x1_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_26),
.Y(n_39)
);

A2O1A1Ixp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_27),
.B(n_8),
.C(n_7),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_40),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_15),
.B1(n_19),
.B2(n_41),
.Y(n_43)
);

CKINVDCx11_ASAP7_75t_R g44 ( 
.A(n_43),
.Y(n_44)
);


endmodule