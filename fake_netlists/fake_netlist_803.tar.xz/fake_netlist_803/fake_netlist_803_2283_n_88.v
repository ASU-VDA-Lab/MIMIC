module fake_netlist_803_2283_n_88 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_28, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_88);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_28;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_88;

wire n_49;
wire n_81;
wire n_80;
wire n_78;
wire n_87;
wire n_54;
wire n_56;
wire n_59;
wire n_63;
wire n_74;
wire n_64;
wire n_79;
wire n_61;
wire n_86;
wire n_43;
wire n_45;
wire n_48;
wire n_47;
wire n_76;
wire n_72;
wire n_73;
wire n_37;
wire n_42;
wire n_52;
wire n_77;
wire n_57;
wire n_51;
wire n_70;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_53;
wire n_84;
wire n_58;
wire n_68;
wire n_33;
wire n_85;
wire n_55;
wire n_65;
wire n_75;
wire n_67;
wire n_66;
wire n_36;
wire n_50;
wire n_83;
wire n_60;
wire n_39;
wire n_32;
wire n_31;
wire n_71;
wire n_82;
wire n_69;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_46;

INVx2_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_17),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_11),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_6),
.B(n_5),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_3),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_28),
.B(n_26),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_22),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_21),
.B(n_26),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_7),
.B(n_27),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_24),
.A2(n_23),
.B(n_1),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_10),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_19),
.B(n_0),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_19),
.Y(n_42)
);

OA21x2_ASAP7_75t_L g43 ( 
.A1(n_22),
.A2(n_24),
.B(n_12),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_28),
.B(n_4),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_30),
.A2(n_25),
.B1(n_23),
.B2(n_20),
.Y(n_45)
);

NOR2xp67_ASAP7_75t_L g46 ( 
.A(n_30),
.B(n_20),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_36),
.A2(n_9),
.B1(n_8),
.B2(n_2),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_36),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_L g49 ( 
.A(n_34),
.B(n_13),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_34),
.B(n_14),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_42),
.A2(n_15),
.B1(n_18),
.B2(n_44),
.Y(n_51)
);

INVxp67_ASAP7_75t_SL g52 ( 
.A(n_34),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_52),
.B(n_34),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_48),
.Y(n_54)
);

AND2x6_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_44),
.Y(n_55)
);

BUFx3_ASAP7_75t_L g56 ( 
.A(n_50),
.Y(n_56)
);

AOI21xp5_ASAP7_75t_L g57 ( 
.A1(n_49),
.A2(n_40),
.B(n_32),
.Y(n_57)
);

INVx2_ASAP7_75t_SL g58 ( 
.A(n_56),
.Y(n_58)
);

OR2x2_ASAP7_75t_L g59 ( 
.A(n_54),
.B(n_35),
.Y(n_59)
);

CKINVDCx6p67_ASAP7_75t_R g60 ( 
.A(n_55),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_53),
.B(n_46),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_55),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_59),
.B(n_55),
.Y(n_63)
);

AND2x6_ASAP7_75t_SL g64 ( 
.A(n_61),
.B(n_35),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_59),
.Y(n_65)
);

NOR4xp75_ASAP7_75t_L g66 ( 
.A(n_63),
.B(n_60),
.C(n_41),
.D(n_37),
.Y(n_66)
);

AOI33xp33_ASAP7_75t_L g67 ( 
.A1(n_65),
.A2(n_61),
.A3(n_45),
.B1(n_63),
.B2(n_64),
.B3(n_32),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_65),
.B(n_58),
.Y(n_68)
);

O2A1O1Ixp5_ASAP7_75t_L g69 ( 
.A1(n_62),
.A2(n_57),
.B(n_33),
.C(n_31),
.Y(n_69)
);

NAND2xp33_ASAP7_75t_L g70 ( 
.A(n_64),
.B(n_55),
.Y(n_70)
);

NOR2xp33_ASAP7_75t_L g71 ( 
.A(n_70),
.B(n_60),
.Y(n_71)
);

HB1xp67_ASAP7_75t_L g72 ( 
.A(n_68),
.Y(n_72)
);

AOI221xp5_ASAP7_75t_L g73 ( 
.A1(n_70),
.A2(n_45),
.B1(n_40),
.B2(n_37),
.C(n_38),
.Y(n_73)
);

NAND4xp75_ASAP7_75t_L g74 ( 
.A(n_69),
.B(n_47),
.C(n_43),
.D(n_41),
.Y(n_74)
);

AOI21xp5_ASAP7_75t_L g75 ( 
.A1(n_67),
.A2(n_38),
.B(n_29),
.Y(n_75)
);

AOI22xp5_ASAP7_75t_L g76 ( 
.A1(n_72),
.A2(n_66),
.B1(n_43),
.B2(n_39),
.Y(n_76)
);

NOR2x1p5_ASAP7_75t_L g77 ( 
.A(n_74),
.B(n_29),
.Y(n_77)
);

CKINVDCx5p33_ASAP7_75t_R g78 ( 
.A(n_71),
.Y(n_78)
);

NOR3x1_ASAP7_75t_L g79 ( 
.A(n_73),
.B(n_39),
.C(n_43),
.Y(n_79)
);

NOR3xp33_ASAP7_75t_L g80 ( 
.A(n_75),
.B(n_29),
.C(n_43),
.Y(n_80)
);

NAND2x1p5_ASAP7_75t_L g81 ( 
.A(n_71),
.B(n_65),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_81),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_81),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_77),
.Y(n_84)
);

XNOR2x1_ASAP7_75t_L g85 ( 
.A(n_78),
.B(n_76),
.Y(n_85)
);

AOI21xp5_ASAP7_75t_L g86 ( 
.A1(n_82),
.A2(n_80),
.B(n_79),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_83),
.Y(n_87)
);

AOI22xp5_ASAP7_75t_L g88 ( 
.A1(n_87),
.A2(n_84),
.B1(n_85),
.B2(n_86),
.Y(n_88)
);


endmodule