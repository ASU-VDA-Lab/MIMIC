module fake_netlist_696_816_n_43 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_43);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_43;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_13;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;
wire n_14;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_6),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_4),
.B(n_10),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_9),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

OA21x2_ASAP7_75t_L g18 ( 
.A1(n_3),
.A2(n_0),
.B(n_1),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_13),
.A2(n_11),
.B(n_2),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_13),
.B(n_5),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

O2A1O1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_19),
.A2(n_6),
.B(n_7),
.C(n_14),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_16),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx4_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_24),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

NOR2xp67_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_19),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_32),
.Y(n_34)
);

NOR4xp25_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_25),
.C(n_14),
.D(n_26),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_15),
.Y(n_36)
);

NAND4xp25_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_18),
.C(n_22),
.D(n_25),
.Y(n_37)
);

NAND2x1p5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_18),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_18),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_40),
.Y(n_42)
);

OAI21xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_38),
.B(n_42),
.Y(n_43)
);


endmodule