module fake_netlist_696_3075_n_35 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_35);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_35;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_34;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_7),
.A2(n_6),
.B1(n_0),
.B2(n_1),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_0),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_15),
.B(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

NOR2x1p5_ASAP7_75t_L g21 ( 
.A(n_11),
.B(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_19),
.A2(n_22),
.B1(n_16),
.B2(n_17),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_21),
.Y(n_25)
);

INVxp67_ASAP7_75t_SL g26 ( 
.A(n_23),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_23),
.Y(n_27)
);

OAI222xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_22),
.B1(n_26),
.B2(n_21),
.C1(n_20),
.C2(n_1),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B1(n_3),
.B2(n_2),
.Y(n_29)
);

OAI211xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_18),
.B(n_4),
.C(n_2),
.Y(n_30)
);

NAND2x1p5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_5),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

OAI22x1_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_31),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_13),
.B1(n_31),
.B2(n_33),
.Y(n_35)
);


endmodule