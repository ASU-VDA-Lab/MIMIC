module fake_netlist_696_3335_n_9 (n_0, n_2, n_1, n_9);

input n_0;
input n_2;
input n_1;

output n_9;

wire n_4;
wire n_7;
wire n_3;
wire n_8;
wire n_5;
wire n_6;

INVx2_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

OA21x2_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_4),
.B(n_2),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

INVx4_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx4_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);


endmodule