module fake_netlist_696_730_n_15 (n_0, n_2, n_1, n_15);

input n_0;
input n_2;
input n_1;

output n_15;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_3;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

INVx6_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

CKINVDCx6p67_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_1),
.Y(n_8)
);

OAI221xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.C(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_7),
.B1(n_4),
.B2(n_6),
.Y(n_11)
);

INVxp67_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVxp67_ASAP7_75t_SL g13 ( 
.A(n_12),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_9),
.C2(n_11),
.Y(n_15)
);


endmodule