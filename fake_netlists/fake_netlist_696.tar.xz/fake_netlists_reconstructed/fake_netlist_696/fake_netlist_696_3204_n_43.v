module fake_netlist_696_3204_n_43 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_43);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_43;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_13;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;
wire n_14;
wire n_12;

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_12),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_3),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_5),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_SL g26 ( 
.A(n_20),
.B(n_15),
.C(n_14),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_SL g27 ( 
.A1(n_21),
.A2(n_19),
.B(n_16),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_22),
.B(n_23),
.Y(n_28)
);

OAI22xp33_ASAP7_75t_L g29 ( 
.A1(n_24),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_SL g34 ( 
.A(n_32),
.B(n_26),
.C(n_24),
.Y(n_34)
);

AOI211x1_ASAP7_75t_SL g35 ( 
.A1(n_31),
.A2(n_25),
.B(n_23),
.C(n_16),
.Y(n_35)
);

AND4x1_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_13),
.C(n_19),
.D(n_32),
.Y(n_36)
);

O2A1O1Ixp33_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_30),
.B(n_22),
.C(n_13),
.Y(n_37)
);

AOI221x1_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_18),
.B1(n_8),
.B2(n_6),
.C(n_7),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

CKINVDCx16_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_18),
.B1(n_35),
.B2(n_38),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_39),
.A2(n_18),
.B1(n_7),
.B2(n_6),
.Y(n_42)
);

OAI221xp5_ASAP7_75t_R g43 ( 
.A1(n_42),
.A2(n_9),
.B1(n_10),
.B2(n_41),
.C(n_36),
.Y(n_43)
);


endmodule