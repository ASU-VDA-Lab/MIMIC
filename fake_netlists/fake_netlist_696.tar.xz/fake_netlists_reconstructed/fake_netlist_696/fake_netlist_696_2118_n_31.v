module fake_netlist_696_2118_n_31 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_31);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_31;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_29;
wire n_13;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_SL g10 ( 
.A(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_6),
.B(n_3),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_2),
.B(n_4),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_8),
.B(n_7),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_4),
.B(n_1),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_6),
.B(n_1),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_11),
.A2(n_7),
.B1(n_10),
.B2(n_16),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_14),
.B(n_15),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_20),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_19),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_21),
.B(n_18),
.C(n_17),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_13),
.B1(n_15),
.B2(n_20),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_25),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_23),
.Y(n_29)
);

AOI31xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_19),
.A3(n_22),
.B(n_24),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B(n_29),
.Y(n_31)
);


endmodule