module fake_netlist_696_3219_n_27 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_13;
wire n_25;
wire n_19;
wire n_14;
wire n_12;

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B(n_2),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_8),
.B(n_9),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_0),
.B(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

OR2x6_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_7),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_R g23 ( 
.A(n_22),
.B(n_15),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_17),
.B1(n_16),
.B2(n_13),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_5),
.C(n_4),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);


endmodule