module fake_netlist_696_553_n_7 (n_3, n_0, n_2, n_1, n_7);

input n_3;
input n_0;
input n_2;
input n_1;

output n_7;

wire n_4;
wire n_5;
wire n_6;

OAI21x1_ASAP7_75t_L g4 ( 
.A1(n_0),
.A2(n_1),
.B(n_3),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_0),
.A2(n_1),
.B(n_2),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_5),
.Y(n_6)
);

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_6),
.Y(n_7)
);


endmodule