module fake_netlist_696_3388_n_32 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_32);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_32;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_28;
wire n_19;
wire n_11;
wire n_30;
wire n_25;
wire n_13;
wire n_14;
wire n_12;

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_13),
.B1(n_12),
.B2(n_16),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_SL g22 ( 
.A(n_20),
.B(n_18),
.C(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_23),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_24),
.B(n_15),
.Y(n_26)
);

OAI211xp5_ASAP7_75t_SL g27 ( 
.A1(n_24),
.A2(n_19),
.B(n_11),
.C(n_23),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_25),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_29),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_6),
.B1(n_7),
.B2(n_30),
.Y(n_32)
);


endmodule