module fake_netlist_696_3178_n_38 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_38);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_38;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_11;
wire n_19;
wire n_30;
wire n_25;
wire n_13;
wire n_14;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_5),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_2),
.B(n_3),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

INVx5_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_10),
.B(n_1),
.Y(n_19)
);

NOR2xp67_ASAP7_75t_SL g20 ( 
.A(n_11),
.B(n_1),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_15),
.B(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

INVx2_ASAP7_75t_SL g24 ( 
.A(n_18),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_22),
.Y(n_28)
);

OAI32xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_17),
.A3(n_23),
.B1(n_24),
.B2(n_13),
.Y(n_29)
);

AOI21xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_26),
.B(n_20),
.Y(n_30)
);

AOI211xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_16),
.B(n_19),
.C(n_24),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_28),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_30),
.Y(n_34)
);

INVxp33_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

AOI22x1_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_14),
.B1(n_18),
.B2(n_4),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_6),
.B(n_5),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_37),
.B1(n_36),
.B2(n_7),
.Y(n_38)
);


endmodule