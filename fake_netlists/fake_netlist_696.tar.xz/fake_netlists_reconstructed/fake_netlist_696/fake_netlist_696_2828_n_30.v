module fake_netlist_696_2828_n_30 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_30);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_30;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_29;
wire n_28;
wire n_19;
wire n_25;
wire n_14;

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_10),
.B(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_SL g20 ( 
.A(n_14),
.B(n_6),
.C(n_4),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_6),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_7),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

OAI322xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_23),
.A3(n_18),
.B1(n_17),
.B2(n_16),
.C1(n_19),
.C2(n_20),
.Y(n_27)
);

OR3x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_7),
.C(n_0),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI322xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_1),
.A3(n_3),
.B1(n_11),
.B2(n_12),
.C1(n_19),
.C2(n_20),
.Y(n_30)
);


endmodule