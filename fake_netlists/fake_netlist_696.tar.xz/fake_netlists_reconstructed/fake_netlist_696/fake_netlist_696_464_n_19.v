module fake_netlist_696_464_n_19 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_19);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_19;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_8;
wire n_11;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_2),
.A2(n_3),
.B1(n_4),
.B2(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_0),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_9),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_1),
.B(n_4),
.Y(n_14)
);

AND2x6_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_7),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_10),
.B2(n_13),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_10),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.C(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);


endmodule