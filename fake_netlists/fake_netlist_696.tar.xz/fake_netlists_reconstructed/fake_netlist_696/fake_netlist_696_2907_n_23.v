module fake_netlist_696_2907_n_23 (n_3, n_0, n_2, n_1, n_23);

input n_3;
input n_0;
input n_2;
input n_1;

output n_23;

wire n_21;
wire n_17;
wire n_6;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_5;
wire n_7;
wire n_8;
wire n_4;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_2),
.B(n_0),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_2),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_11),
.B1(n_8),
.B2(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_8),
.B1(n_11),
.B2(n_4),
.C1(n_14),
.C2(n_0),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_16),
.B1(n_3),
.B2(n_2),
.C(n_9),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_3),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_9),
.B(n_3),
.Y(n_21)
);

OAI22x1_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_3),
.B1(n_9),
.B2(n_19),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_3),
.B1(n_9),
.B2(n_21),
.Y(n_23)
);


endmodule