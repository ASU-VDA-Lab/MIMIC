module fake_netlist_696_3368_n_22 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_22);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_22;

wire n_21;
wire n_17;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_11;
wire n_19;
wire n_13;
wire n_14;
wire n_12;

INVx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

AND2x4_ASAP7_75t_SL g13 ( 
.A(n_8),
.B(n_5),
.Y(n_13)
);

AO22x2_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_5),
.B1(n_7),
.B2(n_6),
.Y(n_14)
);

AO31x2_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_7),
.A3(n_4),
.B(n_0),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_2),
.B(n_1),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_14),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI211xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B(n_14),
.C(n_13),
.Y(n_19)
);

NOR2x1_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_15),
.Y(n_20)
);

XOR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_4),
.Y(n_21)
);

AOI211x1_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_9),
.B(n_15),
.C(n_11),
.Y(n_22)
);


endmodule