module fake_netlist_901_4719_n_13 (n_0, n_1, n_3, n_2, n_13);

input n_0;
input n_1;
input n_3;
input n_2;

output n_13;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_2),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

NAND3xp33_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_2),
.C(n_1),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_3),
.B1(n_7),
.B2(n_9),
.C(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);


endmodule