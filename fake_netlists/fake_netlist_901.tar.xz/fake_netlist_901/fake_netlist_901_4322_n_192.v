module fake_netlist_901_4322_n_192 (n_3, n_33, n_15, n_11, n_34, n_24, n_6, n_16, n_0, n_30, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_17, n_18, n_31, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_32, n_35, n_26, n_10, n_29, n_36, n_8, n_192);

input n_3;
input n_33;
input n_15;
input n_11;
input n_34;
input n_24;
input n_6;
input n_16;
input n_0;
input n_30;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_17;
input n_18;
input n_31;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_32;
input n_35;
input n_26;
input n_10;
input n_29;
input n_36;
input n_8;

output n_192;

wire n_118;
wire n_100;
wire n_60;
wire n_104;
wire n_101;
wire n_52;
wire n_99;
wire n_127;
wire n_151;
wire n_152;
wire n_111;
wire n_154;
wire n_185;
wire n_153;
wire n_116;
wire n_164;
wire n_64;
wire n_102;
wire n_93;
wire n_157;
wire n_66;
wire n_65;
wire n_143;
wire n_88;
wire n_186;
wire n_169;
wire n_94;
wire n_182;
wire n_91;
wire n_71;
wire n_135;
wire n_174;
wire n_80;
wire n_149;
wire n_69;
wire n_83;
wire n_134;
wire n_96;
wire n_128;
wire n_117;
wire n_131;
wire n_165;
wire n_190;
wire n_51;
wire n_50;
wire n_162;
wire n_55;
wire n_123;
wire n_110;
wire n_46;
wire n_183;
wire n_144;
wire n_54;
wire n_59;
wire n_189;
wire n_177;
wire n_173;
wire n_166;
wire n_70;
wire n_40;
wire n_39;
wire n_132;
wire n_42;
wire n_41;
wire n_126;
wire n_62;
wire n_120;
wire n_148;
wire n_150;
wire n_141;
wire n_188;
wire n_44;
wire n_79;
wire n_187;
wire n_87;
wire n_142;
wire n_159;
wire n_115;
wire n_155;
wire n_184;
wire n_113;
wire n_129;
wire n_191;
wire n_172;
wire n_77;
wire n_107;
wire n_95;
wire n_53;
wire n_161;
wire n_180;
wire n_106;
wire n_137;
wire n_90;
wire n_167;
wire n_146;
wire n_81;
wire n_84;
wire n_171;
wire n_140;
wire n_61;
wire n_130;
wire n_122;
wire n_43;
wire n_138;
wire n_170;
wire n_136;
wire n_139;
wire n_48;
wire n_72;
wire n_176;
wire n_181;
wire n_133;
wire n_76;
wire n_38;
wire n_56;
wire n_175;
wire n_74;
wire n_125;
wire n_179;
wire n_103;
wire n_37;
wire n_160;
wire n_108;
wire n_75;
wire n_47;
wire n_68;
wire n_158;
wire n_86;
wire n_63;
wire n_163;
wire n_105;
wire n_114;
wire n_124;
wire n_145;
wire n_85;
wire n_112;
wire n_156;
wire n_49;
wire n_58;
wire n_109;
wire n_147;
wire n_168;
wire n_67;
wire n_57;
wire n_121;
wire n_98;
wire n_97;
wire n_119;
wire n_178;
wire n_45;
wire n_73;
wire n_92;
wire n_89;
wire n_82;
wire n_78;

INVx1_ASAP7_75t_L g37 ( 
.A(n_25),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_29),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_9),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_22),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_19),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_36),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_32),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_33),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_21),
.Y(n_45)
);

BUFx6f_ASAP7_75t_L g46 ( 
.A(n_30),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_23),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_13),
.Y(n_48)
);

CKINVDCx20_ASAP7_75t_R g49 ( 
.A(n_4),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_34),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_31),
.Y(n_51)
);

INVxp67_ASAP7_75t_L g52 ( 
.A(n_12),
.Y(n_52)
);

INVxp67_ASAP7_75t_SL g53 ( 
.A(n_5),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_15),
.Y(n_54)
);

INVxp33_ASAP7_75t_L g55 ( 
.A(n_11),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_27),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_35),
.Y(n_57)
);

CKINVDCx5p33_ASAP7_75t_R g58 ( 
.A(n_1),
.Y(n_58)
);

NOR2xp67_ASAP7_75t_L g59 ( 
.A(n_17),
.B(n_18),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_14),
.Y(n_60)
);

BUFx2_ASAP7_75t_SL g61 ( 
.A(n_26),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_10),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_20),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_24),
.Y(n_64)
);

BUFx6f_ASAP7_75t_L g65 ( 
.A(n_28),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_7),
.Y(n_66)
);

OAI22xp5_ASAP7_75t_SL g67 ( 
.A1(n_49),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_55),
.B(n_0),
.Y(n_68)
);

HB1xp67_ASAP7_75t_L g69 ( 
.A(n_52),
.Y(n_69)
);

NAND2xp5_ASAP7_75t_SL g70 ( 
.A(n_46),
.B(n_2),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_37),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_37),
.Y(n_72)
);

BUFx6f_ASAP7_75t_L g73 ( 
.A(n_46),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_40),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_42),
.Y(n_75)
);

INVx3_ASAP7_75t_L g76 ( 
.A(n_60),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_42),
.Y(n_77)
);

AOI22xp5_ASAP7_75t_L g78 ( 
.A1(n_58),
.A2(n_6),
.B1(n_4),
.B2(n_3),
.Y(n_78)
);

AND2x4_ASAP7_75t_L g79 ( 
.A(n_60),
.B(n_3),
.Y(n_79)
);

INVx3_ASAP7_75t_L g80 ( 
.A(n_44),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_44),
.Y(n_81)
);

BUFx8_ASAP7_75t_L g82 ( 
.A(n_65),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_45),
.Y(n_83)
);

NOR2xp33_ASAP7_75t_SL g84 ( 
.A(n_43),
.B(n_16),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_45),
.Y(n_85)
);

AND2x2_ASAP7_75t_L g86 ( 
.A(n_39),
.B(n_8),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_47),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_80),
.Y(n_88)
);

AND2x2_ASAP7_75t_L g89 ( 
.A(n_69),
.B(n_48),
.Y(n_89)
);

INVx4_ASAP7_75t_L g90 ( 
.A(n_79),
.Y(n_90)
);

AND3x4_ASAP7_75t_L g91 ( 
.A(n_79),
.B(n_59),
.C(n_38),
.Y(n_91)
);

AND2x4_ASAP7_75t_L g92 ( 
.A(n_79),
.B(n_48),
.Y(n_92)
);

AOI22xp5_ASAP7_75t_L g93 ( 
.A1(n_68),
.A2(n_51),
.B1(n_53),
.B2(n_66),
.Y(n_93)
);

NAND2xp5_ASAP7_75t_L g94 ( 
.A(n_71),
.B(n_38),
.Y(n_94)
);

INVx3_ASAP7_75t_L g95 ( 
.A(n_79),
.Y(n_95)
);

INVx1_ASAP7_75t_L g96 ( 
.A(n_80),
.Y(n_96)
);

NAND2xp5_ASAP7_75t_L g97 ( 
.A(n_72),
.B(n_41),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_72),
.B(n_74),
.Y(n_98)
);

AND2x2_ASAP7_75t_L g99 ( 
.A(n_75),
.B(n_62),
.Y(n_99)
);

INVx3_ASAP7_75t_L g100 ( 
.A(n_76),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_75),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_77),
.Y(n_102)
);

NAND2xp5_ASAP7_75t_L g103 ( 
.A(n_77),
.B(n_41),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_81),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_81),
.B(n_50),
.Y(n_105)
);

BUFx6f_ASAP7_75t_L g106 ( 
.A(n_73),
.Y(n_106)
);

AND2x2_ASAP7_75t_L g107 ( 
.A(n_83),
.B(n_61),
.Y(n_107)
);

OAI22xp5_ASAP7_75t_L g108 ( 
.A1(n_78),
.A2(n_57),
.B1(n_56),
.B2(n_54),
.Y(n_108)
);

AND2x4_ASAP7_75t_L g109 ( 
.A(n_85),
.B(n_54),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_88),
.Y(n_110)
);

AND2x4_ASAP7_75t_L g111 ( 
.A(n_107),
.B(n_86),
.Y(n_111)
);

INVx2_ASAP7_75t_L g112 ( 
.A(n_88),
.Y(n_112)
);

BUFx3_ASAP7_75t_L g113 ( 
.A(n_95),
.Y(n_113)
);

INVx2_ASAP7_75t_L g114 ( 
.A(n_96),
.Y(n_114)
);

CKINVDCx5p33_ASAP7_75t_R g115 ( 
.A(n_93),
.Y(n_115)
);

NAND2xp5_ASAP7_75t_L g116 ( 
.A(n_98),
.B(n_87),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_101),
.Y(n_117)
);

INVx5_ASAP7_75t_L g118 ( 
.A(n_90),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_102),
.Y(n_119)
);

INVx2_ASAP7_75t_SL g120 ( 
.A(n_92),
.Y(n_120)
);

INVx2_ASAP7_75t_L g121 ( 
.A(n_104),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_104),
.Y(n_122)
);

INVx2_ASAP7_75t_SL g123 ( 
.A(n_92),
.Y(n_123)
);

INVx1_ASAP7_75t_L g124 ( 
.A(n_95),
.Y(n_124)
);

INVx2_ASAP7_75t_L g125 ( 
.A(n_100),
.Y(n_125)
);

INVx5_ASAP7_75t_L g126 ( 
.A(n_95),
.Y(n_126)
);

INVxp67_ASAP7_75t_L g127 ( 
.A(n_89),
.Y(n_127)
);

INVx2_ASAP7_75t_L g128 ( 
.A(n_100),
.Y(n_128)
);

AND2x6_ASAP7_75t_L g129 ( 
.A(n_92),
.B(n_57),
.Y(n_129)
);

BUFx3_ASAP7_75t_L g130 ( 
.A(n_91),
.Y(n_130)
);

AOI22xp5_ASAP7_75t_L g131 ( 
.A1(n_108),
.A2(n_67),
.B1(n_84),
.B2(n_70),
.Y(n_131)
);

INVx1_ASAP7_75t_L g132 ( 
.A(n_109),
.Y(n_132)
);

AND2x4_ASAP7_75t_L g133 ( 
.A(n_111),
.B(n_99),
.Y(n_133)
);

INVx4_ASAP7_75t_L g134 ( 
.A(n_118),
.Y(n_134)
);

INVx2_ASAP7_75t_L g135 ( 
.A(n_121),
.Y(n_135)
);

INVx8_ASAP7_75t_L g136 ( 
.A(n_129),
.Y(n_136)
);

INVx1_ASAP7_75t_SL g137 ( 
.A(n_118),
.Y(n_137)
);

BUFx3_ASAP7_75t_L g138 ( 
.A(n_118),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_124),
.Y(n_139)
);

AOI22xp33_ASAP7_75t_L g140 ( 
.A1(n_130),
.A2(n_103),
.B1(n_97),
.B2(n_94),
.Y(n_140)
);

INVx3_ASAP7_75t_L g141 ( 
.A(n_118),
.Y(n_141)
);

INVx3_ASAP7_75t_L g142 ( 
.A(n_113),
.Y(n_142)
);

NOR2xp33_ASAP7_75t_L g143 ( 
.A(n_127),
.B(n_105),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_117),
.Y(n_144)
);

INVx4_ASAP7_75t_L g145 ( 
.A(n_129),
.Y(n_145)
);

INVx2_ASAP7_75t_L g146 ( 
.A(n_121),
.Y(n_146)
);

INVx2_ASAP7_75t_L g147 ( 
.A(n_112),
.Y(n_147)
);

OAI21xp33_ASAP7_75t_L g148 ( 
.A1(n_116),
.A2(n_64),
.B(n_63),
.Y(n_148)
);

AND2x6_ASAP7_75t_L g149 ( 
.A(n_132),
.B(n_63),
.Y(n_149)
);

BUFx2_ASAP7_75t_L g150 ( 
.A(n_129),
.Y(n_150)
);

CKINVDCx8_ASAP7_75t_R g151 ( 
.A(n_129),
.Y(n_151)
);

NAND2xp5_ASAP7_75t_L g152 ( 
.A(n_120),
.B(n_82),
.Y(n_152)
);

AND2x2_ASAP7_75t_L g153 ( 
.A(n_133),
.B(n_144),
.Y(n_153)
);

OA21x2_ASAP7_75t_L g154 ( 
.A1(n_148),
.A2(n_122),
.B(n_119),
.Y(n_154)
);

OAI22xp5_ASAP7_75t_L g155 ( 
.A1(n_151),
.A2(n_123),
.B1(n_120),
.B2(n_131),
.Y(n_155)
);

OAI22xp33_ASAP7_75t_L g156 ( 
.A1(n_145),
.A2(n_115),
.B1(n_123),
.B2(n_110),
.Y(n_156)
);

INVx3_ASAP7_75t_L g157 ( 
.A(n_134),
.Y(n_157)
);

INVx2_ASAP7_75t_L g158 ( 
.A(n_135),
.Y(n_158)
);

INVx2_ASAP7_75t_L g159 ( 
.A(n_146),
.Y(n_159)
);

BUFx3_ASAP7_75t_L g160 ( 
.A(n_136),
.Y(n_160)
);

AND2x2_ASAP7_75t_L g161 ( 
.A(n_143),
.B(n_114),
.Y(n_161)
);

AND2x4_ASAP7_75t_L g162 ( 
.A(n_145),
.B(n_150),
.Y(n_162)
);

OAI211xp5_ASAP7_75t_L g163 ( 
.A1(n_140),
.A2(n_126),
.B(n_128),
.C(n_125),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_147),
.Y(n_164)
);

INVx2_ASAP7_75t_L g165 ( 
.A(n_158),
.Y(n_165)
);

INVx2_ASAP7_75t_L g166 ( 
.A(n_158),
.Y(n_166)
);

AND2x2_ASAP7_75t_L g167 ( 
.A(n_161),
.B(n_153),
.Y(n_167)
);

AOI22xp33_ASAP7_75t_L g168 ( 
.A1(n_155),
.A2(n_149),
.B1(n_139),
.B2(n_141),
.Y(n_168)
);

AOI21xp33_ASAP7_75t_L g169 ( 
.A1(n_163),
.A2(n_137),
.B(n_152),
.Y(n_169)
);

OAI31xp33_ASAP7_75t_L g170 ( 
.A1(n_156),
.A2(n_138),
.A3(n_141),
.B(n_142),
.Y(n_170)
);

NOR3xp33_ASAP7_75t_L g171 ( 
.A(n_156),
.B(n_134),
.C(n_142),
.Y(n_171)
);

AND2x2_ASAP7_75t_L g172 ( 
.A(n_167),
.B(n_159),
.Y(n_172)
);

AOI22xp33_ASAP7_75t_L g173 ( 
.A1(n_168),
.A2(n_162),
.B1(n_160),
.B2(n_157),
.Y(n_173)
);

INVx2_ASAP7_75t_L g174 ( 
.A(n_165),
.Y(n_174)
);

NAND3xp33_ASAP7_75t_L g175 ( 
.A(n_170),
.B(n_164),
.C(n_154),
.Y(n_175)
);

AND2x2_ASAP7_75t_L g176 ( 
.A(n_172),
.B(n_166),
.Y(n_176)
);

AO21x2_ASAP7_75t_L g177 ( 
.A1(n_175),
.A2(n_169),
.B(n_171),
.Y(n_177)
);

INVx2_ASAP7_75t_L g178 ( 
.A(n_174),
.Y(n_178)
);

INVx2_ASAP7_75t_L g179 ( 
.A(n_178),
.Y(n_179)
);

NAND2xp5_ASAP7_75t_L g180 ( 
.A(n_176),
.B(n_173),
.Y(n_180)
);

OR2x2_ASAP7_75t_L g181 ( 
.A(n_180),
.B(n_177),
.Y(n_181)
);

NAND2xp5_ASAP7_75t_L g182 ( 
.A(n_181),
.B(n_179),
.Y(n_182)
);

HB1xp67_ASAP7_75t_L g183 ( 
.A(n_182),
.Y(n_183)
);

HB1xp67_ASAP7_75t_L g184 ( 
.A(n_183),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_184),
.Y(n_185)
);

CKINVDCx20_ASAP7_75t_R g186 ( 
.A(n_185),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_186),
.Y(n_187)
);

INVx2_ASAP7_75t_L g188 ( 
.A(n_187),
.Y(n_188)
);

INVx1_ASAP7_75t_L g189 ( 
.A(n_188),
.Y(n_189)
);

INVx2_ASAP7_75t_L g190 ( 
.A(n_189),
.Y(n_190)
);

INVx1_ASAP7_75t_L g191 ( 
.A(n_190),
.Y(n_191)
);

OR2x2_ASAP7_75t_L g192 ( 
.A(n_191),
.B(n_106),
.Y(n_192)
);


endmodule