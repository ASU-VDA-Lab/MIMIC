module fake_netlist_901_4112_n_13 (n_0, n_2, n_3, n_4, n_1, n_13);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_13;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

INVx2_ASAP7_75t_SL g5 ( 
.A(n_3),
.Y(n_5)
);

INVxp67_ASAP7_75t_SL g6 ( 
.A(n_0),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

OAI221xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_4),
.Y(n_8)
);

INVx5_ASAP7_75t_SL g9 ( 
.A(n_7),
.Y(n_9)
);

OAI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_1),
.B1(n_2),
.B2(n_7),
.C(n_8),
.Y(n_10)
);

O2A1O1Ixp33_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_9),
.B(n_7),
.C(n_1),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

A2O1A1O1Ixp25_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.B(n_8),
.C(n_10),
.D(n_6),
.Y(n_13)
);


endmodule