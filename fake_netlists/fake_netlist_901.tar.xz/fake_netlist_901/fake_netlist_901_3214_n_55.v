module fake_netlist_901_3214_n_55 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_55);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_55;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

INVx1_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_13),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_23),
.B(n_18),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_22),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_30),
.B(n_24),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_32),
.A2(n_27),
.B(n_26),
.Y(n_37)
);

INVxp67_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_28),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_18),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_41),
.Y(n_43)
);

AND2x2_ASAP7_75t_SL g44 ( 
.A(n_42),
.B(n_40),
.Y(n_44)
);

OAI21xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_39),
.B(n_33),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_29),
.B1(n_33),
.B2(n_19),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_44),
.Y(n_47)
);

NOR3xp33_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_19),
.C(n_0),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.C(n_5),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

NOR3xp33_ASAP7_75t_SL g51 ( 
.A(n_49),
.B(n_10),
.C(n_9),
.Y(n_51)
);

INVx2_ASAP7_75t_SL g52 ( 
.A(n_50),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_48),
.Y(n_53)
);

AOI21xp33_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_12),
.B(n_11),
.Y(n_54)
);

OA22x2_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_52),
.B1(n_17),
.B2(n_16),
.Y(n_55)
);


endmodule