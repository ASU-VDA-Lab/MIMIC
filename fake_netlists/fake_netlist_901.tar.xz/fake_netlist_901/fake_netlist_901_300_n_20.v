module fake_netlist_901_300_n_20 (n_0, n_1, n_3, n_2, n_20);

input n_0;
input n_1;
input n_3;
input n_2;

output n_20;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_4;
wire n_19;
wire n_12;
wire n_5;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_7)
);

O2A1O1Ixp33_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.C(n_3),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_9),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_4),
.Y(n_11)
);

AO21x2_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_6),
.B(n_1),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_3),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_8),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_12),
.B(n_13),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_13),
.B1(n_14),
.B2(n_12),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_3),
.B1(n_13),
.B2(n_14),
.C(n_11),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B1(n_14),
.B2(n_17),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.B1(n_18),
.B2(n_17),
.Y(n_20)
);


endmodule