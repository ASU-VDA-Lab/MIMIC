module fake_netlist_901_760_n_39 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_39);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_39;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_20;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

AND2x4_ASAP7_75t_L g20 ( 
.A(n_0),
.B(n_18),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_1),
.B(n_3),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_1),
.A2(n_7),
.B1(n_16),
.B2(n_8),
.Y(n_23)
);

OAI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_15),
.A2(n_2),
.B1(n_11),
.B2(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

OAI21xp33_ASAP7_75t_L g28 ( 
.A1(n_20),
.A2(n_5),
.B(n_4),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_26),
.B1(n_20),
.B2(n_21),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

AOI21xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B(n_24),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI321xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_29),
.A3(n_21),
.B1(n_25),
.B2(n_23),
.C(n_22),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_22),
.B(n_6),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_SL g36 ( 
.A(n_34),
.B(n_19),
.C(n_17),
.Y(n_36)
);

NAND3xp33_ASAP7_75t_SL g37 ( 
.A(n_35),
.B(n_19),
.C(n_9),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_10),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_37),
.B1(n_14),
.B2(n_13),
.Y(n_39)
);


endmodule