module fake_netlist_901_775_n_44 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_44);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_44;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_22;
wire n_25;
wire n_32;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

AND2x2_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_14),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

AND2x6_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_7),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_1),
.B(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_17),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_18),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_27),
.B(n_0),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_22),
.B(n_2),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_21),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_26),
.Y(n_32)
);

AOI221xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_24),
.B1(n_30),
.B2(n_20),
.C(n_23),
.Y(n_33)
);

OAI211xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_19),
.B(n_18),
.C(n_22),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_34),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_22),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

BUFx4_ASAP7_75t_SL g39 ( 
.A(n_38),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_40),
.Y(n_42)
);

CKINVDCx20_ASAP7_75t_R g43 ( 
.A(n_41),
.Y(n_43)
);

AOI222xp33_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_42),
.B1(n_37),
.B2(n_11),
.C1(n_10),
.C2(n_9),
.Y(n_44)
);


endmodule