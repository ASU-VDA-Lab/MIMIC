module fake_netlist_827_685_n_347 (n_25, n_20, n_15, n_13, n_2, n_36, n_17, n_14, n_22, n_4, n_7, n_23, n_34, n_28, n_9, n_31, n_32, n_26, n_24, n_37, n_19, n_3, n_33, n_12, n_0, n_29, n_6, n_30, n_18, n_10, n_16, n_21, n_5, n_35, n_38, n_11, n_27, n_1, n_8, n_347);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_36;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_34;
input n_28;
input n_9;
input n_31;
input n_32;
input n_26;
input n_24;
input n_37;
input n_19;
input n_3;
input n_33;
input n_12;
input n_0;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_35;
input n_38;
input n_11;
input n_27;
input n_1;
input n_8;

output n_347;

wire n_298;
wire n_114;
wire n_261;
wire n_316;
wire n_166;
wire n_240;
wire n_326;
wire n_154;
wire n_340;
wire n_195;
wire n_153;
wire n_210;
wire n_87;
wire n_95;
wire n_325;
wire n_232;
wire n_63;
wire n_110;
wire n_265;
wire n_61;
wire n_108;
wire n_48;
wire n_163;
wire n_209;
wire n_196;
wire n_47;
wire n_294;
wire n_202;
wire n_90;
wire n_76;
wire n_299;
wire n_272;
wire n_160;
wire n_338;
wire n_329;
wire n_99;
wire n_42;
wire n_155;
wire n_314;
wire n_52;
wire n_229;
wire n_51;
wire n_119;
wire n_312;
wire n_152;
wire n_131;
wire n_133;
wire n_274;
wire n_323;
wire n_223;
wire n_279;
wire n_84;
wire n_303;
wire n_270;
wire n_188;
wire n_343;
wire n_205;
wire n_65;
wire n_247;
wire n_300;
wire n_309;
wire n_281;
wire n_129;
wire n_201;
wire n_198;
wire n_169;
wire n_180;
wire n_220;
wire n_267;
wire n_208;
wire n_82;
wire n_234;
wire n_165;
wire n_141;
wire n_305;
wire n_280;
wire n_331;
wire n_221;
wire n_311;
wire n_293;
wire n_156;
wire n_126;
wire n_296;
wire n_78;
wire n_187;
wire n_96;
wire n_94;
wire n_162;
wire n_135;
wire n_324;
wire n_275;
wire n_107;
wire n_301;
wire n_288;
wire n_178;
wire n_121;
wire n_73;
wire n_211;
wire n_235;
wire n_246;
wire n_344;
wire n_175;
wire n_185;
wire n_161;
wire n_224;
wire n_179;
wire n_137;
wire n_57;
wire n_226;
wire n_284;
wire n_116;
wire n_128;
wire n_139;
wire n_115;
wire n_339;
wire n_144;
wire n_328;
wire n_283;
wire n_183;
wire n_345;
wire n_106;
wire n_149;
wire n_237;
wire n_159;
wire n_91;
wire n_233;
wire n_333;
wire n_204;
wire n_191;
wire n_317;
wire n_181;
wire n_60;
wire n_39;
wire n_260;
wire n_291;
wire n_186;
wire n_218;
wire n_69;
wire n_212;
wire n_241;
wire n_256;
wire n_134;
wire n_254;
wire n_148;
wire n_245;
wire n_193;
wire n_49;
wire n_132;
wire n_194;
wire n_219;
wire n_250;
wire n_81;
wire n_273;
wire n_80;
wire n_123;
wire n_290;
wire n_319;
wire n_167;
wire n_122;
wire n_289;
wire n_56;
wire n_59;
wire n_74;
wire n_341;
wire n_79;
wire n_177;
wire n_43;
wire n_244;
wire n_158;
wire n_171;
wire n_259;
wire n_214;
wire n_127;
wire n_295;
wire n_213;
wire n_257;
wire n_72;
wire n_266;
wire n_320;
wire n_249;
wire n_120;
wire n_327;
wire n_145;
wire n_307;
wire n_200;
wire n_170;
wire n_77;
wire n_138;
wire n_217;
wire n_253;
wire n_238;
wire n_322;
wire n_332;
wire n_62;
wire n_44;
wire n_40;
wire n_117;
wire n_104;
wire n_168;
wire n_285;
wire n_310;
wire n_176;
wire n_271;
wire n_330;
wire n_101;
wire n_336;
wire n_242;
wire n_313;
wire n_157;
wire n_83;
wire n_334;
wire n_346;
wire n_216;
wire n_150;
wire n_71;
wire n_92;
wire n_100;
wire n_124;
wire n_236;
wire n_206;
wire n_147;
wire n_268;
wire n_97;
wire n_182;
wire n_335;
wire n_130;
wire n_239;
wire n_173;
wire n_287;
wire n_318;
wire n_222;
wire n_277;
wire n_263;
wire n_269;
wire n_54;
wire n_304;
wire n_64;
wire n_278;
wire n_264;
wire n_292;
wire n_297;
wire n_184;
wire n_86;
wire n_45;
wire n_192;
wire n_230;
wire n_118;
wire n_189;
wire n_125;
wire n_255;
wire n_151;
wire n_302;
wire n_258;
wire n_207;
wire n_103;
wire n_227;
wire n_215;
wire n_199;
wire n_143;
wire n_190;
wire n_251;
wire n_136;
wire n_102;
wire n_89;
wire n_262;
wire n_70;
wire n_172;
wire n_142;
wire n_337;
wire n_109;
wire n_41;
wire n_53;
wire n_315;
wire n_58;
wire n_68;
wire n_146;
wire n_248;
wire n_105;
wire n_306;
wire n_321;
wire n_225;
wire n_85;
wire n_55;
wire n_164;
wire n_252;
wire n_75;
wire n_140;
wire n_342;
wire n_67;
wire n_66;
wire n_98;
wire n_286;
wire n_203;
wire n_50;
wire n_112;
wire n_228;
wire n_111;
wire n_93;
wire n_174;
wire n_197;
wire n_88;
wire n_243;
wire n_276;
wire n_113;
wire n_282;
wire n_231;
wire n_308;
wire n_46;

INVx1_ASAP7_75t_L g39 ( 
.A(n_18),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_26),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_24),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_15),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_36),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_32),
.Y(n_44)
);

CKINVDCx16_ASAP7_75t_R g45 ( 
.A(n_22),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_3),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_0),
.Y(n_47)
);

INVxp67_ASAP7_75t_L g48 ( 
.A(n_28),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_27),
.Y(n_49)
);

INVxp67_ASAP7_75t_SL g50 ( 
.A(n_18),
.Y(n_50)
);

INVxp67_ASAP7_75t_SL g51 ( 
.A(n_20),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_11),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_3),
.Y(n_53)
);

INVxp67_ASAP7_75t_SL g54 ( 
.A(n_10),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_30),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_15),
.Y(n_56)
);

CKINVDCx16_ASAP7_75t_R g57 ( 
.A(n_31),
.Y(n_57)
);

BUFx3_ASAP7_75t_L g58 ( 
.A(n_7),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_17),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_21),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_11),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_17),
.Y(n_62)
);

CKINVDCx20_ASAP7_75t_R g63 ( 
.A(n_45),
.Y(n_63)
);

CKINVDCx5p33_ASAP7_75t_R g64 ( 
.A(n_45),
.Y(n_64)
);

CKINVDCx5p33_ASAP7_75t_R g65 ( 
.A(n_57),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_58),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_58),
.Y(n_67)
);

BUFx10_ASAP7_75t_L g68 ( 
.A(n_41),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_58),
.Y(n_69)
);

INVx3_ASAP7_75t_L g70 ( 
.A(n_55),
.Y(n_70)
);

AOI22xp5_ASAP7_75t_L g71 ( 
.A1(n_47),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_71)
);

CKINVDCx5p33_ASAP7_75t_R g72 ( 
.A(n_57),
.Y(n_72)
);

CKINVDCx20_ASAP7_75t_R g73 ( 
.A(n_47),
.Y(n_73)
);

CKINVDCx5p33_ASAP7_75t_R g74 ( 
.A(n_52),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_40),
.Y(n_75)
);

OA21x2_ASAP7_75t_L g76 ( 
.A1(n_40),
.A2(n_49),
.B(n_43),
.Y(n_76)
);

AND2x2_ASAP7_75t_L g77 ( 
.A(n_41),
.B(n_1),
.Y(n_77)
);

NAND2xp33_ASAP7_75t_R g78 ( 
.A(n_52),
.B(n_44),
.Y(n_78)
);

CKINVDCx20_ASAP7_75t_R g79 ( 
.A(n_39),
.Y(n_79)
);

NAND2xp5_ASAP7_75t_L g80 ( 
.A(n_39),
.B(n_2),
.Y(n_80)
);

CKINVDCx5p33_ASAP7_75t_R g81 ( 
.A(n_48),
.Y(n_81)
);

CKINVDCx5p33_ASAP7_75t_R g82 ( 
.A(n_48),
.Y(n_82)
);

NOR2xp33_ASAP7_75t_L g83 ( 
.A(n_43),
.B(n_4),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_77),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_77),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_70),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_77),
.Y(n_87)
);

NAND2xp5_ASAP7_75t_L g88 ( 
.A(n_68),
.B(n_49),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_70),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_70),
.Y(n_90)
);

NOR2xp33_ASAP7_75t_L g91 ( 
.A(n_81),
.B(n_60),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_75),
.Y(n_92)
);

NAND2x1p5_ASAP7_75t_L g93 ( 
.A(n_76),
.B(n_60),
.Y(n_93)
);

AND2x4_ASAP7_75t_L g94 ( 
.A(n_75),
.B(n_42),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_70),
.Y(n_95)
);

AOI22xp5_ASAP7_75t_L g96 ( 
.A1(n_74),
.A2(n_53),
.B1(n_46),
.B2(n_42),
.Y(n_96)
);

AND2x4_ASAP7_75t_L g97 ( 
.A(n_82),
.B(n_46),
.Y(n_97)
);

AND2x2_ASAP7_75t_L g98 ( 
.A(n_68),
.B(n_50),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_66),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_76),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_66),
.Y(n_101)
);

AO22x2_ASAP7_75t_L g102 ( 
.A1(n_67),
.A2(n_54),
.B1(n_50),
.B2(n_51),
.Y(n_102)
);

NAND2xp5_ASAP7_75t_L g103 ( 
.A(n_68),
.B(n_67),
.Y(n_103)
);

INVx2_ASAP7_75t_L g104 ( 
.A(n_76),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_69),
.Y(n_105)
);

AO22x2_ASAP7_75t_L g106 ( 
.A1(n_69),
.A2(n_54),
.B1(n_51),
.B2(n_53),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_76),
.Y(n_107)
);

INVx2_ASAP7_75t_L g108 ( 
.A(n_76),
.Y(n_108)
);

INVx2_ASAP7_75t_L g109 ( 
.A(n_80),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_80),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_83),
.Y(n_111)
);

INVx2_ASAP7_75t_L g112 ( 
.A(n_83),
.Y(n_112)
);

AO22x2_ASAP7_75t_L g113 ( 
.A1(n_71),
.A2(n_61),
.B1(n_59),
.B2(n_56),
.Y(n_113)
);

OAI22xp5_ASAP7_75t_SL g114 ( 
.A1(n_79),
.A2(n_71),
.B1(n_63),
.B2(n_73),
.Y(n_114)
);

NOR2xp33_ASAP7_75t_L g115 ( 
.A(n_110),
.B(n_64),
.Y(n_115)
);

INVxp67_ASAP7_75t_SL g116 ( 
.A(n_109),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_105),
.Y(n_117)
);

NOR2xp33_ASAP7_75t_L g118 ( 
.A(n_111),
.B(n_109),
.Y(n_118)
);

O2A1O1Ixp33_ASAP7_75t_SL g119 ( 
.A1(n_107),
.A2(n_55),
.B(n_59),
.C(n_56),
.Y(n_119)
);

OAI22xp5_ASAP7_75t_L g120 ( 
.A1(n_106),
.A2(n_62),
.B1(n_61),
.B2(n_65),
.Y(n_120)
);

A2O1A1Ixp33_ASAP7_75t_SL g121 ( 
.A1(n_91),
.A2(n_55),
.B(n_62),
.C(n_68),
.Y(n_121)
);

OR2x2_ASAP7_75t_L g122 ( 
.A(n_98),
.B(n_72),
.Y(n_122)
);

NOR2xp33_ASAP7_75t_L g123 ( 
.A(n_111),
.B(n_84),
.Y(n_123)
);

AOI21xp5_ASAP7_75t_L g124 ( 
.A1(n_103),
.A2(n_78),
.B(n_19),
.Y(n_124)
);

AOI21xp5_ASAP7_75t_L g125 ( 
.A1(n_107),
.A2(n_25),
.B(n_23),
.Y(n_125)
);

INVx2_ASAP7_75t_L g126 ( 
.A(n_105),
.Y(n_126)
);

NOR2xp33_ASAP7_75t_L g127 ( 
.A(n_85),
.B(n_87),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_92),
.B(n_29),
.Y(n_128)
);

NOR2xp33_ASAP7_75t_L g129 ( 
.A(n_112),
.B(n_33),
.Y(n_129)
);

BUFx3_ASAP7_75t_L g130 ( 
.A(n_100),
.Y(n_130)
);

INVx1_ASAP7_75t_L g131 ( 
.A(n_86),
.Y(n_131)
);

NOR2xp33_ASAP7_75t_L g132 ( 
.A(n_112),
.B(n_34),
.Y(n_132)
);

A2O1A1Ixp33_ASAP7_75t_SL g133 ( 
.A1(n_100),
.A2(n_38),
.B(n_37),
.C(n_35),
.Y(n_133)
);

AOI21xp5_ASAP7_75t_L g134 ( 
.A1(n_104),
.A2(n_5),
.B(n_4),
.Y(n_134)
);

CKINVDCx8_ASAP7_75t_R g135 ( 
.A(n_97),
.Y(n_135)
);

INVx2_ASAP7_75t_L g136 ( 
.A(n_104),
.Y(n_136)
);

NAND2xp5_ASAP7_75t_SL g137 ( 
.A(n_88),
.B(n_5),
.Y(n_137)
);

AOI21xp5_ASAP7_75t_L g138 ( 
.A1(n_108),
.A2(n_7),
.B(n_6),
.Y(n_138)
);

INVx2_ASAP7_75t_L g139 ( 
.A(n_108),
.Y(n_139)
);

OAI22xp5_ASAP7_75t_L g140 ( 
.A1(n_106),
.A2(n_102),
.B1(n_113),
.B2(n_96),
.Y(n_140)
);

AOI21xp5_ASAP7_75t_L g141 ( 
.A1(n_99),
.A2(n_8),
.B(n_6),
.Y(n_141)
);

BUFx2_ASAP7_75t_L g142 ( 
.A(n_102),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_86),
.Y(n_143)
);

INVx2_ASAP7_75t_L g144 ( 
.A(n_93),
.Y(n_144)
);

NOR2xp33_ASAP7_75t_L g145 ( 
.A(n_97),
.B(n_8),
.Y(n_145)
);

INVx2_ASAP7_75t_L g146 ( 
.A(n_93),
.Y(n_146)
);

NAND2xp5_ASAP7_75t_L g147 ( 
.A(n_94),
.B(n_9),
.Y(n_147)
);

AOI21xp33_ASAP7_75t_L g148 ( 
.A1(n_115),
.A2(n_98),
.B(n_97),
.Y(n_148)
);

OAI21x1_ASAP7_75t_L g149 ( 
.A1(n_144),
.A2(n_93),
.B(n_101),
.Y(n_149)
);

OAI21x1_ASAP7_75t_L g150 ( 
.A1(n_144),
.A2(n_90),
.B(n_89),
.Y(n_150)
);

INVx5_ASAP7_75t_L g151 ( 
.A(n_130),
.Y(n_151)
);

AND2x4_ASAP7_75t_L g152 ( 
.A(n_116),
.B(n_94),
.Y(n_152)
);

OAI21x1_ASAP7_75t_L g153 ( 
.A1(n_146),
.A2(n_90),
.B(n_89),
.Y(n_153)
);

OAI21x1_ASAP7_75t_L g154 ( 
.A1(n_146),
.A2(n_95),
.B(n_106),
.Y(n_154)
);

INVx1_ASAP7_75t_L g155 ( 
.A(n_131),
.Y(n_155)
);

O2A1O1Ixp33_ASAP7_75t_SL g156 ( 
.A1(n_121),
.A2(n_106),
.B(n_102),
.C(n_94),
.Y(n_156)
);

O2A1O1Ixp33_ASAP7_75t_SL g157 ( 
.A1(n_128),
.A2(n_102),
.B(n_113),
.C(n_9),
.Y(n_157)
);

AOI21xp5_ASAP7_75t_L g158 ( 
.A1(n_136),
.A2(n_113),
.B(n_114),
.Y(n_158)
);

INVx2_ASAP7_75t_SL g159 ( 
.A(n_130),
.Y(n_159)
);

AOI21xp5_ASAP7_75t_L g160 ( 
.A1(n_136),
.A2(n_113),
.B(n_10),
.Y(n_160)
);

OAI22xp5_ASAP7_75t_L g161 ( 
.A1(n_142),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_161)
);

OAI21xp5_ASAP7_75t_L g162 ( 
.A1(n_139),
.A2(n_118),
.B(n_131),
.Y(n_162)
);

INVx2_ASAP7_75t_L g163 ( 
.A(n_139),
.Y(n_163)
);

OAI21x1_ASAP7_75t_L g164 ( 
.A1(n_124),
.A2(n_13),
.B(n_12),
.Y(n_164)
);

OAI21x1_ASAP7_75t_L g165 ( 
.A1(n_125),
.A2(n_128),
.B(n_117),
.Y(n_165)
);

OAI21x1_ASAP7_75t_L g166 ( 
.A1(n_117),
.A2(n_16),
.B(n_14),
.Y(n_166)
);

BUFx6f_ASAP7_75t_L g167 ( 
.A(n_126),
.Y(n_167)
);

NOR2x1_ASAP7_75t_SL g168 ( 
.A(n_120),
.B(n_16),
.Y(n_168)
);

OAI21x1_ASAP7_75t_L g169 ( 
.A1(n_126),
.A2(n_138),
.B(n_134),
.Y(n_169)
);

AOI21xp33_ASAP7_75t_L g170 ( 
.A1(n_122),
.A2(n_142),
.B(n_123),
.Y(n_170)
);

AOI22xp33_ASAP7_75t_L g171 ( 
.A1(n_140),
.A2(n_120),
.B1(n_145),
.B2(n_127),
.Y(n_171)
);

AO31x2_ASAP7_75t_L g172 ( 
.A1(n_140),
.A2(n_132),
.A3(n_129),
.B(n_147),
.Y(n_172)
);

OR2x2_ASAP7_75t_L g173 ( 
.A(n_122),
.B(n_147),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_155),
.Y(n_174)
);

AO31x2_ASAP7_75t_L g175 ( 
.A1(n_168),
.A2(n_141),
.A3(n_143),
.B(n_119),
.Y(n_175)
);

INVx2_ASAP7_75t_L g176 ( 
.A(n_163),
.Y(n_176)
);

OR2x6_ASAP7_75t_L g177 ( 
.A(n_152),
.B(n_137),
.Y(n_177)
);

AO31x2_ASAP7_75t_L g178 ( 
.A1(n_168),
.A2(n_143),
.A3(n_133),
.B(n_135),
.Y(n_178)
);

INVx2_ASAP7_75t_L g179 ( 
.A(n_163),
.Y(n_179)
);

NAND2xp5_ASAP7_75t_SL g180 ( 
.A(n_151),
.B(n_135),
.Y(n_180)
);

INVx1_ASAP7_75t_L g181 ( 
.A(n_155),
.Y(n_181)
);

CKINVDCx16_ASAP7_75t_R g182 ( 
.A(n_173),
.Y(n_182)
);

NAND2xp5_ASAP7_75t_L g183 ( 
.A(n_173),
.B(n_152),
.Y(n_183)
);

NOR2xp33_ASAP7_75t_R g184 ( 
.A(n_151),
.B(n_159),
.Y(n_184)
);

INVx5_ASAP7_75t_L g185 ( 
.A(n_151),
.Y(n_185)
);

INVx1_ASAP7_75t_L g186 ( 
.A(n_162),
.Y(n_186)
);

INVx2_ASAP7_75t_L g187 ( 
.A(n_167),
.Y(n_187)
);

NAND2xp5_ASAP7_75t_L g188 ( 
.A(n_152),
.B(n_171),
.Y(n_188)
);

OR2x2_ASAP7_75t_L g189 ( 
.A(n_158),
.B(n_152),
.Y(n_189)
);

INVxp67_ASAP7_75t_L g190 ( 
.A(n_183),
.Y(n_190)
);

AOI211xp5_ASAP7_75t_L g191 ( 
.A1(n_188),
.A2(n_148),
.B(n_170),
.C(n_157),
.Y(n_191)
);

HB1xp67_ASAP7_75t_L g192 ( 
.A(n_182),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_174),
.Y(n_193)
);

AOI21xp5_ASAP7_75t_L g194 ( 
.A1(n_186),
.A2(n_149),
.B(n_162),
.Y(n_194)
);

INVx2_ASAP7_75t_L g195 ( 
.A(n_176),
.Y(n_195)
);

HB1xp67_ASAP7_75t_L g196 ( 
.A(n_185),
.Y(n_196)
);

NOR2xp67_ASAP7_75t_L g197 ( 
.A(n_185),
.B(n_151),
.Y(n_197)
);

NAND2xp5_ASAP7_75t_L g198 ( 
.A(n_174),
.B(n_172),
.Y(n_198)
);

HB1xp67_ASAP7_75t_L g199 ( 
.A(n_185),
.Y(n_199)
);

AO21x2_ASAP7_75t_L g200 ( 
.A1(n_186),
.A2(n_166),
.B(n_169),
.Y(n_200)
);

INVx1_ASAP7_75t_L g201 ( 
.A(n_181),
.Y(n_201)
);

INVx2_ASAP7_75t_SL g202 ( 
.A(n_185),
.Y(n_202)
);

AOI22xp33_ASAP7_75t_L g203 ( 
.A1(n_177),
.A2(n_160),
.B1(n_161),
.B2(n_167),
.Y(n_203)
);

INVx2_ASAP7_75t_L g204 ( 
.A(n_195),
.Y(n_204)
);

AND2x2_ASAP7_75t_L g205 ( 
.A(n_193),
.B(n_182),
.Y(n_205)
);

AND2x2_ASAP7_75t_L g206 ( 
.A(n_193),
.B(n_201),
.Y(n_206)
);

INVx2_ASAP7_75t_L g207 ( 
.A(n_195),
.Y(n_207)
);

AND2x4_ASAP7_75t_L g208 ( 
.A(n_202),
.B(n_181),
.Y(n_208)
);

OR2x6_ASAP7_75t_SL g209 ( 
.A(n_198),
.B(n_189),
.Y(n_209)
);

INVx1_ASAP7_75t_L g210 ( 
.A(n_201),
.Y(n_210)
);

AND2x2_ASAP7_75t_L g211 ( 
.A(n_195),
.B(n_176),
.Y(n_211)
);

HB1xp67_ASAP7_75t_L g212 ( 
.A(n_192),
.Y(n_212)
);

AND2x2_ASAP7_75t_L g213 ( 
.A(n_190),
.B(n_179),
.Y(n_213)
);

INVx2_ASAP7_75t_L g214 ( 
.A(n_200),
.Y(n_214)
);

BUFx2_ASAP7_75t_L g215 ( 
.A(n_196),
.Y(n_215)
);

INVx1_ASAP7_75t_L g216 ( 
.A(n_198),
.Y(n_216)
);

INVx1_ASAP7_75t_L g217 ( 
.A(n_200),
.Y(n_217)
);

INVx2_ASAP7_75t_L g218 ( 
.A(n_200),
.Y(n_218)
);

AND2x4_ASAP7_75t_SL g219 ( 
.A(n_196),
.B(n_179),
.Y(n_219)
);

NAND2xp5_ASAP7_75t_L g220 ( 
.A(n_190),
.B(n_189),
.Y(n_220)
);

INVx2_ASAP7_75t_L g221 ( 
.A(n_200),
.Y(n_221)
);

INVx1_ASAP7_75t_L g222 ( 
.A(n_210),
.Y(n_222)
);

OR2x2_ASAP7_75t_L g223 ( 
.A(n_216),
.B(n_194),
.Y(n_223)
);

INVx2_ASAP7_75t_L g224 ( 
.A(n_214),
.Y(n_224)
);

INVx1_ASAP7_75t_L g225 ( 
.A(n_210),
.Y(n_225)
);

NAND2xp5_ASAP7_75t_SL g226 ( 
.A(n_219),
.B(n_215),
.Y(n_226)
);

INVx2_ASAP7_75t_L g227 ( 
.A(n_214),
.Y(n_227)
);

INVx1_ASAP7_75t_L g228 ( 
.A(n_216),
.Y(n_228)
);

HB1xp67_ASAP7_75t_L g229 ( 
.A(n_215),
.Y(n_229)
);

INVx1_ASAP7_75t_L g230 ( 
.A(n_206),
.Y(n_230)
);

INVx3_ASAP7_75t_L g231 ( 
.A(n_214),
.Y(n_231)
);

INVx1_ASAP7_75t_L g232 ( 
.A(n_206),
.Y(n_232)
);

OR2x2_ASAP7_75t_L g233 ( 
.A(n_217),
.B(n_194),
.Y(n_233)
);

BUFx3_ASAP7_75t_L g234 ( 
.A(n_219),
.Y(n_234)
);

INVx2_ASAP7_75t_L g235 ( 
.A(n_221),
.Y(n_235)
);

AND2x4_ASAP7_75t_L g236 ( 
.A(n_218),
.B(n_202),
.Y(n_236)
);

AND2x2_ASAP7_75t_L g237 ( 
.A(n_217),
.B(n_166),
.Y(n_237)
);

INVxp67_ASAP7_75t_L g238 ( 
.A(n_209),
.Y(n_238)
);

AND2x2_ASAP7_75t_L g239 ( 
.A(n_204),
.B(n_207),
.Y(n_239)
);

INVxp67_ASAP7_75t_SL g240 ( 
.A(n_204),
.Y(n_240)
);

INVx2_ASAP7_75t_L g241 ( 
.A(n_221),
.Y(n_241)
);

AO21x2_ASAP7_75t_L g242 ( 
.A1(n_221),
.A2(n_154),
.B(n_164),
.Y(n_242)
);

INVx2_ASAP7_75t_L g243 ( 
.A(n_218),
.Y(n_243)
);

NAND2xp5_ASAP7_75t_L g244 ( 
.A(n_220),
.B(n_191),
.Y(n_244)
);

OAI33xp33_ASAP7_75t_L g245 ( 
.A1(n_209),
.A2(n_180),
.A3(n_191),
.B1(n_156),
.B2(n_164),
.B3(n_175),
.Y(n_245)
);

INVx2_ASAP7_75t_L g246 ( 
.A(n_207),
.Y(n_246)
);

INVx1_ASAP7_75t_L g247 ( 
.A(n_222),
.Y(n_247)
);

INVxp67_ASAP7_75t_L g248 ( 
.A(n_229),
.Y(n_248)
);

INVx1_ASAP7_75t_L g249 ( 
.A(n_222),
.Y(n_249)
);

INVx1_ASAP7_75t_L g250 ( 
.A(n_225),
.Y(n_250)
);

OR2x2_ASAP7_75t_L g251 ( 
.A(n_230),
.B(n_232),
.Y(n_251)
);

OAI22xp5_ASAP7_75t_L g252 ( 
.A1(n_238),
.A2(n_219),
.B1(n_199),
.B2(n_208),
.Y(n_252)
);

NAND2xp5_ASAP7_75t_L g253 ( 
.A(n_230),
.B(n_213),
.Y(n_253)
);

INVx1_ASAP7_75t_L g254 ( 
.A(n_225),
.Y(n_254)
);

INVx1_ASAP7_75t_L g255 ( 
.A(n_232),
.Y(n_255)
);

INVx1_ASAP7_75t_L g256 ( 
.A(n_228),
.Y(n_256)
);

INVx1_ASAP7_75t_L g257 ( 
.A(n_228),
.Y(n_257)
);

AOI21xp33_ASAP7_75t_L g258 ( 
.A1(n_244),
.A2(n_212),
.B(n_199),
.Y(n_258)
);

AOI32xp33_ASAP7_75t_L g259 ( 
.A1(n_234),
.A2(n_205),
.A3(n_208),
.B1(n_213),
.B2(n_202),
.Y(n_259)
);

AOI22xp5_ASAP7_75t_L g260 ( 
.A1(n_244),
.A2(n_238),
.B1(n_205),
.B2(n_208),
.Y(n_260)
);

AOI33xp33_ASAP7_75t_L g261 ( 
.A1(n_237),
.A2(n_203),
.A3(n_208),
.B1(n_211),
.B2(n_187),
.B3(n_175),
.Y(n_261)
);

NAND4xp25_ASAP7_75t_SL g262 ( 
.A(n_226),
.B(n_211),
.C(n_197),
.D(n_184),
.Y(n_262)
);

NOR2xp67_ASAP7_75t_SL g263 ( 
.A(n_234),
.B(n_185),
.Y(n_263)
);

INVx2_ASAP7_75t_L g264 ( 
.A(n_224),
.Y(n_264)
);

A2O1A1Ixp33_ASAP7_75t_L g265 ( 
.A1(n_234),
.A2(n_197),
.B(n_154),
.C(n_185),
.Y(n_265)
);

INVx1_ASAP7_75t_L g266 ( 
.A(n_229),
.Y(n_266)
);

INVx1_ASAP7_75t_L g267 ( 
.A(n_240),
.Y(n_267)
);

NAND2xp5_ASAP7_75t_L g268 ( 
.A(n_239),
.B(n_172),
.Y(n_268)
);

OAI22xp5_ASAP7_75t_L g269 ( 
.A1(n_234),
.A2(n_177),
.B1(n_187),
.B2(n_167),
.Y(n_269)
);

OAI22xp5_ASAP7_75t_L g270 ( 
.A1(n_226),
.A2(n_240),
.B1(n_236),
.B2(n_223),
.Y(n_270)
);

OAI21xp5_ASAP7_75t_L g271 ( 
.A1(n_237),
.A2(n_169),
.B(n_177),
.Y(n_271)
);

OAI22xp5_ASAP7_75t_L g272 ( 
.A1(n_236),
.A2(n_177),
.B1(n_167),
.B2(n_151),
.Y(n_272)
);

AOI21xp33_ASAP7_75t_L g273 ( 
.A1(n_237),
.A2(n_177),
.B(n_165),
.Y(n_273)
);

AND2x2_ASAP7_75t_L g274 ( 
.A(n_236),
.B(n_175),
.Y(n_274)
);

OAI21xp33_ASAP7_75t_L g275 ( 
.A1(n_233),
.A2(n_165),
.B(n_159),
.Y(n_275)
);

CKINVDCx16_ASAP7_75t_R g276 ( 
.A(n_252),
.Y(n_276)
);

OR2x2_ASAP7_75t_L g277 ( 
.A(n_266),
.B(n_223),
.Y(n_277)
);

INVx1_ASAP7_75t_L g278 ( 
.A(n_247),
.Y(n_278)
);

INVx1_ASAP7_75t_L g279 ( 
.A(n_249),
.Y(n_279)
);

NOR2x1_ASAP7_75t_L g280 ( 
.A(n_262),
.B(n_236),
.Y(n_280)
);

INVx1_ASAP7_75t_L g281 ( 
.A(n_250),
.Y(n_281)
);

INVxp67_ASAP7_75t_L g282 ( 
.A(n_263),
.Y(n_282)
);

INVx2_ASAP7_75t_SL g283 ( 
.A(n_267),
.Y(n_283)
);

AND2x2_ASAP7_75t_L g284 ( 
.A(n_274),
.B(n_231),
.Y(n_284)
);

NAND3xp33_ASAP7_75t_L g285 ( 
.A(n_248),
.B(n_233),
.C(n_223),
.Y(n_285)
);

AND2x2_ASAP7_75t_L g286 ( 
.A(n_274),
.B(n_231),
.Y(n_286)
);

INVx1_ASAP7_75t_SL g287 ( 
.A(n_251),
.Y(n_287)
);

NAND2xp5_ASAP7_75t_L g288 ( 
.A(n_255),
.B(n_239),
.Y(n_288)
);

INVxp67_ASAP7_75t_L g289 ( 
.A(n_260),
.Y(n_289)
);

INVx1_ASAP7_75t_L g290 ( 
.A(n_254),
.Y(n_290)
);

INVx2_ASAP7_75t_L g291 ( 
.A(n_264),
.Y(n_291)
);

INVxp33_ASAP7_75t_L g292 ( 
.A(n_270),
.Y(n_292)
);

INVx1_ASAP7_75t_L g293 ( 
.A(n_256),
.Y(n_293)
);

INVx1_ASAP7_75t_SL g294 ( 
.A(n_253),
.Y(n_294)
);

NAND2xp5_ASAP7_75t_L g295 ( 
.A(n_257),
.B(n_239),
.Y(n_295)
);

NAND2xp5_ASAP7_75t_L g296 ( 
.A(n_248),
.B(n_236),
.Y(n_296)
);

AND2x4_ASAP7_75t_L g297 ( 
.A(n_271),
.B(n_231),
.Y(n_297)
);

NAND2xp5_ASAP7_75t_L g298 ( 
.A(n_268),
.B(n_231),
.Y(n_298)
);

INVx1_ASAP7_75t_L g299 ( 
.A(n_264),
.Y(n_299)
);

NAND2xp5_ASAP7_75t_L g300 ( 
.A(n_258),
.B(n_231),
.Y(n_300)
);

NAND2xp5_ASAP7_75t_L g301 ( 
.A(n_259),
.B(n_233),
.Y(n_301)
);

NAND4xp25_ASAP7_75t_L g302 ( 
.A(n_289),
.B(n_261),
.C(n_265),
.D(n_273),
.Y(n_302)
);

NOR3xp33_ASAP7_75t_L g303 ( 
.A(n_276),
.B(n_245),
.C(n_261),
.Y(n_303)
);

AOI221xp5_ASAP7_75t_L g304 ( 
.A1(n_292),
.A2(n_245),
.B1(n_265),
.B2(n_275),
.C(n_269),
.Y(n_304)
);

AOI221xp5_ASAP7_75t_L g305 ( 
.A1(n_292),
.A2(n_272),
.B1(n_235),
.B2(n_224),
.C(n_227),
.Y(n_305)
);

NOR2xp33_ASAP7_75t_L g306 ( 
.A(n_287),
.B(n_224),
.Y(n_306)
);

AOI222xp33_ASAP7_75t_L g307 ( 
.A1(n_301),
.A2(n_235),
.B1(n_227),
.B2(n_224),
.C1(n_241),
.C2(n_243),
.Y(n_307)
);

AOI221xp5_ASAP7_75t_L g308 ( 
.A1(n_294),
.A2(n_285),
.B1(n_290),
.B2(n_279),
.C(n_278),
.Y(n_308)
);

OAI321xp33_ASAP7_75t_L g309 ( 
.A1(n_282),
.A2(n_235),
.A3(n_227),
.B1(n_241),
.B2(n_243),
.C(n_246),
.Y(n_309)
);

OAI321xp33_ASAP7_75t_L g310 ( 
.A1(n_300),
.A2(n_235),
.A3(n_227),
.B1(n_241),
.B2(n_243),
.C(n_246),
.Y(n_310)
);

OAI211xp5_ASAP7_75t_L g311 ( 
.A1(n_280),
.A2(n_243),
.B(n_246),
.C(n_151),
.Y(n_311)
);

AOI211xp5_ASAP7_75t_L g312 ( 
.A1(n_296),
.A2(n_246),
.B(n_153),
.C(n_150),
.Y(n_312)
);

NAND2xp5_ASAP7_75t_L g313 ( 
.A(n_277),
.B(n_242),
.Y(n_313)
);

BUFx2_ASAP7_75t_L g314 ( 
.A(n_283),
.Y(n_314)
);

NOR2xp33_ASAP7_75t_SL g315 ( 
.A(n_283),
.B(n_167),
.Y(n_315)
);

INVxp67_ASAP7_75t_L g316 ( 
.A(n_277),
.Y(n_316)
);

INVxp33_ASAP7_75t_SL g317 ( 
.A(n_288),
.Y(n_317)
);

NOR2x1_ASAP7_75t_L g318 ( 
.A(n_297),
.B(n_242),
.Y(n_318)
);

AOI221xp5_ASAP7_75t_L g319 ( 
.A1(n_278),
.A2(n_242),
.B1(n_175),
.B2(n_172),
.C(n_178),
.Y(n_319)
);

AOI211xp5_ASAP7_75t_L g320 ( 
.A1(n_297),
.A2(n_153),
.B(n_150),
.C(n_149),
.Y(n_320)
);

OAI221xp5_ASAP7_75t_L g321 ( 
.A1(n_303),
.A2(n_293),
.B1(n_281),
.B2(n_298),
.C(n_295),
.Y(n_321)
);

AOI21xp5_ASAP7_75t_L g322 ( 
.A1(n_311),
.A2(n_297),
.B(n_299),
.Y(n_322)
);

AOI22xp5_ASAP7_75t_L g323 ( 
.A1(n_317),
.A2(n_284),
.B1(n_286),
.B2(n_281),
.Y(n_323)
);

NAND2xp5_ASAP7_75t_SL g324 ( 
.A(n_308),
.B(n_299),
.Y(n_324)
);

NAND2xp5_ASAP7_75t_L g325 ( 
.A(n_316),
.B(n_293),
.Y(n_325)
);

NAND2xp5_ASAP7_75t_SL g326 ( 
.A(n_314),
.B(n_307),
.Y(n_326)
);

AOI22xp33_ASAP7_75t_L g327 ( 
.A1(n_302),
.A2(n_284),
.B1(n_286),
.B2(n_291),
.Y(n_327)
);

NOR3xp33_ASAP7_75t_L g328 ( 
.A(n_304),
.B(n_291),
.C(n_175),
.Y(n_328)
);

AOI221x1_ASAP7_75t_L g329 ( 
.A1(n_313),
.A2(n_306),
.B1(n_309),
.B2(n_310),
.C(n_316),
.Y(n_329)
);

AOI22xp33_ASAP7_75t_L g330 ( 
.A1(n_305),
.A2(n_318),
.B1(n_319),
.B2(n_315),
.Y(n_330)
);

AOI322xp5_ASAP7_75t_L g331 ( 
.A1(n_312),
.A2(n_172),
.A3(n_178),
.B1(n_242),
.B2(n_303),
.C1(n_276),
.C2(n_316),
.Y(n_331)
);

CKINVDCx20_ASAP7_75t_R g332 ( 
.A(n_323),
.Y(n_332)
);

HB1xp67_ASAP7_75t_L g333 ( 
.A(n_325),
.Y(n_333)
);

INVx1_ASAP7_75t_L g334 ( 
.A(n_324),
.Y(n_334)
);

INVx2_ASAP7_75t_SL g335 ( 
.A(n_326),
.Y(n_335)
);

CKINVDCx16_ASAP7_75t_R g336 ( 
.A(n_327),
.Y(n_336)
);

NAND2xp5_ASAP7_75t_L g337 ( 
.A(n_331),
.B(n_320),
.Y(n_337)
);

CKINVDCx5p33_ASAP7_75t_R g338 ( 
.A(n_330),
.Y(n_338)
);

HB1xp67_ASAP7_75t_L g339 ( 
.A(n_333),
.Y(n_339)
);

OAI221xp5_ASAP7_75t_L g340 ( 
.A1(n_335),
.A2(n_338),
.B1(n_334),
.B2(n_337),
.C(n_321),
.Y(n_340)
);

OAI22xp5_ASAP7_75t_L g341 ( 
.A1(n_336),
.A2(n_322),
.B1(n_328),
.B2(n_329),
.Y(n_341)
);

INVx1_ASAP7_75t_L g342 ( 
.A(n_334),
.Y(n_342)
);

HB1xp67_ASAP7_75t_L g343 ( 
.A(n_339),
.Y(n_343)
);

OAI22xp33_ASAP7_75t_L g344 ( 
.A1(n_341),
.A2(n_335),
.B1(n_338),
.B2(n_332),
.Y(n_344)
);

INVx1_ASAP7_75t_L g345 ( 
.A(n_343),
.Y(n_345)
);

AOI22xp33_ASAP7_75t_L g346 ( 
.A1(n_345),
.A2(n_344),
.B1(n_340),
.B2(n_342),
.Y(n_346)
);

AOI21xp5_ASAP7_75t_L g347 ( 
.A1(n_346),
.A2(n_242),
.B(n_172),
.Y(n_347)
);


endmodule