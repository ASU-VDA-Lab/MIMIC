module fake_netlist_827_2093_n_16 (n_2, n_0, n_3, n_1, n_16);

input n_2;
input n_0;
input n_3;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_0),
.Y(n_4)
);

NOR2x1p5_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_2),
.Y(n_5)
);

BUFx3_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AOI21xp33_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_6),
.B(n_7),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_6),
.Y(n_11)
);

OAI221xp5_ASAP7_75t_SL g12 ( 
.A1(n_10),
.A2(n_9),
.B1(n_7),
.B2(n_1),
.C(n_2),
.Y(n_12)
);

NAND4xp25_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_1),
.C(n_3),
.D(n_4),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_3),
.B(n_14),
.Y(n_16)
);


endmodule