module fake_netlist_827_258_n_40 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_40);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_40;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

INVx1_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_3),
.B(n_0),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_5),
.B(n_12),
.Y(n_22)
);

AND2x2_ASAP7_75t_SL g23 ( 
.A(n_7),
.B(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_6),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_14),
.Y(n_25)
);

OAI22x1_ASAP7_75t_L g26 ( 
.A1(n_18),
.A2(n_13),
.B1(n_2),
.B2(n_0),
.Y(n_26)
);

OAI21x1_ASAP7_75t_SL g27 ( 
.A1(n_18),
.A2(n_13),
.B(n_2),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_25),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_28),
.B(n_19),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_28),
.B(n_20),
.Y(n_30)
);

AO21x2_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_27),
.B(n_22),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_24),
.Y(n_32)
);

OAI21xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_23),
.B(n_21),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_23),
.B1(n_26),
.B2(n_21),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_34),
.B1(n_31),
.B2(n_22),
.C(n_23),
.Y(n_35)
);

OAI221xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.C(n_1),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_36),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_35),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.B1(n_9),
.B2(n_8),
.Y(n_40)
);


endmodule