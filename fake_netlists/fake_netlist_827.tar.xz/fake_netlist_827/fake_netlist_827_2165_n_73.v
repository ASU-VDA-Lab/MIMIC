module fake_netlist_827_2165_n_73 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_73);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_73;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_57;
wire n_70;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_34;
wire n_60;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_23;
wire n_32;
wire n_31;
wire n_58;
wire n_68;
wire n_26;
wire n_72;
wire n_24;
wire n_71;
wire n_43;
wire n_37;
wire n_54;
wire n_42;
wire n_44;
wire n_69;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_67;
wire n_45;
wire n_46;
wire n_51;

AND2x4_ASAP7_75t_L g21 ( 
.A(n_7),
.B(n_1),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_14),
.B(n_6),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_5),
.B(n_3),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_9),
.B(n_10),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_20),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_12),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_15),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_0),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_8),
.B(n_0),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_18),
.B(n_4),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_28),
.B(n_32),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_25),
.B(n_16),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_28),
.B(n_17),
.Y(n_37)
);

INVx5_ASAP7_75t_L g38 ( 
.A(n_21),
.Y(n_38)
);

AO22x1_ASAP7_75t_L g39 ( 
.A1(n_32),
.A2(n_22),
.B1(n_21),
.B2(n_33),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_21),
.B(n_17),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_25),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_27),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_31),
.B(n_19),
.Y(n_43)
);

BUFx3_ASAP7_75t_L g44 ( 
.A(n_26),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_36),
.A2(n_30),
.B1(n_33),
.B2(n_22),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_38),
.B(n_22),
.Y(n_46)
);

CKINVDCx6p67_ASAP7_75t_R g47 ( 
.A(n_40),
.Y(n_47)
);

NAND2xp33_ASAP7_75t_SL g48 ( 
.A(n_35),
.B(n_29),
.Y(n_48)
);

CKINVDCx8_ASAP7_75t_R g49 ( 
.A(n_36),
.Y(n_49)
);

AOI21xp5_ASAP7_75t_L g50 ( 
.A1(n_39),
.A2(n_34),
.B(n_27),
.Y(n_50)
);

INVx5_ASAP7_75t_SL g51 ( 
.A(n_36),
.Y(n_51)
);

INVxp67_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

AOI22xp33_ASAP7_75t_SL g54 ( 
.A1(n_51),
.A2(n_37),
.B1(n_38),
.B2(n_29),
.Y(n_54)
);

AO21x2_ASAP7_75t_L g55 ( 
.A1(n_50),
.A2(n_40),
.B(n_43),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_55),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

AOI21xp5_ASAP7_75t_L g59 ( 
.A1(n_55),
.A2(n_50),
.B(n_46),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_SL g60 ( 
.A(n_53),
.B(n_46),
.Y(n_60)
);

NOR4xp25_ASAP7_75t_SL g61 ( 
.A(n_56),
.B(n_47),
.C(n_41),
.D(n_45),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_57),
.Y(n_62)
);

NOR2x1_ASAP7_75t_L g63 ( 
.A(n_60),
.B(n_24),
.Y(n_63)
);

AND2x2_ASAP7_75t_L g64 ( 
.A(n_58),
.B(n_61),
.Y(n_64)
);

NOR4xp25_ASAP7_75t_SL g65 ( 
.A(n_59),
.B(n_54),
.C(n_38),
.D(n_52),
.Y(n_65)
);

OAI211xp5_ASAP7_75t_L g66 ( 
.A1(n_63),
.A2(n_42),
.B(n_30),
.C(n_38),
.Y(n_66)
);

AOI32xp33_ASAP7_75t_L g67 ( 
.A1(n_64),
.A2(n_23),
.A3(n_26),
.B1(n_42),
.B2(n_44),
.Y(n_67)
);

AND2x4_ASAP7_75t_L g68 ( 
.A(n_62),
.B(n_20),
.Y(n_68)
);

CKINVDCx5p33_ASAP7_75t_R g69 ( 
.A(n_68),
.Y(n_69)
);

AOI31xp33_ASAP7_75t_L g70 ( 
.A1(n_66),
.A2(n_62),
.A3(n_65),
.B(n_13),
.Y(n_70)
);

AND2x2_ASAP7_75t_L g71 ( 
.A(n_67),
.B(n_62),
.Y(n_71)
);

AND2x4_ASAP7_75t_L g72 ( 
.A(n_71),
.B(n_69),
.Y(n_72)
);

AOI21xp5_ASAP7_75t_L g73 ( 
.A1(n_72),
.A2(n_70),
.B(n_71),
.Y(n_73)
);


endmodule