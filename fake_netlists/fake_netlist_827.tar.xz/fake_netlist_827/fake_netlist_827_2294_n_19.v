module fake_netlist_827_2294_n_19 (n_2, n_0, n_1, n_19);

input n_2;
input n_0;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_4;
wire n_7;
wire n_9;
wire n_3;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_5;
wire n_11;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g3 ( 
.A(n_1),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_2),
.B(n_0),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_2),
.Y(n_5)
);

O2A1O1Ixp33_ASAP7_75t_SL g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

INVxp67_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_5),
.B(n_2),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

OAI222xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_0),
.B1(n_5),
.B2(n_6),
.C1(n_9),
.C2(n_11),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_13),
.Y(n_16)
);

OAI321xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_6),
.A3(n_12),
.B1(n_14),
.B2(n_10),
.C(n_4),
.Y(n_17)
);

NAND2x1p5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_12),
.Y(n_18)
);

AOI31xp67_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_14),
.A3(n_15),
.B(n_17),
.Y(n_19)
);


endmodule