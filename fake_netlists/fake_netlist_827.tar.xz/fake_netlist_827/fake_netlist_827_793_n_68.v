module fake_netlist_827_793_n_68 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_68);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_68;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_23;
wire n_44;
wire n_34;
wire n_28;
wire n_39;
wire n_53;
wire n_40;
wire n_31;
wire n_32;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_67;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_3),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_6),
.B(n_7),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_13),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_17),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

BUFx12f_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_9),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_22),
.B(n_13),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_21),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_28),
.B(n_14),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_29),
.B(n_21),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_19),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_24),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_22),
.Y(n_39)
);

AO21x2_ASAP7_75t_L g40 ( 
.A1(n_23),
.A2(n_18),
.B(n_1),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_23),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_31),
.B(n_25),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_36),
.B(n_25),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_38),
.B(n_20),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_37),
.A2(n_24),
.B1(n_27),
.B2(n_18),
.Y(n_45)
);

INVx3_ASAP7_75t_L g46 ( 
.A(n_39),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_31),
.A2(n_27),
.B1(n_4),
.B2(n_2),
.Y(n_47)
);

AOI21x1_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_39),
.B(n_33),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_36),
.B1(n_32),
.B2(n_35),
.C(n_34),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_43),
.B(n_38),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_42),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_45),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

XNOR2x2_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_47),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_57),
.Y(n_59)
);

OAI22xp33_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_48),
.B1(n_41),
.B2(n_40),
.Y(n_60)
);

NOR2xp33_ASAP7_75t_L g61 ( 
.A(n_56),
.B(n_40),
.Y(n_61)
);

NOR3xp33_ASAP7_75t_SL g62 ( 
.A(n_61),
.B(n_56),
.C(n_40),
.Y(n_62)
);

OR2x2_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_40),
.Y(n_63)
);

NOR3xp33_ASAP7_75t_L g64 ( 
.A(n_61),
.B(n_41),
.C(n_10),
.Y(n_64)
);

NAND2x1p5_ASAP7_75t_L g65 ( 
.A(n_59),
.B(n_41),
.Y(n_65)
);

INVx1_ASAP7_75t_SL g66 ( 
.A(n_65),
.Y(n_66)
);

NAND2x2_ASAP7_75t_L g67 ( 
.A(n_63),
.B(n_60),
.Y(n_67)
);

AOI221xp5_ASAP7_75t_L g68 ( 
.A1(n_66),
.A2(n_41),
.B1(n_62),
.B2(n_64),
.C(n_67),
.Y(n_68)
);


endmodule