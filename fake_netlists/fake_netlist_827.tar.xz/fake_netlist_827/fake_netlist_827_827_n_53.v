module fake_netlist_827_827_n_53 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_53);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_53;

wire n_48;
wire n_49;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_11),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_0),
.B(n_9),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_15),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_3),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_14),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_26),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_4),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_28),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_28),
.B(n_24),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_31),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_36),
.Y(n_39)
);

OAI22xp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_34),
.B1(n_27),
.B2(n_30),
.Y(n_40)
);

BUFx3_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

NOR4xp25_ASAP7_75t_SL g42 ( 
.A(n_40),
.B(n_33),
.C(n_35),
.D(n_29),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_38),
.B1(n_32),
.B2(n_25),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_38),
.B1(n_25),
.B2(n_1),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

NOR3xp33_ASAP7_75t_SL g46 ( 
.A(n_44),
.B(n_42),
.C(n_2),
.Y(n_46)
);

OAI21xp33_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_6),
.B(n_5),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_SL g48 ( 
.A1(n_46),
.A2(n_8),
.B1(n_7),
.B2(n_10),
.C(n_12),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_13),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_50),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_SL g52 ( 
.A1(n_49),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_52)
);

AOI222xp33_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_20),
.B1(n_21),
.B2(n_22),
.C1(n_23),
.C2(n_52),
.Y(n_53)
);


endmodule