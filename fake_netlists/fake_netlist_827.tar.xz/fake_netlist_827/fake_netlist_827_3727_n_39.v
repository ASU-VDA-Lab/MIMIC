module fake_netlist_827_3727_n_39 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_39);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_39;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_16),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_8),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_4),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_10),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_1),
.B(n_11),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_17),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_25),
.A2(n_23),
.B1(n_18),
.B2(n_24),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_27),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_18),
.B(n_19),
.C(n_17),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_32),
.B(n_18),
.Y(n_34)
);

OAI322xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_2),
.A3(n_0),
.B1(n_6),
.B2(n_7),
.C1(n_3),
.C2(n_5),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_14),
.B1(n_13),
.B2(n_9),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_37),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);


endmodule