module fake_netlist_827_4026_n_34 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_34);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_8),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_7),
.B(n_10),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_3),
.B(n_11),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_18),
.Y(n_22)
);

AND3x1_ASAP7_75t_SL g23 ( 
.A(n_19),
.B(n_12),
.C(n_0),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_SL g24 ( 
.A(n_15),
.B(n_12),
.C(n_5),
.Y(n_24)
);

CKINVDCx8_ASAP7_75t_R g25 ( 
.A(n_22),
.Y(n_25)
);

OAI21x1_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_21),
.B(n_20),
.Y(n_26)
);

CKINVDCx11_ASAP7_75t_R g27 ( 
.A(n_25),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_24),
.B1(n_20),
.B2(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

INVx3_ASAP7_75t_SL g30 ( 
.A(n_29),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_16),
.C(n_27),
.Y(n_31)
);

BUFx4f_ASAP7_75t_SL g32 ( 
.A(n_31),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_R g33 ( 
.A1(n_32),
.A2(n_14),
.B1(n_13),
.B2(n_9),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_33),
.Y(n_34)
);


endmodule