module fake_netlist_827_1361_n_31 (n_4, n_2, n_5, n_3, n_0, n_1, n_31);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_31;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_28;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_6;
wire n_30;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;
wire n_8;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

BUFx10_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_5),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_1),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_7),
.A2(n_4),
.B(n_1),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_7),
.Y(n_14)
);

OA22x2_ASAP7_75t_L g15 ( 
.A1(n_6),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_10),
.Y(n_16)
);

INVx3_ASAP7_75t_SL g17 ( 
.A(n_12),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx2_ASAP7_75t_SL g21 ( 
.A(n_16),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI32xp33_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_11),
.A3(n_13),
.B1(n_17),
.B2(n_8),
.Y(n_25)
);

AO22x2_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_17),
.B1(n_20),
.B2(n_19),
.Y(n_26)
);

NAND4xp75_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_24),
.C(n_15),
.D(n_22),
.Y(n_27)
);

AOI211xp5_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_8),
.B(n_15),
.C(n_2),
.Y(n_28)
);

AOI22x1_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_3),
.B1(n_15),
.B2(n_27),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_21),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_30),
.B1(n_26),
.B2(n_23),
.Y(n_31)
);


endmodule