module fake_netlist_827_3732_n_61 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_61);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_61;

wire n_48;
wire n_49;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_60;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_9),
.B(n_2),
.Y(n_29)
);

INVx4_ASAP7_75t_L g30 ( 
.A(n_5),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_8),
.B(n_11),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_12),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_14),
.B(n_19),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_0),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_22),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_15),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_24),
.B1(n_21),
.B2(n_17),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_35),
.A2(n_24),
.B1(n_21),
.B2(n_17),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_SL g41 ( 
.A(n_32),
.B(n_25),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_29),
.Y(n_42)
);

BUFx3_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_41),
.Y(n_44)
);

INVx3_ASAP7_75t_SL g45 ( 
.A(n_44),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_39),
.B1(n_34),
.B2(n_36),
.C(n_27),
.Y(n_46)
);

INVx3_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AOI33xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_42),
.A3(n_36),
.B1(n_37),
.B2(n_29),
.B3(n_43),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

NAND2x1_ASAP7_75t_SL g50 ( 
.A(n_47),
.B(n_29),
.Y(n_50)
);

A2O1A1Ixp33_ASAP7_75t_SL g51 ( 
.A1(n_49),
.A2(n_47),
.B(n_32),
.C(n_37),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

XOR2x2_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_43),
.Y(n_53)
);

O2A1O1Ixp33_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_47),
.B(n_52),
.C(n_42),
.Y(n_54)
);

OR5x1_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_26),
.C(n_25),
.D(n_30),
.E(n_35),
.Y(n_55)
);

NOR3xp33_ASAP7_75t_L g56 ( 
.A(n_51),
.B(n_30),
.C(n_42),
.Y(n_56)
);

AOI222xp33_ASAP7_75t_L g57 ( 
.A1(n_55),
.A2(n_42),
.B1(n_30),
.B2(n_28),
.C1(n_33),
.C2(n_31),
.Y(n_57)
);

INVxp67_ASAP7_75t_SL g58 ( 
.A(n_54),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_56),
.B1(n_28),
.B2(n_1),
.Y(n_59)
);

OAI22xp33_ASAP7_75t_SL g60 ( 
.A1(n_57),
.A2(n_6),
.B1(n_4),
.B2(n_3),
.Y(n_60)
);

AOI322xp5_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_7),
.A3(n_13),
.B1(n_16),
.B2(n_20),
.C1(n_23),
.C2(n_59),
.Y(n_61)
);


endmodule