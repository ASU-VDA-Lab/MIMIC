module fake_netlist_827_2551_n_19 (n_4, n_2, n_5, n_3, n_0, n_1, n_19);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_5),
.B(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_5),
.B(n_4),
.Y(n_9)
);

AO31x2_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_4),
.A3(n_1),
.B(n_0),
.Y(n_10)
);

O2A1O1Ixp5_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_9),
.B(n_7),
.C(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

OAI321xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.A3(n_11),
.B1(n_12),
.B2(n_13),
.C(n_7),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

XNOR2x1_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_17),
.Y(n_19)
);


endmodule