module fake_netlist_827_1744_n_36 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_36);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_36;

wire n_25;
wire n_20;
wire n_22;
wire n_34;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_27;

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_15),
.B(n_10),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_13),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_4),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_19),
.B(n_0),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_5),
.B1(n_3),
.B2(n_1),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_R g28 ( 
.A(n_26),
.B(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

O2A1O1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_27),
.B(n_18),
.C(n_19),
.Y(n_30)
);

XNOR2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_21),
.Y(n_31)
);

OAI22xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_24),
.B1(n_23),
.B2(n_22),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_31),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_33),
.B1(n_11),
.B2(n_9),
.Y(n_36)
);


endmodule