module fake_netlist_827_79_n_59 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_59);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_59;

wire n_48;
wire n_49;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_30;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_9),
.B(n_12),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

CKINVDCx16_ASAP7_75t_R g31 ( 
.A(n_0),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_13),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_19),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_2),
.B(n_10),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_4),
.A2(n_3),
.B1(n_1),
.B2(n_17),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_24),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_30),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_32),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_31),
.A2(n_26),
.B1(n_25),
.B2(n_24),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_29),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_34),
.B(n_33),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_35),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_42),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_40),
.Y(n_48)
);

NAND3xp33_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_36),
.C(n_35),
.Y(n_49)
);

OAI21xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_28),
.B(n_27),
.Y(n_50)
);

NAND4xp75_ASAP7_75t_L g51 ( 
.A(n_50),
.B(n_26),
.C(n_25),
.D(n_7),
.Y(n_51)
);

AOI21xp33_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_27),
.B(n_8),
.Y(n_52)
);

AND2x4_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_27),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

CKINVDCx20_ASAP7_75t_R g55 ( 
.A(n_52),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_16),
.B1(n_15),
.B2(n_11),
.Y(n_56)
);

OAI21x1_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_20),
.B(n_18),
.Y(n_57)
);

OAI22xp5_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_53),
.B1(n_23),
.B2(n_21),
.Y(n_58)
);

AOI21xp33_ASAP7_75t_SL g59 ( 
.A1(n_58),
.A2(n_53),
.B(n_57),
.Y(n_59)
);


endmodule