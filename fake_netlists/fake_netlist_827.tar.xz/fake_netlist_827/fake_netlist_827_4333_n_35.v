module fake_netlist_827_4333_n_35 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_35);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_35;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

INVx2_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_6),
.B(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B1(n_14),
.B2(n_17),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_16),
.B1(n_15),
.B2(n_13),
.C(n_0),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B1(n_19),
.B2(n_20),
.C(n_0),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_21),
.A2(n_20),
.B1(n_3),
.B2(n_2),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_20),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_20),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_2),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_4),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI21xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_5),
.B(n_4),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

XNOR2x1_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_6),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_SL g34 ( 
.A1(n_32),
.A2(n_7),
.B1(n_9),
.B2(n_8),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_7),
.B1(n_31),
.B2(n_34),
.Y(n_35)
);


endmodule