module fake_netlist_613_3927_n_19 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_19);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_19;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_0),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

AOI21xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B(n_10),
.Y(n_15)
);

NAND4xp25_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_4),
.C(n_3),
.D(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_17),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_19)
);


endmodule