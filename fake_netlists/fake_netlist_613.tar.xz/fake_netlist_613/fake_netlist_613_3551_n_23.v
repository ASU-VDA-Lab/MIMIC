module fake_netlist_613_3551_n_23 (n_7, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_23);

input n_7;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_23;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

NAND3xp33_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_7),
.C(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_6),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_7),
.B(n_0),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_L g13 ( 
.A(n_2),
.B(n_5),
.C(n_1),
.Y(n_13)
);

OAI21x1_ASAP7_75t_SL g14 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_14)
);

AOI21x1_ASAP7_75t_SL g15 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_10),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_10),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_17),
.C(n_16),
.Y(n_19)
);

NOR2x1_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);

OAI211xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_13),
.B(n_9),
.C(n_15),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_4),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_3),
.B1(n_8),
.B2(n_16),
.C(n_21),
.Y(n_23)
);


endmodule