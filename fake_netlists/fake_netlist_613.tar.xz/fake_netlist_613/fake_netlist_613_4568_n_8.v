module fake_netlist_613_4568_n_8 (n_1, n_0, n_8);

input n_1;
input n_0;

output n_8;

wire n_7;
wire n_5;
wire n_6;
wire n_4;
wire n_2;
wire n_3;

AND2x2_ASAP7_75t_L g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

AOI22xp33_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

AO21x1_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B(n_0),
.Y(n_6)
);

NAND4xp75_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.C(n_1),
.D(n_0),
.Y(n_7)
);

AO21x2_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B(n_6),
.Y(n_8)
);


endmodule