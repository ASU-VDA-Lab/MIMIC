module fake_netlist_613_486_n_16 (n_1, n_2, n_0, n_16);

input n_1;
input n_2;
input n_0;

output n_16;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_15;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;
wire n_3;

INVx2_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_2),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_2),
.Y(n_6)
);

NAND2x1p5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_2),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_3),
.Y(n_9)
);

AND2x4_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_6),
.Y(n_10)
);

OAI321xp33_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_6),
.A3(n_4),
.B1(n_3),
.B2(n_1),
.C(n_0),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_9),
.B1(n_3),
.B2(n_0),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_9),
.C2(n_6),
.Y(n_13)
);

AND2x2_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_0),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_14),
.A2(n_1),
.B1(n_2),
.B2(n_15),
.Y(n_16)
);


endmodule