module fake_netlist_613_4255_n_17 (n_7, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_17);

input n_7;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_17;

wire n_11;
wire n_15;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_1),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_4),
.B(n_6),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_2),
.B(n_0),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_7),
.Y(n_14)
);

OA21x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_9),
.B(n_10),
.Y(n_15)
);

INVx4_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AO21x2_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_12),
.B(n_3),
.Y(n_17)
);


endmodule