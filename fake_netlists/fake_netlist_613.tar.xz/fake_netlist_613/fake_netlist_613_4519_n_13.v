module fake_netlist_613_4519_n_13 (n_1, n_2, n_3, n_0, n_13);

input n_1;
input n_2;
input n_3;
input n_0;

output n_13;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_12;

OAI22xp33_ASAP7_75t_L g4 ( 
.A1(n_0),
.A2(n_2),
.B1(n_3),
.B2(n_1),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_1),
.B(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2x1p5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_0),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.Y(n_8)
);

AO21x2_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_2),
.B(n_3),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_7),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B(n_7),
.C(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_2),
.B1(n_9),
.B2(n_10),
.Y(n_13)
);


endmodule