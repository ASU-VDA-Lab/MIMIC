module fake_netlist_613_2851_n_30 (n_7, n_9, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_30);

input n_7;
input n_9;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_30;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_10),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

A2O1A1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_16),
.B(n_13),
.C(n_11),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_7),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_18)
);

AND2x2_ASAP7_75t_SL g19 ( 
.A(n_16),
.B(n_3),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_5),
.B(n_4),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_15),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_19),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_18),
.B(n_14),
.C(n_20),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

NAND3xp33_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_22),
.C(n_23),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_27),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_25),
.B1(n_5),
.B2(n_4),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_10),
.B1(n_9),
.B2(n_6),
.Y(n_30)
);


endmodule