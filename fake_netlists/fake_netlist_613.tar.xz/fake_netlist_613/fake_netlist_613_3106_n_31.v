module fake_netlist_613_3106_n_31 (n_7, n_9, n_11, n_8, n_5, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_31);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_31;

wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

NOR2xp67_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_4),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.Y(n_20)
);

NOR2x1_ASAP7_75t_R g21 ( 
.A(n_16),
.B(n_7),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_18),
.B(n_15),
.C(n_19),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_22),
.Y(n_26)
);

XNOR2x1_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_14),
.Y(n_27)
);

XOR2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_17),
.Y(n_28)
);

OAI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_27),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_9),
.B2(n_5),
.Y(n_31)
);


endmodule