module fake_netlist_613_2330_n_43 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_43);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_43;

wire n_11;
wire n_31;
wire n_15;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_10;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_42;
wire n_33;
wire n_14;
wire n_41;
wire n_13;
wire n_12;

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_8),
.B(n_9),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_7),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_2),
.B(n_3),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

AO21x1_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_3),
.B(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_11),
.B(n_0),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_12),
.B(n_4),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_SL g26 ( 
.A1(n_23),
.A2(n_15),
.B1(n_16),
.B2(n_14),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_15),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_23),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_24),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_25),
.B(n_24),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_SL g33 ( 
.A(n_30),
.B(n_25),
.C(n_19),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_29),
.B1(n_28),
.B2(n_26),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_R g37 ( 
.A(n_34),
.B(n_28),
.Y(n_37)
);

OAI21xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_28),
.B(n_33),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_28),
.B1(n_32),
.B2(n_21),
.Y(n_39)
);

NOR4xp25_ASAP7_75t_SL g40 ( 
.A(n_37),
.B(n_10),
.C(n_6),
.D(n_5),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_10),
.B1(n_6),
.B2(n_5),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_7),
.B1(n_40),
.B2(n_42),
.Y(n_43)
);


endmodule