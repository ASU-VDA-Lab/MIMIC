module fake_netlist_613_4176_n_19 (n_7, n_9, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_19);

input n_7;
input n_9;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_19;

wire n_11;
wire n_15;
wire n_18;
wire n_17;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

INVx2_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_4),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.C(n_0),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

OAI322xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.A3(n_7),
.B1(n_5),
.B2(n_6),
.C1(n_1),
.C2(n_2),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_9),
.B(n_8),
.Y(n_19)
);


endmodule