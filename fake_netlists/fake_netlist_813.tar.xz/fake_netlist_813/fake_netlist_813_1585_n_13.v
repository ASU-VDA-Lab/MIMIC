module fake_netlist_813_1585_n_13 (n_2, n_0, n_3, n_1, n_13);

input n_2;
input n_0;
input n_3;
input n_1;

output n_13;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

OR2x6_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_0),
.Y(n_6)
);

NOR2xp67_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_1),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_4),
.Y(n_9)
);

NAND2x1_ASAP7_75t_SL g10 ( 
.A(n_8),
.B(n_6),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B1(n_3),
.B2(n_1),
.C(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C1(n_10),
.C2(n_0),
.Y(n_13)
);


endmodule