module fake_netlist_813_1733_n_37 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_37);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_37;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_27;

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_3),
.B(n_17),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_16),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_18),
.A2(n_5),
.B(n_1),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_16),
.Y(n_27)
);

AO31x2_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_24),
.A3(n_22),
.B(n_19),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_25),
.B(n_20),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_23),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_7),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_30),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

OAI21xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_26),
.B(n_8),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_12),
.B1(n_11),
.B2(n_9),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_15),
.B2(n_14),
.Y(n_37)
);


endmodule