module fake_netlist_813_757_n_92 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_28, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_29, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_92);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_28;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_29;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_92;

wire n_49;
wire n_81;
wire n_80;
wire n_78;
wire n_87;
wire n_54;
wire n_56;
wire n_59;
wire n_63;
wire n_74;
wire n_64;
wire n_79;
wire n_61;
wire n_86;
wire n_43;
wire n_45;
wire n_48;
wire n_47;
wire n_90;
wire n_76;
wire n_72;
wire n_73;
wire n_37;
wire n_42;
wire n_52;
wire n_77;
wire n_51;
wire n_57;
wire n_89;
wire n_70;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_53;
wire n_84;
wire n_58;
wire n_68;
wire n_33;
wire n_85;
wire n_55;
wire n_65;
wire n_75;
wire n_67;
wire n_66;
wire n_91;
wire n_36;
wire n_50;
wire n_83;
wire n_60;
wire n_39;
wire n_32;
wire n_31;
wire n_71;
wire n_82;
wire n_69;
wire n_88;
wire n_30;
wire n_35;
wire n_38;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_1),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_13),
.B(n_7),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_18),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_22),
.B(n_3),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_16),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_26),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_SL g40 ( 
.A1(n_24),
.A2(n_15),
.B1(n_12),
.B2(n_22),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_5),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_2),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_9),
.Y(n_43)
);

NAND2xp33_ASAP7_75t_L g44 ( 
.A(n_29),
.B(n_26),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_14),
.B(n_6),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_32),
.B(n_19),
.Y(n_46)
);

CKINVDCx20_ASAP7_75t_R g47 ( 
.A(n_30),
.Y(n_47)
);

NOR3xp33_ASAP7_75t_SL g48 ( 
.A(n_39),
.B(n_24),
.C(n_19),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_32),
.Y(n_49)
);

BUFx2_ASAP7_75t_L g50 ( 
.A(n_34),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_35),
.B(n_25),
.Y(n_51)
);

NAND2xp33_ASAP7_75t_SL g52 ( 
.A(n_33),
.B(n_25),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_34),
.B(n_27),
.Y(n_53)
);

BUFx2_ASAP7_75t_R g54 ( 
.A(n_50),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_41),
.Y(n_55)
);

NAND2xp33_ASAP7_75t_SL g56 ( 
.A(n_48),
.B(n_33),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_L g57 ( 
.A1(n_46),
.A2(n_40),
.B1(n_47),
.B2(n_37),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_58),
.B(n_49),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_55),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_56),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_57),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_59),
.Y(n_63)
);

AND2x2_ASAP7_75t_L g64 ( 
.A(n_60),
.B(n_53),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_61),
.Y(n_65)
);

AND2x2_ASAP7_75t_L g66 ( 
.A(n_60),
.B(n_49),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_65),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_64),
.B(n_62),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_65),
.Y(n_69)
);

OAI221xp5_ASAP7_75t_SL g70 ( 
.A1(n_63),
.A2(n_62),
.B1(n_59),
.B2(n_57),
.C(n_46),
.Y(n_70)
);

OAI22xp5_ASAP7_75t_L g71 ( 
.A1(n_64),
.A2(n_51),
.B1(n_36),
.B2(n_45),
.Y(n_71)
);

AOI221xp5_ASAP7_75t_L g72 ( 
.A1(n_70),
.A2(n_44),
.B1(n_66),
.B2(n_52),
.C(n_37),
.Y(n_72)
);

INVx2_ASAP7_75t_L g73 ( 
.A(n_67),
.Y(n_73)
);

AOI321xp33_ASAP7_75t_L g74 ( 
.A1(n_71),
.A2(n_66),
.A3(n_44),
.B1(n_54),
.B2(n_43),
.C(n_42),
.Y(n_74)
);

AOI32xp33_ASAP7_75t_L g75 ( 
.A1(n_69),
.A2(n_45),
.A3(n_38),
.B1(n_30),
.B2(n_31),
.Y(n_75)
);

INVx2_ASAP7_75t_SL g76 ( 
.A(n_67),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_68),
.Y(n_77)
);

INVxp67_ASAP7_75t_SL g78 ( 
.A(n_73),
.Y(n_78)
);

NAND2xp5_ASAP7_75t_L g79 ( 
.A(n_77),
.B(n_38),
.Y(n_79)
);

AOI22xp5_ASAP7_75t_L g80 ( 
.A1(n_72),
.A2(n_45),
.B1(n_33),
.B2(n_27),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_75),
.B(n_73),
.Y(n_81)
);

AND4x2_ASAP7_75t_L g82 ( 
.A(n_74),
.B(n_29),
.C(n_33),
.D(n_0),
.Y(n_82)
);

CKINVDCx5p33_ASAP7_75t_R g83 ( 
.A(n_76),
.Y(n_83)
);

XNOR2x1_ASAP7_75t_L g84 ( 
.A(n_80),
.B(n_4),
.Y(n_84)
);

AO22x2_ASAP7_75t_L g85 ( 
.A1(n_82),
.A2(n_76),
.B1(n_10),
.B2(n_8),
.Y(n_85)
);

AO22x2_ASAP7_75t_L g86 ( 
.A1(n_81),
.A2(n_20),
.B1(n_17),
.B2(n_11),
.Y(n_86)
);

INVxp33_ASAP7_75t_L g87 ( 
.A(n_79),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_78),
.Y(n_88)
);

OAI22xp33_ASAP7_75t_L g89 ( 
.A1(n_87),
.A2(n_21),
.B1(n_83),
.B2(n_84),
.Y(n_89)
);

AOI22xp5_ASAP7_75t_L g90 ( 
.A1(n_86),
.A2(n_83),
.B1(n_85),
.B2(n_88),
.Y(n_90)
);

XNOR2xp5_ASAP7_75t_L g91 ( 
.A(n_86),
.B(n_85),
.Y(n_91)
);

OAI21xp5_ASAP7_75t_SL g92 ( 
.A1(n_91),
.A2(n_90),
.B(n_89),
.Y(n_92)
);


endmodule