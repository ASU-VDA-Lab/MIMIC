module fake_netlist_813_1118_n_57 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_57);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_57;

wire n_48;
wire n_49;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_31;
wire n_32;
wire n_26;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_30;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

NAND2xp33_ASAP7_75t_L g26 ( 
.A(n_1),
.B(n_21),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_7),
.B(n_12),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_17),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_2),
.Y(n_31)
);

OA21x2_ASAP7_75t_L g32 ( 
.A1(n_13),
.A2(n_20),
.B(n_11),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_10),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_0),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_SL g35 ( 
.A1(n_4),
.A2(n_15),
.B1(n_18),
.B2(n_24),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_28),
.Y(n_39)
);

OAI22xp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_35),
.B1(n_33),
.B2(n_30),
.Y(n_40)
);

OAI21x1_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_33),
.B(n_32),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_39),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_36),
.Y(n_46)
);

AOI222xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_40),
.B1(n_35),
.B2(n_26),
.C1(n_29),
.C2(n_44),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_40),
.B1(n_26),
.B2(n_29),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_25),
.B1(n_24),
.B2(n_16),
.C(n_32),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_SL g50 ( 
.A(n_47),
.B(n_16),
.Y(n_50)
);

NAND3xp33_ASAP7_75t_L g51 ( 
.A(n_50),
.B(n_25),
.C(n_3),
.Y(n_51)
);

AOI31xp33_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_8),
.A3(n_6),
.B(n_5),
.Y(n_52)
);

INVx2_ASAP7_75t_SL g53 ( 
.A(n_51),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_19),
.Y(n_54)
);

NAND3x1_ASAP7_75t_L g55 ( 
.A(n_54),
.B(n_23),
.C(n_22),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

XNOR2xp5_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_56),
.Y(n_57)
);


endmodule