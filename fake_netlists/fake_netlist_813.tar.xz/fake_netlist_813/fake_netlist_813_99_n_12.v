module fake_netlist_813_99_n_12 (n_4, n_2, n_3, n_0, n_1, n_12);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_7;
wire n_5;
wire n_9;
wire n_11;
wire n_8;

BUFx3_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx5_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI322xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_1),
.A3(n_2),
.B1(n_3),
.B2(n_8),
.C1(n_6),
.C2(n_5),
.Y(n_10)
);

XNOR2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule