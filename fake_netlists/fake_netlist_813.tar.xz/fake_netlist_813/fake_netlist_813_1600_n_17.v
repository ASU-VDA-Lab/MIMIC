module fake_netlist_813_1600_n_17 (n_4, n_2, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_9;
wire n_14;
wire n_11;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

AND2x4_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_5),
.Y(n_10)
);

NOR2x1_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_8),
.Y(n_11)
);

INVx3_ASAP7_75t_SL g12 ( 
.A(n_10),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_9),
.Y(n_13)
);

O2A1O1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_9),
.B(n_6),
.C(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_3),
.B1(n_4),
.B2(n_6),
.C1(n_11),
.C2(n_8),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_3),
.B1(n_4),
.B2(n_15),
.Y(n_17)
);


endmodule