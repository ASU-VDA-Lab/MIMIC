module fake_netlist_813_328_n_14 (n_4, n_2, n_3, n_0, n_1, n_14);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_1),
.B(n_0),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_2),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_5),
.B1(n_6),
.B2(n_2),
.Y(n_10)
);

AND3x1_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.C(n_9),
.Y(n_11)
);

OAI221xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_9),
.B2(n_3),
.C(n_4),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_12),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_4),
.Y(n_14)
);


endmodule