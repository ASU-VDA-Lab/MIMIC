module fake_netlist_813_1700_n_45 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_45);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_45;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_15),
.B(n_6),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_0),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

INVxp67_ASAP7_75t_SL g25 ( 
.A(n_8),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_3),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

A2O1A1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_24),
.A2(n_18),
.B(n_17),
.C(n_16),
.Y(n_29)
);

XNOR2xp5_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_16),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_27),
.B(n_24),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_28),
.B1(n_25),
.B2(n_21),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_SL g33 ( 
.A1(n_30),
.A2(n_26),
.B(n_23),
.C(n_20),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_29),
.B1(n_22),
.B2(n_19),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_19),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_22),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_22),
.Y(n_37)
);

OAI21xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_22),
.B(n_4),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_5),
.Y(n_39)
);

OAI221xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_9),
.B1(n_7),
.B2(n_10),
.C(n_12),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_43),
.B1(n_14),
.B2(n_13),
.Y(n_45)
);


endmodule