module fake_netlist_813_2077_n_29 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_29);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_29;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_5),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_7),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_2),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_4),
.B(n_1),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_14),
.B1(n_12),
.B2(n_11),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_13),
.Y(n_19)
);

NAND4xp25_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_14),
.C(n_12),
.D(n_15),
.Y(n_20)
);

OAI32xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_19),
.A3(n_5),
.B1(n_1),
.B2(n_4),
.Y(n_21)
);

OAI21xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_4),
.B(n_1),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_22),
.B1(n_7),
.B2(n_6),
.C(n_0),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.C(n_2),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

OAI22x1_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_6),
.B1(n_8),
.B2(n_3),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

AOI322xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_3),
.A3(n_8),
.B1(n_9),
.B2(n_10),
.C1(n_25),
.C2(n_27),
.Y(n_29)
);


endmodule