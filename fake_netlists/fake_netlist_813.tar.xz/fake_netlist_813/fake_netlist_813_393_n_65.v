module fake_netlist_813_393_n_65 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_65);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_65;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_16),
.Y(n_27)
);

AND2x6_ASAP7_75t_L g28 ( 
.A(n_4),
.B(n_2),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

CKINVDCx6p67_ASAP7_75t_R g30 ( 
.A(n_10),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_15),
.B(n_24),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_3),
.B(n_18),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_21),
.B(n_6),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_5),
.B(n_14),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_19),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_1),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_27),
.Y(n_37)
);

BUFx12f_ASAP7_75t_SL g38 ( 
.A(n_32),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_25),
.B(n_16),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_29),
.B(n_18),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_32),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_35),
.B(n_26),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_37),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_41),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

OAI21xp5_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_41),
.B(n_39),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_30),
.Y(n_51)
);

XNOR2x1_ASAP7_75t_L g52 ( 
.A(n_51),
.B(n_47),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_31),
.B1(n_36),
.B2(n_33),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_28),
.Y(n_55)
);

NOR2xp33_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_24),
.Y(n_56)
);

OR2x2_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_33),
.Y(n_57)
);

NOR3xp33_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_34),
.C(n_28),
.Y(n_58)
);

AOI221xp5_ASAP7_75t_L g59 ( 
.A1(n_53),
.A2(n_28),
.B1(n_9),
.B2(n_0),
.C(n_7),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

AOI31xp33_ASAP7_75t_L g61 ( 
.A1(n_56),
.A2(n_28),
.A3(n_12),
.B(n_11),
.Y(n_61)
);

CKINVDCx5p33_ASAP7_75t_R g62 ( 
.A(n_58),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_60),
.B(n_59),
.Y(n_63)
);

OAI22xp33_ASAP7_75t_L g64 ( 
.A1(n_61),
.A2(n_22),
.B1(n_20),
.B2(n_17),
.Y(n_64)
);

AOI21xp5_ASAP7_75t_L g65 ( 
.A1(n_64),
.A2(n_62),
.B(n_63),
.Y(n_65)
);


endmodule