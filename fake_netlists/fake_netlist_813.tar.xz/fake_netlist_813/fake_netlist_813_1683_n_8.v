module fake_netlist_813_1683_n_8 (n_2, n_0, n_1, n_8);

input n_2;
input n_0;
input n_1;

output n_8;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;

OR2x6_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

AND2x4_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_0),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_1),
.Y(n_5)
);

NAND2xp33_ASAP7_75t_SL g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

NOR4xp25_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_3),
.C(n_4),
.D(n_2),
.Y(n_7)
);

OAI22xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_2),
.B1(n_3),
.B2(n_5),
.Y(n_8)
);


endmodule