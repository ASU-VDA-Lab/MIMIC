module fake_netlist_813_107_n_47 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_47);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_47;

wire n_25;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

AND2x4_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_9),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_8),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_6),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_21),
.B(n_19),
.Y(n_31)
);

A2O1A1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_21),
.B(n_25),
.C(n_24),
.Y(n_32)
);

OAI22xp33_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_27),
.B1(n_23),
.B2(n_28),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_29),
.Y(n_39)
);

OAI21xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_31),
.B(n_19),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_28),
.B1(n_4),
.B2(n_3),
.Y(n_41)
);

O2A1O1Ixp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_10),
.B(n_7),
.C(n_5),
.Y(n_42)
);

OAI21xp33_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_13),
.B(n_12),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

OAI221xp5_ASAP7_75t_R g47 ( 
.A1(n_46),
.A2(n_44),
.B1(n_20),
.B2(n_14),
.C(n_17),
.Y(n_47)
);


endmodule