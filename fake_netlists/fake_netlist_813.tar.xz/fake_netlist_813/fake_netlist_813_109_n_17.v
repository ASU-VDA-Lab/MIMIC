module fake_netlist_813_109_n_17 (n_4, n_2, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx3_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_1),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

AO21x2_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_6),
.B(n_2),
.Y(n_10)
);

OAI33xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_8),
.A3(n_7),
.B1(n_4),
.B2(n_3),
.B3(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_8),
.B(n_10),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_10),
.B(n_8),
.C(n_3),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_4),
.B1(n_8),
.B2(n_14),
.Y(n_15)
);

BUFx4f_ASAP7_75t_SL g16 ( 
.A(n_14),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_8),
.B(n_16),
.Y(n_17)
);


endmodule