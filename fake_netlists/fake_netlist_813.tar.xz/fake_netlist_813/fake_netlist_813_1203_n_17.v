module fake_netlist_813_1203_n_17 (n_4, n_2, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

NOR2xp33_ASAP7_75t_R g5 ( 
.A(n_2),
.B(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

NAND2x1p5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_0),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AOI221x1_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_8),
.B1(n_5),
.B2(n_2),
.C(n_3),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_9),
.B1(n_12),
.B2(n_0),
.C(n_1),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C1(n_4),
.C2(n_12),
.Y(n_14)
);

OAI22x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_1),
.B1(n_4),
.B2(n_13),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_4),
.B(n_1),
.Y(n_16)
);

AOI21xp33_ASAP7_75t_SL g17 ( 
.A1(n_15),
.A2(n_16),
.B(n_14),
.Y(n_17)
);


endmodule