module fake_netlist_813_1982_n_40 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_40);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_40;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_5),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

AO22x1_ASAP7_75t_L g26 ( 
.A1(n_20),
.A2(n_17),
.B1(n_16),
.B2(n_4),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_19),
.A2(n_17),
.B1(n_4),
.B2(n_0),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

AO21x2_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_22),
.B(n_27),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_24),
.B1(n_23),
.B2(n_21),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_26),
.B2(n_21),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

OAI221xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_18),
.B1(n_7),
.B2(n_1),
.C(n_6),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

O2A1O1Ixp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_18),
.B(n_9),
.C(n_8),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_11),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_37),
.B1(n_14),
.B2(n_12),
.Y(n_40)
);


endmodule