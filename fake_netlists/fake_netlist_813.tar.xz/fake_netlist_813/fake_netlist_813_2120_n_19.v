module fake_netlist_813_2120_n_19 (n_4, n_2, n_5, n_3, n_0, n_1, n_19);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_2),
.B(n_5),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_5),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_7),
.Y(n_10)
);

OAI31xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.A3(n_7),
.B(n_0),
.Y(n_11)
);

OAI33xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.A3(n_3),
.B1(n_0),
.B2(n_4),
.B3(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_9),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_SL g15 ( 
.A1(n_13),
.A2(n_11),
.B(n_14),
.C(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_9),
.B1(n_4),
.B2(n_3),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_9),
.B1(n_5),
.B2(n_3),
.C(n_4),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_9),
.B1(n_16),
.B2(n_17),
.Y(n_19)
);


endmodule