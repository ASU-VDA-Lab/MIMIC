module fake_netlist_813_1133_n_27 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_27);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_21;
wire n_16;
wire n_11;

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_10),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_13),
.B(n_2),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_SL g19 ( 
.A(n_11),
.B(n_3),
.Y(n_19)
);

AND2x6_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_11),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_17),
.B(n_12),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_14),
.Y(n_22)
);

OAI21xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B(n_18),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_15),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_9),
.B1(n_7),
.B2(n_6),
.Y(n_27)
);


endmodule