module fake_netlist_813_2197_n_18 (n_4, n_2, n_5, n_3, n_0, n_1, n_18);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_18;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_16;
wire n_17;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_0),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_2),
.A2(n_1),
.B1(n_0),
.B2(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_10),
.B1(n_7),
.B2(n_1),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_7),
.C(n_4),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_14),
.B1(n_10),
.B2(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);


endmodule