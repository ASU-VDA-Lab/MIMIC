module fake_netlist_813_218_n_19 (n_4, n_2, n_5, n_3, n_0, n_1, n_19);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_2),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_0),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_4),
.B(n_1),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B(n_9),
.C(n_6),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

XNOR2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_7),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

OAI31xp33_ASAP7_75t_SL g18 ( 
.A1(n_16),
.A2(n_4),
.A3(n_5),
.B(n_15),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_5),
.B1(n_15),
.B2(n_17),
.Y(n_19)
);


endmodule