module fake_netlist_813_681_n_32 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

BUFx3_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_10),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_3),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_11),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_19),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_21),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_16),
.Y(n_26)
);

INVx2_ASAP7_75t_SL g27 ( 
.A(n_25),
.Y(n_27)
);

OA21x2_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_18),
.B(n_20),
.Y(n_28)
);

A2O1A1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_17),
.B(n_15),
.C(n_13),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_28),
.B1(n_6),
.B2(n_1),
.C(n_2),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_32)
);


endmodule