module fake_netlist_813_968_n_17 (n_4, n_2, n_5, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_16;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_0),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_8),
.C(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_3),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_12),
.B1(n_3),
.B2(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_4),
.B1(n_5),
.B2(n_16),
.Y(n_17)
);


endmodule