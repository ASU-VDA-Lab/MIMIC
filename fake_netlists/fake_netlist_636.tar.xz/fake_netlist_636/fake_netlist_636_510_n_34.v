module fake_netlist_636_510_n_34 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_16, n_10, n_6, n_13, n_11, n_34);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_16;
input n_10;
input n_6;
input n_13;
input n_11;

output n_34;

wire n_18;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_20;
wire n_22;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_17;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_20),
.B1(n_17),
.B2(n_21),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_19),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_18),
.B1(n_7),
.B2(n_12),
.C(n_13),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OA21x2_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_26),
.B(n_8),
.Y(n_30)
);

NOR2xp67_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_9),
.Y(n_31)
);

AOI22x1_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_30),
.B1(n_26),
.B2(n_0),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_26),
.B1(n_7),
.B2(n_11),
.Y(n_33)
);

AOI222xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_3),
.B2(n_5),
.C1(n_4),
.C2(n_1),
.Y(n_34)
);


endmodule