module fake_netlist_636_1224_n_29 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_10, n_6, n_13, n_11, n_29);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_10;
input n_6;
input n_13;
input n_11;

output n_29;

wire n_18;
wire n_25;
wire n_20;
wire n_22;
wire n_23;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

INVxp67_ASAP7_75t_SL g16 ( 
.A(n_1),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

AND3x2_ASAP7_75t_L g19 ( 
.A(n_8),
.B(n_2),
.C(n_15),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_5),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_17),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_13),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_17),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_22),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_23),
.B1(n_16),
.B2(n_18),
.C(n_20),
.Y(n_25)
);

AOI321xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.A3(n_11),
.B1(n_10),
.B2(n_12),
.C(n_13),
.Y(n_26)
);

AOI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_19),
.B1(n_9),
.B2(n_12),
.C1(n_11),
.C2(n_6),
.Y(n_27)
);

NAND5xp2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_14),
.C(n_9),
.D(n_6),
.E(n_15),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_0),
.B1(n_4),
.B2(n_7),
.Y(n_29)
);


endmodule