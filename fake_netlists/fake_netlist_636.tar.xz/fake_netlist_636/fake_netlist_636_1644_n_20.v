module fake_netlist_636_1644_n_20 (n_0, n_1, n_4, n_3, n_2, n_20);

input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_20;

wire n_18;
wire n_13;
wire n_7;
wire n_10;
wire n_11;
wire n_9;
wire n_15;
wire n_8;
wire n_12;
wire n_14;
wire n_6;
wire n_5;
wire n_17;
wire n_16;
wire n_19;

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_6),
.B(n_7),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_0),
.B(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_13),
.B(n_11),
.C(n_0),
.Y(n_14)
);

OAI21xp33_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_0),
.B(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_13),
.B(n_2),
.C(n_4),
.Y(n_17)
);

AOI22x1_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_4),
.B1(n_12),
.B2(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

AO21x2_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.B(n_18),
.Y(n_20)
);


endmodule