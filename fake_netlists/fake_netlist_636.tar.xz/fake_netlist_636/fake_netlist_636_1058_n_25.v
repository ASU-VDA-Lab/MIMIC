module fake_netlist_636_1058_n_25 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_11, n_25);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_11;

output n_25;

wire n_18;
wire n_13;
wire n_22;
wire n_20;
wire n_15;
wire n_23;
wire n_14;
wire n_21;
wire n_17;
wire n_16;
wire n_19;
wire n_24;

BUFx3_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_5),
.B(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_1),
.B(n_0),
.C(n_10),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_8),
.B(n_12),
.Y(n_19)
);

BUFx2_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

NOR2xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_3),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_18),
.C(n_14),
.Y(n_22)
);

NOR2x1_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_13),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI221x1_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_17),
.B1(n_9),
.B2(n_2),
.C(n_7),
.Y(n_25)
);


endmodule