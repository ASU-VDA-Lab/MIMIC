module fake_netlist_636_1597_n_30 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_10, n_6, n_13, n_11, n_30);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_10;
input n_6;
input n_13;
input n_11;

output n_30;

wire n_18;
wire n_25;
wire n_22;
wire n_20;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

OAI22xp33_ASAP7_75t_SL g17 ( 
.A1(n_3),
.A2(n_13),
.B1(n_0),
.B2(n_12),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_15),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_3),
.A2(n_1),
.B1(n_6),
.B2(n_2),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_1),
.B1(n_0),
.B2(n_4),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_7),
.B(n_10),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_24),
.B(n_19),
.Y(n_25)
);

AOI22x1_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_16),
.B1(n_18),
.B2(n_17),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_16),
.B1(n_23),
.B2(n_4),
.C(n_2),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_26),
.B1(n_5),
.B2(n_9),
.Y(n_30)
);


endmodule