module fake_netlist_636_1879_n_28 (n_5, n_0, n_1, n_4, n_3, n_2, n_28);

input n_5;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_28;

wire n_18;
wire n_13;
wire n_7;
wire n_25;
wire n_10;
wire n_20;
wire n_22;
wire n_11;
wire n_9;
wire n_15;
wire n_23;
wire n_8;
wire n_12;
wire n_14;
wire n_6;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_24;

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_0),
.B(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_5),
.B(n_4),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_6),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_2),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_7),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_12),
.B1(n_8),
.B2(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NOR3x1_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_2),
.C(n_5),
.Y(n_21)
);

NOR2x1_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_15),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_20),
.B(n_15),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_4),
.Y(n_24)
);

NAND5xp2_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_1),
.C(n_3),
.D(n_5),
.E(n_22),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_24),
.B(n_3),
.Y(n_26)
);

NOR2x1_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_23),
.Y(n_27)
);

OAI21xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_25),
.B(n_27),
.Y(n_28)
);


endmodule