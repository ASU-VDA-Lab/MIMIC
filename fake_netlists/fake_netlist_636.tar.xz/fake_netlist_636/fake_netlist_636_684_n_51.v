module fake_netlist_636_684_n_51 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_51);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_51;

wire n_34;
wire n_49;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_38;
wire n_45;
wire n_36;
wire n_47;
wire n_23;
wire n_42;
wire n_29;
wire n_48;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_24;
wire n_50;

INVx1_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_0),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_5),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_3),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_20),
.B(n_9),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_19),
.Y(n_32)
);

INVx4_ASAP7_75t_L g33 ( 
.A(n_1),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_SL g34 ( 
.A(n_32),
.B(n_30),
.C(n_23),
.Y(n_34)
);

OR2x6_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_11),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_25),
.B(n_22),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_24),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_36),
.B1(n_37),
.B2(n_33),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_33),
.B1(n_31),
.B2(n_29),
.Y(n_39)
);

OAI21x1_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_26),
.B(n_28),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_32),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_40),
.Y(n_44)
);

NAND4xp75_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_11),
.C(n_22),
.D(n_13),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_45),
.Y(n_46)
);

INVx2_ASAP7_75t_SL g47 ( 
.A(n_44),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_16),
.B1(n_21),
.B2(n_14),
.C(n_15),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_SL g49 ( 
.A1(n_46),
.A2(n_47),
.B1(n_48),
.B2(n_10),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_4),
.B1(n_7),
.B2(n_6),
.Y(n_51)
);


endmodule