module fake_netlist_636_1018_n_35 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_16, n_10, n_17, n_6, n_13, n_11, n_35);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_16;
input n_10;
input n_17;
input n_6;
input n_13;
input n_11;

output n_35;

wire n_18;
wire n_34;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_22;
wire n_20;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_26;
wire n_28;
wire n_19;
wire n_24;

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_2),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_8),
.B(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

OR2x4_ASAP7_75t_L g24 ( 
.A(n_18),
.B(n_8),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_17),
.C(n_16),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_27),
.Y(n_29)
);

AOI221x1_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_21),
.B1(n_22),
.B2(n_23),
.C(n_19),
.Y(n_30)
);

AOI322xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_23),
.A3(n_22),
.B1(n_19),
.B2(n_16),
.C1(n_14),
.C2(n_15),
.Y(n_31)
);

NAND2x1p5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_11),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_SL g33 ( 
.A(n_31),
.B(n_32),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_15),
.B1(n_14),
.B2(n_6),
.C(n_10),
.Y(n_34)
);

AOI322xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_34),
.A3(n_5),
.B1(n_12),
.B2(n_7),
.C1(n_3),
.C2(n_0),
.Y(n_35)
);


endmodule