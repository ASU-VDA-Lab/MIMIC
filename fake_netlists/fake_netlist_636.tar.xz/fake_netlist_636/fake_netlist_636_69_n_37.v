module fake_netlist_636_69_n_37 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_16, n_10, n_17, n_6, n_13, n_11, n_37);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_16;
input n_10;
input n_17;
input n_6;
input n_13;
input n_11;

output n_37;

wire n_18;
wire n_34;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_22;
wire n_20;
wire n_36;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_35;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

INVxp33_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_7),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_22),
.B(n_17),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_23),
.C(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_27),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_29),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_18),
.B1(n_20),
.B2(n_21),
.C1(n_17),
.C2(n_8),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_12),
.B(n_10),
.Y(n_33)
);

NAND4xp75_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_9),
.C(n_5),
.D(n_0),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_33),
.B1(n_13),
.B2(n_11),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_2),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_36),
.B1(n_4),
.B2(n_16),
.Y(n_37)
);


endmodule