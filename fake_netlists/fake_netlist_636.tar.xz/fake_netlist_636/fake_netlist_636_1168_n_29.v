module fake_netlist_636_1168_n_29 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_14, n_10, n_6, n_13, n_11, n_29);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_10;
input n_6;
input n_13;
input n_11;

output n_29;

wire n_18;
wire n_25;
wire n_22;
wire n_20;
wire n_23;
wire n_15;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_10),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_20),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_17),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_18),
.B1(n_16),
.B2(n_15),
.Y(n_25)
);

NAND4xp75_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_21),
.C(n_11),
.D(n_9),
.Y(n_26)
);

XNOR2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_13),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_2),
.B1(n_5),
.B2(n_1),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_7),
.B1(n_14),
.B2(n_4),
.Y(n_29)
);


endmodule