module fake_netlist_636_1757_n_38 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_14, n_10, n_6, n_13, n_11, n_38);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_10;
input n_6;
input n_13;
input n_11;

output n_38;

wire n_18;
wire n_34;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_22;
wire n_20;
wire n_36;
wire n_15;
wire n_23;
wire n_29;
wire n_21;
wire n_37;
wire n_27;
wire n_35;
wire n_26;
wire n_16;
wire n_17;
wire n_19;
wire n_28;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_14),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_11),
.B(n_6),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

OA21x2_ASAP7_75t_L g20 ( 
.A1(n_10),
.A2(n_5),
.B(n_7),
.Y(n_20)
);

OA22x2_ASAP7_75t_L g21 ( 
.A1(n_13),
.A2(n_2),
.B1(n_1),
.B2(n_8),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_12),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_12),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_15),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_21),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

INVx2_ASAP7_75t_SL g31 ( 
.A(n_28),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_22),
.B1(n_16),
.B2(n_29),
.C(n_17),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_25),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_32),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_20),
.B1(n_15),
.B2(n_16),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_0),
.B1(n_4),
.B2(n_37),
.Y(n_38)
);


endmodule