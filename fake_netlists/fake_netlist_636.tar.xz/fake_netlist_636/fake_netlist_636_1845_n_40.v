module fake_netlist_636_1845_n_40 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_16, n_10, n_17, n_6, n_13, n_11, n_40);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_16;
input n_10;
input n_17;
input n_6;
input n_13;
input n_11;

output n_40;

wire n_18;
wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_20;
wire n_22;
wire n_38;
wire n_36;
wire n_23;
wire n_29;
wire n_21;
wire n_37;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_19;
wire n_24;

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_17),
.B(n_8),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_4),
.B(n_7),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_5),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_9),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_14),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_22),
.A2(n_24),
.B1(n_20),
.B2(n_21),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_19),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_27),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_31),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_18),
.B1(n_30),
.B2(n_26),
.C(n_8),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_11),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OR3x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_12),
.C(n_10),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_3),
.B1(n_13),
.B2(n_6),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_SL g40 ( 
.A1(n_38),
.A2(n_39),
.B1(n_2),
.B2(n_1),
.Y(n_40)
);


endmodule