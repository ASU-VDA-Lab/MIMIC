module fake_netlist_636_1324_n_13 (n_2, n_0, n_1, n_13);

input n_2;
input n_0;
input n_1;

output n_13;

wire n_5;
wire n_7;
wire n_9;
wire n_4;
wire n_3;
wire n_8;
wire n_12;
wire n_10;
wire n_6;
wire n_11;

INVx2_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_0),
.B(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.Y(n_9)
);

AOI21xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_5),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.C(n_2),
.Y(n_11)
);

AOI22x1_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_0),
.B1(n_2),
.B2(n_9),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_R g13 ( 
.A1(n_12),
.A2(n_0),
.B1(n_2),
.B2(n_11),
.Y(n_13)
);


endmodule