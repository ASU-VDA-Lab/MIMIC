module fake_netlist_636_775_n_30 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_13, n_11, n_30);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_13;
input n_11;

output n_30;

wire n_18;
wire n_25;
wire n_22;
wire n_20;
wire n_23;
wire n_15;
wire n_14;
wire n_29;
wire n_21;
wire n_27;
wire n_26;
wire n_16;
wire n_17;
wire n_19;
wire n_28;
wire n_24;

INVx2_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_1),
.B(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_14),
.A2(n_5),
.B(n_6),
.C(n_4),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_3),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_22),
.B(n_18),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_21),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_24),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_20),
.Y(n_26)
);

AOI211xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_17),
.B(n_15),
.C(n_19),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVxp67_ASAP7_75t_SL g29 ( 
.A(n_28),
.Y(n_29)
);

OAI31xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_2),
.A3(n_8),
.B(n_12),
.Y(n_30)
);


endmodule