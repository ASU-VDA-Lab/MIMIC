module fake_netlist_636_1419_n_48 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_23, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_48);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_23;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_48;

wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_38;
wire n_45;
wire n_36;
wire n_47;
wire n_42;
wire n_29;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_24;

INVx1_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_2),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_13),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_8),
.Y(n_31)
);

INVxp67_ASAP7_75t_SL g32 ( 
.A(n_11),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_26),
.A2(n_27),
.B(n_25),
.C(n_32),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_29),
.B(n_23),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_35),
.B1(n_30),
.B2(n_31),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_R g37 ( 
.A(n_34),
.B(n_30),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_34),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_28),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_12),
.Y(n_41)
);

AOI21xp33_ASAP7_75t_SL g42 ( 
.A1(n_41),
.A2(n_12),
.B(n_15),
.Y(n_42)
);

OAI222xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_18),
.B1(n_16),
.B2(n_17),
.C1(n_1),
.C2(n_20),
.Y(n_43)
);

NAND4xp25_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_21),
.C(n_14),
.D(n_10),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

OAI22x1_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_22),
.B1(n_6),
.B2(n_7),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_0),
.B1(n_3),
.B2(n_47),
.Y(n_48)
);


endmodule