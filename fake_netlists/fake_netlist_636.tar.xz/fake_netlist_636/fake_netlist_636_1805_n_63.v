module fake_netlist_636_1805_n_63 (n_0, n_18, n_1, n_13, n_7, n_25, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_23, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_26, n_19, n_24, n_63);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_25;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_23;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_26;
input n_19;
input n_24;

output n_63;

wire n_53;
wire n_62;
wire n_34;
wire n_49;
wire n_39;
wire n_51;
wire n_54;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_41;
wire n_31;
wire n_38;
wire n_57;
wire n_45;
wire n_36;
wire n_55;
wire n_58;
wire n_60;
wire n_47;
wire n_42;
wire n_52;
wire n_29;
wire n_48;
wire n_56;
wire n_37;
wire n_43;
wire n_59;
wire n_27;
wire n_35;
wire n_61;
wire n_28;
wire n_40;
wire n_46;
wire n_50;

INVx1_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

AND2x6_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_14),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_4),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_5),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_2),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_6),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_8),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_21),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_24),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_24),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_29),
.B(n_26),
.Y(n_40)
);

A2O1A1Ixp33_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_22),
.B(n_13),
.C(n_20),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_29),
.B(n_23),
.Y(n_42)
);

O2A1O1Ixp33_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_42),
.B(n_37),
.C(n_30),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_27),
.B1(n_28),
.B2(n_31),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_39),
.A2(n_31),
.B1(n_34),
.B2(n_33),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_40),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_44),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_35),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_32),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_28),
.B1(n_15),
.B2(n_12),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_49),
.Y(n_54)
);

NOR2x1_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_28),
.Y(n_55)
);

OAI21xp5_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_28),
.B(n_16),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_28),
.B1(n_22),
.B2(n_13),
.Y(n_57)
);

OR5x1_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_25),
.C(n_23),
.D(n_11),
.E(n_10),
.Y(n_58)
);

NAND2xp33_ASAP7_75t_R g59 ( 
.A(n_55),
.B(n_17),
.Y(n_59)
);

NAND2x1_ASAP7_75t_L g60 ( 
.A(n_57),
.B(n_19),
.Y(n_60)
);

INVx1_ASAP7_75t_SL g61 ( 
.A(n_58),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_SL g62 ( 
.A(n_61),
.B(n_59),
.Y(n_62)
);

AOI322xp5_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_60),
.A3(n_7),
.B1(n_0),
.B2(n_3),
.C1(n_1),
.C2(n_9),
.Y(n_63)
);


endmodule