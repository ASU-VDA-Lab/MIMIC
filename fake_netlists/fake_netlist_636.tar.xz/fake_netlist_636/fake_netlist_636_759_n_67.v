module fake_netlist_636_759_n_67 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_17, n_16, n_19, n_67);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_17;
input n_16;
input n_19;

output n_67;

wire n_53;
wire n_62;
wire n_63;
wire n_34;
wire n_49;
wire n_39;
wire n_51;
wire n_54;
wire n_25;
wire n_30;
wire n_32;
wire n_65;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_22;
wire n_38;
wire n_45;
wire n_57;
wire n_36;
wire n_55;
wire n_58;
wire n_60;
wire n_47;
wire n_23;
wire n_42;
wire n_52;
wire n_66;
wire n_29;
wire n_48;
wire n_56;
wire n_64;
wire n_37;
wire n_21;
wire n_43;
wire n_59;
wire n_27;
wire n_35;
wire n_61;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_24;
wire n_50;

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_0),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_6),
.B(n_15),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_11),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_19),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_11),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_18),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_9),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_23),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_27),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

AND2x2_ASAP7_75t_SL g37 ( 
.A(n_25),
.B(n_20),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_22),
.B(n_19),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_29),
.Y(n_40)
);

NAND2xp33_ASAP7_75t_SL g41 ( 
.A(n_35),
.B(n_26),
.Y(n_41)
);

CKINVDCx16_ASAP7_75t_R g42 ( 
.A(n_36),
.Y(n_42)
);

BUFx3_ASAP7_75t_L g43 ( 
.A(n_36),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_37),
.A2(n_26),
.B1(n_21),
.B2(n_22),
.Y(n_44)
);

OAI21x1_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_39),
.B(n_28),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_33),
.B1(n_24),
.B2(n_34),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_42),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_R g50 ( 
.A(n_48),
.B(n_41),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_47),
.Y(n_52)
);

INVx1_ASAP7_75t_SL g53 ( 
.A(n_52),
.Y(n_53)
);

AOI21xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_45),
.B(n_41),
.Y(n_54)
);

NAND2x1p5_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_33),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_50),
.Y(n_56)
);

NAND2x1p5_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_50),
.Y(n_57)
);

A2O1A1Ixp33_ASAP7_75t_SL g58 ( 
.A1(n_54),
.A2(n_38),
.B(n_21),
.C(n_2),
.Y(n_58)
);

XOR2x2_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_18),
.Y(n_59)
);

AOI221xp5_ASAP7_75t_L g60 ( 
.A1(n_56),
.A2(n_17),
.B1(n_13),
.B2(n_14),
.C(n_10),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_59),
.Y(n_61)
);

XNOR2xp5_ASAP7_75t_L g62 ( 
.A(n_60),
.B(n_5),
.Y(n_62)
);

OR2x2_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_3),
.Y(n_63)
);

OA21x2_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_7),
.B(n_45),
.Y(n_64)
);

NOR2xp33_ASAP7_75t_L g65 ( 
.A(n_61),
.B(n_62),
.Y(n_65)
);

NOR2x1_ASAP7_75t_L g66 ( 
.A(n_61),
.B(n_63),
.Y(n_66)
);

AOI22xp33_ASAP7_75t_L g67 ( 
.A1(n_66),
.A2(n_63),
.B1(n_64),
.B2(n_65),
.Y(n_67)
);


endmodule