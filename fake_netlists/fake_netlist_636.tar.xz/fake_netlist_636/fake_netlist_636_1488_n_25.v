module fake_netlist_636_1488_n_25 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_13, n_11, n_25);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_13;
input n_11;

output n_25;

wire n_18;
wire n_22;
wire n_20;
wire n_15;
wire n_23;
wire n_14;
wire n_21;
wire n_17;
wire n_16;
wire n_19;
wire n_24;

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_6),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_1),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_15),
.B(n_14),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_15),
.B1(n_16),
.B2(n_1),
.C(n_0),
.Y(n_22)
);

AOI222xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_2),
.B1(n_0),
.B2(n_12),
.C1(n_9),
.C2(n_8),
.Y(n_23)
);

AOI22x1_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_2),
.B1(n_4),
.B2(n_7),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_3),
.B(n_21),
.Y(n_25)
);


endmodule