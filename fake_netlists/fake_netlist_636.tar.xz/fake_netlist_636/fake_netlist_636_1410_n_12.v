module fake_netlist_636_1410_n_12 (n_2, n_3, n_0, n_1, n_12);

input n_2;
input n_3;
input n_0;
input n_1;

output n_12;

wire n_5;
wire n_7;
wire n_9;
wire n_4;
wire n_8;
wire n_10;
wire n_6;
wire n_11;

AOI22xp33_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_4),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NAND2x1_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_7),
.Y(n_10)
);

AO21x2_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B(n_2),
.Y(n_11)
);

XNOR2x1_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_6),
.Y(n_12)
);


endmodule