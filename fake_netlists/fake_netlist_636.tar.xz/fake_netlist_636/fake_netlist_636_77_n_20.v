module fake_netlist_636_77_n_20 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_10, n_6, n_20);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_10;
input n_6;

output n_20;

wire n_18;
wire n_13;
wire n_11;
wire n_15;
wire n_12;
wire n_14;
wire n_17;
wire n_16;
wire n_19;

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_2),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_SL g15 ( 
.A1(n_11),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.C(n_10),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_12),
.B2(n_13),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_3),
.B1(n_0),
.B2(n_6),
.Y(n_20)
);


endmodule