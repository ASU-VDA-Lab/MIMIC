module fake_netlist_636_1593_n_39 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_10, n_6, n_11, n_39);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_10;
input n_6;
input n_11;

output n_39;

wire n_18;
wire n_34;
wire n_13;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_20;
wire n_22;
wire n_38;
wire n_36;
wire n_15;
wire n_23;
wire n_12;
wire n_14;
wire n_29;
wire n_21;
wire n_37;
wire n_27;
wire n_35;
wire n_17;
wire n_26;
wire n_16;
wire n_19;
wire n_28;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_0),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

INVx2_ASAP7_75t_SL g19 ( 
.A(n_15),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_15),
.B1(n_18),
.B2(n_17),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_18),
.B1(n_17),
.B2(n_19),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_14),
.B1(n_12),
.B2(n_13),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_16),
.Y(n_28)
);

NAND4xp25_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_16),
.C(n_20),
.D(n_21),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_24),
.Y(n_30)
);

INVx4_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_24),
.B(n_21),
.Y(n_32)
);

OA22x2_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_1),
.B1(n_5),
.B2(n_4),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_1),
.B1(n_5),
.B2(n_4),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_2),
.C(n_3),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_34),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_35),
.Y(n_38)
);

AOI222xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_37),
.B1(n_36),
.B2(n_2),
.C1(n_0),
.C2(n_10),
.Y(n_39)
);


endmodule