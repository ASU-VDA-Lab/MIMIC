module fake_netlist_636_1315_n_15 (n_0, n_1, n_4, n_3, n_2, n_15);

input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_15;

wire n_5;
wire n_7;
wire n_9;
wire n_8;
wire n_12;
wire n_14;
wire n_10;
wire n_6;
wire n_13;
wire n_11;

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_SL g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

AO31x2_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_0),
.A3(n_1),
.B(n_3),
.Y(n_8)
);

NAND3xp33_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_3),
.C(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI21xp33_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_1),
.B(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

NOR2xp67_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_2),
.Y(n_13)
);

OR3x1_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_8),
.C(n_12),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);


endmodule