module fake_netlist_636_1699_n_34 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_16, n_10, n_17, n_6, n_13, n_11, n_34);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_16;
input n_10;
input n_17;
input n_6;
input n_13;
input n_11;

output n_34;

wire n_18;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_22;
wire n_20;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_7),
.B(n_8),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

AOI21x1_ASAP7_75t_L g23 ( 
.A1(n_2),
.A2(n_3),
.B(n_1),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_23),
.B(n_15),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_18),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_22),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_28),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_27),
.B1(n_21),
.B2(n_20),
.C(n_19),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_13),
.Y(n_31)
);

CKINVDCx16_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_17),
.B1(n_16),
.B2(n_9),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.A3(n_12),
.B1(n_4),
.B2(n_10),
.C1(n_6),
.C2(n_14),
.Y(n_34)
);


endmodule