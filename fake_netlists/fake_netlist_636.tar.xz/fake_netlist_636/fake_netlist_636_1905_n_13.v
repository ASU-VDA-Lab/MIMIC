module fake_netlist_636_1905_n_13 (n_2, n_3, n_0, n_1, n_13);

input n_2;
input n_3;
input n_0;
input n_1;

output n_13;

wire n_5;
wire n_7;
wire n_9;
wire n_4;
wire n_8;
wire n_12;
wire n_10;
wire n_6;
wire n_11;

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_3),
.B(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_SL g9 ( 
.A1(n_6),
.A2(n_4),
.B(n_2),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_9),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_4),
.B(n_7),
.C(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);


endmodule