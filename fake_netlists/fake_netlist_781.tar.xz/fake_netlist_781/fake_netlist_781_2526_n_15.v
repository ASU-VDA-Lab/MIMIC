module fake_netlist_781_2526_n_15 (n_1, n_2, n_0, n_15);

input n_1;
input n_2;
input n_0;

output n_15;

wire n_7;
wire n_10;
wire n_13;
wire n_11;
wire n_5;
wire n_6;
wire n_3;
wire n_9;
wire n_12;
wire n_14;
wire n_4;
wire n_8;

AND2x6_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

OAI22xp5_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_3),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_3),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_6),
.B1(n_3),
.B2(n_2),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_3),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B(n_1),
.C(n_0),
.Y(n_11)
);

AOI222xp33_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_7),
.B1(n_8),
.B2(n_6),
.C1(n_5),
.C2(n_4),
.Y(n_12)
);

NOR3xp33_ASAP7_75t_SL g13 ( 
.A(n_11),
.B(n_7),
.C(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_7),
.B1(n_12),
.B2(n_13),
.Y(n_15)
);


endmodule