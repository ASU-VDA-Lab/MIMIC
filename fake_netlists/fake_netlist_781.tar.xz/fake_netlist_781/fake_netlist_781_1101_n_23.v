module fake_netlist_781_1101_n_23 (n_1, n_2, n_3, n_0, n_23);

input n_1;
input n_2;
input n_3;
input n_0;

output n_23;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_5;
wire n_18;
wire n_13;
wire n_15;
wire n_16;
wire n_11;
wire n_4;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_3),
.B(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

BUFx8_ASAP7_75t_SL g9 ( 
.A(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVxp67_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.B(n_5),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_4),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_10),
.B(n_6),
.C(n_4),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_8),
.B(n_6),
.Y(n_16)
);

OAI321xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.A3(n_8),
.B1(n_1),
.B2(n_0),
.C(n_2),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_8),
.C(n_2),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_8),
.B1(n_3),
.B2(n_0),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_22),
.B1(n_15),
.B2(n_21),
.Y(n_23)
);


endmodule