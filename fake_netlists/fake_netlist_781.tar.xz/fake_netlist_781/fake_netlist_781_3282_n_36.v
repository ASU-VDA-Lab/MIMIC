module fake_netlist_781_3282_n_36 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_36);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_36;

wire n_20;
wire n_29;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_18;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

NAND2xp33_ASAP7_75t_R g16 ( 
.A(n_10),
.B(n_12),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_11),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_15),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_2),
.B(n_9),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_0),
.Y(n_23)
);

OAI21x1_ASAP7_75t_SL g24 ( 
.A1(n_20),
.A2(n_5),
.B(n_4),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_14),
.B1(n_5),
.B2(n_4),
.Y(n_25)
);

AND2x6_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_26),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_29),
.B(n_28),
.Y(n_30)
);

AND3x1_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_27),
.C(n_20),
.Y(n_31)
);

AOI311xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_15),
.A3(n_14),
.B(n_26),
.C(n_16),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_18),
.B(n_22),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_32),
.Y(n_34)
);

OAI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_33),
.B1(n_19),
.B2(n_17),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_23),
.B1(n_13),
.B2(n_6),
.Y(n_36)
);


endmodule