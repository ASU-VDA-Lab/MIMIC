module fake_netlist_781_1819_n_4 (n_1, n_0, n_4);

input n_1;
input n_0;

output n_4;

wire n_3;
wire n_2;

INVx2_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

OR2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);


endmodule