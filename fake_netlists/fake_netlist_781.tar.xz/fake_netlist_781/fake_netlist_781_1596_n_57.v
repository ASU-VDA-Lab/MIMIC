module fake_netlist_781_1596_n_57 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_57);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_57;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_20;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_17;
wire n_50;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_18;
wire n_49;
wire n_43;
wire n_48;
wire n_15;
wire n_56;
wire n_16;
wire n_38;
wire n_54;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;
wire n_14;

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_1),
.B(n_9),
.Y(n_14)
);

OA21x2_ASAP7_75t_L g15 ( 
.A1(n_3),
.A2(n_4),
.B(n_7),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_5),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_10),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

OR2x6_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_4),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_7),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_23),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_0),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_17),
.B(n_11),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_24),
.A2(n_27),
.B1(n_15),
.B2(n_26),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_24),
.A2(n_20),
.B1(n_19),
.B2(n_29),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_26),
.B(n_19),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_27),
.B1(n_15),
.B2(n_24),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_31),
.B(n_24),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_34),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

NOR2xp67_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_32),
.Y(n_44)
);

NOR3xp33_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_14),
.C(n_20),
.Y(n_45)
);

HAxp5_ASAP7_75t_SL g46 ( 
.A(n_41),
.B(n_36),
.CON(n_46),
.SN(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_44),
.A2(n_36),
.B1(n_27),
.B2(n_15),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_45),
.Y(n_50)
);

NAND5xp2_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_45),
.C(n_22),
.D(n_16),
.E(n_12),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_30),
.Y(n_52)
);

OAI221xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_16),
.B1(n_28),
.B2(n_30),
.C(n_47),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_47),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_54),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

AOI311xp33_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_16),
.A3(n_51),
.B(n_53),
.C(n_55),
.Y(n_57)
);


endmodule