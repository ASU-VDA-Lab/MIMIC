module fake_netlist_781_3358_n_39 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_39);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_39;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_26;
wire n_24;
wire n_18;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_11),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_5),
.B(n_6),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_22),
.B1(n_24),
.B2(n_26),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_R g28 ( 
.A(n_24),
.B(n_22),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_22),
.B1(n_18),
.B2(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_18),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_29),
.B(n_20),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_31),
.Y(n_33)
);

INVxp67_ASAP7_75t_SL g34 ( 
.A(n_33),
.Y(n_34)
);

AOI222xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_16),
.B1(n_15),
.B2(n_4),
.C1(n_1),
.C2(n_0),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

NOR3xp33_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_16),
.C(n_2),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI322xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_37),
.A3(n_8),
.B1(n_7),
.B2(n_3),
.C1(n_12),
.C2(n_10),
.Y(n_39)
);


endmodule