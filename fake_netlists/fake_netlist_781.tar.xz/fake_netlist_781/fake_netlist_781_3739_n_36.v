module fake_netlist_781_3739_n_36 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_36);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_36;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_5),
.B(n_8),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_0),
.B(n_11),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_10),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_4),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_16),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_18),
.B(n_4),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_19),
.Y(n_25)
);

OAI22xp33_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_15),
.B1(n_20),
.B2(n_14),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

XNOR2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

AOI21x1_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_14),
.B(n_17),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_29),
.B(n_22),
.Y(n_32)
);

XNOR2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_29),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_33),
.Y(n_35)
);

OAI221xp5_ASAP7_75t_R g36 ( 
.A1(n_35),
.A2(n_34),
.B1(n_7),
.B2(n_1),
.C(n_2),
.Y(n_36)
);


endmodule