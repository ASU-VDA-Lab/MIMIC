module fake_netlist_786_226_n_15 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_15);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_15;

wire n_7;
wire n_10;
wire n_11;
wire n_14;
wire n_9;
wire n_12;
wire n_13;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

BUFx3_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

OAI332xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.A3(n_7),
.B1(n_3),
.B2(n_1),
.B3(n_5),
.C1(n_4),
.C2(n_2),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.B1(n_9),
.B2(n_10),
.C1(n_8),
.C2(n_2),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B1(n_4),
.B2(n_3),
.Y(n_14)
);

AOI21x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_6),
.B(n_5),
.Y(n_15)
);


endmodule