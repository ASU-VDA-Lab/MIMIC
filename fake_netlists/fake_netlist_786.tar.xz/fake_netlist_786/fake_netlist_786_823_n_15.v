module fake_netlist_786_823_n_15 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_15);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_15;

wire n_7;
wire n_10;
wire n_11;
wire n_14;
wire n_9;
wire n_12;
wire n_13;
wire n_8;

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

OAI221xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_2),
.B1(n_1),
.B2(n_4),
.C(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

NOR4xp25_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.C(n_7),
.D(n_9),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI32xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_6),
.A3(n_4),
.B1(n_2),
.B2(n_3),
.Y(n_15)
);


endmodule