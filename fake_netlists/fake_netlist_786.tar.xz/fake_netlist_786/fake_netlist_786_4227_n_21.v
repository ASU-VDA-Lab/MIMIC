module fake_netlist_786_4227_n_21 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_21);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_21;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_8;
wire n_10;
wire n_19;
wire n_14;

AND2x2_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_5),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_R g9 ( 
.A(n_0),
.B(n_4),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_1),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_6),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_2),
.Y(n_14)
);

AND2x2_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_8),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI221x1_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_7),
.B1(n_9),
.B2(n_13),
.C(n_12),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);


endmodule