module fake_netlist_786_1567_n_344 (n_37, n_0, n_20, n_6, n_29, n_36, n_17, n_2, n_12, n_1, n_35, n_25, n_31, n_5, n_27, n_34, n_33, n_24, n_26, n_18, n_13, n_15, n_11, n_16, n_38, n_23, n_28, n_4, n_9, n_8, n_30, n_7, n_10, n_19, n_21, n_3, n_32, n_22, n_14, n_344);

input n_37;
input n_0;
input n_20;
input n_6;
input n_29;
input n_36;
input n_17;
input n_2;
input n_12;
input n_1;
input n_35;
input n_25;
input n_31;
input n_5;
input n_27;
input n_34;
input n_33;
input n_24;
input n_26;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_38;
input n_23;
input n_28;
input n_4;
input n_9;
input n_8;
input n_30;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_32;
input n_22;
input n_14;

output n_344;

wire n_324;
wire n_100;
wire n_325;
wire n_101;
wire n_232;
wire n_186;
wire n_187;
wire n_107;
wire n_222;
wire n_184;
wire n_179;
wire n_297;
wire n_308;
wire n_301;
wire n_181;
wire n_51;
wire n_255;
wire n_207;
wire n_143;
wire n_201;
wire n_216;
wire n_341;
wire n_117;
wire n_279;
wire n_204;
wire n_128;
wire n_88;
wire n_275;
wire n_290;
wire n_155;
wire n_342;
wire n_126;
wire n_82;
wire n_129;
wire n_150;
wire n_176;
wire n_167;
wire n_303;
wire n_234;
wire n_209;
wire n_294;
wire n_215;
wire n_56;
wire n_300;
wire n_236;
wire n_78;
wire n_161;
wire n_259;
wire n_149;
wire n_159;
wire n_240;
wire n_173;
wire n_141;
wire n_211;
wire n_154;
wire n_193;
wire n_330;
wire n_113;
wire n_256;
wire n_239;
wire n_250;
wire n_191;
wire n_332;
wire n_87;
wire n_328;
wire n_115;
wire n_120;
wire n_264;
wire n_242;
wire n_221;
wire n_318;
wire n_116;
wire n_254;
wire n_140;
wire n_337;
wire n_287;
wire n_65;
wire n_283;
wire n_278;
wire n_73;
wire n_293;
wire n_271;
wire n_68;
wire n_273;
wire n_231;
wire n_312;
wire n_311;
wire n_127;
wire n_166;
wire n_284;
wire n_53;
wire n_74;
wire n_146;
wire n_220;
wire n_182;
wire n_178;
wire n_168;
wire n_246;
wire n_280;
wire n_102;
wire n_302;
wire n_224;
wire n_62;
wire n_270;
wire n_169;
wire n_245;
wire n_148;
wire n_175;
wire n_202;
wire n_195;
wire n_217;
wire n_267;
wire n_331;
wire n_327;
wire n_152;
wire n_86;
wire n_266;
wire n_177;
wire n_298;
wire n_70;
wire n_125;
wire n_262;
wire n_69;
wire n_137;
wire n_233;
wire n_212;
wire n_145;
wire n_133;
wire n_194;
wire n_109;
wire n_340;
wire n_157;
wire n_329;
wire n_203;
wire n_320;
wire n_323;
wire n_260;
wire n_111;
wire n_307;
wire n_170;
wire n_47;
wire n_200;
wire n_288;
wire n_163;
wire n_130;
wire n_160;
wire n_97;
wire n_94;
wire n_39;
wire n_309;
wire n_136;
wire n_135;
wire n_296;
wire n_114;
wire n_223;
wire n_99;
wire n_192;
wire n_60;
wire n_93;
wire n_247;
wire n_131;
wire n_252;
wire n_41;
wire n_299;
wire n_63;
wire n_244;
wire n_291;
wire n_119;
wire n_42;
wire n_105;
wire n_225;
wire n_219;
wire n_132;
wire n_210;
wire n_213;
wire n_59;
wire n_104;
wire n_85;
wire n_106;
wire n_241;
wire n_333;
wire n_253;
wire n_289;
wire n_326;
wire n_321;
wire n_268;
wire n_185;
wire n_249;
wire n_174;
wire n_199;
wire n_229;
wire n_214;
wire n_84;
wire n_317;
wire n_315;
wire n_103;
wire n_147;
wire n_164;
wire n_123;
wire n_198;
wire n_64;
wire n_188;
wire n_251;
wire n_92;
wire n_285;
wire n_295;
wire n_71;
wire n_258;
wire n_49;
wire n_142;
wire n_190;
wire n_110;
wire n_272;
wire n_118;
wire n_277;
wire n_205;
wire n_261;
wire n_343;
wire n_336;
wire n_58;
wire n_50;
wire n_108;
wire n_66;
wire n_263;
wire n_95;
wire n_98;
wire n_57;
wire n_134;
wire n_237;
wire n_314;
wire n_238;
wire n_72;
wire n_183;
wire n_55;
wire n_281;
wire n_153;
wire n_40;
wire n_316;
wire n_124;
wire n_48;
wire n_43;
wire n_158;
wire n_276;
wire n_67;
wire n_54;
wire n_257;
wire n_197;
wire n_227;
wire n_79;
wire n_89;
wire n_45;
wire n_83;
wire n_75;
wire n_334;
wire n_165;
wire n_121;
wire n_96;
wire n_235;
wire n_180;
wire n_76;
wire n_171;
wire n_230;
wire n_156;
wire n_90;
wire n_139;
wire n_286;
wire n_151;
wire n_338;
wire n_196;
wire n_228;
wire n_189;
wire n_292;
wire n_91;
wire n_305;
wire n_265;
wire n_313;
wire n_122;
wire n_61;
wire n_218;
wire n_335;
wire n_112;
wire n_310;
wire n_172;
wire n_44;
wire n_52;
wire n_77;
wire n_138;
wire n_248;
wire n_206;
wire n_282;
wire n_162;
wire n_274;
wire n_243;
wire n_46;
wire n_144;
wire n_81;
wire n_269;
wire n_304;
wire n_339;
wire n_80;
wire n_208;
wire n_306;
wire n_226;
wire n_319;
wire n_322;

CKINVDCx16_ASAP7_75t_R g39 ( 
.A(n_4),
.Y(n_39)
);

CKINVDCx20_ASAP7_75t_R g40 ( 
.A(n_36),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_14),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_23),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_3),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_37),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_12),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_7),
.Y(n_46)
);

INVxp67_ASAP7_75t_SL g47 ( 
.A(n_33),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_1),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_15),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_28),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_4),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_14),
.Y(n_52)
);

CKINVDCx16_ASAP7_75t_R g53 ( 
.A(n_16),
.Y(n_53)
);

BUFx6f_ASAP7_75t_L g54 ( 
.A(n_24),
.Y(n_54)
);

BUFx2_ASAP7_75t_L g55 ( 
.A(n_2),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_6),
.Y(n_56)
);

INVxp67_ASAP7_75t_SL g57 ( 
.A(n_3),
.Y(n_57)
);

CKINVDCx5p33_ASAP7_75t_R g58 ( 
.A(n_38),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_34),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_17),
.Y(n_60)
);

CKINVDCx5p33_ASAP7_75t_R g61 ( 
.A(n_18),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_7),
.Y(n_62)
);

CKINVDCx20_ASAP7_75t_R g63 ( 
.A(n_40),
.Y(n_63)
);

CKINVDCx20_ASAP7_75t_R g64 ( 
.A(n_58),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_43),
.Y(n_65)
);

INVx3_ASAP7_75t_L g66 ( 
.A(n_54),
.Y(n_66)
);

CKINVDCx5p33_ASAP7_75t_R g67 ( 
.A(n_61),
.Y(n_67)
);

INVx4_ASAP7_75t_L g68 ( 
.A(n_54),
.Y(n_68)
);

INVx2_ASAP7_75t_L g69 ( 
.A(n_54),
.Y(n_69)
);

CKINVDCx5p33_ASAP7_75t_R g70 ( 
.A(n_53),
.Y(n_70)
);

CKINVDCx20_ASAP7_75t_R g71 ( 
.A(n_46),
.Y(n_71)
);

CKINVDCx5p33_ASAP7_75t_R g72 ( 
.A(n_39),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_43),
.Y(n_73)
);

CKINVDCx5p33_ASAP7_75t_R g74 ( 
.A(n_39),
.Y(n_74)
);

INVx2_ASAP7_75t_L g75 ( 
.A(n_54),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_41),
.Y(n_76)
);

CKINVDCx5p33_ASAP7_75t_R g77 ( 
.A(n_45),
.Y(n_77)
);

INVx2_ASAP7_75t_L g78 ( 
.A(n_54),
.Y(n_78)
);

INVx2_ASAP7_75t_L g79 ( 
.A(n_54),
.Y(n_79)
);

CKINVDCx5p33_ASAP7_75t_R g80 ( 
.A(n_48),
.Y(n_80)
);

BUFx6f_ASAP7_75t_L g81 ( 
.A(n_42),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_41),
.Y(n_82)
);

CKINVDCx5p33_ASAP7_75t_R g83 ( 
.A(n_55),
.Y(n_83)
);

AO22x2_ASAP7_75t_L g84 ( 
.A1(n_76),
.A2(n_52),
.B1(n_51),
.B2(n_49),
.Y(n_84)
);

NAND2x1p5_ASAP7_75t_L g85 ( 
.A(n_76),
.B(n_55),
.Y(n_85)
);

INVxp67_ASAP7_75t_L g86 ( 
.A(n_72),
.Y(n_86)
);

INVx2_ASAP7_75t_L g87 ( 
.A(n_69),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_81),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_81),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_69),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_81),
.Y(n_91)
);

INVxp67_ASAP7_75t_L g92 ( 
.A(n_74),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_81),
.Y(n_93)
);

BUFx3_ASAP7_75t_L g94 ( 
.A(n_64),
.Y(n_94)
);

AOI22xp33_ASAP7_75t_L g95 ( 
.A1(n_82),
.A2(n_52),
.B1(n_51),
.B2(n_49),
.Y(n_95)
);

NOR2xp33_ASAP7_75t_L g96 ( 
.A(n_77),
.B(n_42),
.Y(n_96)
);

NOR3xp33_ASAP7_75t_L g97 ( 
.A(n_83),
.B(n_57),
.C(n_56),
.Y(n_97)
);

AND2x4_ASAP7_75t_L g98 ( 
.A(n_68),
.B(n_44),
.Y(n_98)
);

NAND3xp33_ASAP7_75t_L g99 ( 
.A(n_80),
.B(n_60),
.C(n_56),
.Y(n_99)
);

INVx1_ASAP7_75t_L g100 ( 
.A(n_81),
.Y(n_100)
);

AOI22xp33_ASAP7_75t_L g101 ( 
.A1(n_82),
.A2(n_62),
.B1(n_60),
.B2(n_44),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_81),
.Y(n_102)
);

OAI221xp5_ASAP7_75t_L g103 ( 
.A1(n_65),
.A2(n_62),
.B1(n_59),
.B2(n_50),
.C(n_47),
.Y(n_103)
);

NOR2xp33_ASAP7_75t_L g104 ( 
.A(n_67),
.B(n_50),
.Y(n_104)
);

INVxp67_ASAP7_75t_L g105 ( 
.A(n_70),
.Y(n_105)
);

INVxp67_ASAP7_75t_L g106 ( 
.A(n_65),
.Y(n_106)
);

AND2x4_ASAP7_75t_L g107 ( 
.A(n_68),
.B(n_59),
.Y(n_107)
);

AND2x4_ASAP7_75t_L g108 ( 
.A(n_68),
.B(n_19),
.Y(n_108)
);

NOR2xp33_ASAP7_75t_SL g109 ( 
.A(n_68),
.B(n_0),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_73),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_66),
.B(n_20),
.Y(n_111)
);

AND2x4_ASAP7_75t_L g112 ( 
.A(n_66),
.B(n_21),
.Y(n_112)
);

AO22x2_ASAP7_75t_L g113 ( 
.A1(n_66),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_73),
.Y(n_114)
);

CKINVDCx20_ASAP7_75t_R g115 ( 
.A(n_63),
.Y(n_115)
);

NAND2xp5_ASAP7_75t_L g116 ( 
.A(n_104),
.B(n_66),
.Y(n_116)
);

NAND2xp5_ASAP7_75t_SL g117 ( 
.A(n_85),
.B(n_71),
.Y(n_117)
);

A2O1A1Ixp33_ASAP7_75t_L g118 ( 
.A1(n_96),
.A2(n_78),
.B(n_75),
.C(n_69),
.Y(n_118)
);

A2O1A1Ixp33_ASAP7_75t_L g119 ( 
.A1(n_96),
.A2(n_79),
.B(n_78),
.C(n_75),
.Y(n_119)
);

HB1xp67_ASAP7_75t_L g120 ( 
.A(n_85),
.Y(n_120)
);

INVx1_ASAP7_75t_L g121 ( 
.A(n_107),
.Y(n_121)
);

NAND2xp5_ASAP7_75t_L g122 ( 
.A(n_104),
.B(n_75),
.Y(n_122)
);

NOR2xp33_ASAP7_75t_L g123 ( 
.A(n_86),
.B(n_78),
.Y(n_123)
);

CKINVDCx20_ASAP7_75t_R g124 ( 
.A(n_115),
.Y(n_124)
);

INVx1_ASAP7_75t_L g125 ( 
.A(n_107),
.Y(n_125)
);

NAND2xp5_ASAP7_75t_L g126 ( 
.A(n_98),
.B(n_79),
.Y(n_126)
);

NOR2xp33_ASAP7_75t_L g127 ( 
.A(n_92),
.B(n_79),
.Y(n_127)
);

AOI22xp33_ASAP7_75t_L g128 ( 
.A1(n_113),
.A2(n_8),
.B1(n_6),
.B2(n_5),
.Y(n_128)
);

AO32x1_ASAP7_75t_L g129 ( 
.A1(n_110),
.A2(n_8),
.A3(n_5),
.B1(n_9),
.B2(n_10),
.Y(n_129)
);

NAND2xp5_ASAP7_75t_SL g130 ( 
.A(n_109),
.B(n_9),
.Y(n_130)
);

NAND2xp5_ASAP7_75t_L g131 ( 
.A(n_98),
.B(n_22),
.Y(n_131)
);

INVxp67_ASAP7_75t_L g132 ( 
.A(n_99),
.Y(n_132)
);

OR2x6_ASAP7_75t_L g133 ( 
.A(n_113),
.B(n_10),
.Y(n_133)
);

NAND2xp5_ASAP7_75t_L g134 ( 
.A(n_98),
.B(n_25),
.Y(n_134)
);

NAND2xp5_ASAP7_75t_L g135 ( 
.A(n_107),
.B(n_26),
.Y(n_135)
);

NOR2xp67_ASAP7_75t_L g136 ( 
.A(n_88),
.B(n_27),
.Y(n_136)
);

AOI21xp5_ASAP7_75t_L g137 ( 
.A1(n_89),
.A2(n_30),
.B(n_29),
.Y(n_137)
);

NAND2x1p5_ASAP7_75t_L g138 ( 
.A(n_108),
.B(n_31),
.Y(n_138)
);

NAND2xp5_ASAP7_75t_SL g139 ( 
.A(n_105),
.B(n_11),
.Y(n_139)
);

INVx2_ASAP7_75t_L g140 ( 
.A(n_87),
.Y(n_140)
);

NAND2xp5_ASAP7_75t_SL g141 ( 
.A(n_108),
.B(n_11),
.Y(n_141)
);

NAND2xp5_ASAP7_75t_L g142 ( 
.A(n_91),
.B(n_32),
.Y(n_142)
);

AND2x2_ASAP7_75t_L g143 ( 
.A(n_106),
.B(n_35),
.Y(n_143)
);

INVx2_ASAP7_75t_L g144 ( 
.A(n_87),
.Y(n_144)
);

NAND2xp5_ASAP7_75t_L g145 ( 
.A(n_93),
.B(n_100),
.Y(n_145)
);

OAI22xp5_ASAP7_75t_L g146 ( 
.A1(n_101),
.A2(n_15),
.B1(n_13),
.B2(n_12),
.Y(n_146)
);

AOI21xp5_ASAP7_75t_L g147 ( 
.A1(n_102),
.A2(n_16),
.B(n_13),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_90),
.Y(n_148)
);

NAND2xp5_ASAP7_75t_L g149 ( 
.A(n_108),
.B(n_17),
.Y(n_149)
);

OAI21x1_ASAP7_75t_L g150 ( 
.A1(n_126),
.A2(n_111),
.B(n_101),
.Y(n_150)
);

AND2x2_ASAP7_75t_L g151 ( 
.A(n_132),
.B(n_133),
.Y(n_151)
);

A2O1A1Ixp33_ASAP7_75t_L g152 ( 
.A1(n_121),
.A2(n_112),
.B(n_103),
.C(n_97),
.Y(n_152)
);

AO21x2_ASAP7_75t_L g153 ( 
.A1(n_149),
.A2(n_112),
.B(n_90),
.Y(n_153)
);

CKINVDCx20_ASAP7_75t_R g154 ( 
.A(n_124),
.Y(n_154)
);

INVx2_ASAP7_75t_L g155 ( 
.A(n_140),
.Y(n_155)
);

AO31x2_ASAP7_75t_L g156 ( 
.A1(n_146),
.A2(n_114),
.A3(n_113),
.B(n_84),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_121),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_125),
.Y(n_158)
);

INVx2_ASAP7_75t_L g159 ( 
.A(n_140),
.Y(n_159)
);

NOR2xp67_ASAP7_75t_L g160 ( 
.A(n_125),
.B(n_112),
.Y(n_160)
);

OR2x2_ASAP7_75t_L g161 ( 
.A(n_120),
.B(n_94),
.Y(n_161)
);

AND2x2_ASAP7_75t_L g162 ( 
.A(n_133),
.B(n_84),
.Y(n_162)
);

INVx2_ASAP7_75t_L g163 ( 
.A(n_144),
.Y(n_163)
);

AND2x4_ASAP7_75t_L g164 ( 
.A(n_141),
.B(n_95),
.Y(n_164)
);

OAI21x1_ASAP7_75t_L g165 ( 
.A1(n_131),
.A2(n_95),
.B(n_84),
.Y(n_165)
);

OAI21x1_ASAP7_75t_L g166 ( 
.A1(n_135),
.A2(n_94),
.B(n_134),
.Y(n_166)
);

AOI21xp5_ASAP7_75t_L g167 ( 
.A1(n_122),
.A2(n_116),
.B(n_145),
.Y(n_167)
);

NAND3xp33_ASAP7_75t_L g168 ( 
.A(n_128),
.B(n_118),
.C(n_119),
.Y(n_168)
);

OR2x2_ASAP7_75t_L g169 ( 
.A(n_117),
.B(n_133),
.Y(n_169)
);

AOI22x1_ASAP7_75t_L g170 ( 
.A1(n_138),
.A2(n_143),
.B1(n_144),
.B2(n_148),
.Y(n_170)
);

AOI22xp5_ASAP7_75t_L g171 ( 
.A1(n_130),
.A2(n_133),
.B1(n_139),
.B2(n_123),
.Y(n_171)
);

INVx2_ASAP7_75t_SL g172 ( 
.A(n_138),
.Y(n_172)
);

OAI21xp5_ASAP7_75t_L g173 ( 
.A1(n_138),
.A2(n_127),
.B(n_143),
.Y(n_173)
);

AO21x1_ASAP7_75t_L g174 ( 
.A1(n_147),
.A2(n_142),
.B(n_129),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_148),
.Y(n_175)
);

INVx2_ASAP7_75t_SL g176 ( 
.A(n_157),
.Y(n_176)
);

NAND2xp5_ASAP7_75t_L g177 ( 
.A(n_157),
.B(n_136),
.Y(n_177)
);

HB1xp67_ASAP7_75t_L g178 ( 
.A(n_151),
.Y(n_178)
);

AOI22xp33_ASAP7_75t_L g179 ( 
.A1(n_164),
.A2(n_136),
.B1(n_137),
.B2(n_124),
.Y(n_179)
);

INVx1_ASAP7_75t_L g180 ( 
.A(n_158),
.Y(n_180)
);

BUFx8_ASAP7_75t_SL g181 ( 
.A(n_154),
.Y(n_181)
);

AND2x2_ASAP7_75t_SL g182 ( 
.A(n_164),
.B(n_129),
.Y(n_182)
);

NAND2xp5_ASAP7_75t_L g183 ( 
.A(n_158),
.B(n_129),
.Y(n_183)
);

INVx2_ASAP7_75t_L g184 ( 
.A(n_155),
.Y(n_184)
);

OR2x2_ASAP7_75t_L g185 ( 
.A(n_161),
.B(n_129),
.Y(n_185)
);

OAI21xp5_ASAP7_75t_SL g186 ( 
.A1(n_171),
.A2(n_129),
.B(n_164),
.Y(n_186)
);

AND2x2_ASAP7_75t_L g187 ( 
.A(n_164),
.B(n_151),
.Y(n_187)
);

NAND2xp5_ASAP7_75t_L g188 ( 
.A(n_164),
.B(n_167),
.Y(n_188)
);

BUFx6f_ASAP7_75t_L g189 ( 
.A(n_172),
.Y(n_189)
);

O2A1O1Ixp33_ASAP7_75t_L g190 ( 
.A1(n_152),
.A2(n_173),
.B(n_168),
.C(n_175),
.Y(n_190)
);

INVx2_ASAP7_75t_L g191 ( 
.A(n_155),
.Y(n_191)
);

HB1xp67_ASAP7_75t_L g192 ( 
.A(n_178),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_187),
.B(n_162),
.Y(n_193)
);

AOI22xp33_ASAP7_75t_L g194 ( 
.A1(n_182),
.A2(n_168),
.B1(n_173),
.B2(n_151),
.Y(n_194)
);

INVx1_ASAP7_75t_L g195 ( 
.A(n_180),
.Y(n_195)
);

CKINVDCx11_ASAP7_75t_R g196 ( 
.A(n_181),
.Y(n_196)
);

INVx2_ASAP7_75t_L g197 ( 
.A(n_184),
.Y(n_197)
);

OR2x2_ASAP7_75t_L g198 ( 
.A(n_187),
.B(n_161),
.Y(n_198)
);

INVx1_ASAP7_75t_L g199 ( 
.A(n_180),
.Y(n_199)
);

INVx2_ASAP7_75t_L g200 ( 
.A(n_184),
.Y(n_200)
);

BUFx6f_ASAP7_75t_L g201 ( 
.A(n_189),
.Y(n_201)
);

AO31x2_ASAP7_75t_L g202 ( 
.A1(n_183),
.A2(n_174),
.A3(n_167),
.B(n_175),
.Y(n_202)
);

OR2x2_ASAP7_75t_L g203 ( 
.A(n_178),
.B(n_169),
.Y(n_203)
);

AO31x2_ASAP7_75t_L g204 ( 
.A1(n_183),
.A2(n_174),
.A3(n_159),
.B(n_155),
.Y(n_204)
);

INVxp33_ASAP7_75t_L g205 ( 
.A(n_188),
.Y(n_205)
);

AND2x2_ASAP7_75t_L g206 ( 
.A(n_193),
.B(n_205),
.Y(n_206)
);

NAND2xp5_ASAP7_75t_L g207 ( 
.A(n_193),
.B(n_188),
.Y(n_207)
);

INVx2_ASAP7_75t_L g208 ( 
.A(n_197),
.Y(n_208)
);

INVx2_ASAP7_75t_L g209 ( 
.A(n_197),
.Y(n_209)
);

NAND2xp5_ASAP7_75t_L g210 ( 
.A(n_195),
.B(n_199),
.Y(n_210)
);

HB1xp67_ASAP7_75t_L g211 ( 
.A(n_192),
.Y(n_211)
);

NOR2xp33_ASAP7_75t_L g212 ( 
.A(n_198),
.B(n_169),
.Y(n_212)
);

OR2x6_ASAP7_75t_L g213 ( 
.A(n_201),
.B(n_190),
.Y(n_213)
);

AND2x2_ASAP7_75t_L g214 ( 
.A(n_194),
.B(n_162),
.Y(n_214)
);

AND2x2_ASAP7_75t_L g215 ( 
.A(n_194),
.B(n_162),
.Y(n_215)
);

AND2x2_ASAP7_75t_L g216 ( 
.A(n_198),
.B(n_182),
.Y(n_216)
);

AND2x4_ASAP7_75t_L g217 ( 
.A(n_201),
.B(n_176),
.Y(n_217)
);

NOR3xp33_ASAP7_75t_SL g218 ( 
.A(n_195),
.B(n_186),
.C(n_190),
.Y(n_218)
);

AND2x4_ASAP7_75t_L g219 ( 
.A(n_201),
.B(n_176),
.Y(n_219)
);

INVx1_ASAP7_75t_L g220 ( 
.A(n_199),
.Y(n_220)
);

INVx1_ASAP7_75t_L g221 ( 
.A(n_197),
.Y(n_221)
);

OR2x2_ASAP7_75t_L g222 ( 
.A(n_203),
.B(n_185),
.Y(n_222)
);

NAND2xp5_ASAP7_75t_L g223 ( 
.A(n_200),
.B(n_176),
.Y(n_223)
);

NAND2xp5_ASAP7_75t_L g224 ( 
.A(n_212),
.B(n_192),
.Y(n_224)
);

BUFx2_ASAP7_75t_L g225 ( 
.A(n_211),
.Y(n_225)
);

AND2x2_ASAP7_75t_L g226 ( 
.A(n_216),
.B(n_182),
.Y(n_226)
);

AOI22xp5_ASAP7_75t_L g227 ( 
.A1(n_206),
.A2(n_171),
.B1(n_179),
.B2(n_196),
.Y(n_227)
);

INVx1_ASAP7_75t_L g228 ( 
.A(n_220),
.Y(n_228)
);

HB1xp67_ASAP7_75t_L g229 ( 
.A(n_211),
.Y(n_229)
);

NAND2xp5_ASAP7_75t_L g230 ( 
.A(n_206),
.B(n_203),
.Y(n_230)
);

INVx2_ASAP7_75t_SL g231 ( 
.A(n_219),
.Y(n_231)
);

INVx1_ASAP7_75t_L g232 ( 
.A(n_220),
.Y(n_232)
);

INVx1_ASAP7_75t_L g233 ( 
.A(n_210),
.Y(n_233)
);

INVx1_ASAP7_75t_L g234 ( 
.A(n_210),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_221),
.Y(n_235)
);

AOI22xp33_ASAP7_75t_L g236 ( 
.A1(n_214),
.A2(n_215),
.B1(n_207),
.B2(n_216),
.Y(n_236)
);

INVx2_ASAP7_75t_L g237 ( 
.A(n_208),
.Y(n_237)
);

AND2x4_ASAP7_75t_L g238 ( 
.A(n_219),
.B(n_201),
.Y(n_238)
);

INVx1_ASAP7_75t_L g239 ( 
.A(n_221),
.Y(n_239)
);

NAND2xp5_ASAP7_75t_L g240 ( 
.A(n_207),
.B(n_186),
.Y(n_240)
);

OR2x2_ASAP7_75t_L g241 ( 
.A(n_222),
.B(n_214),
.Y(n_241)
);

INVx1_ASAP7_75t_L g242 ( 
.A(n_208),
.Y(n_242)
);

XNOR2xp5_ASAP7_75t_L g243 ( 
.A(n_215),
.B(n_185),
.Y(n_243)
);

NAND2xp5_ASAP7_75t_L g244 ( 
.A(n_222),
.B(n_200),
.Y(n_244)
);

INVx2_ASAP7_75t_L g245 ( 
.A(n_208),
.Y(n_245)
);

OAI21x1_ASAP7_75t_L g246 ( 
.A1(n_223),
.A2(n_166),
.B(n_170),
.Y(n_246)
);

INVx1_ASAP7_75t_L g247 ( 
.A(n_209),
.Y(n_247)
);

AOI22xp33_ASAP7_75t_L g248 ( 
.A1(n_213),
.A2(n_172),
.B1(n_170),
.B2(n_189),
.Y(n_248)
);

OAI21xp33_ASAP7_75t_L g249 ( 
.A1(n_227),
.A2(n_218),
.B(n_177),
.Y(n_249)
);

INVx1_ASAP7_75t_L g250 ( 
.A(n_228),
.Y(n_250)
);

INVx1_ASAP7_75t_L g251 ( 
.A(n_228),
.Y(n_251)
);

AOI311xp33_ASAP7_75t_L g252 ( 
.A1(n_224),
.A2(n_218),
.A3(n_223),
.B(n_177),
.C(n_213),
.Y(n_252)
);

AOI221xp5_ASAP7_75t_L g253 ( 
.A1(n_230),
.A2(n_172),
.B1(n_219),
.B2(n_217),
.C(n_159),
.Y(n_253)
);

NAND2x1_ASAP7_75t_L g254 ( 
.A(n_232),
.B(n_201),
.Y(n_254)
);

XNOR2x2_ASAP7_75t_L g255 ( 
.A(n_243),
.B(n_166),
.Y(n_255)
);

NAND2xp5_ASAP7_75t_L g256 ( 
.A(n_233),
.B(n_209),
.Y(n_256)
);

INVx1_ASAP7_75t_L g257 ( 
.A(n_232),
.Y(n_257)
);

INVx1_ASAP7_75t_SL g258 ( 
.A(n_225),
.Y(n_258)
);

INVx1_ASAP7_75t_L g259 ( 
.A(n_235),
.Y(n_259)
);

CKINVDCx14_ASAP7_75t_R g260 ( 
.A(n_225),
.Y(n_260)
);

OAI22xp5_ASAP7_75t_L g261 ( 
.A1(n_243),
.A2(n_213),
.B1(n_189),
.B2(n_217),
.Y(n_261)
);

INVx1_ASAP7_75t_L g262 ( 
.A(n_235),
.Y(n_262)
);

OAI21xp33_ASAP7_75t_L g263 ( 
.A1(n_240),
.A2(n_213),
.B(n_166),
.Y(n_263)
);

INVx1_ASAP7_75t_L g264 ( 
.A(n_239),
.Y(n_264)
);

NAND2xp5_ASAP7_75t_L g265 ( 
.A(n_233),
.B(n_209),
.Y(n_265)
);

INVx1_ASAP7_75t_L g266 ( 
.A(n_239),
.Y(n_266)
);

INVx2_ASAP7_75t_L g267 ( 
.A(n_237),
.Y(n_267)
);

OR2x6_ASAP7_75t_L g268 ( 
.A(n_231),
.B(n_213),
.Y(n_268)
);

BUFx2_ASAP7_75t_L g269 ( 
.A(n_229),
.Y(n_269)
);

HB1xp67_ASAP7_75t_L g270 ( 
.A(n_244),
.Y(n_270)
);

AOI221xp5_ASAP7_75t_L g271 ( 
.A1(n_236),
.A2(n_217),
.B1(n_163),
.B2(n_159),
.C(n_184),
.Y(n_271)
);

OR2x2_ASAP7_75t_L g272 ( 
.A(n_241),
.B(n_213),
.Y(n_272)
);

INVx1_ASAP7_75t_L g273 ( 
.A(n_242),
.Y(n_273)
);

OAI21xp33_ASAP7_75t_L g274 ( 
.A1(n_234),
.A2(n_165),
.B(n_150),
.Y(n_274)
);

INVx1_ASAP7_75t_SL g275 ( 
.A(n_238),
.Y(n_275)
);

NAND2x1_ASAP7_75t_L g276 ( 
.A(n_234),
.B(n_242),
.Y(n_276)
);

OAI22xp5_ASAP7_75t_L g277 ( 
.A1(n_241),
.A2(n_189),
.B1(n_160),
.B2(n_200),
.Y(n_277)
);

AOI21xp5_ASAP7_75t_SL g278 ( 
.A1(n_261),
.A2(n_189),
.B(n_238),
.Y(n_278)
);

NOR2xp33_ASAP7_75t_L g279 ( 
.A(n_260),
.B(n_231),
.Y(n_279)
);

NOR2xp33_ASAP7_75t_L g280 ( 
.A(n_270),
.B(n_226),
.Y(n_280)
);

NAND3xp33_ASAP7_75t_SL g281 ( 
.A(n_249),
.B(n_248),
.C(n_247),
.Y(n_281)
);

NAND2xp5_ASAP7_75t_L g282 ( 
.A(n_269),
.B(n_226),
.Y(n_282)
);

INVx1_ASAP7_75t_L g283 ( 
.A(n_250),
.Y(n_283)
);

NAND2xp5_ASAP7_75t_L g284 ( 
.A(n_258),
.B(n_247),
.Y(n_284)
);

NAND2xp5_ASAP7_75t_L g285 ( 
.A(n_258),
.B(n_238),
.Y(n_285)
);

AND2x2_ASAP7_75t_L g286 ( 
.A(n_272),
.B(n_238),
.Y(n_286)
);

INVx1_ASAP7_75t_L g287 ( 
.A(n_251),
.Y(n_287)
);

INVx1_ASAP7_75t_L g288 ( 
.A(n_257),
.Y(n_288)
);

INVx3_ASAP7_75t_L g289 ( 
.A(n_268),
.Y(n_289)
);

INVx1_ASAP7_75t_L g290 ( 
.A(n_259),
.Y(n_290)
);

INVx2_ASAP7_75t_L g291 ( 
.A(n_262),
.Y(n_291)
);

INVx2_ASAP7_75t_L g292 ( 
.A(n_264),
.Y(n_292)
);

NOR3xp33_ASAP7_75t_L g293 ( 
.A(n_263),
.B(n_165),
.C(n_246),
.Y(n_293)
);

INVx1_ASAP7_75t_L g294 ( 
.A(n_266),
.Y(n_294)
);

AND2x2_ASAP7_75t_L g295 ( 
.A(n_275),
.B(n_202),
.Y(n_295)
);

NAND2xp5_ASAP7_75t_L g296 ( 
.A(n_275),
.B(n_237),
.Y(n_296)
);

INVxp33_ASAP7_75t_L g297 ( 
.A(n_254),
.Y(n_297)
);

AND2x2_ASAP7_75t_L g298 ( 
.A(n_268),
.B(n_202),
.Y(n_298)
);

NAND2xp5_ASAP7_75t_L g299 ( 
.A(n_265),
.B(n_245),
.Y(n_299)
);

INVx1_ASAP7_75t_L g300 ( 
.A(n_273),
.Y(n_300)
);

NOR2xp33_ASAP7_75t_L g301 ( 
.A(n_261),
.B(n_256),
.Y(n_301)
);

NOR2xp33_ASAP7_75t_L g302 ( 
.A(n_276),
.B(n_245),
.Y(n_302)
);

NOR2xp33_ASAP7_75t_L g303 ( 
.A(n_267),
.B(n_189),
.Y(n_303)
);

OAI211xp5_ASAP7_75t_L g304 ( 
.A1(n_278),
.A2(n_252),
.B(n_255),
.C(n_253),
.Y(n_304)
);

O2A1O1Ixp33_ASAP7_75t_L g305 ( 
.A1(n_281),
.A2(n_277),
.B(n_268),
.C(n_274),
.Y(n_305)
);

AOI211x1_ASAP7_75t_L g306 ( 
.A1(n_282),
.A2(n_271),
.B(n_156),
.C(n_202),
.Y(n_306)
);

NOR4xp25_ASAP7_75t_L g307 ( 
.A(n_285),
.B(n_191),
.C(n_163),
.D(n_202),
.Y(n_307)
);

AOI211xp5_ASAP7_75t_L g308 ( 
.A1(n_278),
.A2(n_165),
.B(n_246),
.C(n_150),
.Y(n_308)
);

CKINVDCx20_ASAP7_75t_R g309 ( 
.A(n_279),
.Y(n_309)
);

INVxp67_ASAP7_75t_L g310 ( 
.A(n_280),
.Y(n_310)
);

NAND2xp5_ASAP7_75t_L g311 ( 
.A(n_286),
.B(n_202),
.Y(n_311)
);

OAI211xp5_ASAP7_75t_SL g312 ( 
.A1(n_284),
.A2(n_191),
.B(n_202),
.C(n_156),
.Y(n_312)
);

NAND2xp5_ASAP7_75t_L g313 ( 
.A(n_286),
.B(n_204),
.Y(n_313)
);

AOI221xp5_ASAP7_75t_SL g314 ( 
.A1(n_283),
.A2(n_156),
.B1(n_204),
.B2(n_150),
.C(n_153),
.Y(n_314)
);

OAI22xp33_ASAP7_75t_L g315 ( 
.A1(n_297),
.A2(n_160),
.B1(n_156),
.B2(n_204),
.Y(n_315)
);

AOI211xp5_ASAP7_75t_L g316 ( 
.A1(n_293),
.A2(n_156),
.B(n_204),
.C(n_153),
.Y(n_316)
);

AOI21xp5_ASAP7_75t_L g317 ( 
.A1(n_302),
.A2(n_296),
.B(n_303),
.Y(n_317)
);

AOI221xp5_ASAP7_75t_L g318 ( 
.A1(n_283),
.A2(n_153),
.B1(n_156),
.B2(n_204),
.C(n_287),
.Y(n_318)
);

AOI221xp5_ASAP7_75t_L g319 ( 
.A1(n_287),
.A2(n_204),
.B1(n_294),
.B2(n_290),
.C(n_288),
.Y(n_319)
);

OR2x2_ASAP7_75t_L g320 ( 
.A(n_311),
.B(n_289),
.Y(n_320)
);

INVx2_ASAP7_75t_SL g321 ( 
.A(n_309),
.Y(n_321)
);

NOR3xp33_ASAP7_75t_L g322 ( 
.A(n_304),
.B(n_289),
.C(n_299),
.Y(n_322)
);

AOI222xp33_ASAP7_75t_L g323 ( 
.A1(n_319),
.A2(n_298),
.B1(n_294),
.B2(n_288),
.C1(n_290),
.C2(n_300),
.Y(n_323)
);

OAI211xp5_ASAP7_75t_L g324 ( 
.A1(n_316),
.A2(n_292),
.B(n_291),
.C(n_295),
.Y(n_324)
);

AOI22xp33_ASAP7_75t_L g325 ( 
.A1(n_310),
.A2(n_317),
.B1(n_312),
.B2(n_318),
.Y(n_325)
);

AOI322xp5_ASAP7_75t_L g326 ( 
.A1(n_315),
.A2(n_291),
.A3(n_292),
.B1(n_313),
.B2(n_314),
.C1(n_306),
.C2(n_305),
.Y(n_326)
);

OAI31xp33_ASAP7_75t_L g327 ( 
.A1(n_315),
.A2(n_292),
.A3(n_307),
.B(n_308),
.Y(n_327)
);

AOI22xp5_ASAP7_75t_L g328 ( 
.A1(n_304),
.A2(n_249),
.B1(n_301),
.B2(n_261),
.Y(n_328)
);

OA21x2_ASAP7_75t_L g329 ( 
.A1(n_319),
.A2(n_317),
.B(n_283),
.Y(n_329)
);

HB1xp67_ASAP7_75t_L g330 ( 
.A(n_320),
.Y(n_330)
);

CKINVDCx5p33_ASAP7_75t_R g331 ( 
.A(n_321),
.Y(n_331)
);

INVx1_ASAP7_75t_SL g332 ( 
.A(n_329),
.Y(n_332)
);

AO22x2_ASAP7_75t_L g333 ( 
.A1(n_324),
.A2(n_322),
.B1(n_327),
.B2(n_329),
.Y(n_333)
);

BUFx2_ASAP7_75t_L g334 ( 
.A(n_328),
.Y(n_334)
);

INVx1_ASAP7_75t_L g335 ( 
.A(n_323),
.Y(n_335)
);

BUFx12f_ASAP7_75t_L g336 ( 
.A(n_331),
.Y(n_336)
);

BUFx3_ASAP7_75t_L g337 ( 
.A(n_331),
.Y(n_337)
);

NAND3xp33_ASAP7_75t_L g338 ( 
.A(n_335),
.B(n_325),
.C(n_326),
.Y(n_338)
);

INVx1_ASAP7_75t_L g339 ( 
.A(n_330),
.Y(n_339)
);

BUFx2_ASAP7_75t_L g340 ( 
.A(n_336),
.Y(n_340)
);

INVx3_ASAP7_75t_L g341 ( 
.A(n_336),
.Y(n_341)
);

AOI211xp5_ASAP7_75t_L g342 ( 
.A1(n_340),
.A2(n_338),
.B(n_332),
.C(n_334),
.Y(n_342)
);

AOI22xp33_ASAP7_75t_L g343 ( 
.A1(n_342),
.A2(n_340),
.B1(n_333),
.B2(n_341),
.Y(n_343)
);

AOI221xp5_ASAP7_75t_L g344 ( 
.A1(n_343),
.A2(n_333),
.B1(n_341),
.B2(n_339),
.C(n_337),
.Y(n_344)
);


endmodule