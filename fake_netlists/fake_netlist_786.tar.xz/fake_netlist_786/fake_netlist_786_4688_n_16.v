module fake_netlist_786_4688_n_16 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_16);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_16;

wire n_15;
wire n_11;
wire n_12;
wire n_8;
wire n_9;
wire n_10;
wire n_13;
wire n_14;

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

CKINVDCx16_ASAP7_75t_R g9 ( 
.A(n_6),
.Y(n_9)
);

AND2x6_ASAP7_75t_L g10 ( 
.A(n_2),
.B(n_3),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_10),
.Y(n_11)
);

OAI321xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.A3(n_10),
.B1(n_7),
.B2(n_5),
.C(n_4),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_7),
.B1(n_5),
.B2(n_4),
.C(n_0),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_1),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);


endmodule