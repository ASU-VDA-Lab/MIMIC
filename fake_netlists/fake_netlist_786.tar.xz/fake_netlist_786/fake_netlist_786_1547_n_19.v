module fake_netlist_786_1547_n_19 (n_1, n_0, n_5, n_3, n_2, n_4, n_19);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_19;

wire n_6;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_14;

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_0),
.B(n_5),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_2),
.C(n_1),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_2),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_7),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

NOR2xp67_ASAP7_75t_SL g16 ( 
.A(n_13),
.B(n_10),
.Y(n_16)
);

AOI221x1_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_8),
.B1(n_15),
.B2(n_11),
.C(n_3),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI21xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_5),
.B(n_4),
.Y(n_19)
);


endmodule