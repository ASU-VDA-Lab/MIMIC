module fake_netlist_786_2337_n_25 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_25);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_25;

wire n_20;
wire n_17;
wire n_12;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

OA22x2_ASAP7_75t_L g9 ( 
.A1(n_1),
.A2(n_4),
.B1(n_3),
.B2(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_2),
.Y(n_11)
);

AO32x2_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_1),
.A3(n_5),
.B1(n_3),
.B2(n_4),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_11),
.B(n_9),
.C(n_7),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_1),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_13),
.Y(n_18)
);

NAND4xp25_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_15),
.C(n_16),
.D(n_12),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.B(n_15),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_19),
.B(n_10),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_23),
.C(n_12),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_12),
.B(n_6),
.Y(n_25)
);


endmodule