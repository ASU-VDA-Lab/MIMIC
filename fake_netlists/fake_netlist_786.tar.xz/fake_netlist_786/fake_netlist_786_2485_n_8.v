module fake_netlist_786_2485_n_8 (n_1, n_2, n_0, n_8);

input n_1;
input n_2;
input n_0;

output n_8;

wire n_7;
wire n_5;
wire n_6;
wire n_3;
wire n_4;

CKINVDCx5p33_ASAP7_75t_R g3 ( 
.A(n_1),
.Y(n_3)
);

BUFx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

NOR2xp67_ASAP7_75t_SL g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_2),
.Y(n_6)
);

OAI211xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_7)
);

OAI22xp5_ASAP7_75t_SL g8 ( 
.A1(n_7),
.A2(n_5),
.B1(n_6),
.B2(n_0),
.Y(n_8)
);


endmodule