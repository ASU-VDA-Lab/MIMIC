module fake_netlist_786_1644_n_5 (n_0, n_5);

input n_0;

output n_5;

wire n_1;
wire n_3;
wire n_2;
wire n_4;

BUFx2_ASAP7_75t_SL g1 ( 
.A(n_0),
.Y(n_1)
);

AND2x2_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

NAND4xp25_ASAP7_75t_SL g4 ( 
.A(n_3),
.B(n_0),
.C(n_1),
.D(n_2),
.Y(n_4)
);

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);


endmodule