module fake_netlist_786_644_n_38 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_38);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_38;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_12;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_16;
wire n_11;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_4),
.B(n_7),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_7),
.B(n_0),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_0),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_6),
.B(n_2),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

OR2x6_ASAP7_75t_L g22 ( 
.A(n_12),
.B(n_13),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_21),
.B(n_17),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

O2A1O1Ixp33_ASAP7_75t_SL g25 ( 
.A1(n_18),
.A2(n_13),
.B(n_12),
.C(n_11),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_22),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_22),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_19),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_25),
.B1(n_11),
.B2(n_17),
.C(n_12),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_24),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_27),
.B1(n_26),
.B2(n_24),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_13),
.B1(n_14),
.B2(n_20),
.C(n_27),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_24),
.Y(n_33)
);

AOI221x1_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_24),
.B1(n_14),
.B2(n_2),
.C(n_3),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_SL g36 ( 
.A1(n_33),
.A2(n_9),
.B1(n_8),
.B2(n_3),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_33),
.A2(n_34),
.B1(n_35),
.B2(n_8),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_R g38 ( 
.A1(n_37),
.A2(n_9),
.B1(n_10),
.B2(n_36),
.Y(n_38)
);


endmodule