module fake_netlist_786_2453_n_7 (n_1, n_0, n_7);

input n_1;
input n_0;

output n_7;

wire n_5;
wire n_6;
wire n_3;
wire n_2;
wire n_4;

BUFx6f_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

AND2x2_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B1(n_2),
.B2(n_5),
.Y(n_7)
);


endmodule