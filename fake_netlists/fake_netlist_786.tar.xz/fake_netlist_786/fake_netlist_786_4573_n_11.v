module fake_netlist_786_4573_n_11 (n_1, n_0, n_5, n_3, n_2, n_4, n_11);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_11;

wire n_7;
wire n_10;
wire n_6;
wire n_9;
wire n_8;

NOR2xp33_ASAP7_75t_SL g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_3),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_R g8 ( 
.A(n_2),
.B(n_1),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_0),
.Y(n_9)
);

INVxp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_7),
.B1(n_6),
.B2(n_1),
.Y(n_11)
);


endmodule