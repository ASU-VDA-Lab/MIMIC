module fake_netlist_786_3690_n_12 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_12);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_12;

wire n_7;
wire n_10;
wire n_11;
wire n_9;
wire n_8;

INVx1_ASAP7_75t_SL g7 ( 
.A(n_5),
.Y(n_7)
);

A2O1A1Ixp33_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.C(n_3),
.Y(n_8)
);

AO21x1_ASAP7_75t_L g9 ( 
.A1(n_2),
.A2(n_6),
.B(n_1),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_10),
.Y(n_11)
);

AOI22x1_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_9),
.B2(n_7),
.Y(n_12)
);


endmodule