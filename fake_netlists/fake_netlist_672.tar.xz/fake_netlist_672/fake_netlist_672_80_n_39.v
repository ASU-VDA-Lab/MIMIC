module fake_netlist_672_80_n_39 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_39);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_39;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

INVx1_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_10),
.B(n_16),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_7),
.B(n_2),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_3),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_0),
.B(n_14),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_5),
.B(n_13),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_15),
.Y(n_27)
);

INVx2_ASAP7_75t_SL g28 ( 
.A(n_23),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_19),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_29),
.Y(n_31)
);

AOI31xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_27),
.A3(n_20),
.B(n_21),
.Y(n_32)
);

OA21x2_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_27),
.B(n_18),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_21),
.B1(n_26),
.B2(n_22),
.C(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_33),
.Y(n_36)
);

OAI322xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_24),
.A3(n_16),
.B1(n_6),
.B2(n_8),
.C1(n_1),
.C2(n_4),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);


endmodule