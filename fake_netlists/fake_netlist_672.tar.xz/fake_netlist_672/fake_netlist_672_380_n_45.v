module fake_netlist_672_380_n_45 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_45);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_45;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_39;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_13;
wire n_43;

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_11),
.B(n_2),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_1),
.B(n_7),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_1),
.A2(n_7),
.B(n_11),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_0),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_15),
.B(n_0),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_13),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_15),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_17),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_R g28 ( 
.A(n_22),
.B(n_19),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_24),
.B(n_18),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

OAI33xp33_ASAP7_75t_L g31 ( 
.A1(n_26),
.A2(n_23),
.A3(n_25),
.B1(n_24),
.B2(n_16),
.B3(n_14),
.Y(n_31)
);

A2O1A1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_18),
.B(n_25),
.C(n_17),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_32),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_19),
.B1(n_16),
.B2(n_14),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_19),
.Y(n_36)
);

OAI21xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_28),
.B(n_2),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_4),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AO22x2_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_34),
.B1(n_28),
.B2(n_35),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_4),
.Y(n_41)
);

AOI222xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_37),
.B1(n_40),
.B2(n_41),
.C1(n_8),
.C2(n_5),
.Y(n_42)
);

NAND4xp25_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_10),
.C(n_8),
.D(n_5),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_42),
.B1(n_12),
.B2(n_9),
.Y(n_45)
);


endmodule