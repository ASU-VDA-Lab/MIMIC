module fake_netlist_672_1777_n_44 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_44);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_44;

wire n_36;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_23;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_0),
.B(n_1),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_11),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_10),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_21),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_27),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_30),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OAI211xp5_ASAP7_75t_SL g38 ( 
.A1(n_37),
.A2(n_23),
.B(n_24),
.C(n_28),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_5),
.B(n_4),
.C(n_2),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_7),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_40),
.A2(n_12),
.B1(n_9),
.B2(n_8),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_18),
.B1(n_19),
.B2(n_43),
.Y(n_44)
);


endmodule