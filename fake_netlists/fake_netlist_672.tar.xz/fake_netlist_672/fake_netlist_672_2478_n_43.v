module fake_netlist_672_2478_n_43 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_43);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_43;

wire n_36;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_13),
.B(n_12),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_7),
.B(n_9),
.Y(n_21)
);

BUFx10_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_10),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_14),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_16),
.Y(n_30)
);

OAI221xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_24),
.B1(n_27),
.B2(n_23),
.C(n_21),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_SL g33 ( 
.A(n_32),
.B(n_29),
.Y(n_33)
);

AO21x1_ASAP7_75t_SL g34 ( 
.A1(n_31),
.A2(n_20),
.B(n_22),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_28),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_34),
.B1(n_18),
.B2(n_16),
.Y(n_38)
);

OAI321xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_34),
.A3(n_20),
.B1(n_19),
.B2(n_18),
.C(n_0),
.Y(n_39)
);

OA22x2_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_19),
.B1(n_2),
.B2(n_1),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_3),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_4),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_41),
.B1(n_8),
.B2(n_6),
.Y(n_43)
);


endmodule