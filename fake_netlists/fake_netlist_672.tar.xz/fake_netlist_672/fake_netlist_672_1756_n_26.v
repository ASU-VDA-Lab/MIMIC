module fake_netlist_672_1756_n_26 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_26);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_26;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_15;
wire n_11;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_3),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_11),
.B(n_9),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B(n_9),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_13),
.Y(n_18)
);

OAI221xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_17),
.B1(n_14),
.B2(n_10),
.C(n_12),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_18),
.B(n_8),
.C(n_9),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_8),
.B1(n_16),
.B2(n_6),
.C(n_7),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI22xp33_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_16),
.B1(n_6),
.B2(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_2),
.B1(n_5),
.B2(n_25),
.Y(n_26)
);


endmodule