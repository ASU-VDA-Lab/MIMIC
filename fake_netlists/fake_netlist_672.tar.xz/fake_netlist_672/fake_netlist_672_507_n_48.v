module fake_netlist_672_507_n_48 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_48);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_48;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_23;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_14),
.B(n_9),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_13),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_21),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_17),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_7),
.A2(n_10),
.B1(n_18),
.B2(n_11),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_16),
.Y(n_31)
);

NAND2x1p5_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_16),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

OR2x6_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_26),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_R g37 ( 
.A(n_34),
.B(n_23),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_34),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AND2x2_ASAP7_75t_SL g42 ( 
.A(n_40),
.B(n_31),
.Y(n_42)
);

OAI311xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_30),
.A3(n_27),
.B1(n_25),
.C1(n_33),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_42),
.A2(n_29),
.B1(n_33),
.B2(n_18),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_19),
.B1(n_4),
.B2(n_0),
.C(n_2),
.Y(n_45)
);

AO22x2_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_42),
.B1(n_19),
.B2(n_5),
.Y(n_46)
);

INVxp67_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AOI222xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_8),
.B1(n_12),
.B2(n_15),
.C1(n_22),
.C2(n_47),
.Y(n_48)
);


endmodule