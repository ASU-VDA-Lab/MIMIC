module fake_netlist_672_987_n_54 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_54);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_54;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

OAI21x1_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_15),
.B(n_20),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_13),
.Y(n_28)
);

NAND2x1_ASAP7_75t_L g29 ( 
.A(n_12),
.B(n_10),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_3),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_1),
.Y(n_32)
);

INVxp67_ASAP7_75t_SL g33 ( 
.A(n_7),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_R g34 ( 
.A(n_11),
.B(n_14),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_9),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_31),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_27),
.B(n_25),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_33),
.Y(n_39)
);

OR2x6_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_29),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_33),
.Y(n_41)
);

A2O1A1Ixp33_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_26),
.B(n_35),
.C(n_28),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_32),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_36),
.B1(n_34),
.B2(n_0),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_42),
.Y(n_46)
);

NOR2x1_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_36),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_34),
.Y(n_49)
);

NOR3xp33_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_4),
.C(n_2),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_49),
.Y(n_51)
);

AOI221xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_8),
.B1(n_5),
.B2(n_16),
.C(n_17),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_52),
.Y(n_53)
);

AOI222xp33_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_19),
.B1(n_18),
.B2(n_21),
.C1(n_24),
.C2(n_23),
.Y(n_54)
);


endmodule