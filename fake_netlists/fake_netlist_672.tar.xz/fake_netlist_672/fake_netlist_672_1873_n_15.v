module fake_netlist_672_1873_n_15 (n_3, n_1, n_2, n_0, n_15);

input n_3;
input n_1;
input n_2;
input n_0;

output n_15;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

CKINVDCx20_ASAP7_75t_R g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

OAI21xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_7),
.B(n_5),
.C(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_7),
.B1(n_8),
.B2(n_0),
.C(n_1),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_2),
.B(n_3),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_2),
.B1(n_13),
.B2(n_12),
.Y(n_15)
);


endmodule