module fake_netlist_672_575_n_51 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_51);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_51;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_17),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_19),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_14),
.B(n_13),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_16),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_2),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_9),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_7),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_6),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_24),
.B1(n_1),
.B2(n_0),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_29),
.B(n_24),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_29),
.Y(n_37)
);

A2O1A1Ixp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_33),
.B(n_27),
.C(n_28),
.Y(n_38)
);

OAI221xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_34),
.B1(n_31),
.B2(n_26),
.C(n_25),
.Y(n_39)
);

NAND4xp25_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_5),
.C(n_4),
.D(n_3),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

NOR3xp33_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_10),
.C(n_8),
.Y(n_42)
);

INVxp67_ASAP7_75t_SL g43 ( 
.A(n_42),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_18),
.B1(n_12),
.B2(n_11),
.Y(n_46)
);

INVx2_ASAP7_75t_SL g47 ( 
.A(n_45),
.Y(n_47)
);

CKINVDCx12_ASAP7_75t_R g48 ( 
.A(n_46),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_43),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_SL g51 ( 
.A1(n_50),
.A2(n_20),
.B1(n_21),
.B2(n_49),
.Y(n_51)
);


endmodule