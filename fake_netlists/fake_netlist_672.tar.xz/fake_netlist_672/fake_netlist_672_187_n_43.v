module fake_netlist_672_187_n_43 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_43);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_43;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_7),
.B(n_5),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_0),
.B(n_15),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_3),
.Y(n_26)
);

NOR2xp67_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_16),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_22),
.B(n_16),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_25),
.B1(n_23),
.B2(n_24),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_26),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_29),
.Y(n_32)
);

AOI211xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_27),
.B(n_19),
.C(n_20),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_17),
.Y(n_36)
);

NOR4xp25_ASAP7_75t_SL g37 ( 
.A(n_34),
.B(n_18),
.C(n_17),
.D(n_1),
.Y(n_37)
);

NAND3xp33_ASAP7_75t_SL g38 ( 
.A(n_37),
.B(n_18),
.C(n_20),
.Y(n_38)
);

OAI322xp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_20),
.A3(n_9),
.B1(n_8),
.B2(n_4),
.C1(n_13),
.C2(n_11),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_41),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_40),
.B(n_20),
.Y(n_43)
);


endmodule