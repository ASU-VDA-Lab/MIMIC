module fake_netlist_672_1184_n_55 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_55);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_55;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

NOR2xp67_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_12),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_11),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_10),
.Y(n_29)
);

OAI22x1_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.Y(n_30)
);

AND3x1_ASAP7_75t_SL g31 ( 
.A(n_25),
.B(n_5),
.C(n_1),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_20),
.B(n_16),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_20),
.A2(n_26),
.B(n_25),
.Y(n_33)
);

NOR2x1_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_7),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_21),
.A2(n_18),
.B1(n_17),
.B2(n_9),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_23),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_22),
.Y(n_38)
);

OR2x6_ASAP7_75t_L g39 ( 
.A(n_30),
.B(n_19),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_38),
.Y(n_40)
);

BUFx3_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_36),
.Y(n_42)
);

OAI22xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_39),
.B1(n_35),
.B2(n_31),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_39),
.Y(n_45)
);

OAI21xp33_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_41),
.B(n_40),
.Y(n_46)
);

OAI221xp5_ASAP7_75t_SL g47 ( 
.A1(n_43),
.A2(n_41),
.B1(n_40),
.B2(n_17),
.C(n_18),
.Y(n_47)
);

NOR2x1p5_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_41),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_40),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_40),
.Y(n_50)
);

NOR2xp33_ASAP7_75t_R g51 ( 
.A(n_48),
.B(n_27),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

CKINVDCx20_ASAP7_75t_R g53 ( 
.A(n_49),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_40),
.B1(n_29),
.B2(n_28),
.Y(n_54)
);

AOI22xp5_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_15),
.B1(n_52),
.B2(n_54),
.Y(n_55)
);


endmodule