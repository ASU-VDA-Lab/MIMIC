module fake_netlist_672_153_n_40 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_40);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_40;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_39;
wire n_27;
wire n_21;
wire n_14;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_13;

BUFx8_ASAP7_75t_SL g12 ( 
.A(n_4),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_6),
.B(n_4),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_L g20 ( 
.A(n_2),
.B(n_10),
.C(n_5),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_13),
.B(n_15),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_7),
.B(n_1),
.C(n_0),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_15),
.B(n_7),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_16),
.A2(n_3),
.B(n_1),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_12),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_16),
.A2(n_8),
.B(n_5),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_19),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_19),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

OAI21xp5_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_26),
.B(n_23),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_28),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_28),
.B1(n_22),
.B2(n_27),
.C(n_17),
.Y(n_34)
);

OAI22xp33_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_20),
.B1(n_12),
.B2(n_14),
.Y(n_35)
);

OA22x2_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_33),
.B1(n_32),
.B2(n_8),
.Y(n_36)
);

NOR2x1_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_32),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_36),
.Y(n_38)
);

AO22x1_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_39)
);

AOI21xp33_ASAP7_75t_SL g40 ( 
.A1(n_39),
.A2(n_38),
.B(n_36),
.Y(n_40)
);


endmodule