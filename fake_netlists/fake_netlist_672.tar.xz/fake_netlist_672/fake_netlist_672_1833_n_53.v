module fake_netlist_672_1833_n_53 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_53);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_53;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_10;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_39;
wire n_14;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_9;
wire n_32;
wire n_37;
wire n_13;
wire n_43;
wire n_47;
wire n_8;

NAND3x1_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.C(n_2),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_3),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_5),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_3),
.B(n_1),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_11),
.B(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_9),
.A2(n_5),
.B(n_4),
.C(n_2),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVx4_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_15),
.A2(n_9),
.B(n_12),
.Y(n_23)
);

O2A1O1Ixp5_ASAP7_75t_L g24 ( 
.A1(n_8),
.A2(n_7),
.B(n_6),
.C(n_2),
.Y(n_24)
);

A2O1A1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_16),
.A2(n_6),
.B(n_7),
.C(n_13),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_10),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_17),
.A2(n_8),
.B1(n_14),
.B2(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_8),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_22),
.B(n_18),
.Y(n_29)
);

INVxp67_ASAP7_75t_SL g30 ( 
.A(n_17),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_21),
.B(n_14),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_21),
.Y(n_33)
);

OAI21xp33_ASAP7_75t_SL g34 ( 
.A1(n_27),
.A2(n_19),
.B(n_21),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_28),
.B(n_25),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_29),
.B(n_24),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_31),
.B(n_20),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_29),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_33),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

OAI21xp5_ASAP7_75t_L g42 ( 
.A1(n_36),
.A2(n_28),
.B(n_32),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_33),
.B(n_37),
.Y(n_43)
);

OAI21xp33_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_31),
.B(n_34),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_39),
.A2(n_31),
.B1(n_35),
.B2(n_38),
.C(n_37),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

NOR2xp67_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_37),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_43),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

CKINVDCx20_ASAP7_75t_R g50 ( 
.A(n_45),
.Y(n_50)
);

OAI22xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_40),
.B1(n_35),
.B2(n_42),
.Y(n_51)
);

AO22x2_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_26),
.B1(n_48),
.B2(n_47),
.Y(n_52)
);

AOI22xp33_ASAP7_75t_SL g53 ( 
.A1(n_52),
.A2(n_26),
.B1(n_49),
.B2(n_51),
.Y(n_53)
);


endmodule