module fake_netlist_672_2445_n_11 (n_3, n_1, n_2, n_0, n_11);

input n_3;
input n_1;
input n_2;
input n_0;

output n_11;

wire n_9;
wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_8;
wire n_6;

AND2x2_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_3),
.Y(n_5)
);

INVx5_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_5),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.Y(n_9)
);

NOR4xp75_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_4),
.C(n_7),
.D(n_1),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);


endmodule