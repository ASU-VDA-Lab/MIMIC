module fake_netlist_672_2355_n_52 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_52);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_52;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_16;
wire n_22;
wire n_17;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_1),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_3),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_0),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_15),
.B(n_13),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_20),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_27),
.B1(n_25),
.B2(n_26),
.Y(n_30)
);

AOI22x1_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_19),
.B1(n_21),
.B2(n_16),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_23),
.B1(n_18),
.B2(n_17),
.Y(n_32)
);

CKINVDCx8_ASAP7_75t_R g33 ( 
.A(n_29),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_30),
.A2(n_21),
.B1(n_20),
.B2(n_4),
.Y(n_35)
);

OAI321xp33_ASAP7_75t_L g36 ( 
.A1(n_30),
.A2(n_6),
.A3(n_5),
.B1(n_7),
.B2(n_11),
.C(n_14),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_32),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_5),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_34),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_SL g41 ( 
.A(n_38),
.B(n_34),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_36),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_37),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_SL g45 ( 
.A(n_42),
.B(n_39),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_39),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

A2O1A1Ixp33_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_11),
.B(n_7),
.C(n_6),
.Y(n_48)
);

OR3x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_31),
.C(n_46),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_48),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_50),
.B1(n_48),
.B2(n_49),
.Y(n_52)
);


endmodule