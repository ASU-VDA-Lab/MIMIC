module fake_netlist_862_4536_n_24 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_24);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_24;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

INVx3_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

XNOR2xp5_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_6),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_9),
.B(n_0),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_SL g16 ( 
.A(n_12),
.B(n_14),
.C(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_16),
.B1(n_12),
.B2(n_8),
.Y(n_18)
);

OAI221xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_10),
.B1(n_8),
.B2(n_1),
.C(n_4),
.Y(n_19)
);

OAI21xp33_ASAP7_75t_SL g20 ( 
.A1(n_18),
.A2(n_8),
.B(n_10),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_SL g21 ( 
.A(n_19),
.B(n_20),
.Y(n_21)
);

CKINVDCx6p67_ASAP7_75t_R g22 ( 
.A(n_19),
.Y(n_22)
);

OAI22xp33_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_8),
.B1(n_6),
.B2(n_5),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_22),
.B1(n_8),
.B2(n_7),
.Y(n_24)
);


endmodule