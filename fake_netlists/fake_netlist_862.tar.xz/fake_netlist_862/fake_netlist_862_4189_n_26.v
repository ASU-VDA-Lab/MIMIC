module fake_netlist_862_4189_n_26 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_26);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_3),
.B(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

INVxp67_ASAP7_75t_SL g16 ( 
.A(n_4),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_8),
.B(n_5),
.Y(n_17)
);

AOI221x1_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.C(n_1),
.Y(n_18)
);

INVxp67_ASAP7_75t_SL g19 ( 
.A(n_14),
.Y(n_19)
);

AO21x2_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.B(n_16),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AOI321xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.A3(n_17),
.B1(n_18),
.B2(n_20),
.C(n_6),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_13),
.B1(n_9),
.B2(n_2),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_10),
.B1(n_12),
.B2(n_13),
.C1(n_16),
.C2(n_15),
.Y(n_26)
);


endmodule