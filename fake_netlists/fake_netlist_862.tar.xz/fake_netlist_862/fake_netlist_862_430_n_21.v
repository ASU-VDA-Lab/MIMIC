module fake_netlist_862_430_n_21 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_21);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_21;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_5),
.B1(n_6),
.B2(n_2),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_4),
.B(n_5),
.Y(n_13)
);

AOI221x1_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_3),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_1),
.B(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AND2x2_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_11),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_16),
.B1(n_14),
.B2(n_10),
.C1(n_4),
.C2(n_3),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.B(n_17),
.C(n_7),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_9),
.Y(n_21)
);


endmodule