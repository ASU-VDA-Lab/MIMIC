module fake_netlist_862_1892_n_28 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_28);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_1),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_0),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_2),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_7),
.B(n_6),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_6),
.B(n_4),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_8),
.B(n_3),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_4),
.B(n_1),
.Y(n_17)
);

INVx4_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_14),
.Y(n_22)
);

OAI21xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_20),
.B(n_13),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_12),
.B1(n_17),
.B2(n_21),
.C(n_15),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_21),
.B1(n_12),
.B2(n_5),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_26),
.B1(n_21),
.B2(n_7),
.Y(n_28)
);


endmodule