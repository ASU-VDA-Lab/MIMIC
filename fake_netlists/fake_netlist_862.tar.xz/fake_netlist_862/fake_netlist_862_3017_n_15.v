module fake_netlist_862_3017_n_15 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_15);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_15;

wire n_10;
wire n_7;
wire n_13;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_1),
.B1(n_6),
.B2(n_3),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_2),
.B1(n_0),
.B2(n_4),
.C(n_5),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.C(n_9),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B1(n_9),
.B2(n_6),
.C1(n_2),
.C2(n_0),
.Y(n_15)
);


endmodule