module fake_netlist_862_2331_n_30 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_30);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;
wire n_8;

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_0),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_1),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_12),
.Y(n_17)
);

AO32x2_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_11),
.A3(n_12),
.B1(n_1),
.B2(n_4),
.Y(n_18)
);

CKINVDCx11_ASAP7_75t_R g19 ( 
.A(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_15),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_21),
.C(n_9),
.D(n_18),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_21),
.B1(n_11),
.B2(n_18),
.C(n_19),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_24),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_25),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_21),
.B1(n_3),
.B2(n_5),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_R g30 ( 
.A1(n_28),
.A2(n_6),
.B1(n_7),
.B2(n_26),
.C(n_29),
.Y(n_30)
);


endmodule