module fake_netlist_862_1869_n_7 (n_0, n_1, n_7);

input n_0;
input n_1;

output n_7;

wire n_6;
wire n_4;
wire n_2;
wire n_5;
wire n_3;

NAND2xp5_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

HB1xp67_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AOI221xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.C(n_2),
.Y(n_5)
);

NOR3xp33_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_1),
.C(n_0),
.Y(n_6)
);

XNOR2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);


endmodule