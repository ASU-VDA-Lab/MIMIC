module fake_netlist_862_796_n_30 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_30);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

INVx3_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_2),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_0),
.B(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

INVxp67_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

O2A1O1Ixp33_ASAP7_75t_SL g15 ( 
.A1(n_10),
.A2(n_6),
.B(n_5),
.C(n_1),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_9),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_7),
.B(n_8),
.C(n_3),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_22),
.B(n_18),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_16),
.B1(n_17),
.B2(n_13),
.C(n_9),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_24),
.Y(n_26)
);

NOR3x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_17),
.C(n_12),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

OAI22x1_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_9),
.B1(n_11),
.B2(n_12),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_28),
.A2(n_9),
.B1(n_27),
.B2(n_29),
.Y(n_30)
);


endmodule