module fake_netlist_862_459_n_27 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_27);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_8),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_3),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_6),
.Y(n_12)
);

INVx4_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

OA21x2_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AO31x2_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_13),
.A3(n_12),
.B(n_11),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_14),
.B(n_17),
.C(n_13),
.Y(n_20)
);

AOI211xp5_ASAP7_75t_SL g21 ( 
.A1(n_19),
.A2(n_10),
.B(n_14),
.C(n_1),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_13),
.C(n_14),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_13),
.B1(n_21),
.B2(n_17),
.C(n_3),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

AND3x1_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_5),
.C(n_4),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_26),
.B1(n_5),
.B2(n_4),
.Y(n_27)
);


endmodule