module fake_netlist_852_844_n_17 (n_4, n_2, n_5, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_3),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

O2A1O1Ixp5_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

AND2x4_ASAP7_75t_SL g12 ( 
.A(n_10),
.B(n_7),
.Y(n_12)
);

INVxp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

O2A1O1Ixp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B(n_11),
.C(n_12),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_5),
.B(n_4),
.C(n_2),
.Y(n_15)
);

XNOR2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_5),
.B1(n_13),
.B2(n_15),
.Y(n_17)
);


endmodule