module fake_netlist_852_1779_n_52 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_52);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_52;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_17;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_44;
wire n_28;
wire n_39;
wire n_40;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_10),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_9),
.B(n_15),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_14),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_3),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_15),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_18),
.A2(n_2),
.B(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_18),
.B(n_1),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_24),
.A2(n_5),
.B(n_4),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_26),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_29),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_25),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_36),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AOI211xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_22),
.B(n_32),
.C(n_33),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_36),
.B1(n_33),
.B2(n_38),
.C(n_19),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_33),
.B(n_24),
.C(n_27),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_16),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_44),
.Y(n_45)
);

INVx1_ASAP7_75t_SL g46 ( 
.A(n_43),
.Y(n_46)
);

CKINVDCx16_ASAP7_75t_R g47 ( 
.A(n_42),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

AOI21xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_40),
.B(n_31),
.Y(n_49)
);

OAI22x1_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_16),
.B1(n_21),
.B2(n_1),
.Y(n_50)
);

OAI22xp5_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_45),
.B1(n_48),
.B2(n_17),
.Y(n_51)
);

AOI222xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_11),
.B1(n_13),
.B2(n_17),
.C1(n_51),
.C2(n_49),
.Y(n_52)
);


endmodule