module fake_netlist_852_1484_n_21 (n_4, n_2, n_3, n_0, n_1, n_21);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_21;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_5;
wire n_11;
wire n_8;

INVx2_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AO21x2_ASAP7_75t_L g7 ( 
.A1(n_0),
.A2(n_4),
.B(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

AO21x1_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OR2x2_ASAP7_75t_SL g10 ( 
.A(n_7),
.B(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_11),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_11),
.B(n_10),
.C(n_9),
.Y(n_15)
);

NAND2x1_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_9),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

NAND2x1p5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_1),
.Y(n_18)
);

AOI21xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_4),
.B(n_2),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_2),
.B1(n_4),
.B2(n_18),
.Y(n_20)
);

OA22x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_18),
.B1(n_19),
.B2(n_2),
.Y(n_21)
);


endmodule