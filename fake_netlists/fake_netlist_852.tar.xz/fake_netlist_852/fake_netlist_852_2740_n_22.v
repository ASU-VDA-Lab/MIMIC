module fake_netlist_852_2740_n_22 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_22);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;
wire n_11;

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVx5_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_4),
.B(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_SL g15 ( 
.A(n_11),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_13),
.B(n_12),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

AOI211xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_14),
.B(n_7),
.C(n_13),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_2),
.C(n_0),
.Y(n_20)
);

AOI22x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_9),
.B1(n_6),
.B2(n_3),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_10),
.Y(n_22)
);


endmodule