module fake_netlist_852_1075_n_20 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_20);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_16;

XNOR2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_1),
.Y(n_12)
);

NAND2xp33_ASAP7_75t_L g13 ( 
.A(n_3),
.B(n_11),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_2),
.B(n_6),
.Y(n_14)
);

AO21x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_6),
.B(n_4),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B1(n_12),
.B2(n_4),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_13),
.B1(n_7),
.B2(n_0),
.C(n_5),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_10),
.B2(n_8),
.Y(n_20)
);


endmodule