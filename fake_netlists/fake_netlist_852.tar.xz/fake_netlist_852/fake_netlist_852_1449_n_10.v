module fake_netlist_852_1449_n_10 (n_2, n_0, n_1, n_10);

input n_2;
input n_0;
input n_1;

output n_10;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_8;

AND2x4_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

INVx2_ASAP7_75t_SL g4 ( 
.A(n_2),
.Y(n_4)
);

OR2x6_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_1),
.Y(n_5)
);

INVx5_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

NOR3xp33_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_3),
.C(n_4),
.Y(n_8)
);

INVxp67_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule