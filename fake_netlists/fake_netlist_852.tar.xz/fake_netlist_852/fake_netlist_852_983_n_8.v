module fake_netlist_852_983_n_8 (n_0, n_1, n_8);

input n_0;
input n_1;

output n_8;

wire n_6;
wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_3;

NAND2xp33_ASAP7_75t_R g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

AO21x2_ASAP7_75t_L g3 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_3)
);

INVxp67_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AOI21xp33_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B(n_3),
.Y(n_5)
);

OAI31xp33_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.A3(n_1),
.B(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_6),
.B(n_0),
.Y(n_8)
);


endmodule