module fake_netlist_852_2530_n_19 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_19);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

AO22x2_ASAP7_75t_L g8 ( 
.A1(n_3),
.A2(n_4),
.B1(n_6),
.B2(n_7),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_4),
.B(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_2),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_8),
.B(n_10),
.C(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);

OAI221xp5_ASAP7_75t_R g17 ( 
.A1(n_16),
.A2(n_14),
.B1(n_8),
.B2(n_15),
.C(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_7),
.B1(n_9),
.B2(n_12),
.C1(n_15),
.C2(n_8),
.Y(n_19)
);


endmodule