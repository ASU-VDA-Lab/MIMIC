module fake_netlist_852_2978_n_25 (n_4, n_2, n_5, n_3, n_0, n_1, n_25);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_25;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_24;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_2),
.B(n_5),
.Y(n_6)
);

INVxp33_ASAP7_75t_SL g7 ( 
.A(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_5),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_1),
.B(n_2),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_0),
.Y(n_10)
);

AO21x2_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_6),
.C(n_7),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_0),
.Y(n_14)
);

OAI31xp33_ASAP7_75t_L g15 ( 
.A1(n_10),
.A2(n_5),
.A3(n_4),
.B(n_2),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_12),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

AOI211xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_10),
.B(n_12),
.C(n_11),
.Y(n_19)
);

AOI222xp33_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_10),
.B1(n_12),
.B2(n_11),
.C1(n_4),
.C2(n_3),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_18),
.B1(n_16),
.B2(n_10),
.C(n_11),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_SL g22 ( 
.A(n_20),
.B(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

OR3x2_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_18),
.C(n_17),
.Y(n_24)
);

AOI222xp33_ASAP7_75t_SL g25 ( 
.A1(n_22),
.A2(n_11),
.B1(n_23),
.B2(n_24),
.C1(n_7),
.C2(n_17),
.Y(n_25)
);


endmodule