module fake_netlist_852_622_n_69 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_69);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_69;

wire n_49;
wire n_48;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_62;
wire n_44;
wire n_40;
wire n_34;
wire n_39;
wire n_53;
wire n_28;
wire n_60;
wire n_32;
wire n_31;
wire n_58;
wire n_68;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_52;
wire n_38;
wire n_35;
wire n_61;
wire n_67;
wire n_45;
wire n_46;
wire n_51;

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_15),
.B(n_4),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_3),
.A2(n_24),
.B1(n_26),
.B2(n_11),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_L g30 ( 
.A(n_10),
.B(n_16),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_7),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_17),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_14),
.A2(n_13),
.B1(n_1),
.B2(n_23),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_22),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_5),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_21),
.B(n_2),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_8),
.Y(n_39)
);

BUFx6f_ASAP7_75t_L g40 ( 
.A(n_26),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_32),
.Y(n_41)
);

BUFx6f_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_21),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_33),
.B(n_25),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_38),
.B1(n_34),
.B2(n_31),
.Y(n_47)
);

O2A1O1Ixp33_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_29),
.B(n_38),
.C(n_30),
.Y(n_48)
);

BUFx2_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_41),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_50),
.Y(n_51)
);

NOR2xp33_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_48),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_47),
.Y(n_53)
);

AOI22xp33_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_53),
.B1(n_51),
.B2(n_36),
.Y(n_54)
);

OAI21xp33_ASAP7_75t_SL g55 ( 
.A1(n_52),
.A2(n_43),
.B(n_35),
.Y(n_55)
);

AOI21xp5_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_39),
.B(n_37),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_55),
.A2(n_28),
.B1(n_42),
.B2(n_25),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_54),
.A2(n_42),
.B1(n_27),
.B2(n_0),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_42),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_56),
.Y(n_60)
);

XNOR2x1_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_27),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_60),
.Y(n_62)
);

NAND3x1_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_9),
.C(n_6),
.Y(n_63)
);

NAND4xp75_ASAP7_75t_L g64 ( 
.A(n_59),
.B(n_20),
.C(n_18),
.D(n_12),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_62),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_62),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_63),
.Y(n_67)
);

INVx4_ASAP7_75t_L g68 ( 
.A(n_67),
.Y(n_68)
);

AOI221xp5_ASAP7_75t_L g69 ( 
.A1(n_68),
.A2(n_61),
.B1(n_66),
.B2(n_65),
.C(n_64),
.Y(n_69)
);


endmodule