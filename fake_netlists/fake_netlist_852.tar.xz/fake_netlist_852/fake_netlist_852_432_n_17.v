module fake_netlist_852_432_n_17 (n_4, n_2, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

CKINVDCx11_ASAP7_75t_R g6 ( 
.A(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_8),
.C(n_0),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.C(n_4),
.Y(n_14)
);

AOI22x1_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_15)
);

XNOR2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_2),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B1(n_13),
.B2(n_14),
.Y(n_17)
);


endmodule