module fake_netlist_852_2914_n_22 (n_2, n_0, n_3, n_1, n_22);

input n_2;
input n_0;
input n_3;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_4;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

INVx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_SL g10 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AO31x2_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_4),
.A3(n_6),
.B(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

XNOR2x1_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_1),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_10),
.B(n_12),
.C(n_11),
.Y(n_17)
);

OR5x1_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_10),
.C(n_3),
.D(n_2),
.E(n_8),
.Y(n_18)
);

NAND4xp75_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_8),
.C(n_13),
.D(n_17),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_18),
.B1(n_13),
.B2(n_8),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_13),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_8),
.B(n_21),
.Y(n_22)
);


endmodule