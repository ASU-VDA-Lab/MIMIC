module fake_netlist_852_2029_n_79 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_79);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_79;

wire n_49;
wire n_78;
wire n_54;
wire n_56;
wire n_59;
wire n_63;
wire n_74;
wire n_64;
wire n_61;
wire n_43;
wire n_45;
wire n_48;
wire n_47;
wire n_76;
wire n_72;
wire n_73;
wire n_37;
wire n_42;
wire n_52;
wire n_77;
wire n_27;
wire n_57;
wire n_51;
wire n_70;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_53;
wire n_58;
wire n_68;
wire n_33;
wire n_55;
wire n_65;
wire n_75;
wire n_67;
wire n_66;
wire n_36;
wire n_50;
wire n_60;
wire n_39;
wire n_32;
wire n_31;
wire n_71;
wire n_69;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_46;

INVx1_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_3),
.A2(n_18),
.B1(n_21),
.B2(n_12),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_6),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_10),
.B(n_11),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_15),
.B(n_19),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_0),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_20),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_22),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_4),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_1),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_25),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_29),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_34),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_35),
.B(n_25),
.Y(n_44)
);

INVx2_ASAP7_75t_SL g45 ( 
.A(n_35),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_37),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_39),
.Y(n_47)
);

INVxp67_ASAP7_75t_L g48 ( 
.A(n_27),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_32),
.B(n_33),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_46),
.Y(n_50)
);

OA21x2_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_36),
.B(n_30),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_43),
.Y(n_52)
);

BUFx4f_ASAP7_75t_L g53 ( 
.A(n_42),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_48),
.Y(n_55)
);

AND2x4_ASAP7_75t_L g56 ( 
.A(n_49),
.B(n_44),
.Y(n_56)
);

INVx5_ASAP7_75t_L g57 ( 
.A(n_51),
.Y(n_57)
);

NAND4xp25_ASAP7_75t_SL g58 ( 
.A(n_55),
.B(n_44),
.C(n_49),
.D(n_56),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

AND2x2_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_45),
.Y(n_60)
);

BUFx3_ASAP7_75t_L g61 ( 
.A(n_55),
.Y(n_61)
);

AOI22xp5_ASAP7_75t_L g62 ( 
.A1(n_58),
.A2(n_56),
.B1(n_61),
.B2(n_60),
.Y(n_62)
);

OAI21xp33_ASAP7_75t_L g63 ( 
.A1(n_60),
.A2(n_41),
.B(n_50),
.Y(n_63)
);

INVx3_ASAP7_75t_L g64 ( 
.A(n_61),
.Y(n_64)
);

AOI321xp33_ASAP7_75t_L g65 ( 
.A1(n_59),
.A2(n_40),
.A3(n_28),
.B1(n_26),
.B2(n_53),
.C(n_31),
.Y(n_65)
);

OAI31xp33_ASAP7_75t_L g66 ( 
.A1(n_63),
.A2(n_51),
.A3(n_57),
.B(n_31),
.Y(n_66)
);

AOI31xp33_ASAP7_75t_SL g67 ( 
.A1(n_65),
.A2(n_38),
.A3(n_5),
.B(n_2),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_62),
.B(n_57),
.Y(n_68)
);

AOI22xp33_ASAP7_75t_L g69 ( 
.A1(n_64),
.A2(n_57),
.B1(n_38),
.B2(n_7),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_62),
.Y(n_70)
);

NOR3xp33_ASAP7_75t_L g71 ( 
.A(n_70),
.B(n_57),
.C(n_8),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_68),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_67),
.Y(n_73)
);

OAI21xp5_ASAP7_75t_L g74 ( 
.A1(n_68),
.A2(n_57),
.B(n_9),
.Y(n_74)
);

HB1xp67_ASAP7_75t_L g75 ( 
.A(n_72),
.Y(n_75)
);

XNOR2x1_ASAP7_75t_L g76 ( 
.A(n_73),
.B(n_13),
.Y(n_76)
);

AOI21xp33_ASAP7_75t_L g77 ( 
.A1(n_74),
.A2(n_66),
.B(n_69),
.Y(n_77)
);

OAI22xp5_ASAP7_75t_SL g78 ( 
.A1(n_76),
.A2(n_71),
.B1(n_17),
.B2(n_16),
.Y(n_78)
);

AOI22xp5_ASAP7_75t_L g79 ( 
.A1(n_78),
.A2(n_71),
.B1(n_77),
.B2(n_75),
.Y(n_79)
);


endmodule