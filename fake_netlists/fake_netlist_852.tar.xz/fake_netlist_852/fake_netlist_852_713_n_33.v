module fake_netlist_852_713_n_33 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_33);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_33;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

NAND2xp33_ASAP7_75t_R g10 ( 
.A(n_0),
.B(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_7),
.B(n_3),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_8),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_0),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_SL g18 ( 
.A(n_11),
.B(n_2),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_4),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_4),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_SL g22 ( 
.A(n_17),
.B(n_12),
.C(n_15),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_16),
.Y(n_25)
);

OAI22xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_18),
.B1(n_23),
.B2(n_22),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_15),
.B1(n_25),
.B2(n_13),
.C(n_11),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_5),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_30),
.B1(n_14),
.B2(n_11),
.Y(n_33)
);


endmodule