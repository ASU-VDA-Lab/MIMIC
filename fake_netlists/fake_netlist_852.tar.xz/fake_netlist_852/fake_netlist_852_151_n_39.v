module fake_netlist_852_151_n_39 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_39);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_39;

wire n_25;
wire n_20;
wire n_36;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

INVx3_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_6),
.A2(n_0),
.B1(n_11),
.B2(n_7),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_0),
.Y(n_24)
);

INVxp67_ASAP7_75t_SL g25 ( 
.A(n_17),
.Y(n_25)
);

AO31x2_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_19),
.A3(n_18),
.B(n_20),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_21),
.B1(n_19),
.B2(n_22),
.C(n_1),
.Y(n_27)
);

INVxp67_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

OAI33xp33_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_25),
.A3(n_24),
.B1(n_23),
.B2(n_2),
.B3(n_1),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_26),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AOI32xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_29),
.A3(n_6),
.B1(n_3),
.B2(n_5),
.Y(n_33)
);

NAND4xp75_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_29),
.C(n_16),
.D(n_5),
.Y(n_34)
);

OAI21xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_32),
.B(n_16),
.Y(n_35)
);

NOR2xp67_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_9),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI322xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_10),
.A3(n_12),
.B1(n_13),
.B2(n_14),
.C1(n_15),
.C2(n_38),
.Y(n_39)
);


endmodule