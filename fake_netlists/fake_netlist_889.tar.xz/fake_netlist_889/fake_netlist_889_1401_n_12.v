module fake_netlist_889_1401_n_12 (n_0, n_1, n_2, n_12);

input n_0;
input n_1;
input n_2;

output n_12;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

AND2x4_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

BUFx10_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

A2O1A1Ixp33_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_3),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OAI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_0),
.B1(n_3),
.B2(n_8),
.C(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule