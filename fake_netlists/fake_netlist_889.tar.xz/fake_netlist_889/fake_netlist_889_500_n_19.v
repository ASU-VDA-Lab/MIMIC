module fake_netlist_889_500_n_19 (n_0, n_1, n_3, n_2, n_19);

input n_0;
input n_1;
input n_3;
input n_2;

output n_19;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_4;
wire n_12;
wire n_5;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

BUFx2_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

AO31x2_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_7)
);

NAND3xp33_ASAP7_75t_SL g8 ( 
.A(n_6),
.B(n_1),
.C(n_0),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_2),
.B(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.C(n_13),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_9),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);


endmodule