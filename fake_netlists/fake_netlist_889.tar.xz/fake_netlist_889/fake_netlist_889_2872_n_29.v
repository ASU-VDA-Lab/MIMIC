module fake_netlist_889_2872_n_29 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_29);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_29;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

INVx3_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_9),
.B(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_5),
.B(n_1),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_3),
.B(n_0),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_10),
.B(n_6),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_12),
.B(n_4),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_17),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

OAI211xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_20),
.B(n_18),
.C(n_13),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.B1(n_16),
.B2(n_13),
.Y(n_29)
);


endmodule