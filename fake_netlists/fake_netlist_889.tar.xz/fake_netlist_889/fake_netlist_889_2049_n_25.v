module fake_netlist_889_2049_n_25 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_25;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_SL g13 ( 
.A(n_11),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_12),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_3),
.A2(n_1),
.B1(n_10),
.B2(n_8),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_4),
.B(n_5),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NOR2x1_ASAP7_75t_SL g19 ( 
.A(n_16),
.B(n_4),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_13),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_18),
.B1(n_17),
.B2(n_14),
.C(n_15),
.Y(n_22)
);

OR5x1_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_19),
.C(n_7),
.D(n_6),
.E(n_0),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_9),
.B(n_2),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);


endmodule