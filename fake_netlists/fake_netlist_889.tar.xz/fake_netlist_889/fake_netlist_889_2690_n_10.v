module fake_netlist_889_2690_n_10 (n_0, n_1, n_2, n_10);

input n_0;
input n_1;
input n_2;

output n_10;

wire n_5;
wire n_3;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

HB1xp67_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

AO31x2_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_5)
);

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_6)
);

NAND4xp75_ASAP7_75t_SL g7 ( 
.A(n_6),
.B(n_2),
.C(n_5),
.D(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

INVx5_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

OR2x6_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_3),
.Y(n_10)
);


endmodule