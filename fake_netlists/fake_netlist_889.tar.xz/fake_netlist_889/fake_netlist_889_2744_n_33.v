module fake_netlist_889_2744_n_33 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_33);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_33;

wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_26;
wire n_29;

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

AND2x6_ASAP7_75t_L g17 ( 
.A(n_5),
.B(n_9),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_1),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_15),
.B1(n_14),
.B2(n_0),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_14),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_16),
.Y(n_25)
);

OAI22xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_25),
.B1(n_19),
.B2(n_22),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_18),
.Y(n_27)
);

XNOR2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_20),
.Y(n_28)
);

NOR2x1_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_16),
.Y(n_29)
);

NOR2x1_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_17),
.Y(n_30)
);

NAND4xp25_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_15),
.C(n_17),
.D(n_3),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

AOI322xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_30),
.A3(n_8),
.B1(n_7),
.B2(n_6),
.C1(n_13),
.C2(n_12),
.Y(n_33)
);


endmodule