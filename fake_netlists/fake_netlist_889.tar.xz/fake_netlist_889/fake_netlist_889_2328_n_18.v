module fake_netlist_889_2328_n_18 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_18);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_18;

wire n_15;
wire n_11;
wire n_9;
wire n_17;
wire n_13;
wire n_16;
wire n_14;
wire n_10;
wire n_12;

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_8),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_3),
.B(n_1),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_1),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B1(n_12),
.B2(n_9),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

O2A1O1Ixp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B(n_2),
.C(n_0),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B1(n_15),
.B2(n_2),
.C(n_3),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_4),
.B1(n_5),
.B2(n_7),
.C1(n_11),
.C2(n_15),
.Y(n_18)
);


endmodule