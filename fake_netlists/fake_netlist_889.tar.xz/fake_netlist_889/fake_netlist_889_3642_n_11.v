module fake_netlist_889_3642_n_11 (n_0, n_1, n_2, n_11);

input n_0;
input n_1;
input n_2;

output n_11;

wire n_5;
wire n_3;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

AND2x2_ASAP7_75t_SL g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AO21x2_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B(n_0),
.Y(n_5)
);

OAI22xp33_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

O2A1O1Ixp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_4),
.B(n_6),
.C(n_5),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_3),
.B1(n_7),
.B2(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI222xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_2),
.B1(n_3),
.B2(n_6),
.C1(n_9),
.C2(n_4),
.Y(n_11)
);


endmodule