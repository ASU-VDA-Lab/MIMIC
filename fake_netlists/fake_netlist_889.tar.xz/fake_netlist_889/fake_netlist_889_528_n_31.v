module fake_netlist_889_528_n_31 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_31);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_31;

wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_25;
wire n_22;
wire n_26;
wire n_29;

INVx1_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_3),
.B(n_9),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_15),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_6),
.A2(n_5),
.B(n_0),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_6),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_16),
.B(n_7),
.C(n_2),
.Y(n_23)
);

AOI211xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_17),
.B(n_20),
.C(n_21),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_7),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_17),
.B1(n_23),
.B2(n_18),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_8),
.B(n_4),
.Y(n_29)
);

INVx8_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_13),
.B1(n_12),
.B2(n_10),
.Y(n_31)
);


endmodule