module fake_netlist_889_1817_n_16 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_16);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_16;

wire n_15;
wire n_11;
wire n_9;
wire n_13;
wire n_14;
wire n_10;
wire n_8;
wire n_12;

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

AND2x6_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_6),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_9),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_9),
.B(n_7),
.C(n_6),
.Y(n_14)
);

AOI22x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);


endmodule