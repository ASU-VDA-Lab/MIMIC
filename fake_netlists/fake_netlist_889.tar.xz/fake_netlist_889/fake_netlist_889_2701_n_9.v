module fake_netlist_889_2701_n_9 (n_0, n_1, n_9);

input n_0;
input n_1;

output n_9;

wire n_5;
wire n_2;
wire n_3;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

INVx1_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

OAI21x1_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

OAI221xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.C(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AOI222xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_0),
.B1(n_1),
.B2(n_4),
.C1(n_7),
.C2(n_6),
.Y(n_9)
);


endmodule