module fake_netlist_889_4165_n_15 (n_0, n_1, n_3, n_2, n_15);

input n_0;
input n_1;
input n_3;
input n_2;

output n_15;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

INVx4_ASAP7_75t_SL g4 ( 
.A(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_0),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_4),
.B1(n_9),
.B2(n_6),
.Y(n_11)
);

AO22x1_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_1),
.B1(n_3),
.B2(n_2),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_6),
.B1(n_3),
.B2(n_2),
.Y(n_13)
);

BUFx12f_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C1(n_12),
.C2(n_13),
.Y(n_15)
);


endmodule