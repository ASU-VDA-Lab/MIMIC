module fake_netlist_889_2356_n_14 (n_0, n_1, n_2, n_14);

input n_0;
input n_1;
input n_2;

output n_14;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

INVx3_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_1),
.Y(n_5)
);

NAND2x1p5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_4),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AOI221xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_4),
.B1(n_3),
.B2(n_5),
.C(n_6),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_4),
.B1(n_3),
.B2(n_8),
.C(n_1),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_3),
.B(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_SL g12 ( 
.A(n_11),
.Y(n_12)
);

NAND2xp33_ASAP7_75t_R g13 ( 
.A(n_10),
.B(n_2),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_0),
.B1(n_11),
.B2(n_13),
.Y(n_14)
);


endmodule