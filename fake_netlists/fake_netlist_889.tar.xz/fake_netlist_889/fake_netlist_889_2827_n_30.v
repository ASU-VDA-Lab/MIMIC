module fake_netlist_889_2827_n_30 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_30);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_30;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_25;
wire n_22;
wire n_26;
wire n_29;

INVx2_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_0),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_6),
.B(n_3),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_5),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_7),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_21),
.C(n_22),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NAND2x1p5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_15),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_17),
.B1(n_19),
.B2(n_18),
.C(n_7),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_27),
.Y(n_28)
);

INVxp67_ASAP7_75t_SL g29 ( 
.A(n_28),
.Y(n_29)
);

AOI322xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_4),
.A3(n_2),
.B1(n_13),
.B2(n_14),
.C1(n_9),
.C2(n_11),
.Y(n_30)
);


endmodule