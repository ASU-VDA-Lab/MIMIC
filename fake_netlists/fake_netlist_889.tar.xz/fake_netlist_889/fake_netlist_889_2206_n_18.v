module fake_netlist_889_2206_n_18 (n_0, n_1, n_3, n_2, n_18);

input n_0;
input n_1;
input n_3;
input n_2;

output n_18;

wire n_5;
wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_17;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

AND2x6_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

BUFx3_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_1),
.B1(n_3),
.B2(n_5),
.Y(n_7)
);

OAI22xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B1(n_5),
.B2(n_4),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_1),
.Y(n_9)
);

INVx5_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_9),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_12),
.B(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_SL g15 ( 
.A1(n_13),
.A2(n_11),
.B(n_12),
.C(n_10),
.Y(n_15)
);

AOI321xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_10),
.A3(n_11),
.B1(n_8),
.B2(n_12),
.C(n_7),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_10),
.B1(n_15),
.B2(n_13),
.Y(n_18)
);


endmodule