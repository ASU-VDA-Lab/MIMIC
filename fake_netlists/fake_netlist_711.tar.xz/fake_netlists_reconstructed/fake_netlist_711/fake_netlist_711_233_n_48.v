module fake_netlist_711_233_n_48 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_48);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_48;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

INVx1_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_14),
.B1(n_17),
.B2(n_9),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_7),
.Y(n_28)
);

INVx8_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_19),
.B1(n_18),
.B2(n_16),
.Y(n_30)
);

INVx5_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_29),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_23),
.B1(n_22),
.B2(n_21),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_31),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_37),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_30),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_36),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_SL g41 ( 
.A(n_39),
.B(n_26),
.Y(n_41)
);

NAND3xp33_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_28),
.C(n_27),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_0),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

NOR2x1_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_4),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_8),
.B1(n_6),
.B2(n_5),
.Y(n_46)
);

AOI221x1_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_45),
.B1(n_13),
.B2(n_10),
.C(n_12),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_15),
.Y(n_48)
);


endmodule