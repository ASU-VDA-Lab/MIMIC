module fake_netlist_711_904_n_21 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_21);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_21;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

CKINVDCx20_ASAP7_75t_R g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

OAI221xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_4),
.Y(n_12)
);

NAND2xp33_ASAP7_75t_R g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_3),
.B(n_14),
.C(n_5),
.Y(n_17)
);

BUFx12f_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVxp33_ASAP7_75t_SL g19 ( 
.A(n_18),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_6),
.B(n_5),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_19),
.A2(n_6),
.B1(n_18),
.B2(n_20),
.Y(n_21)
);


endmodule