module fake_netlist_711_173_n_57 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_57);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_57;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_46;
wire n_31;
wire n_23;
wire n_41;
wire n_29;
wire n_56;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;
wire n_55;

NAND2x1_ASAP7_75t_L g23 ( 
.A(n_2),
.B(n_1),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_5),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_13),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_SL g30 ( 
.A(n_9),
.B(n_8),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_10),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_0),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_29),
.A2(n_17),
.B1(n_16),
.B2(n_3),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_32),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_3),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_24),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

BUFx4_ASAP7_75t_SL g40 ( 
.A(n_34),
.Y(n_40)
);

CKINVDCx12_ASAP7_75t_R g41 ( 
.A(n_34),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_36),
.B1(n_30),
.B2(n_35),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_38),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_39),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_38),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_40),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

XNOR2x1_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_40),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_27),
.Y(n_49)
);

AOI221xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_44),
.B1(n_30),
.B2(n_24),
.C(n_25),
.Y(n_50)
);

OAI22xp5_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_28),
.B1(n_25),
.B2(n_23),
.Y(n_51)
);

AOI221xp5_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_28),
.B1(n_33),
.B2(n_26),
.C(n_16),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_48),
.Y(n_53)
);

INVx2_ASAP7_75t_SL g54 ( 
.A(n_52),
.Y(n_54)
);

OR2x2_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_48),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_54),
.B1(n_55),
.B2(n_19),
.Y(n_56)
);

AOI322xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_21),
.A3(n_20),
.B1(n_11),
.B2(n_15),
.C1(n_4),
.C2(n_7),
.Y(n_57)
);


endmodule