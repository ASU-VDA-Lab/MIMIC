module fake_netlist_711_4_n_25 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_25);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_25;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_19;
wire n_13;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_0),
.B(n_11),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_SL g15 ( 
.A(n_7),
.B(n_3),
.Y(n_15)
);

INVx4_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_7),
.B1(n_4),
.B2(n_8),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_6),
.B1(n_4),
.B2(n_1),
.Y(n_18)
);

AND3x2_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_2),
.C(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

INVxp33_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_16),
.B1(n_12),
.B2(n_19),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_14),
.B(n_16),
.Y(n_25)
);


endmodule