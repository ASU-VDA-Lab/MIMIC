module fake_netlist_711_1059_n_26 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_26);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_26;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_19;
wire n_11;
wire n_25;
wire n_13;
wire n_14;
wire n_12;

NAND2xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_10),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_5),
.A2(n_8),
.B1(n_3),
.B2(n_7),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_7),
.A2(n_5),
.B1(n_2),
.B2(n_6),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_0),
.B(n_1),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_4),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_15),
.B(n_12),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_13),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_22),
.B(n_19),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_11),
.B(n_23),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_21),
.B(n_18),
.Y(n_26)
);


endmodule