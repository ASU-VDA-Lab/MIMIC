module fake_netlist_711_319_n_18 (n_4, n_2, n_3, n_1, n_0, n_18);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_18;

wire n_9;
wire n_17;
wire n_7;
wire n_14;
wire n_15;
wire n_11;
wire n_16;
wire n_8;
wire n_10;
wire n_13;
wire n_5;
wire n_6;
wire n_12;

BUFx10_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

BUFx5_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_5),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_7),
.B1(n_5),
.B2(n_0),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_5),
.B1(n_8),
.B2(n_0),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_8),
.Y(n_13)
);

O2A1O1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_4),
.B(n_2),
.C(n_1),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_SL g15 ( 
.A1(n_12),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C(n_13),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C1(n_15),
.C2(n_16),
.Y(n_18)
);


endmodule