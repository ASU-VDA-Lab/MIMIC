module fake_netlist_711_6_n_27 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_12;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

OR2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_4),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_1),
.A2(n_6),
.B1(n_3),
.B2(n_11),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_3),
.B1(n_9),
.B2(n_8),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

INVxp33_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_2),
.B(n_4),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_5),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_12),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_19),
.Y(n_22)
);

AOI222xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B1(n_13),
.B2(n_17),
.C1(n_14),
.C2(n_0),
.Y(n_23)
);

AOI211xp5_ASAP7_75t_SL g24 ( 
.A1(n_21),
.A2(n_13),
.B(n_7),
.C(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_22),
.B1(n_10),
.B2(n_7),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_24),
.B(n_26),
.Y(n_27)
);


endmodule