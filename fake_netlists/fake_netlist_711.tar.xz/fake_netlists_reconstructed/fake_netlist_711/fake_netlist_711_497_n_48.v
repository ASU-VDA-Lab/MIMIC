module fake_netlist_711_497_n_48 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_48);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_48;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;

AND2x2_ASAP7_75t_SL g17 ( 
.A(n_0),
.B(n_3),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_7),
.B(n_9),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_14),
.B(n_4),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_10),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_15),
.A2(n_8),
.B1(n_2),
.B2(n_6),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_6),
.B(n_16),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_L g25 ( 
.A1(n_18),
.A2(n_11),
.B(n_1),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_22),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_1),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

AO21x2_ASAP7_75t_L g29 ( 
.A1(n_25),
.A2(n_20),
.B(n_21),
.Y(n_29)
);

OA21x2_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_19),
.B(n_24),
.Y(n_30)
);

OAI21x1_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_23),
.B(n_17),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_27),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_29),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_27),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_31),
.B1(n_27),
.B2(n_29),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

BUFx6f_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

AOI211xp5_ASAP7_75t_SL g41 ( 
.A1(n_36),
.A2(n_23),
.B(n_28),
.C(n_33),
.Y(n_41)
);

NAND5xp2_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_37),
.C(n_31),
.D(n_33),
.E(n_26),
.Y(n_42)
);

OAI21xp33_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_26),
.B(n_28),
.Y(n_43)
);

OAI222xp33_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_5),
.B1(n_28),
.B2(n_30),
.C1(n_23),
.C2(n_40),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

XNOR2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_5),
.Y(n_47)
);

OAI21x1_ASAP7_75t_SL g48 ( 
.A1(n_47),
.A2(n_46),
.B(n_44),
.Y(n_48)
);


endmodule