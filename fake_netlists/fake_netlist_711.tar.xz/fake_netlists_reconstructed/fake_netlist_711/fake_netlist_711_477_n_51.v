module fake_netlist_711_477_n_51 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_51);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_51;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_19;
wire n_39;

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_9),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_4),
.B(n_5),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_13),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_1),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_1),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_4),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

OR2x6_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_23),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

OAI221xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_21),
.B1(n_24),
.B2(n_22),
.C(n_5),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_27),
.B1(n_26),
.B2(n_21),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_24),
.B1(n_16),
.B2(n_6),
.C(n_0),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_R g37 ( 
.A(n_34),
.B(n_29),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_16),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_SL g40 ( 
.A1(n_35),
.A2(n_8),
.B1(n_3),
.B2(n_2),
.Y(n_40)
);

INVxp67_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_R g42 ( 
.A(n_38),
.B(n_37),
.Y(n_42)
);

OA22x2_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_35),
.B1(n_14),
.B2(n_10),
.Y(n_43)
);

NAND2xp33_ASAP7_75t_SL g44 ( 
.A(n_39),
.B(n_35),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_42),
.Y(n_45)
);

NOR4xp25_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_40),
.C(n_43),
.D(n_44),
.Y(n_46)
);

CKINVDCx20_ASAP7_75t_R g47 ( 
.A(n_42),
.Y(n_47)
);

CKINVDCx6p67_ASAP7_75t_R g48 ( 
.A(n_42),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_45),
.B1(n_48),
.B2(n_50),
.Y(n_51)
);


endmodule