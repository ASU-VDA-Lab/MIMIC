module fake_netlist_711_337_n_18 (n_4, n_2, n_3, n_1, n_0, n_18);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_18;

wire n_9;
wire n_17;
wire n_7;
wire n_15;
wire n_14;
wire n_11;
wire n_16;
wire n_12;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_13;

AO22x2_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_0),
.B1(n_3),
.B2(n_4),
.Y(n_5)
);

BUFx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

AND2x6_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_4),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_6),
.B1(n_5),
.B2(n_0),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_SL g10 ( 
.A(n_8),
.B(n_5),
.C(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_10),
.C(n_5),
.Y(n_12)
);

NAND2x1p5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI211xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_7),
.B(n_4),
.C(n_1),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_1),
.B2(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_7),
.B1(n_14),
.B2(n_17),
.Y(n_18)
);


endmodule