module fake_netlist_711_834_n_50 (n_2, n_21, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_50);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_50;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_46;
wire n_31;
wire n_23;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

AND2x4_ASAP7_75t_L g22 ( 
.A(n_0),
.B(n_2),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_13),
.B(n_10),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_11),
.B(n_14),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

CKINVDCx11_ASAP7_75t_R g33 ( 
.A(n_29),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_33),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_33),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_37),
.B1(n_34),
.B2(n_25),
.C(n_26),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NOR2x1_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_22),
.Y(n_43)
);

AO22x2_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_24),
.B1(n_22),
.B2(n_27),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_30),
.B1(n_19),
.B2(n_16),
.C(n_24),
.Y(n_46)
);

OAI22x1_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_19),
.B1(n_16),
.B2(n_1),
.Y(n_47)
);

NOR3xp33_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_23),
.C(n_3),
.Y(n_48)
);

OAI22x1_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_48),
.B1(n_7),
.B2(n_6),
.Y(n_49)
);

AOI322xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_23),
.A3(n_15),
.B1(n_12),
.B2(n_8),
.C1(n_20),
.C2(n_17),
.Y(n_50)
);


endmodule