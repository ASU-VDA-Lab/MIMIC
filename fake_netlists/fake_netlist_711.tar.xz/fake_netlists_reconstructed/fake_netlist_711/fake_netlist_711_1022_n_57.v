module fake_netlist_711_1022_n_57 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_57);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_57;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_56;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;
wire n_55;

CKINVDCx16_ASAP7_75t_R g20 ( 
.A(n_13),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_4),
.B(n_17),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_9),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_12),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_23),
.B(n_16),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

BUFx4_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_31),
.Y(n_40)
);

INVx4_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

INVx2_ASAP7_75t_SL g42 ( 
.A(n_40),
.Y(n_42)
);

NOR2xp67_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_36),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_20),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_33),
.B1(n_35),
.B2(n_24),
.C(n_25),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

O2A1O1Ixp33_ASAP7_75t_SL g48 ( 
.A1(n_47),
.A2(n_26),
.B(n_3),
.C(n_2),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_SL g49 ( 
.A1(n_46),
.A2(n_25),
.B(n_28),
.Y(n_49)
);

INVxp67_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_30),
.B(n_5),
.Y(n_51)
);

BUFx12f_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

BUFx2_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

AOI21xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_10),
.B(n_7),
.Y(n_54)
);

BUFx2_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

AOI22x1_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_52),
.B1(n_51),
.B2(n_16),
.Y(n_56)
);

AOI22x1_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_54),
.B1(n_19),
.B2(n_14),
.Y(n_57)
);


endmodule