module fake_netlist_711_1334_n_55 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_55);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_55;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_23;
wire n_41;
wire n_46;
wire n_29;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_19;
wire n_39;

AND2x2_ASAP7_75t_L g18 ( 
.A(n_3),
.B(n_11),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_2),
.B(n_5),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_9),
.Y(n_22)
);

XOR2xp5_ASAP7_75t_L g23 ( 
.A(n_5),
.B(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

CKINVDCx16_ASAP7_75t_R g26 ( 
.A(n_13),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_0),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_26),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_22),
.B(n_6),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_SL g32 ( 
.A(n_31),
.B(n_22),
.C(n_21),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_19),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_34),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_36),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_37),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_27),
.B(n_18),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

NAND2xp33_ASAP7_75t_R g44 ( 
.A(n_43),
.B(n_31),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_39),
.B1(n_23),
.B2(n_19),
.Y(n_45)
);

CKINVDCx16_ASAP7_75t_R g46 ( 
.A(n_41),
.Y(n_46)
);

OAI322xp33_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_23),
.A3(n_28),
.B1(n_39),
.B2(n_18),
.C1(n_0),
.C2(n_1),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_R g49 ( 
.A1(n_46),
.A2(n_42),
.B1(n_4),
.B2(n_1),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_44),
.Y(n_51)
);

NAND4xp25_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_47),
.C(n_16),
.D(n_4),
.Y(n_52)
);

INVx4_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

NAND4xp75_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_17),
.C(n_16),
.D(n_8),
.Y(n_54)
);

AOI322xp5_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_10),
.A3(n_12),
.B1(n_17),
.B2(n_50),
.C1(n_54),
.C2(n_53),
.Y(n_55)
);


endmodule