module fake_netlist_711_213_n_18 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_18);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_9;
wire n_17;
wire n_7;
wire n_15;
wire n_11;
wire n_13;
wire n_16;
wire n_8;
wire n_10;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_8),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_7),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_10),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_15),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_9),
.B1(n_4),
.B2(n_0),
.Y(n_17)
);

NOR4xp25_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_9),
.C(n_5),
.D(n_2),
.Y(n_18)
);


endmodule