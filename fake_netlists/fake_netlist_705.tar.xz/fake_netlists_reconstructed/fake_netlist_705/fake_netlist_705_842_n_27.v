module fake_netlist_705_842_n_27 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_13;
wire n_25;
wire n_19;
wire n_14;

INVx2_ASAP7_75t_SL g13 ( 
.A(n_2),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_6),
.A2(n_0),
.B1(n_12),
.B2(n_8),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_1),
.B1(n_0),
.B2(n_4),
.C(n_5),
.Y(n_19)
);

AND3x4_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_7),
.C(n_1),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI221x1_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_15),
.B1(n_16),
.B2(n_21),
.C(n_13),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_16),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_14),
.B1(n_7),
.B2(n_9),
.Y(n_26)
);

AOI31xp67_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_14),
.A3(n_11),
.B(n_10),
.Y(n_27)
);


endmodule