module fake_netlist_705_451_n_5 (n_0, n_1, n_5);

input n_0;
input n_1;

output n_5;

wire n_4;
wire n_2;
wire n_3;

BUFx2_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

NOR2x1_ASAP7_75t_SL g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

NOR4xp25_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.C(n_1),
.D(n_2),
.Y(n_4)
);

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_5)
);


endmodule