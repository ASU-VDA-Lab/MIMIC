module fake_netlist_705_1081_n_25 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_25);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_25;

wire n_24;
wire n_21;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_12;
wire n_8;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_6),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_3),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_1),
.Y(n_12)
);

A2O1A1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_3),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OR2x6_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_11),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_8),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_9),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_16),
.B1(n_10),
.B2(n_9),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_17),
.B1(n_20),
.B2(n_8),
.C(n_11),
.Y(n_21)
);

NAND2x1p5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_4),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_23),
.A2(n_5),
.B1(n_7),
.B2(n_24),
.Y(n_25)
);


endmodule