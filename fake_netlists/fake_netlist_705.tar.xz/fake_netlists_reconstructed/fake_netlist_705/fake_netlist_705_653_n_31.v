module fake_netlist_705_653_n_31 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_31);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_31;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_29;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;

INVx2_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_SL g21 ( 
.A(n_17),
.B(n_18),
.C(n_15),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_6),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_6),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NAND4xp25_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_19),
.C(n_14),
.D(n_7),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_26),
.B(n_7),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_16),
.B1(n_22),
.B2(n_0),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI322xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.A3(n_5),
.B1(n_4),
.B2(n_2),
.C1(n_13),
.C2(n_12),
.Y(n_31)
);


endmodule