module fake_netlist_705_1101_n_33 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_33);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_33;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_7;
wire n_23;
wire n_31;
wire n_29;
wire n_13;
wire n_8;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

AND3x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.C(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

NAND2xp33_ASAP7_75t_L g11 ( 
.A(n_4),
.B(n_3),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_4),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_6),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_2),
.Y(n_16)
);

AOI21x1_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_9),
.B(n_7),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_11),
.B(n_12),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_8),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_19),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_18),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_14),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

NAND3xp33_ASAP7_75t_SL g27 ( 
.A(n_25),
.B(n_18),
.C(n_19),
.Y(n_27)
);

OAI21xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_23),
.B(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

XNOR2xp5_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_24),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_24),
.B1(n_16),
.B2(n_17),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_28),
.B(n_16),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_31),
.Y(n_33)
);


endmodule