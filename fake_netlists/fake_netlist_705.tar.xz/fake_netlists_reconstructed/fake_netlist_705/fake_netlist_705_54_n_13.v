module fake_netlist_705_54_n_13 (n_4, n_2, n_3, n_1, n_0, n_13);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_13;

wire n_9;
wire n_7;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

OAI21xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_7),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_1),
.B1(n_4),
.B2(n_2),
.C(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_8),
.B1(n_10),
.B2(n_11),
.Y(n_13)
);


endmodule