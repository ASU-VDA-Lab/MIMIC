module fake_netlist_705_329_n_15 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_15);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_15;

wire n_9;
wire n_7;
wire n_14;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_12;

AND2x4_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_5),
.Y(n_7)
);

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_1),
.A2(n_4),
.B1(n_5),
.B2(n_3),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_6),
.B1(n_4),
.B2(n_2),
.Y(n_10)
);

INVx5_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_7),
.B(n_8),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

OA22x2_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_7),
.B1(n_11),
.B2(n_2),
.Y(n_14)
);

OR2x6_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_6),
.Y(n_15)
);


endmodule