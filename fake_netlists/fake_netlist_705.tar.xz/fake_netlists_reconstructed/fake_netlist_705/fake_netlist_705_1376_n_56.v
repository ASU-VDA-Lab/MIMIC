module fake_netlist_705_1376_n_56 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_56);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_56;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_16;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_19;
wire n_39;
wire n_55;

INVx1_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx4_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_3),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_7),
.B(n_6),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_0),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_21),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_0),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_13),
.B1(n_12),
.B2(n_1),
.Y(n_28)
);

OR2x6_ASAP7_75t_L g29 ( 
.A(n_23),
.B(n_1),
.Y(n_29)
);

OA21x2_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_19),
.B(n_16),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_18),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_25),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_30),
.B1(n_29),
.B2(n_31),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_28),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_30),
.B(n_22),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_35),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_30),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_18),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_42)
);

INVx1_ASAP7_75t_SL g43 ( 
.A(n_39),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_24),
.B1(n_15),
.B2(n_14),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_42),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

NOR2x1p5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_24),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_41),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_43),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_44),
.B(n_15),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

INVx1_ASAP7_75t_SL g53 ( 
.A(n_50),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_47),
.B1(n_48),
.B2(n_4),
.Y(n_54)
);

HB1xp67_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

AOI22xp33_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_11),
.B1(n_51),
.B2(n_55),
.Y(n_56)
);


endmodule