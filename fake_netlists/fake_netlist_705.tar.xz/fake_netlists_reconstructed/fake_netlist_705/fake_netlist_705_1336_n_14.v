module fake_netlist_705_1336_n_14 (n_3, n_0, n_2, n_1, n_14);

input n_3;
input n_0;
input n_2;
input n_1;

output n_14;

wire n_9;
wire n_4;
wire n_7;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx3_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_5),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AOI21x1_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_1),
.B(n_3),
.C(n_2),
.Y(n_12)
);

INVx4_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B(n_8),
.Y(n_14)
);


endmodule