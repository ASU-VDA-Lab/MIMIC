module fake_netlist_705_348_n_20 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_20);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_20;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_7;
wire n_13;
wire n_8;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_4),
.B(n_1),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_9),
.B1(n_8),
.B2(n_10),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_2),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AO22x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_5),
.B2(n_2),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.B1(n_3),
.B2(n_0),
.Y(n_20)
);


endmodule