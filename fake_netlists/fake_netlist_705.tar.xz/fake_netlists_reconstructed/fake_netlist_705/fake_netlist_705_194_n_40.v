module fake_netlist_705_194_n_40 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_40);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_40;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_5),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_2),
.B(n_0),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_13),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_16),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_17),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_4),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_SL g26 ( 
.A1(n_22),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_22),
.A2(n_6),
.B(n_3),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_18),
.A2(n_15),
.B1(n_5),
.B2(n_1),
.Y(n_28)
);

OAI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_19),
.B1(n_23),
.B2(n_21),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_26),
.A2(n_19),
.B1(n_25),
.B2(n_20),
.C(n_24),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_27),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_31),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_15),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI32xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_17),
.A3(n_16),
.B1(n_7),
.B2(n_8),
.Y(n_36)
);

XNOR2x1_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_9),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_34),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.B1(n_11),
.B2(n_10),
.Y(n_40)
);


endmodule