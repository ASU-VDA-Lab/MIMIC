module fake_netlist_705_378_n_28 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_28);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_28;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_25;
wire n_19;
wire n_14;

INVx2_ASAP7_75t_SL g14 ( 
.A(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_6),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_11),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_13),
.B(n_7),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_19),
.B(n_4),
.Y(n_21)
);

OAI21xp33_ASAP7_75t_SL g22 ( 
.A1(n_20),
.A2(n_16),
.B(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_17),
.B1(n_15),
.B2(n_18),
.C(n_21),
.Y(n_24)
);

NAND4xp75_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_7),
.C(n_6),
.D(n_4),
.Y(n_25)
);

NAND4xp75_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_8),
.C(n_5),
.D(n_3),
.Y(n_26)
);

XNOR2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_9),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_12),
.B1(n_19),
.B2(n_23),
.Y(n_28)
);


endmodule