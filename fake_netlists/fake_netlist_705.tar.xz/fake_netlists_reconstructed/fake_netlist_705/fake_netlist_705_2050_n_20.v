module fake_netlist_705_2050_n_20 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_20);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_20;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx2_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_4),
.B(n_5),
.Y(n_12)
);

AO31x2_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_5),
.A3(n_4),
.B(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_SL g14 ( 
.A(n_11),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B(n_12),
.Y(n_16)
);

AOI322xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_1),
.A3(n_3),
.B1(n_6),
.B2(n_7),
.C1(n_13),
.C2(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B(n_6),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_13),
.Y(n_20)
);


endmodule