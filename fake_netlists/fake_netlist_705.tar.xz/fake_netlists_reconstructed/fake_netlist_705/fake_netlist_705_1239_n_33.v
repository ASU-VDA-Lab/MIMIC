module fake_netlist_705_1239_n_33 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_33);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_33;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_12;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_3),
.B(n_0),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_4),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_4),
.B(n_6),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_7),
.A2(n_8),
.B(n_2),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_13),
.B1(n_10),
.B2(n_14),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B(n_10),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_16),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

OAI21xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_18),
.B(n_14),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_15),
.B1(n_20),
.B2(n_11),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_20),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

NOR2x1_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_11),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_5),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_9),
.B2(n_20),
.Y(n_33)
);


endmodule