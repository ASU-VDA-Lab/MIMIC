module fake_netlist_741_2042_n_19 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_19);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_19;

wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_9;
wire n_7;
wire n_17;
wire n_12;
wire n_15;
wire n_8;

BUFx10_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_8),
.B1(n_7),
.B2(n_1),
.Y(n_12)
);

INVxp67_ASAP7_75t_SL g13 ( 
.A(n_12),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_7),
.Y(n_14)
);

AOI21xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_13),
.B(n_2),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B1(n_14),
.B2(n_7),
.C1(n_4),
.C2(n_2),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B1(n_5),
.B2(n_4),
.Y(n_17)
);

AO22x2_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_6),
.B1(n_5),
.B2(n_3),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_3),
.B1(n_6),
.B2(n_17),
.Y(n_19)
);


endmodule