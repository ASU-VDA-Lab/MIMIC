module fake_netlist_741_1640_n_47 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_47);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_47;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_19),
.B(n_3),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_15),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_16),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_23),
.B(n_16),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_17),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_22),
.B(n_17),
.Y(n_32)
);

AOI221xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_28),
.B1(n_26),
.B2(n_24),
.C(n_25),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_29),
.B(n_27),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_30),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_28),
.B1(n_21),
.B2(n_18),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_35),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_18),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_21),
.Y(n_39)
);

NOR3xp33_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_19),
.C(n_2),
.Y(n_40)
);

NOR2xp67_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_5),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_6),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_11),
.B1(n_10),
.B2(n_12),
.C(n_13),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_41),
.Y(n_44)
);

AND2x2_ASAP7_75t_SL g45 ( 
.A(n_43),
.B(n_42),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_14),
.B1(n_20),
.B2(n_46),
.Y(n_47)
);


endmodule