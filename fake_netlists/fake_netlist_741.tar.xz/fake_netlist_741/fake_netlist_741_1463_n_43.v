module fake_netlist_741_1463_n_43 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_43);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_43;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_15;
wire n_41;
wire n_29;
wire n_32;

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_2),
.B(n_10),
.Y(n_15)
);

CKINVDCx16_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_11),
.B(n_8),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_5),
.B(n_3),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_22),
.A2(n_13),
.B(n_4),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_6),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_19),
.B(n_7),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_24),
.B(n_16),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_25),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_25),
.Y(n_32)
);

NOR4xp25_ASAP7_75t_SL g33 ( 
.A(n_31),
.B(n_22),
.C(n_26),
.D(n_20),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_29),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_30),
.B1(n_28),
.B2(n_27),
.Y(n_36)
);

NOR2x1_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_21),
.Y(n_37)
);

NAND3xp33_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_33),
.C(n_30),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OAI22x1_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_39),
.B1(n_32),
.B2(n_14),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_15),
.B(n_17),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_7),
.B1(n_32),
.B2(n_42),
.Y(n_43)
);


endmodule