module fake_netlist_741_1347_n_32 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_32);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_32;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_29;

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_9),
.B(n_0),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_2),
.B(n_7),
.Y(n_17)
);

INVxp33_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_10),
.B(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_7),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_3),
.C(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_16),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_18),
.B1(n_14),
.B2(n_19),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_18),
.Y(n_26)
);

INVxp33_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVxp67_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_30),
.B1(n_25),
.B2(n_22),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_11),
.B1(n_8),
.B2(n_4),
.Y(n_32)
);


endmodule