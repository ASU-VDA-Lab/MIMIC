module fake_netlist_741_1985_n_37 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_37);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_37;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_8),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_7),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_15),
.B(n_11),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_23),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_16),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_17),
.B(n_14),
.Y(n_31)
);

AOI221x1_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_17),
.B1(n_11),
.B2(n_18),
.C(n_20),
.Y(n_32)
);

AOI221xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_22),
.B1(n_21),
.B2(n_0),
.C(n_2),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_5),
.Y(n_34)
);

INVx8_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_35),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_10),
.B1(n_12),
.B2(n_34),
.Y(n_37)
);


endmodule