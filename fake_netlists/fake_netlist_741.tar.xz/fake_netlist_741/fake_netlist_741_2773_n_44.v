module fake_netlist_741_2773_n_44 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_44);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_44;

wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_15),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_1),
.Y(n_25)
);

AOI21x1_ASAP7_75t_L g26 ( 
.A1(n_20),
.A2(n_0),
.B(n_17),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_8),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

INVxp67_ASAP7_75t_SL g30 ( 
.A(n_24),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_19),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_23),
.Y(n_33)
);

OAI21xp33_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_27),
.B(n_22),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_32),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_32),
.Y(n_36)
);

AOI21xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_21),
.B(n_25),
.Y(n_37)
);

NAND2xp33_ASAP7_75t_SL g38 ( 
.A(n_37),
.B(n_36),
.Y(n_38)
);

AO21x1_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_26),
.B(n_21),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_28),
.Y(n_40)
);

CKINVDCx20_ASAP7_75t_R g41 ( 
.A(n_39),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_6),
.B1(n_4),
.B2(n_2),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_10),
.B1(n_9),
.B2(n_7),
.Y(n_43)
);

AOI222xp33_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_43),
.B1(n_14),
.B2(n_11),
.C1(n_18),
.C2(n_13),
.Y(n_44)
);


endmodule