module fake_netlist_851_869_n_49 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_49);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_49;

wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

INVxp33_ASAP7_75t_SL g22 ( 
.A(n_7),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_12),
.Y(n_24)
);

BUFx8_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_15),
.B(n_2),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

NOR2x1_ASAP7_75t_L g29 ( 
.A(n_6),
.B(n_17),
.Y(n_29)
);

A2O1A1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_19),
.B(n_3),
.C(n_1),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_19),
.B1(n_8),
.B2(n_4),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_23),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_24),
.B(n_22),
.C(n_27),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_31),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_29),
.B(n_25),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_25),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

OR2x6_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_36),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AND3x4_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_36),
.C(n_9),
.Y(n_43)
);

NOR3xp33_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_11),
.C(n_10),
.Y(n_44)
);

NAND2xp33_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_14),
.Y(n_45)
);

INVxp33_ASAP7_75t_SL g46 ( 
.A(n_43),
.Y(n_46)
);

XNOR2xp5_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_16),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_45),
.B(n_20),
.Y(n_48)
);

OR2x6_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_21),
.Y(n_49)
);


endmodule