module fake_netlist_851_1907_n_12 (n_2, n_0, n_3, n_1, n_12);

input n_2;
input n_0;
input n_3;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_9;
wire n_11;
wire n_8;

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI21xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_4),
.B(n_6),
.Y(n_9)
);

OAI311xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_3),
.A3(n_2),
.B1(n_1),
.C1(n_6),
.Y(n_10)
);

NOR2xp67_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_1),
.Y(n_11)
);

AO21x2_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_3),
.B(n_2),
.Y(n_12)
);


endmodule