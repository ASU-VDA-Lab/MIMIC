module fake_netlist_851_1693_n_66 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_66);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_66;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_54;
wire n_42;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_55;
wire n_65;
wire n_21;
wire n_35;
wire n_52;
wire n_38;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_9),
.B(n_14),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_20),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_8),
.B(n_18),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_12),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

XNOR2xp5_ASAP7_75t_L g27 ( 
.A(n_0),
.B(n_20),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_7),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_2),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_0),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

NOR2x2_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_2),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_28),
.B(n_25),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_32),
.A2(n_31),
.B(n_25),
.Y(n_37)
);

INVx4_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_32),
.Y(n_39)
);

AND2x4_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_33),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_33),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_34),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_27),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

OR2x6_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_37),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_39),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_22),
.B1(n_31),
.B2(n_35),
.C(n_23),
.Y(n_47)
);

AND2x4_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_30),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_39),
.B1(n_23),
.B2(n_24),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_SL g50 ( 
.A(n_47),
.B(n_31),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_48),
.Y(n_51)
);

AOI221x1_ASAP7_75t_SL g52 ( 
.A1(n_45),
.A2(n_30),
.B1(n_17),
.B2(n_3),
.C(n_16),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_45),
.Y(n_53)
);

NAND5xp2_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_23),
.C(n_24),
.D(n_21),
.E(n_3),
.Y(n_54)
);

OAI22xp5_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_21),
.B1(n_24),
.B2(n_25),
.Y(n_55)
);

NOR3xp33_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_28),
.C(n_25),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_51),
.B(n_36),
.Y(n_57)
);

NOR2x1_ASAP7_75t_L g58 ( 
.A(n_51),
.B(n_28),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_52),
.B1(n_28),
.B2(n_36),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

NAND3xp33_ASAP7_75t_L g61 ( 
.A(n_55),
.B(n_18),
.C(n_16),
.Y(n_61)
);

AND2x4_ASAP7_75t_L g62 ( 
.A(n_56),
.B(n_4),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_60),
.Y(n_63)
);

OAI22xp5_ASAP7_75t_SL g64 ( 
.A1(n_61),
.A2(n_54),
.B1(n_19),
.B2(n_5),
.Y(n_64)
);

OAI221xp5_ASAP7_75t_L g65 ( 
.A1(n_59),
.A2(n_19),
.B1(n_15),
.B2(n_10),
.C(n_11),
.Y(n_65)
);

AOI22xp5_ASAP7_75t_SL g66 ( 
.A1(n_63),
.A2(n_62),
.B1(n_64),
.B2(n_65),
.Y(n_66)
);


endmodule