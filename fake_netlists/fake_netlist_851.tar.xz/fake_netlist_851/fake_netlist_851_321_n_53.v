module fake_netlist_851_321_n_53 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_53);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_53;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_19),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_13),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_18),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_14),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

OA21x2_ASAP7_75t_L g30 ( 
.A1(n_20),
.A2(n_17),
.B(n_9),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_4),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_23),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_17),
.Y(n_36)
);

OAI211xp5_ASAP7_75t_SL g37 ( 
.A1(n_33),
.A2(n_31),
.B(n_29),
.C(n_28),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_32),
.Y(n_38)
);

INVxp67_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_SL g40 ( 
.A1(n_37),
.A2(n_35),
.B1(n_36),
.B2(n_24),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_36),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_26),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_30),
.B(n_27),
.Y(n_45)
);

A2O1A1Ixp33_ASAP7_75t_SL g46 ( 
.A1(n_43),
.A2(n_30),
.B(n_18),
.C(n_1),
.Y(n_46)
);

AND2x4_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_2),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_45),
.Y(n_48)
);

AOI21xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_6),
.B(n_5),
.Y(n_49)
);

AO22x2_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_10),
.B1(n_8),
.B2(n_7),
.Y(n_50)
);

AND2x4_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_12),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_SL g53 ( 
.A1(n_52),
.A2(n_51),
.B1(n_49),
.B2(n_15),
.Y(n_53)
);


endmodule