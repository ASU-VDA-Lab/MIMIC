module fake_netlist_851_704_n_44 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_44);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_44;

wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_17;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

BUFx10_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_14),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_11),
.B1(n_5),
.B2(n_0),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

BUFx8_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_0),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_3),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_18),
.B(n_3),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_16),
.B(n_4),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_15),
.B1(n_23),
.B2(n_20),
.Y(n_29)
);

OR2x6_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_15),
.Y(n_30)
);

OAI22xp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_19),
.B1(n_20),
.B2(n_21),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

AO21x2_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_27),
.B(n_30),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_SL g35 ( 
.A(n_32),
.B(n_29),
.C(n_24),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_37),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_SL g39 ( 
.A(n_36),
.B(n_5),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_1),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NOR2x1p5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_39),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_42),
.A2(n_9),
.B1(n_10),
.B2(n_43),
.Y(n_44)
);


endmodule