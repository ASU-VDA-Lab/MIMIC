module fake_netlist_851_62_n_50 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_50);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_50;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

INVx2_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_19),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_3),
.B(n_9),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_21),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_7),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_8),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_13),
.B(n_22),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_R g32 ( 
.A(n_17),
.B(n_10),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_16),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_29),
.B(n_19),
.Y(n_35)
);

NAND2xp33_ASAP7_75t_SL g36 ( 
.A(n_26),
.B(n_1),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_31),
.B1(n_24),
.B2(n_28),
.Y(n_38)
);

OAI222xp33_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_30),
.B1(n_27),
.B2(n_32),
.C1(n_5),
.C2(n_2),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_34),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVxp67_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_36),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_27),
.Y(n_45)
);

INVx1_ASAP7_75t_SL g46 ( 
.A(n_45),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_32),
.Y(n_47)
);

OAI221xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_11),
.B1(n_6),
.B2(n_12),
.C(n_14),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

AOI222xp33_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_47),
.B1(n_20),
.B2(n_15),
.C1(n_23),
.C2(n_18),
.Y(n_50)
);


endmodule