module fake_netlist_851_2135_n_38 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_38);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_38;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_34;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_27;

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_7),
.B(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_3),
.B(n_0),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_12),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_27),
.Y(n_31)
);

OAI31xp33_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_30),
.A3(n_22),
.B(n_26),
.Y(n_32)
);

OAI211xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_22),
.B(n_28),
.C(n_30),
.Y(n_33)
);

OAI21xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_20),
.B(n_24),
.Y(n_34)
);

NAND4xp25_ASAP7_75t_SL g35 ( 
.A(n_34),
.B(n_15),
.C(n_14),
.D(n_23),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_36),
.Y(n_37)
);

AOI322xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_6),
.A3(n_4),
.B1(n_16),
.B2(n_17),
.C1(n_10),
.C2(n_13),
.Y(n_38)
);


endmodule