module fake_netlist_851_1048_n_17 (n_4, n_2, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

AOI22xp33_ASAP7_75t_L g5 ( 
.A1(n_0),
.A2(n_1),
.B1(n_4),
.B2(n_3),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_2),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AO32x2_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_2),
.A3(n_1),
.B1(n_0),
.B2(n_3),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_6),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_1),
.Y(n_12)
);

NAND5xp2_ASAP7_75t_SL g13 ( 
.A(n_11),
.B(n_8),
.C(n_10),
.D(n_3),
.E(n_4),
.Y(n_13)
);

AOI221x1_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_4),
.B1(n_3),
.B2(n_1),
.C(n_2),
.Y(n_14)
);

AO22x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_15)
);

NOR4xp25_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_2),
.C(n_10),
.D(n_11),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_14),
.B1(n_16),
.B2(n_13),
.Y(n_17)
);


endmodule