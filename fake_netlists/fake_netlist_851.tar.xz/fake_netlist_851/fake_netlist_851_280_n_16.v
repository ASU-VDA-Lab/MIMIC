module fake_netlist_851_280_n_16 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_16);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_15;
wire n_13;
wire n_14;
wire n_12;
wire n_10;
wire n_11;
wire n_9;
wire n_8;

INVx2_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_0),
.A2(n_3),
.B1(n_5),
.B2(n_2),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

OR3x4_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_4),
.C(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

OAI321xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.A3(n_12),
.B1(n_8),
.B2(n_4),
.C(n_1),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_5),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_6),
.B1(n_7),
.B2(n_12),
.C1(n_14),
.C2(n_13),
.Y(n_16)
);


endmodule