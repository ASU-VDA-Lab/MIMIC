module fake_netlist_851_1228_n_40 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_40);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_40;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;

BUFx2_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_4),
.B(n_11),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_9),
.B(n_1),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_7),
.Y(n_20)
);

INVx4_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx5_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_13),
.B(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OAI21x1_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_18),
.B(n_19),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_21),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_26),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_30),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_18),
.B1(n_27),
.B2(n_26),
.Y(n_34)
);

A2O1A1Ixp33_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_27),
.B(n_15),
.C(n_16),
.Y(n_35)
);

OAI21xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_15),
.B(n_20),
.Y(n_36)
);

NAND4xp75_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_12),
.C(n_11),
.D(n_3),
.Y(n_37)
);

OR2x6_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_35),
.Y(n_38)
);

XNOR2xp5_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_22),
.Y(n_39)
);

AOI21xp33_ASAP7_75t_SL g40 ( 
.A1(n_39),
.A2(n_38),
.B(n_22),
.Y(n_40)
);


endmodule