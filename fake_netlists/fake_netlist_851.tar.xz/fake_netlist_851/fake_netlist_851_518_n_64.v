module fake_netlist_851_518_n_64 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_64);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_64;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_18;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_6),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_2),
.B(n_14),
.Y(n_20)
);

INVx4_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_11),
.B(n_3),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_0),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_27),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_22),
.Y(n_31)
);

NAND2x1_ASAP7_75t_L g32 ( 
.A(n_24),
.B(n_25),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_SL g33 ( 
.A1(n_28),
.A2(n_20),
.B(n_24),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_19),
.B(n_20),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_21),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_33),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

INVx4_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_20),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_31),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_SL g45 ( 
.A1(n_39),
.A2(n_37),
.B(n_20),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_27),
.B1(n_39),
.B2(n_22),
.C(n_23),
.Y(n_46)
);

O2A1O1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_23),
.B(n_30),
.C(n_29),
.Y(n_47)
);

AOI221x1_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_44),
.B1(n_45),
.B2(n_21),
.C(n_27),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_21),
.Y(n_49)
);

AOI221xp5_ASAP7_75t_L g50 ( 
.A1(n_44),
.A2(n_27),
.B1(n_26),
.B2(n_18),
.C(n_0),
.Y(n_50)
);

NAND4xp25_ASAP7_75t_L g51 ( 
.A(n_50),
.B(n_13),
.C(n_3),
.D(n_2),
.Y(n_51)
);

NAND3xp33_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_46),
.C(n_47),
.Y(n_52)
);

NAND4xp75_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_15),
.C(n_14),
.D(n_13),
.Y(n_53)
);

NAND4xp25_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_17),
.C(n_16),
.D(n_18),
.Y(n_54)
);

OAI21xp33_ASAP7_75t_SL g55 ( 
.A1(n_50),
.A2(n_16),
.B(n_18),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

NAND2x1p5_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_18),
.Y(n_58)
);

NOR2xp67_ASAP7_75t_L g59 ( 
.A(n_54),
.B(n_1),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_SL g60 ( 
.A1(n_56),
.A2(n_51),
.B1(n_26),
.B2(n_18),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_57),
.Y(n_61)
);

OAI21xp5_ASAP7_75t_L g62 ( 
.A1(n_57),
.A2(n_26),
.B(n_7),
.Y(n_62)
);

OAI21xp5_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_59),
.B(n_58),
.Y(n_63)
);

AOI221x1_ASAP7_75t_L g64 ( 
.A1(n_63),
.A2(n_61),
.B1(n_60),
.B2(n_26),
.C(n_58),
.Y(n_64)
);


endmodule