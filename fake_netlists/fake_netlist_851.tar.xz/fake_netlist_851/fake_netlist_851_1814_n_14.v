module fake_netlist_851_1814_n_14 (n_2, n_0, n_3, n_1, n_14);

input n_2;
input n_0;
input n_3;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

INVx3_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

NAND3xp33_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_1),
.C(n_0),
.Y(n_6)
);

INVx8_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_5),
.B1(n_4),
.B2(n_0),
.C(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_8),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_9),
.B1(n_4),
.B2(n_1),
.C(n_2),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND4xp25_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_3),
.C(n_11),
.D(n_12),
.Y(n_14)
);


endmodule