module fake_netlist_851_2268_n_32 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

NAND2xp33_ASAP7_75t_R g16 ( 
.A(n_11),
.B(n_7),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_7),
.B(n_6),
.C(n_0),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

OAI22x1_ASAP7_75t_L g24 ( 
.A1(n_18),
.A2(n_8),
.B1(n_4),
.B2(n_3),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_15),
.Y(n_25)
);

AO31x2_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_16),
.A3(n_20),
.B(n_17),
.Y(n_26)
);

INVx2_ASAP7_75t_SL g27 ( 
.A(n_26),
.Y(n_27)
);

INVxp67_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

AOI211x1_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_22),
.B(n_25),
.C(n_16),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_32)
);


endmodule