module fake_netlist_851_1138_n_28 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_28);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_7),
.B(n_3),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

BUFx6f_ASAP7_75t_SL g14 ( 
.A(n_12),
.Y(n_14)
);

NOR2x1_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_9),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_12),
.B(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_18),
.Y(n_21)
);

O2A1O1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_16),
.B(n_6),
.C(n_4),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_21),
.B(n_16),
.Y(n_23)
);

NOR2x1_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_0),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_23),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_25),
.Y(n_27)
);

OAI321xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_1),
.A3(n_4),
.B1(n_5),
.B2(n_6),
.C(n_27),
.Y(n_28)
);


endmodule