module fake_netlist_687_4113_n_20 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_20);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_20;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_12;
wire n_8;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_4),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

OAI21xp33_ASAP7_75t_SL g11 ( 
.A1(n_3),
.A2(n_0),
.B(n_7),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_5),
.B(n_3),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

AOI211xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B(n_10),
.C(n_9),
.Y(n_17)
);

AND3x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.C(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_12),
.B(n_1),
.Y(n_20)
);


endmodule