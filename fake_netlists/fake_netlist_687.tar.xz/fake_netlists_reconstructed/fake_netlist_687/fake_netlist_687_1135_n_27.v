module fake_netlist_687_1135_n_27 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_27);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_7;
wire n_23;
wire n_12;
wire n_8;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

BUFx10_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

BUFx3_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

BUFx8_ASAP7_75t_SL g12 ( 
.A(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_11),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_10),
.B(n_2),
.Y(n_16)
);

BUFx3_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_9),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

AOI221x1_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_18),
.B1(n_13),
.B2(n_14),
.C(n_19),
.Y(n_22)
);

NOR4xp25_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_18),
.C(n_16),
.D(n_14),
.Y(n_23)
);

AOI321xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_12),
.A3(n_10),
.B1(n_5),
.B2(n_4),
.C(n_3),
.Y(n_24)
);

INVxp33_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

OAI22xp33_ASAP7_75t_SL g26 ( 
.A1(n_24),
.A2(n_12),
.B1(n_22),
.B2(n_3),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_25),
.B(n_23),
.Y(n_27)
);


endmodule