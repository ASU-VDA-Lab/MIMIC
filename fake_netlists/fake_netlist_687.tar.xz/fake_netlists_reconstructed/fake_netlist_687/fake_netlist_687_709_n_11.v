module fake_netlist_687_709_n_11 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_11);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_11;

wire n_9;
wire n_7;
wire n_8;
wire n_10;

AND2x4_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_1),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_1),
.A2(n_3),
.B(n_5),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_6),
.B(n_2),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_7),
.B1(n_8),
.B2(n_9),
.Y(n_11)
);


endmodule