module fake_netlist_687_594_n_11 (n_4, n_2, n_3, n_1, n_0, n_11);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_11;

wire n_9;
wire n_7;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

AND2x2_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_1),
.Y(n_5)
);

BUFx3_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

O2A1O1Ixp33_ASAP7_75t_L g7 ( 
.A1(n_3),
.A2(n_4),
.B(n_0),
.C(n_1),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_9),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_7),
.B1(n_8),
.B2(n_6),
.Y(n_11)
);


endmodule