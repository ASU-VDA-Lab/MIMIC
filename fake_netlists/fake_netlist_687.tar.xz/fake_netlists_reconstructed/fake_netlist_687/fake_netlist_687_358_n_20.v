module fake_netlist_687_358_n_20 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_20);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_20;

wire n_17;
wire n_18;
wire n_15;
wire n_16;
wire n_12;
wire n_11;
wire n_19;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_3),
.A2(n_8),
.B1(n_6),
.B2(n_1),
.Y(n_12)
);

INVxp67_ASAP7_75t_SL g13 ( 
.A(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_7),
.Y(n_14)
);

OAI221xp5_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_4),
.B1(n_1),
.B2(n_5),
.C(n_6),
.Y(n_15)
);

AND2x4_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_12),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

NAND4xp25_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_11),
.C(n_14),
.D(n_4),
.Y(n_18)
);

AO22x2_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.B1(n_13),
.B2(n_5),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_2),
.B1(n_9),
.B2(n_10),
.C(n_17),
.Y(n_20)
);


endmodule