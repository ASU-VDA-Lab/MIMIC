module fake_netlist_687_3447_n_25 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_25);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_25;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_13;
wire n_11;
wire n_19;
wire n_14;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_6),
.B1(n_7),
.B2(n_1),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_7),
.B(n_0),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

OAI21xp33_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_16),
.B(n_13),
.C(n_12),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);

OAI31xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_15),
.A3(n_18),
.B(n_17),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_14),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_14),
.B2(n_2),
.C(n_3),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_14),
.Y(n_24)
);

AOI322xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_2),
.A3(n_3),
.B1(n_4),
.B2(n_5),
.C1(n_9),
.C2(n_16),
.Y(n_25)
);


endmodule