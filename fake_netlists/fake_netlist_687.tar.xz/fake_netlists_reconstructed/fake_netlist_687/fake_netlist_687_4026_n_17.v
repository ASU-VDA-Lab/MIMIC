module fake_netlist_687_4026_n_17 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_17);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_17;

wire n_9;
wire n_7;
wire n_14;
wire n_15;
wire n_11;
wire n_13;
wire n_16;
wire n_8;
wire n_10;
wire n_12;

NOR2xp33_ASAP7_75t_SL g7 ( 
.A(n_6),
.B(n_2),
.Y(n_7)
);

OAI22xp33_ASAP7_75t_L g8 ( 
.A1(n_0),
.A2(n_5),
.B1(n_4),
.B2(n_6),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

CKINVDCx16_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_9),
.B1(n_8),
.B2(n_1),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

NOR4xp25_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.C(n_4),
.D(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI21x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B(n_3),
.Y(n_16)
);

AO21x2_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B(n_15),
.Y(n_17)
);


endmodule