module fake_netlist_687_1238_n_26 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_26);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_26;

wire n_24;
wire n_21;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_7;
wire n_23;
wire n_13;
wire n_8;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

OAI22xp33_ASAP7_75t_L g7 ( 
.A1(n_3),
.A2(n_2),
.B1(n_0),
.B2(n_6),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_5),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_2),
.A2(n_0),
.B1(n_5),
.B2(n_6),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_1),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_1),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_1),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_6),
.B(n_4),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_9),
.A2(n_4),
.B(n_7),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_SL g16 ( 
.A1(n_14),
.A2(n_13),
.B(n_12),
.Y(n_16)
);

BUFx3_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AO21x1_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_16),
.B(n_17),
.Y(n_21)
);

NOR2x1_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_20),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.B(n_17),
.C(n_20),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_20),
.B(n_19),
.Y(n_25)
);

OAI22xp33_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_11),
.B1(n_22),
.B2(n_24),
.Y(n_26)
);


endmodule