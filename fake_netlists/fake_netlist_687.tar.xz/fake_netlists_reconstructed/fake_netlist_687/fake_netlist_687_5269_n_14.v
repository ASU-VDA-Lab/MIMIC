module fake_netlist_687_5269_n_14 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_14);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_14;

wire n_9;
wire n_7;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_12;

NAND2xp33_ASAP7_75t_SL g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_4),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_0),
.A2(n_1),
.B(n_5),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_3),
.Y(n_12)
);

NOR4xp25_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.C(n_10),
.D(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);


endmodule