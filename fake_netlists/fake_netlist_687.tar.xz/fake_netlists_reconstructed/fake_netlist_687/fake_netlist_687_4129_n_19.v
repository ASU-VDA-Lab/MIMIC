module fake_netlist_687_4129_n_19 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_19);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_19;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_7;
wire n_8;
wire n_11;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_1),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

NOR2xp67_ASAP7_75t_SL g11 ( 
.A(n_8),
.B(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_11),
.B(n_4),
.C(n_2),
.Y(n_15)
);

NAND4xp75_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_9),
.C(n_5),
.D(n_4),
.Y(n_16)
);

AO22x2_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_6),
.B1(n_5),
.B2(n_8),
.Y(n_17)
);

AO22x2_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_3),
.B1(n_8),
.B2(n_12),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_8),
.B1(n_17),
.B2(n_12),
.Y(n_19)
);


endmodule