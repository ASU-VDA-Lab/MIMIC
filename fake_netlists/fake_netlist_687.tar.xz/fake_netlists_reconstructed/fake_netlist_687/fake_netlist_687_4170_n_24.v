module fake_netlist_687_4170_n_24 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_24);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_24;

wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_12;
wire n_11;
wire n_19;
wire n_14;
wire n_13;

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_10),
.B(n_4),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_2),
.B(n_0),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NAND4xp25_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_17),
.C(n_7),
.D(n_11),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_9),
.B1(n_5),
.B2(n_3),
.Y(n_24)
);


endmodule