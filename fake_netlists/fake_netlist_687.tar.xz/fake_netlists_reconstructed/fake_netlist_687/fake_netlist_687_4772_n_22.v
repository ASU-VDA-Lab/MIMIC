module fake_netlist_687_4772_n_22 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_22);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_22;

wire n_21;
wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

CKINVDCx20_ASAP7_75t_R g8 ( 
.A(n_7),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_0),
.B(n_1),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B1(n_11),
.B2(n_1),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B(n_12),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

XNOR2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_6),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_21),
.B(n_7),
.Y(n_22)
);


endmodule