module fake_netlist_687_987_n_8 (n_3, n_0, n_2, n_1, n_8);

input n_3;
input n_0;
input n_2;
input n_1;

output n_8;

wire n_4;
wire n_7;
wire n_5;
wire n_6;

OAI21x1_ASAP7_75t_SL g4 ( 
.A1(n_2),
.A2(n_3),
.B(n_0),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_0),
.B(n_1),
.Y(n_5)
);

AOI21xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_3),
.B(n_1),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

AO21x2_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_5),
.B(n_6),
.Y(n_8)
);


endmodule