module fake_netlist_687_3842_n_53 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_53);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_53;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_23;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_19;
wire n_39;

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_13),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_11),
.B(n_2),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_1),
.B(n_11),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_18),
.A2(n_2),
.B1(n_0),
.B2(n_3),
.C(n_4),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_21),
.B(n_0),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_19),
.A2(n_12),
.B(n_8),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

AOI21xp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_22),
.B(n_20),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_17),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_31),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_32),
.Y(n_36)
);

O2A1O1Ixp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_34),
.B(n_19),
.C(n_27),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_23),
.Y(n_39)
);

XNOR2x1_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_21),
.Y(n_40)
);

A2O1A1Ixp33_ASAP7_75t_SL g41 ( 
.A1(n_39),
.A2(n_24),
.B(n_25),
.C(n_23),
.Y(n_41)
);

OAI31xp33_ASAP7_75t_L g42 ( 
.A1(n_37),
.A2(n_18),
.A3(n_30),
.B(n_25),
.Y(n_42)
);

AND4x1_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_6),
.C(n_5),
.D(n_4),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_16),
.C(n_6),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_40),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

OAI22x1_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_41),
.B1(n_16),
.B2(n_14),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_44),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

OAI21xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_46),
.B(n_47),
.Y(n_52)
);

AOI22x1_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_48),
.B1(n_50),
.B2(n_51),
.Y(n_53)
);


endmodule