module fake_netlist_687_1649_n_21 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_21);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_21;

wire n_17;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_11;
wire n_19;
wire n_13;
wire n_14;
wire n_12;

AND3x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.C(n_3),
.Y(n_11)
);

NAND2xp33_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_7),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_2),
.B(n_5),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

AOI221x1_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_13),
.B1(n_11),
.B2(n_0),
.C(n_1),
.Y(n_18)
);

AND3x4_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_4),
.C(n_2),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.B1(n_6),
.B2(n_4),
.Y(n_20)
);

OA22x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B1(n_7),
.B2(n_6),
.Y(n_21)
);


endmodule