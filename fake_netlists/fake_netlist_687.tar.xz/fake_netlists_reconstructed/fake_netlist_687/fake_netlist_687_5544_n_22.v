module fake_netlist_687_5544_n_22 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_22);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_22;

wire n_21;
wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

OAI21xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_5),
.B(n_4),
.Y(n_14)
);

AO31x2_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_10),
.A3(n_6),
.B(n_4),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_11),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

NAND4xp25_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_15),
.C(n_7),
.D(n_0),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_7),
.B1(n_8),
.B2(n_2),
.Y(n_22)
);


endmodule