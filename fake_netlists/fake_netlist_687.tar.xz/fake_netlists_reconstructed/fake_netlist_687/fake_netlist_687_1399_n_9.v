module fake_netlist_687_1399_n_9 (n_0, n_1, n_9);

input n_0;
input n_1;

output n_9;

wire n_4;
wire n_2;
wire n_7;
wire n_3;
wire n_8;
wire n_5;
wire n_6;

INVx1_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

BUFx6f_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

O2A1O1Ixp33_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B(n_3),
.C(n_0),
.Y(n_6)
);

AOI221xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_2),
.B1(n_3),
.B2(n_0),
.C(n_1),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_3),
.B(n_0),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B1(n_3),
.B2(n_5),
.Y(n_9)
);


endmodule