module fake_netlist_687_5084_n_22 (n_4, n_2, n_3, n_1, n_5, n_0, n_22);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_22;

wire n_21;
wire n_17;
wire n_6;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_7;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVxp67_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_5),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_0),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

OAI22x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_11)
);

NAND2x1p5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_1),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_6),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_13),
.B1(n_12),
.B2(n_7),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_9),
.B(n_8),
.C(n_12),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_9),
.B1(n_12),
.B2(n_2),
.C(n_3),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_R g22 ( 
.A1(n_21),
.A2(n_4),
.B1(n_5),
.B2(n_20),
.Y(n_22)
);


endmodule