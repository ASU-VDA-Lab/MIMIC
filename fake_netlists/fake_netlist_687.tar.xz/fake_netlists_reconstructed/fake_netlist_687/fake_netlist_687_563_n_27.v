module fake_netlist_687_563_n_27 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

BUFx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_0),
.B(n_11),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_4),
.B(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_13),
.B(n_7),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_7),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_18),
.B1(n_15),
.B2(n_14),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_21),
.Y(n_22)
);

XNOR2x1_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_16),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NOR3xp33_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_2),
.C(n_1),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_12),
.B1(n_5),
.B2(n_3),
.Y(n_27)
);


endmodule