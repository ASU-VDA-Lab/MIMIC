module fake_netlist_635_2603_n_16 (n_0, n_1, n_4, n_3, n_2, n_16);

input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_16;

wire n_5;
wire n_7;
wire n_9;
wire n_15;
wire n_14;
wire n_8;
wire n_12;
wire n_10;
wire n_6;
wire n_13;
wire n_11;

INVx3_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B(n_3),
.Y(n_8)
);

NAND2x1p5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_6),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_11)
);

AND2x2_ASAP7_75t_SL g12 ( 
.A(n_10),
.B(n_7),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_8),
.B(n_2),
.C(n_0),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_4),
.B(n_0),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B(n_2),
.Y(n_16)
);


endmodule