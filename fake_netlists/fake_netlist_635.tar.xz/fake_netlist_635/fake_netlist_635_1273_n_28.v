module fake_netlist_635_1273_n_28 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_11, n_28);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_11;

output n_28;

wire n_18;
wire n_13;
wire n_25;
wire n_20;
wire n_22;
wire n_15;
wire n_23;
wire n_14;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_24;

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_4),
.B(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_7),
.Y(n_15)
);

AND3x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_11),
.C(n_5),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_3),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_2),
.B(n_3),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_19),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_20),
.B1(n_14),
.B2(n_18),
.C(n_19),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_17),
.B1(n_13),
.B2(n_0),
.C(n_1),
.Y(n_24)
);

XNOR2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

OAI321xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_17),
.C(n_27),
.Y(n_28)
);


endmodule