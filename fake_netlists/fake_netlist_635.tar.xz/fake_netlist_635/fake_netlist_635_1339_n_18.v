module fake_netlist_635_1339_n_18 (n_0, n_1, n_4, n_3, n_2, n_18);

input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_18;

wire n_5;
wire n_7;
wire n_9;
wire n_15;
wire n_8;
wire n_12;
wire n_14;
wire n_17;
wire n_10;
wire n_16;
wire n_6;
wire n_13;
wire n_11;

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_1),
.B(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_2),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_4),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_0),
.B(n_4),
.Y(n_9)
);

AOI21x1_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_5),
.B(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_0),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_9),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_3),
.B(n_4),
.Y(n_13)
);

XNOR2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

AOI211xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_1),
.B(n_2),
.C(n_3),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_2),
.B1(n_15),
.B2(n_8),
.C1(n_16),
.C2(n_0),
.Y(n_18)
);


endmodule