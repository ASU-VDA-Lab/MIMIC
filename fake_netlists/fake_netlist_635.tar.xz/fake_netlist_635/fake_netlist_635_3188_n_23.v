module fake_netlist_635_3188_n_23 (n_0, n_1, n_4, n_3, n_2, n_23);

input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_23;

wire n_18;
wire n_13;
wire n_7;
wire n_10;
wire n_20;
wire n_22;
wire n_11;
wire n_9;
wire n_15;
wire n_8;
wire n_12;
wire n_14;
wire n_6;
wire n_5;
wire n_21;
wire n_17;
wire n_16;
wire n_19;

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_SL g6 ( 
.A(n_3),
.Y(n_6)
);

XOR2xp5_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_4),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

A2O1A1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_1),
.B(n_2),
.C(n_0),
.Y(n_9)
);

OAI21xp33_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_3),
.B(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_8),
.Y(n_15)
);

AOI211xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B(n_11),
.C(n_9),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_6),
.B1(n_7),
.B2(n_15),
.Y(n_17)
);

NAND2x1_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_15),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_14),
.Y(n_20)
);

INVxp33_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AO21x2_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B(n_21),
.Y(n_23)
);


endmodule