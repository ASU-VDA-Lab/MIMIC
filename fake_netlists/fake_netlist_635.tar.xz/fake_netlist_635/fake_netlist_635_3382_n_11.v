module fake_netlist_635_3382_n_11 (n_2, n_0, n_1, n_11);

input n_2;
input n_0;
input n_1;

output n_11;

wire n_5;
wire n_7;
wire n_9;
wire n_4;
wire n_3;
wire n_8;
wire n_10;
wire n_6;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B(n_1),
.Y(n_5)
);

AO21x2_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_3),
.B(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_8),
.Y(n_9)
);

OAI22x1_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_10)
);

OA21x2_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_2),
.B(n_8),
.Y(n_11)
);


endmodule