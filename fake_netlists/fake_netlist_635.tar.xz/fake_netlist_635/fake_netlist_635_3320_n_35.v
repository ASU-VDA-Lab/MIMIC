module fake_netlist_635_3320_n_35 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_17, n_16, n_35);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_17;
input n_16;

output n_35;

wire n_34;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_20;
wire n_22;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_3),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_8),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_9),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_7),
.B(n_5),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_14),
.Y(n_26)
);

OA22x2_ASAP7_75t_L g27 ( 
.A1(n_22),
.A2(n_23),
.B1(n_24),
.B2(n_20),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_19),
.Y(n_28)
);

NOR2x1_ASAP7_75t_SL g29 ( 
.A(n_26),
.B(n_25),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_21),
.Y(n_30)
);

AOI322xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.A3(n_13),
.B1(n_11),
.B2(n_15),
.C1(n_16),
.C2(n_17),
.Y(n_31)
);

NAND2xp33_ASAP7_75t_R g32 ( 
.A(n_31),
.B(n_10),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_6),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_1),
.B1(n_4),
.B2(n_0),
.Y(n_35)
);


endmodule