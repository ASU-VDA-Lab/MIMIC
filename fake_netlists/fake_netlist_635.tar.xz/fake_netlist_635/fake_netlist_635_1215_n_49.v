module fake_netlist_635_1215_n_49 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_49);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_49;

wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_38;
wire n_45;
wire n_36;
wire n_47;
wire n_23;
wire n_42;
wire n_29;
wire n_48;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_20),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_14),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_10),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_8),
.B(n_4),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_12),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_5),
.Y(n_31)
);

CKINVDCx16_ASAP7_75t_R g32 ( 
.A(n_3),
.Y(n_32)
);

O2A1O1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_26),
.A2(n_19),
.B(n_16),
.C(n_18),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_21),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_15),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_25),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

BUFx8_ASAP7_75t_SL g38 ( 
.A(n_34),
.Y(n_38)
);

OR2x2_ASAP7_75t_SL g39 ( 
.A(n_38),
.B(n_32),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_31),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_35),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_28),
.Y(n_43)
);

AOI22x1_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_24),
.B1(n_23),
.B2(n_33),
.Y(n_44)
);

OAI211xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_29),
.B(n_13),
.C(n_11),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_6),
.B1(n_9),
.B2(n_7),
.Y(n_46)
);

INVx2_ASAP7_75t_SL g47 ( 
.A(n_46),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_45),
.B1(n_0),
.B2(n_22),
.Y(n_49)
);


endmodule