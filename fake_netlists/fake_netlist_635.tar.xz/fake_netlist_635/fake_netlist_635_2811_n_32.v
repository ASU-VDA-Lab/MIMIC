module fake_netlist_635_2811_n_32 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_10, n_6, n_13, n_11, n_32);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_10;
input n_6;
input n_13;
input n_11;

output n_32;

wire n_18;
wire n_25;
wire n_30;
wire n_31;
wire n_22;
wire n_20;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

BUFx2_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

BUFx3_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

O2A1O1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_20),
.B(n_16),
.C(n_17),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_15),
.C(n_7),
.D(n_21),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_SL g25 ( 
.A(n_23),
.B(n_21),
.C(n_19),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NAND4xp25_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_25),
.C(n_7),
.D(n_13),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_8),
.B1(n_6),
.B2(n_1),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

OAI22x1_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_12),
.B1(n_11),
.B2(n_3),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_29),
.B1(n_2),
.B2(n_0),
.Y(n_32)
);


endmodule