module fake_netlist_635_668_n_15 (n_0, n_1, n_4, n_3, n_2, n_15);

input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_15;

wire n_5;
wire n_7;
wire n_9;
wire n_8;
wire n_12;
wire n_14;
wire n_10;
wire n_6;
wire n_13;
wire n_11;

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_4),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_0),
.Y(n_6)
);

OA21x2_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_2),
.B(n_4),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_4),
.B(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_5),
.Y(n_11)
);

OAI221xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_7),
.B1(n_5),
.B2(n_10),
.C(n_3),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_7),
.B(n_2),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_7),
.B(n_3),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_0),
.B1(n_1),
.B2(n_5),
.C1(n_13),
.C2(n_4),
.Y(n_15)
);


endmodule