module fake_netlist_635_1471_n_19 (n_5, n_0, n_1, n_4, n_3, n_2, n_19);

input n_5;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_19;

wire n_18;
wire n_13;
wire n_7;
wire n_10;
wire n_11;
wire n_9;
wire n_15;
wire n_8;
wire n_12;
wire n_14;
wire n_6;
wire n_17;
wire n_16;

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_3),
.B(n_2),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_4),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_SL g12 ( 
.A1(n_9),
.A2(n_7),
.B(n_4),
.Y(n_12)
);

AOI211xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_10),
.B(n_9),
.C(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

NOR4xp25_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.C(n_9),
.D(n_0),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_9),
.B(n_2),
.C(n_0),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI22x1_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_9),
.B1(n_14),
.B2(n_10),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_9),
.B1(n_17),
.B2(n_14),
.Y(n_19)
);


endmodule