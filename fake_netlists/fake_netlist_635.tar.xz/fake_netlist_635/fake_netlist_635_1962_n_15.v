module fake_netlist_635_1962_n_15 (n_2, n_3, n_0, n_1, n_15);

input n_2;
input n_3;
input n_0;
input n_1;

output n_15;

wire n_5;
wire n_7;
wire n_9;
wire n_4;
wire n_8;
wire n_12;
wire n_14;
wire n_10;
wire n_6;
wire n_13;
wire n_11;

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx4_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

AOI21xp5_ASAP7_75t_SL g7 ( 
.A1(n_5),
.A2(n_0),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_5),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_11),
.B(n_4),
.C(n_7),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_4),
.B1(n_2),
.B2(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AOI21xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B(n_1),
.Y(n_15)
);


endmodule