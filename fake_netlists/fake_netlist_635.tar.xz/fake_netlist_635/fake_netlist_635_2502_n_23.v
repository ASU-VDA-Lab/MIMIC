module fake_netlist_635_2502_n_23 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_6, n_23);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_6;

output n_23;

wire n_18;
wire n_13;
wire n_10;
wire n_20;
wire n_22;
wire n_11;
wire n_15;
wire n_12;
wire n_14;
wire n_21;
wire n_17;
wire n_16;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_9),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_10),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_11),
.B(n_14),
.C(n_12),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OR3x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_6),
.C(n_3),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_0),
.B1(n_2),
.B2(n_1),
.Y(n_23)
);


endmodule