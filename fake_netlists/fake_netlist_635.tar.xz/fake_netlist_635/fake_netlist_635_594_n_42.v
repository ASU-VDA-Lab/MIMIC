module fake_netlist_635_594_n_42 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_16, n_10, n_17, n_6, n_13, n_11, n_42);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_16;
input n_10;
input n_17;
input n_6;
input n_13;
input n_11;

output n_42;

wire n_18;
wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_41;
wire n_20;
wire n_22;
wire n_38;
wire n_36;
wire n_23;
wire n_29;
wire n_21;
wire n_37;
wire n_27;
wire n_35;
wire n_26;
wire n_19;
wire n_28;
wire n_40;
wire n_24;

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_6),
.B(n_15),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

OR2x6_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_17),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_25),
.B1(n_19),
.B2(n_22),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_27),
.A2(n_20),
.B1(n_24),
.B2(n_18),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_26),
.B1(n_28),
.B2(n_23),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_SL g33 ( 
.A(n_32),
.B(n_28),
.C(n_13),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_10),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_31),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_34),
.B1(n_9),
.B2(n_16),
.C(n_13),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_11),
.B1(n_7),
.B2(n_2),
.Y(n_37)
);

OAI322xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_9),
.A3(n_16),
.B1(n_12),
.B2(n_1),
.C1(n_5),
.C2(n_4),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

OAI22xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_40),
.B1(n_39),
.B2(n_35),
.Y(n_42)
);


endmodule