module fake_netlist_635_785_n_34 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_11, n_34);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_11;

output n_34;

wire n_18;
wire n_13;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_22;
wire n_20;
wire n_15;
wire n_23;
wire n_14;
wire n_29;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_0),
.B(n_5),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_7),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

BUFx8_ASAP7_75t_SL g19 ( 
.A(n_13),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_7),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_14),
.B(n_11),
.Y(n_21)
);

O2A1O1Ixp33_ASAP7_75t_SL g22 ( 
.A1(n_20),
.A2(n_17),
.B(n_16),
.C(n_15),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_15),
.Y(n_23)
);

OAI31xp33_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_15),
.A3(n_16),
.B(n_17),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_20),
.B1(n_13),
.B2(n_18),
.C(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_2),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_13),
.B1(n_18),
.B2(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

NOR2x1_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_18),
.Y(n_30)
);

CKINVDCx16_ASAP7_75t_R g31 ( 
.A(n_28),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_3),
.A3(n_4),
.B1(n_8),
.B2(n_9),
.C1(n_10),
.C2(n_33),
.Y(n_34)
);


endmodule