module fake_netlist_635_2765_n_33 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_14, n_10, n_6, n_13, n_11, n_33);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_10;
input n_6;
input n_13;
input n_11;

output n_33;

wire n_18;
wire n_25;
wire n_30;
wire n_32;
wire n_31;
wire n_22;
wire n_20;
wire n_15;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_26;
wire n_16;
wire n_17;
wire n_28;
wire n_19;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_12),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

O2A1O1Ixp5_ASAP7_75t_L g23 ( 
.A1(n_16),
.A2(n_6),
.B(n_9),
.C(n_10),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_16),
.A2(n_11),
.B(n_7),
.Y(n_24)
);

BUFx10_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_15),
.Y(n_26)
);

CKINVDCx12_ASAP7_75t_R g27 ( 
.A(n_23),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.B(n_24),
.Y(n_29)
);

AOI321xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_22),
.A3(n_19),
.B1(n_18),
.B2(n_20),
.C(n_17),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_5),
.B1(n_13),
.B2(n_14),
.Y(n_33)
);


endmodule