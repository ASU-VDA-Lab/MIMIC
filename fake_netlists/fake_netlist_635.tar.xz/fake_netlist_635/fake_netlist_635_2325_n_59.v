module fake_netlist_635_2325_n_59 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_14, n_10, n_6, n_13, n_11, n_59);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_10;
input n_6;
input n_13;
input n_11;

output n_59;

wire n_18;
wire n_53;
wire n_34;
wire n_49;
wire n_39;
wire n_51;
wire n_54;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_22;
wire n_38;
wire n_20;
wire n_45;
wire n_57;
wire n_36;
wire n_55;
wire n_58;
wire n_47;
wire n_15;
wire n_23;
wire n_42;
wire n_52;
wire n_29;
wire n_48;
wire n_56;
wire n_21;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_17;
wire n_26;
wire n_16;
wire n_19;
wire n_28;
wire n_40;
wire n_46;
wire n_24;
wire n_50;

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_3),
.B(n_5),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_9),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

XNOR2xp5_ASAP7_75t_L g23 ( 
.A(n_7),
.B(n_2),
.Y(n_23)
);

INVxp67_ASAP7_75t_SL g24 ( 
.A(n_11),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_3),
.B(n_10),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_18),
.A2(n_10),
.B1(n_9),
.B2(n_1),
.Y(n_26)
);

O2A1O1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_22),
.A2(n_12),
.B(n_8),
.C(n_6),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_21),
.A2(n_1),
.B1(n_6),
.B2(n_0),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_22),
.B(n_13),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_15),
.A2(n_24),
.B(n_25),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_22),
.A2(n_24),
.B1(n_25),
.B2(n_19),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_15),
.B(n_13),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_19),
.B(n_17),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_29),
.B(n_17),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_29),
.B(n_23),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_33),
.Y(n_38)
);

INVx1_ASAP7_75t_SL g39 ( 
.A(n_30),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_28),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_36),
.B(n_37),
.Y(n_42)
);

AOI31xp33_ASAP7_75t_L g43 ( 
.A1(n_38),
.A2(n_23),
.A3(n_26),
.B(n_16),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

INVx3_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

INVxp67_ASAP7_75t_SL g48 ( 
.A(n_45),
.Y(n_48)
);

AOI32xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_39),
.A3(n_41),
.B1(n_46),
.B2(n_43),
.Y(n_49)
);

AOI21xp5_ASAP7_75t_L g50 ( 
.A1(n_44),
.A2(n_38),
.B(n_39),
.Y(n_50)
);

NAND4xp75_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_46),
.C(n_43),
.D(n_45),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_47),
.Y(n_52)
);

AOI21xp33_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_47),
.B(n_34),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_51),
.Y(n_54)
);

BUFx6f_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

NAND3xp33_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_34),
.C(n_47),
.Y(n_57)
);

OAI22xp5_ASAP7_75t_L g58 ( 
.A1(n_54),
.A2(n_27),
.B1(n_20),
.B2(n_12),
.Y(n_58)
);

AOI222xp33_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_57),
.B1(n_56),
.B2(n_55),
.C1(n_20),
.C2(n_0),
.Y(n_59)
);


endmodule