module fake_netlist_721_3755_n_56 (n_3, n_14, n_20, n_0, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_56);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_56;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_27;
wire n_36;
wire n_37;
wire n_41;
wire n_29;
wire n_55;
wire n_43;
wire n_31;
wire n_45;
wire n_39;
wire n_28;
wire n_52;
wire n_25;
wire n_46;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_40;
wire n_34;
wire n_51;

INVx3_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_7),
.B(n_2),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_6),
.B(n_20),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_16),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_3),
.Y(n_34)
);

OAI22xp33_ASAP7_75t_L g35 ( 
.A1(n_30),
.A2(n_20),
.B1(n_17),
.B2(n_16),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_25),
.B(n_17),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_25),
.B(n_21),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AO31x2_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_33),
.A3(n_27),
.B(n_26),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_41),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_41),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_35),
.B1(n_32),
.B2(n_34),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_32),
.B(n_31),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_SL g49 ( 
.A1(n_46),
.A2(n_29),
.B(n_25),
.Y(n_49)
);

INVxp67_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

AOI211x1_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_24),
.B(n_23),
.C(n_21),
.Y(n_51)
);

NOR3xp33_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_29),
.C(n_26),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_29),
.B1(n_28),
.B2(n_41),
.Y(n_53)
);

OR4x1_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_24),
.C(n_4),
.D(n_0),
.Y(n_54)
);

AOI222xp33_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_28),
.B1(n_52),
.B2(n_9),
.C1(n_8),
.C2(n_5),
.Y(n_55)
);

AOI322xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_54),
.A3(n_13),
.B1(n_12),
.B2(n_10),
.C1(n_18),
.C2(n_15),
.Y(n_56)
);


endmodule