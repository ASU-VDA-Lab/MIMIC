module fake_netlist_721_1714_n_21 (n_1, n_2, n_0, n_3, n_4, n_5, n_21);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;
input n_5;

output n_21;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_7;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_8;
wire n_10;
wire n_15;
wire n_16;
wire n_6;
wire n_19;

INVx3_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

AND2x6_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_3),
.Y(n_9)
);

INVxp33_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

AO31x2_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_4),
.A3(n_1),
.B(n_0),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_4),
.B1(n_0),
.B2(n_2),
.Y(n_12)
);

AO31x2_ASAP7_75t_L g13 ( 
.A1(n_6),
.A2(n_7),
.A3(n_9),
.B(n_10),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_6),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_9),
.B1(n_12),
.B2(n_6),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_7),
.B2(n_13),
.C(n_11),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_7),
.Y(n_19)
);

XNOR2x1_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_9),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_9),
.B1(n_17),
.B2(n_16),
.Y(n_21)
);


endmodule