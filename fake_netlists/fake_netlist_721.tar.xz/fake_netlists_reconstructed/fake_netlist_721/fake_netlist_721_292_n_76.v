module fake_netlist_721_292_n_76 (n_3, n_14, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_19, n_5, n_76);

input n_3;
input n_14;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_19;
input n_5;

output n_76;

wire n_60;
wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_61;
wire n_72;
wire n_75;
wire n_30;
wire n_63;
wire n_35;
wire n_54;
wire n_68;
wire n_20;
wire n_73;
wire n_27;
wire n_37;
wire n_36;
wire n_29;
wire n_41;
wire n_24;
wire n_66;
wire n_57;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_55;
wire n_52;
wire n_71;
wire n_65;
wire n_25;
wire n_46;
wire n_70;
wire n_23;
wire n_56;
wire n_21;
wire n_47;
wire n_67;
wire n_26;
wire n_44;
wire n_74;
wire n_42;
wire n_53;
wire n_64;
wire n_62;
wire n_69;
wire n_50;
wire n_38;
wire n_49;
wire n_40;
wire n_34;
wire n_51;
wire n_59;
wire n_22;

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_15),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_10),
.B(n_4),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_8),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_12),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_11),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_7),
.B(n_16),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_16),
.Y(n_30)
);

INVx5_ASAP7_75t_L g31 ( 
.A(n_0),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_5),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_23),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_20),
.B(n_17),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_25),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_23),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_22),
.Y(n_38)
);

CKINVDCx20_ASAP7_75t_R g39 ( 
.A(n_30),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_31),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_31),
.Y(n_41)
);

BUFx6f_ASAP7_75t_L g42 ( 
.A(n_22),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

INVx3_ASAP7_75t_L g44 ( 
.A(n_37),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_36),
.B(n_29),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_38),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_L g47 ( 
.A1(n_33),
.A2(n_30),
.B1(n_29),
.B2(n_31),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_35),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_33),
.A2(n_27),
.B1(n_22),
.B2(n_32),
.Y(n_49)
);

AOI33xp33_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_41),
.A3(n_24),
.B1(n_28),
.B2(n_34),
.B3(n_39),
.Y(n_50)
);

AOI33xp33_ASAP7_75t_L g51 ( 
.A1(n_45),
.A2(n_24),
.A3(n_28),
.B1(n_27),
.B2(n_22),
.B3(n_17),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_27),
.B1(n_21),
.B2(n_38),
.Y(n_52)
);

NAND4xp25_ASAP7_75t_L g53 ( 
.A(n_47),
.B(n_18),
.C(n_27),
.D(n_26),
.Y(n_53)
);

OAI33xp33_ASAP7_75t_L g54 ( 
.A1(n_43),
.A2(n_18),
.A3(n_42),
.B1(n_38),
.B2(n_6),
.B3(n_3),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_48),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_50),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_57),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

NOR2xp33_ASAP7_75t_L g61 ( 
.A(n_56),
.B(n_45),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_55),
.B(n_44),
.Y(n_62)
);

NOR2xp33_ASAP7_75t_R g63 ( 
.A(n_59),
.B(n_55),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_61),
.B(n_44),
.Y(n_64)
);

OAI221xp5_ASAP7_75t_L g65 ( 
.A1(n_61),
.A2(n_52),
.B1(n_44),
.B2(n_38),
.C(n_42),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_60),
.B(n_42),
.Y(n_66)
);

AOI221xp5_ASAP7_75t_L g67 ( 
.A1(n_62),
.A2(n_54),
.B1(n_42),
.B2(n_46),
.C(n_9),
.Y(n_67)
);

OAI211xp5_ASAP7_75t_SL g68 ( 
.A1(n_64),
.A2(n_14),
.B(n_46),
.C(n_66),
.Y(n_68)
);

BUFx3_ASAP7_75t_L g69 ( 
.A(n_65),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_67),
.Y(n_70)
);

NOR2xp67_ASAP7_75t_L g71 ( 
.A(n_63),
.B(n_53),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_66),
.Y(n_72)
);

CKINVDCx20_ASAP7_75t_R g73 ( 
.A(n_69),
.Y(n_73)
);

HB1xp67_ASAP7_75t_L g74 ( 
.A(n_71),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_72),
.Y(n_75)
);

OAI33xp33_ASAP7_75t_L g76 ( 
.A1(n_75),
.A2(n_68),
.A3(n_69),
.B1(n_70),
.B2(n_74),
.B3(n_73),
.Y(n_76)
);


endmodule