module fake_netlist_721_2304_n_57 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_17, n_5, n_57);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_17;
input n_5;

output n_57;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_20;
wire n_27;
wire n_24;
wire n_37;
wire n_29;
wire n_36;
wire n_41;
wire n_55;
wire n_43;
wire n_31;
wire n_18;
wire n_28;
wire n_39;
wire n_45;
wire n_52;
wire n_25;
wire n_22;
wire n_46;
wire n_23;
wire n_56;
wire n_21;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_26;
wire n_19;

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_7),
.B1(n_6),
.B2(n_8),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

AND2x2_ASAP7_75t_SL g23 ( 
.A(n_11),
.B(n_12),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_13),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_5),
.B(n_2),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_12),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_15),
.B1(n_10),
.B2(n_0),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_25),
.B(n_10),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_15),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_21),
.B(n_1),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_24),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_29),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_26),
.B(n_20),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_30),
.Y(n_39)
);

BUFx6f_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_30),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_36),
.B(n_33),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_35),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_32),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_R g45 ( 
.A(n_40),
.B(n_23),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_41),
.Y(n_46)
);

AOI21xp33_ASAP7_75t_SL g47 ( 
.A1(n_43),
.A2(n_31),
.B(n_18),
.Y(n_47)
);

OAI211xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_19),
.B(n_28),
.C(n_22),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

AO22x2_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_40),
.B1(n_26),
.B2(n_42),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_42),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_SL g53 ( 
.A1(n_51),
.A2(n_28),
.B1(n_29),
.B2(n_3),
.Y(n_53)
);

XNOR2xp5_ASAP7_75t_L g54 ( 
.A(n_53),
.B(n_50),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

HB1xp67_ASAP7_75t_L g56 ( 
.A(n_55),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_56),
.B(n_54),
.Y(n_57)
);


endmodule