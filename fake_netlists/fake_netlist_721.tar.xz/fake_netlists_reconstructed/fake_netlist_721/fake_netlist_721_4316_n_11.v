module fake_netlist_721_4316_n_11 (n_1, n_2, n_0, n_3, n_4, n_11);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_11;

wire n_8;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_5;

O2A1O1Ixp33_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_5)
);

NAND2x1_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_7),
.Y(n_9)
);

OAI211xp5_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_8),
.B(n_5),
.C(n_7),
.Y(n_10)
);

XNOR2x1_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);


endmodule