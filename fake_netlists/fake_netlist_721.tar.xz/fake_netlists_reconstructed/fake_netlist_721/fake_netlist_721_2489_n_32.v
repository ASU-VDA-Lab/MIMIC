module fake_netlist_721_2489_n_32 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_32);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_32;

wire n_30;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_11;
wire n_9;
wire n_25;
wire n_12;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

BUFx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

INVxp33_ASAP7_75t_SL g13 ( 
.A(n_0),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_7),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_8),
.B(n_3),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_9),
.B(n_0),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B1(n_11),
.B2(n_10),
.Y(n_19)
);

OR2x6_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_11),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

NOR2x1_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_17),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_SL g23 ( 
.A(n_19),
.B(n_13),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_20),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AOI221x1_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_15),
.B1(n_21),
.B2(n_12),
.C(n_14),
.Y(n_26)
);

OAI211xp5_ASAP7_75t_SL g27 ( 
.A1(n_24),
.A2(n_4),
.B(n_2),
.C(n_1),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_26),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

OAI22x1_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_7),
.B1(n_29),
.B2(n_30),
.Y(n_32)
);


endmodule