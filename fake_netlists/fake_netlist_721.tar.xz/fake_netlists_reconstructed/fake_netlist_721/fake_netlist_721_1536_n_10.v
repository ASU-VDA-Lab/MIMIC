module fake_netlist_721_1536_n_10 (n_1, n_2, n_0, n_3, n_4, n_10);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_10;

wire n_8;
wire n_7;
wire n_9;
wire n_6;
wire n_5;

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

AOI21xp5_ASAP7_75t_L g6 ( 
.A1(n_1),
.A2(n_2),
.B(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OAI221xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_3),
.B1(n_7),
.B2(n_5),
.C(n_6),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule