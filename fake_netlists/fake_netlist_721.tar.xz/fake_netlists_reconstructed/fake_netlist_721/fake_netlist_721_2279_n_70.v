module fake_netlist_721_2279_n_70 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_17, n_5, n_70);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_17;
input n_5;

output n_70;

wire n_60;
wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_61;
wire n_30;
wire n_63;
wire n_54;
wire n_35;
wire n_68;
wire n_20;
wire n_27;
wire n_36;
wire n_24;
wire n_37;
wire n_29;
wire n_41;
wire n_66;
wire n_55;
wire n_43;
wire n_18;
wire n_31;
wire n_39;
wire n_28;
wire n_45;
wire n_52;
wire n_57;
wire n_65;
wire n_25;
wire n_46;
wire n_23;
wire n_56;
wire n_21;
wire n_47;
wire n_67;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_64;
wire n_62;
wire n_69;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_59;
wire n_22;
wire n_19;

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_5),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_0),
.B(n_11),
.Y(n_22)
);

INVx4_ASAP7_75t_L g23 ( 
.A(n_9),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_2),
.Y(n_25)
);

CKINVDCx16_ASAP7_75t_R g26 ( 
.A(n_3),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_15),
.Y(n_27)
);

AND3x2_ASAP7_75t_L g28 ( 
.A(n_1),
.B(n_16),
.C(n_13),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_12),
.Y(n_30)
);

INVx4_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_22),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_18),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_30),
.B(n_7),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_22),
.B(n_1),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_23),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_22),
.A2(n_10),
.B1(n_3),
.B2(n_2),
.Y(n_38)
);

OR2x6_ASAP7_75t_L g39 ( 
.A(n_24),
.B(n_10),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_26),
.B(n_20),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_34),
.B(n_30),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_33),
.A2(n_29),
.B(n_23),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_37),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_36),
.A2(n_25),
.B1(n_21),
.B2(n_28),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_40),
.B(n_11),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_36),
.A2(n_21),
.B1(n_27),
.B2(n_14),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_36),
.B1(n_39),
.B2(n_37),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_41),
.Y(n_49)
);

OAI22xp33_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_39),
.B1(n_38),
.B2(n_27),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_41),
.A2(n_39),
.B1(n_33),
.B2(n_31),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_46),
.B(n_31),
.Y(n_52)
);

NAND2xp33_ASAP7_75t_SL g53 ( 
.A(n_48),
.B(n_47),
.Y(n_53)
);

NOR2xp33_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_45),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_31),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_51),
.Y(n_56)
);

CKINVDCx14_ASAP7_75t_R g57 ( 
.A(n_53),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

AOI221xp5_ASAP7_75t_L g60 ( 
.A1(n_54),
.A2(n_50),
.B1(n_32),
.B2(n_38),
.C(n_42),
.Y(n_60)
);

OAI22xp5_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_32),
.B1(n_44),
.B2(n_35),
.Y(n_61)
);

NOR2xp33_ASAP7_75t_R g62 ( 
.A(n_57),
.B(n_58),
.Y(n_62)
);

XNOR2x2_ASAP7_75t_SL g63 ( 
.A(n_60),
.B(n_17),
.Y(n_63)
);

NOR2x1_ASAP7_75t_L g64 ( 
.A(n_59),
.B(n_21),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_63),
.Y(n_65)
);

HB1xp67_ASAP7_75t_L g66 ( 
.A(n_62),
.Y(n_66)
);

BUFx2_ASAP7_75t_L g67 ( 
.A(n_64),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_61),
.Y(n_68)
);

INVx1_ASAP7_75t_SL g69 ( 
.A(n_66),
.Y(n_69)
);

AOI22xp5_ASAP7_75t_SL g70 ( 
.A1(n_69),
.A2(n_65),
.B1(n_67),
.B2(n_68),
.Y(n_70)
);


endmodule