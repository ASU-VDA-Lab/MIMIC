module fake_netlist_721_646_n_47 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_47);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_47;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_43;
wire n_18;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_25;
wire n_46;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_3),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_2),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_2),
.B(n_4),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_8),
.B(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_9),
.B(n_7),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_5),
.B(n_11),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_14),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_19),
.B(n_0),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_19),
.B(n_1),
.Y(n_30)
);

OAI21x1_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_17),
.B(n_21),
.Y(n_31)
);

AOI21xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_24),
.B(n_16),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_23),
.B1(n_20),
.B2(n_18),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_25),
.B1(n_23),
.B2(n_20),
.C(n_15),
.Y(n_35)
);

AOI33xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_27),
.A3(n_26),
.B1(n_28),
.B2(n_5),
.B3(n_4),
.Y(n_36)
);

NOR2xp67_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_6),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_6),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_31),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_35),
.B(n_37),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_SL g43 ( 
.A(n_41),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_40),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_42),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);


endmodule