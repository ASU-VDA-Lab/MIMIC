module fake_netlist_721_3167_n_67 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_19, n_5, n_67);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_19;
input n_5;

output n_67;

wire n_60;
wire n_32;
wire n_33;
wire n_48;
wire n_61;
wire n_30;
wire n_63;
wire n_35;
wire n_54;
wire n_27;
wire n_36;
wire n_37;
wire n_24;
wire n_29;
wire n_41;
wire n_66;
wire n_55;
wire n_43;
wire n_57;
wire n_45;
wire n_39;
wire n_28;
wire n_52;
wire n_31;
wire n_65;
wire n_25;
wire n_22;
wire n_46;
wire n_23;
wire n_56;
wire n_21;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_64;
wire n_62;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_59;
wire n_26;
wire n_58;

INVx1_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_8),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_18),
.B(n_11),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_12),
.B(n_18),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_2),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_15),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_10),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_30),
.B(n_10),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_27),
.B(n_11),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_27),
.B(n_12),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_25),
.Y(n_38)
);

INVxp67_ASAP7_75t_L g39 ( 
.A(n_26),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_21),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_33),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_34),
.A2(n_32),
.B1(n_22),
.B2(n_28),
.Y(n_42)
);

AOI21x1_ASAP7_75t_L g43 ( 
.A1(n_33),
.A2(n_29),
.B(n_23),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_34),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_36),
.Y(n_45)
);

INVxp67_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

AO21x2_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_35),
.B(n_29),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_37),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_34),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_35),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_44),
.B1(n_47),
.B2(n_41),
.Y(n_52)
);

INVxp67_ASAP7_75t_SL g53 ( 
.A(n_49),
.Y(n_53)
);

OR2x2_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_47),
.Y(n_54)
);

NOR2xp33_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_47),
.Y(n_55)
);

AOI22xp33_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_47),
.B1(n_24),
.B2(n_41),
.Y(n_56)
);

INVxp67_ASAP7_75t_SL g57 ( 
.A(n_55),
.Y(n_57)
);

O2A1O1Ixp33_ASAP7_75t_L g58 ( 
.A1(n_54),
.A2(n_38),
.B(n_32),
.C(n_22),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_52),
.Y(n_59)
);

NOR3xp33_ASAP7_75t_L g60 ( 
.A(n_58),
.B(n_57),
.C(n_59),
.Y(n_60)
);

NAND3xp33_ASAP7_75t_L g61 ( 
.A(n_56),
.B(n_31),
.C(n_13),
.Y(n_61)
);

O2A1O1Ixp5_ASAP7_75t_SL g62 ( 
.A1(n_59),
.A2(n_31),
.B(n_1),
.C(n_0),
.Y(n_62)
);

XNOR2xp5_ASAP7_75t_L g63 ( 
.A(n_61),
.B(n_13),
.Y(n_63)
);

NAND2x1_ASAP7_75t_L g64 ( 
.A(n_60),
.B(n_31),
.Y(n_64)
);

OR3x2_ASAP7_75t_L g65 ( 
.A(n_62),
.B(n_19),
.C(n_17),
.Y(n_65)
);

OAI22xp5_ASAP7_75t_L g66 ( 
.A1(n_63),
.A2(n_20),
.B1(n_7),
.B2(n_4),
.Y(n_66)
);

AOI22xp5_ASAP7_75t_L g67 ( 
.A1(n_66),
.A2(n_65),
.B1(n_64),
.B2(n_9),
.Y(n_67)
);


endmodule