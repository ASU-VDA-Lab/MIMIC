module fake_netlist_721_4300_n_10 (n_0, n_3, n_2, n_1, n_10);

input n_0;
input n_3;
input n_2;
input n_1;

output n_10;

wire n_8;
wire n_7;
wire n_9;
wire n_6;
wire n_4;
wire n_5;

AO22x2_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

AOI21xp5_ASAP7_75t_SL g6 ( 
.A1(n_5),
.A2(n_4),
.B(n_0),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

OAI211xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_6),
.B(n_4),
.C(n_2),
.Y(n_8)
);

AO22x2_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_9)
);

AOI222xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_1),
.B1(n_3),
.B2(n_5),
.C1(n_8),
.C2(n_7),
.Y(n_10)
);


endmodule