module fake_netlist_721_2554_n_22 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_22);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_22;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_19;

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx4_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

INVxp67_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI322xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.A3(n_9),
.B1(n_7),
.B2(n_6),
.C1(n_10),
.C2(n_12),
.Y(n_19)
);

XOR2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_7),
.Y(n_20)
);

NOR4xp25_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_3),
.C(n_1),
.D(n_0),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);


endmodule