module fake_netlist_721_2620_n_53 (n_3, n_14, n_20, n_0, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_25, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_26, n_16, n_22, n_6, n_19, n_5, n_53);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_25;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_26;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_53;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_37;
wire n_29;
wire n_41;
wire n_43;
wire n_31;
wire n_39;
wire n_28;
wire n_45;
wire n_52;
wire n_46;
wire n_47;
wire n_44;
wire n_42;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;

INVx2_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_4),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_20),
.B(n_15),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_L g31 ( 
.A(n_3),
.B(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_5),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_18),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_35),
.Y(n_36)
);

INVx5_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_0),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_29),
.Y(n_39)
);

BUFx6f_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NOR2x1_ASAP7_75t_SL g41 ( 
.A(n_39),
.B(n_28),
.Y(n_41)
);

NAND4xp25_ASAP7_75t_SL g42 ( 
.A(n_40),
.B(n_32),
.C(n_27),
.D(n_31),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_38),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_30),
.Y(n_44)
);

OAI21xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_2),
.B(n_1),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_6),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_7),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_8),
.Y(n_48)
);

CKINVDCx20_ASAP7_75t_R g49 ( 
.A(n_47),
.Y(n_49)
);

AOI211x1_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_11),
.B(n_10),
.C(n_9),
.Y(n_50)
);

XOR2x2_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_13),
.Y(n_51)
);

XNOR2xp5_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_14),
.Y(n_52)
);

AOI322xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_16),
.A3(n_17),
.B1(n_22),
.B2(n_25),
.C1(n_26),
.C2(n_52),
.Y(n_53)
);


endmodule