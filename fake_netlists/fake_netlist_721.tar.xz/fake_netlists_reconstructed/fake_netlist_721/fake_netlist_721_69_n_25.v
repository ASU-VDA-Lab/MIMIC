module fake_netlist_721_69_n_25 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_25);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_25;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

AND2x6_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_7),
.B(n_1),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_3),
.Y(n_16)
);

BUFx4f_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

OAI22xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_14),
.B1(n_12),
.B2(n_13),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_17),
.B1(n_10),
.B2(n_15),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_3),
.Y(n_20)
);

AND2x2_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_10),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_2),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_5),
.Y(n_25)
);


endmodule