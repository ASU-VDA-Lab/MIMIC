module fake_netlist_721_1596_n_7 (n_1, n_2, n_0, n_3, n_4, n_7);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_7;

wire n_6;
wire n_5;

AOI21xp5_ASAP7_75t_SL g5 ( 
.A1(n_0),
.A2(n_2),
.B(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_3),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);


endmodule