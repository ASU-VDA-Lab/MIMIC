module fake_netlist_721_4287_n_61 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_61);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_61;

wire n_60;
wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_27;
wire n_24;
wire n_36;
wire n_37;
wire n_41;
wire n_29;
wire n_55;
wire n_43;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_52;
wire n_57;
wire n_25;
wire n_46;
wire n_56;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_59;
wire n_26;

AND2x4_ASAP7_75t_L g24 ( 
.A(n_13),
.B(n_6),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

OAI21x1_ASAP7_75t_L g28 ( 
.A1(n_18),
.A2(n_4),
.B(n_19),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_12),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_17),
.B(n_1),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_9),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

NAND2x1p5_ASAP7_75t_L g36 ( 
.A(n_30),
.B(n_16),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_31),
.A2(n_23),
.B1(n_18),
.B2(n_0),
.Y(n_37)
);

INVx4_ASAP7_75t_SL g38 ( 
.A(n_34),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_33),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_34),
.B(n_24),
.Y(n_40)
);

OA21x2_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_28),
.B(n_26),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_36),
.Y(n_42)
);

AO21x2_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_28),
.B(n_37),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_43),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_41),
.A2(n_24),
.B1(n_29),
.B2(n_33),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_SL g49 ( 
.A(n_48),
.B(n_46),
.Y(n_49)
);

OAI222xp33_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_46),
.B1(n_32),
.B2(n_27),
.C1(n_29),
.C2(n_41),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_SL g51 ( 
.A1(n_47),
.A2(n_27),
.B(n_25),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_29),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_SL g53 ( 
.A(n_51),
.B(n_29),
.C(n_25),
.Y(n_53)
);

NOR4xp25_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_25),
.C(n_3),
.D(n_2),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

AND3x4_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_8),
.C(n_5),
.Y(n_56)
);

XOR2x1_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_10),
.Y(n_57)
);

OR2x6_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_25),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_57),
.Y(n_59)
);

XNOR2xp5_ASAP7_75t_L g60 ( 
.A(n_59),
.B(n_56),
.Y(n_60)
);

OAI222xp33_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_58),
.B1(n_20),
.B2(n_11),
.C1(n_21),
.C2(n_14),
.Y(n_61)
);


endmodule