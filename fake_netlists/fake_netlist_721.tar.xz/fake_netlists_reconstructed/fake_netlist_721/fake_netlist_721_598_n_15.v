module fake_netlist_721_598_n_15 (n_0, n_2, n_1, n_15);

input n_0;
input n_2;
input n_1;

output n_15;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_14;
wire n_4;
wire n_3;
wire n_5;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

BUFx3_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_3),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_2),
.Y(n_8)
);

AND2x4_ASAP7_75t_SL g9 ( 
.A(n_7),
.B(n_3),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_6),
.B1(n_4),
.B2(n_0),
.Y(n_10)
);

NOR2xp67_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_0),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_0),
.Y(n_12)
);

AOI211xp5_ASAP7_75t_SL g13 ( 
.A1(n_11),
.A2(n_9),
.B(n_1),
.C(n_0),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_1),
.B2(n_0),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_1),
.B1(n_2),
.B2(n_13),
.C1(n_11),
.C2(n_7),
.Y(n_15)
);


endmodule