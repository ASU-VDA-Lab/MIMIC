module fake_netlist_721_4080_n_54 (n_3, n_14, n_20, n_0, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_54);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_54;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_37;
wire n_29;
wire n_41;
wire n_43;
wire n_31;
wire n_45;
wire n_39;
wire n_28;
wire n_52;
wire n_25;
wire n_46;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_40;
wire n_34;
wire n_51;
wire n_26;

INVx2_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_10),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_14),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_6),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_13),
.B(n_24),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_2),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_21),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_32),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_29),
.B(n_1),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_29),
.B(n_3),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_27),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

INVx6_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

OR2x6_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_31),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_37),
.Y(n_43)
);

NOR2x1_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_28),
.Y(n_44)
);

OAI322xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_33),
.A3(n_34),
.B1(n_30),
.B2(n_25),
.C1(n_41),
.C2(n_5),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_SL g46 ( 
.A(n_45),
.B(n_41),
.Y(n_46)
);

O2A1O1Ixp33_ASAP7_75t_SL g47 ( 
.A1(n_44),
.A2(n_9),
.B(n_8),
.C(n_7),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_11),
.Y(n_48)
);

AOI21xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_15),
.B(n_12),
.Y(n_49)
);

OR2x2_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_16),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

BUFx2_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

INVxp33_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

AOI322xp5_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_17),
.A3(n_18),
.B1(n_19),
.B2(n_20),
.C1(n_23),
.C2(n_53),
.Y(n_54)
);


endmodule