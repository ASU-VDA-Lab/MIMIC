module fake_netlist_721_170_n_73 (n_3, n_14, n_20, n_0, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_73);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_73;

wire n_60;
wire n_32;
wire n_48;
wire n_33;
wire n_61;
wire n_72;
wire n_30;
wire n_63;
wire n_35;
wire n_54;
wire n_68;
wire n_27;
wire n_36;
wire n_37;
wire n_41;
wire n_29;
wire n_66;
wire n_55;
wire n_43;
wire n_31;
wire n_45;
wire n_39;
wire n_28;
wire n_52;
wire n_57;
wire n_71;
wire n_65;
wire n_25;
wire n_46;
wire n_70;
wire n_56;
wire n_47;
wire n_67;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_64;
wire n_62;
wire n_69;
wire n_50;
wire n_38;
wire n_49;
wire n_40;
wire n_34;
wire n_51;
wire n_59;
wire n_58;

INVx3_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_9),
.B(n_22),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_8),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_4),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

AOI22x1_ASAP7_75t_R g34 ( 
.A1(n_0),
.A2(n_7),
.B1(n_23),
.B2(n_16),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_3),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_1),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_21),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_10),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_30),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_30),
.B(n_22),
.Y(n_40)
);

OR2x6_ASAP7_75t_L g41 ( 
.A(n_27),
.B(n_24),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_30),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_35),
.B(n_5),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_31),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_35),
.B(n_11),
.Y(n_45)
);

OAI211xp5_ASAP7_75t_SL g46 ( 
.A1(n_39),
.A2(n_31),
.B(n_26),
.C(n_38),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_44),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_40),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_43),
.Y(n_49)
);

INVxp67_ASAP7_75t_SL g50 ( 
.A(n_47),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_41),
.Y(n_52)
);

AOI22xp33_ASAP7_75t_L g53 ( 
.A1(n_46),
.A2(n_41),
.B1(n_27),
.B2(n_31),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_41),
.Y(n_56)
);

AOI21xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_53),
.B(n_45),
.Y(n_57)
);

AOI211xp5_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_46),
.B(n_37),
.C(n_27),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_55),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_59),
.Y(n_61)
);

NOR3xp33_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_25),
.C(n_28),
.Y(n_62)
);

INVx5_ASAP7_75t_L g63 ( 
.A(n_60),
.Y(n_63)
);

AOI311xp33_ASAP7_75t_L g64 ( 
.A1(n_57),
.A2(n_33),
.A3(n_29),
.B(n_34),
.C(n_25),
.Y(n_64)
);

AND2x2_ASAP7_75t_L g65 ( 
.A(n_61),
.B(n_57),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_63),
.Y(n_66)
);

AOI22xp33_ASAP7_75t_L g67 ( 
.A1(n_62),
.A2(n_36),
.B1(n_32),
.B2(n_12),
.Y(n_67)
);

NOR2xp33_ASAP7_75t_SL g68 ( 
.A(n_64),
.B(n_32),
.Y(n_68)
);

OAI22xp5_ASAP7_75t_SL g69 ( 
.A1(n_66),
.A2(n_36),
.B1(n_14),
.B2(n_13),
.Y(n_69)
);

HB1xp67_ASAP7_75t_L g70 ( 
.A(n_65),
.Y(n_70)
);

NOR4xp25_ASAP7_75t_SL g71 ( 
.A(n_68),
.B(n_19),
.C(n_18),
.D(n_17),
.Y(n_71)
);

AOI22xp5_ASAP7_75t_L g72 ( 
.A1(n_69),
.A2(n_70),
.B1(n_67),
.B2(n_71),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_72),
.Y(n_73)
);


endmodule