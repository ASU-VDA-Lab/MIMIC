module fake_netlist_721_3661_n_19 (n_1, n_2, n_0, n_3, n_4, n_19);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_19;

wire n_14;
wire n_17;
wire n_13;
wire n_7;
wire n_18;
wire n_6;
wire n_11;
wire n_9;
wire n_12;
wire n_8;
wire n_10;
wire n_15;
wire n_16;
wire n_5;

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

BUFx3_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_1),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_1),
.B(n_2),
.Y(n_11)
);

AOI31xp67_ASAP7_75t_L g12 ( 
.A1(n_5),
.A2(n_3),
.A3(n_4),
.B(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B1(n_14),
.B2(n_11),
.C(n_6),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_7),
.B1(n_5),
.B2(n_10),
.C(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_3),
.B1(n_4),
.B2(n_11),
.C1(n_8),
.C2(n_5),
.Y(n_19)
);


endmodule