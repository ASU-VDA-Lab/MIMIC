module fake_netlist_721_3238_n_40 (n_3, n_14, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_5, n_40);

input n_3;
input n_14;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_5;

output n_40;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_31;
wire n_28;
wire n_39;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_38;
wire n_34;
wire n_22;
wire n_19;

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_12),
.A2(n_2),
.B1(n_16),
.B2(n_17),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

INVxp67_ASAP7_75t_SL g24 ( 
.A(n_6),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_10),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_15),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_16),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_18),
.Y(n_28)
);

A2O1A1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_25),
.B(n_21),
.C(n_23),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_28),
.Y(n_31)
);

OAI33xp33_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_26),
.A3(n_19),
.B1(n_18),
.B2(n_3),
.B3(n_0),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_26),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

O2A1O1Ixp33_ASAP7_75t_SL g36 ( 
.A1(n_34),
.A2(n_19),
.B(n_32),
.C(n_5),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_31),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

NOR2xp67_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_8),
.Y(n_39)
);

AOI222xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.B1(n_13),
.B2(n_9),
.C1(n_14),
.C2(n_11),
.Y(n_40)
);


endmodule