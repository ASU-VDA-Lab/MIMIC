module fake_netlist_721_687_n_25 (n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_25);

input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_25;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_8;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_6),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_SL g11 ( 
.A1(n_0),
.A2(n_6),
.B1(n_2),
.B2(n_1),
.Y(n_11)
);

BUFx6f_ASAP7_75t_SL g12 ( 
.A(n_5),
.Y(n_12)
);

A2O1A1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_7),
.B(n_9),
.Y(n_14)
);

BUFx8_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_7),
.B(n_12),
.C(n_10),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_16),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_15),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_14),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_21),
.B(n_18),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_18),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_19),
.Y(n_25)
);


endmodule