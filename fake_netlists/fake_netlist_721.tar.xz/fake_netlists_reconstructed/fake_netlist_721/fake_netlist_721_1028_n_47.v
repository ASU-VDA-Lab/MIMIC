module fake_netlist_721_1028_n_47 (n_12, n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_47);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_47;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_37;
wire n_29;
wire n_36;
wire n_41;
wire n_13;
wire n_43;
wire n_31;
wire n_18;
wire n_28;
wire n_39;
wire n_45;
wire n_25;
wire n_22;
wire n_46;
wire n_23;
wire n_15;
wire n_21;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_16;
wire n_26;
wire n_19;

INVx1_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_3),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

INVx3_ASAP7_75t_SL g24 ( 
.A(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_13),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_15),
.B(n_14),
.Y(n_27)
);

INVx6_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_26),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_24),
.B1(n_25),
.B2(n_19),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_21),
.Y(n_35)
);

AOI221x1_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_16),
.B1(n_15),
.B2(n_17),
.C(n_18),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AOI221xp5_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_22),
.B1(n_16),
.B2(n_20),
.C(n_27),
.Y(n_39)
);

NOR2xp67_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_9),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_36),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

AND2x4_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_22),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_SL g46 ( 
.A1(n_42),
.A2(n_22),
.B1(n_12),
.B2(n_9),
.Y(n_46)
);

AOI322xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_44),
.A3(n_43),
.B1(n_46),
.B2(n_4),
.C1(n_1),
.C2(n_5),
.Y(n_47)
);


endmodule