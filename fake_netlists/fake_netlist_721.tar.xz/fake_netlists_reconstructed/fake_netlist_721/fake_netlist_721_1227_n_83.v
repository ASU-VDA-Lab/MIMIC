module fake_netlist_721_1227_n_83 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_6, n_19, n_5, n_83);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_6;
input n_19;
input n_5;

output n_83;

wire n_68;
wire n_82;
wire n_37;
wire n_31;
wire n_39;
wire n_65;
wire n_56;
wire n_62;
wire n_69;
wire n_55;
wire n_60;
wire n_33;
wire n_61;
wire n_75;
wire n_79;
wire n_30;
wire n_54;
wire n_73;
wire n_77;
wire n_27;
wire n_24;
wire n_70;
wire n_67;
wire n_81;
wire n_44;
wire n_74;
wire n_53;
wire n_64;
wire n_49;
wire n_40;
wire n_51;
wire n_59;
wire n_22;
wire n_32;
wire n_48;
wire n_35;
wire n_41;
wire n_76;
wire n_57;
wire n_43;
wire n_71;
wire n_25;
wire n_80;
wire n_42;
wire n_34;
wire n_58;
wire n_72;
wire n_63;
wire n_36;
wire n_29;
wire n_66;
wire n_45;
wire n_28;
wire n_52;
wire n_78;
wire n_46;
wire n_23;
wire n_47;
wire n_50;
wire n_38;
wire n_26;

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_6),
.B(n_5),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_14),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_2),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

BUFx10_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_7),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_12),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_13),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_19),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_17),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_10),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_27),
.Y(n_38)
);

OR2x6_ASAP7_75t_L g39 ( 
.A(n_34),
.B(n_16),
.Y(n_39)
);

NAND2xp33_ASAP7_75t_SL g40 ( 
.A(n_27),
.B(n_18),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_35),
.B(n_18),
.Y(n_41)
);

INVx3_ASAP7_75t_L g42 ( 
.A(n_29),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_24),
.Y(n_43)
);

INVx4_ASAP7_75t_L g44 ( 
.A(n_31),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_28),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_31),
.B(n_19),
.Y(n_46)
);

NAND3xp33_ASAP7_75t_SL g47 ( 
.A(n_24),
.B(n_21),
.C(n_1),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_34),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_39),
.A2(n_32),
.B1(n_30),
.B2(n_26),
.Y(n_49)
);

OAI22xp33_ASAP7_75t_L g50 ( 
.A1(n_39),
.A2(n_36),
.B1(n_25),
.B2(n_22),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_36),
.Y(n_51)
);

NOR2xp33_ASAP7_75t_L g52 ( 
.A(n_45),
.B(n_25),
.Y(n_52)
);

AO32x2_ASAP7_75t_L g53 ( 
.A1(n_44),
.A2(n_39),
.A3(n_47),
.B1(n_46),
.B2(n_41),
.Y(n_53)
);

AND2x4_ASAP7_75t_L g54 ( 
.A(n_42),
.B(n_22),
.Y(n_54)
);

INVx4_ASAP7_75t_L g55 ( 
.A(n_42),
.Y(n_55)
);

AOI222xp33_ASAP7_75t_L g56 ( 
.A1(n_43),
.A2(n_29),
.B1(n_23),
.B2(n_33),
.C1(n_22),
.C2(n_3),
.Y(n_56)
);

OAI21x1_ASAP7_75t_L g57 ( 
.A1(n_51),
.A2(n_37),
.B(n_47),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_49),
.A2(n_41),
.B1(n_40),
.B2(n_38),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

BUFx2_ASAP7_75t_L g60 ( 
.A(n_53),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_53),
.Y(n_61)
);

AND2x2_ASAP7_75t_L g62 ( 
.A(n_60),
.B(n_38),
.Y(n_62)
);

OAI31xp33_ASAP7_75t_L g63 ( 
.A1(n_61),
.A2(n_50),
.A3(n_52),
.B(n_48),
.Y(n_63)
);

NAND3xp33_ASAP7_75t_L g64 ( 
.A(n_58),
.B(n_56),
.C(n_55),
.Y(n_64)
);

NAND2xp5_ASAP7_75t_L g65 ( 
.A(n_57),
.B(n_23),
.Y(n_65)
);

NOR3xp33_ASAP7_75t_SL g66 ( 
.A(n_57),
.B(n_8),
.C(n_4),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_62),
.Y(n_67)
);

HB1xp67_ASAP7_75t_L g68 ( 
.A(n_62),
.Y(n_68)
);

NAND2xp5_ASAP7_75t_SL g69 ( 
.A(n_66),
.B(n_22),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_65),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_64),
.Y(n_71)
);

OR2x2_ASAP7_75t_L g72 ( 
.A(n_68),
.B(n_59),
.Y(n_72)
);

AOI22xp5_ASAP7_75t_L g73 ( 
.A1(n_67),
.A2(n_59),
.B1(n_33),
.B2(n_63),
.Y(n_73)
);

NAND4xp75_ASAP7_75t_L g74 ( 
.A(n_71),
.B(n_33),
.C(n_11),
.D(n_9),
.Y(n_74)
);

HB1xp67_ASAP7_75t_L g75 ( 
.A(n_70),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_69),
.Y(n_76)
);

NAND3xp33_ASAP7_75t_SL g77 ( 
.A(n_75),
.B(n_69),
.C(n_33),
.Y(n_77)
);

OAI21xp5_ASAP7_75t_L g78 ( 
.A1(n_73),
.A2(n_76),
.B(n_72),
.Y(n_78)
);

INVx1_ASAP7_75t_SL g79 ( 
.A(n_74),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_75),
.Y(n_80)
);

CKINVDCx20_ASAP7_75t_R g81 ( 
.A(n_80),
.Y(n_81)
);

HB1xp67_ASAP7_75t_L g82 ( 
.A(n_78),
.Y(n_82)
);

AOI22xp33_ASAP7_75t_L g83 ( 
.A1(n_82),
.A2(n_77),
.B1(n_79),
.B2(n_81),
.Y(n_83)
);


endmodule