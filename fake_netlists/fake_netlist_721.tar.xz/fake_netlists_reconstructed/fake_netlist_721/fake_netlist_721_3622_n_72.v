module fake_netlist_721_3622_n_72 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_72);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_72;

wire n_60;
wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_61;
wire n_30;
wire n_63;
wire n_35;
wire n_54;
wire n_68;
wire n_27;
wire n_24;
wire n_37;
wire n_29;
wire n_41;
wire n_36;
wire n_66;
wire n_55;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_57;
wire n_71;
wire n_65;
wire n_25;
wire n_46;
wire n_70;
wire n_23;
wire n_56;
wire n_47;
wire n_67;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_64;
wire n_62;
wire n_69;
wire n_50;
wire n_38;
wire n_49;
wire n_40;
wire n_34;
wire n_51;
wire n_59;

AND2x2_ASAP7_75t_L g23 ( 
.A(n_5),
.B(n_9),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx5_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_22),
.B(n_16),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_15),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_18),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_10),
.Y(n_32)
);

AND2x6_ASAP7_75t_L g33 ( 
.A(n_14),
.B(n_6),
.Y(n_33)
);

INVx5_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_3),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_27),
.B(n_3),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_25),
.B(n_16),
.Y(n_38)
);

INVxp67_ASAP7_75t_L g39 ( 
.A(n_25),
.Y(n_39)
);

OAI21x1_ASAP7_75t_L g40 ( 
.A1(n_35),
.A2(n_32),
.B(n_23),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_SL g41 ( 
.A1(n_38),
.A2(n_31),
.B1(n_28),
.B2(n_24),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_39),
.A2(n_31),
.B1(n_28),
.B2(n_24),
.Y(n_42)
);

INVx1_ASAP7_75t_SL g43 ( 
.A(n_37),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_29),
.B1(n_33),
.B2(n_26),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_41),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_42),
.Y(n_49)
);

NOR3xp33_ASAP7_75t_SL g50 ( 
.A(n_46),
.B(n_36),
.C(n_33),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_26),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_45),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_48),
.Y(n_54)
);

INVx3_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

NAND5xp2_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_50),
.C(n_26),
.D(n_17),
.E(n_19),
.Y(n_56)
);

OAI22xp33_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_32),
.B1(n_27),
.B2(n_34),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

OAI21xp33_ASAP7_75t_SL g59 ( 
.A1(n_55),
.A2(n_33),
.B(n_20),
.Y(n_59)
);

A2O1A1Ixp33_ASAP7_75t_L g60 ( 
.A1(n_55),
.A2(n_27),
.B(n_34),
.C(n_33),
.Y(n_60)
);

NAND2xp33_ASAP7_75t_R g61 ( 
.A(n_58),
.B(n_55),
.Y(n_61)
);

AND2x4_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_52),
.Y(n_62)
);

NOR2xp33_ASAP7_75t_SL g63 ( 
.A(n_59),
.B(n_54),
.Y(n_63)
);

NAND3x1_ASAP7_75t_L g64 ( 
.A(n_56),
.B(n_55),
.C(n_20),
.Y(n_64)
);

INVxp67_ASAP7_75t_L g65 ( 
.A(n_57),
.Y(n_65)
);

AOI22xp33_ASAP7_75t_SL g66 ( 
.A1(n_63),
.A2(n_27),
.B1(n_60),
.B2(n_34),
.Y(n_66)
);

HB1xp67_ASAP7_75t_L g67 ( 
.A(n_62),
.Y(n_67)
);

AOI22xp5_ASAP7_75t_L g68 ( 
.A1(n_64),
.A2(n_34),
.B1(n_21),
.B2(n_0),
.Y(n_68)
);

OA22x2_ASAP7_75t_L g69 ( 
.A1(n_62),
.A2(n_21),
.B1(n_2),
.B2(n_1),
.Y(n_69)
);

AOI222xp33_ASAP7_75t_SL g70 ( 
.A1(n_67),
.A2(n_65),
.B1(n_61),
.B2(n_8),
.C1(n_7),
.C2(n_4),
.Y(n_70)
);

OR3x2_ASAP7_75t_L g71 ( 
.A(n_69),
.B(n_13),
.C(n_12),
.Y(n_71)
);

AOI22xp5_ASAP7_75t_L g72 ( 
.A1(n_70),
.A2(n_66),
.B1(n_68),
.B2(n_71),
.Y(n_72)
);


endmodule