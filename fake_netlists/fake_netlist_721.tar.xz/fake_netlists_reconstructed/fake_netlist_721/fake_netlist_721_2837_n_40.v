module fake_netlist_721_2837_n_40 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_17, n_5, n_40);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_17;
input n_5;

output n_40;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_31;
wire n_18;
wire n_28;
wire n_39;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_38;
wire n_34;
wire n_22;
wire n_19;

INVx1_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_5),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_17),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_1),
.B(n_8),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_11),
.B(n_9),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_4),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_18),
.A2(n_17),
.B1(n_16),
.B2(n_4),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_SL g28 ( 
.A1(n_26),
.A2(n_21),
.B1(n_19),
.B2(n_24),
.Y(n_28)
);

A2O1A1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_25),
.A2(n_21),
.B(n_22),
.C(n_23),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_25),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_27),
.Y(n_32)
);

OAI21xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B(n_27),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_19),
.Y(n_34)
);

AOI211xp5_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_16),
.B(n_3),
.C(n_0),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_34),
.B(n_6),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_36),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_35),
.Y(n_38)
);

NOR3x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_10),
.C(n_7),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_SL g40 ( 
.A1(n_39),
.A2(n_38),
.B1(n_14),
.B2(n_12),
.Y(n_40)
);


endmodule