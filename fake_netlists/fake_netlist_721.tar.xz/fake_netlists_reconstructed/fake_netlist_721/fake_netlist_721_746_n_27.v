module fake_netlist_721_746_n_27 (n_1, n_2, n_0, n_3, n_4, n_27);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_27;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_7;
wire n_18;
wire n_11;
wire n_9;
wire n_25;
wire n_12;
wire n_8;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_6;
wire n_19;
wire n_5;

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_1),
.A2(n_2),
.B1(n_0),
.B2(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_2),
.Y(n_8)
);

AO31x2_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_7),
.A3(n_8),
.B(n_1),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx6_ASAP7_75t_SL g12 ( 
.A(n_6),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_7),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_8),
.C(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_9),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_17),
.B(n_14),
.C(n_16),
.Y(n_19)
);

NOR4xp25_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_9),
.C(n_2),
.D(n_0),
.Y(n_20)
);

OAI211xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_12),
.B(n_9),
.C(n_0),
.Y(n_21)
);

NAND4xp25_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_12),
.C(n_9),
.D(n_0),
.Y(n_22)
);

NAND4xp75_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_12),
.C(n_4),
.D(n_3),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_L g24 ( 
.A1(n_19),
.A2(n_20),
.B1(n_12),
.B2(n_3),
.C(n_4),
.Y(n_24)
);

OAI22x1_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_1),
.B1(n_4),
.B2(n_23),
.Y(n_25)
);

AO22x2_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_1),
.B1(n_21),
.B2(n_16),
.Y(n_26)
);

AO21x2_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B(n_25),
.Y(n_27)
);


endmodule