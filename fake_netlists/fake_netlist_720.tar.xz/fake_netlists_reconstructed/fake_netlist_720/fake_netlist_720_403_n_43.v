module fake_netlist_720_403_n_43 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_43);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_43;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_31;
wire n_18;
wire n_28;
wire n_39;
wire n_25;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_16;
wire n_22;
wire n_19;

INVx2_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

INVxp67_ASAP7_75t_SL g19 ( 
.A(n_4),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_8),
.B(n_11),
.Y(n_20)
);

AO22x1_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_7),
.B1(n_6),
.B2(n_1),
.Y(n_21)
);

INVxp67_ASAP7_75t_SL g22 ( 
.A(n_17),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_19),
.B1(n_24),
.B2(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AND2x2_ASAP7_75t_SL g31 ( 
.A(n_29),
.B(n_20),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_30),
.B(n_16),
.C(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

NOR4xp25_ASAP7_75t_SL g34 ( 
.A(n_31),
.B(n_15),
.C(n_24),
.D(n_18),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_SL g35 ( 
.A(n_33),
.B(n_26),
.C(n_18),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

OAI322xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_14),
.A3(n_27),
.B1(n_23),
.B2(n_5),
.C1(n_3),
.C2(n_9),
.Y(n_37)
);

XOR2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_10),
.Y(n_38)
);

BUFx6f_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

OAI21xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_27),
.B(n_13),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_38),
.B1(n_39),
.B2(n_42),
.Y(n_43)
);


endmodule