module fake_netlist_720_1738_n_33 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_17, n_5, n_33);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_17;
input n_5;

output n_33;

wire n_32;
wire n_30;
wire n_20;
wire n_27;
wire n_24;
wire n_29;
wire n_18;
wire n_31;
wire n_28;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_22;
wire n_19;

INVx2_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_11),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_14),
.A2(n_5),
.B1(n_17),
.B2(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_18),
.B(n_15),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_16),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_21),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_22),
.B1(n_20),
.B2(n_23),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_27),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_16),
.Y(n_29)
);

AOI211xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_4),
.B(n_3),
.C(n_2),
.Y(n_30)
);

AND3x4_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_8),
.C(n_6),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_R g33 ( 
.A1(n_32),
.A2(n_13),
.B1(n_12),
.B2(n_10),
.Y(n_33)
);


endmodule