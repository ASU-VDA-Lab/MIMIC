module fake_netlist_720_1581_n_7 (n_1, n_2, n_0, n_3, n_4, n_7);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_7;

wire n_6;
wire n_5;

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_3),
.Y(n_6)
);

NAND4xp75_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_0),
.C(n_1),
.D(n_5),
.Y(n_7)
);


endmodule