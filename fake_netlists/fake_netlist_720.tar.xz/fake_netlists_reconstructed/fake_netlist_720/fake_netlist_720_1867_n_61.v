module fake_netlist_720_1867_n_61 (n_12, n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_61);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_61;

wire n_60;
wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_36;
wire n_37;
wire n_41;
wire n_29;
wire n_24;
wire n_13;
wire n_57;
wire n_43;
wire n_18;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_52;
wire n_55;
wire n_25;
wire n_46;
wire n_23;
wire n_56;
wire n_15;
wire n_21;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_40;
wire n_34;
wire n_51;
wire n_59;
wire n_16;
wire n_22;
wire n_19;

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

BUFx3_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_10),
.Y(n_16)
);

BUFx6f_ASAP7_75t_SL g17 ( 
.A(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_4),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_3),
.B(n_0),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_9),
.B(n_3),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_9),
.B(n_11),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_13),
.A2(n_2),
.B(n_0),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

A2O1A1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_14),
.A2(n_6),
.B(n_5),
.C(n_2),
.Y(n_27)
);

OR2x2_ASAP7_75t_SL g28 ( 
.A(n_22),
.B(n_18),
.Y(n_28)
);

O2A1O1Ixp5_ASAP7_75t_L g29 ( 
.A1(n_21),
.A2(n_8),
.B(n_7),
.C(n_6),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_14),
.B(n_7),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_14),
.B(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_13),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_17),
.A2(n_8),
.B1(n_11),
.B2(n_21),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_19),
.B(n_16),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_20),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_25),
.B(n_23),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_25),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_28),
.B(n_17),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_30),
.Y(n_40)
);

NOR2x1_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_31),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_36),
.B(n_28),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_26),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_36),
.B(n_33),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_34),
.B1(n_35),
.B2(n_37),
.C(n_40),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_41),
.B(n_34),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

AOI21xp33_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_39),
.B(n_29),
.Y(n_49)
);

NAND3xp33_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_42),
.C(n_35),
.Y(n_50)
);

OAI311xp33_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_27),
.A3(n_37),
.B1(n_49),
.C1(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

OAI21xp33_ASAP7_75t_L g53 ( 
.A1(n_46),
.A2(n_23),
.B(n_20),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

CKINVDCx5p33_ASAP7_75t_R g55 ( 
.A(n_53),
.Y(n_55)
);

INVx1_ASAP7_75t_SL g56 ( 
.A(n_52),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_50),
.Y(n_57)
);

OAI22xp5_ASAP7_75t_SL g58 ( 
.A1(n_57),
.A2(n_55),
.B1(n_56),
.B2(n_54),
.Y(n_58)
);

XNOR2xp5_ASAP7_75t_L g59 ( 
.A(n_57),
.B(n_24),
.Y(n_59)
);

AOI22x1_ASAP7_75t_L g60 ( 
.A1(n_54),
.A2(n_56),
.B1(n_51),
.B2(n_38),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_SL g61 ( 
.A1(n_59),
.A2(n_58),
.B1(n_60),
.B2(n_17),
.Y(n_61)
);


endmodule