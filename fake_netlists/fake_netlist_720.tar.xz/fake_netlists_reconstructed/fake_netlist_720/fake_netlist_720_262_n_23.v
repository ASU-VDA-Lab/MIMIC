module fake_netlist_720_262_n_23 (n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_23);

input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_23;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_12;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

INVx3_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_6),
.B(n_8),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_SL g17 ( 
.A1(n_12),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_12),
.A2(n_7),
.B1(n_4),
.B2(n_2),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.C1(n_16),
.C2(n_18),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_16),
.Y(n_20)
);

XOR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_15),
.Y(n_21)
);

INVx1_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_11),
.B1(n_9),
.B2(n_3),
.Y(n_23)
);


endmodule