module fake_netlist_720_1370_n_48 (n_3, n_14, n_20, n_0, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_48);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_48;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_25;
wire n_46;
wire n_47;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_26;

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_9),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_17),
.B(n_7),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_11),
.B(n_20),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_12),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_0),
.B(n_13),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_2),
.B(n_21),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_24),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_15),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_24),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_28),
.B(n_32),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_1),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NOR3xp33_ASAP7_75t_SL g37 ( 
.A(n_33),
.B(n_29),
.C(n_26),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_35),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_30),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_25),
.B1(n_27),
.B2(n_3),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_5),
.B1(n_4),
.B2(n_6),
.C(n_8),
.Y(n_43)
);

INVx2_ASAP7_75t_SL g44 ( 
.A(n_42),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

XOR2x1_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_10),
.Y(n_46)
);

OAI22x1_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_18),
.B1(n_16),
.B2(n_14),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_19),
.B1(n_22),
.B2(n_46),
.Y(n_48)
);


endmodule