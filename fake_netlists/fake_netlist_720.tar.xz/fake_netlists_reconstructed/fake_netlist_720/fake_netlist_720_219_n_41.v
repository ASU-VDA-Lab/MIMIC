module fake_netlist_720_219_n_41 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_6, n_19, n_5, n_41);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_6;
input n_19;
input n_5;

output n_41;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_27;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_31;
wire n_28;
wire n_39;
wire n_25;
wire n_23;
wire n_26;
wire n_38;
wire n_34;
wire n_40;
wire n_22;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_20),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_19),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_17),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_6),
.B(n_15),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_0),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_12),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_7),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_25),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_24),
.B(n_17),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_22),
.B(n_1),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_26),
.B1(n_29),
.B2(n_27),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_R g34 ( 
.A(n_31),
.B(n_23),
.Y(n_34)
);

OAI31xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_32),
.A3(n_28),
.B(n_2),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_3),
.Y(n_36)
);

AOI222xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_8),
.B2(n_4),
.C1(n_9),
.C2(n_5),
.Y(n_37)
);

AOI211x1_ASAP7_75t_SL g38 ( 
.A1(n_37),
.A2(n_14),
.B(n_11),
.C(n_10),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_21),
.B1(n_18),
.B2(n_16),
.Y(n_41)
);


endmodule