module fake_netlist_720_410_n_34 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_17, n_5, n_34);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_17;
input n_5;

output n_34;

wire n_32;
wire n_33;
wire n_30;
wire n_20;
wire n_27;
wire n_24;
wire n_29;
wire n_18;
wire n_31;
wire n_28;
wire n_25;
wire n_22;
wire n_23;
wire n_21;
wire n_26;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

INVxp33_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_7),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_10),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_11),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_13),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_19),
.B1(n_18),
.B2(n_21),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_23),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_27),
.B1(n_24),
.B2(n_18),
.C1(n_22),
.C2(n_13),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_16),
.B1(n_15),
.B2(n_0),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_16),
.B1(n_3),
.B2(n_1),
.Y(n_33)
);

AOI222xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_8),
.B1(n_5),
.B2(n_9),
.C1(n_14),
.C2(n_12),
.Y(n_34)
);


endmodule