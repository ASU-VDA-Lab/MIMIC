module fake_netlist_720_490_n_14 (n_1, n_2, n_0, n_3, n_4, n_14);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_14;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_5;

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_4),
.Y(n_6)
);

OAI21x1_ASAP7_75t_SL g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

OAI21x1_ASAP7_75t_SL g8 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

AO21x2_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI21xp33_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B1(n_9),
.B2(n_2),
.C(n_3),
.Y(n_12)
);

NOR3xp33_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.C(n_9),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_4),
.B2(n_3),
.Y(n_14)
);


endmodule