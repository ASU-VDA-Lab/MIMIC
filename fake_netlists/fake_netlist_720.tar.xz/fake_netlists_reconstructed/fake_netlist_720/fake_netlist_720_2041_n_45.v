module fake_netlist_720_2041_n_45 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_19, n_5, n_45);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_19;
input n_5;

output n_45;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_24;
wire n_29;
wire n_37;
wire n_41;
wire n_43;
wire n_31;
wire n_28;
wire n_39;
wire n_25;
wire n_22;
wire n_23;
wire n_21;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_26;

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_17),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_0),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_5),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_3),
.B(n_18),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_1),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_28),
.B1(n_23),
.B2(n_26),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_21),
.A2(n_19),
.B(n_18),
.C(n_16),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

NAND2xp33_ASAP7_75t_R g34 ( 
.A(n_30),
.B(n_23),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_31),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_22),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_32),
.B1(n_25),
.B2(n_24),
.C(n_29),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_19),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_7),
.C(n_4),
.Y(n_40)
);

AO22x2_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

OR2x6_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_11),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_20),
.B1(n_41),
.B2(n_44),
.Y(n_45)
);


endmodule