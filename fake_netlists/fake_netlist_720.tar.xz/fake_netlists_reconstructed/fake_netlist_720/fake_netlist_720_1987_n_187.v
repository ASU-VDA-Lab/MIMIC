module fake_netlist_720_1987_n_187 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_6, n_19, n_5, n_187);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_6;
input n_19;
input n_5;

output n_187;

wire n_154;
wire n_68;
wire n_185;
wire n_82;
wire n_37;
wire n_112;
wire n_141;
wire n_31;
wire n_39;
wire n_173;
wire n_121;
wire n_179;
wire n_162;
wire n_65;
wire n_184;
wire n_140;
wire n_164;
wire n_144;
wire n_171;
wire n_128;
wire n_181;
wire n_56;
wire n_130;
wire n_159;
wire n_165;
wire n_94;
wire n_62;
wire n_123;
wire n_69;
wire n_97;
wire n_135;
wire n_139;
wire n_55;
wire n_148;
wire n_110;
wire n_172;
wire n_102;
wire n_60;
wire n_105;
wire n_33;
wire n_61;
wire n_75;
wire n_174;
wire n_106;
wire n_79;
wire n_30;
wire n_186;
wire n_118;
wire n_54;
wire n_168;
wire n_73;
wire n_77;
wire n_27;
wire n_125;
wire n_24;
wire n_131;
wire n_85;
wire n_126;
wire n_169;
wire n_120;
wire n_116;
wire n_132;
wire n_70;
wire n_142;
wire n_129;
wire n_67;
wire n_92;
wire n_81;
wire n_155;
wire n_44;
wire n_74;
wire n_124;
wire n_53;
wire n_64;
wire n_107;
wire n_138;
wire n_49;
wire n_40;
wire n_51;
wire n_147;
wire n_163;
wire n_59;
wire n_111;
wire n_166;
wire n_161;
wire n_117;
wire n_22;
wire n_93;
wire n_158;
wire n_84;
wire n_180;
wire n_32;
wire n_48;
wire n_143;
wire n_35;
wire n_136;
wire n_96;
wire n_182;
wire n_104;
wire n_115;
wire n_41;
wire n_98;
wire n_183;
wire n_100;
wire n_145;
wire n_76;
wire n_57;
wire n_43;
wire n_137;
wire n_71;
wire n_25;
wire n_113;
wire n_80;
wire n_108;
wire n_119;
wire n_160;
wire n_87;
wire n_176;
wire n_42;
wire n_167;
wire n_156;
wire n_34;
wire n_89;
wire n_58;
wire n_86;
wire n_72;
wire n_114;
wire n_151;
wire n_90;
wire n_63;
wire n_101;
wire n_127;
wire n_146;
wire n_36;
wire n_29;
wire n_66;
wire n_83;
wire n_91;
wire n_95;
wire n_150;
wire n_152;
wire n_45;
wire n_28;
wire n_52;
wire n_133;
wire n_78;
wire n_153;
wire n_46;
wire n_122;
wire n_88;
wire n_134;
wire n_23;
wire n_99;
wire n_157;
wire n_47;
wire n_50;
wire n_38;
wire n_109;
wire n_178;
wire n_170;
wire n_175;
wire n_103;
wire n_177;
wire n_149;
wire n_26;

INVx1_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_8),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_13),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

INVx2_ASAP7_75t_SL g28 ( 
.A(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_10),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_12),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_1),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_19),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_16),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_15),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_7),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_18),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_9),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_22),
.Y(n_40)
);

INVx5_ASAP7_75t_L g41 ( 
.A(n_25),
.Y(n_41)
);

AND2x2_ASAP7_75t_SL g42 ( 
.A(n_26),
.B(n_0),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_29),
.Y(n_43)
);

BUFx6f_ASAP7_75t_L g44 ( 
.A(n_27),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_29),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_33),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_SL g47 ( 
.A(n_28),
.B(n_2),
.Y(n_47)
);

BUFx6f_ASAP7_75t_L g48 ( 
.A(n_27),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_L g49 ( 
.A(n_39),
.B(n_3),
.Y(n_49)
);

BUFx6f_ASAP7_75t_L g50 ( 
.A(n_31),
.Y(n_50)
);

BUFx6f_ASAP7_75t_L g51 ( 
.A(n_31),
.Y(n_51)
);

BUFx3_ASAP7_75t_L g52 ( 
.A(n_24),
.Y(n_52)
);

BUFx6f_ASAP7_75t_L g53 ( 
.A(n_35),
.Y(n_53)
);

INVx8_ASAP7_75t_L g54 ( 
.A(n_41),
.Y(n_54)
);

BUFx10_ASAP7_75t_L g55 ( 
.A(n_49),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_44),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_44),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_40),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_43),
.Y(n_59)
);

INVx2_ASAP7_75t_SL g60 ( 
.A(n_52),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_43),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_44),
.Y(n_62)
);

INVx2_ASAP7_75t_L g63 ( 
.A(n_48),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_45),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_46),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_46),
.Y(n_66)
);

INVx2_ASAP7_75t_L g67 ( 
.A(n_48),
.Y(n_67)
);

INVx3_ASAP7_75t_L g68 ( 
.A(n_48),
.Y(n_68)
);

INVx4_ASAP7_75t_L g69 ( 
.A(n_41),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_50),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_50),
.Y(n_71)
);

OR2x6_ASAP7_75t_L g72 ( 
.A(n_47),
.B(n_34),
.Y(n_72)
);

INVx2_ASAP7_75t_L g73 ( 
.A(n_50),
.Y(n_73)
);

INVx2_ASAP7_75t_L g74 ( 
.A(n_51),
.Y(n_74)
);

INVx2_ASAP7_75t_L g75 ( 
.A(n_51),
.Y(n_75)
);

INVx2_ASAP7_75t_L g76 ( 
.A(n_51),
.Y(n_76)
);

INVx2_ASAP7_75t_L g77 ( 
.A(n_51),
.Y(n_77)
);

INVx2_ASAP7_75t_L g78 ( 
.A(n_51),
.Y(n_78)
);

AOI22xp5_ASAP7_75t_L g79 ( 
.A1(n_42),
.A2(n_32),
.B1(n_30),
.B2(n_37),
.Y(n_79)
);

INVx2_ASAP7_75t_L g80 ( 
.A(n_51),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_53),
.Y(n_81)
);

NAND2xp5_ASAP7_75t_L g82 ( 
.A(n_60),
.B(n_41),
.Y(n_82)
);

INVx2_ASAP7_75t_L g83 ( 
.A(n_67),
.Y(n_83)
);

NAND2xp5_ASAP7_75t_SL g84 ( 
.A(n_55),
.B(n_53),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_58),
.Y(n_85)
);

AND2x2_ASAP7_75t_SL g86 ( 
.A(n_79),
.B(n_36),
.Y(n_86)
);

BUFx3_ASAP7_75t_L g87 ( 
.A(n_68),
.Y(n_87)
);

NAND2xp5_ASAP7_75t_L g88 ( 
.A(n_72),
.B(n_23),
.Y(n_88)
);

INVx2_ASAP7_75t_L g89 ( 
.A(n_70),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_71),
.Y(n_90)
);

NOR3xp33_ASAP7_75t_L g91 ( 
.A(n_79),
.B(n_61),
.C(n_59),
.Y(n_91)
);

NOR2xp33_ASAP7_75t_L g92 ( 
.A(n_64),
.B(n_65),
.Y(n_92)
);

NOR2xp33_ASAP7_75t_L g93 ( 
.A(n_66),
.B(n_38),
.Y(n_93)
);

BUFx6f_ASAP7_75t_L g94 ( 
.A(n_87),
.Y(n_94)
);

AOI21xp5_ASAP7_75t_L g95 ( 
.A1(n_84),
.A2(n_54),
.B(n_56),
.Y(n_95)
);

INVx2_ASAP7_75t_L g96 ( 
.A(n_83),
.Y(n_96)
);

INVx2_ASAP7_75t_L g97 ( 
.A(n_83),
.Y(n_97)
);

AOI21xp5_ASAP7_75t_L g98 ( 
.A1(n_84),
.A2(n_54),
.B(n_57),
.Y(n_98)
);

OAI21xp5_ASAP7_75t_L g99 ( 
.A1(n_92),
.A2(n_63),
.B(n_62),
.Y(n_99)
);

A2O1A1Ixp33_ASAP7_75t_L g100 ( 
.A1(n_91),
.A2(n_75),
.B(n_74),
.C(n_73),
.Y(n_100)
);

A2O1A1Ixp33_ASAP7_75t_L g101 ( 
.A1(n_86),
.A2(n_76),
.B(n_75),
.C(n_74),
.Y(n_101)
);

NAND2xp5_ASAP7_75t_L g102 ( 
.A(n_85),
.B(n_76),
.Y(n_102)
);

AOI21xp5_ASAP7_75t_L g103 ( 
.A1(n_82),
.A2(n_54),
.B(n_63),
.Y(n_103)
);

NOR2x1_ASAP7_75t_L g104 ( 
.A(n_88),
.B(n_77),
.Y(n_104)
);

O2A1O1Ixp5_ASAP7_75t_L g105 ( 
.A1(n_93),
.A2(n_81),
.B(n_80),
.C(n_78),
.Y(n_105)
);

OAI21xp5_ASAP7_75t_L g106 ( 
.A1(n_105),
.A2(n_100),
.B(n_101),
.Y(n_106)
);

OAI21x1_ASAP7_75t_L g107 ( 
.A1(n_99),
.A2(n_90),
.B(n_89),
.Y(n_107)
);

INVx2_ASAP7_75t_L g108 ( 
.A(n_96),
.Y(n_108)
);

BUFx6f_ASAP7_75t_L g109 ( 
.A(n_94),
.Y(n_109)
);

INVx2_ASAP7_75t_L g110 ( 
.A(n_96),
.Y(n_110)
);

BUFx6f_ASAP7_75t_L g111 ( 
.A(n_94),
.Y(n_111)
);

INVx2_ASAP7_75t_L g112 ( 
.A(n_97),
.Y(n_112)
);

OAI21x1_ASAP7_75t_L g113 ( 
.A1(n_103),
.A2(n_98),
.B(n_95),
.Y(n_113)
);

OAI21x1_ASAP7_75t_L g114 ( 
.A1(n_106),
.A2(n_113),
.B(n_107),
.Y(n_114)
);

OAI21x1_ASAP7_75t_L g115 ( 
.A1(n_106),
.A2(n_104),
.B(n_102),
.Y(n_115)
);

BUFx6f_ASAP7_75t_L g116 ( 
.A(n_109),
.Y(n_116)
);

INVx5_ASAP7_75t_L g117 ( 
.A(n_109),
.Y(n_117)
);

INVx2_ASAP7_75t_L g118 ( 
.A(n_108),
.Y(n_118)
);

INVx2_ASAP7_75t_L g119 ( 
.A(n_110),
.Y(n_119)
);

INVx2_ASAP7_75t_L g120 ( 
.A(n_112),
.Y(n_120)
);

INVx3_ASAP7_75t_L g121 ( 
.A(n_111),
.Y(n_121)
);

INVx2_ASAP7_75t_SL g122 ( 
.A(n_117),
.Y(n_122)
);

INVx2_ASAP7_75t_L g123 ( 
.A(n_114),
.Y(n_123)
);

INVx2_ASAP7_75t_L g124 ( 
.A(n_118),
.Y(n_124)
);

INVx2_ASAP7_75t_L g125 ( 
.A(n_119),
.Y(n_125)
);

INVx3_ASAP7_75t_L g126 ( 
.A(n_116),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_120),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_121),
.Y(n_128)
);

INVx2_ASAP7_75t_L g129 ( 
.A(n_115),
.Y(n_129)
);

INVx2_ASAP7_75t_L g130 ( 
.A(n_124),
.Y(n_130)
);

INVx2_ASAP7_75t_L g131 ( 
.A(n_124),
.Y(n_131)
);

INVx2_ASAP7_75t_L g132 ( 
.A(n_124),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_127),
.Y(n_133)
);

INVx2_ASAP7_75t_L g134 ( 
.A(n_125),
.Y(n_134)
);

AND2x2_ASAP7_75t_L g135 ( 
.A(n_128),
.B(n_5),
.Y(n_135)
);

INVx2_ASAP7_75t_L g136 ( 
.A(n_123),
.Y(n_136)
);

INVx2_ASAP7_75t_L g137 ( 
.A(n_123),
.Y(n_137)
);

INVx2_ASAP7_75t_L g138 ( 
.A(n_123),
.Y(n_138)
);

INVx2_ASAP7_75t_L g139 ( 
.A(n_129),
.Y(n_139)
);

INVx1_ASAP7_75t_L g140 ( 
.A(n_126),
.Y(n_140)
);

INVx2_ASAP7_75t_L g141 ( 
.A(n_139),
.Y(n_141)
);

INVx2_ASAP7_75t_L g142 ( 
.A(n_139),
.Y(n_142)
);

INVx2_ASAP7_75t_L g143 ( 
.A(n_136),
.Y(n_143)
);

INVx2_ASAP7_75t_L g144 ( 
.A(n_137),
.Y(n_144)
);

INVx2_ASAP7_75t_L g145 ( 
.A(n_138),
.Y(n_145)
);

INVx2_ASAP7_75t_L g146 ( 
.A(n_130),
.Y(n_146)
);

INVx2_ASAP7_75t_L g147 ( 
.A(n_131),
.Y(n_147)
);

NAND2xp5_ASAP7_75t_L g148 ( 
.A(n_135),
.B(n_122),
.Y(n_148)
);

INVx2_ASAP7_75t_L g149 ( 
.A(n_132),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_133),
.Y(n_150)
);

INVx2_ASAP7_75t_L g151 ( 
.A(n_134),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_140),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_150),
.Y(n_153)
);

INVx2_ASAP7_75t_L g154 ( 
.A(n_141),
.Y(n_154)
);

INVx2_ASAP7_75t_L g155 ( 
.A(n_141),
.Y(n_155)
);

INVx2_ASAP7_75t_L g156 ( 
.A(n_142),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_152),
.Y(n_157)
);

INVx2_ASAP7_75t_L g158 ( 
.A(n_142),
.Y(n_158)
);

INVx2_ASAP7_75t_L g159 ( 
.A(n_143),
.Y(n_159)
);

INVx2_ASAP7_75t_L g160 ( 
.A(n_143),
.Y(n_160)
);

INVx2_ASAP7_75t_L g161 ( 
.A(n_144),
.Y(n_161)
);

INVx2_ASAP7_75t_L g162 ( 
.A(n_145),
.Y(n_162)
);

INVx2_ASAP7_75t_L g163 ( 
.A(n_145),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_146),
.Y(n_164)
);

INVx2_ASAP7_75t_L g165 ( 
.A(n_147),
.Y(n_165)
);

INVx2_ASAP7_75t_L g166 ( 
.A(n_149),
.Y(n_166)
);

INVx2_ASAP7_75t_L g167 ( 
.A(n_151),
.Y(n_167)
);

AND2x2_ASAP7_75t_L g168 ( 
.A(n_148),
.B(n_69),
.Y(n_168)
);

INVx1_ASAP7_75t_L g169 ( 
.A(n_153),
.Y(n_169)
);

INVx1_ASAP7_75t_L g170 ( 
.A(n_157),
.Y(n_170)
);

INVx1_ASAP7_75t_L g171 ( 
.A(n_169),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_170),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_171),
.Y(n_173)
);

NAND2xp5_ASAP7_75t_L g174 ( 
.A(n_173),
.B(n_172),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_174),
.Y(n_175)
);

INVx2_ASAP7_75t_L g176 ( 
.A(n_175),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_176),
.Y(n_177)
);

AND2x4_ASAP7_75t_L g178 ( 
.A(n_177),
.B(n_154),
.Y(n_178)
);

AOI211xp5_ASAP7_75t_SL g179 ( 
.A1(n_178),
.A2(n_168),
.B(n_156),
.C(n_155),
.Y(n_179)
);

OAI22xp5_ASAP7_75t_SL g180 ( 
.A1(n_179),
.A2(n_160),
.B1(n_159),
.B2(n_158),
.Y(n_180)
);

INVx1_ASAP7_75t_L g181 ( 
.A(n_180),
.Y(n_181)
);

INVx1_ASAP7_75t_L g182 ( 
.A(n_181),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_182),
.Y(n_183)
);

OAI21xp5_ASAP7_75t_L g184 ( 
.A1(n_183),
.A2(n_162),
.B(n_161),
.Y(n_184)
);

NAND2xp5_ASAP7_75t_L g185 ( 
.A(n_184),
.B(n_163),
.Y(n_185)
);

OR2x6_ASAP7_75t_L g186 ( 
.A(n_185),
.B(n_164),
.Y(n_186)
);

AOI22xp33_ASAP7_75t_L g187 ( 
.A1(n_186),
.A2(n_167),
.B1(n_166),
.B2(n_165),
.Y(n_187)
);


endmodule