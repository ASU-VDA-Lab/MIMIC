module fake_netlist_720_580_n_16 (n_1, n_2, n_0, n_3, n_4, n_5, n_16);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;
input n_5;

output n_16;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_15;
wire n_14;
wire n_6;
wire n_9;

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_5),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_1),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_8),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_6),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_7),
.Y(n_13)
);

INVxp67_ASAP7_75t_SL g14 ( 
.A(n_13),
.Y(n_14)
);

OAI22x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_4),
.B1(n_0),
.B2(n_2),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_4),
.B1(n_0),
.B2(n_3),
.Y(n_16)
);


endmodule