module fake_netlist_720_1044_n_60 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_19, n_5, n_60);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_19;
input n_5;

output n_60;

wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_27;
wire n_37;
wire n_24;
wire n_36;
wire n_29;
wire n_41;
wire n_55;
wire n_43;
wire n_31;
wire n_28;
wire n_45;
wire n_39;
wire n_52;
wire n_57;
wire n_25;
wire n_22;
wire n_46;
wire n_23;
wire n_56;
wire n_21;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_59;
wire n_26;

INVx3_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

AND2x6_ASAP7_75t_L g25 ( 
.A(n_7),
.B(n_19),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_14),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_11),
.B(n_6),
.Y(n_30)
);

OAI22x1_ASAP7_75t_R g31 ( 
.A1(n_10),
.A2(n_5),
.B1(n_3),
.B2(n_15),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_23),
.B(n_16),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_26),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

INVxp67_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_23),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_21),
.B(n_17),
.Y(n_37)
);

AO22x2_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_21),
.B1(n_28),
.B2(n_31),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_24),
.B(n_30),
.Y(n_39)
);

NOR2xp67_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_29),
.Y(n_40)
);

OR2x6_ASAP7_75t_L g41 ( 
.A(n_35),
.B(n_28),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_33),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_37),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_42),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_42),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_39),
.B(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

OAI21xp5_ASAP7_75t_SL g51 ( 
.A1(n_50),
.A2(n_38),
.B(n_32),
.Y(n_51)
);

XOR2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_38),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_40),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_22),
.Y(n_55)
);

CKINVDCx5p33_ASAP7_75t_R g56 ( 
.A(n_53),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_25),
.B1(n_29),
.B2(n_27),
.Y(n_57)
);

OAI221xp5_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_27),
.B1(n_25),
.B2(n_0),
.C(n_1),
.Y(n_58)
);

AOI222xp33_ASAP7_75t_SL g59 ( 
.A1(n_58),
.A2(n_25),
.B1(n_56),
.B2(n_9),
.C1(n_8),
.C2(n_2),
.Y(n_59)
);

AOI22xp5_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_57),
.B1(n_25),
.B2(n_12),
.Y(n_60)
);


endmodule