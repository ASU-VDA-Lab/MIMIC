module fake_netlist_720_551_n_42 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_6, n_19, n_5, n_42);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_6;
input n_19;
input n_5;

output n_42;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_27;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_31;
wire n_28;
wire n_39;
wire n_25;
wire n_23;
wire n_26;
wire n_38;
wire n_34;
wire n_40;
wire n_22;

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_14),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_13),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_3),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_4),
.B(n_9),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_10),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_2),
.B(n_0),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_15),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_22),
.B2(n_26),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_30),
.Y(n_34)
);

AND2x4_ASAP7_75t_SL g35 ( 
.A(n_33),
.B(n_26),
.Y(n_35)
);

AOI322xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_34),
.A3(n_29),
.B1(n_25),
.B2(n_27),
.C1(n_17),
.C2(n_18),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_28),
.B2(n_17),
.C(n_18),
.Y(n_37)
);

OAI221xp5_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_19),
.B1(n_7),
.B2(n_5),
.C(n_6),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_SL g41 ( 
.A1(n_40),
.A2(n_19),
.B1(n_11),
.B2(n_8),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_39),
.B1(n_21),
.B2(n_20),
.Y(n_42)
);


endmodule