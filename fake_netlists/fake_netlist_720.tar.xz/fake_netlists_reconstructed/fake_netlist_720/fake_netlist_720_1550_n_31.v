module fake_netlist_720_1550_n_31 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_31);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_31;

wire n_30;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_18;
wire n_28;
wire n_25;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

INVx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_3),
.A2(n_4),
.B1(n_5),
.B2(n_13),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_3),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_11),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_2),
.C(n_0),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_14),
.A2(n_12),
.B(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_19),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_19),
.Y(n_24)
);

OAI222xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_16),
.B1(n_22),
.B2(n_14),
.C1(n_18),
.C2(n_19),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_17),
.B1(n_16),
.B2(n_23),
.C(n_0),
.Y(n_26)
);

OAI222xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_23),
.B1(n_6),
.B2(n_2),
.C1(n_7),
.C2(n_4),
.Y(n_27)
);

XNOR2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_6),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_23),
.B1(n_8),
.B2(n_7),
.Y(n_30)
);

OAI221xp5_ASAP7_75t_R g31 ( 
.A1(n_30),
.A2(n_28),
.B1(n_11),
.B2(n_8),
.C(n_10),
.Y(n_31)
);


endmodule