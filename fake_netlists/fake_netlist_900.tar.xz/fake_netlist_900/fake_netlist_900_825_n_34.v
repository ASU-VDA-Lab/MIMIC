module fake_netlist_900_825_n_34 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_34);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_34;

wire n_33;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_26;
wire n_29;

INVx2_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_3),
.Y(n_19)
);

NAND2xp33_ASAP7_75t_R g20 ( 
.A(n_14),
.B(n_6),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_R g23 ( 
.A(n_15),
.B(n_9),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_2),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_21),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OAI31xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_26),
.A3(n_19),
.B(n_23),
.Y(n_30)
);

NAND5xp2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_20),
.C(n_7),
.D(n_4),
.E(n_5),
.Y(n_31)
);

XNOR2x1_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_8),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_13),
.B1(n_12),
.B2(n_10),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_R g34 ( 
.A1(n_33),
.A2(n_31),
.B1(n_17),
.B2(n_16),
.Y(n_34)
);


endmodule