module fake_netlist_900_1734_n_53 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_53);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_53;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_41;
wire n_21;
wire n_42;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

INVx1_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_6),
.B(n_4),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_10),
.B(n_9),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_15),
.Y(n_22)
);

AND2x6_ASAP7_75t_L g23 ( 
.A(n_7),
.B(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_13),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_0),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

BUFx4_ASAP7_75t_SL g29 ( 
.A(n_17),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_22),
.A2(n_23),
.B1(n_19),
.B2(n_18),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_19),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_23),
.B1(n_19),
.B2(n_17),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_28),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_26),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_27),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_19),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_19),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI31xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_21),
.A3(n_23),
.B(n_20),
.Y(n_43)
);

AOI21xp33_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_18),
.B(n_21),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_40),
.B(n_18),
.Y(n_45)
);

NAND4xp75_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_14),
.C(n_13),
.D(n_8),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

AND2x4_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_5),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_23),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_11),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

OA22x2_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_51),
.B1(n_48),
.B2(n_49),
.Y(n_53)
);


endmodule