module fake_netlist_900_1550_n_26 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_26);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_26;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_10;

INVx3_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

BUFx10_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_8),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_9),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_15)
);

O2A1O1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_9),
.A2(n_4),
.B(n_2),
.C(n_1),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_SL g17 ( 
.A(n_11),
.B(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

AOI31xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_15),
.A3(n_19),
.B(n_14),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_20),
.B1(n_10),
.B2(n_12),
.C(n_13),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_5),
.B1(n_6),
.B2(n_24),
.Y(n_26)
);


endmodule