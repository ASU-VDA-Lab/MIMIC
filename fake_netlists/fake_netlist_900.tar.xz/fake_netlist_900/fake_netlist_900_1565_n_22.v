module fake_netlist_900_1565_n_22 (n_0, n_2, n_5, n_3, n_4, n_1, n_22);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_22;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_21;
wire n_14;
wire n_10;
wire n_8;

INVx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_SL g7 ( 
.A(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_0),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_0),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_4),
.B(n_2),
.C(n_1),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_6),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_6),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_11),
.B(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_12),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_7),
.B(n_2),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.C(n_14),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_5),
.C(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_3),
.B(n_21),
.Y(n_22)
);


endmodule