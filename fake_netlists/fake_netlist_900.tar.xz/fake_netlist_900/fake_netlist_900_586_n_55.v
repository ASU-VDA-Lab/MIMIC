module fake_netlist_900_586_n_55 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_55);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_55;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_19;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_31;
wire n_21;
wire n_42;
wire n_32;
wire n_25;
wire n_35;
wire n_41;
wire n_22;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

BUFx2_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_3),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_18),
.B(n_0),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

BUFx4f_ASAP7_75t_SL g28 ( 
.A(n_23),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

NOR2xp67_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_29),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_24),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_25),
.B1(n_19),
.B2(n_20),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_19),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_25),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_33),
.Y(n_36)
);

INVxp67_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_0),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_21),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_21),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_37),
.Y(n_41)
);

OAI32xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_38),
.A3(n_3),
.B1(n_1),
.B2(n_2),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_22),
.B1(n_21),
.B2(n_2),
.C(n_4),
.Y(n_43)
);

OAI211xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_22),
.B(n_5),
.C(n_4),
.Y(n_44)
);

NAND2xp33_ASAP7_75t_SL g45 ( 
.A(n_40),
.B(n_22),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_SL g46 ( 
.A(n_42),
.B(n_5),
.Y(n_46)
);

XNOR2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_7),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_11),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_43),
.Y(n_49)
);

OR5x1_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_17),
.C(n_16),
.D(n_11),
.E(n_13),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_16),
.Y(n_52)
);

OAI21xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_48),
.B(n_17),
.Y(n_53)
);

XNOR2xp5_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_48),
.Y(n_54)
);

OAI221xp5_ASAP7_75t_R g55 ( 
.A1(n_54),
.A2(n_14),
.B1(n_50),
.B2(n_47),
.C(n_53),
.Y(n_55)
);


endmodule