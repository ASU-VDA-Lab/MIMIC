module fake_netlist_900_1388_n_30 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_30);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_30;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_0),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_5),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B(n_14),
.C(n_12),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_13),
.B(n_0),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_13),
.B(n_4),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_12),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_17),
.B(n_10),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_18),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_21),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_21),
.Y(n_25)
);

OAI221xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_11),
.B1(n_14),
.B2(n_5),
.C(n_6),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_2),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_27),
.B1(n_9),
.B2(n_8),
.Y(n_30)
);


endmodule