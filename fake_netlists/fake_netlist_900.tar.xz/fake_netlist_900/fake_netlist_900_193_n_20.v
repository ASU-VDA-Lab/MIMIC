module fake_netlist_900_193_n_20 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_20);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_20;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_17;
wire n_18;
wire n_13;
wire n_14;

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_0),
.B(n_7),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_2),
.B(n_10),
.Y(n_13)
);

INVx4_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_6),
.B(n_5),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_14),
.B1(n_12),
.B2(n_13),
.Y(n_17)
);

NOR4xp25_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.C(n_15),
.D(n_5),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B1(n_12),
.B2(n_6),
.Y(n_19)
);

AOI321xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.A3(n_8),
.B1(n_1),
.B2(n_9),
.C(n_3),
.Y(n_20)
);


endmodule