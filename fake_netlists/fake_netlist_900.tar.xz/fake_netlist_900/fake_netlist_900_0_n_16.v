module fake_netlist_900_0_n_16 (n_0, n_2, n_5, n_3, n_4, n_1, n_16);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_16;

wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_3),
.B(n_1),
.Y(n_6)
);

AO22x2_ASAP7_75t_L g7 ( 
.A1(n_1),
.A2(n_0),
.B1(n_5),
.B2(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_0),
.Y(n_9)
);

AOI21x1_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_3),
.B(n_2),
.Y(n_10)
);

NOR2x1_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_7),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B(n_7),
.C(n_10),
.Y(n_13)
);

XNOR2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_7),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_14),
.Y(n_15)
);

OAI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_4),
.B1(n_12),
.B2(n_11),
.Y(n_16)
);


endmodule