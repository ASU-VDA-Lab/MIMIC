module fake_netlist_900_823_n_15 (n_0, n_1, n_2, n_15);

input n_0;
input n_1;
input n_2;

output n_15;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

BUFx2_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_SL g4 ( 
.A(n_2),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

BUFx4f_ASAP7_75t_SL g6 ( 
.A(n_3),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI211xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_5),
.B(n_6),
.C(n_0),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_5),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_10),
.B1(n_9),
.B2(n_2),
.Y(n_14)
);

OR2x6_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_14),
.Y(n_15)
);


endmodule