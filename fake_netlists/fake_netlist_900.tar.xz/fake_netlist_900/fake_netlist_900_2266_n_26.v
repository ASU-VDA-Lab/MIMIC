module fake_netlist_900_2266_n_26 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_26);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_26;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_22;
wire n_14;
wire n_25;

INVx2_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_10),
.B(n_6),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_7),
.B(n_9),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_5),
.Y(n_18)
);

AO31x2_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_3),
.A3(n_2),
.B(n_1),
.Y(n_19)
);

OAI22x1_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_12),
.B1(n_8),
.B2(n_4),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_16),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_19),
.C(n_17),
.D(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_13),
.Y(n_26)
);


endmodule