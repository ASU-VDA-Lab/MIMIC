module fake_netlist_900_1064_n_49 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_49);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_49;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_35;
wire n_22;
wire n_42;
wire n_41;
wire n_25;
wire n_43;
wire n_26;
wire n_36;
wire n_44;
wire n_29;
wire n_45;
wire n_48;
wire n_38;

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_0),
.A2(n_3),
.B1(n_17),
.B2(n_20),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_4),
.B(n_5),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_21),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_8),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_7),
.B(n_16),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_10),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_SL g31 ( 
.A(n_18),
.B(n_13),
.Y(n_31)
);

BUFx3_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_28),
.B(n_19),
.Y(n_33)
);

NAND2x1_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_1),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx5_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_33),
.B1(n_31),
.B2(n_22),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_36),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_30),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx2_ASAP7_75t_SL g42 ( 
.A(n_40),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_24),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_41),
.B(n_25),
.Y(n_44)
);

XOR2x2_ASAP7_75t_SL g45 ( 
.A(n_44),
.B(n_29),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_27),
.Y(n_48)
);

AOI322xp5_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_6),
.A3(n_11),
.B1(n_12),
.B2(n_14),
.C1(n_29),
.C2(n_47),
.Y(n_49)
);


endmodule