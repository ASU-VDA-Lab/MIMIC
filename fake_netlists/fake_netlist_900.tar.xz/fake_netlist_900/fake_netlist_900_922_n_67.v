module fake_netlist_900_922_n_67 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_67);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_67;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_63;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_66;
wire n_65;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_21;
wire n_25;
wire n_22;
wire n_32;
wire n_41;
wire n_42;
wire n_35;
wire n_57;
wire n_43;
wire n_62;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;
wire n_56;

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_10),
.B(n_4),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_17),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_0),
.B(n_6),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_13),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_3),
.Y(n_30)
);

INVx5_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_25),
.A2(n_16),
.B1(n_2),
.B2(n_0),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_21),
.A2(n_17),
.B1(n_16),
.B2(n_2),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_20),
.B1(n_19),
.B2(n_18),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_21),
.B(n_7),
.Y(n_37)
);

O2A1O1Ixp33_ASAP7_75t_SL g38 ( 
.A1(n_37),
.A2(n_30),
.B(n_28),
.C(n_27),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_24),
.B(n_22),
.Y(n_39)
);

AO21x2_ASAP7_75t_L g40 ( 
.A1(n_32),
.A2(n_26),
.B(n_22),
.Y(n_40)
);

OAI21x1_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_24),
.B(n_23),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_31),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_33),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_39),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

AND3x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_23),
.C(n_35),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_41),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_40),
.Y(n_50)
);

NOR2xp33_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_40),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

INVx1_ASAP7_75t_SL g53 ( 
.A(n_49),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_53),
.Y(n_54)
);

OAI21xp5_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_48),
.B(n_46),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_50),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_50),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

NOR2xp67_ASAP7_75t_L g60 ( 
.A(n_57),
.B(n_51),
.Y(n_60)
);

OAI32xp33_ASAP7_75t_L g61 ( 
.A1(n_55),
.A2(n_45),
.A3(n_43),
.B1(n_38),
.B2(n_26),
.Y(n_61)
);

OAI221xp5_ASAP7_75t_L g62 ( 
.A1(n_54),
.A2(n_31),
.B1(n_12),
.B2(n_9),
.C(n_11),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_59),
.Y(n_63)
);

OAI22xp5_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_14),
.B1(n_58),
.B2(n_62),
.Y(n_64)
);

INVx2_ASAP7_75t_SL g65 ( 
.A(n_61),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_63),
.Y(n_66)
);

AOI221x1_ASAP7_75t_L g67 ( 
.A1(n_66),
.A2(n_61),
.B1(n_65),
.B2(n_64),
.C(n_63),
.Y(n_67)
);


endmodule