module fake_netlist_900_91_n_37 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_37);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_37;

wire n_33;
wire n_34;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_SL g18 ( 
.A(n_9),
.B(n_6),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_R g19 ( 
.A(n_7),
.B(n_15),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_14),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_16),
.B1(n_6),
.B2(n_4),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_16),
.B1(n_4),
.B2(n_0),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_23),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_25),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_28),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_18),
.B(n_23),
.Y(n_31)
);

AOI211xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_24),
.B(n_21),
.C(n_20),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

OAI31xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_19),
.A3(n_2),
.B(n_1),
.Y(n_35)
);

NOR2x1p5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_3),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_36),
.B1(n_13),
.B2(n_8),
.Y(n_37)
);


endmodule