module fake_netlist_900_1262_n_24 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_24);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_24;

wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_2),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

OAI22x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_7),
.B1(n_6),
.B2(n_1),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

BUFx12f_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

NOR2x1_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NOR4xp25_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_15),
.C(n_12),
.D(n_9),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_15),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_20),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_22),
.B1(n_4),
.B2(n_3),
.Y(n_24)
);


endmodule