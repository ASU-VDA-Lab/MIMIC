module fake_netlist_900_1421_n_44 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_44);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_44;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_7),
.Y(n_24)
);

XOR2xp5_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_15),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_9),
.B(n_11),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_12),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_22),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_14),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_21),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

NOR2x1_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_25),
.Y(n_32)
);

NOR2x1_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_22),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_24),
.B(n_23),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_SL g35 ( 
.A(n_31),
.B(n_30),
.C(n_27),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_32),
.Y(n_36)
);

INVxp67_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_29),
.Y(n_38)
);

NOR2xp67_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_37),
.Y(n_39)
);

O2A1O1Ixp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_26),
.B(n_1),
.C(n_0),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

OAI322xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_4),
.A3(n_2),
.B1(n_8),
.B2(n_10),
.C1(n_5),
.C2(n_6),
.Y(n_42)
);

XOR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_42),
.Y(n_43)
);

AOI222xp33_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_17),
.B1(n_13),
.B2(n_18),
.C1(n_20),
.C2(n_19),
.Y(n_44)
);


endmodule