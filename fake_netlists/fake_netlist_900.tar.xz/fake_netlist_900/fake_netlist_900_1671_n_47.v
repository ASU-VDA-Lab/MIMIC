module fake_netlist_900_1671_n_47 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_47);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_47;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_25;
wire n_35;
wire n_42;
wire n_41;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_38;

INVx1_ASAP7_75t_SL g23 ( 
.A(n_1),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

NAND2xp33_ASAP7_75t_R g26 ( 
.A(n_5),
.B(n_3),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_17),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_2),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_25),
.A2(n_6),
.B(n_4),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_27),
.A2(n_19),
.B1(n_18),
.B2(n_16),
.Y(n_34)
);

AO31x2_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_28),
.A3(n_31),
.B(n_30),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_24),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_24),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_23),
.Y(n_38)
);

AOI222xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_36),
.B1(n_29),
.B2(n_35),
.C1(n_19),
.C2(n_16),
.Y(n_39)
);

OAI21xp33_ASAP7_75t_SL g40 ( 
.A1(n_37),
.A2(n_32),
.B(n_36),
.Y(n_40)
);

NAND2xp33_ASAP7_75t_R g41 ( 
.A(n_40),
.B(n_39),
.Y(n_41)
);

AOI211xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_29),
.B(n_26),
.C(n_7),
.Y(n_42)
);

A2O1A1Ixp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_11),
.B(n_10),
.C(n_8),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

AO22x2_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_45)
);

XNOR2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_15),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_SL g47 ( 
.A1(n_46),
.A2(n_20),
.B1(n_21),
.B2(n_45),
.Y(n_47)
);


endmodule