module fake_netlist_900_1249_n_18 (n_0, n_2, n_3, n_4, n_1, n_18);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_18;

wire n_5;
wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_17;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

OAI21xp33_ASAP7_75t_L g5 ( 
.A1(n_0),
.A2(n_4),
.B(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVxp67_ASAP7_75t_SL g8 ( 
.A(n_6),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_SL g9 ( 
.A1(n_5),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_7),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_9),
.B(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_7),
.B(n_2),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_3),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

NAND2xp33_ASAP7_75t_SL g17 ( 
.A(n_15),
.B(n_13),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B(n_16),
.Y(n_18)
);


endmodule