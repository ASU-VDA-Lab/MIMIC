module fake_netlist_655_1190_n_30 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_30);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_30;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_11;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_26;
wire n_13;

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_7),
.B(n_10),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_11),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_14),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_13),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

OAI222xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_12),
.B1(n_17),
.B2(n_16),
.C1(n_15),
.C2(n_18),
.Y(n_24)
);

OAI32xp33_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_12),
.A3(n_3),
.B1(n_0),
.B2(n_2),
.Y(n_25)
);

NAND5xp2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_23),
.C(n_25),
.D(n_3),
.E(n_5),
.Y(n_26)
);

XNOR2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_5),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_6),
.Y(n_28)
);

OAI22x1_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_6),
.B1(n_7),
.B2(n_26),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_28),
.Y(n_30)
);


endmodule