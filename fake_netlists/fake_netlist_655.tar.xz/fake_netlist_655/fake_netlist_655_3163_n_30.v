module fake_netlist_655_3163_n_30 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_30);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_30;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_26;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_8),
.Y(n_15)
);

CKINVDCx12_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_7),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_4),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_13),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_SL g22 ( 
.A(n_17),
.B(n_1),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_19),
.Y(n_23)
);

INVx2_ASAP7_75t_SL g24 ( 
.A(n_20),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_22),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_24),
.B(n_23),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_16),
.B1(n_18),
.B2(n_15),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_27),
.B(n_2),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_28),
.B(n_5),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_11),
.B1(n_9),
.B2(n_6),
.Y(n_30)
);


endmodule