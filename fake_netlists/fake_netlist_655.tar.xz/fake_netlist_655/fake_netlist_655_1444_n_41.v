module fake_netlist_655_1444_n_41 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_41);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_41;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_39;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_13;

INVx4_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_3),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_11),
.B(n_5),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_1),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_14),
.B(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_SL g22 ( 
.A(n_18),
.B(n_4),
.C(n_1),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_R g23 ( 
.A(n_20),
.B(n_17),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_19),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_12),
.B1(n_15),
.B2(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_23),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_25),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_19),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_28),
.B(n_27),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AOI21xp33_ASAP7_75t_SL g34 ( 
.A1(n_32),
.A2(n_25),
.B(n_15),
.Y(n_34)
);

OAI21xp5_ASAP7_75t_SL g35 ( 
.A1(n_31),
.A2(n_22),
.B(n_21),
.Y(n_35)
);

CKINVDCx16_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_R g37 ( 
.A1(n_34),
.A2(n_7),
.B1(n_5),
.B2(n_8),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_7),
.B1(n_9),
.B2(n_37),
.C1(n_38),
.C2(n_40),
.Y(n_41)
);


endmodule