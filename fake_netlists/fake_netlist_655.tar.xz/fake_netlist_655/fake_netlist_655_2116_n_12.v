module fake_netlist_655_2116_n_12 (n_1, n_2, n_0, n_12);

input n_1;
input n_2;
input n_0;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_11;
wire n_8;
wire n_6;
wire n_3;

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

NAND3xp33_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_2),
.C(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_2),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_6),
.Y(n_9)
);

NOR2xp67_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

XOR2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);


endmodule