module fake_netlist_655_3531_n_35 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_35);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_35;

wire n_18;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_4),
.B(n_8),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_9),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_4),
.Y(n_21)
);

CKINVDCx8_ASAP7_75t_R g22 ( 
.A(n_18),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_19),
.B(n_0),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_15),
.B(n_18),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_SL g26 ( 
.A1(n_24),
.A2(n_17),
.B1(n_23),
.B2(n_20),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_23),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI31xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.A3(n_6),
.B(n_5),
.Y(n_29)
);

NOR2x1_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_18),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_25),
.B1(n_7),
.B2(n_6),
.Y(n_31)
);

NAND2x1p5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_7),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AOI322xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_33),
.A3(n_11),
.B1(n_3),
.B2(n_1),
.C1(n_13),
.C2(n_12),
.Y(n_35)
);


endmodule