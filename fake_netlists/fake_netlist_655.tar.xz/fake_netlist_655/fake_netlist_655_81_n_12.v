module fake_netlist_655_81_n_12 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_12);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_12;

wire n_9;
wire n_7;
wire n_10;
wire n_11;
wire n_8;

AOI21xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_6),
.B(n_3),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_4),
.Y(n_8)
);

A2O1A1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.C(n_5),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B1(n_9),
.B2(n_1),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule