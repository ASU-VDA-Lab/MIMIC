module fake_netlist_655_4589_n_29 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_29);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_29;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_26;
wire n_13;

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_6),
.B(n_9),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_8),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_3),
.B(n_12),
.Y(n_17)
);

INVxp33_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

O2A1O1Ixp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_11),
.B(n_10),
.C(n_0),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_2),
.B(n_1),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_18),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_16),
.Y(n_22)
);

AOI32xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.A3(n_16),
.B1(n_17),
.B2(n_15),
.Y(n_23)
);

NAND4xp75_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_22),
.C(n_17),
.D(n_19),
.Y(n_24)
);

OAI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_17),
.B1(n_13),
.B2(n_1),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

OA22x2_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_13),
.B1(n_3),
.B2(n_2),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_5),
.B(n_4),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_28),
.B1(n_7),
.B2(n_5),
.Y(n_29)
);


endmodule