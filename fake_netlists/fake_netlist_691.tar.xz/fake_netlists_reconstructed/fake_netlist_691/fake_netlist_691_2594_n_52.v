module fake_netlist_691_2594_n_52 (n_9, n_4, n_2, n_7, n_14, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_52);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_52;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_23;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_19;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_11),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_4),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_16),
.A2(n_2),
.B(n_0),
.Y(n_25)
);

INVxp33_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_18),
.A2(n_14),
.B(n_3),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_SL g28 ( 
.A(n_15),
.B(n_5),
.C(n_3),
.Y(n_28)
);

O2A1O1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_20),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

NAND2xp33_ASAP7_75t_R g32 ( 
.A(n_31),
.B(n_19),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_22),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

CKINVDCx16_ASAP7_75t_R g35 ( 
.A(n_28),
.Y(n_35)
);

NAND2xp33_ASAP7_75t_SL g36 ( 
.A(n_26),
.B(n_16),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_30),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_34),
.B(n_18),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

OAI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_36),
.B1(n_32),
.B2(n_29),
.C(n_25),
.Y(n_41)
);

OAI22xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_35),
.B1(n_40),
.B2(n_38),
.Y(n_42)
);

OAI221xp5_ASAP7_75t_L g43 ( 
.A1(n_37),
.A2(n_36),
.B1(n_25),
.B2(n_23),
.C(n_24),
.Y(n_43)
);

AOI211xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_18),
.B(n_21),
.C(n_27),
.Y(n_44)
);

AOI211xp5_ASAP7_75t_SL g45 ( 
.A1(n_42),
.A2(n_21),
.B(n_17),
.C(n_6),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_SL g46 ( 
.A(n_43),
.B(n_7),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

AO221x1_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_9),
.B1(n_8),
.B2(n_10),
.C(n_11),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_9),
.B(n_8),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_SL g52 ( 
.A1(n_51),
.A2(n_13),
.B1(n_48),
.B2(n_50),
.Y(n_52)
);


endmodule