module fake_netlist_691_2444_n_33 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_33);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_33;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_13;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_2),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_0),
.B(n_6),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_10),
.A2(n_5),
.B(n_4),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_9),
.B(n_4),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_5),
.B(n_4),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_5),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_7),
.B(n_6),
.C(n_1),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_18),
.B(n_14),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_16),
.B(n_11),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_19),
.C(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_21),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_11),
.B1(n_15),
.B2(n_22),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_14),
.B(n_6),
.Y(n_27)
);

AOI222xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_3),
.B1(n_7),
.B2(n_8),
.C1(n_11),
.C2(n_21),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_27),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_R g33 ( 
.A1(n_32),
.A2(n_30),
.B1(n_31),
.B2(n_3),
.Y(n_33)
);


endmodule