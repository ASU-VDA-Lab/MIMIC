module fake_netlist_691_3437_n_12 (n_0, n_2, n_1, n_12);

input n_0;
input n_2;
input n_1;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_3;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

AOI21xp5_ASAP7_75t_L g4 ( 
.A1(n_1),
.A2(n_2),
.B(n_0),
.Y(n_4)
);

BUFx3_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

OR2x6_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_0),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

AOI211xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_2),
.C(n_8),
.Y(n_10)
);

OAI22x1_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B1(n_8),
.B2(n_1),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_2),
.B1(n_8),
.B2(n_9),
.C(n_5),
.Y(n_12)
);


endmodule