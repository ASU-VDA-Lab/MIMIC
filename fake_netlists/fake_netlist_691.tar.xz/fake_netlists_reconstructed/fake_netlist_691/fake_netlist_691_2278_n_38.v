module fake_netlist_691_2278_n_38 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_38);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_38;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_11;
wire n_19;
wire n_30;
wire n_25;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_3),
.B(n_0),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_3),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_7),
.B(n_1),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

OAI21xp33_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_7),
.B(n_1),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

NOR2xp67_ASAP7_75t_L g21 ( 
.A(n_11),
.B(n_2),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_SL g22 ( 
.A(n_18),
.B(n_16),
.Y(n_22)
);

OR2x6_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_12),
.Y(n_23)
);

BUFx4f_ASAP7_75t_SL g24 ( 
.A(n_18),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_10),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_20),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_20),
.Y(n_27)
);

NOR2xp67_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_21),
.Y(n_28)
);

INVxp67_ASAP7_75t_SL g29 ( 
.A(n_28),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_12),
.B1(n_19),
.B2(n_14),
.C(n_15),
.Y(n_30)
);

AOI211xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_26),
.B(n_24),
.C(n_20),
.Y(n_31)
);

AOI211xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_23),
.B(n_4),
.C(n_2),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_23),
.B(n_5),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_32),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_23),
.B1(n_9),
.B2(n_5),
.Y(n_36)
);

AO211x2_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_23),
.B(n_35),
.C(n_33),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_33),
.B1(n_35),
.B2(n_37),
.Y(n_38)
);


endmodule