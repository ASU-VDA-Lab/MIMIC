module fake_netlist_691_667_n_18 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_18);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_17;
wire n_9;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

AND2x2_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_3),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

AND2x6_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_6),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

INVxp67_ASAP7_75t_SL g13 ( 
.A(n_10),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_9),
.B2(n_11),
.C(n_1),
.Y(n_14)
);

OAI31xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.A3(n_11),
.B(n_1),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B1(n_5),
.B2(n_4),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_5),
.B1(n_4),
.B2(n_6),
.C1(n_7),
.C2(n_8),
.Y(n_18)
);


endmodule