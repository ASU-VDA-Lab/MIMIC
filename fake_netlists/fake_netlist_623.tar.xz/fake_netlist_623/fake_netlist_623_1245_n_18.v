module fake_netlist_623_1245_n_18 (n_7, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_18);

input n_7;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_18;

wire n_11;
wire n_15;
wire n_10;
wire n_16;
wire n_14;
wire n_17;
wire n_13;
wire n_12;
wire n_9;

INVx2_ASAP7_75t_SL g9 ( 
.A(n_8),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B1(n_10),
.B2(n_1),
.C(n_2),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_5),
.Y(n_16)
);

INVx3_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_7),
.B(n_6),
.Y(n_18)
);


endmodule