module fake_netlist_623_1325_n_23 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_23);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_23;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_9;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_6),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

NAND2x1p5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_1),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_4),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_9),
.Y(n_16)
);

OAI31xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.A3(n_8),
.B(n_4),
.Y(n_17)
);

NAND4xp25_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.C(n_15),
.D(n_6),
.Y(n_18)
);

AOI21xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_12),
.B(n_15),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_15),
.B(n_3),
.C(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);


endmodule