module fake_netlist_623_3050_n_27 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_27);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_27;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_3),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_12),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_14),
.B(n_0),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_15),
.B1(n_13),
.B2(n_16),
.Y(n_19)
);

OAI31xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.A3(n_18),
.B(n_1),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_15),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_20),
.B(n_15),
.C(n_2),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_15),
.B1(n_6),
.B2(n_4),
.C(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AND2x2_ASAP7_75t_SL g25 ( 
.A(n_23),
.B(n_4),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_R g26 ( 
.A1(n_25),
.A2(n_6),
.B1(n_5),
.B2(n_9),
.C(n_10),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_24),
.B1(n_25),
.B2(n_11),
.Y(n_27)
);


endmodule