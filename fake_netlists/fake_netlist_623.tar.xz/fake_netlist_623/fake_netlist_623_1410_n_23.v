module fake_netlist_623_1410_n_23 (n_7, n_9, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_23);

input n_7;
input n_9;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_23;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_19;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

AND2x2_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_0),
.B(n_4),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_SL g15 ( 
.A1(n_7),
.A2(n_2),
.B1(n_3),
.B2(n_0),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_10),
.B(n_8),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_2),
.B(n_1),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NOR2x1_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_11),
.Y(n_19)
);

AOI211xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_15),
.B(n_12),
.C(n_13),
.Y(n_20)
);

AND4x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_16),
.C(n_4),
.D(n_3),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_13),
.B1(n_6),
.B2(n_5),
.Y(n_22)
);

AO21x2_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_7),
.B(n_18),
.Y(n_23)
);


endmodule