module fake_netlist_623_1164_n_18 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_18);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_18;

wire n_11;
wire n_8;
wire n_15;
wire n_10;
wire n_16;
wire n_14;
wire n_17;
wire n_13;
wire n_12;
wire n_9;

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_1),
.B(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_11)
);

XNOR2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

OAI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_12),
.B1(n_13),
.B2(n_8),
.C(n_10),
.Y(n_15)
);

NOR2x1_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);

OAI22x1_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_6),
.B1(n_7),
.B2(n_16),
.Y(n_18)
);


endmodule