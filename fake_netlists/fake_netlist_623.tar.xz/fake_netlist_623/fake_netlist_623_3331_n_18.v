module fake_netlist_623_3331_n_18 (n_7, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_18);

input n_7;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_18;

wire n_11;
wire n_15;
wire n_10;
wire n_16;
wire n_14;
wire n_17;
wire n_13;
wire n_12;
wire n_9;

INVxp67_ASAP7_75t_SL g9 ( 
.A(n_8),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_5),
.B(n_6),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_3),
.A2(n_0),
.B1(n_6),
.B2(n_2),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_7),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

OAI21xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B(n_10),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_11),
.B2(n_14),
.C1(n_13),
.C2(n_1),
.Y(n_16)
);

OR4x1_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.C(n_4),
.D(n_2),
.Y(n_17)
);

OAI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_4),
.B1(n_5),
.B2(n_7),
.C1(n_14),
.C2(n_11),
.Y(n_18)
);


endmodule