module fake_netlist_623_3494_n_7 (n_1, n_2, n_0, n_7);

input n_1;
input n_2;
input n_0;

output n_7;

wire n_5;
wire n_6;
wire n_4;
wire n_3;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

OAI31xp33_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_0),
.A3(n_2),
.B(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

AND2x4_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_2),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);


endmodule