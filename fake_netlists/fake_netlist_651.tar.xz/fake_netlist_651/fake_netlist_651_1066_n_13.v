module fake_netlist_651_1066_n_13 (n_4, n_1, n_2, n_0, n_5, n_3, n_13);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_13;

wire n_7;
wire n_10;
wire n_6;
wire n_12;
wire n_11;
wire n_8;
wire n_9;

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx5_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_2),
.Y(n_11)
);

AO22x2_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.B1(n_6),
.B2(n_9),
.Y(n_12)
);

AO21x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_11),
.B(n_4),
.Y(n_13)
);


endmodule