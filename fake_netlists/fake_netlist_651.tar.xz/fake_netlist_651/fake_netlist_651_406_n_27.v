module fake_netlist_651_406_n_27 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_27);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_27;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_11;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_26;
wire n_9;
wire n_13;

INVx8_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_2),
.Y(n_12)
);

BUFx10_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

AOI21x1_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_5),
.B(n_4),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx3_ASAP7_75t_SL g17 ( 
.A(n_14),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_9),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_17),
.Y(n_20)
);

OAI21xp33_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_11),
.B(n_13),
.Y(n_21)
);

AOI321xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_13),
.A3(n_19),
.B1(n_7),
.B2(n_6),
.C(n_9),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_9),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_24),
.B1(n_3),
.B2(n_0),
.Y(n_27)
);


endmodule