module fake_netlist_651_689_n_22 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_22);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_22;

wire n_18;
wire n_19;
wire n_10;
wire n_15;
wire n_11;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx4_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

OAI22xp33_ASAP7_75t_L g14 ( 
.A1(n_5),
.A2(n_9),
.B1(n_2),
.B2(n_4),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_12),
.Y(n_16)
);

NOR2x1_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_15),
.C(n_14),
.Y(n_19)
);

NAND4xp75_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_11),
.C(n_7),
.D(n_10),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_7),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_3),
.B(n_1),
.Y(n_22)
);


endmodule