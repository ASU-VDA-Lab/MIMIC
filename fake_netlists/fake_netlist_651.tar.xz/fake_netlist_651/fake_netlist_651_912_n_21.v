module fake_netlist_651_912_n_21 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_21);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_4),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_7),
.B(n_6),
.C(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_16)
);

AOI32xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_10),
.A3(n_8),
.B1(n_7),
.B2(n_1),
.Y(n_17)
);

NAND4xp25_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_4),
.C(n_3),
.D(n_2),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

XNOR2x1_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_2),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_19),
.A2(n_3),
.B1(n_5),
.B2(n_20),
.Y(n_21)
);


endmodule