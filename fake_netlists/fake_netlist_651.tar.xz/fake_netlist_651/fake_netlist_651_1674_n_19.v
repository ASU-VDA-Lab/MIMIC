module fake_netlist_651_1674_n_19 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_19);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_19;

wire n_18;
wire n_11;
wire n_15;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_9),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_10),
.B(n_3),
.Y(n_12)
);

INVx4_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

OAI32xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.A3(n_12),
.B1(n_14),
.B2(n_0),
.Y(n_16)
);

OAI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_2),
.B2(n_5),
.C(n_6),
.Y(n_17)
);

NOR2x1_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_2),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_4),
.B1(n_5),
.B2(n_6),
.C1(n_7),
.C2(n_0),
.Y(n_19)
);


endmodule