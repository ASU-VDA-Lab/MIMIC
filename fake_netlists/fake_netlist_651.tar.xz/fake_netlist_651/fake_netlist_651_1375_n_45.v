module fake_netlist_651_1375_n_45 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_45);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_45;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_39;
wire n_17;
wire n_21;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_5),
.B(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

NAND2xp33_ASAP7_75t_R g20 ( 
.A(n_5),
.B(n_1),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_17),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_15),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_SL g28 ( 
.A(n_23),
.B(n_22),
.C(n_16),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_25),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_25),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_26),
.Y(n_33)
);

NOR2x1_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_28),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_33),
.B(n_27),
.Y(n_35)
);

NOR3xp33_ASAP7_75t_SL g36 ( 
.A(n_33),
.B(n_20),
.C(n_18),
.Y(n_36)
);

AOI322xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_21),
.A3(n_19),
.B1(n_33),
.B2(n_25),
.C1(n_4),
.C2(n_6),
.Y(n_37)
);

NAND2xp33_ASAP7_75t_R g38 ( 
.A(n_35),
.B(n_2),
.Y(n_38)
);

NOR3xp33_ASAP7_75t_L g39 ( 
.A(n_34),
.B(n_21),
.C(n_25),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_38),
.Y(n_40)
);

AOI211xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_7),
.B(n_8),
.C(n_3),
.Y(n_41)
);

OAI211xp5_ASAP7_75t_L g42 ( 
.A1(n_37),
.A2(n_7),
.B(n_11),
.C(n_9),
.Y(n_42)
);

NAND2xp33_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_12),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_13),
.B1(n_41),
.B2(n_43),
.Y(n_45)
);


endmodule