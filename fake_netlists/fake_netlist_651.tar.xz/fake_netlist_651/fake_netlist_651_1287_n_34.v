module fake_netlist_651_1287_n_34 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_34);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_34;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_13;

INVx1_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_10),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_2),
.B(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_13),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_12),
.B(n_1),
.Y(n_17)
);

BUFx4f_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_SL g19 ( 
.A1(n_16),
.A2(n_13),
.B1(n_12),
.B2(n_15),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_12),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_20),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_17),
.B1(n_12),
.B2(n_18),
.C(n_15),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_11),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_11),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_4),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

A2O1A1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_14),
.B(n_5),
.C(n_4),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_27),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

AND3x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_26),
.C(n_6),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_3),
.A3(n_7),
.B1(n_8),
.B2(n_9),
.C1(n_30),
.C2(n_32),
.Y(n_34)
);


endmodule