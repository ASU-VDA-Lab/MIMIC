module fake_netlist_651_475_n_12 (n_3, n_1, n_2, n_0, n_12);

input n_3;
input n_1;
input n_2;
input n_0;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_11;
wire n_8;
wire n_6;

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_3),
.Y(n_4)
);

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_1),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);

BUFx8_ASAP7_75t_SL g7 ( 
.A(n_4),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NAND5xp2_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_7),
.C(n_6),
.D(n_0),
.E(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_10),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_7),
.B2(n_6),
.Y(n_12)
);


endmodule