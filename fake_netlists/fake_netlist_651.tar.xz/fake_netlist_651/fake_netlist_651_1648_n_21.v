module fake_netlist_651_1648_n_21 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_21);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_4),
.A2(n_2),
.B1(n_7),
.B2(n_1),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_9),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_3),
.B(n_7),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_6),
.B(n_4),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_12),
.B(n_14),
.C(n_13),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.C(n_6),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_8),
.B(n_5),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_11),
.Y(n_21)
);


endmodule