module fake_netlist_702_2338_n_30 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_30);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_30;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_29;
wire n_28;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_8),
.B(n_12),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_4),
.Y(n_17)
);

AND2x6_ASAP7_75t_L g18 ( 
.A(n_0),
.B(n_5),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_7),
.B1(n_2),
.B2(n_1),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_15),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_22),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_21),
.B1(n_17),
.B2(n_18),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_7),
.Y(n_27)
);

OR2x6_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_18),
.Y(n_28)
);

OAI22x1_ASAP7_75t_SL g29 ( 
.A1(n_26),
.A2(n_16),
.B1(n_18),
.B2(n_9),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_28),
.B1(n_11),
.B2(n_10),
.Y(n_30)
);


endmodule