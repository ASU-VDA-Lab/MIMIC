module fake_netlist_702_2876_n_29 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_29);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_29;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_28;
wire n_25;
wire n_19;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_13),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_14),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_17),
.B(n_10),
.C(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AO31x2_ASAP7_75t_L g23 ( 
.A1(n_19),
.A2(n_17),
.A3(n_10),
.B(n_9),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND4xp25_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_20),
.C(n_23),
.D(n_15),
.Y(n_25)
);

OAI211xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_11),
.B(n_8),
.Y(n_29)
);


endmodule