module fake_netlist_702_1903_n_39 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_39);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_39;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_22;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_4),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_16),
.A2(n_0),
.B1(n_10),
.B2(n_1),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_11),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

NAND2xp33_ASAP7_75t_R g26 ( 
.A(n_8),
.B(n_12),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_7),
.Y(n_27)
);

OAI21xp33_ASAP7_75t_SL g28 ( 
.A1(n_23),
.A2(n_16),
.B(n_15),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

O2A1O1Ixp5_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_15),
.B(n_3),
.C(n_2),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_20),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_27),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_22),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

OAI31xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_34),
.A3(n_21),
.B(n_30),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_26),
.B1(n_24),
.B2(n_5),
.Y(n_36)
);

XOR2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_9),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_39)
);


endmodule