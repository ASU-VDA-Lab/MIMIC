module fake_netlist_702_2139_n_44 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_44);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_44;

wire n_24;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

INVx1_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_20),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_12),
.B(n_16),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

BUFx10_ASAP7_75t_L g28 ( 
.A(n_10),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_7),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

A2O1A1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_29),
.A2(n_23),
.B(n_3),
.C(n_1),
.Y(n_34)
);

AO31x2_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_27),
.A3(n_28),
.B(n_30),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_31),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_33),
.Y(n_37)
);

NAND2x1p5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_33),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_38),
.Y(n_39)
);

OAI322xp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_25),
.A3(n_23),
.B1(n_35),
.B2(n_26),
.C1(n_4),
.C2(n_5),
.Y(n_40)
);

OAI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_40),
.B1(n_11),
.B2(n_6),
.C(n_8),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_41),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_17),
.B1(n_15),
.B2(n_14),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_43),
.A2(n_21),
.B1(n_19),
.B2(n_18),
.Y(n_44)
);


endmodule