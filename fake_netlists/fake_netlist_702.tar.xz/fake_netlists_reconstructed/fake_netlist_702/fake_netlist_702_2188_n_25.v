module fake_netlist_702_2188_n_25 (n_4, n_2, n_3, n_1, n_5, n_0, n_25);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_25;

wire n_24;
wire n_21;
wire n_17;
wire n_6;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_7;
wire n_23;
wire n_13;
wire n_8;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

BUFx4f_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx4_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

AO21x1_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_1),
.B(n_2),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_1),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_7),
.A2(n_4),
.B(n_3),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_3),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

AO31x2_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_11),
.A3(n_14),
.B(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_13),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_12),
.B1(n_13),
.B2(n_15),
.C(n_16),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_20),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_18),
.C(n_6),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_14),
.B(n_18),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_22),
.B(n_16),
.Y(n_25)
);


endmodule