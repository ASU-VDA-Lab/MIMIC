module fake_netlist_702_1697_n_34 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_34);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_34;

wire n_24;
wire n_21;
wire n_27;
wire n_22;
wire n_18;
wire n_20;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

AND3x2_ASAP7_75t_L g19 ( 
.A(n_8),
.B(n_6),
.C(n_7),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_10),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_14),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_14),
.Y(n_25)
);

AO22x1_ASAP7_75t_L g26 ( 
.A1(n_21),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_22),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_R g28 ( 
.A(n_26),
.B(n_19),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_24),
.B(n_28),
.C(n_18),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_31),
.Y(n_32)
);

OAI22x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_13),
.B1(n_12),
.B2(n_9),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_34)
);


endmodule