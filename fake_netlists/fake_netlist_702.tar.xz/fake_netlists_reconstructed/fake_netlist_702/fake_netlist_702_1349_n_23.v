module fake_netlist_702_1349_n_23 (n_4, n_2, n_3, n_1, n_5, n_0, n_23);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_23;

wire n_21;
wire n_17;
wire n_6;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_7;
wire n_13;
wire n_8;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_7),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_6),
.B(n_0),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_1),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_SL g15 ( 
.A(n_13),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_11),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_14),
.C(n_11),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_12),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND4xp75_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_16),
.C(n_10),
.D(n_4),
.Y(n_20)
);

OAI31xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_12),
.A3(n_3),
.B(n_2),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_12),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_22),
.Y(n_23)
);


endmodule