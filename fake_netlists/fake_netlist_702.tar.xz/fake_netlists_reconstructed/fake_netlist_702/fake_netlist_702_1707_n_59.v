module fake_netlist_702_1707_n_59 (n_2, n_21, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_59);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_59;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_58;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_23;
wire n_41;
wire n_46;
wire n_29;
wire n_56;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_15),
.B(n_3),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_4),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_3),
.B(n_20),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_5),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_2),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_26),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_22),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_31),
.Y(n_34)
);

OAI22xp33_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_27),
.B1(n_24),
.B2(n_23),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_31),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_32),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_32),
.Y(n_38)
);

AOI221x1_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_35),
.B1(n_27),
.B2(n_23),
.C(n_24),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_36),
.Y(n_40)
);

NAND3xp33_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_33),
.C(n_28),
.Y(n_41)
);

OAI211xp5_ASAP7_75t_SL g42 ( 
.A1(n_38),
.A2(n_26),
.B(n_35),
.C(n_30),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

OAI221xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_25),
.B1(n_26),
.B2(n_30),
.C(n_29),
.Y(n_44)
);

OAI31xp33_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_40),
.A3(n_43),
.B(n_29),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

O2A1O1Ixp5_ASAP7_75t_L g47 ( 
.A1(n_41),
.A2(n_29),
.B(n_30),
.C(n_6),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_40),
.B(n_29),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_44),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

NOR3xp33_ASAP7_75t_SL g51 ( 
.A(n_45),
.B(n_12),
.C(n_11),
.Y(n_51)
);

AOI221xp5_ASAP7_75t_L g52 ( 
.A1(n_45),
.A2(n_14),
.B1(n_13),
.B2(n_15),
.C(n_16),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_L g53 ( 
.A(n_47),
.B(n_16),
.C(n_14),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

OAI22xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_46),
.B1(n_19),
.B2(n_17),
.Y(n_55)
);

OAI22xp5_ASAP7_75t_L g56 ( 
.A1(n_49),
.A2(n_1),
.B1(n_21),
.B2(n_52),
.Y(n_56)
);

HB1xp67_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

AOI22xp33_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_56),
.B1(n_57),
.B2(n_55),
.Y(n_59)
);


endmodule