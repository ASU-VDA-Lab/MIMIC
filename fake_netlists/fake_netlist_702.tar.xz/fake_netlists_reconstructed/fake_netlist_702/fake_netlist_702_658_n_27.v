module fake_netlist_702_658_n_27 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_25;
wire n_19;
wire n_14;

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_13),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_1),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_3),
.B(n_12),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_4),
.B(n_0),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_SL g20 ( 
.A1(n_17),
.A2(n_5),
.B(n_4),
.C(n_0),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_14),
.B1(n_16),
.B2(n_15),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI322xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.A3(n_18),
.B1(n_20),
.B2(n_6),
.C1(n_5),
.C2(n_7),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.C(n_6),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_11),
.B1(n_9),
.B2(n_2),
.Y(n_27)
);


endmodule