module fake_netlist_702_1309_n_29 (n_4, n_2, n_3, n_1, n_5, n_0, n_29);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_29;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_6;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_7;
wire n_23;
wire n_13;
wire n_8;
wire n_28;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

INVx3_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

BUFx6f_ASAP7_75t_SL g8 ( 
.A(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_3),
.Y(n_9)
);

NAND2xp33_ASAP7_75t_SL g10 ( 
.A(n_1),
.B(n_3),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_0),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_0),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_6),
.A2(n_4),
.B(n_1),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_5),
.B(n_7),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_7),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_14),
.Y(n_16)
);

NAND4xp25_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_10),
.C(n_8),
.D(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_20),
.Y(n_23)
);

NOR3x1_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_13),
.C(n_10),
.Y(n_24)
);

OAI211xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_8),
.B(n_13),
.C(n_22),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_21),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_8),
.B1(n_25),
.B2(n_24),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

OR2x6_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_27),
.Y(n_29)
);


endmodule