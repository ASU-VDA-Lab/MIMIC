module fake_netlist_702_2527_n_11 (n_4, n_2, n_3, n_1, n_0, n_11);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_11;

wire n_9;
wire n_7;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_R g6 ( 
.A(n_0),
.B(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_2),
.Y(n_8)
);

OAI31xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.A3(n_6),
.B(n_3),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

XOR2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);


endmodule