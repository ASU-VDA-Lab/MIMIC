module fake_netlist_702_2680_n_6 (n_3, n_0, n_2, n_1, n_6);

input n_3;
input n_0;
input n_2;
input n_1;

output n_6;

wire n_4;
wire n_5;

BUFx3_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

AOI221xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B1(n_3),
.B2(n_4),
.C(n_0),
.Y(n_6)
);


endmodule