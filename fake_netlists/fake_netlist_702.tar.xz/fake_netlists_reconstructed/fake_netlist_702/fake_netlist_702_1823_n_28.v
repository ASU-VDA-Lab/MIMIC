module fake_netlist_702_1823_n_28 (n_9, n_4, n_2, n_7, n_14, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_28);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_28;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_25;
wire n_19;

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_9),
.B(n_12),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_4),
.Y(n_19)
);

O2A1O1Ixp5_ASAP7_75t_SL g20 ( 
.A1(n_17),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_15),
.B1(n_18),
.B2(n_16),
.Y(n_24)
);

NAND4xp25_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_20),
.C(n_7),
.D(n_6),
.Y(n_25)
);

INVx3_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_11),
.B1(n_10),
.B2(n_3),
.Y(n_28)
);


endmodule