module fake_netlist_702_1772_n_49 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_49);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_49;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_39;

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_12),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_5),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_3),
.B(n_17),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_2),
.B(n_0),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_23),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_4),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_31),
.B1(n_26),
.B2(n_25),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_32),
.Y(n_36)
);

INVx5_ASAP7_75t_SL g37 ( 
.A(n_36),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_28),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_29),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

NOR3xp33_ASAP7_75t_SL g41 ( 
.A(n_40),
.B(n_30),
.C(n_7),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_8),
.Y(n_42)
);

OAI21xp33_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_10),
.B(n_9),
.Y(n_43)
);

CKINVDCx16_ASAP7_75t_R g44 ( 
.A(n_41),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_SL g45 ( 
.A(n_44),
.B(n_11),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_13),
.Y(n_46)
);

NOR2x1_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_14),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_18),
.B1(n_16),
.B2(n_15),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_47),
.A2(n_20),
.B1(n_22),
.B2(n_48),
.Y(n_49)
);


endmodule