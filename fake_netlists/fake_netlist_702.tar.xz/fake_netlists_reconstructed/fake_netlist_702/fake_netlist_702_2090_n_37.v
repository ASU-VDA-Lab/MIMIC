module fake_netlist_702_2090_n_37 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_37);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_37;

wire n_24;
wire n_21;
wire n_27;
wire n_22;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_18),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_11),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_21),
.B(n_16),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_26),
.B(n_20),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_22),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_25),
.Y(n_30)
);

AOI31xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_24),
.A3(n_28),
.B(n_23),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_21),
.B1(n_18),
.B2(n_16),
.C(n_17),
.Y(n_32)
);

XNOR2x1_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_17),
.Y(n_33)
);

OAI211xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_19),
.B(n_2),
.C(n_1),
.Y(n_34)
);

AOI22x1_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_19),
.B1(n_6),
.B2(n_3),
.Y(n_35)
);

AOI22x1_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_36)
);

AOI222xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_10),
.B1(n_12),
.B2(n_13),
.C1(n_14),
.C2(n_35),
.Y(n_37)
);


endmodule