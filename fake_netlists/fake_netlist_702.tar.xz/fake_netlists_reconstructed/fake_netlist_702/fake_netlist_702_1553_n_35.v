module fake_netlist_702_1553_n_35 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_35);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_35;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_34;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_7),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_2),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_9),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_21),
.A2(n_1),
.B(n_0),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_6),
.B(n_3),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_24),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_24),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_29),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_26),
.B(n_17),
.Y(n_31)
);

OA211x2_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_13),
.B(n_20),
.C(n_18),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

OAI22xp33_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_22),
.B1(n_13),
.B2(n_8),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_16),
.B1(n_14),
.B2(n_12),
.Y(n_35)
);


endmodule