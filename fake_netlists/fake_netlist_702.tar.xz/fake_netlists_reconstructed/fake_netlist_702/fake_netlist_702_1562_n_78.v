module fake_netlist_702_1562_n_78 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_78);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_78;

wire n_61;
wire n_27;
wire n_40;
wire n_66;
wire n_47;
wire n_35;
wire n_52;
wire n_71;
wire n_60;
wire n_33;
wire n_30;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_45;
wire n_64;
wire n_58;
wire n_62;
wire n_76;
wire n_63;
wire n_70;
wire n_69;
wire n_53;
wire n_74;
wire n_28;
wire n_75;
wire n_55;
wire n_54;
wire n_44;
wire n_38;
wire n_42;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_68;
wire n_32;
wire n_77;
wire n_46;
wire n_31;
wire n_73;
wire n_41;
wire n_29;
wire n_56;
wire n_72;
wire n_65;
wire n_36;
wire n_49;
wire n_57;

INVx2_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_3),
.B(n_22),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_10),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_0),
.B(n_23),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_6),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_12),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_25),
.Y(n_35)
);

AND2x6_ASAP7_75t_L g36 ( 
.A(n_15),
.B(n_14),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_24),
.B(n_2),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_24),
.B(n_13),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_16),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_16),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_28),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_26),
.A2(n_21),
.B1(n_20),
.B2(n_17),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_26),
.B(n_20),
.C(n_17),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_30),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_32),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

OAI21x1_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_34),
.B(n_33),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_40),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_43),
.A2(n_38),
.B1(n_31),
.B2(n_29),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_46),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_46),
.B(n_44),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_39),
.B(n_37),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

OR2x2_ASAP7_75t_L g57 ( 
.A(n_50),
.B(n_39),
.Y(n_57)
);

OR2x2_ASAP7_75t_L g58 ( 
.A(n_57),
.B(n_41),
.Y(n_58)
);

AOI21xp5_ASAP7_75t_L g59 ( 
.A1(n_55),
.A2(n_52),
.B(n_29),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_54),
.Y(n_60)
);

AOI31xp33_ASAP7_75t_L g61 ( 
.A1(n_56),
.A2(n_42),
.A3(n_37),
.B(n_38),
.Y(n_61)
);

NAND3x1_ASAP7_75t_L g62 ( 
.A(n_60),
.B(n_43),
.C(n_48),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_58),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_61),
.Y(n_64)
);

AOI22xp5_ASAP7_75t_L g65 ( 
.A1(n_59),
.A2(n_31),
.B1(n_41),
.B2(n_27),
.Y(n_65)
);

CKINVDCx16_ASAP7_75t_R g66 ( 
.A(n_58),
.Y(n_66)
);

NOR3x1_ASAP7_75t_L g67 ( 
.A(n_64),
.B(n_25),
.C(n_36),
.Y(n_67)
);

INVx4_ASAP7_75t_L g68 ( 
.A(n_66),
.Y(n_68)
);

NOR3x1_ASAP7_75t_L g69 ( 
.A(n_63),
.B(n_36),
.C(n_33),
.Y(n_69)
);

AND3x4_ASAP7_75t_L g70 ( 
.A(n_62),
.B(n_34),
.C(n_36),
.Y(n_70)
);

AOI221xp5_ASAP7_75t_L g71 ( 
.A1(n_65),
.A2(n_36),
.B1(n_5),
.B2(n_1),
.C(n_4),
.Y(n_71)
);

NAND2xp5_ASAP7_75t_SL g72 ( 
.A(n_68),
.B(n_7),
.Y(n_72)
);

BUFx6f_ASAP7_75t_L g73 ( 
.A(n_70),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_69),
.Y(n_74)
);

OR3x1_ASAP7_75t_L g75 ( 
.A(n_67),
.B(n_18),
.C(n_8),
.Y(n_75)
);

HB1xp67_ASAP7_75t_L g76 ( 
.A(n_74),
.Y(n_76)
);

AOI21xp5_ASAP7_75t_L g77 ( 
.A1(n_72),
.A2(n_71),
.B(n_73),
.Y(n_77)
);

OA22x2_ASAP7_75t_L g78 ( 
.A1(n_76),
.A2(n_73),
.B1(n_75),
.B2(n_77),
.Y(n_78)
);


endmodule