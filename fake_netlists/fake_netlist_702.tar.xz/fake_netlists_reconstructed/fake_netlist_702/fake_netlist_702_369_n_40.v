module fake_netlist_702_369_n_40 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_40);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_40;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_22;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

INVx1_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_4),
.B(n_12),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_17),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

NOR2xp67_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_2),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_20),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_6),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_23),
.A2(n_17),
.B1(n_1),
.B2(n_0),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_24),
.B(n_3),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_5),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_SL g31 ( 
.A(n_28),
.B(n_23),
.C(n_29),
.Y(n_31)
);

AO31x2_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_25),
.A3(n_22),
.B(n_26),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_27),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.B1(n_8),
.B2(n_7),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_9),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_35),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_38),
.B1(n_13),
.B2(n_11),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_18),
.B1(n_16),
.B2(n_14),
.Y(n_40)
);


endmodule