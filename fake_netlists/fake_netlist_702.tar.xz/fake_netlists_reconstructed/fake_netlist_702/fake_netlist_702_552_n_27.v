module fake_netlist_702_552_n_27 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_27);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_12;
wire n_8;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

NAND2xp33_ASAP7_75t_R g9 ( 
.A(n_5),
.B(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

INVx6_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_6),
.B1(n_4),
.B2(n_1),
.Y(n_13)
);

AOI21x1_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_7),
.B(n_6),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_7),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_11),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_16),
.B(n_13),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_18),
.B(n_19),
.C(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

INVx2_ASAP7_75t_SL g24 ( 
.A(n_22),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_19),
.B1(n_10),
.B2(n_9),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B1(n_25),
.B2(n_3),
.Y(n_27)
);


endmodule