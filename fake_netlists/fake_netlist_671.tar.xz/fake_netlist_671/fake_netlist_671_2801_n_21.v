module fake_netlist_671_2801_n_21 (n_3, n_1, n_2, n_0, n_21);

input n_3;
input n_1;
input n_2;
input n_0;

output n_21;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_4;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx2_ASAP7_75t_SL g4 ( 
.A(n_2),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_4),
.A2(n_3),
.B(n_5),
.Y(n_10)
);

AOI21xp33_ASAP7_75t_L g11 ( 
.A1(n_5),
.A2(n_4),
.B(n_6),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_5),
.Y(n_12)
);

AO21x2_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_5),
.B(n_3),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_11),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_12),
.B1(n_13),
.B2(n_8),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI211xp5_ASAP7_75t_SL g18 ( 
.A1(n_15),
.A2(n_11),
.B(n_9),
.C(n_8),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.B(n_13),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_12),
.B1(n_19),
.B2(n_17),
.Y(n_21)
);


endmodule