module fake_netlist_671_1453_n_43 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_43);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_43;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_17;
wire n_39;
wire n_21;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

INVx1_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_9),
.B(n_2),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_13),
.B(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_7),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_1),
.B(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_15),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_21),
.Y(n_26)
);

INVx2_ASAP7_75t_SL g27 ( 
.A(n_21),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_17),
.B(n_0),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_21),
.B(n_1),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_22),
.B(n_2),
.Y(n_30)
);

AOI22x1_ASAP7_75t_L g31 ( 
.A1(n_20),
.A2(n_14),
.B1(n_8),
.B2(n_6),
.Y(n_31)
);

NAND2xp33_ASAP7_75t_SL g32 ( 
.A(n_30),
.B(n_18),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NAND2x1p5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_19),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_26),
.B(n_23),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_35),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_28),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_34),
.B1(n_29),
.B2(n_31),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_34),
.B1(n_27),
.B2(n_24),
.C(n_25),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_16),
.B1(n_3),
.B2(n_39),
.Y(n_43)
);


endmodule