module fake_netlist_671_2570_n_38 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_38);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_38;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_13;

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_SL g20 ( 
.A1(n_11),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_20)
);

O2A1O1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_13),
.A2(n_4),
.B(n_2),
.C(n_0),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_12),
.B(n_14),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_12),
.B(n_4),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_18),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_23),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_24),
.Y(n_30)
);

OAI21xp33_ASAP7_75t_SL g31 ( 
.A1(n_29),
.A2(n_22),
.B(n_27),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_28),
.Y(n_32)
);

NAND5xp2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_21),
.C(n_28),
.D(n_24),
.E(n_20),
.Y(n_33)
);

AOI31xp33_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_30),
.A3(n_20),
.B(n_16),
.Y(n_34)
);

NAND2xp33_ASAP7_75t_SL g35 ( 
.A(n_34),
.B(n_17),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_SL g38 ( 
.A1(n_37),
.A2(n_35),
.B1(n_8),
.B2(n_6),
.Y(n_38)
);


endmodule