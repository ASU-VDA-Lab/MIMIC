module fake_netlist_671_1058_n_66 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_66);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_66;

wire n_18;
wire n_36;
wire n_59;
wire n_19;
wire n_62;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_64;
wire n_25;
wire n_40;
wire n_57;
wire n_24;
wire n_35;
wire n_54;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_60;
wire n_22;
wire n_39;
wire n_17;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_63;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_65;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;
wire n_61;

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_13),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_16),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_1),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx3_ASAP7_75t_SL g29 ( 
.A(n_17),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_19),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_25),
.B(n_0),
.Y(n_31)
);

INVx5_ASAP7_75t_L g32 ( 
.A(n_25),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_22),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

AO21x2_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_26),
.B(n_27),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_28),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_35),
.A2(n_27),
.B1(n_18),
.B2(n_20),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_35),
.A2(n_18),
.B(n_21),
.Y(n_41)
);

NOR2x1_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_34),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_34),
.Y(n_43)
);

OAI221xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_30),
.B1(n_33),
.B2(n_24),
.C(n_34),
.Y(n_44)
);

OAI221xp5_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_29),
.B1(n_32),
.B2(n_23),
.C(n_4),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_29),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_38),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_29),
.Y(n_50)
);

XNOR2xp5_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_36),
.Y(n_51)
);

OAI22xp33_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_32),
.B1(n_39),
.B2(n_37),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_46),
.Y(n_53)
);

OAI221xp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_49),
.B1(n_46),
.B2(n_32),
.C(n_23),
.Y(n_54)
);

AOI221xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_36),
.B1(n_32),
.B2(n_23),
.C(n_5),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_32),
.Y(n_56)
);

AOI221xp5_ASAP7_75t_L g57 ( 
.A1(n_51),
.A2(n_32),
.B1(n_23),
.B2(n_5),
.C(n_15),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_R g58 ( 
.A(n_52),
.B(n_15),
.Y(n_58)
);

AOI221xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_55),
.B1(n_54),
.B2(n_58),
.C(n_56),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_56),
.Y(n_60)
);

AOI211xp5_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_23),
.B(n_16),
.C(n_6),
.Y(n_61)
);

CKINVDCx5p33_ASAP7_75t_R g62 ( 
.A(n_58),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_60),
.B(n_7),
.Y(n_63)
);

OAI221xp5_ASAP7_75t_L g64 ( 
.A1(n_59),
.A2(n_9),
.B1(n_8),
.B2(n_11),
.C(n_12),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_61),
.Y(n_65)
);

AOI22xp5_ASAP7_75t_SL g66 ( 
.A1(n_65),
.A2(n_62),
.B1(n_63),
.B2(n_64),
.Y(n_66)
);


endmodule