module fake_netlist_671_2449_n_16 (n_4, n_1, n_2, n_0, n_3, n_16);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_16;

wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_12;
wire n_10;
wire n_11;
wire n_8;
wire n_15;
wire n_6;
wire n_9;

AND2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

BUFx3_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

NAND2x1p5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_0),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_2),
.Y(n_9)
);

OA21x2_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_5),
.Y(n_10)
);

INVx5_ASAP7_75t_SL g11 ( 
.A(n_8),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_6),
.B1(n_7),
.B2(n_5),
.Y(n_13)
);

AOI221x1_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_5),
.B1(n_10),
.B2(n_6),
.C(n_11),
.Y(n_14)
);

OA22x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B1(n_1),
.B2(n_2),
.Y(n_15)
);

OAI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_3),
.B1(n_4),
.B2(n_8),
.C1(n_13),
.C2(n_7),
.Y(n_16)
);


endmodule