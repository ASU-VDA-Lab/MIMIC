module fake_netlist_671_501_n_57 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_57);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_57;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_16;
wire n_22;
wire n_17;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_13),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_12),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_16),
.A2(n_9),
.B(n_8),
.Y(n_26)
);

A2O1A1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_21),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_19),
.B(n_1),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_3),
.Y(n_29)
);

AND2x2_ASAP7_75t_SL g30 ( 
.A(n_21),
.B(n_4),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_17),
.A2(n_14),
.B(n_5),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_SL g32 ( 
.A(n_22),
.B(n_7),
.C(n_5),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_19),
.Y(n_33)
);

INVx8_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_23),
.Y(n_35)
);

BUFx3_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_29),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_R g38 ( 
.A(n_32),
.B(n_18),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_27),
.Y(n_39)
);

NOR2xp67_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_31),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_34),
.B(n_21),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_34),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_38),
.Y(n_43)
);

NOR4xp25_ASAP7_75t_SL g44 ( 
.A(n_40),
.B(n_28),
.C(n_25),
.D(n_24),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_26),
.B(n_24),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_41),
.Y(n_46)
);

OAI211xp5_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_25),
.B(n_19),
.C(n_42),
.Y(n_47)
);

AO221x1_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_19),
.B1(n_33),
.B2(n_10),
.C(n_11),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_19),
.B1(n_34),
.B2(n_36),
.C(n_11),
.Y(n_49)
);

BUFx2_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

CKINVDCx16_ASAP7_75t_R g51 ( 
.A(n_46),
.Y(n_51)
);

CKINVDCx16_ASAP7_75t_R g52 ( 
.A(n_48),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_47),
.Y(n_53)
);

BUFx2_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);

OAI22xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_19),
.B1(n_34),
.B2(n_36),
.Y(n_55)
);

INVx2_ASAP7_75t_SL g56 ( 
.A(n_53),
.Y(n_56)
);

AOI222xp33_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_34),
.B1(n_50),
.B2(n_52),
.C1(n_56),
.C2(n_55),
.Y(n_57)
);


endmodule