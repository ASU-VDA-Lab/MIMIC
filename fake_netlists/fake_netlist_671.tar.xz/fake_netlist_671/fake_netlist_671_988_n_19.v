module fake_netlist_671_988_n_19 (n_3, n_1, n_2, n_0, n_19);

input n_3;
input n_1;
input n_2;
input n_0;

output n_19;

wire n_18;
wire n_5;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_16;
wire n_12;
wire n_4;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_1),
.B(n_2),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

INVxp67_ASAP7_75t_SL g9 ( 
.A(n_7),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

OAI21xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_5),
.B(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_10),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.C(n_3),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_0),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_0),
.B1(n_3),
.B2(n_12),
.C(n_14),
.Y(n_16)
);

AOI211xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_3),
.B(n_12),
.C(n_10),
.Y(n_17)
);

XNOR2x1_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);


endmodule