module fake_netlist_671_2246_n_15 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_15);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_15;

wire n_9;
wire n_7;
wire n_14;
wire n_13;
wire n_10;
wire n_12;
wire n_11;
wire n_8;

AND2x4_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_6),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_1),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_1),
.Y(n_12)
);

AOI321xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_8),
.A3(n_7),
.B1(n_6),
.B2(n_5),
.C(n_4),
.Y(n_13)
);

XOR2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_4),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_8),
.B(n_7),
.Y(n_15)
);


endmodule