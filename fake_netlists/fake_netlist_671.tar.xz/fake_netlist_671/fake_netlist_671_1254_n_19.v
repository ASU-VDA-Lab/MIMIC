module fake_netlist_671_1254_n_19 (n_4, n_1, n_2, n_0, n_5, n_3, n_19);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_19;

wire n_18;
wire n_10;
wire n_15;
wire n_11;
wire n_7;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

AND2x6_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_3),
.Y(n_6)
);

NAND3x1_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.C(n_2),
.Y(n_7)
);

INVx4_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_10)
);

OAI21xp33_ASAP7_75t_SL g11 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_5),
.B(n_4),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

NAND2xp33_ASAP7_75t_SL g16 ( 
.A(n_14),
.B(n_10),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B1(n_8),
.B2(n_6),
.C1(n_7),
.C2(n_2),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_11),
.B1(n_15),
.B2(n_7),
.C(n_6),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_6),
.B1(n_17),
.B2(n_16),
.Y(n_19)
);


endmodule