module fake_netlist_671_703_n_53 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_53);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_53;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_18),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_22),
.B(n_23),
.Y(n_26)
);

NOR2xp67_ASAP7_75t_L g27 ( 
.A(n_2),
.B(n_6),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_14),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_19),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_12),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_10),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_7),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_11),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_17),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_28),
.B(n_0),
.Y(n_35)
);

INVx5_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_31),
.B(n_32),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_34),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_SL g40 ( 
.A(n_35),
.B(n_29),
.C(n_26),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_38),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_36),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_36),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_33),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_24),
.Y(n_46)
);

INVx1_ASAP7_75t_SL g47 ( 
.A(n_46),
.Y(n_47)
);

INVx2_ASAP7_75t_SL g48 ( 
.A(n_45),
.Y(n_48)
);

OAI322xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_25),
.A3(n_24),
.B1(n_4),
.B2(n_5),
.C1(n_1),
.C2(n_3),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_8),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_50),
.Y(n_51)
);

BUFx2_ASAP7_75t_SL g52 ( 
.A(n_49),
.Y(n_52)
);

AOI322xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_9),
.A3(n_13),
.B1(n_15),
.B2(n_16),
.C1(n_21),
.C2(n_52),
.Y(n_53)
);


endmodule