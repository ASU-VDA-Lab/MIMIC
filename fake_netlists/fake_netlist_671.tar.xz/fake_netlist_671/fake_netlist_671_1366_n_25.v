module fake_netlist_671_1366_n_25 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_25);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_25;

wire n_18;
wire n_19;
wire n_10;
wire n_24;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

CKINVDCx16_ASAP7_75t_R g8 ( 
.A(n_0),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_1),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_1),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_6),
.B(n_1),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_6),
.B1(n_2),
.B2(n_0),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_6),
.B(n_2),
.Y(n_13)
);

INVxp67_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_8),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_13),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B1(n_8),
.B2(n_7),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_16),
.B(n_3),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OAI22x1_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_5),
.B1(n_21),
.B2(n_24),
.Y(n_25)
);


endmodule