module fake_netlist_671_1070_n_394 (n_18, n_36, n_19, n_34, n_1, n_38, n_0, n_5, n_10, n_25, n_40, n_24, n_35, n_28, n_11, n_15, n_7, n_30, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_39, n_14, n_21, n_27, n_42, n_2, n_29, n_31, n_41, n_26, n_33, n_9, n_32, n_37, n_13, n_43, n_8, n_6, n_394);

input n_18;
input n_36;
input n_19;
input n_34;
input n_1;
input n_38;
input n_0;
input n_5;
input n_10;
input n_25;
input n_40;
input n_24;
input n_35;
input n_28;
input n_11;
input n_15;
input n_7;
input n_30;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_39;
input n_14;
input n_21;
input n_27;
input n_42;
input n_2;
input n_29;
input n_31;
input n_41;
input n_26;
input n_33;
input n_9;
input n_32;
input n_37;
input n_13;
input n_43;
input n_8;
input n_6;

output n_394;

wire n_326;
wire n_385;
wire n_101;
wire n_313;
wire n_209;
wire n_321;
wire n_245;
wire n_164;
wire n_118;
wire n_189;
wire n_306;
wire n_275;
wire n_173;
wire n_183;
wire n_260;
wire n_63;
wire n_190;
wire n_362;
wire n_187;
wire n_238;
wire n_71;
wire n_201;
wire n_294;
wire n_331;
wire n_217;
wire n_300;
wire n_392;
wire n_49;
wire n_241;
wire n_345;
wire n_161;
wire n_234;
wire n_259;
wire n_312;
wire n_180;
wire n_142;
wire n_232;
wire n_379;
wire n_143;
wire n_122;
wire n_323;
wire n_250;
wire n_227;
wire n_365;
wire n_85;
wire n_176;
wire n_160;
wire n_156;
wire n_317;
wire n_174;
wire n_349;
wire n_389;
wire n_175;
wire n_368;
wire n_195;
wire n_67;
wire n_112;
wire n_303;
wire n_169;
wire n_322;
wire n_103;
wire n_162;
wire n_64;
wire n_44;
wire n_228;
wire n_343;
wire n_265;
wire n_145;
wire n_215;
wire n_205;
wire n_56;
wire n_361;
wire n_171;
wire n_337;
wire n_222;
wire n_158;
wire n_354;
wire n_285;
wire n_350;
wire n_114;
wire n_272;
wire n_99;
wire n_318;
wire n_144;
wire n_155;
wire n_270;
wire n_377;
wire n_214;
wire n_84;
wire n_116;
wire n_45;
wire n_218;
wire n_78;
wire n_235;
wire n_191;
wire n_60;
wire n_256;
wire n_384;
wire n_369;
wire n_177;
wire n_269;
wire n_286;
wire n_81;
wire n_357;
wire n_266;
wire n_163;
wire n_91;
wire n_105;
wire n_329;
wire n_230;
wire n_223;
wire n_371;
wire n_278;
wire n_282;
wire n_283;
wire n_336;
wire n_151;
wire n_53;
wire n_77;
wire n_48;
wire n_346;
wire n_199;
wire n_364;
wire n_372;
wire n_382;
wire n_219;
wire n_119;
wire n_310;
wire n_149;
wire n_182;
wire n_341;
wire n_359;
wire n_281;
wire n_202;
wire n_298;
wire n_167;
wire n_237;
wire n_104;
wire n_284;
wire n_291;
wire n_146;
wire n_325;
wire n_200;
wire n_196;
wire n_106;
wire n_355;
wire n_258;
wire n_391;
wire n_87;
wire n_115;
wire n_79;
wire n_307;
wire n_128;
wire n_126;
wire n_339;
wire n_147;
wire n_352;
wire n_267;
wire n_95;
wire n_186;
wire n_297;
wire n_316;
wire n_293;
wire n_70;
wire n_62;
wire n_90;
wire n_58;
wire n_166;
wire n_247;
wire n_344;
wire n_327;
wire n_220;
wire n_358;
wire n_296;
wire n_347;
wire n_154;
wire n_194;
wire n_184;
wire n_376;
wire n_288;
wire n_121;
wire n_381;
wire n_157;
wire n_290;
wire n_92;
wire n_386;
wire n_117;
wire n_360;
wire n_136;
wire n_276;
wire n_170;
wire n_314;
wire n_207;
wire n_75;
wire n_93;
wire n_279;
wire n_338;
wire n_181;
wire n_390;
wire n_213;
wire n_65;
wire n_240;
wire n_208;
wire n_273;
wire n_320;
wire n_308;
wire n_72;
wire n_229;
wire n_51;
wire n_301;
wire n_383;
wire n_68;
wire n_380;
wire n_198;
wire n_248;
wire n_253;
wire n_335;
wire n_179;
wire n_254;
wire n_150;
wire n_374;
wire n_305;
wire n_148;
wire n_159;
wire n_123;
wire n_141;
wire n_309;
wire n_353;
wire n_185;
wire n_73;
wire n_328;
wire n_132;
wire n_367;
wire n_224;
wire n_264;
wire n_366;
wire n_138;
wire n_46;
wire n_239;
wire n_274;
wire n_55;
wire n_315;
wire n_287;
wire n_102;
wire n_135;
wire n_178;
wire n_324;
wire n_47;
wire n_255;
wire n_311;
wire n_334;
wire n_80;
wire n_88;
wire n_375;
wire n_168;
wire n_348;
wire n_139;
wire n_57;
wire n_252;
wire n_89;
wire n_152;
wire n_96;
wire n_172;
wire n_107;
wire n_342;
wire n_66;
wire n_261;
wire n_137;
wire n_197;
wire n_363;
wire n_243;
wire n_211;
wire n_206;
wire n_192;
wire n_124;
wire n_165;
wire n_263;
wire n_302;
wire n_244;
wire n_125;
wire n_333;
wire n_304;
wire n_110;
wire n_388;
wire n_393;
wire n_378;
wire n_203;
wire n_109;
wire n_340;
wire n_387;
wire n_82;
wire n_277;
wire n_204;
wire n_120;
wire n_61;
wire n_246;
wire n_242;
wire n_257;
wire n_231;
wire n_226;
wire n_54;
wire n_86;
wire n_280;
wire n_130;
wire n_233;
wire n_210;
wire n_140;
wire n_262;
wire n_299;
wire n_249;
wire n_292;
wire n_251;
wire n_332;
wire n_52;
wire n_50;
wire n_113;
wire n_127;
wire n_236;
wire n_100;
wire n_129;
wire n_76;
wire n_83;
wire n_134;
wire n_330;
wire n_319;
wire n_133;
wire n_225;
wire n_59;
wire n_97;
wire n_131;
wire n_295;
wire n_108;
wire n_98;
wire n_69;
wire n_94;
wire n_268;
wire n_212;
wire n_221;
wire n_271;
wire n_356;
wire n_193;
wire n_289;
wire n_153;
wire n_216;
wire n_373;
wire n_74;
wire n_351;
wire n_188;
wire n_370;
wire n_111;

INVxp67_ASAP7_75t_L g44 ( 
.A(n_12),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_27),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_21),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_29),
.Y(n_47)
);

INVxp33_ASAP7_75t_SL g48 ( 
.A(n_2),
.Y(n_48)
);

CKINVDCx20_ASAP7_75t_R g49 ( 
.A(n_43),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_1),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_16),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_36),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_1),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_28),
.Y(n_54)
);

CKINVDCx5p33_ASAP7_75t_R g55 ( 
.A(n_6),
.Y(n_55)
);

CKINVDCx16_ASAP7_75t_R g56 ( 
.A(n_26),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_19),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_7),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_11),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_10),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_15),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_32),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_18),
.Y(n_63)
);

INVxp33_ASAP7_75t_L g64 ( 
.A(n_6),
.Y(n_64)
);

CKINVDCx16_ASAP7_75t_R g65 ( 
.A(n_7),
.Y(n_65)
);

CKINVDCx5p33_ASAP7_75t_R g66 ( 
.A(n_4),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_30),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_31),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_37),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_5),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_SL g71 ( 
.A(n_65),
.B(n_68),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_68),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_69),
.Y(n_73)
);

INVx3_ASAP7_75t_L g74 ( 
.A(n_58),
.Y(n_74)
);

AND2x2_ASAP7_75t_L g75 ( 
.A(n_64),
.B(n_0),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_53),
.B(n_0),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_69),
.Y(n_77)
);

NAND2xp5_ASAP7_75t_SL g78 ( 
.A(n_56),
.B(n_2),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_58),
.Y(n_79)
);

OAI21x1_ASAP7_75t_L g80 ( 
.A1(n_45),
.A2(n_14),
.B(n_13),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_59),
.Y(n_81)
);

BUFx6f_ASAP7_75t_L g82 ( 
.A(n_46),
.Y(n_82)
);

INVx2_ASAP7_75t_L g83 ( 
.A(n_47),
.Y(n_83)
);

CKINVDCx20_ASAP7_75t_R g84 ( 
.A(n_49),
.Y(n_84)
);

INVx4_ASAP7_75t_L g85 ( 
.A(n_51),
.Y(n_85)
);

AND2x4_ASAP7_75t_L g86 ( 
.A(n_59),
.B(n_3),
.Y(n_86)
);

NAND2xp5_ASAP7_75t_L g87 ( 
.A(n_53),
.B(n_3),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_52),
.Y(n_88)
);

XNOR2xp5_ASAP7_75t_L g89 ( 
.A(n_48),
.B(n_4),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_54),
.Y(n_90)
);

INVxp67_ASAP7_75t_L g91 ( 
.A(n_50),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_57),
.Y(n_92)
);

NOR2xp33_ASAP7_75t_SL g93 ( 
.A(n_44),
.B(n_17),
.Y(n_93)
);

NAND2xp33_ASAP7_75t_SL g94 ( 
.A(n_49),
.B(n_5),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_86),
.Y(n_95)
);

NAND2xp33_ASAP7_75t_L g96 ( 
.A(n_88),
.B(n_92),
.Y(n_96)
);

AO22x2_ASAP7_75t_L g97 ( 
.A1(n_86),
.A2(n_70),
.B1(n_60),
.B2(n_61),
.Y(n_97)
);

INVx2_ASAP7_75t_L g98 ( 
.A(n_82),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_85),
.B(n_55),
.Y(n_99)
);

NAND2xp5_ASAP7_75t_L g100 ( 
.A(n_85),
.B(n_55),
.Y(n_100)
);

INVx2_ASAP7_75t_L g101 ( 
.A(n_82),
.Y(n_101)
);

NAND2xp5_ASAP7_75t_SL g102 ( 
.A(n_72),
.B(n_62),
.Y(n_102)
);

INVx2_ASAP7_75t_L g103 ( 
.A(n_82),
.Y(n_103)
);

AND2x4_ASAP7_75t_SL g104 ( 
.A(n_84),
.B(n_60),
.Y(n_104)
);

BUFx5_ASAP7_75t_L g105 ( 
.A(n_72),
.Y(n_105)
);

NAND2xp5_ASAP7_75t_L g106 ( 
.A(n_85),
.B(n_66),
.Y(n_106)
);

AOI22xp5_ASAP7_75t_L g107 ( 
.A1(n_71),
.A2(n_48),
.B1(n_66),
.B2(n_70),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_86),
.Y(n_108)
);

INVx2_ASAP7_75t_L g109 ( 
.A(n_82),
.Y(n_109)
);

CKINVDCx5p33_ASAP7_75t_R g110 ( 
.A(n_75),
.Y(n_110)
);

INVx2_ASAP7_75t_L g111 ( 
.A(n_82),
.Y(n_111)
);

BUFx12f_ASAP7_75t_SL g112 ( 
.A(n_75),
.Y(n_112)
);

OAI22xp5_ASAP7_75t_L g113 ( 
.A1(n_91),
.A2(n_67),
.B1(n_63),
.B2(n_8),
.Y(n_113)
);

INVxp33_ASAP7_75t_L g114 ( 
.A(n_76),
.Y(n_114)
);

OAI21xp5_ASAP7_75t_L g115 ( 
.A1(n_73),
.A2(n_22),
.B(n_20),
.Y(n_115)
);

AND2x6_ASAP7_75t_SL g116 ( 
.A(n_86),
.B(n_8),
.Y(n_116)
);

INVx1_ASAP7_75t_SL g117 ( 
.A(n_87),
.Y(n_117)
);

NOR2xp67_ASAP7_75t_SL g118 ( 
.A(n_73),
.B(n_23),
.Y(n_118)
);

AOI22xp5_ASAP7_75t_L g119 ( 
.A1(n_78),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_119)
);

INVx1_ASAP7_75t_L g120 ( 
.A(n_77),
.Y(n_120)
);

INVx2_ASAP7_75t_L g121 ( 
.A(n_82),
.Y(n_121)
);

NAND2xp5_ASAP7_75t_L g122 ( 
.A(n_85),
.B(n_9),
.Y(n_122)
);

AND2x4_ASAP7_75t_L g123 ( 
.A(n_77),
.B(n_24),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_88),
.B(n_25),
.Y(n_124)
);

NOR2xp33_ASAP7_75t_L g125 ( 
.A(n_92),
.B(n_33),
.Y(n_125)
);

NAND2xp5_ASAP7_75t_L g126 ( 
.A(n_83),
.B(n_34),
.Y(n_126)
);

NAND2xp5_ASAP7_75t_L g127 ( 
.A(n_83),
.B(n_35),
.Y(n_127)
);

INVxp67_ASAP7_75t_SL g128 ( 
.A(n_90),
.Y(n_128)
);

NAND2xp5_ASAP7_75t_L g129 ( 
.A(n_90),
.B(n_38),
.Y(n_129)
);

NAND2xp5_ASAP7_75t_L g130 ( 
.A(n_74),
.B(n_39),
.Y(n_130)
);

A2O1A1Ixp33_ASAP7_75t_L g131 ( 
.A1(n_95),
.A2(n_80),
.B(n_81),
.C(n_79),
.Y(n_131)
);

BUFx2_ASAP7_75t_L g132 ( 
.A(n_112),
.Y(n_132)
);

INVx2_ASAP7_75t_L g133 ( 
.A(n_98),
.Y(n_133)
);

AOI22xp5_ASAP7_75t_L g134 ( 
.A1(n_97),
.A2(n_94),
.B1(n_89),
.B2(n_93),
.Y(n_134)
);

OAI221xp5_ASAP7_75t_L g135 ( 
.A1(n_107),
.A2(n_89),
.B1(n_81),
.B2(n_79),
.C(n_74),
.Y(n_135)
);

NAND2xp5_ASAP7_75t_SL g136 ( 
.A(n_105),
.B(n_74),
.Y(n_136)
);

OR2x2_ASAP7_75t_L g137 ( 
.A(n_117),
.B(n_74),
.Y(n_137)
);

NAND2xp5_ASAP7_75t_L g138 ( 
.A(n_99),
.B(n_80),
.Y(n_138)
);

NAND2xp5_ASAP7_75t_L g139 ( 
.A(n_106),
.B(n_40),
.Y(n_139)
);

AND2x2_ASAP7_75t_L g140 ( 
.A(n_114),
.B(n_41),
.Y(n_140)
);

CKINVDCx5p33_ASAP7_75t_R g141 ( 
.A(n_112),
.Y(n_141)
);

NAND2xp5_ASAP7_75t_L g142 ( 
.A(n_100),
.B(n_42),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_105),
.Y(n_143)
);

BUFx6f_ASAP7_75t_L g144 ( 
.A(n_123),
.Y(n_144)
);

INVx2_ASAP7_75t_L g145 ( 
.A(n_98),
.Y(n_145)
);

NAND2xp5_ASAP7_75t_SL g146 ( 
.A(n_105),
.B(n_123),
.Y(n_146)
);

NOR2xp33_ASAP7_75t_L g147 ( 
.A(n_114),
.B(n_110),
.Y(n_147)
);

INVx2_ASAP7_75t_L g148 ( 
.A(n_101),
.Y(n_148)
);

AND2x2_ASAP7_75t_L g149 ( 
.A(n_97),
.B(n_128),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_105),
.Y(n_150)
);

AND2x4_ASAP7_75t_L g151 ( 
.A(n_108),
.B(n_123),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_105),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_105),
.Y(n_153)
);

NAND2xp5_ASAP7_75t_L g154 ( 
.A(n_105),
.B(n_120),
.Y(n_154)
);

NAND2xp5_ASAP7_75t_L g155 ( 
.A(n_96),
.B(n_97),
.Y(n_155)
);

O2A1O1Ixp33_ASAP7_75t_L g156 ( 
.A1(n_113),
.A2(n_102),
.B(n_122),
.C(n_124),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_102),
.Y(n_157)
);

NOR2xp33_ASAP7_75t_R g158 ( 
.A(n_116),
.B(n_130),
.Y(n_158)
);

OAI22xp5_ASAP7_75t_L g159 ( 
.A1(n_119),
.A2(n_104),
.B1(n_125),
.B2(n_126),
.Y(n_159)
);

AND2x2_ASAP7_75t_L g160 ( 
.A(n_104),
.B(n_125),
.Y(n_160)
);

CKINVDCx5p33_ASAP7_75t_R g161 ( 
.A(n_115),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_127),
.Y(n_162)
);

BUFx6f_ASAP7_75t_L g163 ( 
.A(n_101),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_103),
.Y(n_164)
);

INVx2_ASAP7_75t_L g165 ( 
.A(n_103),
.Y(n_165)
);

AND2x2_ASAP7_75t_L g166 ( 
.A(n_129),
.B(n_118),
.Y(n_166)
);

INVx1_ASAP7_75t_L g167 ( 
.A(n_109),
.Y(n_167)
);

INVx1_ASAP7_75t_L g168 ( 
.A(n_109),
.Y(n_168)
);

NAND2xp5_ASAP7_75t_L g169 ( 
.A(n_137),
.B(n_111),
.Y(n_169)
);

NAND3xp33_ASAP7_75t_L g170 ( 
.A(n_147),
.B(n_121),
.C(n_111),
.Y(n_170)
);

BUFx6f_ASAP7_75t_L g171 ( 
.A(n_144),
.Y(n_171)
);

INVxp67_ASAP7_75t_L g172 ( 
.A(n_137),
.Y(n_172)
);

AND2x2_ASAP7_75t_L g173 ( 
.A(n_149),
.B(n_121),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_157),
.Y(n_174)
);

INVx2_ASAP7_75t_SL g175 ( 
.A(n_144),
.Y(n_175)
);

INVx3_ASAP7_75t_L g176 ( 
.A(n_144),
.Y(n_176)
);

CKINVDCx20_ASAP7_75t_R g177 ( 
.A(n_141),
.Y(n_177)
);

AND2x2_ASAP7_75t_L g178 ( 
.A(n_149),
.B(n_151),
.Y(n_178)
);

NOR2xp33_ASAP7_75t_L g179 ( 
.A(n_160),
.B(n_135),
.Y(n_179)
);

OAI22xp5_ASAP7_75t_L g180 ( 
.A1(n_151),
.A2(n_161),
.B1(n_144),
.B2(n_155),
.Y(n_180)
);

AND2x2_ASAP7_75t_L g181 ( 
.A(n_151),
.B(n_140),
.Y(n_181)
);

INVx1_ASAP7_75t_L g182 ( 
.A(n_154),
.Y(n_182)
);

OAI22xp5_ASAP7_75t_L g183 ( 
.A1(n_161),
.A2(n_144),
.B1(n_146),
.B2(n_134),
.Y(n_183)
);

AOI21x1_ASAP7_75t_L g184 ( 
.A1(n_138),
.A2(n_142),
.B(n_139),
.Y(n_184)
);

INVx5_ASAP7_75t_L g185 ( 
.A(n_140),
.Y(n_185)
);

INVx1_ASAP7_75t_L g186 ( 
.A(n_156),
.Y(n_186)
);

INVx2_ASAP7_75t_L g187 ( 
.A(n_133),
.Y(n_187)
);

NAND2x1p5_ASAP7_75t_L g188 ( 
.A(n_132),
.B(n_143),
.Y(n_188)
);

NAND2x1p5_ASAP7_75t_L g189 ( 
.A(n_132),
.B(n_143),
.Y(n_189)
);

BUFx6f_ASAP7_75t_L g190 ( 
.A(n_150),
.Y(n_190)
);

AND2x4_ASAP7_75t_L g191 ( 
.A(n_160),
.B(n_141),
.Y(n_191)
);

NAND2xp5_ASAP7_75t_L g192 ( 
.A(n_159),
.B(n_162),
.Y(n_192)
);

NAND2xp5_ASAP7_75t_L g193 ( 
.A(n_150),
.B(n_152),
.Y(n_193)
);

AOI21xp5_ASAP7_75t_L g194 ( 
.A1(n_152),
.A2(n_153),
.B(n_131),
.Y(n_194)
);

INVx1_ASAP7_75t_SL g195 ( 
.A(n_158),
.Y(n_195)
);

AOI22xp5_ASAP7_75t_L g196 ( 
.A1(n_153),
.A2(n_166),
.B1(n_136),
.B2(n_167),
.Y(n_196)
);

AOI21xp5_ASAP7_75t_L g197 ( 
.A1(n_166),
.A2(n_168),
.B(n_133),
.Y(n_197)
);

INVx2_ASAP7_75t_L g198 ( 
.A(n_145),
.Y(n_198)
);

INVx3_ASAP7_75t_L g199 ( 
.A(n_171),
.Y(n_199)
);

INVx1_ASAP7_75t_L g200 ( 
.A(n_174),
.Y(n_200)
);

INVx1_ASAP7_75t_L g201 ( 
.A(n_182),
.Y(n_201)
);

INVx1_ASAP7_75t_L g202 ( 
.A(n_192),
.Y(n_202)
);

OAI21x1_ASAP7_75t_L g203 ( 
.A1(n_184),
.A2(n_148),
.B(n_145),
.Y(n_203)
);

OAI21x1_ASAP7_75t_L g204 ( 
.A1(n_194),
.A2(n_164),
.B(n_148),
.Y(n_204)
);

OAI21xp5_ASAP7_75t_L g205 ( 
.A1(n_186),
.A2(n_165),
.B(n_164),
.Y(n_205)
);

AND2x2_ASAP7_75t_L g206 ( 
.A(n_178),
.B(n_165),
.Y(n_206)
);

AOI22xp33_ASAP7_75t_L g207 ( 
.A1(n_179),
.A2(n_178),
.B1(n_181),
.B2(n_172),
.Y(n_207)
);

HB1xp67_ASAP7_75t_L g208 ( 
.A(n_188),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_193),
.Y(n_209)
);

NAND2x1_ASAP7_75t_L g210 ( 
.A(n_176),
.B(n_171),
.Y(n_210)
);

BUFx6f_ASAP7_75t_L g211 ( 
.A(n_171),
.Y(n_211)
);

INVx1_ASAP7_75t_L g212 ( 
.A(n_173),
.Y(n_212)
);

BUFx3_ASAP7_75t_L g213 ( 
.A(n_171),
.Y(n_213)
);

AND2x4_ASAP7_75t_L g214 ( 
.A(n_181),
.B(n_163),
.Y(n_214)
);

INVx4_ASAP7_75t_L g215 ( 
.A(n_190),
.Y(n_215)
);

INVx1_ASAP7_75t_L g216 ( 
.A(n_173),
.Y(n_216)
);

INVx3_ASAP7_75t_L g217 ( 
.A(n_215),
.Y(n_217)
);

NAND2xp5_ASAP7_75t_L g218 ( 
.A(n_202),
.B(n_179),
.Y(n_218)
);

HB1xp67_ASAP7_75t_L g219 ( 
.A(n_208),
.Y(n_219)
);

AND2x2_ASAP7_75t_L g220 ( 
.A(n_209),
.B(n_201),
.Y(n_220)
);

AND2x2_ASAP7_75t_L g221 ( 
.A(n_209),
.B(n_201),
.Y(n_221)
);

AND2x2_ASAP7_75t_L g222 ( 
.A(n_212),
.B(n_189),
.Y(n_222)
);

INVx2_ASAP7_75t_L g223 ( 
.A(n_211),
.Y(n_223)
);

INVx1_ASAP7_75t_L g224 ( 
.A(n_200),
.Y(n_224)
);

AND2x2_ASAP7_75t_L g225 ( 
.A(n_212),
.B(n_189),
.Y(n_225)
);

AND2x2_ASAP7_75t_L g226 ( 
.A(n_216),
.B(n_207),
.Y(n_226)
);

NAND2xp5_ASAP7_75t_L g227 ( 
.A(n_202),
.B(n_183),
.Y(n_227)
);

INVx2_ASAP7_75t_L g228 ( 
.A(n_211),
.Y(n_228)
);

INVx1_ASAP7_75t_L g229 ( 
.A(n_200),
.Y(n_229)
);

AND2x4_ASAP7_75t_L g230 ( 
.A(n_208),
.B(n_216),
.Y(n_230)
);

CKINVDCx6p67_ASAP7_75t_R g231 ( 
.A(n_215),
.Y(n_231)
);

BUFx2_ASAP7_75t_L g232 ( 
.A(n_215),
.Y(n_232)
);

BUFx2_ASAP7_75t_L g233 ( 
.A(n_232),
.Y(n_233)
);

HB1xp67_ASAP7_75t_L g234 ( 
.A(n_219),
.Y(n_234)
);

OR2x6_ASAP7_75t_L g235 ( 
.A(n_232),
.B(n_215),
.Y(n_235)
);

INVxp67_ASAP7_75t_L g236 ( 
.A(n_220),
.Y(n_236)
);

OAI211xp5_ASAP7_75t_L g237 ( 
.A1(n_218),
.A2(n_195),
.B(n_177),
.C(n_196),
.Y(n_237)
);

NAND2xp5_ASAP7_75t_L g238 ( 
.A(n_220),
.B(n_191),
.Y(n_238)
);

BUFx3_ASAP7_75t_L g239 ( 
.A(n_231),
.Y(n_239)
);

AND2x4_ASAP7_75t_L g240 ( 
.A(n_217),
.B(n_213),
.Y(n_240)
);

HB1xp67_ASAP7_75t_L g241 ( 
.A(n_221),
.Y(n_241)
);

INVx1_ASAP7_75t_L g242 ( 
.A(n_224),
.Y(n_242)
);

INVx1_ASAP7_75t_L g243 ( 
.A(n_224),
.Y(n_243)
);

AND2x4_ASAP7_75t_L g244 ( 
.A(n_217),
.B(n_221),
.Y(n_244)
);

AND2x4_ASAP7_75t_SL g245 ( 
.A(n_231),
.B(n_191),
.Y(n_245)
);

INVx1_ASAP7_75t_L g246 ( 
.A(n_229),
.Y(n_246)
);

NAND2xp5_ASAP7_75t_SL g247 ( 
.A(n_217),
.B(n_185),
.Y(n_247)
);

INVx1_ASAP7_75t_L g248 ( 
.A(n_229),
.Y(n_248)
);

OA21x2_ASAP7_75t_L g249 ( 
.A1(n_227),
.A2(n_203),
.B(n_204),
.Y(n_249)
);

INVx1_ASAP7_75t_L g250 ( 
.A(n_227),
.Y(n_250)
);

INVx1_ASAP7_75t_L g251 ( 
.A(n_226),
.Y(n_251)
);

NAND2xp5_ASAP7_75t_L g252 ( 
.A(n_226),
.B(n_218),
.Y(n_252)
);

NAND2xp5_ASAP7_75t_L g253 ( 
.A(n_241),
.B(n_230),
.Y(n_253)
);

INVx1_ASAP7_75t_L g254 ( 
.A(n_242),
.Y(n_254)
);

INVx1_ASAP7_75t_L g255 ( 
.A(n_242),
.Y(n_255)
);

INVx1_ASAP7_75t_L g256 ( 
.A(n_246),
.Y(n_256)
);

INVx2_ASAP7_75t_SL g257 ( 
.A(n_239),
.Y(n_257)
);

AND2x2_ASAP7_75t_L g258 ( 
.A(n_251),
.B(n_230),
.Y(n_258)
);

INVx1_ASAP7_75t_L g259 ( 
.A(n_246),
.Y(n_259)
);

AND2x2_ASAP7_75t_L g260 ( 
.A(n_251),
.B(n_230),
.Y(n_260)
);

OR2x2_ASAP7_75t_L g261 ( 
.A(n_236),
.B(n_230),
.Y(n_261)
);

AND2x2_ASAP7_75t_L g262 ( 
.A(n_244),
.B(n_225),
.Y(n_262)
);

INVx1_ASAP7_75t_L g263 ( 
.A(n_243),
.Y(n_263)
);

OR2x2_ASAP7_75t_L g264 ( 
.A(n_234),
.B(n_225),
.Y(n_264)
);

AOI22xp5_ASAP7_75t_L g265 ( 
.A1(n_237),
.A2(n_245),
.B1(n_238),
.B2(n_244),
.Y(n_265)
);

NAND2xp5_ASAP7_75t_L g266 ( 
.A(n_252),
.B(n_222),
.Y(n_266)
);

NAND2xp5_ASAP7_75t_L g267 ( 
.A(n_248),
.B(n_222),
.Y(n_267)
);

AOI22xp5_ASAP7_75t_L g268 ( 
.A1(n_245),
.A2(n_244),
.B1(n_191),
.B2(n_239),
.Y(n_268)
);

OR2x2_ASAP7_75t_L g269 ( 
.A(n_233),
.B(n_231),
.Y(n_269)
);

AOI21xp33_ASAP7_75t_L g270 ( 
.A1(n_235),
.A2(n_217),
.B(n_180),
.Y(n_270)
);

INVx1_ASAP7_75t_L g271 ( 
.A(n_233),
.Y(n_271)
);

INVx2_ASAP7_75t_L g272 ( 
.A(n_249),
.Y(n_272)
);

INVx2_ASAP7_75t_L g273 ( 
.A(n_249),
.Y(n_273)
);

AOI22xp5_ASAP7_75t_L g274 ( 
.A1(n_250),
.A2(n_177),
.B1(n_206),
.B2(n_214),
.Y(n_274)
);

OR2x2_ASAP7_75t_L g275 ( 
.A(n_235),
.B(n_223),
.Y(n_275)
);

INVx1_ASAP7_75t_L g276 ( 
.A(n_250),
.Y(n_276)
);

INVx2_ASAP7_75t_L g277 ( 
.A(n_249),
.Y(n_277)
);

INVxp33_ASAP7_75t_L g278 ( 
.A(n_240),
.Y(n_278)
);

NOR2xp33_ASAP7_75t_L g279 ( 
.A(n_235),
.B(n_188),
.Y(n_279)
);

AND2x2_ASAP7_75t_L g280 ( 
.A(n_235),
.B(n_223),
.Y(n_280)
);

AND2x2_ASAP7_75t_L g281 ( 
.A(n_262),
.B(n_240),
.Y(n_281)
);

NAND2xp5_ASAP7_75t_L g282 ( 
.A(n_263),
.B(n_240),
.Y(n_282)
);

INVx1_ASAP7_75t_L g283 ( 
.A(n_254),
.Y(n_283)
);

INVx2_ASAP7_75t_SL g284 ( 
.A(n_269),
.Y(n_284)
);

INVx1_ASAP7_75t_L g285 ( 
.A(n_255),
.Y(n_285)
);

INVxp67_ASAP7_75t_L g286 ( 
.A(n_276),
.Y(n_286)
);

AND2x2_ASAP7_75t_L g287 ( 
.A(n_262),
.B(n_223),
.Y(n_287)
);

INVx1_ASAP7_75t_L g288 ( 
.A(n_256),
.Y(n_288)
);

NAND3xp33_ASAP7_75t_SL g289 ( 
.A(n_268),
.B(n_265),
.C(n_279),
.Y(n_289)
);

HB1xp67_ASAP7_75t_L g290 ( 
.A(n_272),
.Y(n_290)
);

OR2x2_ASAP7_75t_L g291 ( 
.A(n_264),
.B(n_249),
.Y(n_291)
);

OR2x2_ASAP7_75t_L g292 ( 
.A(n_253),
.B(n_228),
.Y(n_292)
);

NAND2x1_ASAP7_75t_L g293 ( 
.A(n_257),
.B(n_228),
.Y(n_293)
);

INVx1_ASAP7_75t_L g294 ( 
.A(n_259),
.Y(n_294)
);

HB1xp67_ASAP7_75t_L g295 ( 
.A(n_272),
.Y(n_295)
);

INVxp67_ASAP7_75t_L g296 ( 
.A(n_271),
.Y(n_296)
);

INVx2_ASAP7_75t_L g297 ( 
.A(n_273),
.Y(n_297)
);

OR2x2_ASAP7_75t_L g298 ( 
.A(n_266),
.B(n_228),
.Y(n_298)
);

INVx1_ASAP7_75t_L g299 ( 
.A(n_258),
.Y(n_299)
);

OR2x2_ASAP7_75t_L g300 ( 
.A(n_260),
.B(n_247),
.Y(n_300)
);

INVx1_ASAP7_75t_L g301 ( 
.A(n_258),
.Y(n_301)
);

AND2x2_ASAP7_75t_L g302 ( 
.A(n_260),
.B(n_214),
.Y(n_302)
);

NAND2xp5_ASAP7_75t_L g303 ( 
.A(n_267),
.B(n_206),
.Y(n_303)
);

OR2x2_ASAP7_75t_L g304 ( 
.A(n_261),
.B(n_203),
.Y(n_304)
);

OR2x2_ASAP7_75t_L g305 ( 
.A(n_275),
.B(n_203),
.Y(n_305)
);

INVx1_ASAP7_75t_L g306 ( 
.A(n_257),
.Y(n_306)
);

INVx1_ASAP7_75t_L g307 ( 
.A(n_280),
.Y(n_307)
);

INVx3_ASAP7_75t_L g308 ( 
.A(n_280),
.Y(n_308)
);

NAND3xp33_ASAP7_75t_SL g309 ( 
.A(n_279),
.B(n_210),
.C(n_197),
.Y(n_309)
);

INVx2_ASAP7_75t_L g310 ( 
.A(n_273),
.Y(n_310)
);

OR2x2_ASAP7_75t_L g311 ( 
.A(n_278),
.B(n_213),
.Y(n_311)
);

INVx1_ASAP7_75t_SL g312 ( 
.A(n_278),
.Y(n_312)
);

NAND2xp5_ASAP7_75t_L g313 ( 
.A(n_274),
.B(n_214),
.Y(n_313)
);

INVx2_ASAP7_75t_SL g314 ( 
.A(n_293),
.Y(n_314)
);

OAI21xp33_ASAP7_75t_L g315 ( 
.A1(n_308),
.A2(n_277),
.B(n_270),
.Y(n_315)
);

INVx1_ASAP7_75t_L g316 ( 
.A(n_283),
.Y(n_316)
);

INVx1_ASAP7_75t_L g317 ( 
.A(n_285),
.Y(n_317)
);

CKINVDCx5p33_ASAP7_75t_R g318 ( 
.A(n_284),
.Y(n_318)
);

NAND2xp5_ASAP7_75t_L g319 ( 
.A(n_299),
.B(n_277),
.Y(n_319)
);

AND2x2_ASAP7_75t_L g320 ( 
.A(n_307),
.B(n_204),
.Y(n_320)
);

NAND2xp5_ASAP7_75t_L g321 ( 
.A(n_301),
.B(n_214),
.Y(n_321)
);

INVx2_ASAP7_75t_L g322 ( 
.A(n_297),
.Y(n_322)
);

INVx2_ASAP7_75t_L g323 ( 
.A(n_297),
.Y(n_323)
);

AND2x2_ASAP7_75t_L g324 ( 
.A(n_308),
.B(n_204),
.Y(n_324)
);

INVx2_ASAP7_75t_L g325 ( 
.A(n_310),
.Y(n_325)
);

BUFx2_ASAP7_75t_L g326 ( 
.A(n_290),
.Y(n_326)
);

INVx2_ASAP7_75t_L g327 ( 
.A(n_310),
.Y(n_327)
);

INVx1_ASAP7_75t_L g328 ( 
.A(n_288),
.Y(n_328)
);

INVx2_ASAP7_75t_L g329 ( 
.A(n_290),
.Y(n_329)
);

INVx1_ASAP7_75t_L g330 ( 
.A(n_294),
.Y(n_330)
);

NAND2x1p5_ASAP7_75t_L g331 ( 
.A(n_306),
.B(n_213),
.Y(n_331)
);

INVx1_ASAP7_75t_L g332 ( 
.A(n_286),
.Y(n_332)
);

INVx1_ASAP7_75t_SL g333 ( 
.A(n_281),
.Y(n_333)
);

AOI21xp33_ASAP7_75t_L g334 ( 
.A1(n_296),
.A2(n_210),
.B(n_185),
.Y(n_334)
);

NAND2xp5_ASAP7_75t_L g335 ( 
.A(n_286),
.B(n_185),
.Y(n_335)
);

INVx1_ASAP7_75t_L g336 ( 
.A(n_296),
.Y(n_336)
);

INVx1_ASAP7_75t_L g337 ( 
.A(n_291),
.Y(n_337)
);

INVx1_ASAP7_75t_L g338 ( 
.A(n_295),
.Y(n_338)
);

NAND2xp5_ASAP7_75t_L g339 ( 
.A(n_284),
.B(n_282),
.Y(n_339)
);

NOR2xp33_ASAP7_75t_SL g340 ( 
.A(n_289),
.B(n_185),
.Y(n_340)
);

AND2x2_ASAP7_75t_L g341 ( 
.A(n_287),
.B(n_199),
.Y(n_341)
);

INVx1_ASAP7_75t_L g342 ( 
.A(n_298),
.Y(n_342)
);

BUFx3_ASAP7_75t_L g343 ( 
.A(n_318),
.Y(n_343)
);

NAND2xp5_ASAP7_75t_L g344 ( 
.A(n_337),
.B(n_312),
.Y(n_344)
);

NOR2xp67_ASAP7_75t_L g345 ( 
.A(n_314),
.B(n_295),
.Y(n_345)
);

NAND2xp5_ASAP7_75t_SL g346 ( 
.A(n_318),
.B(n_314),
.Y(n_346)
);

NAND4xp25_ASAP7_75t_L g347 ( 
.A(n_340),
.B(n_289),
.C(n_313),
.D(n_300),
.Y(n_347)
);

NOR2xp33_ASAP7_75t_L g348 ( 
.A(n_333),
.B(n_339),
.Y(n_348)
);

INVx1_ASAP7_75t_L g349 ( 
.A(n_316),
.Y(n_349)
);

AOI22xp5_ASAP7_75t_L g350 ( 
.A1(n_342),
.A2(n_302),
.B1(n_303),
.B2(n_309),
.Y(n_350)
);

NOR2xp33_ASAP7_75t_L g351 ( 
.A(n_317),
.B(n_292),
.Y(n_351)
);

NAND2xp5_ASAP7_75t_L g352 ( 
.A(n_332),
.B(n_304),
.Y(n_352)
);

NOR3xp33_ASAP7_75t_L g353 ( 
.A(n_315),
.B(n_309),
.C(n_311),
.Y(n_353)
);

AND4x1_ASAP7_75t_L g354 ( 
.A(n_336),
.B(n_170),
.C(n_205),
.D(n_169),
.Y(n_354)
);

NOR2xp67_ASAP7_75t_L g355 ( 
.A(n_329),
.B(n_305),
.Y(n_355)
);

NOR2x1_ASAP7_75t_SL g356 ( 
.A(n_335),
.B(n_319),
.Y(n_356)
);

NAND2xp5_ASAP7_75t_L g357 ( 
.A(n_316),
.B(n_185),
.Y(n_357)
);

INVx1_ASAP7_75t_L g358 ( 
.A(n_328),
.Y(n_358)
);

NAND2xp5_ASAP7_75t_L g359 ( 
.A(n_328),
.B(n_205),
.Y(n_359)
);

NOR3xp33_ASAP7_75t_L g360 ( 
.A(n_330),
.B(n_199),
.C(n_176),
.Y(n_360)
);

NOR3xp33_ASAP7_75t_SL g361 ( 
.A(n_321),
.B(n_199),
.C(n_176),
.Y(n_361)
);

AOI211xp5_ASAP7_75t_L g362 ( 
.A1(n_326),
.A2(n_199),
.B(n_211),
.C(n_175),
.Y(n_362)
);

NOR3xp33_ASAP7_75t_L g363 ( 
.A(n_334),
.B(n_175),
.C(n_187),
.Y(n_363)
);

AOI22xp33_ASAP7_75t_L g364 ( 
.A1(n_347),
.A2(n_341),
.B1(n_324),
.B2(n_320),
.Y(n_364)
);

AOI22xp5_ASAP7_75t_L g365 ( 
.A1(n_350),
.A2(n_338),
.B1(n_326),
.B2(n_341),
.Y(n_365)
);

AOI331xp33_ASAP7_75t_L g366 ( 
.A1(n_348),
.A2(n_338),
.A3(n_329),
.B1(n_320),
.B2(n_324),
.B3(n_322),
.C1(n_323),
.Y(n_366)
);

NOR2xp33_ASAP7_75t_L g367 ( 
.A(n_343),
.B(n_331),
.Y(n_367)
);

NAND4xp25_ASAP7_75t_L g368 ( 
.A(n_353),
.B(n_325),
.C(n_323),
.D(n_322),
.Y(n_368)
);

NAND3x1_ASAP7_75t_SL g369 ( 
.A(n_346),
.B(n_331),
.C(n_325),
.Y(n_369)
);

OAI32xp33_ASAP7_75t_L g370 ( 
.A1(n_344),
.A2(n_331),
.A3(n_327),
.B1(n_187),
.B2(n_198),
.Y(n_370)
);

AOI322xp5_ASAP7_75t_L g371 ( 
.A1(n_351),
.A2(n_163),
.A3(n_190),
.B1(n_198),
.B2(n_211),
.C1(n_327),
.C2(n_352),
.Y(n_371)
);

OAI22xp33_ASAP7_75t_L g372 ( 
.A1(n_345),
.A2(n_211),
.B1(n_190),
.B2(n_163),
.Y(n_372)
);

INVx1_ASAP7_75t_L g373 ( 
.A(n_349),
.Y(n_373)
);

INVx1_ASAP7_75t_L g374 ( 
.A(n_358),
.Y(n_374)
);

NAND2xp5_ASAP7_75t_L g375 ( 
.A(n_356),
.B(n_211),
.Y(n_375)
);

AND2x2_ASAP7_75t_L g376 ( 
.A(n_355),
.B(n_190),
.Y(n_376)
);

NAND5xp2_ASAP7_75t_L g377 ( 
.A(n_364),
.B(n_362),
.C(n_361),
.D(n_363),
.E(n_360),
.Y(n_377)
);

NOR2x1_ASAP7_75t_L g378 ( 
.A(n_368),
.B(n_357),
.Y(n_378)
);

AND3x4_ASAP7_75t_L g379 ( 
.A(n_369),
.B(n_354),
.C(n_363),
.Y(n_379)
);

INVx1_ASAP7_75t_L g380 ( 
.A(n_373),
.Y(n_380)
);

NAND2xp5_ASAP7_75t_L g381 ( 
.A(n_366),
.B(n_365),
.Y(n_381)
);

NOR2xp33_ASAP7_75t_L g382 ( 
.A(n_367),
.B(n_359),
.Y(n_382)
);

NOR2xp33_ASAP7_75t_L g383 ( 
.A(n_368),
.B(n_360),
.Y(n_383)
);

OAI211xp5_ASAP7_75t_SL g384 ( 
.A1(n_371),
.A2(n_163),
.B(n_375),
.C(n_374),
.Y(n_384)
);

BUFx2_ASAP7_75t_L g385 ( 
.A(n_378),
.Y(n_385)
);

INVx1_ASAP7_75t_L g386 ( 
.A(n_380),
.Y(n_386)
);

AOI22x1_ASAP7_75t_L g387 ( 
.A1(n_379),
.A2(n_376),
.B1(n_370),
.B2(n_372),
.Y(n_387)
);

AOI22xp5_ASAP7_75t_L g388 ( 
.A1(n_383),
.A2(n_163),
.B1(n_381),
.B2(n_382),
.Y(n_388)
);

NAND3xp33_ASAP7_75t_L g389 ( 
.A(n_388),
.B(n_384),
.C(n_377),
.Y(n_389)
);

NAND2xp5_ASAP7_75t_SL g390 ( 
.A(n_387),
.B(n_385),
.Y(n_390)
);

XOR2x2_ASAP7_75t_L g391 ( 
.A(n_390),
.B(n_385),
.Y(n_391)
);

INVx2_ASAP7_75t_L g392 ( 
.A(n_391),
.Y(n_392)
);

INVx1_ASAP7_75t_L g393 ( 
.A(n_392),
.Y(n_393)
);

AOI21xp5_ASAP7_75t_L g394 ( 
.A1(n_393),
.A2(n_389),
.B(n_386),
.Y(n_394)
);


endmodule