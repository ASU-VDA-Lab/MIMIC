module fake_netlist_671_456_n_54 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_54);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_54;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_23;
wire n_48;
wire n_16;
wire n_22;
wire n_17;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

NAND2xp33_ASAP7_75t_SL g18 ( 
.A(n_8),
.B(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

BUFx10_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

BUFx6f_ASAP7_75t_SL g26 ( 
.A(n_14),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_17),
.B(n_2),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_22),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_21),
.A2(n_25),
.B(n_24),
.C(n_22),
.Y(n_32)
);

AOI21x1_ASAP7_75t_L g33 ( 
.A1(n_26),
.A2(n_12),
.B(n_7),
.Y(n_33)
);

A2O1A1Ixp33_ASAP7_75t_SL g34 ( 
.A1(n_26),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_27),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_R g37 ( 
.A(n_33),
.B(n_16),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_29),
.Y(n_38)
);

INVx1_ASAP7_75t_SL g39 ( 
.A(n_35),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_19),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_36),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_23),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_34),
.B(n_28),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_40),
.B1(n_18),
.B2(n_30),
.Y(n_46)
);

AOI211xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_37),
.B(n_41),
.C(n_24),
.Y(n_47)
);

AOI211xp5_ASAP7_75t_SL g48 ( 
.A1(n_44),
.A2(n_41),
.B(n_26),
.C(n_24),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_46),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_48),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

AOI22x1_ASAP7_75t_SL g52 ( 
.A1(n_48),
.A2(n_10),
.B1(n_9),
.B2(n_5),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_SL g54 ( 
.A1(n_53),
.A2(n_49),
.B1(n_52),
.B2(n_51),
.Y(n_54)
);


endmodule