module fake_netlist_671_2155_n_25 (n_4, n_1, n_2, n_0, n_3, n_25);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_25;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_24;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx6_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_0),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_0),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_1),
.Y(n_10)
);

BUFx4f_ASAP7_75t_SL g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_5),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_7),
.Y(n_16)
);

OAI221xp5_ASAP7_75t_SL g17 ( 
.A1(n_10),
.A2(n_9),
.B1(n_13),
.B2(n_11),
.C(n_1),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_11),
.B(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_2),
.B1(n_3),
.B2(n_15),
.C(n_16),
.Y(n_21)
);

AOI211xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_17),
.B(n_18),
.C(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

OAI22x1_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_3),
.B1(n_18),
.B2(n_16),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_16),
.B1(n_22),
.B2(n_20),
.Y(n_25)
);


endmodule