module fake_netlist_671_299_n_51 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_51);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_51;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx2_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_13),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_15),
.B(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_12),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_14),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_20),
.B(n_14),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

AOI22x1_ASAP7_75t_L g32 ( 
.A1(n_20),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_22),
.B(n_15),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_26),
.B1(n_21),
.B2(n_24),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_30),
.A2(n_28),
.B(n_22),
.Y(n_36)
);

NOR2x1_ASAP7_75t_SL g37 ( 
.A(n_34),
.B(n_28),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_23),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_35),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_36),
.Y(n_40)
);

BUFx4f_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_38),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_29),
.C(n_25),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_41),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_43),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_44),
.Y(n_46)
);

OAI211xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_32),
.B(n_27),
.C(n_16),
.Y(n_47)
);

NAND3xp33_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_19),
.C(n_17),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

AOI322xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_4),
.A3(n_6),
.B1(n_10),
.B2(n_11),
.C1(n_46),
.C2(n_49),
.Y(n_51)
);


endmodule