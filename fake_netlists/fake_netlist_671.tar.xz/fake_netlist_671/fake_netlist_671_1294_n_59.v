module fake_netlist_671_1294_n_59 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_59);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_59;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_22;
wire n_17;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_11),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_12),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_5),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

XNOR2xp5_ASAP7_75t_L g21 ( 
.A(n_8),
.B(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_9),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_1),
.Y(n_25)
);

BUFx10_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

OA21x2_ASAP7_75t_L g27 ( 
.A1(n_14),
.A2(n_1),
.B(n_2),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_13),
.B(n_0),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_22),
.A2(n_3),
.B(n_0),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_24),
.A2(n_4),
.B(n_3),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_26),
.B(n_4),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

OAI21x1_ASAP7_75t_L g35 ( 
.A1(n_27),
.A2(n_8),
.B(n_6),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_26),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_R g38 ( 
.A(n_29),
.B(n_18),
.Y(n_38)
);

AO31x2_ASAP7_75t_L g39 ( 
.A1(n_30),
.A2(n_27),
.A3(n_26),
.B(n_17),
.Y(n_39)
);

A2O1A1Ixp33_ASAP7_75t_L g40 ( 
.A1(n_35),
.A2(n_25),
.B(n_20),
.C(n_19),
.Y(n_40)
);

INVxp67_ASAP7_75t_SL g41 ( 
.A(n_33),
.Y(n_41)
);

INVx3_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_37),
.B(n_27),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_37),
.B(n_21),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_37),
.B(n_36),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_41),
.B1(n_40),
.B2(n_21),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_SL g47 ( 
.A1(n_44),
.A2(n_41),
.B1(n_38),
.B2(n_42),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_31),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

OAI22xp33_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_42),
.B1(n_43),
.B2(n_28),
.Y(n_50)
);

OAI211xp5_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_32),
.B(n_28),
.C(n_43),
.Y(n_51)
);

NAND5xp2_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_46),
.C(n_16),
.D(n_10),
.E(n_11),
.Y(n_52)
);

A2O1A1Ixp33_ASAP7_75t_L g53 ( 
.A1(n_48),
.A2(n_39),
.B(n_27),
.C(n_10),
.Y(n_53)
);

CKINVDCx20_ASAP7_75t_R g54 ( 
.A(n_52),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_39),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_SL g57 ( 
.A1(n_54),
.A2(n_16),
.B1(n_39),
.B2(n_50),
.Y(n_57)
);

INVxp67_ASAP7_75t_L g58 ( 
.A(n_56),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_SL g59 ( 
.A1(n_58),
.A2(n_39),
.B1(n_55),
.B2(n_57),
.Y(n_59)
);


endmodule