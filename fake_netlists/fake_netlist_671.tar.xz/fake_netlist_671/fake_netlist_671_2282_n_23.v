module fake_netlist_671_2282_n_23 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_23);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_23;

wire n_18;
wire n_19;
wire n_10;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_4),
.B(n_2),
.C(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_SL g14 ( 
.A1(n_8),
.A2(n_9),
.B1(n_10),
.B2(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_SL g15 ( 
.A(n_8),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_7),
.Y(n_17)
);

OAI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.C1(n_4),
.C2(n_2),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_16),
.B(n_14),
.Y(n_19)
);

AOI321xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.A3(n_6),
.B1(n_5),
.B2(n_3),
.C(n_7),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_18),
.B(n_7),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_7),
.B1(n_18),
.B2(n_5),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_3),
.B1(n_5),
.B2(n_6),
.C(n_22),
.Y(n_23)
);


endmodule