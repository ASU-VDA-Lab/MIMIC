module fake_netlist_671_963_n_11 (n_1, n_2, n_0, n_11);

input n_1;
input n_2;
input n_0;

output n_11;

wire n_9;
wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_8;
wire n_6;
wire n_3;

INVx3_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVxp67_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_SL g6 ( 
.A(n_4),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_4),
.B1(n_2),
.B2(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

OAI31xp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_6),
.A3(n_2),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B(n_2),
.Y(n_11)
);


endmodule