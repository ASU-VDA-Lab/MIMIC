module fake_netlist_671_1326_n_49 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_49);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_49;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx2_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_0),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_8),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_13),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_11),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_1),
.B(n_2),
.Y(n_32)
);

INVx4_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_25),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_33),
.A2(n_30),
.B1(n_29),
.B2(n_27),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_35),
.A2(n_28),
.B1(n_32),
.B2(n_3),
.Y(n_37)
);

AO21x2_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_34),
.B(n_4),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

OAI31xp33_ASAP7_75t_SL g40 ( 
.A1(n_39),
.A2(n_7),
.A3(n_6),
.B(n_5),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_9),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_41),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_10),
.Y(n_43)
);

XNOR2x1_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_12),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_15),
.B(n_14),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_45),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_16),
.Y(n_47)
);

AND2x4_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_17),
.Y(n_48)
);

AOI222xp33_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_46),
.B1(n_23),
.B2(n_19),
.C1(n_24),
.C2(n_21),
.Y(n_49)
);


endmodule