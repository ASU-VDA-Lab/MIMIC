module fake_netlist_673_917_n_32 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_32);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_32;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_9),
.A2(n_12),
.B(n_3),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

INVx4_ASAP7_75t_SL g22 ( 
.A(n_17),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_22),
.Y(n_24)
);

OAI22xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_16),
.B1(n_20),
.B2(n_21),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

OAI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_18),
.B1(n_19),
.B2(n_7),
.C(n_0),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_7),
.Y(n_30)
);

OR5x1_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_19),
.C(n_10),
.D(n_1),
.E(n_4),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_32)
);


endmodule