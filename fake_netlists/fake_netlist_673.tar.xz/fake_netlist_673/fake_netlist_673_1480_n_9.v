module fake_netlist_673_1480_n_9 (n_1, n_2, n_0, n_9);

input n_1;
input n_2;
input n_0;

output n_9;

wire n_4;
wire n_7;
wire n_5;
wire n_8;
wire n_6;
wire n_3;

BUFx3_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

BUFx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NOR3xp33_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.C(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);


endmodule