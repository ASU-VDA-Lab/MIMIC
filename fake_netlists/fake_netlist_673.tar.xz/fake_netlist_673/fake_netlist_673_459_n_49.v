module fake_netlist_673_459_n_49 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_49);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_49;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_14),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_11),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_16),
.B(n_15),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

A2O1A1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_17),
.B(n_16),
.C(n_2),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_25),
.B(n_2),
.Y(n_32)
);

AOI21x1_ASAP7_75t_SL g33 ( 
.A1(n_30),
.A2(n_28),
.B(n_27),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_22),
.B1(n_32),
.B2(n_25),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_17),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_25),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_23),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_26),
.Y(n_38)
);

AOI21xp33_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_35),
.B(n_18),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_18),
.Y(n_40)
);

AOI221x1_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_37),
.B1(n_38),
.B2(n_29),
.C(n_24),
.Y(n_41)
);

AOI222xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_38),
.B1(n_37),
.B2(n_21),
.C1(n_20),
.C2(n_19),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_37),
.B(n_20),
.C(n_0),
.Y(n_43)
);

NOR3xp33_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_37),
.C(n_3),
.Y(n_44)
);

NAND2x1_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_37),
.Y(n_45)
);

NAND3xp33_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_37),
.C(n_6),
.Y(n_46)
);

OA21x2_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_8),
.B(n_7),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_45),
.B1(n_12),
.B2(n_9),
.Y(n_48)
);

AO21x2_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_13),
.B(n_44),
.Y(n_49)
);


endmodule