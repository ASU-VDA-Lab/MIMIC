module fake_netlist_673_3074_n_39 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_39);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_39;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

INVx2_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_13),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_2),
.B(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_5),
.B(n_1),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_26)
);

O2A1O1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_17),
.B(n_16),
.C(n_3),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_22),
.A2(n_6),
.B(n_4),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_28),
.B(n_20),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_27),
.A2(n_20),
.B1(n_25),
.B2(n_19),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_19),
.B1(n_30),
.B2(n_22),
.C1(n_26),
.C2(n_16),
.Y(n_32)
);

AOI221xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_21),
.B1(n_18),
.B2(n_17),
.C(n_7),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_18),
.A3(n_10),
.B1(n_9),
.B2(n_8),
.C1(n_15),
.C2(n_14),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

OAI31xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_36),
.A3(n_37),
.B(n_27),
.Y(n_39)
);


endmodule