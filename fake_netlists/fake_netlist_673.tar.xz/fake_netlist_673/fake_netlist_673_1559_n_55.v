module fake_netlist_673_1559_n_55 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_55);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_55;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

BUFx3_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_8),
.B(n_5),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_0),
.B(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_1),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_15),
.Y(n_27)
);

INVx2_ASAP7_75t_SL g28 ( 
.A(n_23),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_26),
.B(n_2),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

OAI21x1_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_19),
.B(n_20),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_25),
.Y(n_32)
);

NOR2x1_ASAP7_75t_SL g33 ( 
.A(n_27),
.B(n_25),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_33),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_29),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

NAND2x1p5_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_31),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

OAI31xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_35),
.A3(n_36),
.B(n_21),
.Y(n_40)
);

OAI221xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_25),
.B1(n_22),
.B2(n_19),
.C(n_18),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

XNOR2xp5_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_41),
.Y(n_43)
);

AOI211xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_29),
.B(n_21),
.C(n_18),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_R g46 ( 
.A(n_42),
.B(n_15),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_SL g47 ( 
.A(n_46),
.B(n_21),
.Y(n_47)
);

NOR2x1_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_16),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_44),
.A2(n_17),
.B1(n_16),
.B2(n_3),
.Y(n_49)
);

OR2x2_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_4),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_50),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_SL g52 ( 
.A1(n_48),
.A2(n_10),
.B1(n_9),
.B2(n_7),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_47),
.Y(n_54)
);

O2A1O1Ixp33_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_53),
.B(n_52),
.C(n_11),
.Y(n_55)
);


endmodule