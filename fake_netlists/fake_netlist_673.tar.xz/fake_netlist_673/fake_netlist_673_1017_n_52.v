module fake_netlist_673_1017_n_52 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_52);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_52;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx2_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_5),
.A2(n_10),
.B1(n_3),
.B2(n_2),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_4),
.B(n_6),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_13),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_16),
.B1(n_5),
.B2(n_4),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_1),
.C(n_0),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_22),
.B(n_16),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_29),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_26),
.A2(n_23),
.B1(n_21),
.B2(n_22),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_31),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_32),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_17),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_18),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_19),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

XNOR2x1_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_37),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_37),
.B(n_36),
.Y(n_44)
);

NOR4xp25_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_20),
.C(n_36),
.D(n_25),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_25),
.Y(n_46)
);

AOI21xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_9),
.B(n_8),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_42),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

OAI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_48),
.A2(n_12),
.B1(n_42),
.B2(n_45),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

OAI21xp5_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_47),
.B(n_50),
.Y(n_52)
);


endmodule