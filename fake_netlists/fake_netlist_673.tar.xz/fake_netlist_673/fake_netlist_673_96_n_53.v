module fake_netlist_673_96_n_53 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_53);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_53;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_10),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_2),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_15),
.B(n_6),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_3),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_21),
.B(n_9),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_14),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_19),
.B(n_20),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_26),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_25),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_R g38 ( 
.A(n_34),
.B(n_0),
.Y(n_38)
);

AO22x1_ASAP7_75t_L g39 ( 
.A1(n_31),
.A2(n_33),
.B1(n_27),
.B2(n_28),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_31),
.B1(n_33),
.B2(n_27),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_38),
.Y(n_41)
);

AOI222xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_30),
.B1(n_32),
.B2(n_29),
.C1(n_35),
.C2(n_36),
.Y(n_42)
);

HB1xp67_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_24),
.B1(n_17),
.B2(n_1),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

XOR2x2_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_44),
.Y(n_46)
);

OAI222xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_7),
.B1(n_4),
.B2(n_11),
.C1(n_13),
.C2(n_12),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AOI211xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_22),
.B(n_23),
.C(n_45),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

AND2x4_ASAP7_75t_L g52 ( 
.A(n_51),
.B(n_50),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);


endmodule