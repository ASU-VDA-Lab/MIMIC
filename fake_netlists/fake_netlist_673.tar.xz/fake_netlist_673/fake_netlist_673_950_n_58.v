module fake_netlist_673_950_n_58 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_58);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_58;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_2),
.A2(n_0),
.B1(n_17),
.B2(n_5),
.Y(n_21)
);

BUFx8_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_2),
.B(n_5),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_8),
.B(n_6),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_8),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_15),
.B(n_4),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

O2A1O1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_20),
.A2(n_19),
.B(n_25),
.C(n_24),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_20),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_19),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

OAI21x1_ASAP7_75t_SL g35 ( 
.A1(n_29),
.A2(n_27),
.B(n_22),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_31),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_28),
.B1(n_30),
.B2(n_21),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_33),
.Y(n_39)
);

OAI33xp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_32),
.A3(n_35),
.B1(n_23),
.B2(n_22),
.B3(n_1),
.Y(n_40)
);

OAI222xp33_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_35),
.B1(n_11),
.B2(n_3),
.C1(n_16),
.C2(n_10),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_36),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_10),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_18),
.B1(n_11),
.B2(n_7),
.Y(n_45)
);

INVx1_ASAP7_75t_SL g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_42),
.Y(n_48)
);

A2O1A1Ixp33_ASAP7_75t_SL g49 ( 
.A1(n_44),
.A2(n_9),
.B(n_14),
.C(n_45),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

INVxp67_ASAP7_75t_SL g51 ( 
.A(n_46),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

AOI221x1_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_44),
.B1(n_45),
.B2(n_47),
.C(n_48),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

AO21x2_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_51),
.B(n_53),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

AOI22x1_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_54),
.B1(n_55),
.B2(n_56),
.Y(n_58)
);


endmodule