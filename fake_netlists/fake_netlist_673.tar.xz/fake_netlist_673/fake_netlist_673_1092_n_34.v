module fake_netlist_673_1092_n_34 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_34);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_34;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

INVx2_ASAP7_75t_SL g18 ( 
.A(n_2),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_4),
.B(n_13),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_5),
.B(n_15),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_0),
.B(n_17),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_3),
.B(n_17),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_7),
.A2(n_9),
.B1(n_12),
.B2(n_6),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

OA21x2_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_8),
.B(n_1),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_21),
.B(n_24),
.C(n_25),
.Y(n_32)
);

AOI211xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_29),
.B(n_28),
.C(n_20),
.Y(n_33)
);

AOI222xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_22),
.B1(n_19),
.B2(n_16),
.C1(n_26),
.C2(n_11),
.Y(n_34)
);


endmodule