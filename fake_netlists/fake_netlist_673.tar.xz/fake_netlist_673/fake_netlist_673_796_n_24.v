module fake_netlist_673_796_n_24 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_24);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_24;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_8),
.B(n_3),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_14)
);

OA22x2_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_12),
.B1(n_9),
.B2(n_10),
.Y(n_15)
);

NOR2xp67_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_0),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_13),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_17),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_16),
.B1(n_13),
.B2(n_1),
.C(n_3),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_20),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_24)
);


endmodule