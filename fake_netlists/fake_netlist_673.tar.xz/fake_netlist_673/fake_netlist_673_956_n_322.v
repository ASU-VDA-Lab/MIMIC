module fake_netlist_673_956_n_322 (n_18, n_36, n_19, n_34, n_1, n_38, n_0, n_5, n_10, n_44, n_25, n_40, n_24, n_35, n_28, n_11, n_15, n_7, n_30, n_20, n_45, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_39, n_14, n_21, n_27, n_42, n_2, n_29, n_31, n_41, n_26, n_33, n_9, n_32, n_37, n_13, n_43, n_8, n_6, n_322);

input n_18;
input n_36;
input n_19;
input n_34;
input n_1;
input n_38;
input n_0;
input n_5;
input n_10;
input n_44;
input n_25;
input n_40;
input n_24;
input n_35;
input n_28;
input n_11;
input n_15;
input n_7;
input n_30;
input n_20;
input n_45;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_39;
input n_14;
input n_21;
input n_27;
input n_42;
input n_2;
input n_29;
input n_31;
input n_41;
input n_26;
input n_33;
input n_9;
input n_32;
input n_37;
input n_13;
input n_43;
input n_8;
input n_6;

output n_322;

wire n_101;
wire n_313;
wire n_209;
wire n_321;
wire n_245;
wire n_164;
wire n_118;
wire n_189;
wire n_306;
wire n_275;
wire n_173;
wire n_183;
wire n_260;
wire n_63;
wire n_190;
wire n_187;
wire n_238;
wire n_71;
wire n_201;
wire n_294;
wire n_217;
wire n_300;
wire n_49;
wire n_241;
wire n_161;
wire n_234;
wire n_259;
wire n_312;
wire n_180;
wire n_142;
wire n_232;
wire n_143;
wire n_122;
wire n_250;
wire n_227;
wire n_85;
wire n_176;
wire n_160;
wire n_156;
wire n_317;
wire n_174;
wire n_175;
wire n_195;
wire n_67;
wire n_112;
wire n_303;
wire n_169;
wire n_103;
wire n_162;
wire n_64;
wire n_228;
wire n_265;
wire n_145;
wire n_215;
wire n_205;
wire n_56;
wire n_171;
wire n_222;
wire n_158;
wire n_285;
wire n_114;
wire n_272;
wire n_99;
wire n_318;
wire n_144;
wire n_155;
wire n_270;
wire n_214;
wire n_84;
wire n_116;
wire n_218;
wire n_78;
wire n_235;
wire n_191;
wire n_60;
wire n_256;
wire n_177;
wire n_269;
wire n_286;
wire n_81;
wire n_266;
wire n_163;
wire n_91;
wire n_105;
wire n_230;
wire n_223;
wire n_278;
wire n_282;
wire n_283;
wire n_151;
wire n_53;
wire n_77;
wire n_48;
wire n_199;
wire n_219;
wire n_119;
wire n_310;
wire n_149;
wire n_182;
wire n_281;
wire n_202;
wire n_298;
wire n_167;
wire n_237;
wire n_104;
wire n_284;
wire n_291;
wire n_146;
wire n_200;
wire n_196;
wire n_106;
wire n_258;
wire n_87;
wire n_115;
wire n_79;
wire n_307;
wire n_128;
wire n_126;
wire n_147;
wire n_267;
wire n_95;
wire n_186;
wire n_297;
wire n_316;
wire n_293;
wire n_90;
wire n_62;
wire n_70;
wire n_58;
wire n_166;
wire n_247;
wire n_220;
wire n_296;
wire n_154;
wire n_194;
wire n_184;
wire n_288;
wire n_121;
wire n_157;
wire n_290;
wire n_92;
wire n_117;
wire n_136;
wire n_276;
wire n_170;
wire n_314;
wire n_207;
wire n_75;
wire n_93;
wire n_279;
wire n_181;
wire n_213;
wire n_65;
wire n_240;
wire n_208;
wire n_273;
wire n_320;
wire n_308;
wire n_72;
wire n_229;
wire n_51;
wire n_301;
wire n_68;
wire n_198;
wire n_248;
wire n_253;
wire n_179;
wire n_254;
wire n_150;
wire n_305;
wire n_148;
wire n_159;
wire n_123;
wire n_141;
wire n_309;
wire n_185;
wire n_73;
wire n_132;
wire n_224;
wire n_264;
wire n_138;
wire n_46;
wire n_239;
wire n_274;
wire n_55;
wire n_315;
wire n_287;
wire n_102;
wire n_135;
wire n_178;
wire n_47;
wire n_255;
wire n_311;
wire n_80;
wire n_88;
wire n_168;
wire n_139;
wire n_57;
wire n_252;
wire n_89;
wire n_152;
wire n_96;
wire n_172;
wire n_107;
wire n_66;
wire n_261;
wire n_137;
wire n_197;
wire n_243;
wire n_211;
wire n_206;
wire n_192;
wire n_124;
wire n_165;
wire n_263;
wire n_302;
wire n_244;
wire n_125;
wire n_304;
wire n_110;
wire n_203;
wire n_109;
wire n_82;
wire n_277;
wire n_204;
wire n_120;
wire n_61;
wire n_246;
wire n_242;
wire n_257;
wire n_231;
wire n_226;
wire n_54;
wire n_86;
wire n_280;
wire n_130;
wire n_233;
wire n_210;
wire n_140;
wire n_262;
wire n_299;
wire n_249;
wire n_292;
wire n_251;
wire n_52;
wire n_50;
wire n_113;
wire n_127;
wire n_236;
wire n_100;
wire n_129;
wire n_76;
wire n_134;
wire n_83;
wire n_319;
wire n_133;
wire n_225;
wire n_59;
wire n_131;
wire n_97;
wire n_295;
wire n_108;
wire n_98;
wire n_69;
wire n_94;
wire n_268;
wire n_221;
wire n_212;
wire n_271;
wire n_193;
wire n_289;
wire n_153;
wire n_216;
wire n_74;
wire n_188;
wire n_111;

INVx1_ASAP7_75t_L g46 ( 
.A(n_1),
.Y(n_46)
);

CKINVDCx16_ASAP7_75t_R g47 ( 
.A(n_34),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_19),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_3),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_31),
.Y(n_50)
);

INVxp33_ASAP7_75t_L g51 ( 
.A(n_5),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_33),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_4),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_32),
.Y(n_54)
);

CKINVDCx20_ASAP7_75t_R g55 ( 
.A(n_22),
.Y(n_55)
);

INVxp67_ASAP7_75t_SL g56 ( 
.A(n_7),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_38),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_18),
.Y(n_58)
);

INVxp33_ASAP7_75t_L g59 ( 
.A(n_9),
.Y(n_59)
);

HB1xp67_ASAP7_75t_L g60 ( 
.A(n_3),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_39),
.Y(n_61)
);

CKINVDCx20_ASAP7_75t_R g62 ( 
.A(n_0),
.Y(n_62)
);

CKINVDCx5p33_ASAP7_75t_R g63 ( 
.A(n_40),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_1),
.Y(n_64)
);

OAI21x1_ASAP7_75t_L g65 ( 
.A1(n_54),
.A2(n_23),
.B(n_21),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_50),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_50),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_54),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_52),
.Y(n_69)
);

BUFx6f_ASAP7_75t_L g70 ( 
.A(n_54),
.Y(n_70)
);

NOR2xp33_ASAP7_75t_SL g71 ( 
.A(n_47),
.B(n_24),
.Y(n_71)
);

BUFx6f_ASAP7_75t_L g72 ( 
.A(n_52),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_61),
.Y(n_73)
);

AND2x2_ASAP7_75t_L g74 ( 
.A(n_66),
.B(n_51),
.Y(n_74)
);

INVx3_ASAP7_75t_L g75 ( 
.A(n_72),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_66),
.B(n_61),
.Y(n_76)
);

AND2x2_ASAP7_75t_L g77 ( 
.A(n_66),
.B(n_51),
.Y(n_77)
);

NOR2xp33_ASAP7_75t_L g78 ( 
.A(n_67),
.B(n_59),
.Y(n_78)
);

AND2x4_ASAP7_75t_L g79 ( 
.A(n_67),
.B(n_46),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_72),
.Y(n_80)
);

INVx1_ASAP7_75t_SL g81 ( 
.A(n_71),
.Y(n_81)
);

NAND2xp5_ASAP7_75t_L g82 ( 
.A(n_67),
.B(n_47),
.Y(n_82)
);

NAND2xp5_ASAP7_75t_SL g83 ( 
.A(n_69),
.B(n_57),
.Y(n_83)
);

NAND2xp5_ASAP7_75t_L g84 ( 
.A(n_69),
.B(n_63),
.Y(n_84)
);

BUFx6f_ASAP7_75t_L g85 ( 
.A(n_65),
.Y(n_85)
);

NAND2x1p5_ASAP7_75t_L g86 ( 
.A(n_65),
.B(n_46),
.Y(n_86)
);

NAND2xp5_ASAP7_75t_L g87 ( 
.A(n_77),
.B(n_74),
.Y(n_87)
);

INVx5_ASAP7_75t_L g88 ( 
.A(n_85),
.Y(n_88)
);

BUFx6f_ASAP7_75t_L g89 ( 
.A(n_85),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_79),
.Y(n_90)
);

INVx2_ASAP7_75t_L g91 ( 
.A(n_85),
.Y(n_91)
);

NAND2xp5_ASAP7_75t_L g92 ( 
.A(n_77),
.B(n_69),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_79),
.Y(n_93)
);

INVx4_ASAP7_75t_L g94 ( 
.A(n_79),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_85),
.Y(n_95)
);

NAND2xp5_ASAP7_75t_L g96 ( 
.A(n_77),
.B(n_73),
.Y(n_96)
);

INVx1_ASAP7_75t_L g97 ( 
.A(n_79),
.Y(n_97)
);

AND2x2_ASAP7_75t_L g98 ( 
.A(n_74),
.B(n_60),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_77),
.B(n_73),
.Y(n_99)
);

HB1xp67_ASAP7_75t_L g100 ( 
.A(n_74),
.Y(n_100)
);

NAND2xp5_ASAP7_75t_L g101 ( 
.A(n_74),
.B(n_73),
.Y(n_101)
);

CKINVDCx5p33_ASAP7_75t_R g102 ( 
.A(n_82),
.Y(n_102)
);

NAND2xp5_ASAP7_75t_L g103 ( 
.A(n_82),
.B(n_71),
.Y(n_103)
);

BUFx2_ASAP7_75t_L g104 ( 
.A(n_81),
.Y(n_104)
);

BUFx3_ASAP7_75t_L g105 ( 
.A(n_94),
.Y(n_105)
);

INVxp67_ASAP7_75t_SL g106 ( 
.A(n_94),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_94),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_94),
.Y(n_108)
);

BUFx3_ASAP7_75t_L g109 ( 
.A(n_94),
.Y(n_109)
);

OAI22xp5_ASAP7_75t_L g110 ( 
.A1(n_103),
.A2(n_81),
.B1(n_76),
.B2(n_79),
.Y(n_110)
);

INVxp67_ASAP7_75t_SL g111 ( 
.A(n_100),
.Y(n_111)
);

AND2x2_ASAP7_75t_L g112 ( 
.A(n_100),
.B(n_78),
.Y(n_112)
);

AND2x4_ASAP7_75t_L g113 ( 
.A(n_90),
.B(n_79),
.Y(n_113)
);

OAI22xp5_ASAP7_75t_L g114 ( 
.A1(n_103),
.A2(n_81),
.B1(n_76),
.B2(n_79),
.Y(n_114)
);

INVx2_ASAP7_75t_SL g115 ( 
.A(n_88),
.Y(n_115)
);

AOI21xp33_ASAP7_75t_L g116 ( 
.A1(n_102),
.A2(n_84),
.B(n_78),
.Y(n_116)
);

AOI22xp33_ASAP7_75t_SL g117 ( 
.A1(n_98),
.A2(n_56),
.B1(n_62),
.B2(n_60),
.Y(n_117)
);

NAND2xp33_ASAP7_75t_L g118 ( 
.A(n_89),
.B(n_85),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_90),
.Y(n_119)
);

NAND2xp5_ASAP7_75t_L g120 ( 
.A(n_111),
.B(n_87),
.Y(n_120)
);

AND2x2_ASAP7_75t_L g121 ( 
.A(n_112),
.B(n_98),
.Y(n_121)
);

BUFx4f_ASAP7_75t_SL g122 ( 
.A(n_105),
.Y(n_122)
);

BUFx2_ASAP7_75t_L g123 ( 
.A(n_105),
.Y(n_123)
);

OAI22xp33_ASAP7_75t_SL g124 ( 
.A1(n_111),
.A2(n_86),
.B1(n_56),
.B2(n_104),
.Y(n_124)
);

INVx1_ASAP7_75t_L g125 ( 
.A(n_119),
.Y(n_125)
);

OAI22xp5_ASAP7_75t_L g126 ( 
.A1(n_110),
.A2(n_96),
.B1(n_99),
.B2(n_92),
.Y(n_126)
);

OAI22xp5_ASAP7_75t_L g127 ( 
.A1(n_114),
.A2(n_99),
.B1(n_96),
.B2(n_92),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_112),
.B(n_87),
.Y(n_128)
);

INVx2_ASAP7_75t_L g129 ( 
.A(n_115),
.Y(n_129)
);

AND2x2_ASAP7_75t_L g130 ( 
.A(n_112),
.B(n_98),
.Y(n_130)
);

AND2x2_ASAP7_75t_L g131 ( 
.A(n_121),
.B(n_113),
.Y(n_131)
);

OAI22xp5_ASAP7_75t_L g132 ( 
.A1(n_126),
.A2(n_117),
.B1(n_114),
.B2(n_110),
.Y(n_132)
);

OAI211xp5_ASAP7_75t_L g133 ( 
.A1(n_128),
.A2(n_117),
.B(n_116),
.C(n_62),
.Y(n_133)
);

AOI22xp33_ASAP7_75t_L g134 ( 
.A1(n_121),
.A2(n_116),
.B1(n_109),
.B2(n_105),
.Y(n_134)
);

AOI222xp33_ASAP7_75t_L g135 ( 
.A1(n_130),
.A2(n_101),
.B1(n_59),
.B2(n_119),
.C1(n_49),
.C2(n_48),
.Y(n_135)
);

AOI221xp5_ASAP7_75t_L g136 ( 
.A1(n_130),
.A2(n_101),
.B1(n_119),
.B2(n_113),
.C(n_93),
.Y(n_136)
);

OAI21x1_ASAP7_75t_L g137 ( 
.A1(n_126),
.A2(n_86),
.B(n_91),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_125),
.Y(n_138)
);

OAI22xp33_ASAP7_75t_L g139 ( 
.A1(n_122),
.A2(n_104),
.B1(n_55),
.B2(n_106),
.Y(n_139)
);

NOR2xp33_ASAP7_75t_L g140 ( 
.A(n_120),
.B(n_107),
.Y(n_140)
);

AOI221xp5_ASAP7_75t_L g141 ( 
.A1(n_132),
.A2(n_124),
.B1(n_127),
.B2(n_125),
.C(n_48),
.Y(n_141)
);

OAI22xp5_ASAP7_75t_L g142 ( 
.A1(n_132),
.A2(n_123),
.B1(n_129),
.B2(n_106),
.Y(n_142)
);

OR2x2_ASAP7_75t_SL g143 ( 
.A(n_133),
.B(n_49),
.Y(n_143)
);

AOI221xp5_ASAP7_75t_L g144 ( 
.A1(n_136),
.A2(n_124),
.B1(n_64),
.B2(n_53),
.C(n_58),
.Y(n_144)
);

AO21x2_ASAP7_75t_L g145 ( 
.A1(n_137),
.A2(n_118),
.B(n_65),
.Y(n_145)
);

OR2x2_ASAP7_75t_L g146 ( 
.A(n_131),
.B(n_123),
.Y(n_146)
);

AOI22xp33_ASAP7_75t_L g147 ( 
.A1(n_135),
.A2(n_109),
.B1(n_105),
.B2(n_113),
.Y(n_147)
);

AOI21xp5_ASAP7_75t_L g148 ( 
.A1(n_137),
.A2(n_118),
.B(n_88),
.Y(n_148)
);

OAI221xp5_ASAP7_75t_SL g149 ( 
.A1(n_135),
.A2(n_64),
.B1(n_58),
.B2(n_53),
.C(n_68),
.Y(n_149)
);

AOI22xp5_ASAP7_75t_L g150 ( 
.A1(n_139),
.A2(n_140),
.B1(n_134),
.B2(n_131),
.Y(n_150)
);

INVx2_ASAP7_75t_SL g151 ( 
.A(n_138),
.Y(n_151)
);

AOI222xp33_ASAP7_75t_L g152 ( 
.A1(n_138),
.A2(n_113),
.B1(n_108),
.B2(n_107),
.C1(n_97),
.C2(n_93),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_138),
.Y(n_153)
);

INVx2_ASAP7_75t_L g154 ( 
.A(n_153),
.Y(n_154)
);

NOR2xp33_ASAP7_75t_SL g155 ( 
.A(n_149),
.B(n_115),
.Y(n_155)
);

AOI33xp33_ASAP7_75t_L g156 ( 
.A1(n_147),
.A2(n_68),
.A3(n_108),
.B1(n_107),
.B2(n_113),
.B3(n_97),
.Y(n_156)
);

OR2x6_ASAP7_75t_SL g157 ( 
.A(n_142),
.B(n_68),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_151),
.Y(n_158)
);

AND2x2_ASAP7_75t_L g159 ( 
.A(n_146),
.B(n_129),
.Y(n_159)
);

AND2x2_ASAP7_75t_L g160 ( 
.A(n_150),
.B(n_129),
.Y(n_160)
);

INVx2_ASAP7_75t_L g161 ( 
.A(n_145),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_145),
.Y(n_162)
);

NAND2xp5_ASAP7_75t_L g163 ( 
.A(n_141),
.B(n_68),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_143),
.Y(n_164)
);

HB1xp67_ASAP7_75t_L g165 ( 
.A(n_152),
.Y(n_165)
);

INVx2_ASAP7_75t_L g166 ( 
.A(n_148),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_L g167 ( 
.A(n_144),
.B(n_72),
.Y(n_167)
);

NAND2xp5_ASAP7_75t_L g168 ( 
.A(n_148),
.B(n_86),
.Y(n_168)
);

AOI22xp33_ASAP7_75t_L g169 ( 
.A1(n_149),
.A2(n_72),
.B1(n_109),
.B2(n_113),
.Y(n_169)
);

NAND4xp25_ASAP7_75t_L g170 ( 
.A(n_149),
.B(n_83),
.C(n_84),
.D(n_108),
.Y(n_170)
);

OAI21xp5_ASAP7_75t_SL g171 ( 
.A1(n_150),
.A2(n_86),
.B(n_115),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_153),
.Y(n_172)
);

OAI221xp5_ASAP7_75t_L g173 ( 
.A1(n_149),
.A2(n_83),
.B1(n_86),
.B2(n_72),
.C(n_109),
.Y(n_173)
);

NAND2xp5_ASAP7_75t_L g174 ( 
.A(n_153),
.B(n_72),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_154),
.Y(n_175)
);

NAND2xp5_ASAP7_75t_L g176 ( 
.A(n_172),
.B(n_72),
.Y(n_176)
);

OAI221xp5_ASAP7_75t_L g177 ( 
.A1(n_164),
.A2(n_171),
.B1(n_155),
.B2(n_165),
.C(n_170),
.Y(n_177)
);

OR2x6_ASAP7_75t_L g178 ( 
.A(n_171),
.B(n_115),
.Y(n_178)
);

NAND2xp5_ASAP7_75t_L g179 ( 
.A(n_172),
.B(n_72),
.Y(n_179)
);

HB1xp67_ASAP7_75t_L g180 ( 
.A(n_158),
.Y(n_180)
);

NAND2xp5_ASAP7_75t_L g181 ( 
.A(n_154),
.B(n_0),
.Y(n_181)
);

INVx2_ASAP7_75t_L g182 ( 
.A(n_154),
.Y(n_182)
);

NOR4xp25_ASAP7_75t_SL g183 ( 
.A(n_158),
.B(n_5),
.C(n_4),
.D(n_2),
.Y(n_183)
);

INVx1_ASAP7_75t_L g184 ( 
.A(n_162),
.Y(n_184)
);

NAND2xp5_ASAP7_75t_L g185 ( 
.A(n_160),
.B(n_2),
.Y(n_185)
);

NAND2xp5_ASAP7_75t_L g186 ( 
.A(n_160),
.B(n_159),
.Y(n_186)
);

BUFx2_ASAP7_75t_L g187 ( 
.A(n_168),
.Y(n_187)
);

NAND4xp25_ASAP7_75t_SL g188 ( 
.A(n_156),
.B(n_8),
.C(n_7),
.D(n_6),
.Y(n_188)
);

OAI31xp33_ASAP7_75t_L g189 ( 
.A1(n_170),
.A2(n_9),
.A3(n_8),
.B(n_6),
.Y(n_189)
);

NAND2xp5_ASAP7_75t_L g190 ( 
.A(n_159),
.B(n_10),
.Y(n_190)
);

NAND3xp33_ASAP7_75t_L g191 ( 
.A(n_155),
.B(n_70),
.C(n_85),
.Y(n_191)
);

NAND2xp5_ASAP7_75t_L g192 ( 
.A(n_164),
.B(n_10),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_162),
.B(n_70),
.Y(n_193)
);

INVx1_ASAP7_75t_SL g194 ( 
.A(n_168),
.Y(n_194)
);

BUFx2_ASAP7_75t_SL g195 ( 
.A(n_164),
.Y(n_195)
);

BUFx2_ASAP7_75t_L g196 ( 
.A(n_157),
.Y(n_196)
);

NAND2xp5_ASAP7_75t_L g197 ( 
.A(n_169),
.B(n_11),
.Y(n_197)
);

INVx1_ASAP7_75t_L g198 ( 
.A(n_161),
.Y(n_198)
);

INVx2_ASAP7_75t_L g199 ( 
.A(n_161),
.Y(n_199)
);

NAND2xp5_ASAP7_75t_L g200 ( 
.A(n_157),
.B(n_11),
.Y(n_200)
);

OR2x2_ASAP7_75t_L g201 ( 
.A(n_161),
.B(n_70),
.Y(n_201)
);

INVx1_ASAP7_75t_L g202 ( 
.A(n_166),
.Y(n_202)
);

INVx1_ASAP7_75t_L g203 ( 
.A(n_166),
.Y(n_203)
);

NAND2xp5_ASAP7_75t_L g204 ( 
.A(n_174),
.B(n_163),
.Y(n_204)
);

BUFx2_ASAP7_75t_L g205 ( 
.A(n_166),
.Y(n_205)
);

AND2x2_ASAP7_75t_L g206 ( 
.A(n_167),
.B(n_70),
.Y(n_206)
);

INVx1_ASAP7_75t_L g207 ( 
.A(n_180),
.Y(n_207)
);

O2A1O1Ixp33_ASAP7_75t_L g208 ( 
.A1(n_192),
.A2(n_173),
.B(n_80),
.C(n_12),
.Y(n_208)
);

OR2x2_ASAP7_75t_L g209 ( 
.A(n_187),
.B(n_70),
.Y(n_209)
);

OAI21xp5_ASAP7_75t_L g210 ( 
.A1(n_189),
.A2(n_80),
.B(n_88),
.Y(n_210)
);

NAND2xp5_ASAP7_75t_L g211 ( 
.A(n_186),
.B(n_12),
.Y(n_211)
);

AOI21xp5_ASAP7_75t_L g212 ( 
.A1(n_178),
.A2(n_88),
.B(n_91),
.Y(n_212)
);

INVx1_ASAP7_75t_L g213 ( 
.A(n_175),
.Y(n_213)
);

OR2x2_ASAP7_75t_L g214 ( 
.A(n_187),
.B(n_70),
.Y(n_214)
);

INVx2_ASAP7_75t_L g215 ( 
.A(n_182),
.Y(n_215)
);

AOI21xp33_ASAP7_75t_L g216 ( 
.A1(n_189),
.A2(n_200),
.B(n_177),
.Y(n_216)
);

INVxp67_ASAP7_75t_L g217 ( 
.A(n_196),
.Y(n_217)
);

INVxp67_ASAP7_75t_L g218 ( 
.A(n_196),
.Y(n_218)
);

NOR2xp33_ASAP7_75t_L g219 ( 
.A(n_195),
.B(n_13),
.Y(n_219)
);

NAND2xp5_ASAP7_75t_L g220 ( 
.A(n_175),
.B(n_13),
.Y(n_220)
);

INVx2_ASAP7_75t_SL g221 ( 
.A(n_201),
.Y(n_221)
);

INVx1_ASAP7_75t_L g222 ( 
.A(n_182),
.Y(n_222)
);

AND2x2_ASAP7_75t_L g223 ( 
.A(n_194),
.B(n_70),
.Y(n_223)
);

NAND2xp5_ASAP7_75t_L g224 ( 
.A(n_195),
.B(n_14),
.Y(n_224)
);

INVx1_ASAP7_75t_L g225 ( 
.A(n_184),
.Y(n_225)
);

AOI21xp33_ASAP7_75t_SL g226 ( 
.A1(n_178),
.A2(n_15),
.B(n_14),
.Y(n_226)
);

AOI221xp5_ASAP7_75t_L g227 ( 
.A1(n_188),
.A2(n_70),
.B1(n_80),
.B2(n_75),
.C(n_15),
.Y(n_227)
);

AOI22xp33_ASAP7_75t_L g228 ( 
.A1(n_178),
.A2(n_85),
.B1(n_89),
.B2(n_88),
.Y(n_228)
);

AND2x2_ASAP7_75t_L g229 ( 
.A(n_194),
.B(n_16),
.Y(n_229)
);

OAI21xp33_ASAP7_75t_L g230 ( 
.A1(n_178),
.A2(n_85),
.B(n_16),
.Y(n_230)
);

AOI22xp5_ASAP7_75t_L g231 ( 
.A1(n_178),
.A2(n_85),
.B1(n_88),
.B2(n_89),
.Y(n_231)
);

INVx1_ASAP7_75t_L g232 ( 
.A(n_181),
.Y(n_232)
);

INVx1_ASAP7_75t_L g233 ( 
.A(n_176),
.Y(n_233)
);

INVx1_ASAP7_75t_L g234 ( 
.A(n_179),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_193),
.Y(n_235)
);

AOI21xp5_ASAP7_75t_L g236 ( 
.A1(n_191),
.A2(n_88),
.B(n_91),
.Y(n_236)
);

HB1xp67_ASAP7_75t_L g237 ( 
.A(n_201),
.Y(n_237)
);

O2A1O1Ixp33_ASAP7_75t_L g238 ( 
.A1(n_185),
.A2(n_19),
.B(n_18),
.C(n_17),
.Y(n_238)
);

AOI222xp33_ASAP7_75t_L g239 ( 
.A1(n_190),
.A2(n_85),
.B1(n_20),
.B2(n_17),
.C1(n_89),
.C2(n_88),
.Y(n_239)
);

INVx1_ASAP7_75t_L g240 ( 
.A(n_193),
.Y(n_240)
);

INVx1_ASAP7_75t_L g241 ( 
.A(n_198),
.Y(n_241)
);

AND2x2_ASAP7_75t_L g242 ( 
.A(n_198),
.B(n_20),
.Y(n_242)
);

OAI221xp5_ASAP7_75t_L g243 ( 
.A1(n_197),
.A2(n_75),
.B1(n_95),
.B2(n_89),
.C(n_25),
.Y(n_243)
);

INVx1_ASAP7_75t_L g244 ( 
.A(n_207),
.Y(n_244)
);

INVx1_ASAP7_75t_L g245 ( 
.A(n_225),
.Y(n_245)
);

NAND2xp33_ASAP7_75t_SL g246 ( 
.A(n_229),
.B(n_183),
.Y(n_246)
);

INVx1_ASAP7_75t_L g247 ( 
.A(n_213),
.Y(n_247)
);

NOR2xp33_ASAP7_75t_L g248 ( 
.A(n_216),
.B(n_204),
.Y(n_248)
);

NAND2xp5_ASAP7_75t_L g249 ( 
.A(n_232),
.B(n_199),
.Y(n_249)
);

NAND2xp5_ASAP7_75t_L g250 ( 
.A(n_237),
.B(n_199),
.Y(n_250)
);

XNOR2x2_ASAP7_75t_L g251 ( 
.A(n_219),
.B(n_191),
.Y(n_251)
);

INVx1_ASAP7_75t_SL g252 ( 
.A(n_237),
.Y(n_252)
);

XOR2xp5_ASAP7_75t_L g253 ( 
.A(n_211),
.B(n_206),
.Y(n_253)
);

AND2x2_ASAP7_75t_L g254 ( 
.A(n_217),
.B(n_205),
.Y(n_254)
);

NOR2xp33_ASAP7_75t_L g255 ( 
.A(n_218),
.B(n_206),
.Y(n_255)
);

AND2x2_ASAP7_75t_L g256 ( 
.A(n_221),
.B(n_205),
.Y(n_256)
);

INVx2_ASAP7_75t_L g257 ( 
.A(n_215),
.Y(n_257)
);

INVx1_ASAP7_75t_L g258 ( 
.A(n_209),
.Y(n_258)
);

OAI21xp5_ASAP7_75t_SL g259 ( 
.A1(n_226),
.A2(n_203),
.B(n_202),
.Y(n_259)
);

NAND2xp5_ASAP7_75t_L g260 ( 
.A(n_229),
.B(n_202),
.Y(n_260)
);

NAND2x1_ASAP7_75t_L g261 ( 
.A(n_219),
.B(n_203),
.Y(n_261)
);

AOI321xp33_ASAP7_75t_L g262 ( 
.A1(n_238),
.A2(n_183),
.A3(n_95),
.B1(n_75),
.B2(n_27),
.C(n_26),
.Y(n_262)
);

OR2x2_ASAP7_75t_L g263 ( 
.A(n_221),
.B(n_28),
.Y(n_263)
);

INVx1_ASAP7_75t_L g264 ( 
.A(n_209),
.Y(n_264)
);

AND3x1_ASAP7_75t_L g265 ( 
.A(n_230),
.B(n_30),
.C(n_29),
.Y(n_265)
);

CKINVDCx14_ASAP7_75t_R g266 ( 
.A(n_214),
.Y(n_266)
);

INVx1_ASAP7_75t_L g267 ( 
.A(n_241),
.Y(n_267)
);

INVx1_ASAP7_75t_L g268 ( 
.A(n_222),
.Y(n_268)
);

OR2x2_ASAP7_75t_L g269 ( 
.A(n_235),
.B(n_35),
.Y(n_269)
);

INVx1_ASAP7_75t_L g270 ( 
.A(n_240),
.Y(n_270)
);

INVxp33_ASAP7_75t_SL g271 ( 
.A(n_242),
.Y(n_271)
);

INVx1_ASAP7_75t_L g272 ( 
.A(n_242),
.Y(n_272)
);

NAND2x1p5_ASAP7_75t_L g273 ( 
.A(n_231),
.B(n_89),
.Y(n_273)
);

NAND2xp5_ASAP7_75t_SL g274 ( 
.A(n_228),
.B(n_89),
.Y(n_274)
);

OR2x2_ASAP7_75t_L g275 ( 
.A(n_233),
.B(n_36),
.Y(n_275)
);

OR2x2_ASAP7_75t_L g276 ( 
.A(n_252),
.B(n_234),
.Y(n_276)
);

OA22x2_ASAP7_75t_L g277 ( 
.A1(n_259),
.A2(n_224),
.B1(n_210),
.B2(n_220),
.Y(n_277)
);

NAND2xp5_ASAP7_75t_L g278 ( 
.A(n_270),
.B(n_223),
.Y(n_278)
);

AOI211xp5_ASAP7_75t_L g279 ( 
.A1(n_248),
.A2(n_208),
.B(n_227),
.C(n_212),
.Y(n_279)
);

INVx1_ASAP7_75t_L g280 ( 
.A(n_249),
.Y(n_280)
);

NAND2xp5_ASAP7_75t_SL g281 ( 
.A(n_265),
.B(n_271),
.Y(n_281)
);

OAI21xp5_ASAP7_75t_L g282 ( 
.A1(n_248),
.A2(n_239),
.B(n_228),
.Y(n_282)
);

AOI211x1_ASAP7_75t_SL g283 ( 
.A1(n_251),
.A2(n_260),
.B(n_274),
.C(n_250),
.Y(n_283)
);

OAI222xp33_ASAP7_75t_L g284 ( 
.A1(n_261),
.A2(n_223),
.B1(n_243),
.B2(n_236),
.C1(n_95),
.C2(n_37),
.Y(n_284)
);

OR2x2_ASAP7_75t_L g285 ( 
.A(n_244),
.B(n_41),
.Y(n_285)
);

NAND3xp33_ASAP7_75t_L g286 ( 
.A(n_246),
.B(n_75),
.C(n_42),
.Y(n_286)
);

INVxp67_ASAP7_75t_L g287 ( 
.A(n_255),
.Y(n_287)
);

INVx1_ASAP7_75t_L g288 ( 
.A(n_247),
.Y(n_288)
);

NAND2xp5_ASAP7_75t_L g289 ( 
.A(n_272),
.B(n_43),
.Y(n_289)
);

INVxp33_ASAP7_75t_L g290 ( 
.A(n_274),
.Y(n_290)
);

AOI21xp33_ASAP7_75t_L g291 ( 
.A1(n_253),
.A2(n_45),
.B(n_44),
.Y(n_291)
);

AND2x2_ASAP7_75t_L g292 ( 
.A(n_254),
.B(n_75),
.Y(n_292)
);

INVxp67_ASAP7_75t_L g293 ( 
.A(n_255),
.Y(n_293)
);

NAND2xp5_ASAP7_75t_L g294 ( 
.A(n_258),
.B(n_75),
.Y(n_294)
);

O2A1O1Ixp33_ASAP7_75t_L g295 ( 
.A1(n_271),
.A2(n_266),
.B(n_264),
.C(n_263),
.Y(n_295)
);

INVx2_ASAP7_75t_SL g296 ( 
.A(n_276),
.Y(n_296)
);

CKINVDCx16_ASAP7_75t_R g297 ( 
.A(n_282),
.Y(n_297)
);

OAI211xp5_ASAP7_75t_L g298 ( 
.A1(n_281),
.A2(n_246),
.B(n_266),
.C(n_262),
.Y(n_298)
);

NOR3xp33_ASAP7_75t_L g299 ( 
.A(n_286),
.B(n_275),
.C(n_267),
.Y(n_299)
);

XNOR2xp5_ASAP7_75t_L g300 ( 
.A(n_281),
.B(n_251),
.Y(n_300)
);

AND2x4_ASAP7_75t_L g301 ( 
.A(n_280),
.B(n_256),
.Y(n_301)
);

NOR2xp33_ASAP7_75t_R g302 ( 
.A(n_285),
.B(n_269),
.Y(n_302)
);

INVx1_ASAP7_75t_SL g303 ( 
.A(n_292),
.Y(n_303)
);

NOR2x1_ASAP7_75t_L g304 ( 
.A(n_284),
.B(n_268),
.Y(n_304)
);

CKINVDCx16_ASAP7_75t_R g305 ( 
.A(n_285),
.Y(n_305)
);

INVx1_ASAP7_75t_L g306 ( 
.A(n_288),
.Y(n_306)
);

NAND2xp33_ASAP7_75t_R g307 ( 
.A(n_283),
.B(n_257),
.Y(n_307)
);

NOR3xp33_ASAP7_75t_L g308 ( 
.A(n_297),
.B(n_279),
.C(n_292),
.Y(n_308)
);

NAND5xp2_ASAP7_75t_L g309 ( 
.A(n_298),
.B(n_295),
.C(n_291),
.D(n_290),
.E(n_273),
.Y(n_309)
);

OAI21xp33_ASAP7_75t_SL g310 ( 
.A1(n_304),
.A2(n_277),
.B(n_290),
.Y(n_310)
);

OAI221xp5_ASAP7_75t_L g311 ( 
.A1(n_300),
.A2(n_277),
.B1(n_293),
.B2(n_287),
.C(n_278),
.Y(n_311)
);

OR5x1_ASAP7_75t_L g312 ( 
.A(n_307),
.B(n_305),
.C(n_296),
.D(n_303),
.E(n_302),
.Y(n_312)
);

AND4x1_ASAP7_75t_L g313 ( 
.A(n_299),
.B(n_289),
.C(n_294),
.D(n_245),
.Y(n_313)
);

NOR2xp67_ASAP7_75t_L g314 ( 
.A(n_310),
.B(n_306),
.Y(n_314)
);

CKINVDCx5p33_ASAP7_75t_R g315 ( 
.A(n_312),
.Y(n_315)
);

INVx1_ASAP7_75t_L g316 ( 
.A(n_308),
.Y(n_316)
);

OR3x1_ASAP7_75t_L g317 ( 
.A(n_316),
.B(n_309),
.C(n_311),
.Y(n_317)
);

INVx1_ASAP7_75t_L g318 ( 
.A(n_314),
.Y(n_318)
);

HB1xp67_ASAP7_75t_L g319 ( 
.A(n_318),
.Y(n_319)
);

AOI22xp5_ASAP7_75t_L g320 ( 
.A1(n_319),
.A2(n_317),
.B1(n_315),
.B2(n_303),
.Y(n_320)
);

AOI22xp33_ASAP7_75t_SL g321 ( 
.A1(n_320),
.A2(n_315),
.B1(n_317),
.B2(n_301),
.Y(n_321)
);

AOI21xp5_ASAP7_75t_L g322 ( 
.A1(n_321),
.A2(n_301),
.B(n_313),
.Y(n_322)
);


endmodule