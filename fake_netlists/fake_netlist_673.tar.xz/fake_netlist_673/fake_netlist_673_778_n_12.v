module fake_netlist_673_778_n_12 (n_3, n_1, n_2, n_0, n_12);

input n_3;
input n_1;
input n_2;
input n_0;

output n_12;

wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_6;
wire n_11;
wire n_8;
wire n_9;

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

OAI22xp33_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

INVxp67_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_5),
.Y(n_9)
);

OAI31xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_6),
.A3(n_5),
.B(n_4),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule