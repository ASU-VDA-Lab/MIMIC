module fake_netlist_673_240_n_16 (n_4, n_1, n_2, n_0, n_5, n_3, n_16);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_16;

wire n_7;
wire n_14;
wire n_13;
wire n_10;
wire n_12;
wire n_6;
wire n_8;
wire n_15;
wire n_11;
wire n_9;

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_1),
.Y(n_6)
);

CKINVDCx16_ASAP7_75t_R g7 ( 
.A(n_1),
.Y(n_7)
);

INVxp67_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_11),
.B1(n_8),
.B2(n_6),
.C(n_0),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_13),
.B(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_4),
.B1(n_5),
.B2(n_2),
.Y(n_16)
);


endmodule