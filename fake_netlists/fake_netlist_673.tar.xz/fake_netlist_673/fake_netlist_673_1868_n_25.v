module fake_netlist_673_1868_n_25 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_25);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_25;

wire n_18;
wire n_19;
wire n_24;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

OAI22xp33_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_3),
.B1(n_0),
.B2(n_6),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_11),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_5),
.B(n_9),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_8),
.B(n_4),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_10),
.B(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_12),
.C(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_1),
.Y(n_21)
);

NAND5xp2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_17),
.C(n_12),
.D(n_15),
.E(n_1),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_22),
.B(n_21),
.Y(n_23)
);

AO22x2_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_2),
.B1(n_6),
.B2(n_23),
.Y(n_25)
);


endmodule