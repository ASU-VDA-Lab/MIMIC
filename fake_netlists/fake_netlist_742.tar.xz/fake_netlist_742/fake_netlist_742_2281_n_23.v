module fake_netlist_742_2281_n_23 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_23);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_23;

wire n_20;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

AND2x2_ASAP7_75t_SL g13 ( 
.A(n_0),
.B(n_9),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

NOR2x1p5_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_2),
.Y(n_15)
);

OR2x6_ASAP7_75t_L g16 ( 
.A(n_1),
.B(n_7),
.Y(n_16)
);

OAI22x1_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_6),
.B1(n_4),
.B2(n_5),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.B1(n_16),
.B2(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OA22x2_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_6),
.B1(n_10),
.B2(n_8),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_12),
.B(n_11),
.Y(n_23)
);


endmodule