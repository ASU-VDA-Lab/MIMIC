module fake_netlist_742_1389_n_24 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_24);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_24;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;

INVxp33_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_9),
.A2(n_6),
.B1(n_0),
.B2(n_7),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

CKINVDCx6p67_ASAP7_75t_R g17 ( 
.A(n_14),
.Y(n_17)
);

CKINVDCx16_ASAP7_75t_R g18 ( 
.A(n_16),
.Y(n_18)
);

INVx2_ASAP7_75t_SL g19 ( 
.A(n_18),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

O2A1O1Ixp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B(n_12),
.C(n_15),
.Y(n_21)
);

NOR2x1_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_4),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_7),
.B(n_5),
.Y(n_23)
);

AO21x2_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_10),
.B(n_8),
.Y(n_24)
);


endmodule