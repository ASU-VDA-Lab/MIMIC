module fake_netlist_742_346_n_33 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_33);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_33;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_12;
wire n_29;
wire n_32;

AND2x6_ASAP7_75t_L g10 ( 
.A(n_2),
.B(n_8),
.Y(n_10)
);

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

AOI21xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_14),
.B(n_13),
.Y(n_18)
);

OAI21x1_ASAP7_75t_SL g19 ( 
.A1(n_17),
.A2(n_14),
.B(n_10),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_15),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_15),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_10),
.B1(n_15),
.B2(n_12),
.Y(n_26)
);

AOI21xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_5),
.B(n_4),
.Y(n_27)
);

NOR2x1_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_12),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_5),
.Y(n_29)
);

AOI211x1_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_7),
.B(n_6),
.C(n_0),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_7),
.Y(n_31)
);

AOI211xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_1),
.B(n_30),
.C(n_27),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_32),
.Y(n_33)
);


endmodule