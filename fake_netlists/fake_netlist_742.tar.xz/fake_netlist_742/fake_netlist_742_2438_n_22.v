module fake_netlist_742_2438_n_22 (n_1, n_2, n_3, n_4, n_5, n_0, n_22);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_22;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

INVx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

BUFx10_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

BUFx10_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_7),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_7),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_0),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_11),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_8),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_14),
.B(n_13),
.Y(n_17)
);

OAI211xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_8),
.B(n_1),
.C(n_0),
.Y(n_18)
);

NAND4xp75_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.C(n_3),
.D(n_2),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_SL g20 ( 
.A1(n_17),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_20)
);

AOI22x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_4),
.B1(n_5),
.B2(n_19),
.Y(n_21)
);

OAI222xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_4),
.B1(n_5),
.B2(n_14),
.C1(n_10),
.C2(n_13),
.Y(n_22)
);


endmodule