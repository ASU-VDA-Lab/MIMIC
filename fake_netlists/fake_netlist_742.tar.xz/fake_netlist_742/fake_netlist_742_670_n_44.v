module fake_netlist_742_670_n_44 (n_12, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_44);

input n_12;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_44;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_15;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_10),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_SL g17 ( 
.A1(n_4),
.A2(n_6),
.B1(n_3),
.B2(n_14),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_7),
.B(n_8),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_18),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_18),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_0),
.Y(n_25)
);

OAI21x1_ASAP7_75t_L g26 ( 
.A1(n_15),
.A2(n_13),
.B(n_12),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_22),
.A2(n_19),
.B1(n_16),
.B2(n_17),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_23),
.Y(n_29)
);

NOR2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_24),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_29),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVxp67_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_26),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_35),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_36),
.Y(n_40)
);

NOR2x1_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_20),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_39),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_42),
.B1(n_41),
.B2(n_2),
.Y(n_44)
);


endmodule