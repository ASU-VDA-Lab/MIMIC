module fake_netlist_742_194_n_44 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_44);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_44;

wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_4),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_19),
.B(n_11),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_20),
.B(n_10),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_R g29 ( 
.A(n_18),
.B(n_15),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_21),
.A2(n_1),
.B(n_0),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_7),
.B1(n_3),
.B2(n_2),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_R g33 ( 
.A(n_30),
.B(n_22),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_26),
.Y(n_34)
);

NOR2xp67_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_25),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_24),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_35),
.B(n_26),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_31),
.B1(n_28),
.B2(n_27),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_39),
.B(n_8),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_41),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_14),
.B1(n_13),
.B2(n_9),
.Y(n_44)
);


endmodule