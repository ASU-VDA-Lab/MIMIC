module fake_netlist_742_2230_n_41 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_41);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_41;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

INVx2_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_0),
.Y(n_26)
);

BUFx12f_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_23),
.B(n_18),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_26),
.B(n_21),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_29),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_27),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI311xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_35),
.A3(n_24),
.B(n_22),
.C(n_1),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_6),
.B1(n_4),
.B2(n_2),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

CKINVDCx16_ASAP7_75t_R g39 ( 
.A(n_36),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AOI322xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_39),
.A3(n_12),
.B1(n_11),
.B2(n_10),
.C1(n_15),
.C2(n_14),
.Y(n_41)
);


endmodule