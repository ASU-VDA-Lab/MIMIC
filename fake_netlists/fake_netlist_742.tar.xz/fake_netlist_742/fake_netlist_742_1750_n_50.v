module fake_netlist_742_1750_n_50 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_50);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_50;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVxp67_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_8),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_10),
.B(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_1),
.B(n_15),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_12),
.B(n_0),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_4),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_20),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_18),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

AO22x1_ASAP7_75t_SL g30 ( 
.A1(n_26),
.A2(n_21),
.B1(n_6),
.B2(n_5),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_19),
.B1(n_23),
.B2(n_24),
.Y(n_32)
);

AOI221xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_25),
.B1(n_22),
.B2(n_17),
.C(n_19),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

NAND2xp33_ASAP7_75t_SL g36 ( 
.A(n_34),
.B(n_23),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_16),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_19),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_33),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_29),
.B(n_24),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_29),
.B(n_24),
.Y(n_43)
);

O2A1O1Ixp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_24),
.B(n_9),
.C(n_3),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

A2O1A1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_24),
.B(n_29),
.C(n_13),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_29),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_14),
.B1(n_47),
.B2(n_49),
.Y(n_50)
);


endmodule