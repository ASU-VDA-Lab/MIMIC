module fake_netlist_742_475_n_22 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_22);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_22;

wire n_20;
wire n_14;
wire n_18;
wire n_16;
wire n_13;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;

AND2x6_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_11),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_1),
.B(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

AND2x6_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_0),
.Y(n_16)
);

AO31x2_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_7),
.A3(n_3),
.B(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI322xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.A3(n_7),
.B1(n_16),
.B2(n_12),
.C1(n_4),
.C2(n_5),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_12),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

BUFx2_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);


endmodule