module fake_netlist_742_1111_n_9 (n_0, n_1, n_9);

input n_0;
input n_1;

output n_9;

wire n_2;
wire n_3;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

INVx1_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

NOR2xp33_ASAP7_75t_SL g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

OAI221xp5_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_5),
.B1(n_2),
.B2(n_4),
.C(n_0),
.Y(n_7)
);

AOI222xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_0),
.B1(n_1),
.B2(n_5),
.C1(n_4),
.C2(n_3),
.Y(n_8)
);

AOI222xp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_0),
.B1(n_1),
.B2(n_7),
.C1(n_2),
.C2(n_5),
.Y(n_9)
);


endmodule