module fake_netlist_742_327_n_43 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_43);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_43;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_41;
wire n_29;
wire n_32;

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_R g21 ( 
.A(n_3),
.B(n_12),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_9),
.B(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_0),
.Y(n_24)
);

BUFx8_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_6),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_SL g29 ( 
.A1(n_20),
.A2(n_19),
.B1(n_18),
.B2(n_2),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_27),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_18),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_29),
.Y(n_34)
);

NOR2x1_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_21),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_26),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_35),
.B(n_25),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_19),
.Y(n_38)
);

AOI222xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_25),
.B1(n_22),
.B2(n_11),
.C1(n_8),
.C2(n_7),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

CKINVDCx20_ASAP7_75t_R g41 ( 
.A(n_40),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_39),
.Y(n_42)
);

OAI321xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_13),
.A3(n_15),
.B1(n_16),
.B2(n_17),
.C(n_41),
.Y(n_43)
);


endmodule