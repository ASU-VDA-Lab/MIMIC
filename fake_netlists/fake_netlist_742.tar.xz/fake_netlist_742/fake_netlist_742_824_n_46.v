module fake_netlist_742_824_n_46 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_46);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_46;

wire n_23;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_37;
wire n_27;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_3),
.B(n_10),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_17),
.A2(n_14),
.B1(n_19),
.B2(n_13),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_11),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_1),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_0),
.Y(n_29)
);

BUFx8_ASAP7_75t_SL g30 ( 
.A(n_26),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_18),
.Y(n_32)
);

OAI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_22),
.B1(n_29),
.B2(n_25),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_34),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

INVxp33_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_23),
.Y(n_38)
);

NOR3xp33_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_30),
.C(n_18),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AO21x2_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_27),
.B(n_25),
.Y(n_41)
);

XNOR2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_27),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_30),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_4),
.B(n_2),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_SL g45 ( 
.A1(n_43),
.A2(n_42),
.B1(n_7),
.B2(n_6),
.Y(n_45)
);

AOI322xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_44),
.A3(n_12),
.B1(n_9),
.B2(n_8),
.C1(n_21),
.C2(n_16),
.Y(n_46)
);


endmodule