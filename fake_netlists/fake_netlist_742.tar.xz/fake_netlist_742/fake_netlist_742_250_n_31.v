module fake_netlist_742_250_n_31 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_31);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_31;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_29;

AOI22xp5_ASAP7_75t_SL g12 ( 
.A1(n_6),
.A2(n_5),
.B1(n_7),
.B2(n_3),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_2),
.C(n_1),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_7),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_4),
.Y(n_19)
);

OA21x2_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_4),
.B(n_0),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_13),
.A2(n_9),
.B(n_15),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_12),
.B1(n_13),
.B2(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_17),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_20),
.B(n_22),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

AOI211xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_22),
.B(n_23),
.C(n_17),
.Y(n_27)
);

NOR2xp67_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_17),
.Y(n_28)
);

NAND2x1p5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_20),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_17),
.B1(n_20),
.B2(n_29),
.Y(n_31)
);


endmodule