module fake_netlist_742_1883_n_23 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_23);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_23;

wire n_20;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_1),
.B(n_2),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_SL g15 ( 
.A1(n_0),
.A2(n_3),
.B1(n_5),
.B2(n_10),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

AO32x2_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_12),
.A3(n_16),
.B1(n_13),
.B2(n_14),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_12),
.B1(n_4),
.B2(n_1),
.C(n_2),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_4),
.Y(n_19)
);

AOI211xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.B(n_6),
.C(n_5),
.Y(n_20)
);

NAND3xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_7),
.C(n_6),
.Y(n_21)
);

NAND4xp25_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_10),
.C(n_8),
.D(n_7),
.Y(n_22)
);

O2A1O1Ixp33_ASAP7_75t_R g23 ( 
.A1(n_22),
.A2(n_11),
.B(n_8),
.C(n_9),
.Y(n_23)
);


endmodule