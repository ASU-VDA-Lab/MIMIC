module fake_netlist_742_1733_n_48 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_48);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_48;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

AND2x2_ASAP7_75t_L g18 ( 
.A(n_0),
.B(n_7),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_4),
.B(n_12),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_8),
.B(n_13),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_6),
.B(n_15),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_11),
.B(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_1),
.B(n_10),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_2),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

CKINVDCx11_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22x1_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_21),
.B1(n_20),
.B2(n_18),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_27),
.A2(n_26),
.B(n_23),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_33),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_29),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_37),
.B(n_20),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

A2O1A1Ixp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_29),
.B(n_22),
.C(n_23),
.Y(n_42)
);

O2A1O1Ixp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_32),
.B(n_28),
.C(n_3),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

OAI21xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_28),
.B(n_9),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_R g47 ( 
.A(n_45),
.B(n_46),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);


endmodule