module fake_netlist_742_181_n_28 (n_1, n_2, n_3, n_4, n_0, n_28);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_28;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_27;
wire n_24;
wire n_10;
wire n_5;
wire n_26;
wire n_6;
wire n_9;
wire n_25;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

NAND3xp33_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_0),
.C(n_4),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_6),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_7),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_9),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_10),
.B(n_7),
.C(n_8),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_10),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_10),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_19),
.B(n_18),
.C(n_6),
.Y(n_20)
);

NAND3xp33_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_5),
.C(n_8),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_14),
.B(n_11),
.Y(n_22)
);

NAND4xp75_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_8),
.C(n_5),
.D(n_11),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_11),
.C(n_2),
.D(n_0),
.Y(n_24)
);

AND3x2_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_4),
.C(n_13),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_13),
.B(n_4),
.Y(n_26)
);

XNOR2x1_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_13),
.Y(n_27)
);

AOI22x1_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_13),
.B1(n_24),
.B2(n_27),
.Y(n_28)
);


endmodule