module fake_netlist_656_2318_n_26 (n_9, n_4, n_7, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_26);

input n_9;
input n_4;
input n_7;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_26;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_21;

INVx1_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_3),
.Y(n_15)
);

BUFx10_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_1),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_4),
.B(n_0),
.Y(n_19)
);

OAI21x1_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_9),
.B(n_6),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_17),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_20),
.C(n_17),
.Y(n_23)
);

NAND2x1_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_16),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_16),
.B1(n_7),
.B2(n_11),
.Y(n_25)
);

OAI22xp33_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_7),
.B1(n_13),
.B2(n_12),
.Y(n_26)
);


endmodule