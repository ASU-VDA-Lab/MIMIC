module fake_netlist_656_2992_n_15 (n_3, n_1, n_2, n_0, n_15);

input n_3;
input n_1;
input n_2;
input n_0;

output n_15;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;

OAI22xp33_ASAP7_75t_SL g4 ( 
.A1(n_0),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.Y(n_4)
);

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_4),
.B1(n_5),
.B2(n_0),
.C(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

NAND2x1_ASAP7_75t_SL g10 ( 
.A(n_8),
.B(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_6),
.B(n_9),
.C(n_5),
.Y(n_12)
);

OAI222xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_3),
.C2(n_10),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_0),
.B1(n_3),
.B2(n_12),
.C1(n_13),
.C2(n_8),
.Y(n_15)
);


endmodule