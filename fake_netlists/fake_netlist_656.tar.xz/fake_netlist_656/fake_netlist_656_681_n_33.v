module fake_netlist_656_681_n_33 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_33);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_33;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_32;
wire n_13;

BUFx3_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_15),
.B(n_8),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_13),
.B1(n_12),
.B2(n_16),
.Y(n_20)
);

BUFx8_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

OAI222xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_13),
.B1(n_12),
.B2(n_16),
.C1(n_19),
.C2(n_17),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_18),
.B1(n_19),
.B2(n_14),
.C(n_0),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_22),
.B(n_0),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_2),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_24),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_2),
.Y(n_27)
);

AOI222xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_25),
.B1(n_27),
.B2(n_14),
.C1(n_4),
.C2(n_3),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_4),
.B(n_3),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_30),
.B2(n_5),
.Y(n_33)
);


endmodule