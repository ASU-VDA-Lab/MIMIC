module fake_netlist_656_260_n_35 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_35);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_35;

wire n_18;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_3),
.B(n_11),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_7),
.B(n_2),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_12),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

OR2x6_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_4),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_22),
.B1(n_16),
.B2(n_20),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_19),
.B1(n_15),
.B2(n_4),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_23),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NAND2x1_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_0),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_SL g32 ( 
.A1(n_30),
.A2(n_29),
.B1(n_7),
.B2(n_5),
.C(n_6),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_SL g33 ( 
.A(n_31),
.B(n_6),
.C(n_5),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

OAI221xp5_ASAP7_75t_R g35 ( 
.A1(n_34),
.A2(n_32),
.B1(n_10),
.B2(n_1),
.C(n_9),
.Y(n_35)
);


endmodule