module fake_netlist_656_3540_n_14 (n_1, n_2, n_0, n_14);

input n_1;
input n_2;
input n_0;

output n_14;

wire n_9;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;
wire n_3;

BUFx6f_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

XNOR2xp5_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_7),
.B1(n_3),
.B2(n_5),
.C(n_8),
.Y(n_11)
);

OA22x2_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_6),
.B1(n_1),
.B2(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_1),
.B1(n_3),
.B2(n_6),
.C1(n_11),
.C2(n_13),
.Y(n_14)
);


endmodule