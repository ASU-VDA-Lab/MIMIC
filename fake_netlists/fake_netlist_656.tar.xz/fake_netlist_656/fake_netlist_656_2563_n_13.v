module fake_netlist_656_2563_n_13 (n_3, n_1, n_2, n_0, n_13);

input n_3;
input n_1;
input n_2;
input n_0;

output n_13;

wire n_9;
wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_0),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_2),
.B(n_1),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

AO21x2_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_3),
.B(n_2),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_3),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.C(n_6),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_7),
.B1(n_9),
.B2(n_10),
.Y(n_12)
);

XNOR2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_9),
.Y(n_13)
);


endmodule