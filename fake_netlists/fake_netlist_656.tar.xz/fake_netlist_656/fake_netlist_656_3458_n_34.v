module fake_netlist_656_3458_n_34 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_34);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_34;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_7;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_9;
wire n_32;
wire n_13;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

INVxp67_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_12),
.B(n_1),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_9),
.A2(n_5),
.B(n_4),
.Y(n_15)
);

O2A1O1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

OR2x6_ASAP7_75t_L g18 ( 
.A(n_8),
.B(n_5),
.Y(n_18)
);

AO31x2_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_11),
.A3(n_6),
.B(n_10),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_17),
.B(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_7),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_18),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_14),
.B1(n_15),
.B2(n_16),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.B(n_6),
.C(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_23),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_24),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_19),
.C(n_2),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_29),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

INVxp33_ASAP7_75t_SL g33 ( 
.A(n_32),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_30),
.B1(n_31),
.B2(n_32),
.Y(n_34)
);


endmodule