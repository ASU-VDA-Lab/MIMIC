module fake_netlist_656_472_n_18 (n_4, n_1, n_2, n_0, n_5, n_3, n_18);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_18;

wire n_7;
wire n_17;
wire n_14;
wire n_15;
wire n_13;
wire n_12;
wire n_6;
wire n_10;
wire n_11;
wire n_8;
wire n_16;
wire n_9;

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_0),
.B(n_4),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

OA21x2_ASAP7_75t_L g12 ( 
.A1(n_6),
.A2(n_1),
.B(n_2),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_7),
.A2(n_1),
.B(n_2),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_8),
.B1(n_10),
.B2(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AND3x1_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_11),
.C(n_13),
.Y(n_16)
);

XOR2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_15),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.Y(n_18)
);


endmodule