module fake_netlist_656_2058_n_18 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_18);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_18;

wire n_17;
wire n_14;
wire n_10;
wire n_15;
wire n_11;
wire n_13;
wire n_16;
wire n_12;

OR2x6_ASAP7_75t_L g10 ( 
.A(n_3),
.B(n_1),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_5),
.B(n_2),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

AO22x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B1(n_13),
.B2(n_4),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_10),
.C(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_6),
.B1(n_7),
.B2(n_8),
.C1(n_9),
.C2(n_12),
.Y(n_18)
);


endmodule