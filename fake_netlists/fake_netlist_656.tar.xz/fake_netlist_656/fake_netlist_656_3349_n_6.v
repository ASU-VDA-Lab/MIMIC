module fake_netlist_656_3349_n_6 (n_3, n_1, n_2, n_0, n_6);

input n_3;
input n_1;
input n_2;
input n_0;

output n_6;

wire n_4;
wire n_5;

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_3),
.Y(n_5)
);

OAI221xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_4),
.C(n_2),
.Y(n_6)
);


endmodule