module fake_netlist_627_2010_n_22 (n_7, n_9, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_22);

input n_7;
input n_9;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_22;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_17;
wire n_19;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

AO21x2_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_9),
.B(n_0),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_SL g12 ( 
.A(n_2),
.B(n_1),
.Y(n_12)
);

AND2x6_ASAP7_75t_L g13 ( 
.A(n_3),
.B(n_2),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_L g14 ( 
.A(n_0),
.B(n_7),
.C(n_8),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_1),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI221xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B1(n_12),
.B2(n_13),
.C(n_4),
.Y(n_19)
);

NOR2xp67_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B1(n_6),
.B2(n_5),
.Y(n_21)
);

OAI222xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_6),
.B1(n_8),
.B2(n_10),
.C1(n_13),
.C2(n_19),
.Y(n_22)
);


endmodule