module fake_netlist_627_731_n_83 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_83);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_83;

wire n_75;
wire n_37;
wire n_54;
wire n_44;
wire n_36;
wire n_65;
wire n_63;
wire n_47;
wire n_57;
wire n_82;
wire n_55;
wire n_76;
wire n_64;
wire n_68;
wire n_81;
wire n_39;
wire n_53;
wire n_77;
wire n_29;
wire n_27;
wire n_35;
wire n_80;
wire n_69;
wire n_78;
wire n_71;
wire n_42;
wire n_59;
wire n_50;
wire n_58;
wire n_28;
wire n_52;
wire n_49;
wire n_51;
wire n_45;
wire n_73;
wire n_56;
wire n_66;
wire n_32;
wire n_33;
wire n_41;
wire n_34;
wire n_31;
wire n_79;
wire n_40;
wire n_30;
wire n_61;
wire n_62;
wire n_70;
wire n_67;
wire n_48;
wire n_25;
wire n_26;
wire n_60;
wire n_38;
wire n_46;
wire n_43;
wire n_74;
wire n_72;

INVx2_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_5),
.B(n_16),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_4),
.Y(n_28)
);

CKINVDCx16_ASAP7_75t_R g29 ( 
.A(n_7),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_22),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_17),
.B(n_6),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_11),
.B(n_12),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_18),
.B(n_22),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_9),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_10),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_0),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_25),
.Y(n_38)
);

BUFx3_ASAP7_75t_L g39 ( 
.A(n_31),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_25),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_31),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_L g42 ( 
.A(n_35),
.B(n_21),
.Y(n_42)
);

AND2x6_ASAP7_75t_SL g43 ( 
.A(n_34),
.B(n_21),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_30),
.B(n_23),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_33),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_39),
.A2(n_34),
.B1(n_33),
.B2(n_31),
.Y(n_46)
);

OA21x2_ASAP7_75t_L g47 ( 
.A1(n_38),
.A2(n_28),
.B(n_26),
.Y(n_47)
);

OAI222xp33_ASAP7_75t_L g48 ( 
.A1(n_41),
.A2(n_30),
.B1(n_34),
.B2(n_29),
.C1(n_37),
.C2(n_27),
.Y(n_48)
);

OAI21x1_ASAP7_75t_L g49 ( 
.A1(n_38),
.A2(n_28),
.B(n_26),
.Y(n_49)
);

OAI21x1_ASAP7_75t_L g50 ( 
.A1(n_40),
.A2(n_32),
.B(n_36),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_46),
.B(n_44),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_47),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_54),
.Y(n_55)
);

OR2x2_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_40),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_51),
.B(n_47),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_51),
.B(n_47),
.Y(n_58)
);

INVxp67_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

NAND2x1_ASAP7_75t_SL g60 ( 
.A(n_58),
.B(n_47),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_SL g61 ( 
.A(n_55),
.B(n_53),
.Y(n_61)
);

NOR3xp33_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_48),
.C(n_42),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_57),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_59),
.B(n_57),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_63),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_60),
.Y(n_66)
);

XNOR2xp5_ASAP7_75t_L g67 ( 
.A(n_62),
.B(n_43),
.Y(n_67)
);

AOI222xp33_ASAP7_75t_L g68 ( 
.A1(n_61),
.A2(n_39),
.B1(n_45),
.B2(n_43),
.C1(n_36),
.C2(n_50),
.Y(n_68)
);

XOR2x2_ASAP7_75t_L g69 ( 
.A(n_61),
.B(n_23),
.Y(n_69)
);

NAND4xp25_ASAP7_75t_SL g70 ( 
.A(n_69),
.B(n_45),
.C(n_24),
.D(n_1),
.Y(n_70)
);

AOI221x1_ASAP7_75t_L g71 ( 
.A1(n_66),
.A2(n_36),
.B1(n_50),
.B2(n_24),
.C(n_2),
.Y(n_71)
);

HB1xp67_ASAP7_75t_L g72 ( 
.A(n_66),
.Y(n_72)
);

NOR2xp67_ASAP7_75t_L g73 ( 
.A(n_67),
.B(n_39),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_65),
.Y(n_74)
);

AOI211xp5_ASAP7_75t_L g75 ( 
.A1(n_64),
.A2(n_36),
.B(n_8),
.C(n_3),
.Y(n_75)
);

INVx5_ASAP7_75t_L g76 ( 
.A(n_70),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_74),
.Y(n_77)
);

XOR2xp5_ASAP7_75t_L g78 ( 
.A(n_72),
.B(n_69),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_72),
.Y(n_79)
);

OAI22xp5_ASAP7_75t_SL g80 ( 
.A1(n_78),
.A2(n_75),
.B1(n_73),
.B2(n_68),
.Y(n_80)
);

AOI22xp5_ASAP7_75t_SL g81 ( 
.A1(n_77),
.A2(n_71),
.B1(n_15),
.B2(n_13),
.Y(n_81)
);

AOI22x1_ASAP7_75t_L g82 ( 
.A1(n_79),
.A2(n_19),
.B1(n_78),
.B2(n_67),
.Y(n_82)
);

AOI22xp33_ASAP7_75t_L g83 ( 
.A1(n_80),
.A2(n_76),
.B1(n_82),
.B2(n_81),
.Y(n_83)
);


endmodule