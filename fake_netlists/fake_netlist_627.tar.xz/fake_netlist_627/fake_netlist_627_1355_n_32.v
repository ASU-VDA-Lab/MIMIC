module fake_netlist_627_1355_n_32 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_32);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_32;

wire n_11;
wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

NAND2xp33_ASAP7_75t_SL g10 ( 
.A(n_2),
.B(n_8),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_3),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

NOR2xp67_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_4),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_0),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_4),
.B(n_2),
.C(n_1),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_12),
.Y(n_19)
);

BUFx10_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_SL g22 ( 
.A(n_19),
.B(n_10),
.C(n_18),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_20),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_22),
.B(n_16),
.Y(n_24)
);

NAND5xp2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_18),
.C(n_7),
.D(n_5),
.E(n_6),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_13),
.B1(n_15),
.B2(n_14),
.C1(n_17),
.C2(n_5),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_17),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_6),
.B1(n_15),
.B2(n_26),
.C1(n_31),
.C2(n_30),
.Y(n_32)
);


endmodule