module fake_netlist_627_428_n_11 (n_5, n_0, n_4, n_1, n_2, n_3, n_11);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_11;

wire n_7;
wire n_9;
wire n_8;
wire n_10;
wire n_6;

INVx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

NAND2x1p5_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_5),
.Y(n_7)
);

AND2x2_ASAP7_75t_SL g8 ( 
.A(n_0),
.B(n_4),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

NOR4xp25_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.C(n_7),
.D(n_1),
.Y(n_10)
);

OAI22x1_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B1(n_4),
.B2(n_1),
.Y(n_11)
);


endmodule