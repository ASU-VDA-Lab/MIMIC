module fake_netlist_627_2602_n_46 (n_7, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_46);

input n_7;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_46;

wire n_11;
wire n_31;
wire n_15;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_10;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_42;
wire n_33;
wire n_14;
wire n_41;
wire n_13;
wire n_12;
wire n_9;

NOR2xp33_ASAP7_75t_R g9 ( 
.A(n_0),
.B(n_2),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

INVxp33_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_6),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

CKINVDCx6p67_ASAP7_75t_R g14 ( 
.A(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_7),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_7),
.B(n_6),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_7),
.B(n_3),
.C(n_2),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_13),
.A2(n_4),
.B(n_11),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_4),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_14),
.A2(n_13),
.B1(n_11),
.B2(n_10),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_R g25 ( 
.A(n_23),
.B(n_9),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_14),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_18),
.B(n_14),
.Y(n_28)
);

AND2x4_ASAP7_75t_SL g29 ( 
.A(n_18),
.B(n_12),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_12),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_27),
.Y(n_33)
);

INVxp33_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

OAI222xp33_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_20),
.B1(n_19),
.B2(n_21),
.C1(n_16),
.C2(n_22),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_30),
.A2(n_29),
.B1(n_25),
.B2(n_9),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_32),
.B1(n_31),
.B2(n_33),
.Y(n_39)
);

AOI21xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_32),
.B(n_31),
.Y(n_40)
);

OAI211xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_31),
.B(n_33),
.C(n_36),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_34),
.B1(n_36),
.B2(n_40),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_41),
.B1(n_44),
.B2(n_43),
.Y(n_46)
);


endmodule