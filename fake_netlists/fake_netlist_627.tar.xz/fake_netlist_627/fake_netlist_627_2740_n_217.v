module fake_netlist_627_2740_n_217 (n_11, n_8, n_31, n_15, n_37, n_39, n_3, n_53, n_54, n_40, n_21, n_30, n_44, n_50, n_18, n_36, n_22, n_29, n_34, n_27, n_28, n_17, n_58, n_52, n_4, n_1, n_24, n_49, n_51, n_48, n_35, n_7, n_45, n_25, n_26, n_19, n_38, n_46, n_10, n_47, n_57, n_43, n_56, n_20, n_32, n_23, n_16, n_42, n_5, n_33, n_14, n_41, n_55, n_13, n_6, n_0, n_12, n_2, n_9, n_217);

input n_11;
input n_8;
input n_31;
input n_15;
input n_37;
input n_39;
input n_3;
input n_53;
input n_54;
input n_40;
input n_21;
input n_30;
input n_44;
input n_50;
input n_18;
input n_36;
input n_22;
input n_29;
input n_34;
input n_27;
input n_28;
input n_17;
input n_58;
input n_52;
input n_4;
input n_1;
input n_24;
input n_49;
input n_51;
input n_48;
input n_35;
input n_7;
input n_45;
input n_25;
input n_26;
input n_19;
input n_38;
input n_46;
input n_10;
input n_47;
input n_57;
input n_43;
input n_56;
input n_20;
input n_32;
input n_23;
input n_16;
input n_42;
input n_5;
input n_33;
input n_14;
input n_41;
input n_55;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_217;

wire n_137;
wire n_133;
wire n_170;
wire n_75;
wire n_109;
wire n_121;
wire n_198;
wire n_119;
wire n_179;
wire n_168;
wire n_120;
wire n_123;
wire n_164;
wire n_181;
wire n_87;
wire n_125;
wire n_185;
wire n_65;
wire n_211;
wire n_106;
wire n_83;
wire n_63;
wire n_88;
wire n_126;
wire n_116;
wire n_135;
wire n_82;
wire n_197;
wire n_214;
wire n_76;
wire n_64;
wire n_157;
wire n_160;
wire n_68;
wire n_146;
wire n_196;
wire n_177;
wire n_161;
wire n_81;
wire n_97;
wire n_182;
wire n_122;
wire n_188;
wire n_77;
wire n_215;
wire n_193;
wire n_163;
wire n_101;
wire n_184;
wire n_80;
wire n_112;
wire n_172;
wire n_69;
wire n_176;
wire n_99;
wire n_213;
wire n_86;
wire n_110;
wire n_78;
wire n_114;
wire n_141;
wire n_71;
wire n_167;
wire n_149;
wire n_132;
wire n_205;
wire n_155;
wire n_96;
wire n_84;
wire n_107;
wire n_115;
wire n_210;
wire n_201;
wire n_148;
wire n_150;
wire n_158;
wire n_117;
wire n_130;
wire n_171;
wire n_94;
wire n_129;
wire n_169;
wire n_208;
wire n_59;
wire n_102;
wire n_134;
wire n_143;
wire n_142;
wire n_194;
wire n_202;
wire n_95;
wire n_212;
wire n_145;
wire n_73;
wire n_159;
wire n_104;
wire n_108;
wire n_200;
wire n_85;
wire n_66;
wire n_192;
wire n_216;
wire n_92;
wire n_105;
wire n_209;
wire n_153;
wire n_147;
wire n_166;
wire n_103;
wire n_144;
wire n_79;
wire n_191;
wire n_139;
wire n_186;
wire n_190;
wire n_180;
wire n_162;
wire n_111;
wire n_189;
wire n_187;
wire n_61;
wire n_70;
wire n_62;
wire n_90;
wire n_204;
wire n_206;
wire n_67;
wire n_89;
wire n_152;
wire n_91;
wire n_128;
wire n_138;
wire n_140;
wire n_183;
wire n_165;
wire n_60;
wire n_178;
wire n_175;
wire n_195;
wire n_156;
wire n_199;
wire n_151;
wire n_131;
wire n_136;
wire n_154;
wire n_203;
wire n_74;
wire n_173;
wire n_113;
wire n_207;
wire n_118;
wire n_93;
wire n_72;
wire n_100;
wire n_98;
wire n_127;
wire n_174;
wire n_124;

INVx1_ASAP7_75t_L g59 ( 
.A(n_58),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_27),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_0),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_5),
.Y(n_62)
);

INVxp67_ASAP7_75t_SL g63 ( 
.A(n_22),
.Y(n_63)
);

INVxp67_ASAP7_75t_SL g64 ( 
.A(n_52),
.Y(n_64)
);

INVxp67_ASAP7_75t_L g65 ( 
.A(n_26),
.Y(n_65)
);

INVxp67_ASAP7_75t_L g66 ( 
.A(n_1),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_57),
.Y(n_67)
);

INVxp67_ASAP7_75t_SL g68 ( 
.A(n_56),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_50),
.Y(n_69)
);

INVxp67_ASAP7_75t_L g70 ( 
.A(n_9),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_48),
.Y(n_71)
);

CKINVDCx5p33_ASAP7_75t_R g72 ( 
.A(n_13),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_21),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_40),
.Y(n_74)
);

INVxp67_ASAP7_75t_SL g75 ( 
.A(n_55),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_3),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_33),
.Y(n_77)
);

CKINVDCx20_ASAP7_75t_R g78 ( 
.A(n_16),
.Y(n_78)
);

CKINVDCx5p33_ASAP7_75t_R g79 ( 
.A(n_31),
.Y(n_79)
);

CKINVDCx20_ASAP7_75t_R g80 ( 
.A(n_53),
.Y(n_80)
);

CKINVDCx20_ASAP7_75t_R g81 ( 
.A(n_54),
.Y(n_81)
);

CKINVDCx20_ASAP7_75t_R g82 ( 
.A(n_28),
.Y(n_82)
);

INVx2_ASAP7_75t_L g83 ( 
.A(n_2),
.Y(n_83)
);

CKINVDCx5p33_ASAP7_75t_R g84 ( 
.A(n_8),
.Y(n_84)
);

CKINVDCx20_ASAP7_75t_R g85 ( 
.A(n_49),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_19),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_41),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_12),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_3),
.Y(n_89)
);

XOR2xp5_ASAP7_75t_L g90 ( 
.A(n_45),
.B(n_42),
.Y(n_90)
);

CKINVDCx20_ASAP7_75t_R g91 ( 
.A(n_25),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_51),
.Y(n_92)
);

INVx3_ASAP7_75t_L g93 ( 
.A(n_61),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_71),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_83),
.Y(n_95)
);

INVxp67_ASAP7_75t_L g96 ( 
.A(n_76),
.Y(n_96)
);

INVx2_ASAP7_75t_L g97 ( 
.A(n_59),
.Y(n_97)
);

OAI22xp33_ASAP7_75t_SL g98 ( 
.A1(n_66),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_98)
);

HB1xp67_ASAP7_75t_L g99 ( 
.A(n_66),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_60),
.Y(n_100)
);

O2A1O1Ixp33_ASAP7_75t_L g101 ( 
.A1(n_99),
.A2(n_89),
.B(n_70),
.C(n_65),
.Y(n_101)
);

INVx2_ASAP7_75t_SL g102 ( 
.A(n_97),
.Y(n_102)
);

A2O1A1Ixp33_ASAP7_75t_L g103 ( 
.A1(n_96),
.A2(n_100),
.B(n_95),
.C(n_94),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_93),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_93),
.B(n_65),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_104),
.Y(n_106)
);

NAND2xp5_ASAP7_75t_L g107 ( 
.A(n_102),
.B(n_105),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_103),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_103),
.Y(n_109)
);

CKINVDCx5p33_ASAP7_75t_R g110 ( 
.A(n_101),
.Y(n_110)
);

BUFx10_ASAP7_75t_L g111 ( 
.A(n_108),
.Y(n_111)
);

AND2x4_ASAP7_75t_L g112 ( 
.A(n_106),
.B(n_78),
.Y(n_112)
);

INVx3_ASAP7_75t_L g113 ( 
.A(n_107),
.Y(n_113)
);

INVx2_ASAP7_75t_L g114 ( 
.A(n_109),
.Y(n_114)
);

BUFx2_ASAP7_75t_L g115 ( 
.A(n_110),
.Y(n_115)
);

NOR2x1_ASAP7_75t_R g116 ( 
.A(n_112),
.B(n_110),
.Y(n_116)
);

AO21x2_ASAP7_75t_L g117 ( 
.A1(n_114),
.A2(n_67),
.B(n_62),
.Y(n_117)
);

BUFx4f_ASAP7_75t_SL g118 ( 
.A(n_113),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_115),
.Y(n_119)
);

OAI22xp33_ASAP7_75t_L g120 ( 
.A1(n_115),
.A2(n_82),
.B1(n_81),
.B2(n_80),
.Y(n_120)
);

HB1xp67_ASAP7_75t_L g121 ( 
.A(n_112),
.Y(n_121)
);

AOI22xp33_ASAP7_75t_L g122 ( 
.A1(n_111),
.A2(n_91),
.B1(n_85),
.B2(n_98),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_117),
.Y(n_123)
);

INVx2_ASAP7_75t_L g124 ( 
.A(n_117),
.Y(n_124)
);

AND2x2_ASAP7_75t_L g125 ( 
.A(n_121),
.B(n_119),
.Y(n_125)
);

AND2x2_ASAP7_75t_L g126 ( 
.A(n_122),
.B(n_90),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_116),
.Y(n_127)
);

INVx2_ASAP7_75t_L g128 ( 
.A(n_118),
.Y(n_128)
);

INVx2_ASAP7_75t_L g129 ( 
.A(n_120),
.Y(n_129)
);

INVx2_ASAP7_75t_SL g130 ( 
.A(n_120),
.Y(n_130)
);

AND2x2_ASAP7_75t_SL g131 ( 
.A(n_122),
.B(n_111),
.Y(n_131)
);

BUFx2_ASAP7_75t_L g132 ( 
.A(n_118),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_117),
.Y(n_133)
);

INVx2_ASAP7_75t_L g134 ( 
.A(n_117),
.Y(n_134)
);

NAND2xp5_ASAP7_75t_L g135 ( 
.A(n_119),
.B(n_70),
.Y(n_135)
);

HB1xp67_ASAP7_75t_L g136 ( 
.A(n_118),
.Y(n_136)
);

HB1xp67_ASAP7_75t_L g137 ( 
.A(n_130),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_125),
.Y(n_138)
);

AND2x2_ASAP7_75t_L g139 ( 
.A(n_129),
.B(n_63),
.Y(n_139)
);

OAI22xp5_ASAP7_75t_L g140 ( 
.A1(n_131),
.A2(n_75),
.B1(n_68),
.B2(n_64),
.Y(n_140)
);

INVxp67_ASAP7_75t_SL g141 ( 
.A(n_124),
.Y(n_141)
);

AOI221xp5_ASAP7_75t_L g142 ( 
.A1(n_135),
.A2(n_73),
.B1(n_69),
.B2(n_74),
.C(n_77),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_123),
.Y(n_143)
);

INVxp67_ASAP7_75t_L g144 ( 
.A(n_132),
.Y(n_144)
);

OAI33xp33_ASAP7_75t_L g145 ( 
.A1(n_127),
.A2(n_87),
.A3(n_86),
.B1(n_88),
.B2(n_92),
.B3(n_72),
.Y(n_145)
);

AND2x2_ASAP7_75t_L g146 ( 
.A(n_127),
.B(n_79),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_123),
.Y(n_147)
);

AND2x2_ASAP7_75t_L g148 ( 
.A(n_126),
.B(n_84),
.Y(n_148)
);

BUFx2_ASAP7_75t_L g149 ( 
.A(n_136),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_133),
.Y(n_150)
);

NAND2xp5_ASAP7_75t_L g151 ( 
.A(n_133),
.B(n_4),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_134),
.Y(n_152)
);

AOI22xp5_ASAP7_75t_L g153 ( 
.A1(n_128),
.A2(n_10),
.B1(n_7),
.B2(n_6),
.Y(n_153)
);

AND2x2_ASAP7_75t_L g154 ( 
.A(n_130),
.B(n_11),
.Y(n_154)
);

AO21x2_ASAP7_75t_L g155 ( 
.A1(n_123),
.A2(n_15),
.B(n_14),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_125),
.Y(n_156)
);

OAI22xp33_ASAP7_75t_L g157 ( 
.A1(n_130),
.A2(n_20),
.B1(n_18),
.B2(n_17),
.Y(n_157)
);

NAND2xp5_ASAP7_75t_L g158 ( 
.A(n_138),
.B(n_23),
.Y(n_158)
);

OR2x2_ASAP7_75t_L g159 ( 
.A(n_156),
.B(n_24),
.Y(n_159)
);

OR2x2_ASAP7_75t_L g160 ( 
.A(n_137),
.B(n_29),
.Y(n_160)
);

OR2x2_ASAP7_75t_L g161 ( 
.A(n_143),
.B(n_30),
.Y(n_161)
);

AND2x2_ASAP7_75t_L g162 ( 
.A(n_139),
.B(n_32),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_147),
.Y(n_163)
);

AND2x2_ASAP7_75t_L g164 ( 
.A(n_149),
.B(n_34),
.Y(n_164)
);

HB1xp67_ASAP7_75t_SL g165 ( 
.A(n_140),
.Y(n_165)
);

OR2x6_ASAP7_75t_L g166 ( 
.A(n_140),
.B(n_35),
.Y(n_166)
);

AND2x2_ASAP7_75t_L g167 ( 
.A(n_144),
.B(n_36),
.Y(n_167)
);

NOR2xp33_ASAP7_75t_SL g168 ( 
.A(n_145),
.B(n_37),
.Y(n_168)
);

INVx2_ASAP7_75t_L g169 ( 
.A(n_150),
.Y(n_169)
);

NAND2xp5_ASAP7_75t_L g170 ( 
.A(n_148),
.B(n_38),
.Y(n_170)
);

INVx1_ASAP7_75t_L g171 ( 
.A(n_152),
.Y(n_171)
);

AND2x2_ASAP7_75t_L g172 ( 
.A(n_146),
.B(n_39),
.Y(n_172)
);

INVx2_ASAP7_75t_L g173 ( 
.A(n_141),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_151),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_151),
.Y(n_175)
);

NAND2x1_ASAP7_75t_L g176 ( 
.A(n_154),
.B(n_43),
.Y(n_176)
);

AND2x2_ASAP7_75t_L g177 ( 
.A(n_142),
.B(n_44),
.Y(n_177)
);

INVx1_ASAP7_75t_L g178 ( 
.A(n_163),
.Y(n_178)
);

AND2x2_ASAP7_75t_L g179 ( 
.A(n_173),
.B(n_155),
.Y(n_179)
);

INVx2_ASAP7_75t_SL g180 ( 
.A(n_164),
.Y(n_180)
);

AND2x2_ASAP7_75t_L g181 ( 
.A(n_169),
.B(n_155),
.Y(n_181)
);

INVx2_ASAP7_75t_L g182 ( 
.A(n_171),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_174),
.Y(n_183)
);

INVx1_ASAP7_75t_L g184 ( 
.A(n_174),
.Y(n_184)
);

OAI31xp33_ASAP7_75t_L g185 ( 
.A1(n_177),
.A2(n_157),
.A3(n_153),
.B(n_46),
.Y(n_185)
);

NAND2xp5_ASAP7_75t_L g186 ( 
.A(n_175),
.B(n_47),
.Y(n_186)
);

INVx2_ASAP7_75t_L g187 ( 
.A(n_175),
.Y(n_187)
);

OR2x2_ASAP7_75t_L g188 ( 
.A(n_161),
.B(n_160),
.Y(n_188)
);

INVx1_ASAP7_75t_L g189 ( 
.A(n_165),
.Y(n_189)
);

INVx1_ASAP7_75t_L g190 ( 
.A(n_158),
.Y(n_190)
);

INVx1_ASAP7_75t_L g191 ( 
.A(n_159),
.Y(n_191)
);

HB1xp67_ASAP7_75t_L g192 ( 
.A(n_166),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_189),
.B(n_167),
.Y(n_193)
);

INVxp67_ASAP7_75t_L g194 ( 
.A(n_192),
.Y(n_194)
);

INVx2_ASAP7_75t_L g195 ( 
.A(n_182),
.Y(n_195)
);

INVx1_ASAP7_75t_SL g196 ( 
.A(n_180),
.Y(n_196)
);

OR2x2_ASAP7_75t_L g197 ( 
.A(n_178),
.B(n_187),
.Y(n_197)
);

INVx1_ASAP7_75t_L g198 ( 
.A(n_183),
.Y(n_198)
);

AND2x2_ASAP7_75t_L g199 ( 
.A(n_184),
.B(n_166),
.Y(n_199)
);

NAND2xp5_ASAP7_75t_L g200 ( 
.A(n_191),
.B(n_168),
.Y(n_200)
);

INVx2_ASAP7_75t_L g201 ( 
.A(n_179),
.Y(n_201)
);

AOI21xp5_ASAP7_75t_L g202 ( 
.A1(n_200),
.A2(n_185),
.B(n_176),
.Y(n_202)
);

INVxp67_ASAP7_75t_SL g203 ( 
.A(n_195),
.Y(n_203)
);

INVx1_ASAP7_75t_L g204 ( 
.A(n_197),
.Y(n_204)
);

NAND2xp5_ASAP7_75t_L g205 ( 
.A(n_194),
.B(n_181),
.Y(n_205)
);

NAND2xp5_ASAP7_75t_L g206 ( 
.A(n_198),
.B(n_190),
.Y(n_206)
);

NAND2xp5_ASAP7_75t_L g207 ( 
.A(n_204),
.B(n_203),
.Y(n_207)
);

NAND2xp5_ASAP7_75t_L g208 ( 
.A(n_205),
.B(n_201),
.Y(n_208)
);

NOR3x1_ASAP7_75t_L g209 ( 
.A(n_206),
.B(n_188),
.C(n_170),
.Y(n_209)
);

INVxp67_ASAP7_75t_L g210 ( 
.A(n_207),
.Y(n_210)
);

INVx1_ASAP7_75t_L g211 ( 
.A(n_208),
.Y(n_211)
);

XNOR2xp5_ASAP7_75t_L g212 ( 
.A(n_211),
.B(n_196),
.Y(n_212)
);

AOI311xp33_ASAP7_75t_L g213 ( 
.A1(n_212),
.A2(n_210),
.A3(n_202),
.B(n_209),
.C(n_186),
.Y(n_213)
);

OR3x1_ASAP7_75t_L g214 ( 
.A(n_213),
.B(n_185),
.C(n_193),
.Y(n_214)
);

OAI21xp5_ASAP7_75t_L g215 ( 
.A1(n_214),
.A2(n_172),
.B(n_199),
.Y(n_215)
);

INVxp67_ASAP7_75t_L g216 ( 
.A(n_215),
.Y(n_216)
);

AOI21xp33_ASAP7_75t_L g217 ( 
.A1(n_216),
.A2(n_186),
.B(n_162),
.Y(n_217)
);


endmodule