module fake_netlist_627_2779_n_11 (n_1, n_2, n_0, n_11);

input n_1;
input n_2;
input n_0;

output n_11;

wire n_7;
wire n_9;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_3;

AND2x2_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

INVx3_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.Y(n_5)
);

BUFx12f_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AOI322xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.A3(n_3),
.B1(n_6),
.B2(n_4),
.C1(n_1),
.C2(n_0),
.Y(n_9)
);

NOR2x1_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.Y(n_10)
);

NAND4xp25_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_0),
.C(n_5),
.D(n_9),
.Y(n_11)
);


endmodule