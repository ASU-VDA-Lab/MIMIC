module fake_netlist_627_2245_n_77 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_77);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_77;

wire n_75;
wire n_37;
wire n_54;
wire n_44;
wire n_36;
wire n_65;
wire n_63;
wire n_47;
wire n_57;
wire n_55;
wire n_76;
wire n_64;
wire n_68;
wire n_53;
wire n_39;
wire n_29;
wire n_27;
wire n_35;
wire n_69;
wire n_71;
wire n_42;
wire n_59;
wire n_50;
wire n_58;
wire n_28;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_45;
wire n_73;
wire n_56;
wire n_66;
wire n_32;
wire n_23;
wire n_33;
wire n_41;
wire n_34;
wire n_31;
wire n_40;
wire n_30;
wire n_61;
wire n_62;
wire n_70;
wire n_67;
wire n_48;
wire n_25;
wire n_26;
wire n_60;
wire n_46;
wire n_38;
wire n_43;
wire n_74;
wire n_72;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_7),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_3),
.B(n_20),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_3),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_13),
.B(n_9),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_8),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_17),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_1),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_10),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_5),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_10),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_17),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_31),
.Y(n_37)
);

NAND2x1_ASAP7_75t_L g38 ( 
.A(n_31),
.B(n_27),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_31),
.B(n_8),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_27),
.A2(n_12),
.B1(n_11),
.B2(n_9),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_31),
.B(n_26),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_26),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_36),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_41),
.B(n_24),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_27),
.B1(n_33),
.B2(n_28),
.Y(n_45)
);

OAI211xp5_ASAP7_75t_L g46 ( 
.A1(n_40),
.A2(n_34),
.B(n_33),
.C(n_28),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_38),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_43),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_42),
.Y(n_50)
);

BUFx3_ASAP7_75t_L g51 ( 
.A(n_50),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_45),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_47),
.B(n_45),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_42),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_54),
.Y(n_55)
);

AOI322xp5_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_34),
.A3(n_38),
.B1(n_29),
.B2(n_23),
.C1(n_25),
.C2(n_42),
.Y(n_56)
);

NAND3xp33_ASAP7_75t_SL g57 ( 
.A(n_53),
.B(n_24),
.C(n_23),
.Y(n_57)
);

OAI222xp33_ASAP7_75t_L g58 ( 
.A1(n_51),
.A2(n_29),
.B1(n_25),
.B2(n_39),
.C1(n_32),
.C2(n_42),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_54),
.B(n_42),
.Y(n_59)
);

AOI221xp5_ASAP7_75t_L g60 ( 
.A1(n_58),
.A2(n_46),
.B1(n_44),
.B2(n_35),
.C(n_51),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_55),
.Y(n_61)
);

AOI221xp5_ASAP7_75t_L g62 ( 
.A1(n_58),
.A2(n_51),
.B1(n_37),
.B2(n_36),
.C(n_30),
.Y(n_62)
);

OAI21xp5_ASAP7_75t_L g63 ( 
.A1(n_57),
.A2(n_37),
.B(n_36),
.Y(n_63)
);

XOR2xp5_ASAP7_75t_L g64 ( 
.A(n_57),
.B(n_11),
.Y(n_64)
);

NAND4xp25_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_56),
.C(n_55),
.D(n_59),
.Y(n_65)
);

NOR2xp67_ASAP7_75t_L g66 ( 
.A(n_61),
.B(n_12),
.Y(n_66)
);

AND2x2_ASAP7_75t_L g67 ( 
.A(n_64),
.B(n_56),
.Y(n_67)
);

NAND3xp33_ASAP7_75t_SL g68 ( 
.A(n_62),
.B(n_59),
.C(n_13),
.Y(n_68)
);

A2O1A1Ixp33_ASAP7_75t_SL g69 ( 
.A1(n_63),
.A2(n_36),
.B(n_18),
.C(n_16),
.Y(n_69)
);

AND3x4_ASAP7_75t_L g70 ( 
.A(n_64),
.B(n_18),
.C(n_16),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_70),
.Y(n_71)
);

NAND2xp5_ASAP7_75t_L g72 ( 
.A(n_67),
.B(n_36),
.Y(n_72)
);

OAI22xp5_ASAP7_75t_L g73 ( 
.A1(n_66),
.A2(n_21),
.B1(n_20),
.B2(n_19),
.Y(n_73)
);

AND4x1_ASAP7_75t_L g74 ( 
.A(n_68),
.B(n_22),
.C(n_21),
.D(n_19),
.Y(n_74)
);

OAI22xp5_ASAP7_75t_L g75 ( 
.A1(n_71),
.A2(n_65),
.B1(n_69),
.B2(n_0),
.Y(n_75)
);

AOI22xp5_ASAP7_75t_L g76 ( 
.A1(n_73),
.A2(n_65),
.B1(n_4),
.B2(n_2),
.Y(n_76)
);

OA331x2_ASAP7_75t_L g77 ( 
.A1(n_75),
.A2(n_6),
.A3(n_14),
.B1(n_15),
.B2(n_72),
.B3(n_74),
.C1(n_76),
.Y(n_77)
);


endmodule