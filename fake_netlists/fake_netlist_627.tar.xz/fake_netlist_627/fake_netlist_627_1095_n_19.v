module fake_netlist_627_1095_n_19 (n_0, n_4, n_1, n_2, n_3, n_19);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_19;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_7;
wire n_10;
wire n_16;
wire n_5;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_0),
.Y(n_7)
);

O2A1O1Ixp33_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_2),
.B(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx4_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_5),
.B1(n_7),
.B2(n_6),
.C1(n_8),
.C2(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_SL g15 ( 
.A1(n_13),
.A2(n_12),
.B(n_7),
.C(n_1),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_12),
.B1(n_7),
.B2(n_2),
.C(n_4),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_14),
.B1(n_12),
.B2(n_4),
.Y(n_17)
);

OR3x1_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_3),
.C(n_12),
.Y(n_18)
);

AO21x2_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_17),
.B(n_14),
.Y(n_19)
);


endmodule