module fake_netlist_627_2332_n_70 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_70);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_70;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_58;
wire n_62;
wire n_67;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_65;
wire n_69;
wire n_25;
wire n_63;
wire n_26;
wire n_60;
wire n_46;
wire n_38;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_66;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_64;
wire n_68;

AND2x2_ASAP7_75t_L g21 ( 
.A(n_3),
.B(n_14),
.Y(n_21)
);

OA21x2_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_12),
.B(n_11),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_8),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_17),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_5),
.B(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_0),
.B(n_2),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_19),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_1),
.B(n_13),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_18),
.B(n_15),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

BUFx12f_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

AND3x1_ASAP7_75t_L g36 ( 
.A(n_26),
.B(n_17),
.C(n_16),
.Y(n_36)
);

INVx8_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

INVxp67_ASAP7_75t_SL g39 ( 
.A(n_22),
.Y(n_39)
);

OAI21xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_34),
.B(n_31),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_34),
.Y(n_41)
);

AO21x2_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_25),
.B(n_28),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_37),
.A2(n_31),
.B(n_21),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_33),
.A2(n_29),
.B1(n_24),
.B2(n_32),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_40),
.B(n_36),
.Y(n_46)
);

NOR2x1_ASAP7_75t_SL g47 ( 
.A(n_42),
.B(n_35),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_42),
.A2(n_37),
.B1(n_29),
.B2(n_22),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_44),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_43),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_46),
.B(n_37),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_47),
.Y(n_53)
);

AOI22xp33_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_48),
.B1(n_22),
.B2(n_27),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

BUFx2_ASAP7_75t_SL g56 ( 
.A(n_51),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_51),
.B1(n_47),
.B2(n_27),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

NOR2xp33_ASAP7_75t_R g59 ( 
.A(n_54),
.B(n_16),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_56),
.Y(n_60)
);

AOI221xp5_ASAP7_75t_L g61 ( 
.A1(n_56),
.A2(n_27),
.B1(n_38),
.B2(n_18),
.C(n_9),
.Y(n_61)
);

NOR2xp33_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_60),
.Y(n_62)
);

INVx1_ASAP7_75t_SL g63 ( 
.A(n_59),
.Y(n_63)
);

OR2x2_ASAP7_75t_L g64 ( 
.A(n_57),
.B(n_38),
.Y(n_64)
);

NAND2x1p5_ASAP7_75t_L g65 ( 
.A(n_61),
.B(n_38),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_62),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_64),
.Y(n_67)
);

CKINVDCx20_ASAP7_75t_R g68 ( 
.A(n_63),
.Y(n_68)
);

INVx2_ASAP7_75t_L g69 ( 
.A(n_66),
.Y(n_69)
);

AOI322xp5_ASAP7_75t_L g70 ( 
.A1(n_69),
.A2(n_63),
.A3(n_68),
.B1(n_67),
.B2(n_38),
.C1(n_65),
.C2(n_10),
.Y(n_70)
);


endmodule