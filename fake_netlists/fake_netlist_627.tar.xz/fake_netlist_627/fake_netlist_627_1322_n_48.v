module fake_netlist_627_1322_n_48 (n_7, n_9, n_11, n_8, n_5, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_48);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_48;

wire n_31;
wire n_15;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_42;
wire n_33;
wire n_14;
wire n_41;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_5),
.B(n_13),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_19),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_4),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_15),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_16),
.B(n_4),
.Y(n_26)
);

NAND2x1_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_21),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_18),
.B1(n_14),
.B2(n_20),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_23),
.B(n_14),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_24),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_25),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

OAI221xp5_ASAP7_75t_L g33 ( 
.A1(n_28),
.A2(n_22),
.B1(n_18),
.B2(n_16),
.C(n_5),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_30),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_29),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_33),
.Y(n_39)
);

OAI21xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_35),
.B(n_36),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_6),
.Y(n_41)
);

AOI21xp33_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_7),
.B(n_6),
.Y(n_42)
);

BUFx4f_ASAP7_75t_SL g43 ( 
.A(n_41),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_8),
.B(n_0),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_11),
.B1(n_44),
.B2(n_46),
.Y(n_48)
);


endmodule