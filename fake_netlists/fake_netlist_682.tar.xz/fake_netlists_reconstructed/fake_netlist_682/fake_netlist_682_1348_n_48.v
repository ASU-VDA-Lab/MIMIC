module fake_netlist_682_1348_n_48 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_48);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_48;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_31;
wire n_23;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_15),
.B(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_11),
.B(n_4),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_8),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_0),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_26),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_20),
.C(n_22),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_28),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_32),
.B1(n_33),
.B2(n_23),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_24),
.C(n_29),
.Y(n_35)
);

NOR3xp33_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_25),
.C(n_29),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_29),
.Y(n_37)
);

XOR2xp5_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_2),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_18),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NOR2xp67_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_1),
.Y(n_41)
);

OAI21xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_18),
.B(n_13),
.Y(n_42)
);

OAI21xp5_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_16),
.B(n_14),
.Y(n_43)
);

INVx3_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_43),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_38),
.Y(n_46)
);

CKINVDCx20_ASAP7_75t_R g47 ( 
.A(n_45),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_SL g48 ( 
.A1(n_47),
.A2(n_46),
.B1(n_44),
.B2(n_10),
.Y(n_48)
);


endmodule