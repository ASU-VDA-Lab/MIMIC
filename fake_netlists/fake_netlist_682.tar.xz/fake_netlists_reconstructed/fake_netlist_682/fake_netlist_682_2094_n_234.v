module fake_netlist_682_2094_n_234 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_234);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_234;

wire n_61;
wire n_99;
wire n_210;
wire n_115;
wire n_233;
wire n_219;
wire n_110;
wire n_148;
wire n_27;
wire n_86;
wire n_147;
wire n_171;
wire n_230;
wire n_102;
wire n_40;
wire n_66;
wire n_165;
wire n_88;
wire n_47;
wire n_119;
wire n_175;
wire n_35;
wire n_196;
wire n_52;
wire n_220;
wire n_213;
wire n_71;
wire n_150;
wire n_162;
wire n_157;
wire n_179;
wire n_121;
wire n_182;
wire n_60;
wire n_189;
wire n_33;
wire n_89;
wire n_114;
wire n_181;
wire n_194;
wire n_211;
wire n_30;
wire n_212;
wire n_112;
wire n_197;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_83;
wire n_113;
wire n_229;
wire n_131;
wire n_45;
wire n_204;
wire n_124;
wire n_158;
wire n_163;
wire n_130;
wire n_156;
wire n_64;
wire n_190;
wire n_146;
wire n_85;
wire n_136;
wire n_58;
wire n_218;
wire n_62;
wire n_200;
wire n_76;
wire n_63;
wire n_184;
wire n_70;
wire n_224;
wire n_69;
wire n_101;
wire n_141;
wire n_123;
wire n_53;
wire n_109;
wire n_231;
wire n_168;
wire n_173;
wire n_74;
wire n_188;
wire n_160;
wire n_176;
wire n_209;
wire n_226;
wire n_144;
wire n_170;
wire n_187;
wire n_28;
wire n_208;
wire n_164;
wire n_94;
wire n_149;
wire n_81;
wire n_75;
wire n_161;
wire n_55;
wire n_192;
wire n_111;
wire n_54;
wire n_78;
wire n_207;
wire n_44;
wire n_38;
wire n_174;
wire n_203;
wire n_199;
wire n_91;
wire n_167;
wire n_42;
wire n_106;
wire n_116;
wire n_127;
wire n_34;
wire n_225;
wire n_100;
wire n_145;
wire n_43;
wire n_84;
wire n_177;
wire n_37;
wire n_51;
wire n_191;
wire n_68;
wire n_140;
wire n_92;
wire n_195;
wire n_129;
wire n_90;
wire n_143;
wire n_169;
wire n_32;
wire n_77;
wire n_82;
wire n_117;
wire n_152;
wire n_134;
wire n_180;
wire n_228;
wire n_128;
wire n_202;
wire n_172;
wire n_93;
wire n_193;
wire n_118;
wire n_186;
wire n_97;
wire n_214;
wire n_216;
wire n_95;
wire n_98;
wire n_103;
wire n_135;
wire n_222;
wire n_125;
wire n_122;
wire n_79;
wire n_178;
wire n_154;
wire n_104;
wire n_105;
wire n_215;
wire n_139;
wire n_133;
wire n_183;
wire n_155;
wire n_120;
wire n_217;
wire n_137;
wire n_46;
wire n_31;
wire n_87;
wire n_41;
wire n_73;
wire n_205;
wire n_29;
wire n_56;
wire n_159;
wire n_185;
wire n_72;
wire n_65;
wire n_80;
wire n_107;
wire n_132;
wire n_227;
wire n_232;
wire n_138;
wire n_151;
wire n_153;
wire n_201;
wire n_36;
wire n_142;
wire n_126;
wire n_223;
wire n_221;
wire n_206;
wire n_49;
wire n_57;
wire n_96;
wire n_166;
wire n_198;
wire n_108;

INVxp67_ASAP7_75t_SL g27 ( 
.A(n_12),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_3),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_15),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_19),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_15),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_4),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_0),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_17),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_12),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_17),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_26),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_2),
.Y(n_39)
);

INVxp67_ASAP7_75t_SL g40 ( 
.A(n_24),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_7),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_35),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_35),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_35),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_38),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_38),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_30),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_38),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_28),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_29),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_29),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_32),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_37),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_37),
.B(n_9),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_28),
.Y(n_55)
);

OAI221xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_27),
.B1(n_40),
.B2(n_36),
.C(n_33),
.Y(n_56)
);

NAND2x1p5_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_33),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_51),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_50),
.Y(n_59)
);

AO22x2_ASAP7_75t_L g60 ( 
.A1(n_54),
.A2(n_40),
.B1(n_27),
.B2(n_34),
.Y(n_60)
);

NAND2xp33_ASAP7_75t_L g61 ( 
.A(n_47),
.B(n_41),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_49),
.B(n_34),
.Y(n_62)
);

BUFx3_ASAP7_75t_L g63 ( 
.A(n_43),
.Y(n_63)
);

NAND2xp33_ASAP7_75t_L g64 ( 
.A(n_52),
.B(n_41),
.Y(n_64)
);

BUFx8_ASAP7_75t_L g65 ( 
.A(n_51),
.Y(n_65)
);

BUFx6f_ASAP7_75t_SL g66 ( 
.A(n_53),
.Y(n_66)
);

NAND2x1p5_ASAP7_75t_L g67 ( 
.A(n_49),
.B(n_39),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_53),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_42),
.Y(n_69)
);

NAND2xp5_ASAP7_75t_SL g70 ( 
.A(n_43),
.B(n_41),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_42),
.Y(n_71)
);

HB1xp67_ASAP7_75t_L g72 ( 
.A(n_44),
.Y(n_72)
);

OAI22xp5_ASAP7_75t_L g73 ( 
.A1(n_60),
.A2(n_56),
.B1(n_57),
.B2(n_31),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_SL g74 ( 
.A(n_57),
.B(n_39),
.Y(n_74)
);

NAND2xp5_ASAP7_75t_L g75 ( 
.A(n_57),
.B(n_44),
.Y(n_75)
);

NOR2xp33_ASAP7_75t_R g76 ( 
.A(n_61),
.B(n_31),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_69),
.Y(n_77)
);

AND3x1_ASAP7_75t_SL g78 ( 
.A(n_59),
.B(n_60),
.C(n_58),
.Y(n_78)
);

NAND2xp5_ASAP7_75t_L g79 ( 
.A(n_64),
.B(n_45),
.Y(n_79)
);

NAND2xp5_ASAP7_75t_L g80 ( 
.A(n_67),
.B(n_45),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_67),
.B(n_63),
.Y(n_81)
);

AND2x2_ASAP7_75t_L g82 ( 
.A(n_58),
.B(n_46),
.Y(n_82)
);

NAND2xp5_ASAP7_75t_L g83 ( 
.A(n_67),
.B(n_63),
.Y(n_83)
);

OAI21x1_ASAP7_75t_L g84 ( 
.A1(n_62),
.A2(n_48),
.B(n_46),
.Y(n_84)
);

NOR2xp33_ASAP7_75t_R g85 ( 
.A(n_65),
.B(n_1),
.Y(n_85)
);

OR2x2_ASAP7_75t_L g86 ( 
.A(n_72),
.B(n_48),
.Y(n_86)
);

AOI22xp5_ASAP7_75t_L g87 ( 
.A1(n_60),
.A2(n_14),
.B1(n_13),
.B2(n_9),
.Y(n_87)
);

INVx2_ASAP7_75t_L g88 ( 
.A(n_69),
.Y(n_88)
);

NOR2xp33_ASAP7_75t_R g89 ( 
.A(n_65),
.B(n_5),
.Y(n_89)
);

AND2x2_ASAP7_75t_L g90 ( 
.A(n_68),
.B(n_13),
.Y(n_90)
);

NAND2xp5_ASAP7_75t_L g91 ( 
.A(n_71),
.B(n_6),
.Y(n_91)
);

NAND2xp5_ASAP7_75t_L g92 ( 
.A(n_71),
.B(n_68),
.Y(n_92)
);

NAND2xp5_ASAP7_75t_L g93 ( 
.A(n_70),
.B(n_8),
.Y(n_93)
);

HB1xp67_ASAP7_75t_L g94 ( 
.A(n_90),
.Y(n_94)
);

NAND2xp5_ASAP7_75t_L g95 ( 
.A(n_75),
.B(n_60),
.Y(n_95)
);

AOI21xp5_ASAP7_75t_SL g96 ( 
.A1(n_81),
.A2(n_66),
.B(n_65),
.Y(n_96)
);

INVx2_ASAP7_75t_L g97 ( 
.A(n_88),
.Y(n_97)
);

INVx1_ASAP7_75t_L g98 ( 
.A(n_88),
.Y(n_98)
);

AND2x2_ASAP7_75t_L g99 ( 
.A(n_82),
.B(n_90),
.Y(n_99)
);

A2O1A1Ixp33_ASAP7_75t_L g100 ( 
.A1(n_87),
.A2(n_66),
.B(n_16),
.C(n_14),
.Y(n_100)
);

CKINVDCx11_ASAP7_75t_R g101 ( 
.A(n_73),
.Y(n_101)
);

AND2x2_ASAP7_75t_L g102 ( 
.A(n_82),
.B(n_66),
.Y(n_102)
);

AND2x2_ASAP7_75t_L g103 ( 
.A(n_92),
.B(n_16),
.Y(n_103)
);

NOR2xp67_ASAP7_75t_L g104 ( 
.A(n_83),
.B(n_80),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_77),
.B(n_18),
.Y(n_105)
);

BUFx3_ASAP7_75t_L g106 ( 
.A(n_77),
.Y(n_106)
);

OA21x2_ASAP7_75t_L g107 ( 
.A1(n_84),
.A2(n_91),
.B(n_92),
.Y(n_107)
);

O2A1O1Ixp5_ASAP7_75t_L g108 ( 
.A1(n_74),
.A2(n_20),
.B(n_19),
.C(n_18),
.Y(n_108)
);

BUFx2_ASAP7_75t_L g109 ( 
.A(n_76),
.Y(n_109)
);

OR2x2_ASAP7_75t_L g110 ( 
.A(n_73),
.B(n_20),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_88),
.B(n_21),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_84),
.Y(n_112)
);

NOR2x1_ASAP7_75t_SL g113 ( 
.A(n_106),
.B(n_91),
.Y(n_113)
);

NOR2xp33_ASAP7_75t_L g114 ( 
.A(n_109),
.B(n_86),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_98),
.Y(n_115)
);

NAND4xp25_ASAP7_75t_L g116 ( 
.A(n_110),
.B(n_87),
.C(n_86),
.D(n_79),
.Y(n_116)
);

O2A1O1Ixp33_ASAP7_75t_SL g117 ( 
.A1(n_112),
.A2(n_95),
.B(n_105),
.C(n_111),
.Y(n_117)
);

AND2x2_ASAP7_75t_L g118 ( 
.A(n_99),
.B(n_85),
.Y(n_118)
);

AOI22xp5_ASAP7_75t_L g119 ( 
.A1(n_95),
.A2(n_78),
.B1(n_93),
.B2(n_89),
.Y(n_119)
);

BUFx6f_ASAP7_75t_L g120 ( 
.A(n_106),
.Y(n_120)
);

NAND2xp5_ASAP7_75t_L g121 ( 
.A(n_99),
.B(n_93),
.Y(n_121)
);

AOI221xp5_ASAP7_75t_L g122 ( 
.A1(n_110),
.A2(n_22),
.B1(n_21),
.B2(n_23),
.C(n_24),
.Y(n_122)
);

BUFx3_ASAP7_75t_L g123 ( 
.A(n_109),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_99),
.B(n_22),
.Y(n_124)
);

INVx4_ASAP7_75t_SL g125 ( 
.A(n_120),
.Y(n_125)
);

INVx1_ASAP7_75t_L g126 ( 
.A(n_115),
.Y(n_126)
);

AOI21xp5_ASAP7_75t_L g127 ( 
.A1(n_121),
.A2(n_117),
.B(n_113),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_SL g128 ( 
.A(n_120),
.B(n_119),
.Y(n_128)
);

OR2x6_ASAP7_75t_L g129 ( 
.A(n_123),
.B(n_110),
.Y(n_129)
);

HB1xp67_ASAP7_75t_L g130 ( 
.A(n_120),
.Y(n_130)
);

BUFx3_ASAP7_75t_L g131 ( 
.A(n_123),
.Y(n_131)
);

INVx1_ASAP7_75t_L g132 ( 
.A(n_115),
.Y(n_132)
);

OAI21xp5_ASAP7_75t_L g133 ( 
.A1(n_124),
.A2(n_112),
.B(n_104),
.Y(n_133)
);

AOI21xp5_ASAP7_75t_L g134 ( 
.A1(n_113),
.A2(n_104),
.B(n_107),
.Y(n_134)
);

INVx2_ASAP7_75t_L g135 ( 
.A(n_126),
.Y(n_135)
);

AND2x2_ASAP7_75t_L g136 ( 
.A(n_132),
.B(n_129),
.Y(n_136)
);

INVx2_ASAP7_75t_L g137 ( 
.A(n_130),
.Y(n_137)
);

BUFx3_ASAP7_75t_L g138 ( 
.A(n_131),
.Y(n_138)
);

OR2x2_ASAP7_75t_L g139 ( 
.A(n_129),
.B(n_116),
.Y(n_139)
);

BUFx3_ASAP7_75t_L g140 ( 
.A(n_130),
.Y(n_140)
);

AOI22xp5_ASAP7_75t_L g141 ( 
.A1(n_129),
.A2(n_114),
.B1(n_101),
.B2(n_118),
.Y(n_141)
);

INVx1_ASAP7_75t_L g142 ( 
.A(n_125),
.Y(n_142)
);

NOR3xp33_ASAP7_75t_L g143 ( 
.A(n_128),
.B(n_122),
.C(n_118),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_125),
.Y(n_144)
);

AOI22xp33_ASAP7_75t_L g145 ( 
.A1(n_128),
.A2(n_101),
.B1(n_109),
.B2(n_102),
.Y(n_145)
);

INVx1_ASAP7_75t_L g146 ( 
.A(n_135),
.Y(n_146)
);

HB1xp67_ASAP7_75t_L g147 ( 
.A(n_137),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_135),
.Y(n_148)
);

INVx2_ASAP7_75t_SL g149 ( 
.A(n_142),
.Y(n_149)
);

OR2x2_ASAP7_75t_L g150 ( 
.A(n_137),
.B(n_111),
.Y(n_150)
);

OR2x2_ASAP7_75t_L g151 ( 
.A(n_137),
.B(n_105),
.Y(n_151)
);

INVx1_ASAP7_75t_SL g152 ( 
.A(n_138),
.Y(n_152)
);

INVx1_ASAP7_75t_SL g153 ( 
.A(n_138),
.Y(n_153)
);

HB1xp67_ASAP7_75t_L g154 ( 
.A(n_136),
.Y(n_154)
);

INVx1_ASAP7_75t_L g155 ( 
.A(n_135),
.Y(n_155)
);

OR2x2_ASAP7_75t_L g156 ( 
.A(n_140),
.B(n_133),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_136),
.Y(n_157)
);

AND2x2_ASAP7_75t_L g158 ( 
.A(n_136),
.B(n_103),
.Y(n_158)
);

INVxp67_ASAP7_75t_L g159 ( 
.A(n_138),
.Y(n_159)
);

OR2x2_ASAP7_75t_L g160 ( 
.A(n_140),
.B(n_103),
.Y(n_160)
);

INVx1_ASAP7_75t_L g161 ( 
.A(n_140),
.Y(n_161)
);

NOR2xp33_ASAP7_75t_L g162 ( 
.A(n_159),
.B(n_139),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_146),
.Y(n_163)
);

INVx1_ASAP7_75t_SL g164 ( 
.A(n_152),
.Y(n_164)
);

AND2x2_ASAP7_75t_L g165 ( 
.A(n_157),
.B(n_158),
.Y(n_165)
);

OR2x2_ASAP7_75t_L g166 ( 
.A(n_157),
.B(n_139),
.Y(n_166)
);

NOR2x1_ASAP7_75t_L g167 ( 
.A(n_151),
.B(n_142),
.Y(n_167)
);

NAND2xp5_ASAP7_75t_L g168 ( 
.A(n_158),
.B(n_143),
.Y(n_168)
);

AND2x2_ASAP7_75t_L g169 ( 
.A(n_154),
.B(n_143),
.Y(n_169)
);

NOR2x1_ASAP7_75t_L g170 ( 
.A(n_151),
.B(n_150),
.Y(n_170)
);

INVx2_ASAP7_75t_L g171 ( 
.A(n_148),
.Y(n_171)
);

OAI21xp33_ASAP7_75t_L g172 ( 
.A1(n_160),
.A2(n_100),
.B(n_103),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_155),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_161),
.Y(n_174)
);

AND2x2_ASAP7_75t_L g175 ( 
.A(n_161),
.B(n_141),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_147),
.Y(n_176)
);

NAND2xp5_ASAP7_75t_L g177 ( 
.A(n_153),
.B(n_141),
.Y(n_177)
);

NAND2xp5_ASAP7_75t_SL g178 ( 
.A(n_156),
.B(n_145),
.Y(n_178)
);

NAND2xp5_ASAP7_75t_L g179 ( 
.A(n_160),
.B(n_100),
.Y(n_179)
);

AND2x2_ASAP7_75t_L g180 ( 
.A(n_156),
.B(n_150),
.Y(n_180)
);

NOR2xp33_ASAP7_75t_L g181 ( 
.A(n_168),
.B(n_162),
.Y(n_181)
);

NOR2x1_ASAP7_75t_L g182 ( 
.A(n_167),
.B(n_177),
.Y(n_182)
);

BUFx6f_ASAP7_75t_L g183 ( 
.A(n_166),
.Y(n_183)
);

AND2x2_ASAP7_75t_L g184 ( 
.A(n_165),
.B(n_149),
.Y(n_184)
);

OR2x2_ASAP7_75t_L g185 ( 
.A(n_180),
.B(n_149),
.Y(n_185)
);

AND2x4_ASAP7_75t_L g186 ( 
.A(n_174),
.B(n_144),
.Y(n_186)
);

NAND2xp5_ASAP7_75t_L g187 ( 
.A(n_180),
.B(n_127),
.Y(n_187)
);

NAND2xp5_ASAP7_75t_L g188 ( 
.A(n_165),
.B(n_170),
.Y(n_188)
);

NAND2xp5_ASAP7_75t_L g189 ( 
.A(n_170),
.B(n_134),
.Y(n_189)
);

NOR3xp33_ASAP7_75t_SL g190 ( 
.A(n_178),
.B(n_172),
.C(n_179),
.Y(n_190)
);

AOI21xp5_ASAP7_75t_L g191 ( 
.A1(n_167),
.A2(n_144),
.B(n_107),
.Y(n_191)
);

NAND2xp5_ASAP7_75t_L g192 ( 
.A(n_169),
.B(n_94),
.Y(n_192)
);

AOI22xp5_ASAP7_75t_L g193 ( 
.A1(n_175),
.A2(n_102),
.B1(n_94),
.B2(n_120),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_174),
.Y(n_194)
);

NAND2xp5_ASAP7_75t_L g195 ( 
.A(n_169),
.B(n_23),
.Y(n_195)
);

INVx1_ASAP7_75t_L g196 ( 
.A(n_163),
.Y(n_196)
);

INVxp33_ASAP7_75t_L g197 ( 
.A(n_166),
.Y(n_197)
);

INVx2_ASAP7_75t_L g198 ( 
.A(n_171),
.Y(n_198)
);

OR2x2_ASAP7_75t_L g199 ( 
.A(n_176),
.B(n_107),
.Y(n_199)
);

NAND2xp33_ASAP7_75t_L g200 ( 
.A(n_190),
.B(n_175),
.Y(n_200)
);

NAND2xp5_ASAP7_75t_L g201 ( 
.A(n_181),
.B(n_176),
.Y(n_201)
);

AOI221xp5_ASAP7_75t_L g202 ( 
.A1(n_195),
.A2(n_108),
.B1(n_173),
.B2(n_163),
.C(n_164),
.Y(n_202)
);

INVxp67_ASAP7_75t_SL g203 ( 
.A(n_194),
.Y(n_203)
);

NAND2xp5_ASAP7_75t_L g204 ( 
.A(n_181),
.B(n_173),
.Y(n_204)
);

INVx1_ASAP7_75t_L g205 ( 
.A(n_196),
.Y(n_205)
);

INVx2_ASAP7_75t_L g206 ( 
.A(n_183),
.Y(n_206)
);

INVx1_ASAP7_75t_L g207 ( 
.A(n_185),
.Y(n_207)
);

AOI21xp5_ASAP7_75t_L g208 ( 
.A1(n_191),
.A2(n_96),
.B(n_171),
.Y(n_208)
);

OR3x1_ASAP7_75t_L g209 ( 
.A(n_190),
.B(n_98),
.C(n_25),
.Y(n_209)
);

INVxp67_ASAP7_75t_L g210 ( 
.A(n_182),
.Y(n_210)
);

INVx1_ASAP7_75t_L g211 ( 
.A(n_188),
.Y(n_211)
);

NAND3x1_ASAP7_75t_SL g212 ( 
.A(n_184),
.B(n_108),
.C(n_193),
.Y(n_212)
);

OAI31xp33_ASAP7_75t_L g213 ( 
.A1(n_192),
.A2(n_102),
.A3(n_106),
.B(n_26),
.Y(n_213)
);

AOI22xp5_ASAP7_75t_L g214 ( 
.A1(n_209),
.A2(n_187),
.B1(n_189),
.B2(n_183),
.Y(n_214)
);

NAND2xp5_ASAP7_75t_L g215 ( 
.A(n_211),
.B(n_186),
.Y(n_215)
);

INVx1_ASAP7_75t_L g216 ( 
.A(n_203),
.Y(n_216)
);

NAND2xp5_ASAP7_75t_L g217 ( 
.A(n_204),
.B(n_201),
.Y(n_217)
);

HB1xp67_ASAP7_75t_L g218 ( 
.A(n_210),
.Y(n_218)
);

NAND3xp33_ASAP7_75t_L g219 ( 
.A(n_210),
.B(n_191),
.C(n_183),
.Y(n_219)
);

NAND3x1_ASAP7_75t_L g220 ( 
.A(n_213),
.B(n_197),
.C(n_186),
.Y(n_220)
);

NOR2xp67_ASAP7_75t_L g221 ( 
.A(n_206),
.B(n_198),
.Y(n_221)
);

AOI21xp5_ASAP7_75t_L g222 ( 
.A1(n_200),
.A2(n_199),
.B(n_183),
.Y(n_222)
);

AND2x2_ASAP7_75t_L g223 ( 
.A(n_218),
.B(n_215),
.Y(n_223)
);

AOI221xp5_ASAP7_75t_L g224 ( 
.A1(n_219),
.A2(n_205),
.B1(n_203),
.B2(n_202),
.C(n_207),
.Y(n_224)
);

AOI21xp5_ASAP7_75t_L g225 ( 
.A1(n_217),
.A2(n_208),
.B(n_212),
.Y(n_225)
);

OAI22xp33_ASAP7_75t_L g226 ( 
.A1(n_214),
.A2(n_220),
.B1(n_222),
.B2(n_216),
.Y(n_226)
);

NOR4xp25_ASAP7_75t_L g227 ( 
.A(n_221),
.B(n_212),
.C(n_97),
.D(n_125),
.Y(n_227)
);

NOR3xp33_ASAP7_75t_SL g228 ( 
.A(n_226),
.B(n_225),
.C(n_224),
.Y(n_228)
);

OAI22xp5_ASAP7_75t_SL g229 ( 
.A1(n_227),
.A2(n_107),
.B1(n_120),
.B2(n_106),
.Y(n_229)
);

AOI222xp33_ASAP7_75t_L g230 ( 
.A1(n_223),
.A2(n_10),
.B1(n_11),
.B2(n_97),
.C1(n_107),
.C2(n_226),
.Y(n_230)
);

INVx4_ASAP7_75t_L g231 ( 
.A(n_228),
.Y(n_231)
);

XOR2xp5_ASAP7_75t_L g232 ( 
.A(n_229),
.B(n_230),
.Y(n_232)
);

OR2x2_ASAP7_75t_L g233 ( 
.A(n_232),
.B(n_107),
.Y(n_233)
);

OAI22xp5_ASAP7_75t_SL g234 ( 
.A1(n_233),
.A2(n_97),
.B1(n_231),
.B2(n_232),
.Y(n_234)
);


endmodule