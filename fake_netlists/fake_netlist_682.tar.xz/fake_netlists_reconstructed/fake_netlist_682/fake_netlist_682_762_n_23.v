module fake_netlist_682_762_n_23 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_23);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_23;

wire n_21;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_8;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_1),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

INVxp33_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_11),
.B(n_3),
.Y(n_13)
);

O2A1O1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_6),
.B(n_5),
.C(n_3),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_12),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_14),
.B(n_9),
.C(n_8),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI22x1_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_18),
.B1(n_6),
.B2(n_5),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_10),
.B1(n_7),
.B2(n_0),
.Y(n_23)
);


endmodule