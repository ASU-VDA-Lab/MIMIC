module fake_netlist_682_119_n_37 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_37);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_37;

wire n_24;
wire n_21;
wire n_27;
wire n_22;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_4),
.B(n_19),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_9),
.B(n_10),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_23),
.B(n_18),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_21),
.B(n_18),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_24),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_25),
.B1(n_20),
.B2(n_22),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_29),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_32)
);

CKINVDCx16_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_32),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_35)
);

OAI22x1_ASAP7_75t_SL g36 ( 
.A1(n_33),
.A2(n_13),
.B1(n_11),
.B2(n_8),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_35),
.A2(n_36),
.B1(n_16),
.B2(n_15),
.Y(n_37)
);


endmodule