module fake_netlist_682_1372_n_15 (n_3, n_0, n_2, n_1, n_15);

input n_3;
input n_0;
input n_2;
input n_1;

output n_15;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_11;
wire n_8;
wire n_13;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.C(n_2),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B1(n_3),
.B2(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NOR3xp33_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_7),
.C(n_6),
.Y(n_13)
);

XNOR2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_3),
.B1(n_6),
.B2(n_11),
.C1(n_8),
.C2(n_12),
.Y(n_15)
);


endmodule