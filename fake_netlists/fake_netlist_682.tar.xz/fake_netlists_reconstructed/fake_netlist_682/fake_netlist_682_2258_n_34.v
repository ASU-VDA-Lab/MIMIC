module fake_netlist_682_2258_n_34 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_34);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_34;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_31;
wire n_23;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_19;
wire n_30;
wire n_25;
wire n_13;
wire n_14;
wire n_12;

BUFx3_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_1),
.Y(n_14)
);

BUFx8_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

AND2x2_ASAP7_75t_SL g18 ( 
.A(n_3),
.B(n_11),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_8),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

OR2x6_ASAP7_75t_L g21 ( 
.A(n_12),
.B(n_0),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_18),
.B(n_4),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_20),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_17),
.B1(n_19),
.B2(n_13),
.C(n_14),
.Y(n_26)
);

OR2x6_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_17),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_21),
.Y(n_28)
);

AND2x4_ASAP7_75t_SL g29 ( 
.A(n_28),
.B(n_25),
.Y(n_29)
);

XNOR2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_22),
.Y(n_30)
);

CKINVDCx16_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

NAND2x1p5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_23),
.Y(n_32)
);

INVx3_ASAP7_75t_SL g33 ( 
.A(n_32),
.Y(n_33)
);

AOI222xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_6),
.B1(n_9),
.B2(n_10),
.C1(n_23),
.C2(n_26),
.Y(n_34)
);


endmodule