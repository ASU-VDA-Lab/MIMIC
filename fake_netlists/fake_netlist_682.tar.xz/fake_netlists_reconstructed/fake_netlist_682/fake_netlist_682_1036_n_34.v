module fake_netlist_682_1036_n_34 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_34);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_34;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

INVx5_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_0),
.B(n_2),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_8),
.B(n_4),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_6),
.B(n_1),
.Y(n_24)
);

AO32x1_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_21),
.A3(n_17),
.B1(n_13),
.B2(n_15),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_20),
.B(n_23),
.C(n_19),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_R g27 ( 
.A(n_24),
.B(n_15),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_21),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_21),
.B(n_27),
.Y(n_29)
);

OAI21xp33_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_16),
.B(n_18),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AO211x2_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_16),
.B(n_9),
.C(n_7),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_14),
.B2(n_11),
.Y(n_34)
);


endmodule