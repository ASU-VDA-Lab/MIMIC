module fake_netlist_682_599_n_45 (n_2, n_21, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_45);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_45;

wire n_24;
wire n_44;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

INVx1_ASAP7_75t_L g22 ( 
.A(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_9),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_8),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_3),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_10),
.Y(n_29)
);

NAND3xp33_ASAP7_75t_SL g30 ( 
.A(n_28),
.B(n_18),
.C(n_16),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

OAI22x1_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_19),
.B1(n_18),
.B2(n_16),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_23),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_19),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_32),
.Y(n_35)
);

INVx4_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_36),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI22x1_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_29),
.B1(n_26),
.B2(n_24),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_26),
.B1(n_27),
.B2(n_25),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

NAND4xp75_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_2),
.C(n_1),
.D(n_0),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_11),
.B1(n_7),
.B2(n_4),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_17),
.B1(n_21),
.B2(n_43),
.Y(n_45)
);


endmodule