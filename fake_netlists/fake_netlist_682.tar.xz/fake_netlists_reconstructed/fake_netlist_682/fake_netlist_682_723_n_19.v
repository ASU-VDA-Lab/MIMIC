module fake_netlist_682_723_n_19 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_19);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_19;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_8;
wire n_11;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

BUFx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

CKINVDCx16_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

AO22x2_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_12)
);

AOI221x1_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_5),
.B1(n_2),
.B2(n_6),
.C(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B(n_13),
.C(n_10),
.Y(n_16)
);

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_11),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_10),
.B(n_17),
.Y(n_19)
);


endmodule