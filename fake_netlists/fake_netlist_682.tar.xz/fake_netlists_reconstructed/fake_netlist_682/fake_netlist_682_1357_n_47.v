module fake_netlist_682_1357_n_47 (n_2, n_21, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_47);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_47;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_10),
.B1(n_4),
.B2(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_17),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_13),
.Y(n_27)
);

AND2x2_ASAP7_75t_SL g28 ( 
.A(n_5),
.B(n_0),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_14),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_20),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_25),
.B(n_1),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_22),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_27),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_28),
.B1(n_24),
.B2(n_33),
.Y(n_37)
);

NAND2xp33_ASAP7_75t_SL g38 ( 
.A(n_36),
.B(n_29),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_30),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_35),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

NAND3x1_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_6),
.C(n_3),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_9),
.B(n_8),
.C(n_7),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_43),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_12),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

OAI22xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_45),
.B1(n_21),
.B2(n_15),
.Y(n_47)
);


endmodule