module fake_netlist_682_1272_n_12 (n_3, n_0, n_2, n_1, n_12);

input n_3;
input n_0;
input n_2;
input n_1;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

INVxp33_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_1),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

BUFx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVxp67_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B1(n_6),
.B2(n_0),
.Y(n_9)
);

OAI221xp5_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_8),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_10)
);

OAI21x1_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_3),
.B(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule