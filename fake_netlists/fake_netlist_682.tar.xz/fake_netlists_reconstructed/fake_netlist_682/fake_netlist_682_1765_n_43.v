module fake_netlist_682_1765_n_43 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_43);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_43;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_12;
wire n_8;
wire n_36;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_10;
wire n_19;
wire n_39;
wire n_14;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_2),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_6),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_3),
.B(n_0),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_2),
.B(n_1),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_5),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_5),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_7),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_15),
.B(n_13),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_R g23 ( 
.A(n_20),
.B(n_8),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_SL g24 ( 
.A(n_19),
.B(n_10),
.C(n_11),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_17),
.A2(n_14),
.B(n_15),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_22),
.B(n_14),
.Y(n_27)
);

AND2x2_ASAP7_75t_SL g28 ( 
.A(n_25),
.B(n_9),
.Y(n_28)
);

OR2x2_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_9),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_14),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_23),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_SL g33 ( 
.A(n_30),
.B(n_24),
.C(n_18),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_9),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_28),
.Y(n_35)
);

INVxp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI221x1_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_30),
.B1(n_16),
.B2(n_31),
.C(n_15),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVxp67_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

CKINVDCx20_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_33),
.B1(n_29),
.B2(n_31),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_38),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_14),
.B1(n_40),
.B2(n_42),
.Y(n_43)
);


endmodule