module fake_netlist_682_415_n_35 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_35);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_35;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_34;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_13;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_3),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_R g15 ( 
.A(n_3),
.B(n_7),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_9),
.B(n_4),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_5),
.B(n_8),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_16),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_17),
.B(n_1),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_19),
.A2(n_12),
.B(n_2),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_20),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_22),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_25),
.C(n_14),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_25),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_SL g30 ( 
.A1(n_28),
.A2(n_14),
.B1(n_24),
.B2(n_25),
.C(n_13),
.Y(n_30)
);

OAI211xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_18),
.B(n_24),
.C(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_31),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_15),
.B1(n_5),
.B2(n_4),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_11),
.B1(n_33),
.B2(n_28),
.Y(n_35)
);


endmodule