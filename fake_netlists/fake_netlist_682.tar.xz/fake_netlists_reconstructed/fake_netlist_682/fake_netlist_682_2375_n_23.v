module fake_netlist_682_2375_n_23 (n_4, n_2, n_3, n_1, n_0, n_23);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_23;

wire n_21;
wire n_17;
wire n_6;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_5;
wire n_7;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_4),
.B1(n_0),
.B2(n_2),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_3),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_6),
.B(n_1),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_1),
.C(n_5),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_7),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_SL g17 ( 
.A1(n_15),
.A2(n_13),
.B1(n_14),
.B2(n_5),
.Y(n_17)
);

NAND4xp25_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_8),
.C(n_6),
.D(n_11),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

NAND4xp25_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_16),
.C(n_6),
.D(n_5),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_21),
.B(n_19),
.Y(n_23)
);


endmodule