module fake_netlist_682_1328_n_17 (n_3, n_0, n_2, n_1, n_17);

input n_3;
input n_0;
input n_2;
input n_1;

output n_17;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_15;
wire n_11;
wire n_13;
wire n_16;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx2_ASAP7_75t_SL g4 ( 
.A(n_1),
.Y(n_4)
);

OAI22xp33_ASAP7_75t_L g5 ( 
.A1(n_1),
.A2(n_0),
.B1(n_3),
.B2(n_2),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_2),
.Y(n_6)
);

AOI21xp5_ASAP7_75t_SL g7 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

AO21x1_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.B(n_8),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_4),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_6),
.B1(n_13),
.B2(n_11),
.C(n_9),
.Y(n_14)
);

NOR2x1_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_5),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B1(n_9),
.B2(n_2),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_3),
.B1(n_15),
.B2(n_14),
.Y(n_17)
);


endmodule