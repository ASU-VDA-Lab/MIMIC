module fake_netlist_682_1066_n_7 (n_4, n_2, n_3, n_1, n_0, n_7);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_7;

wire n_5;
wire n_6;

AOI22xp33_ASAP7_75t_SL g5 ( 
.A1(n_2),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_5)
);

AND2x2_ASAP7_75t_SL g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

OAI211xp5_ASAP7_75t_SL g7 ( 
.A1(n_5),
.A2(n_0),
.B(n_1),
.C(n_6),
.Y(n_7)
);


endmodule