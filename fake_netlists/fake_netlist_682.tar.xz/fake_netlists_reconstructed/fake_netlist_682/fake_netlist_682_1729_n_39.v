module fake_netlist_682_1729_n_39 (n_2, n_21, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_39);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_39;

wire n_24;
wire n_38;
wire n_27;
wire n_22;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_6),
.B(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_9),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_18),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_7),
.B(n_2),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_15),
.B(n_4),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

AO32x2_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_19),
.A3(n_3),
.B1(n_0),
.B2(n_1),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_23),
.B(n_19),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_8),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_SL g32 ( 
.A(n_30),
.B(n_27),
.C(n_24),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_26),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_26),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_32),
.B1(n_22),
.B2(n_29),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_11),
.B1(n_10),
.B2(n_12),
.C(n_13),
.Y(n_36)
);

XNOR2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_14),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_37),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_21),
.B1(n_20),
.B2(n_17),
.Y(n_39)
);


endmodule