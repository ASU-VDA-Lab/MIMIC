module fake_netlist_682_825_n_24 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_24);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_24;

wire n_21;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_12;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_5),
.B(n_4),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_13)
);

NOR2xp67_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_6),
.Y(n_14)
);

AO32x2_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_11),
.A3(n_7),
.B1(n_6),
.B2(n_9),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_12),
.B1(n_11),
.B2(n_7),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_12),
.Y(n_17)
);

XOR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_19),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_20),
.B1(n_1),
.B2(n_0),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_3),
.B1(n_22),
.B2(n_20),
.Y(n_24)
);


endmodule