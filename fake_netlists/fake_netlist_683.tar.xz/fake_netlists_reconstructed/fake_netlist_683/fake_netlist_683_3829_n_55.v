module fake_netlist_683_3829_n_55 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_55);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_55;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_19;
wire n_39;

INVx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_4),
.B(n_12),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_9),
.A2(n_8),
.B1(n_17),
.B2(n_0),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_2),
.B(n_3),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_5),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_18),
.B(n_19),
.Y(n_27)
);

INVx5_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_SL g30 ( 
.A(n_23),
.B(n_14),
.C(n_1),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_SL g33 ( 
.A(n_29),
.B(n_26),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_29),
.A2(n_26),
.B1(n_20),
.B2(n_22),
.Y(n_34)
);

NAND4xp25_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_27),
.C(n_31),
.D(n_18),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_27),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_32),
.Y(n_39)
);

NOR3xp33_ASAP7_75t_SL g40 ( 
.A(n_36),
.B(n_20),
.C(n_30),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

INVxp67_ASAP7_75t_SL g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_40),
.B1(n_22),
.B2(n_28),
.C(n_1),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_41),
.B1(n_42),
.B2(n_28),
.Y(n_45)
);

XNOR2x1_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_15),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

NOR2x1p5_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_22),
.Y(n_48)
);

NAND3xp33_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_22),
.C(n_28),
.Y(n_49)
);

BUFx12f_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

AOI21x1_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_48),
.B(n_49),
.Y(n_52)
);

OAI21x1_ASAP7_75t_SL g53 ( 
.A1(n_50),
.A2(n_16),
.B(n_15),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_SL g54 ( 
.A1(n_53),
.A2(n_17),
.B1(n_16),
.B2(n_7),
.Y(n_54)
);

XNOR2xp5_ASAP7_75t_L g55 ( 
.A(n_54),
.B(n_52),
.Y(n_55)
);


endmodule