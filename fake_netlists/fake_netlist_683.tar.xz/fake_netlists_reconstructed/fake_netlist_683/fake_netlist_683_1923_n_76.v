module fake_netlist_683_1923_n_76 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_76);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_76;

wire n_54;
wire n_24;
wire n_61;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_22;
wire n_66;
wire n_47;
wire n_20;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_71;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_70;
wire n_31;
wire n_23;
wire n_46;
wire n_41;
wire n_69;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_68;
wire n_72;
wire n_33;
wire n_65;
wire n_73;
wire n_74;
wire n_36;
wire n_75;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_67;
wire n_39;
wire n_55;

INVx2_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_17),
.B(n_6),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_9),
.B(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_4),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_11),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

NAND2x1_ASAP7_75t_L g30 ( 
.A(n_12),
.B(n_2),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_14),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_13),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_SL g33 ( 
.A(n_21),
.B(n_2),
.C(n_0),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_SL g34 ( 
.A(n_22),
.B(n_16),
.C(n_0),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_32),
.B(n_3),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_32),
.Y(n_36)
);

BUFx3_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_24),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_20),
.Y(n_39)
);

BUFx3_ASAP7_75t_L g40 ( 
.A(n_31),
.Y(n_40)
);

AOI211xp5_ASAP7_75t_L g41 ( 
.A1(n_20),
.A2(n_29),
.B(n_27),
.C(n_26),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_28),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_37),
.Y(n_43)
);

AND2x4_ASAP7_75t_L g44 ( 
.A(n_38),
.B(n_29),
.Y(n_44)
);

AO21x2_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_23),
.B(n_25),
.Y(n_45)
);

NAND2xp33_ASAP7_75t_R g46 ( 
.A(n_33),
.B(n_23),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_37),
.Y(n_47)
);

NAND2xp33_ASAP7_75t_SL g48 ( 
.A(n_36),
.B(n_30),
.Y(n_48)
);

OAI22xp33_ASAP7_75t_L g49 ( 
.A1(n_38),
.A2(n_29),
.B1(n_19),
.B2(n_18),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_43),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

OAI31xp33_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_48),
.A3(n_38),
.B(n_42),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_45),
.B(n_47),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_44),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_44),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_34),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_37),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_51),
.B1(n_46),
.B2(n_54),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_56),
.Y(n_61)
);

OR2x6_ASAP7_75t_L g62 ( 
.A(n_55),
.B(n_39),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_40),
.Y(n_63)
);

AOI21xp5_ASAP7_75t_L g64 ( 
.A1(n_61),
.A2(n_50),
.B(n_49),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_60),
.Y(n_65)
);

O2A1O1Ixp33_ASAP7_75t_L g66 ( 
.A1(n_62),
.A2(n_39),
.B(n_40),
.C(n_41),
.Y(n_66)
);

INVx2_ASAP7_75t_L g67 ( 
.A(n_63),
.Y(n_67)
);

OAI22xp5_ASAP7_75t_SL g68 ( 
.A1(n_62),
.A2(n_46),
.B1(n_29),
.B2(n_41),
.Y(n_68)
);

AND2x2_ASAP7_75t_L g69 ( 
.A(n_65),
.B(n_59),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_67),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_64),
.B(n_40),
.Y(n_71)
);

NOR3xp33_ASAP7_75t_SL g72 ( 
.A(n_68),
.B(n_50),
.C(n_35),
.Y(n_72)
);

HB1xp67_ASAP7_75t_L g73 ( 
.A(n_70),
.Y(n_73)
);

INVx1_ASAP7_75t_SL g74 ( 
.A(n_69),
.Y(n_74)
);

OAI22xp5_ASAP7_75t_SL g75 ( 
.A1(n_71),
.A2(n_19),
.B1(n_18),
.B2(n_66),
.Y(n_75)
);

AOI322xp5_ASAP7_75t_L g76 ( 
.A1(n_73),
.A2(n_10),
.A3(n_15),
.B1(n_69),
.B2(n_72),
.C1(n_74),
.C2(n_75),
.Y(n_76)
);


endmodule