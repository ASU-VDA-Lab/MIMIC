module fake_netlist_683_85_n_31 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_31);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_31;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_29;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;

AND2x6_ASAP7_75t_L g14 ( 
.A(n_4),
.B(n_13),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_12),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_1),
.B(n_3),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

INVx4_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_19),
.B(n_17),
.Y(n_22)
);

O2A1O1Ixp5_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_14),
.B(n_16),
.C(n_15),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_20),
.B1(n_7),
.B2(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

OA22x2_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_22),
.B1(n_7),
.B2(n_6),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_22),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_14),
.B1(n_8),
.B2(n_5),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_28),
.B1(n_11),
.B2(n_9),
.Y(n_31)
);


endmodule