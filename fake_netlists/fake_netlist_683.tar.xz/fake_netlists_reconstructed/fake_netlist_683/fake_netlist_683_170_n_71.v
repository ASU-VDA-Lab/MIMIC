module fake_netlist_683_170_n_71 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_71);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_71;

wire n_54;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_66;
wire n_47;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_70;
wire n_31;
wire n_46;
wire n_41;
wire n_69;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_68;
wire n_33;
wire n_65;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_59;
wire n_48;
wire n_49;
wire n_57;
wire n_67;
wire n_39;
wire n_55;

INVx2_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_15),
.B(n_24),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_6),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_17),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_18),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_23),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_4),
.B(n_1),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_19),
.A2(n_18),
.B1(n_10),
.B2(n_21),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_20),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_19),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_30),
.B(n_20),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_35),
.B(n_21),
.Y(n_41)
);

BUFx8_ASAP7_75t_SL g42 ( 
.A(n_38),
.Y(n_42)
);

BUFx6f_ASAP7_75t_L g43 ( 
.A(n_29),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_34),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_39),
.B(n_22),
.Y(n_45)
);

OAI21x1_ASAP7_75t_L g46 ( 
.A1(n_40),
.A2(n_27),
.B(n_26),
.Y(n_46)
);

AND2x6_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_31),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

OA21x2_ASAP7_75t_L g49 ( 
.A1(n_44),
.A2(n_33),
.B(n_32),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

BUFx2_ASAP7_75t_SL g51 ( 
.A(n_47),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_41),
.Y(n_52)
);

NOR3xp33_ASAP7_75t_L g53 ( 
.A(n_52),
.B(n_37),
.C(n_45),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_47),
.Y(n_54)
);

AND2x4_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_47),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_47),
.Y(n_56)
);

AO22x1_ASAP7_75t_L g57 ( 
.A1(n_55),
.A2(n_50),
.B1(n_47),
.B2(n_51),
.Y(n_57)
);

OAI321xp33_ASAP7_75t_L g58 ( 
.A1(n_54),
.A2(n_38),
.A3(n_29),
.B1(n_43),
.B2(n_36),
.C(n_42),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_49),
.Y(n_60)
);

AOI322xp5_ASAP7_75t_L g61 ( 
.A1(n_59),
.A2(n_38),
.A3(n_42),
.B1(n_25),
.B2(n_22),
.C1(n_28),
.C2(n_29),
.Y(n_61)
);

A2O1A1Ixp33_ASAP7_75t_L g62 ( 
.A1(n_58),
.A2(n_43),
.B(n_49),
.C(n_48),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_SL g63 ( 
.A(n_57),
.B(n_43),
.Y(n_63)
);

NOR2x1p5_ASAP7_75t_L g64 ( 
.A(n_61),
.B(n_57),
.Y(n_64)
);

OR2x6_ASAP7_75t_L g65 ( 
.A(n_63),
.B(n_60),
.Y(n_65)
);

INVx2_ASAP7_75t_SL g66 ( 
.A(n_62),
.Y(n_66)
);

AND2x4_ASAP7_75t_L g67 ( 
.A(n_63),
.B(n_0),
.Y(n_67)
);

OAI22x1_ASAP7_75t_L g68 ( 
.A1(n_64),
.A2(n_7),
.B1(n_3),
.B2(n_2),
.Y(n_68)
);

AOI21xp5_ASAP7_75t_SL g69 ( 
.A1(n_67),
.A2(n_9),
.B(n_8),
.Y(n_69)
);

AOI221x1_ASAP7_75t_L g70 ( 
.A1(n_68),
.A2(n_65),
.B1(n_66),
.B2(n_12),
.C(n_13),
.Y(n_70)
);

AOI21xp5_ASAP7_75t_L g71 ( 
.A1(n_70),
.A2(n_69),
.B(n_65),
.Y(n_71)
);


endmodule