module fake_netlist_683_1317_n_81 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_81);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_81;

wire n_24;
wire n_61;
wire n_27;
wire n_40;
wire n_66;
wire n_47;
wire n_20;
wire n_35;
wire n_52;
wire n_71;
wire n_60;
wire n_33;
wire n_30;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_45;
wire n_64;
wire n_58;
wire n_62;
wire n_76;
wire n_63;
wire n_70;
wire n_69;
wire n_53;
wire n_74;
wire n_28;
wire n_75;
wire n_55;
wire n_54;
wire n_78;
wire n_44;
wire n_38;
wire n_42;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_68;
wire n_32;
wire n_77;
wire n_21;
wire n_79;
wire n_22;
wire n_46;
wire n_31;
wire n_73;
wire n_41;
wire n_29;
wire n_56;
wire n_72;
wire n_65;
wire n_80;
wire n_36;
wire n_25;
wire n_57;
wire n_49;

INVx1_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_2),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_5),
.B(n_2),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_14),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_15),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_3),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_8),
.B(n_16),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_6),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_18),
.B(n_19),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_17),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_17),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_24),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_0),
.Y(n_36)
);

OAI22xp33_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_18),
.B1(n_1),
.B2(n_0),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_31),
.B(n_1),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_23),
.Y(n_39)
);

BUFx5_ASAP7_75t_L g40 ( 
.A(n_20),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_31),
.Y(n_41)
);

INVx3_ASAP7_75t_L g42 ( 
.A(n_31),
.Y(n_42)
);

A2O1A1Ixp33_ASAP7_75t_L g43 ( 
.A1(n_23),
.A2(n_19),
.B(n_10),
.C(n_7),
.Y(n_43)
);

OAI21x1_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_30),
.B(n_26),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_25),
.B1(n_22),
.B2(n_21),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_30),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_38),
.A2(n_27),
.B(n_29),
.Y(n_47)
);

INVx1_ASAP7_75t_SL g48 ( 
.A(n_35),
.Y(n_48)
);

OAI21x1_ASAP7_75t_L g49 ( 
.A1(n_34),
.A2(n_28),
.B(n_25),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_38),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_50),
.B(n_40),
.Y(n_51)
);

BUFx2_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_46),
.Y(n_53)
);

INVx3_ASAP7_75t_SL g54 ( 
.A(n_48),
.Y(n_54)
);

OR2x2_ASAP7_75t_L g55 ( 
.A(n_45),
.B(n_36),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

INVx1_ASAP7_75t_SL g57 ( 
.A(n_54),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_54),
.B(n_50),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_52),
.B(n_47),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_51),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_56),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_SL g62 ( 
.A(n_57),
.B(n_55),
.Y(n_62)
);

OAI22xp5_ASAP7_75t_L g63 ( 
.A1(n_60),
.A2(n_55),
.B1(n_46),
.B2(n_43),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_58),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_60),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_64),
.B(n_59),
.Y(n_66)
);

NAND2xp5_ASAP7_75t_L g67 ( 
.A(n_65),
.B(n_59),
.Y(n_67)
);

AOI221xp5_ASAP7_75t_L g68 ( 
.A1(n_63),
.A2(n_37),
.B1(n_58),
.B2(n_46),
.C(n_39),
.Y(n_68)
);

AOI21xp5_ASAP7_75t_L g69 ( 
.A1(n_63),
.A2(n_44),
.B(n_49),
.Y(n_69)
);

OA22x2_ASAP7_75t_L g70 ( 
.A1(n_62),
.A2(n_49),
.B1(n_37),
.B2(n_46),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_66),
.B(n_61),
.Y(n_71)
);

NAND3xp33_ASAP7_75t_L g72 ( 
.A(n_68),
.B(n_43),
.C(n_28),
.Y(n_72)
);

NOR2xp67_ASAP7_75t_L g73 ( 
.A(n_67),
.B(n_12),
.Y(n_73)
);

NOR3xp33_ASAP7_75t_L g74 ( 
.A(n_69),
.B(n_44),
.C(n_40),
.Y(n_74)
);

AND2x2_ASAP7_75t_L g75 ( 
.A(n_70),
.B(n_40),
.Y(n_75)
);

AOI211xp5_ASAP7_75t_L g76 ( 
.A1(n_75),
.A2(n_28),
.B(n_40),
.C(n_72),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_71),
.Y(n_77)
);

HB1xp67_ASAP7_75t_L g78 ( 
.A(n_73),
.Y(n_78)
);

XNOR2xp5_ASAP7_75t_L g79 ( 
.A(n_77),
.B(n_74),
.Y(n_79)
);

OAI22x1_ASAP7_75t_L g80 ( 
.A1(n_77),
.A2(n_28),
.B1(n_40),
.B2(n_78),
.Y(n_80)
);

AOI22x1_ASAP7_75t_L g81 ( 
.A1(n_80),
.A2(n_40),
.B1(n_76),
.B2(n_79),
.Y(n_81)
);


endmodule