module fake_netlist_683_859_n_61 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_61);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_61;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_58;
wire n_35;
wire n_34;
wire n_52;
wire n_16;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_19;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_14),
.B(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_7),
.B(n_12),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_9),
.A2(n_8),
.B1(n_6),
.B2(n_4),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_4),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_3),
.B(n_0),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_1),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_11),
.C(n_2),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_16),
.Y(n_31)
);

INVx5_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_23),
.B(n_21),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_23),
.B(n_25),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_25),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_27),
.A2(n_22),
.B1(n_26),
.B2(n_16),
.Y(n_36)
);

NAND3xp33_ASAP7_75t_SL g37 ( 
.A(n_34),
.B(n_19),
.C(n_18),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_27),
.A2(n_17),
.B1(n_24),
.B2(n_1),
.Y(n_38)
);

BUFx5_ASAP7_75t_L g39 ( 
.A(n_27),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_33),
.A2(n_30),
.B1(n_27),
.B2(n_31),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_35),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

OAI221xp5_ASAP7_75t_L g43 ( 
.A1(n_38),
.A2(n_31),
.B1(n_30),
.B2(n_28),
.C(n_32),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_40),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_36),
.Y(n_46)
);

INVxp67_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_42),
.B(n_39),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_28),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

NOR3xp33_ASAP7_75t_SL g52 ( 
.A(n_47),
.B(n_43),
.C(n_37),
.Y(n_52)
);

AOI221xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_30),
.B1(n_28),
.B2(n_48),
.C(n_32),
.Y(n_53)
);

AND2x2_ASAP7_75t_SL g54 ( 
.A(n_51),
.B(n_30),
.Y(n_54)
);

NOR2x1_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_29),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

OA22x2_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_52),
.B1(n_28),
.B2(n_32),
.Y(n_57)
);

INVxp67_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

NAND3xp33_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_32),
.C(n_53),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

AOI22xp33_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_59),
.B1(n_58),
.B2(n_32),
.Y(n_61)
);


endmodule