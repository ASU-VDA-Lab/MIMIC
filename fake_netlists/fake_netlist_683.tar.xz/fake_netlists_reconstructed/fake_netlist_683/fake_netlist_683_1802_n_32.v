module fake_netlist_683_1802_n_32 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_32);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_32;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

AND2x4_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_5),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_2),
.B(n_9),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_4),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_21),
.B1(n_23),
.B2(n_19),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_20),
.C(n_22),
.Y(n_27)
);

NAND4xp25_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_20),
.C(n_17),
.D(n_4),
.Y(n_28)
);

AOI322xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_17),
.A3(n_16),
.B1(n_6),
.B2(n_24),
.C1(n_3),
.C2(n_7),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_16),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_11),
.B1(n_8),
.B2(n_13),
.C1(n_15),
.C2(n_14),
.Y(n_32)
);


endmodule