module fake_netlist_683_3758_n_55 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_55);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_55;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_46;
wire n_41;
wire n_23;
wire n_29;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_19;
wire n_39;

BUFx2_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_13),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_12),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_3),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

BUFx3_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

NOR2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_16),
.Y(n_32)
);

AOI22x1_ASAP7_75t_L g33 ( 
.A1(n_22),
.A2(n_5),
.B1(n_2),
.B2(n_0),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_26),
.B(n_25),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI21xp33_ASAP7_75t_SL g38 ( 
.A1(n_35),
.A2(n_31),
.B(n_32),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_34),
.B(n_20),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_34),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_36),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_21),
.Y(n_44)
);

OAI321xp33_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_25),
.A3(n_33),
.B1(n_18),
.B2(n_17),
.C(n_6),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx3_ASAP7_75t_SL g47 ( 
.A(n_45),
.Y(n_47)
);

INVxp67_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

BUFx2_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

BUFx6f_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

NAND4xp25_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_18),
.C(n_25),
.D(n_23),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

AND2x2_ASAP7_75t_SL g53 ( 
.A(n_49),
.B(n_8),
.Y(n_53)
);

AOI21xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_11),
.B(n_10),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_14),
.B1(n_54),
.B2(n_52),
.Y(n_55)
);


endmodule