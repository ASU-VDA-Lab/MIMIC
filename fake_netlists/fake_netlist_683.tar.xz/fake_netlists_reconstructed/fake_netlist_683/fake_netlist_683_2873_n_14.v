module fake_netlist_683_2873_n_14 (n_0, n_2, n_1, n_14);

input n_0;
input n_2;
input n_1;

output n_14;

wire n_9;
wire n_4;
wire n_7;
wire n_3;
wire n_11;
wire n_12;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_13;

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

OAI21x1_ASAP7_75t_SL g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AND3x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_8),
.C(n_7),
.Y(n_11)
);

AND3x1_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_5),
.C(n_2),
.Y(n_12)
);

OAI31xp33_ASAP7_75t_SL g13 ( 
.A1(n_11),
.A2(n_0),
.A3(n_4),
.B(n_3),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_4),
.B1(n_10),
.B2(n_12),
.Y(n_14)
);


endmodule