module fake_netlist_683_1073_n_33 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_33);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_33;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_32;
wire n_28;
wire n_11;
wire n_19;
wire n_30;
wire n_25;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_6),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_5),
.B(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_10),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.C(n_0),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_1),
.B(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_10),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_11),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_SL g22 ( 
.A(n_16),
.B(n_11),
.C(n_15),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_15),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_21),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_12),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_17),
.B(n_12),
.C(n_19),
.Y(n_26)
);

O2A1O1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_12),
.B(n_14),
.C(n_1),
.Y(n_27)
);

OAI211xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_14),
.B(n_25),
.C(n_2),
.Y(n_28)
);

NAND4xp25_ASAP7_75t_SL g29 ( 
.A(n_26),
.B(n_25),
.C(n_3),
.D(n_2),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NOR2x1_ASAP7_75t_SL g31 ( 
.A(n_28),
.B(n_5),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_30),
.B1(n_31),
.B2(n_8),
.Y(n_33)
);


endmodule