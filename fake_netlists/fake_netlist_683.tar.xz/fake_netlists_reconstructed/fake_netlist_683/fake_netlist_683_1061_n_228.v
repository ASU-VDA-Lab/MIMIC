module fake_netlist_683_1061_n_228 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_228);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_228;

wire n_61;
wire n_99;
wire n_210;
wire n_115;
wire n_219;
wire n_110;
wire n_148;
wire n_86;
wire n_147;
wire n_171;
wire n_102;
wire n_40;
wire n_66;
wire n_165;
wire n_88;
wire n_47;
wire n_119;
wire n_175;
wire n_35;
wire n_196;
wire n_52;
wire n_220;
wire n_213;
wire n_71;
wire n_150;
wire n_162;
wire n_157;
wire n_179;
wire n_121;
wire n_182;
wire n_60;
wire n_189;
wire n_33;
wire n_89;
wire n_114;
wire n_181;
wire n_194;
wire n_211;
wire n_30;
wire n_212;
wire n_112;
wire n_197;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_83;
wire n_113;
wire n_131;
wire n_45;
wire n_204;
wire n_124;
wire n_158;
wire n_163;
wire n_130;
wire n_156;
wire n_64;
wire n_190;
wire n_146;
wire n_85;
wire n_136;
wire n_58;
wire n_218;
wire n_62;
wire n_200;
wire n_76;
wire n_63;
wire n_184;
wire n_70;
wire n_224;
wire n_69;
wire n_101;
wire n_141;
wire n_123;
wire n_53;
wire n_109;
wire n_168;
wire n_173;
wire n_74;
wire n_188;
wire n_160;
wire n_176;
wire n_209;
wire n_226;
wire n_144;
wire n_170;
wire n_187;
wire n_28;
wire n_208;
wire n_164;
wire n_94;
wire n_149;
wire n_81;
wire n_75;
wire n_161;
wire n_55;
wire n_192;
wire n_111;
wire n_54;
wire n_78;
wire n_207;
wire n_44;
wire n_38;
wire n_174;
wire n_203;
wire n_199;
wire n_91;
wire n_167;
wire n_42;
wire n_106;
wire n_116;
wire n_127;
wire n_34;
wire n_225;
wire n_100;
wire n_145;
wire n_43;
wire n_84;
wire n_177;
wire n_37;
wire n_51;
wire n_191;
wire n_68;
wire n_140;
wire n_92;
wire n_195;
wire n_129;
wire n_90;
wire n_143;
wire n_169;
wire n_32;
wire n_77;
wire n_117;
wire n_82;
wire n_134;
wire n_152;
wire n_180;
wire n_128;
wire n_202;
wire n_172;
wire n_93;
wire n_193;
wire n_97;
wire n_118;
wire n_186;
wire n_214;
wire n_216;
wire n_95;
wire n_98;
wire n_103;
wire n_135;
wire n_222;
wire n_125;
wire n_122;
wire n_79;
wire n_178;
wire n_154;
wire n_104;
wire n_105;
wire n_215;
wire n_139;
wire n_133;
wire n_183;
wire n_155;
wire n_120;
wire n_217;
wire n_137;
wire n_46;
wire n_31;
wire n_73;
wire n_41;
wire n_87;
wire n_205;
wire n_29;
wire n_56;
wire n_159;
wire n_185;
wire n_72;
wire n_65;
wire n_80;
wire n_107;
wire n_132;
wire n_227;
wire n_138;
wire n_151;
wire n_153;
wire n_201;
wire n_36;
wire n_142;
wire n_126;
wire n_223;
wire n_221;
wire n_206;
wire n_49;
wire n_57;
wire n_96;
wire n_166;
wire n_198;
wire n_108;

INVxp33_ASAP7_75t_SL g28 ( 
.A(n_11),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_26),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_7),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_4),
.Y(n_33)
);

INVxp33_ASAP7_75t_SL g34 ( 
.A(n_12),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_0),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_16),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_9),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_21),
.Y(n_38)
);

INVxp67_ASAP7_75t_SL g39 ( 
.A(n_10),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_30),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_30),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_33),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_30),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_30),
.Y(n_44)
);

BUFx6f_ASAP7_75t_L g45 ( 
.A(n_33),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_36),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_35),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_SL g48 ( 
.A(n_42),
.B(n_47),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_42),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_29),
.Y(n_51)
);

AO22x2_ASAP7_75t_L g52 ( 
.A1(n_40),
.A2(n_39),
.B1(n_35),
.B2(n_32),
.Y(n_52)
);

NAND2x1p5_ASAP7_75t_L g53 ( 
.A(n_41),
.B(n_36),
.Y(n_53)
);

AND2x2_ASAP7_75t_SL g54 ( 
.A(n_45),
.B(n_36),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_45),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_46),
.Y(n_56)
);

BUFx6f_ASAP7_75t_SL g57 ( 
.A(n_45),
.Y(n_57)
);

BUFx3_ASAP7_75t_L g58 ( 
.A(n_45),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_45),
.Y(n_59)
);

AOI22xp5_ASAP7_75t_L g60 ( 
.A1(n_46),
.A2(n_34),
.B1(n_28),
.B2(n_37),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_40),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_61),
.Y(n_62)
);

INVx2_ASAP7_75t_L g63 ( 
.A(n_61),
.Y(n_63)
);

O2A1O1Ixp33_ASAP7_75t_L g64 ( 
.A1(n_56),
.A2(n_38),
.B(n_32),
.C(n_43),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_53),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_51),
.B(n_28),
.Y(n_66)
);

AOI22xp5_ASAP7_75t_L g67 ( 
.A1(n_52),
.A2(n_37),
.B1(n_34),
.B2(n_38),
.Y(n_67)
);

AND3x1_ASAP7_75t_SL g68 ( 
.A(n_60),
.B(n_44),
.C(n_43),
.Y(n_68)
);

AND2x2_ASAP7_75t_L g69 ( 
.A(n_52),
.B(n_41),
.Y(n_69)
);

AND2x2_ASAP7_75t_L g70 ( 
.A(n_52),
.B(n_41),
.Y(n_70)
);

AOI22xp33_ASAP7_75t_L g71 ( 
.A1(n_52),
.A2(n_41),
.B1(n_44),
.B2(n_39),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_53),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_53),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_L g74 ( 
.A(n_50),
.B(n_31),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_48),
.Y(n_75)
);

OAI22xp5_ASAP7_75t_SL g76 ( 
.A1(n_54),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_76)
);

O2A1O1Ixp33_ASAP7_75t_L g77 ( 
.A1(n_64),
.A2(n_59),
.B(n_55),
.C(n_49),
.Y(n_77)
);

AND2x4_ASAP7_75t_L g78 ( 
.A(n_65),
.B(n_58),
.Y(n_78)
);

AND2x2_ASAP7_75t_L g79 ( 
.A(n_65),
.B(n_72),
.Y(n_79)
);

NAND2xp5_ASAP7_75t_L g80 ( 
.A(n_72),
.B(n_54),
.Y(n_80)
);

AND2x2_ASAP7_75t_L g81 ( 
.A(n_73),
.B(n_62),
.Y(n_81)
);

BUFx3_ASAP7_75t_L g82 ( 
.A(n_73),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_62),
.Y(n_83)
);

NAND2xp5_ASAP7_75t_L g84 ( 
.A(n_63),
.B(n_69),
.Y(n_84)
);

OR2x2_ASAP7_75t_L g85 ( 
.A(n_67),
.B(n_13),
.Y(n_85)
);

AND2x4_ASAP7_75t_L g86 ( 
.A(n_69),
.B(n_70),
.Y(n_86)
);

BUFx6f_ASAP7_75t_L g87 ( 
.A(n_63),
.Y(n_87)
);

OAI22xp5_ASAP7_75t_L g88 ( 
.A1(n_82),
.A2(n_71),
.B1(n_83),
.B2(n_81),
.Y(n_88)
);

AND2x2_ASAP7_75t_L g89 ( 
.A(n_79),
.B(n_70),
.Y(n_89)
);

AOI22xp33_ASAP7_75t_L g90 ( 
.A1(n_86),
.A2(n_76),
.B1(n_66),
.B2(n_75),
.Y(n_90)
);

A2O1A1Ixp33_ASAP7_75t_L g91 ( 
.A1(n_77),
.A2(n_83),
.B(n_81),
.C(n_85),
.Y(n_91)
);

INVxp67_ASAP7_75t_SL g92 ( 
.A(n_79),
.Y(n_92)
);

AND2x2_ASAP7_75t_L g93 ( 
.A(n_79),
.B(n_75),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_87),
.Y(n_94)
);

O2A1O1Ixp33_ASAP7_75t_SL g95 ( 
.A1(n_84),
.A2(n_74),
.B(n_55),
.C(n_49),
.Y(n_95)
);

INVx2_ASAP7_75t_SL g96 ( 
.A(n_89),
.Y(n_96)
);

INVx1_ASAP7_75t_SL g97 ( 
.A(n_93),
.Y(n_97)
);

HB1xp67_ASAP7_75t_L g98 ( 
.A(n_92),
.Y(n_98)
);

AOI21xp5_ASAP7_75t_L g99 ( 
.A1(n_95),
.A2(n_81),
.B(n_80),
.Y(n_99)
);

INVx1_ASAP7_75t_L g100 ( 
.A(n_93),
.Y(n_100)
);

NAND2xp5_ASAP7_75t_L g101 ( 
.A(n_89),
.B(n_85),
.Y(n_101)
);

NAND2xp33_ASAP7_75t_SL g102 ( 
.A(n_90),
.B(n_85),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_88),
.Y(n_103)
);

A2O1A1Ixp33_ASAP7_75t_L g104 ( 
.A1(n_91),
.A2(n_77),
.B(n_82),
.C(n_84),
.Y(n_104)
);

INVx2_ASAP7_75t_L g105 ( 
.A(n_100),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_100),
.Y(n_106)
);

BUFx2_ASAP7_75t_L g107 ( 
.A(n_98),
.Y(n_107)
);

AND2x2_ASAP7_75t_L g108 ( 
.A(n_97),
.B(n_88),
.Y(n_108)
);

INVx4_ASAP7_75t_L g109 ( 
.A(n_96),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_96),
.Y(n_110)
);

NOR2xp67_ASAP7_75t_L g111 ( 
.A(n_101),
.B(n_14),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_103),
.Y(n_112)
);

INVx6_ASAP7_75t_L g113 ( 
.A(n_97),
.Y(n_113)
);

NAND4xp25_ASAP7_75t_L g114 ( 
.A(n_103),
.B(n_68),
.C(n_86),
.D(n_80),
.Y(n_114)
);

BUFx3_ASAP7_75t_L g115 ( 
.A(n_99),
.Y(n_115)
);

INVx1_ASAP7_75t_SL g116 ( 
.A(n_104),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_100),
.Y(n_117)
);

AOI22xp5_ASAP7_75t_L g118 ( 
.A1(n_102),
.A2(n_86),
.B1(n_82),
.B2(n_78),
.Y(n_118)
);

AND2x2_ASAP7_75t_L g119 ( 
.A(n_108),
.B(n_94),
.Y(n_119)
);

INVx2_ASAP7_75t_L g120 ( 
.A(n_112),
.Y(n_120)
);

AND2x2_ASAP7_75t_L g121 ( 
.A(n_108),
.B(n_105),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_112),
.Y(n_122)
);

AND2x2_ASAP7_75t_L g123 ( 
.A(n_105),
.B(n_94),
.Y(n_123)
);

INVx1_ASAP7_75t_L g124 ( 
.A(n_106),
.Y(n_124)
);

AND2x2_ASAP7_75t_L g125 ( 
.A(n_106),
.B(n_117),
.Y(n_125)
);

AND2x2_ASAP7_75t_L g126 ( 
.A(n_107),
.B(n_94),
.Y(n_126)
);

NAND2x1p5_ASAP7_75t_L g127 ( 
.A(n_109),
.B(n_87),
.Y(n_127)
);

OAI22xp5_ASAP7_75t_L g128 ( 
.A1(n_118),
.A2(n_86),
.B1(n_87),
.B2(n_78),
.Y(n_128)
);

AND2x2_ASAP7_75t_L g129 ( 
.A(n_107),
.B(n_15),
.Y(n_129)
);

OR2x2_ASAP7_75t_L g130 ( 
.A(n_109),
.B(n_16),
.Y(n_130)
);

NAND2xp5_ASAP7_75t_L g131 ( 
.A(n_114),
.B(n_110),
.Y(n_131)
);

INVx1_ASAP7_75t_SL g132 ( 
.A(n_113),
.Y(n_132)
);

AND2x4_ASAP7_75t_L g133 ( 
.A(n_115),
.B(n_87),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_115),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_113),
.Y(n_135)
);

INVx1_ASAP7_75t_L g136 ( 
.A(n_113),
.Y(n_136)
);

INVxp67_ASAP7_75t_L g137 ( 
.A(n_111),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_113),
.Y(n_138)
);

INVx3_ASAP7_75t_L g139 ( 
.A(n_109),
.Y(n_139)
);

AND2x2_ASAP7_75t_L g140 ( 
.A(n_116),
.B(n_17),
.Y(n_140)
);

BUFx2_ASAP7_75t_L g141 ( 
.A(n_107),
.Y(n_141)
);

AND2x2_ASAP7_75t_L g142 ( 
.A(n_108),
.B(n_17),
.Y(n_142)
);

INVx1_ASAP7_75t_SL g143 ( 
.A(n_141),
.Y(n_143)
);

AND2x2_ASAP7_75t_L g144 ( 
.A(n_121),
.B(n_18),
.Y(n_144)
);

NAND2xp5_ASAP7_75t_SL g145 ( 
.A(n_139),
.B(n_87),
.Y(n_145)
);

AND2x2_ASAP7_75t_L g146 ( 
.A(n_121),
.B(n_18),
.Y(n_146)
);

NOR2x1_ASAP7_75t_L g147 ( 
.A(n_130),
.B(n_78),
.Y(n_147)
);

NAND2xp5_ASAP7_75t_L g148 ( 
.A(n_125),
.B(n_20),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_124),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_124),
.Y(n_150)
);

AND2x2_ASAP7_75t_L g151 ( 
.A(n_119),
.B(n_20),
.Y(n_151)
);

NAND2x1p5_ASAP7_75t_L g152 ( 
.A(n_139),
.B(n_78),
.Y(n_152)
);

OR2x2_ASAP7_75t_L g153 ( 
.A(n_141),
.B(n_21),
.Y(n_153)
);

INVx2_ASAP7_75t_L g154 ( 
.A(n_120),
.Y(n_154)
);

NOR2xp33_ASAP7_75t_L g155 ( 
.A(n_137),
.B(n_22),
.Y(n_155)
);

AND2x2_ASAP7_75t_L g156 ( 
.A(n_119),
.B(n_22),
.Y(n_156)
);

INVx2_ASAP7_75t_SL g157 ( 
.A(n_139),
.Y(n_157)
);

NAND2xp33_ASAP7_75t_SL g158 ( 
.A(n_130),
.B(n_87),
.Y(n_158)
);

AND2x2_ASAP7_75t_L g159 ( 
.A(n_120),
.B(n_23),
.Y(n_159)
);

NOR2x1_ASAP7_75t_SL g160 ( 
.A(n_128),
.B(n_87),
.Y(n_160)
);

NAND2xp5_ASAP7_75t_L g161 ( 
.A(n_142),
.B(n_23),
.Y(n_161)
);

NAND2xp5_ASAP7_75t_L g162 ( 
.A(n_129),
.B(n_24),
.Y(n_162)
);

AOI221xp5_ASAP7_75t_L g163 ( 
.A1(n_131),
.A2(n_59),
.B1(n_58),
.B2(n_57),
.C(n_78),
.Y(n_163)
);

OAI21xp33_ASAP7_75t_L g164 ( 
.A1(n_129),
.A2(n_25),
.B(n_24),
.Y(n_164)
);

INVxp67_ASAP7_75t_L g165 ( 
.A(n_126),
.Y(n_165)
);

INVx2_ASAP7_75t_L g166 ( 
.A(n_120),
.Y(n_166)
);

INVxp67_ASAP7_75t_L g167 ( 
.A(n_126),
.Y(n_167)
);

INVx1_ASAP7_75t_SL g168 ( 
.A(n_132),
.Y(n_168)
);

NAND2xp5_ASAP7_75t_L g169 ( 
.A(n_122),
.B(n_27),
.Y(n_169)
);

INVx1_ASAP7_75t_L g170 ( 
.A(n_123),
.Y(n_170)
);

OR2x2_ASAP7_75t_L g171 ( 
.A(n_135),
.B(n_87),
.Y(n_171)
);

INVx2_ASAP7_75t_L g172 ( 
.A(n_154),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_149),
.Y(n_173)
);

OAI21xp33_ASAP7_75t_L g174 ( 
.A1(n_155),
.A2(n_140),
.B(n_134),
.Y(n_174)
);

INVxp67_ASAP7_75t_L g175 ( 
.A(n_143),
.Y(n_175)
);

INVxp67_ASAP7_75t_SL g176 ( 
.A(n_160),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_150),
.Y(n_177)
);

NAND2xp5_ASAP7_75t_SL g178 ( 
.A(n_158),
.B(n_157),
.Y(n_178)
);

AND2x2_ASAP7_75t_L g179 ( 
.A(n_170),
.B(n_134),
.Y(n_179)
);

NAND2xp5_ASAP7_75t_L g180 ( 
.A(n_144),
.B(n_135),
.Y(n_180)
);

NAND2xp5_ASAP7_75t_L g181 ( 
.A(n_144),
.B(n_136),
.Y(n_181)
);

OR2x2_ASAP7_75t_L g182 ( 
.A(n_165),
.B(n_136),
.Y(n_182)
);

NAND2xp5_ASAP7_75t_L g183 ( 
.A(n_146),
.B(n_138),
.Y(n_183)
);

NOR2xp33_ASAP7_75t_L g184 ( 
.A(n_161),
.B(n_138),
.Y(n_184)
);

NAND2xp5_ASAP7_75t_L g185 ( 
.A(n_146),
.B(n_167),
.Y(n_185)
);

NAND2xp5_ASAP7_75t_L g186 ( 
.A(n_151),
.B(n_123),
.Y(n_186)
);

NAND2xp5_ASAP7_75t_L g187 ( 
.A(n_151),
.B(n_132),
.Y(n_187)
);

NAND2xp33_ASAP7_75t_L g188 ( 
.A(n_147),
.B(n_127),
.Y(n_188)
);

NAND2xp5_ASAP7_75t_L g189 ( 
.A(n_156),
.B(n_127),
.Y(n_189)
);

NAND2xp5_ASAP7_75t_L g190 ( 
.A(n_156),
.B(n_133),
.Y(n_190)
);

OAI21xp5_ASAP7_75t_L g191 ( 
.A1(n_164),
.A2(n_133),
.B(n_1),
.Y(n_191)
);

NOR3xp33_ASAP7_75t_L g192 ( 
.A(n_162),
.B(n_133),
.C(n_2),
.Y(n_192)
);

AOI21xp5_ASAP7_75t_L g193 ( 
.A1(n_160),
.A2(n_145),
.B(n_157),
.Y(n_193)
);

NOR3xp33_ASAP7_75t_L g194 ( 
.A(n_148),
.B(n_133),
.C(n_3),
.Y(n_194)
);

AND2x2_ASAP7_75t_L g195 ( 
.A(n_154),
.B(n_5),
.Y(n_195)
);

NAND2xp5_ASAP7_75t_L g196 ( 
.A(n_159),
.B(n_6),
.Y(n_196)
);

BUFx4f_ASAP7_75t_SL g197 ( 
.A(n_178),
.Y(n_197)
);

AOI221x1_ASAP7_75t_L g198 ( 
.A1(n_174),
.A2(n_169),
.B1(n_159),
.B2(n_166),
.C(n_153),
.Y(n_198)
);

NAND2xp5_ASAP7_75t_SL g199 ( 
.A(n_193),
.B(n_168),
.Y(n_199)
);

NAND2xp5_ASAP7_75t_SL g200 ( 
.A(n_176),
.B(n_145),
.Y(n_200)
);

NOR2xp33_ASAP7_75t_L g201 ( 
.A(n_175),
.B(n_152),
.Y(n_201)
);

AND2x2_ASAP7_75t_L g202 ( 
.A(n_185),
.B(n_166),
.Y(n_202)
);

NAND2xp5_ASAP7_75t_L g203 ( 
.A(n_179),
.B(n_171),
.Y(n_203)
);

NAND3xp33_ASAP7_75t_L g204 ( 
.A(n_184),
.B(n_163),
.C(n_8),
.Y(n_204)
);

OAI21xp5_ASAP7_75t_SL g205 ( 
.A1(n_191),
.A2(n_19),
.B(n_57),
.Y(n_205)
);

NOR2x1_ASAP7_75t_L g206 ( 
.A(n_178),
.B(n_57),
.Y(n_206)
);

AND3x4_ASAP7_75t_L g207 ( 
.A(n_192),
.B(n_194),
.C(n_188),
.Y(n_207)
);

INVx1_ASAP7_75t_L g208 ( 
.A(n_173),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_177),
.Y(n_209)
);

AND2x2_ASAP7_75t_L g210 ( 
.A(n_202),
.B(n_187),
.Y(n_210)
);

AOI21xp5_ASAP7_75t_L g211 ( 
.A1(n_207),
.A2(n_189),
.B(n_190),
.Y(n_211)
);

NOR2x1p5_ASAP7_75t_L g212 ( 
.A(n_197),
.B(n_186),
.Y(n_212)
);

NAND4xp75_ASAP7_75t_L g213 ( 
.A(n_198),
.B(n_183),
.C(n_181),
.D(n_180),
.Y(n_213)
);

NAND3xp33_ASAP7_75t_L g214 ( 
.A(n_199),
.B(n_182),
.C(n_196),
.Y(n_214)
);

NOR2x1_ASAP7_75t_L g215 ( 
.A(n_207),
.B(n_195),
.Y(n_215)
);

AND2x4_ASAP7_75t_L g216 ( 
.A(n_200),
.B(n_182),
.Y(n_216)
);

XNOR2xp5_ASAP7_75t_L g217 ( 
.A(n_203),
.B(n_172),
.Y(n_217)
);

OR2x2_ASAP7_75t_L g218 ( 
.A(n_216),
.B(n_208),
.Y(n_218)
);

NAND2xp5_ASAP7_75t_L g219 ( 
.A(n_211),
.B(n_209),
.Y(n_219)
);

OAI21xp5_ASAP7_75t_L g220 ( 
.A1(n_215),
.A2(n_205),
.B(n_206),
.Y(n_220)
);

AND2x2_ASAP7_75t_L g221 ( 
.A(n_212),
.B(n_201),
.Y(n_221)
);

AOI22xp5_ASAP7_75t_L g222 ( 
.A1(n_219),
.A2(n_215),
.B1(n_213),
.B2(n_216),
.Y(n_222)
);

AOI22xp5_ASAP7_75t_L g223 ( 
.A1(n_221),
.A2(n_214),
.B1(n_217),
.B2(n_210),
.Y(n_223)
);

XOR2xp5_ASAP7_75t_L g224 ( 
.A(n_220),
.B(n_204),
.Y(n_224)
);

OR2x2_ASAP7_75t_L g225 ( 
.A(n_222),
.B(n_218),
.Y(n_225)
);

INVx1_ASAP7_75t_L g226 ( 
.A(n_223),
.Y(n_226)
);

INVxp67_ASAP7_75t_SL g227 ( 
.A(n_226),
.Y(n_227)
);

AOI22xp5_ASAP7_75t_L g228 ( 
.A1(n_227),
.A2(n_224),
.B1(n_225),
.B2(n_220),
.Y(n_228)
);


endmodule