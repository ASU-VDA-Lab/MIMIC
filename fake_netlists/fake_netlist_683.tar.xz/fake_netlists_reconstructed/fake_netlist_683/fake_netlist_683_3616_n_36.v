module fake_netlist_683_3616_n_36 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_36);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_36;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_31;
wire n_23;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;

INVxp67_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_4),
.B(n_10),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_8),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_L g17 ( 
.A(n_7),
.B(n_13),
.C(n_5),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_4),
.A2(n_1),
.B(n_5),
.C(n_2),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_6),
.B(n_7),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_6),
.B(n_3),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_15),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_25),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

AOI322xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_23),
.A3(n_20),
.B1(n_29),
.B2(n_14),
.C1(n_28),
.C2(n_15),
.Y(n_32)
);

NOR4xp25_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_28),
.C(n_24),
.D(n_17),
.Y(n_33)
);

AOI311xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_16),
.A3(n_32),
.B(n_27),
.C(n_21),
.Y(n_34)
);

OAI221xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_17),
.B1(n_11),
.B2(n_3),
.C(n_12),
.Y(n_35)
);

OAI21xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_11),
.B(n_34),
.Y(n_36)
);


endmodule