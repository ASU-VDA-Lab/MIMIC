module fake_netlist_683_3866_n_9 (n_0, n_2, n_1, n_9);

input n_0;
input n_2;
input n_1;

output n_9;

wire n_4;
wire n_7;
wire n_3;
wire n_8;
wire n_5;
wire n_6;

INVx4_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

NAND3xp33_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_1),
.C(n_2),
.Y(n_4)
);

INVx4_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVxp67_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);

OAI211xp5_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_4),
.B(n_5),
.C(n_0),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B1(n_2),
.B2(n_6),
.C(n_5),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B1(n_2),
.B2(n_7),
.Y(n_9)
);


endmodule