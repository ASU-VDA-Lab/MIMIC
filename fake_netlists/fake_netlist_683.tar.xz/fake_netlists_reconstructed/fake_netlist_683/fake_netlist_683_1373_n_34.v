module fake_netlist_683_1373_n_34 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_34);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_34;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

BUFx6f_ASAP7_75t_SL g16 ( 
.A(n_14),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx6_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_9),
.A2(n_15),
.B1(n_13),
.B2(n_8),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_4),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_20),
.B(n_6),
.C(n_4),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

AO21x2_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.B(n_23),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_24),
.B1(n_16),
.B2(n_18),
.Y(n_29)
);

OAI322xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_24),
.A3(n_18),
.B1(n_2),
.B2(n_5),
.C1(n_0),
.C2(n_1),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_29),
.Y(n_31)
);

NOR2xp67_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_7),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_12),
.B2(n_11),
.Y(n_34)
);


endmodule