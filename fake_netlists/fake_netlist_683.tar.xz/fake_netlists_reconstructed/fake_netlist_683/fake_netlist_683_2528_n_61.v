module fake_netlist_683_2528_n_61 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_61);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_61;

wire n_54;
wire n_50;
wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_58;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_23;
wire n_46;
wire n_41;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_19;
wire n_39;
wire n_55;

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_3),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_0),
.B(n_12),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

INVxp67_ASAP7_75t_SL g25 ( 
.A(n_8),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_17),
.B(n_10),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

OA21x2_ASAP7_75t_L g29 ( 
.A1(n_6),
.A2(n_7),
.B(n_2),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_5),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_1),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_R g33 ( 
.A(n_19),
.B(n_4),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_5),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_18),
.Y(n_35)
);

BUFx3_ASAP7_75t_L g36 ( 
.A(n_21),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_21),
.B(n_15),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_26),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_36),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_31),
.B(n_23),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_34),
.A2(n_28),
.B1(n_20),
.B2(n_23),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_23),
.Y(n_42)
);

BUFx6f_ASAP7_75t_SL g43 ( 
.A(n_33),
.Y(n_43)
);

NAND2xp33_ASAP7_75t_SL g44 ( 
.A(n_43),
.B(n_19),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_39),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

INVxp67_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_41),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_32),
.Y(n_50)
);

NOR2xp33_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_44),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_40),
.Y(n_52)
);

AOI211xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_44),
.B(n_32),
.C(n_37),
.Y(n_53)
);

NOR4xp25_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_26),
.C(n_27),
.D(n_25),
.Y(n_54)
);

AOI221xp5_ASAP7_75t_L g55 ( 
.A1(n_49),
.A2(n_42),
.B1(n_43),
.B2(n_24),
.C(n_29),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_42),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_53),
.Y(n_57)
);

OAI22xp5_ASAP7_75t_SL g58 ( 
.A1(n_55),
.A2(n_29),
.B1(n_24),
.B2(n_9),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_57),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_56),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_SL g61 ( 
.A1(n_59),
.A2(n_24),
.B1(n_58),
.B2(n_60),
.Y(n_61)
);


endmodule