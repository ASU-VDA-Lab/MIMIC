module fake_netlist_683_452_n_73 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_73);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_73;

wire n_54;
wire n_24;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_66;
wire n_47;
wire n_20;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_71;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_70;
wire n_23;
wire n_31;
wire n_46;
wire n_41;
wire n_69;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_68;
wire n_72;
wire n_33;
wire n_65;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_19;
wire n_67;
wire n_39;
wire n_55;

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_14),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_15),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_2),
.B(n_6),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_3),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_8),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

BUFx8_ASAP7_75t_L g29 ( 
.A(n_0),
.Y(n_29)
);

INVx5_ASAP7_75t_L g30 ( 
.A(n_4),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_9),
.Y(n_31)
);

NAND2xp33_ASAP7_75t_L g32 ( 
.A(n_22),
.B(n_25),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_0),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_19),
.A2(n_31),
.B1(n_28),
.B2(n_27),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_19),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_19),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_26),
.B(n_1),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_27),
.B(n_1),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_28),
.B(n_2),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_40),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_34),
.B(n_24),
.Y(n_44)
);

A2O1A1Ixp33_ASAP7_75t_L g45 ( 
.A1(n_34),
.A2(n_25),
.B(n_22),
.C(n_21),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_L g46 ( 
.A1(n_32),
.A2(n_21),
.B(n_25),
.Y(n_46)
);

OAI22xp33_ASAP7_75t_L g47 ( 
.A1(n_41),
.A2(n_20),
.B1(n_18),
.B2(n_29),
.Y(n_47)
);

OAI21xp33_ASAP7_75t_SL g48 ( 
.A1(n_36),
.A2(n_23),
.B(n_29),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_40),
.A2(n_41),
.B1(n_33),
.B2(n_42),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_42),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_44),
.Y(n_51)
);

NAND4xp75_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_33),
.C(n_23),
.D(n_29),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_43),
.B(n_37),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_37),
.Y(n_54)
);

NOR2xp33_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_43),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_48),
.Y(n_56)
);

NOR2xp67_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_46),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_54),
.B(n_35),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_51),
.A2(n_47),
.B1(n_35),
.B2(n_38),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_56),
.B(n_50),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_57),
.Y(n_62)
);

A2O1A1Ixp33_ASAP7_75t_SL g63 ( 
.A1(n_59),
.A2(n_51),
.B(n_39),
.C(n_38),
.Y(n_63)
);

AND3x2_ASAP7_75t_L g64 ( 
.A(n_62),
.B(n_55),
.C(n_29),
.Y(n_64)
);

INVx2_ASAP7_75t_SL g65 ( 
.A(n_60),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_61),
.B(n_52),
.Y(n_66)
);

OAI221xp5_ASAP7_75t_L g67 ( 
.A1(n_63),
.A2(n_30),
.B1(n_15),
.B2(n_13),
.C(n_14),
.Y(n_67)
);

CKINVDCx5p33_ASAP7_75t_R g68 ( 
.A(n_65),
.Y(n_68)
);

NOR3xp33_ASAP7_75t_L g69 ( 
.A(n_67),
.B(n_63),
.C(n_13),
.Y(n_69)
);

AOI22xp5_ASAP7_75t_L g70 ( 
.A1(n_66),
.A2(n_30),
.B1(n_17),
.B2(n_16),
.Y(n_70)
);

CKINVDCx16_ASAP7_75t_R g71 ( 
.A(n_64),
.Y(n_71)
);

OR2x2_ASAP7_75t_L g72 ( 
.A(n_68),
.B(n_30),
.Y(n_72)
);

AOI322xp5_ASAP7_75t_L g73 ( 
.A1(n_72),
.A2(n_71),
.A3(n_69),
.B1(n_70),
.B2(n_30),
.C1(n_7),
.C2(n_12),
.Y(n_73)
);


endmodule