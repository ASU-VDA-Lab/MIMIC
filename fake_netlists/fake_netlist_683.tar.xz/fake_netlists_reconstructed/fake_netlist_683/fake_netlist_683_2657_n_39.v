module fake_netlist_683_2657_n_39 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_39);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_39;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_19;
wire n_25;

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_R g19 ( 
.A(n_4),
.B(n_3),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_16),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_1),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVx4_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_24),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_L g29 ( 
.A1(n_25),
.A2(n_18),
.B(n_21),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_27),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_28),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_22),
.B(n_19),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_2),
.Y(n_33)
);

OAI31xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_8),
.A3(n_7),
.B(n_5),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_32),
.Y(n_35)
);

NOR2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_9),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI322xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_37),
.A3(n_14),
.B1(n_11),
.B2(n_10),
.C1(n_17),
.C2(n_15),
.Y(n_39)
);


endmodule