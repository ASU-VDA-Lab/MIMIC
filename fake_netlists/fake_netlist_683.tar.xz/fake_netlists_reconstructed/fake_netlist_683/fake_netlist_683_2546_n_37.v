module fake_netlist_683_2546_n_37 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_37);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_37;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_12;
wire n_36;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_9),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_14),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_SL g21 ( 
.A(n_16),
.B(n_12),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_16),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_16),
.B(n_1),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_13),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_21),
.Y(n_25)
);

CKINVDCx16_ASAP7_75t_R g26 ( 
.A(n_21),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_22),
.B(n_17),
.C(n_15),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_23),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

AO221x1_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_11),
.B1(n_26),
.B2(n_27),
.C(n_4),
.Y(n_31)
);

AOI221x1_ASAP7_75t_SL g32 ( 
.A1(n_28),
.A2(n_11),
.B1(n_18),
.B2(n_4),
.C(n_5),
.Y(n_32)
);

AOI311xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_30),
.A3(n_9),
.B(n_6),
.C(n_8),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_R g34 ( 
.A(n_31),
.B(n_6),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

XOR2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_10),
.Y(n_36)
);

AOI222xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_10),
.B1(n_31),
.B2(n_33),
.C1(n_35),
.C2(n_14),
.Y(n_37)
);


endmodule