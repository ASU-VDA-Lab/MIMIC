module fake_netlist_683_1246_n_55 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_55);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_55;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_16;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_19;
wire n_39;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

AND2x6_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_8),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_2),
.B(n_4),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_R g21 ( 
.A(n_12),
.B(n_4),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_9),
.B(n_11),
.Y(n_22)
);

NAND2x1p5_ASAP7_75t_L g23 ( 
.A(n_15),
.B(n_0),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_13),
.Y(n_25)
);

INVx8_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_19),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_30),
.Y(n_31)
);

INVx11_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_25),
.A2(n_14),
.B1(n_20),
.B2(n_22),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_26),
.A2(n_14),
.B1(n_21),
.B2(n_5),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_26),
.A2(n_14),
.B(n_10),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_23),
.B(n_14),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_24),
.Y(n_37)
);

OAI221xp5_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_24),
.B1(n_23),
.B2(n_27),
.C(n_26),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_31),
.B(n_27),
.Y(n_39)
);

INVxp67_ASAP7_75t_L g40 ( 
.A(n_32),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_27),
.Y(n_41)
);

NAND2x1p5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_35),
.Y(n_42)
);

INVx1_ASAP7_75t_SL g43 ( 
.A(n_39),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_R g44 ( 
.A(n_43),
.B(n_37),
.Y(n_44)
);

INVx2_ASAP7_75t_SL g45 ( 
.A(n_41),
.Y(n_45)
);

NOR2x1_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_38),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

AOI321xp33_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_33),
.A3(n_37),
.B1(n_38),
.B2(n_42),
.C(n_45),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_49),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

AND2x4_ASAP7_75t_SL g52 ( 
.A(n_47),
.B(n_37),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

AO22x2_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_48),
.B1(n_37),
.B2(n_33),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_50),
.B1(n_52),
.B2(n_53),
.Y(n_55)
);


endmodule