module fake_netlist_683_2089_n_63 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_63);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_63;

wire n_54;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_40;
wire n_42;
wire n_47;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_43;
wire n_37;
wire n_51;
wire n_46;
wire n_41;
wire n_31;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

INVx3_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

AND2x2_ASAP7_75t_SL g29 ( 
.A(n_16),
.B(n_13),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_20),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_4),
.B(n_0),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_7),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_24),
.A2(n_14),
.B1(n_1),
.B2(n_6),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_27),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_23),
.Y(n_36)
);

INVx3_ASAP7_75t_L g37 ( 
.A(n_2),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_25),
.Y(n_38)
);

BUFx3_ASAP7_75t_L g39 ( 
.A(n_33),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_28),
.Y(n_40)
);

NAND2xp33_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_3),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_37),
.B(n_25),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

OAI21x1_ASAP7_75t_SL g44 ( 
.A1(n_41),
.A2(n_32),
.B(n_35),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_28),
.C(n_38),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AND2x4_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_39),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_47),
.Y(n_48)
);

AND2x4_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_45),
.Y(n_49)
);

AOI31xp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_42),
.A3(n_34),
.B(n_31),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

A2O1A1Ixp33_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_49),
.B(n_29),
.C(n_30),
.Y(n_53)
);

O2A1O1Ixp33_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_49),
.B(n_32),
.C(n_34),
.Y(n_54)
);

CKINVDCx20_ASAP7_75t_R g55 ( 
.A(n_51),
.Y(n_55)
);

OAI221xp5_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_52),
.B1(n_36),
.B2(n_49),
.C(n_29),
.Y(n_56)
);

AOI21xp5_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_49),
.B(n_36),
.Y(n_57)
);

AOI221xp5_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_36),
.B1(n_27),
.B2(n_26),
.C(n_5),
.Y(n_58)
);

AO21x2_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_26),
.B(n_8),
.Y(n_59)
);

NAND3xp33_ASAP7_75t_L g60 ( 
.A(n_58),
.B(n_57),
.C(n_9),
.Y(n_60)
);

OAI22xp5_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_61)
);

BUFx3_ASAP7_75t_L g62 ( 
.A(n_59),
.Y(n_62)
);

AOI322xp5_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_15),
.A3(n_17),
.B1(n_18),
.B2(n_21),
.C1(n_22),
.C2(n_61),
.Y(n_63)
);


endmodule