module fake_netlist_683_410_n_21 (n_4, n_2, n_3, n_1, n_0, n_21);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_21;

wire n_17;
wire n_6;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_5;
wire n_7;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx2_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_2),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_2),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_2),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OA21x2_ASAP7_75t_L g10 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_8),
.B1(n_7),
.B2(n_0),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_8),
.Y(n_15)
);

AOI211xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_11),
.B(n_10),
.C(n_2),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_11),
.Y(n_17)
);

OAI211xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_15),
.B(n_10),
.C(n_3),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_3),
.B1(n_4),
.B2(n_13),
.C(n_14),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_3),
.B(n_4),
.C(n_18),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_4),
.B(n_3),
.Y(n_21)
);


endmodule