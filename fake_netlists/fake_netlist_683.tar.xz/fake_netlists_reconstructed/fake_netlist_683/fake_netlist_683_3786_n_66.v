module fake_netlist_683_3786_n_66 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_66);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_66;

wire n_54;
wire n_24;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_46;
wire n_31;
wire n_41;
wire n_23;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_65;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_4),
.B(n_19),
.Y(n_22)
);

OA21x2_ASAP7_75t_L g23 ( 
.A1(n_10),
.A2(n_15),
.B(n_0),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_8),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_7),
.B(n_15),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_13),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_1),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_9),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_11),
.Y(n_31)
);

NAND2x1p5_ASAP7_75t_L g32 ( 
.A(n_25),
.B(n_14),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_SL g33 ( 
.A(n_26),
.B(n_14),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_25),
.B(n_16),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_27),
.B(n_17),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_21),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_32),
.Y(n_40)
);

INVxp67_ASAP7_75t_L g41 ( 
.A(n_32),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

INVx3_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_40),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_38),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_43),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_SL g49 ( 
.A1(n_45),
.A2(n_35),
.B(n_22),
.Y(n_49)
);

AOI322xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_33),
.A3(n_22),
.B1(n_35),
.B2(n_36),
.C1(n_26),
.C2(n_24),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_45),
.B(n_21),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_47),
.Y(n_52)
);

OAI21xp33_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_45),
.B(n_46),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_48),
.A2(n_46),
.B1(n_31),
.B2(n_28),
.Y(n_54)
);

AOI211xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_21),
.B(n_30),
.C(n_27),
.Y(n_55)
);

AOI22xp33_ASAP7_75t_L g56 ( 
.A1(n_48),
.A2(n_21),
.B1(n_23),
.B2(n_30),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_23),
.B1(n_29),
.B2(n_17),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_52),
.Y(n_58)
);

NOR2x1p5_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_29),
.Y(n_59)
);

NOR2x1p5_ASAP7_75t_L g60 ( 
.A(n_54),
.B(n_29),
.Y(n_60)
);

INVx1_ASAP7_75t_SL g61 ( 
.A(n_56),
.Y(n_61)
);

OA22x2_ASAP7_75t_L g62 ( 
.A1(n_58),
.A2(n_23),
.B1(n_3),
.B2(n_2),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_60),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_59),
.Y(n_64)
);

AOI32xp33_ASAP7_75t_L g65 ( 
.A1(n_63),
.A2(n_61),
.A3(n_57),
.B1(n_6),
.B2(n_12),
.Y(n_65)
);

AOI22xp33_ASAP7_75t_SL g66 ( 
.A1(n_65),
.A2(n_64),
.B1(n_62),
.B2(n_18),
.Y(n_66)
);


endmodule