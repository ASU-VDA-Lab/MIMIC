module fake_netlist_683_293_n_58 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_58);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_58;

wire n_54;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_56;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_48;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

INVx2_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_19),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_10),
.Y(n_28)
);

NOR2xp67_ASAP7_75t_L g29 ( 
.A(n_21),
.B(n_24),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_15),
.B(n_16),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_7),
.B(n_22),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_0),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_3),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_8),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_20),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_23),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_26),
.Y(n_37)
);

HB1xp67_ASAP7_75t_SL g38 ( 
.A(n_27),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_26),
.Y(n_39)
);

AND2x6_ASAP7_75t_L g40 ( 
.A(n_30),
.B(n_34),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_33),
.B1(n_32),
.B2(n_28),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

INVx4_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_35),
.B1(n_36),
.B2(n_31),
.C(n_40),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_43),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_25),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_25),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_R g50 ( 
.A(n_48),
.B(n_1),
.Y(n_50)
);

OAI211xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_29),
.B(n_4),
.C(n_2),
.Y(n_51)
);

NOR2xp33_ASAP7_75t_R g52 ( 
.A(n_49),
.B(n_5),
.Y(n_52)
);

OAI22x1_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_11),
.B1(n_9),
.B2(n_6),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_13),
.Y(n_54)
);

NOR2xp33_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_14),
.Y(n_55)
);

INVx1_ASAP7_75t_SL g56 ( 
.A(n_54),
.Y(n_56)
);

XNOR2xp5_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_17),
.Y(n_57)
);

AOI22xp33_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_18),
.B1(n_55),
.B2(n_56),
.Y(n_58)
);


endmodule