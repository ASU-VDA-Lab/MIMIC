module fake_netlist_648_2553_n_22 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_22);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_22;

wire n_18;
wire n_19;
wire n_15;
wire n_20;
wire n_16;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_4),
.B(n_2),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_3),
.B(n_1),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_4),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI322xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.A3(n_15),
.B1(n_13),
.B2(n_5),
.C1(n_0),
.C2(n_6),
.Y(n_19)
);

NAND5xp2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_7),
.C(n_6),
.D(n_8),
.E(n_11),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B1(n_12),
.B2(n_7),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);


endmodule