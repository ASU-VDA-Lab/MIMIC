module fake_netlist_648_200_n_21 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_21);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_6),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

NOR3xp33_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_4),
.C(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_8),
.B(n_4),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.B1(n_10),
.B2(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND2x1_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_0),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_5),
.B(n_2),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_15),
.B(n_3),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_19),
.B1(n_18),
.B2(n_5),
.Y(n_21)
);


endmodule