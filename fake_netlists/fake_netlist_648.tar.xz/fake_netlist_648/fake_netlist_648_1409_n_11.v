module fake_netlist_648_1409_n_11 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_11);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_11;

wire n_9;
wire n_7;
wire n_10;
wire n_8;

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_0),
.A2(n_5),
.B(n_2),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

AOI321xp33_ASAP7_75t_SL g10 ( 
.A1(n_8),
.A2(n_1),
.A3(n_3),
.B1(n_4),
.B2(n_6),
.C(n_9),
.Y(n_10)
);

NAND3x1_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.C(n_7),
.Y(n_11)
);


endmodule