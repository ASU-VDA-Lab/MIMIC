module fake_netlist_648_1237_n_21 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_21);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_11;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

NAND2x1p5_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_9),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_SL g13 ( 
.A1(n_10),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_13)
);

NAND2x1p5_ASAP7_75t_L g14 ( 
.A(n_3),
.B(n_4),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_2),
.B(n_1),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_SL g16 ( 
.A(n_1),
.B(n_8),
.C(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_4),
.Y(n_18)
);

OAI321xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.A3(n_16),
.B1(n_12),
.B2(n_13),
.C(n_5),
.Y(n_19)
);

OAI322xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.A3(n_17),
.B1(n_7),
.B2(n_8),
.C1(n_5),
.C2(n_6),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.B(n_19),
.Y(n_21)
);


endmodule