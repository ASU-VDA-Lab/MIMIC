module fake_netlist_648_2288_n_22 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_22);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_22;

wire n_18;
wire n_19;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

INVx2_ASAP7_75t_SL g12 ( 
.A(n_2),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_0),
.B(n_5),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_7),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_15),
.B(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_17),
.B1(n_16),
.B2(n_14),
.Y(n_19)
);

OAI222xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_4),
.B1(n_1),
.B2(n_6),
.C1(n_7),
.C2(n_3),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_8),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_20),
.B1(n_11),
.B2(n_6),
.Y(n_22)
);


endmodule