module fake_netlist_648_1124_n_20 (n_4, n_1, n_2, n_0, n_5, n_3, n_20);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_20;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_4),
.Y(n_6)
);

AND3x2_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_3),
.C(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_4),
.B(n_2),
.Y(n_8)
);

AND3x4_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_1),
.C(n_5),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

NOR2xp67_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_0),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_4),
.B(n_1),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.C(n_14),
.Y(n_16)
);

AOI332xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_9),
.A3(n_10),
.B1(n_4),
.B2(n_5),
.B3(n_3),
.C1(n_2),
.C2(n_13),
.Y(n_17)
);

AND4x1_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_9),
.C(n_12),
.D(n_2),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_5),
.B1(n_16),
.B2(n_13),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);


endmodule