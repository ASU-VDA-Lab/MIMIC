module fake_netlist_648_362_n_9 (n_1, n_0, n_9);

input n_1;
input n_0;

output n_9;

wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_8;
wire n_6;
wire n_3;

NOR2xp33_ASAP7_75t_L g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

INVx5_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

OR2x2_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

OAI221xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_5),
.B1(n_3),
.B2(n_1),
.C(n_0),
.Y(n_7)
);

NAND3xp33_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_0),
.C(n_1),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_0),
.B1(n_3),
.B2(n_5),
.Y(n_9)
);


endmodule