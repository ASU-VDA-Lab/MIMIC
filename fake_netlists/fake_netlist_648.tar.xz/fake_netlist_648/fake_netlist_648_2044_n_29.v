module fake_netlist_648_2044_n_29 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_29);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_29;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_11;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_26;
wire n_9;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_3),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_2),
.B(n_3),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_8),
.B(n_1),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_0),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_SL g15 ( 
.A1(n_9),
.A2(n_13),
.B1(n_11),
.B2(n_0),
.Y(n_15)
);

NAND2x1p5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_1),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_13),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_15),
.Y(n_19)
);

OA21x2_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_9),
.B(n_12),
.Y(n_20)
);

OAI22xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_18),
.B1(n_13),
.B2(n_15),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_18),
.B1(n_13),
.B2(n_2),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_22),
.B1(n_18),
.B2(n_20),
.C(n_4),
.Y(n_23)
);

INVxp67_ASAP7_75t_SL g24 ( 
.A(n_22),
.Y(n_24)
);

NOR2x1_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_18),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_23),
.B(n_18),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

OAI22x1_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_6),
.B1(n_7),
.B2(n_27),
.Y(n_29)
);


endmodule