module fake_netlist_648_1773_n_18 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_18);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_18;

wire n_17;
wire n_14;
wire n_10;
wire n_15;
wire n_9;
wire n_11;
wire n_13;
wire n_16;
wire n_12;

AND2x2_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_3),
.B(n_4),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_1),
.B(n_5),
.Y(n_11)
);

AND2x6_ASAP7_75t_L g12 ( 
.A(n_2),
.B(n_7),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_5),
.B(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_11),
.B(n_9),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_13),
.B1(n_12),
.B2(n_6),
.C(n_8),
.Y(n_16)
);

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_6),
.B1(n_12),
.B2(n_15),
.Y(n_18)
);


endmodule