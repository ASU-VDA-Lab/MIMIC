module fake_netlist_648_143_n_25 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_25);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_25;

wire n_18;
wire n_19;
wire n_24;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

INVx2_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_7),
.B(n_4),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_8),
.A2(n_2),
.B1(n_11),
.B2(n_10),
.Y(n_17)
);

AND2x2_ASAP7_75t_SL g18 ( 
.A(n_9),
.B(n_6),
.Y(n_18)
);

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_5),
.B(n_4),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_6),
.B(n_5),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_13),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_14),
.B(n_17),
.C(n_19),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_17),
.C(n_7),
.D(n_18),
.Y(n_23)
);

AO22x2_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_19),
.B1(n_12),
.B2(n_3),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);


endmodule