module fake_netlist_648_2740_n_19 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_19);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_19;

wire n_18;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;

INVx6_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_5),
.B(n_3),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_7),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_6),
.B(n_1),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_12),
.B1(n_10),
.B2(n_9),
.Y(n_15)
);

NAND4xp25_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_8),
.C(n_14),
.D(n_7),
.Y(n_16)
);

NAND4xp75_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_6),
.C(n_1),
.D(n_2),
.Y(n_17)
);

OAI22x1_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_6),
.B1(n_1),
.B2(n_4),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_5),
.Y(n_19)
);


endmodule