module fake_netlist_648_2464_n_12 (n_1, n_2, n_0, n_12);

input n_1;
input n_2;
input n_0;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_11;
wire n_8;
wire n_6;
wire n_3;

INVx6_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

AOI21x1_ASAP7_75t_SL g6 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AO22x2_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_0),
.B1(n_6),
.B2(n_5),
.Y(n_9)
);

NOR2x1_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVxp67_ASAP7_75t_SL g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule