module fake_netlist_791_3126_n_18 (n_1, n_0, n_3, n_2, n_4, n_18);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_18;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_5;
wire n_16;
wire n_6;
wire n_14;
wire n_8;
wire n_17;
wire n_12;
wire n_13;
wire n_9;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_SL g6 ( 
.A(n_0),
.Y(n_6)
);

NAND2x1p5_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_2),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_7),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_8),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.B1(n_1),
.B2(n_8),
.C(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

A2O1A1O1Ixp25_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_7),
.B(n_1),
.C(n_10),
.D(n_3),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_11),
.Y(n_15)
);

XNOR2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_10),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_3),
.B1(n_4),
.B2(n_11),
.C1(n_15),
.C2(n_17),
.Y(n_18)
);


endmodule