module fake_netlist_791_588_n_33 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_4, n_8, n_33);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_4;
input n_8;

output n_33;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_31;
wire n_27;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

CKINVDCx16_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_1),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_15),
.A2(n_4),
.B(n_3),
.C(n_2),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_20),
.B(n_15),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_21),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_14),
.B(n_15),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_16),
.B1(n_18),
.B2(n_17),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_24),
.B1(n_18),
.B2(n_17),
.C(n_14),
.Y(n_28)
);

XNOR2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_5),
.Y(n_29)
);

NOR2x1p5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_15),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_6),
.C(n_5),
.Y(n_31)
);

AOI22x1_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_7),
.B1(n_6),
.B2(n_9),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_11),
.B2(n_10),
.Y(n_33)
);


endmodule