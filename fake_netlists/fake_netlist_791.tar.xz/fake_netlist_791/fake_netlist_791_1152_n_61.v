module fake_netlist_791_1152_n_61 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_25, n_5, n_24, n_26, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_61);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_25;
input n_5;
input n_24;
input n_26;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_61;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_50;
wire n_58;
wire n_35;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_42;
wire n_33;
wire n_49;
wire n_48;
wire n_43;
wire n_56;
wire n_38;
wire n_54;
wire n_60;
wire n_57;
wire n_28;
wire n_30;
wire n_59;
wire n_53;
wire n_41;
wire n_51;
wire n_32;

NAND2x1_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_9),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_16),
.B(n_1),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_3),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_7),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_6),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_12),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_23),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_0),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_14),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_20),
.A2(n_4),
.B(n_17),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_25),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_15),
.B(n_8),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_29),
.B(n_24),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_29),
.Y(n_40)
);

AND3x1_ASAP7_75t_SL g41 ( 
.A(n_31),
.B(n_26),
.C(n_24),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_35),
.Y(n_42)
);

AND2x4_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_36),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_34),
.B1(n_37),
.B2(n_27),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_39),
.B(n_32),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_42),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_34),
.B1(n_28),
.B2(n_38),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AOI21xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_43),
.B(n_44),
.Y(n_49)
);

NOR4xp25_ASAP7_75t_SL g50 ( 
.A(n_49),
.B(n_33),
.C(n_41),
.D(n_43),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

AOI221xp5_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_30),
.B1(n_26),
.B2(n_2),
.C(n_5),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_30),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

HB1xp67_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

AO22x2_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_13),
.B1(n_11),
.B2(n_10),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

BUFx3_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

AND3x4_ASAP7_75t_L g59 ( 
.A(n_58),
.B(n_19),
.C(n_18),
.Y(n_59)
);

AND2x4_ASAP7_75t_L g60 ( 
.A(n_57),
.B(n_30),
.Y(n_60)
);

AOI222xp33_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_21),
.B1(n_22),
.B2(n_30),
.C1(n_56),
.C2(n_59),
.Y(n_61)
);


endmodule