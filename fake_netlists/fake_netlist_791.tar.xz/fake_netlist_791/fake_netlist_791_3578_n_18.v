module fake_netlist_791_3578_n_18 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_18);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_18;

wire n_15;
wire n_11;
wire n_16;
wire n_17;
wire n_12;
wire n_8;
wire n_9;
wire n_10;
wire n_13;
wire n_14;

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_2),
.Y(n_8)
);

INVx4_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_4),
.Y(n_12)
);

AO31x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.A3(n_11),
.B(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OR3x1_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.C(n_9),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_8),
.C(n_4),
.Y(n_16)
);

OAI22x1_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.Y(n_17)
);

OAI21xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_7),
.B(n_1),
.Y(n_18)
);


endmodule