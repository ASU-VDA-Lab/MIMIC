module fake_netlist_791_738_n_6 (n_1, n_2, n_0, n_6);

input n_1;
input n_2;
input n_0;

output n_6;

wire n_5;
wire n_3;
wire n_4;

AOI21xp5_ASAP7_75t_L g3 ( 
.A1(n_0),
.A2(n_2),
.B(n_1),
.Y(n_3)
);

OR2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_SL g5 ( 
.A(n_4),
.Y(n_5)
);

CKINVDCx20_ASAP7_75t_R g6 ( 
.A(n_5),
.Y(n_6)
);


endmodule