module fake_netlist_791_1563_n_31 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_31);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_31;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_27;
wire n_26;
wire n_24;
wire n_18;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_22;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_10),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

AND2x6_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_17),
.Y(n_22)
);

CKINVDCx8_ASAP7_75t_R g23 ( 
.A(n_16),
.Y(n_23)
);

INVx4_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_19),
.B1(n_18),
.B2(n_23),
.Y(n_25)
);

NAND4xp75_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_21),
.C(n_20),
.D(n_6),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_R g30 ( 
.A1(n_29),
.A2(n_6),
.B1(n_4),
.B2(n_0),
.C(n_3),
.Y(n_30)
);

AOI322xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_9),
.A3(n_5),
.B1(n_14),
.B2(n_15),
.C1(n_11),
.C2(n_13),
.Y(n_31)
);


endmodule