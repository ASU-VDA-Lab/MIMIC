module fake_netlist_791_175_n_78 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_78);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_78;

wire n_37;
wire n_55;
wire n_36;
wire n_63;
wire n_65;
wire n_35;
wire n_25;
wire n_40;
wire n_73;
wire n_42;
wire n_24;
wire n_48;
wire n_43;
wire n_68;
wire n_67;
wire n_54;
wire n_30;
wire n_59;
wire n_53;
wire n_74;
wire n_51;
wire n_45;
wire n_62;
wire n_75;
wire n_31;
wire n_76;
wire n_28;
wire n_64;
wire n_29;
wire n_70;
wire n_69;
wire n_71;
wire n_26;
wire n_49;
wire n_56;
wire n_61;
wire n_23;
wire n_32;
wire n_47;
wire n_44;
wire n_52;
wire n_77;
wire n_50;
wire n_58;
wire n_66;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_38;
wire n_60;
wire n_57;
wire n_41;
wire n_72;

NAND3xp33_ASAP7_75t_L g23 ( 
.A(n_13),
.B(n_16),
.C(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_3),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_2),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_18),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_0),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_5),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_20),
.A2(n_21),
.B1(n_17),
.B2(n_15),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_12),
.Y(n_35)
);

NOR2x1p5_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_3),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_31),
.B(n_24),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_25),
.B(n_17),
.Y(n_38)
);

OAI21xp33_ASAP7_75t_L g39 ( 
.A1(n_25),
.A2(n_9),
.B(n_4),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_27),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_28),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_29),
.B(n_19),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_37),
.B(n_26),
.Y(n_43)
);

OAI21x1_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_32),
.B(n_30),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_38),
.A2(n_41),
.B(n_42),
.Y(n_45)
);

OAI21x1_ASAP7_75t_L g46 ( 
.A1(n_41),
.A2(n_32),
.B(n_33),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_38),
.Y(n_47)
);

BUFx6f_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

OR2x2_ASAP7_75t_L g50 ( 
.A(n_43),
.B(n_40),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

NOR2xp33_ASAP7_75t_R g52 ( 
.A(n_50),
.B(n_43),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_36),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_48),
.Y(n_55)
);

NAND2xp33_ASAP7_75t_SL g56 ( 
.A(n_52),
.B(n_48),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_49),
.Y(n_57)
);

OAI21xp5_ASAP7_75t_L g58 ( 
.A1(n_53),
.A2(n_51),
.B(n_44),
.Y(n_58)
);

BUFx2_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_SL g60 ( 
.A(n_52),
.B(n_48),
.Y(n_60)
);

OAI21xp5_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_44),
.B(n_51),
.Y(n_61)
);

OAI322xp33_ASAP7_75t_L g62 ( 
.A1(n_60),
.A2(n_34),
.A3(n_45),
.B1(n_23),
.B2(n_29),
.C1(n_35),
.C2(n_36),
.Y(n_62)
);

AO22x2_ASAP7_75t_L g63 ( 
.A1(n_56),
.A2(n_38),
.B1(n_25),
.B2(n_48),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_59),
.Y(n_64)
);

AOI22xp33_ASAP7_75t_L g65 ( 
.A1(n_56),
.A2(n_38),
.B1(n_35),
.B2(n_29),
.Y(n_65)
);

NOR2xp33_ASAP7_75t_R g66 ( 
.A(n_64),
.B(n_19),
.Y(n_66)
);

NOR4xp75_ASAP7_75t_SL g67 ( 
.A(n_63),
.B(n_22),
.C(n_21),
.D(n_10),
.Y(n_67)
);

NAND2x1p5_ASAP7_75t_L g68 ( 
.A(n_63),
.B(n_29),
.Y(n_68)
);

NOR2x1_ASAP7_75t_L g69 ( 
.A(n_62),
.B(n_35),
.Y(n_69)
);

NOR2xp33_ASAP7_75t_L g70 ( 
.A(n_65),
.B(n_22),
.Y(n_70)
);

INVx1_ASAP7_75t_SL g71 ( 
.A(n_61),
.Y(n_71)
);

AO21x2_ASAP7_75t_L g72 ( 
.A1(n_70),
.A2(n_58),
.B(n_61),
.Y(n_72)
);

OR5x1_ASAP7_75t_L g73 ( 
.A(n_66),
.B(n_11),
.C(n_14),
.D(n_35),
.E(n_67),
.Y(n_73)
);

AO21x2_ASAP7_75t_L g74 ( 
.A1(n_68),
.A2(n_71),
.B(n_69),
.Y(n_74)
);

INVx2_ASAP7_75t_SL g75 ( 
.A(n_68),
.Y(n_75)
);

OAI21xp5_ASAP7_75t_SL g76 ( 
.A1(n_75),
.A2(n_73),
.B(n_74),
.Y(n_76)
);

INVx1_ASAP7_75t_SL g77 ( 
.A(n_73),
.Y(n_77)
);

AOI22xp33_ASAP7_75t_SL g78 ( 
.A1(n_77),
.A2(n_74),
.B1(n_76),
.B2(n_72),
.Y(n_78)
);


endmodule