module fake_netlist_791_3114_n_59 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_3, n_14, n_59);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_3;
input n_14;

output n_59;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_20;
wire n_52;
wire n_29;
wire n_36;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_48;
wire n_43;
wire n_49;
wire n_56;
wire n_38;
wire n_54;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_19;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;
wire n_47;

AND2x4_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_11),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_9),
.B(n_5),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

AND2x6_ASAP7_75t_L g25 ( 
.A(n_4),
.B(n_16),
.Y(n_25)
);

INVx6_ASAP7_75t_L g26 ( 
.A(n_8),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_22),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_6),
.B(n_3),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_19),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_28),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_28),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_34),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_31),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_24),
.Y(n_41)
);

OAI21xp5_ASAP7_75t_SL g42 ( 
.A1(n_39),
.A2(n_24),
.B(n_29),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_36),
.B1(n_19),
.B2(n_25),
.Y(n_43)
);

OAI322xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_32),
.A3(n_30),
.B1(n_23),
.B2(n_36),
.C1(n_20),
.C2(n_0),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_25),
.B1(n_26),
.B2(n_23),
.Y(n_45)
);

AOI211x1_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_25),
.B(n_1),
.C(n_0),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

OAI21xp33_ASAP7_75t_SL g48 ( 
.A1(n_43),
.A2(n_25),
.B(n_32),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

AOI211xp5_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_20),
.B(n_5),
.C(n_1),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_45),
.A2(n_20),
.B1(n_18),
.B2(n_17),
.Y(n_53)
);

OA21x2_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_13),
.B(n_7),
.Y(n_54)
);

NAND2x1_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_14),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_49),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_50),
.Y(n_58)
);

AOI322xp5_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_15),
.A3(n_54),
.B1(n_55),
.B2(n_57),
.C1(n_49),
.C2(n_56),
.Y(n_59)
);


endmodule