module fake_netlist_791_2339_n_30 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_30);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_30;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_9),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_11),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_11),
.B(n_7),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_2),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_13),
.B(n_0),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_15),
.B(n_12),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_17),
.B(n_18),
.C(n_16),
.Y(n_23)
);

OAI33xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_18),
.A3(n_21),
.B1(n_10),
.B2(n_2),
.B3(n_16),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_22),
.B1(n_16),
.B2(n_1),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_22),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_3),
.Y(n_27)
);

BUFx4f_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_29),
.Y(n_30)
);


endmodule