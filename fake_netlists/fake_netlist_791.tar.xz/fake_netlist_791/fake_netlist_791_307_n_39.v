module fake_netlist_791_307_n_39 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_3, n_14, n_39);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_3;
input n_14;

output n_39;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_26;
wire n_24;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

INVx2_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_SL g21 ( 
.A(n_7),
.B(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_21),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_24),
.B(n_10),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_26),
.B1(n_22),
.B2(n_20),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_30),
.C(n_29),
.Y(n_32)
);

AOI211x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_25),
.B(n_23),
.C(n_21),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_33),
.B(n_30),
.Y(n_34)
);

OAI21xp5_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_27),
.B(n_11),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_29),
.B1(n_14),
.B2(n_12),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_R g37 ( 
.A1(n_35),
.A2(n_18),
.B1(n_16),
.B2(n_15),
.C(n_29),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI322xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_37),
.A3(n_6),
.B1(n_5),
.B2(n_3),
.C1(n_17),
.C2(n_8),
.Y(n_39)
);


endmodule