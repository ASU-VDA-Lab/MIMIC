module fake_netlist_791_2054_n_51 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_51);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_51;

wire n_37;
wire n_45;
wire n_44;
wire n_47;
wire n_29;
wire n_36;
wire n_50;
wire n_35;
wire n_25;
wire n_40;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_48;
wire n_43;
wire n_49;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_41;
wire n_32;

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_10),
.B(n_9),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_19),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_SL g27 ( 
.A(n_13),
.B(n_14),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_11),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_2),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_16),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_26),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_27),
.A2(n_19),
.B1(n_18),
.B2(n_0),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_24),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_25),
.Y(n_36)
);

CKINVDCx14_ASAP7_75t_R g37 ( 
.A(n_35),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_32),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVxp67_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_34),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_29),
.B1(n_28),
.B2(n_30),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_18),
.Y(n_46)
);

NAND4xp75_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_23),
.C(n_4),
.D(n_3),
.Y(n_47)
);

NAND2x1p5_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_25),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

OAI322xp33_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_36),
.A3(n_31),
.B1(n_8),
.B2(n_15),
.C1(n_5),
.C2(n_7),
.Y(n_50)
);

AOI222xp33_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_17),
.B1(n_20),
.B2(n_21),
.C1(n_36),
.C2(n_50),
.Y(n_51)
);


endmodule