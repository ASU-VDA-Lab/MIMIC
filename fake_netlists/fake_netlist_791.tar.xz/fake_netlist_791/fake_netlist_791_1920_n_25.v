module fake_netlist_791_1920_n_25 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_4, n_8, n_25);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_4;
input n_8;

output n_25;

wire n_20;
wire n_17;
wire n_24;
wire n_18;
wire n_13;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_8),
.B(n_5),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_12),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_6),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_10),
.Y(n_17)
);

AO21x1_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_14),
.B(n_15),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_7),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI311xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_18),
.A3(n_7),
.B(n_14),
.C(n_0),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_1),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_24)
);

NOR2x1p5_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_9),
.Y(n_25)
);


endmodule