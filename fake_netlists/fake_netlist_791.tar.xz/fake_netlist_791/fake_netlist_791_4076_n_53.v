module fake_netlist_791_4076_n_53 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_53);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_53;

wire n_37;
wire n_45;
wire n_44;
wire n_20;
wire n_52;
wire n_29;
wire n_36;
wire n_17;
wire n_50;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_18;
wire n_48;
wire n_43;
wire n_49;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;
wire n_47;

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_12),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_8),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_1),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_8),
.B(n_5),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_12),
.A2(n_9),
.B1(n_16),
.B2(n_15),
.Y(n_22)
);

NAND2x1_ASAP7_75t_L g23 ( 
.A(n_10),
.B(n_2),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_17),
.B(n_0),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_0),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_1),
.Y(n_27)
);

INVx2_ASAP7_75t_SL g28 ( 
.A(n_18),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_19),
.B1(n_21),
.B2(n_23),
.Y(n_29)
);

OAI21x1_ASAP7_75t_L g30 ( 
.A1(n_26),
.A2(n_18),
.B(n_22),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_25),
.B1(n_20),
.B2(n_27),
.C1(n_26),
.C2(n_28),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_30),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_20),
.B1(n_31),
.B2(n_28),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

O2A1O1Ixp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_32),
.B(n_36),
.C(n_31),
.Y(n_42)
);

INVx1_ASAP7_75t_SL g43 ( 
.A(n_38),
.Y(n_43)
);

NAND4xp25_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_36),
.C(n_37),
.D(n_2),
.Y(n_44)
);

INVx4_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

AOI31xp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_44),
.A3(n_41),
.B(n_42),
.Y(n_46)
);

O2A1O1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_47)
);

NOR2x1_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_3),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_6),
.B1(n_4),
.B2(n_9),
.C(n_10),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

AOI21xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_47),
.B(n_48),
.Y(n_52)
);

AOI322xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_49),
.A3(n_51),
.B1(n_16),
.B2(n_11),
.C1(n_13),
.C2(n_14),
.Y(n_53)
);


endmodule