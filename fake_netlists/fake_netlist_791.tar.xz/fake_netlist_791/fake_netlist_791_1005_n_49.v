module fake_netlist_791_1005_n_49 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_4, n_8, n_49);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_4;
input n_8;

output n_49;

wire n_37;
wire n_45;
wire n_44;
wire n_20;
wire n_47;
wire n_29;
wire n_36;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_18;
wire n_13;
wire n_48;
wire n_43;
wire n_15;
wire n_16;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_41;
wire n_32;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_8),
.B(n_7),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

BUFx12f_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_20),
.B(n_3),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

NOR3xp33_ASAP7_75t_SL g26 ( 
.A(n_15),
.B(n_1),
.C(n_0),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_21),
.A2(n_18),
.B1(n_16),
.B2(n_17),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_SL g28 ( 
.A1(n_21),
.A2(n_18),
.B1(n_14),
.B2(n_17),
.Y(n_28)
);

INVx6_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_20),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_SL g32 ( 
.A1(n_27),
.A2(n_24),
.B1(n_22),
.B2(n_25),
.C(n_13),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_25),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_28),
.Y(n_34)
);

NAND2xp33_ASAP7_75t_R g35 ( 
.A(n_33),
.B(n_26),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_29),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_36),
.B(n_33),
.Y(n_38)
);

AOI211x1_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_24),
.B(n_13),
.C(n_26),
.Y(n_39)
);

NOR2x1_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_25),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

OAI322xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_22),
.A3(n_20),
.B1(n_32),
.B2(n_19),
.C1(n_1),
.C2(n_2),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_37),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_32),
.B1(n_22),
.B2(n_23),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_41),
.Y(n_45)
);

NOR5xp2_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_5),
.C(n_4),
.D(n_2),
.E(n_23),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

AOI322xp5_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_4),
.A3(n_5),
.B1(n_11),
.B2(n_40),
.C1(n_46),
.C2(n_47),
.Y(n_49)
);


endmodule