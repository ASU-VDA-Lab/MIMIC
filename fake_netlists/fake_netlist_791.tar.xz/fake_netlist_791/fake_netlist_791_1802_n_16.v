module fake_netlist_791_1802_n_16 (n_1, n_0, n_3, n_2, n_4, n_16);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_16;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_5;
wire n_6;
wire n_14;
wire n_9;
wire n_12;
wire n_13;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_0),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_4),
.Y(n_8)
);

NAND2x1p5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

AO31x2_ASAP7_75t_L g10 ( 
.A1(n_5),
.A2(n_6),
.A3(n_7),
.B(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

NAND4xp25_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_6),
.C(n_8),
.D(n_5),
.Y(n_14)
);

INVx6_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_1),
.B1(n_5),
.B2(n_11),
.C1(n_14),
.C2(n_0),
.Y(n_16)
);


endmodule