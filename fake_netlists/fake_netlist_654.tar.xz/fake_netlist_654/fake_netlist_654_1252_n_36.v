module fake_netlist_654_1252_n_36 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_36);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_36;

wire n_18;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_9),
.B(n_10),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_1),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_19),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

AO221x1_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_22),
.B1(n_15),
.B2(n_5),
.C(n_6),
.Y(n_27)
);

OAI221xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_25),
.B1(n_20),
.B2(n_16),
.C(n_17),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_23),
.B(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_30),
.B(n_6),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_31),
.Y(n_33)
);

NAND4xp25_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_23),
.C(n_27),
.D(n_15),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_22),
.B1(n_7),
.B2(n_3),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_34),
.B1(n_22),
.B2(n_8),
.Y(n_36)
);


endmodule