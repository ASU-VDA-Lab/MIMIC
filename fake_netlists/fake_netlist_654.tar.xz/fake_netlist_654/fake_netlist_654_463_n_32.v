module fake_netlist_654_463_n_32 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_32);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_32;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_9;
wire n_13;

BUFx2_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_3),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_8),
.B(n_3),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_6),
.B(n_4),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_9),
.B(n_6),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_9),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_21),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_10),
.Y(n_23)
);

AOI21xp33_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_15),
.B(n_11),
.Y(n_24)
);

OAI21xp33_ASAP7_75t_SL g25 ( 
.A1(n_23),
.A2(n_19),
.B(n_16),
.Y(n_25)
);

OAI221xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_23),
.B1(n_19),
.B2(n_13),
.C(n_14),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_13),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_7),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_26),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_14),
.B1(n_7),
.B2(n_1),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_28),
.A2(n_5),
.B1(n_2),
.B2(n_1),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_2),
.B1(n_5),
.B2(n_30),
.Y(n_32)
);


endmodule