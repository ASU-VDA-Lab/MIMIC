module fake_netlist_654_3077_n_31 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_31);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_31;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_29;
wire n_26;

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

CKINVDCx16_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_22),
.B(n_16),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_15),
.B(n_20),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_25),
.B1(n_23),
.B2(n_21),
.C(n_18),
.Y(n_27)
);

XOR2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_15),
.Y(n_28)
);

OAI321xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_5),
.A3(n_4),
.B1(n_6),
.B2(n_7),
.C(n_3),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_14),
.B2(n_13),
.Y(n_31)
);


endmodule