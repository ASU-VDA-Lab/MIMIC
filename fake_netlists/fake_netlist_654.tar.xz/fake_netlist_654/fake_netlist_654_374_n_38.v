module fake_netlist_654_374_n_38 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_38);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_38;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_13;

INVx4_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_7),
.B(n_2),
.Y(n_16)
);

XOR2xp5_ASAP7_75t_L g17 ( 
.A(n_8),
.B(n_6),
.Y(n_17)
);

AO22x1_ASAP7_75t_L g18 ( 
.A1(n_11),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_4),
.B(n_3),
.C(n_1),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_4),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_5),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_15),
.Y(n_24)
);

OAI211xp5_ASAP7_75t_L g25 ( 
.A1(n_19),
.A2(n_11),
.B(n_17),
.C(n_13),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_20),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_21),
.B1(n_14),
.B2(n_11),
.C(n_16),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_SL g28 ( 
.A1(n_25),
.A2(n_17),
.B1(n_14),
.B2(n_18),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_24),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_28),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_29),
.B1(n_30),
.B2(n_24),
.Y(n_33)
);

OAI322xp33_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_7),
.A3(n_8),
.B1(n_12),
.B2(n_15),
.C1(n_30),
.C2(n_32),
.Y(n_34)
);

CKINVDCx12_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_32),
.Y(n_36)
);

XNOR2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_35),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_SL g38 ( 
.A1(n_37),
.A2(n_35),
.B1(n_36),
.B2(n_32),
.Y(n_38)
);


endmodule