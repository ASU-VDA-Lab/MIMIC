module fake_netlist_654_2370_n_22 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_22);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_22;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx6_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_L g16 ( 
.A(n_7),
.B(n_4),
.C(n_3),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_12),
.B1(n_11),
.B2(n_8),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_14),
.Y(n_19)
);

AOI31xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_14),
.A3(n_13),
.B(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_13),
.B1(n_17),
.B2(n_20),
.C1(n_8),
.C2(n_7),
.Y(n_22)
);


endmodule