module fake_netlist_654_2712_n_33 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_33);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_33;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_32;

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_13),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_4),
.A2(n_14),
.B(n_7),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_0),
.B(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_6),
.B(n_10),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_18),
.B(n_17),
.Y(n_22)
);

AOI322xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.A3(n_15),
.B1(n_16),
.B2(n_2),
.C1(n_1),
.C2(n_3),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_SL g24 ( 
.A(n_22),
.B(n_19),
.C(n_16),
.Y(n_24)
);

OR2x2_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_8),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI21xp33_ASAP7_75t_SL g29 ( 
.A1(n_27),
.A2(n_23),
.B(n_9),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_SL g31 ( 
.A(n_29),
.B(n_12),
.C(n_11),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

XNOR2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_31),
.Y(n_33)
);


endmodule