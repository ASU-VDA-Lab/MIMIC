module fake_netlist_654_1354_n_8 (n_1, n_2, n_0, n_8);

input n_1;
input n_2;
input n_0;

output n_8;

wire n_4;
wire n_7;
wire n_5;
wire n_6;
wire n_3;

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

O2A1O1Ixp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_7)
);

AO22x2_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.Y(n_8)
);


endmodule