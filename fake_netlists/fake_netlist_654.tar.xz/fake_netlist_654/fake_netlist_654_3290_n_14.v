module fake_netlist_654_3290_n_14 (n_4, n_1, n_2, n_0, n_5, n_6, n_3, n_14);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_14;

wire n_9;
wire n_7;
wire n_13;
wire n_10;
wire n_12;
wire n_11;
wire n_8;

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_2),
.A2(n_3),
.B1(n_4),
.B2(n_6),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_R g8 ( 
.A(n_5),
.B(n_2),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_0),
.A2(n_4),
.B1(n_5),
.B2(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_1),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_1),
.Y(n_12)
);

AOI321xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.A3(n_7),
.B1(n_11),
.B2(n_6),
.C(n_1),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_8),
.B2(n_3),
.Y(n_14)
);


endmodule