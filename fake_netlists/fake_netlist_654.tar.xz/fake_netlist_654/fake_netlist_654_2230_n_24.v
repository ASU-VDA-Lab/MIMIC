module fake_netlist_654_2230_n_24 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_24);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_24;

wire n_18;
wire n_19;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_2),
.Y(n_12)
);

BUFx10_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

CKINVDCx16_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_1),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_15),
.B1(n_12),
.B2(n_13),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_12),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_16),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B1(n_6),
.B2(n_4),
.C(n_5),
.Y(n_21)
);

INVx6_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_7),
.B1(n_5),
.B2(n_20),
.Y(n_23)
);

AOI222xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_7),
.B1(n_10),
.B2(n_3),
.C1(n_11),
.C2(n_8),
.Y(n_24)
);


endmodule