module fake_netlist_654_1079_n_29 (n_4, n_1, n_2, n_0, n_5, n_3, n_29);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_29;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_26;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_0),
.B(n_3),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_1),
.Y(n_10)
);

AO31x2_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_2),
.B(n_1),
.Y(n_13)
);

AO21x1_ASAP7_75t_L g14 ( 
.A1(n_6),
.A2(n_4),
.B(n_3),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_6),
.B(n_10),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_7),
.B1(n_12),
.B2(n_15),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_11),
.B(n_8),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_4),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_13),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_17),
.Y(n_22)
);

AOI221x1_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.C(n_11),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

AO22x1_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_19),
.B1(n_18),
.B2(n_4),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_22),
.Y(n_26)
);

OAI22x1_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_22),
.B1(n_23),
.B2(n_5),
.Y(n_27)
);

XNOR2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_23),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_5),
.B1(n_25),
.B2(n_27),
.Y(n_29)
);


endmodule