module fake_netlist_854_2222_n_12 (n_2, n_0, n_1, n_12);

input n_2;
input n_0;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_8;

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_0),
.B(n_2),
.Y(n_3)
);

INVx6_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI32xp33_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.A3(n_3),
.B1(n_5),
.B2(n_7),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_9),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_5),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);


endmodule