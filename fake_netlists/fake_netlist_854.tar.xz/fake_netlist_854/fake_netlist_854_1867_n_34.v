module fake_netlist_854_1867_n_34 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_34);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_28;
wire n_9;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;
wire n_8;

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_6),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_2),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

NAND2xp33_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_0),
.Y(n_13)
);

AOI221x1_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_4),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_2),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_7),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_4),
.Y(n_17)
);

O2A1O1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_11),
.A2(n_6),
.B(n_5),
.C(n_3),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_14),
.B(n_9),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_13),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_13),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_20),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_20),
.B1(n_22),
.B2(n_9),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_24),
.B1(n_23),
.B2(n_25),
.C(n_22),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_23),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_25),
.B(n_18),
.C(n_10),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_22),
.B(n_11),
.Y(n_32)
);

OAI21xp5_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_5),
.B(n_3),
.Y(n_33)
);

AOI21xp33_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_33),
.B(n_32),
.Y(n_34)
);


endmodule