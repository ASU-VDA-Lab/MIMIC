module fake_netlist_854_1353_n_30 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_30);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_8),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_SL g20 ( 
.A(n_4),
.B(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

OAI211xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_22),
.B(n_18),
.C(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_1),
.C(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_26),
.Y(n_27)
);

OAI222xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_5),
.B1(n_2),
.B2(n_6),
.C1(n_11),
.C2(n_10),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_30)
);


endmodule