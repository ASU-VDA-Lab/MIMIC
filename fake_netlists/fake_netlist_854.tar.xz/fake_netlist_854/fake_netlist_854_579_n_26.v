module fake_netlist_854_579_n_26 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_26);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

AND2x4_ASAP7_75t_L g10 ( 
.A(n_2),
.B(n_4),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_7),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_3),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_3),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_1),
.B(n_8),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_5),
.Y(n_17)
);

AO31x2_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_11),
.A3(n_16),
.B(n_14),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_13),
.B1(n_11),
.B2(n_10),
.C1(n_15),
.C2(n_6),
.Y(n_19)
);

AOI21xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_6),
.B(n_0),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_18),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);


endmodule