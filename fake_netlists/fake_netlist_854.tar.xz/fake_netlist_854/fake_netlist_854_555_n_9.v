module fake_netlist_854_555_n_9 (n_2, n_0, n_1, n_9);

input n_2;
input n_0;
input n_1;

output n_9;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_8;

NOR2xp33_ASAP7_75t_R g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_1),
.Y(n_4)
);

AO21x2_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B(n_0),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_3),
.B(n_2),
.Y(n_6)
);

OAI211xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_5),
.B(n_2),
.C(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI222xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B1(n_2),
.B2(n_4),
.C1(n_7),
.C2(n_3),
.Y(n_9)
);


endmodule