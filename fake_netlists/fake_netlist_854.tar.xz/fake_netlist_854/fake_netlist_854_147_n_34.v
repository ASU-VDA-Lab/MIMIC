module fake_netlist_854_147_n_34 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_34);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_14),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_5),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

BUFx4f_ASAP7_75t_SL g21 ( 
.A(n_19),
.Y(n_21)
);

OR2x6_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_4),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_18),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_17),
.B1(n_16),
.B2(n_19),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_15),
.B(n_19),
.Y(n_25)
);

BUFx10_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_24),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_27),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_26),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_R g30 ( 
.A(n_28),
.B(n_6),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_23),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_7),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_19),
.C(n_21),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.A3(n_9),
.B1(n_3),
.B2(n_0),
.C1(n_11),
.C2(n_10),
.Y(n_34)
);


endmodule