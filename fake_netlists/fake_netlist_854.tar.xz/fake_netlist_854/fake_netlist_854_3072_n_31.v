module fake_netlist_854_3072_n_31 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_31);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_31;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

BUFx3_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_9),
.B(n_12),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_4),
.B(n_0),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_1),
.A2(n_8),
.B(n_7),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_2),
.B(n_5),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_10),
.B(n_11),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_14),
.B(n_3),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_17),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_16),
.C(n_18),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_15),
.B2(n_6),
.Y(n_31)
);


endmodule