module fake_netlist_854_3101_n_22 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_22);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;
wire n_11;

O2A1O1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_0),
.B(n_4),
.C(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_3),
.A2(n_4),
.B1(n_6),
.B2(n_1),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_5),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_9),
.B(n_2),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_15),
.B(n_12),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.B1(n_13),
.B2(n_5),
.C(n_7),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_19),
.Y(n_20)
);

XOR2x1_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_18),
.Y(n_21)
);

INVxp67_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);


endmodule