module fake_netlist_854_2665_n_36 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_36);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_36;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_11;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_0),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_5),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_8),
.B(n_2),
.Y(n_17)
);

AOI21x1_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_17),
.B(n_11),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_13),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_15),
.A2(n_16),
.B(n_14),
.C(n_1),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_15),
.A2(n_9),
.B(n_3),
.Y(n_22)
);

AND2x2_ASAP7_75t_SL g23 ( 
.A(n_20),
.B(n_4),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_18),
.B(n_4),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx4_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_23),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_22),
.B(n_21),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_SL g30 ( 
.A1(n_28),
.A2(n_19),
.B1(n_21),
.B2(n_29),
.C(n_26),
.Y(n_30)
);

AOI221xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_27),
.B1(n_24),
.B2(n_23),
.C(n_7),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_32),
.B1(n_34),
.B2(n_27),
.Y(n_36)
);


endmodule