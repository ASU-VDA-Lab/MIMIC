module fake_netlist_888_1726_n_21 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_21;

wire n_15;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_14;

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_2),
.B(n_7),
.Y(n_13)
);

AO22x2_ASAP7_75t_L g14 ( 
.A1(n_3),
.A2(n_10),
.B1(n_8),
.B2(n_1),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_7),
.B(n_9),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_15),
.B1(n_12),
.B2(n_14),
.C(n_0),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_4),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_11),
.B(n_6),
.Y(n_21)
);


endmodule