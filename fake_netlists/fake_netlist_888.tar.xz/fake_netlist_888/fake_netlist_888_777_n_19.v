module fake_netlist_888_777_n_19 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_19);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_19;

wire n_15;
wire n_11;
wire n_16;
wire n_12;
wire n_17;
wire n_18;
wire n_13;
wire n_14;

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_9),
.Y(n_11)
);

CKINVDCx11_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

AO31x2_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_7),
.A3(n_6),
.B(n_0),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

NOR4xp25_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.C(n_7),
.D(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_12),
.B1(n_5),
.B2(n_3),
.C1(n_10),
.C2(n_4),
.Y(n_19)
);


endmodule