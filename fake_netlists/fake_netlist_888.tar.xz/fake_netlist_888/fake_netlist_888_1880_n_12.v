module fake_netlist_888_1880_n_12 (n_0, n_1, n_2, n_12);

input n_0;
input n_1;
input n_2;

output n_12;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_SL g8 ( 
.A1(n_5),
.A2(n_3),
.B(n_2),
.Y(n_8)
);

OAI31xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_6),
.A3(n_1),
.B(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI322xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_7),
.C1(n_3),
.C2(n_4),
.Y(n_11)
);

OA22x2_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_12)
);


endmodule