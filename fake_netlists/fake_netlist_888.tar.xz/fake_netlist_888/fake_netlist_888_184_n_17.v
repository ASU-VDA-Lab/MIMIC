module fake_netlist_888_184_n_17 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_17);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_17;

wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_0),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

OAI33xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_9),
.A3(n_10),
.B1(n_6),
.B2(n_4),
.B3(n_3),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_6),
.B1(n_9),
.B2(n_12),
.C(n_13),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

XNOR2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.Y(n_17)
);


endmodule