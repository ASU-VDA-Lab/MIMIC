module fake_netlist_888_263_n_35 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_35);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_35;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_32;
wire n_26;
wire n_29;

INVx1_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_3),
.B(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_SL g20 ( 
.A(n_15),
.B(n_1),
.C(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

AOI21x1_ASAP7_75t_SL g22 ( 
.A1(n_18),
.A2(n_20),
.B(n_15),
.Y(n_22)
);

OAI222xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_14),
.B1(n_11),
.B2(n_12),
.C1(n_19),
.C2(n_17),
.Y(n_23)
);

OAI33xp33_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_17),
.A3(n_19),
.B1(n_16),
.B2(n_18),
.B3(n_0),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_21),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_18),
.Y(n_28)
);

OAI21xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_22),
.B(n_2),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_5),
.B1(n_2),
.B2(n_6),
.C1(n_7),
.C2(n_8),
.Y(n_30)
);

NOR2xp67_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_9),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

XNOR2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_5),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_7),
.B1(n_31),
.B2(n_33),
.Y(n_35)
);


endmodule