module fake_netlist_888_934_n_33 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_33);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_33;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_13;
wire n_25;
wire n_14;
wire n_22;
wire n_32;
wire n_26;
wire n_29;

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_10),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_2),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_R g21 ( 
.A(n_17),
.B(n_14),
.Y(n_21)
);

NOR2x1p5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_15),
.Y(n_24)
);

OAI31xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_18),
.A3(n_15),
.B(n_21),
.Y(n_25)
);

OAI211xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_13),
.B(n_11),
.C(n_22),
.Y(n_26)
);

NAND4xp25_ASAP7_75t_SL g27 ( 
.A(n_25),
.B(n_5),
.C(n_4),
.D(n_3),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

OAI21xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_24),
.B(n_3),
.Y(n_30)
);

XOR2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_24),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_24),
.B1(n_6),
.B2(n_4),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_31),
.A2(n_32),
.B1(n_30),
.B2(n_6),
.Y(n_33)
);


endmodule