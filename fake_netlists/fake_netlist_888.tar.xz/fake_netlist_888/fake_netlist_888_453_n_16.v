module fake_netlist_888_453_n_16 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_16);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_16;

wire n_15;
wire n_11;
wire n_9;
wire n_13;
wire n_14;
wire n_10;
wire n_8;
wire n_12;

NAND2xp33_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_2),
.B(n_7),
.Y(n_10)
);

AOI21x1_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

INVxp67_ASAP7_75t_SL g12 ( 
.A(n_11),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_8),
.C(n_12),
.Y(n_14)
);

OAI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_2),
.B1(n_1),
.B2(n_4),
.C1(n_6),
.C2(n_5),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_5),
.B1(n_7),
.B2(n_13),
.Y(n_16)
);


endmodule