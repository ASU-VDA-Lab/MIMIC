module fake_netlist_888_347_n_22 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_22);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_22;

wire n_15;
wire n_16;
wire n_19;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_14;

XOR2xp5_ASAP7_75t_L g13 ( 
.A(n_1),
.B(n_11),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_4),
.B(n_9),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_L g15 ( 
.A1(n_3),
.A2(n_10),
.B1(n_8),
.B2(n_5),
.Y(n_15)
);

BUFx10_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI31xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.A3(n_13),
.B(n_14),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_7),
.Y(n_21)
);

OR2x6_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_12),
.Y(n_22)
);


endmodule