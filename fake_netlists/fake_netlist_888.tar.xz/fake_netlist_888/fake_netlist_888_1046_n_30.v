module fake_netlist_888_1046_n_30 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_30);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_30;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_6),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_2),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_8),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

NOR2xp67_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_0),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_0),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_15),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

OAI21xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B(n_18),
.Y(n_22)
);

O2A1O1Ixp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_15),
.B(n_16),
.C(n_3),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_11),
.C(n_1),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_11),
.B1(n_4),
.B2(n_2),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

OA22x2_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_26),
.B1(n_23),
.B2(n_5),
.Y(n_28)
);

AO22x2_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_7),
.B1(n_9),
.B2(n_29),
.Y(n_30)
);


endmodule