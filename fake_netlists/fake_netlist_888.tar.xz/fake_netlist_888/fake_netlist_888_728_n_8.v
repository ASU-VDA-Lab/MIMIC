module fake_netlist_888_728_n_8 (n_0, n_1, n_8);

input n_0;
input n_1;

output n_8;

wire n_2;
wire n_5;
wire n_3;
wire n_4;
wire n_6;
wire n_7;

INVx3_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

OAI21x1_ASAP7_75t_L g3 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_3)
);

HB1xp67_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AOI21xp33_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_3),
.B(n_2),
.Y(n_5)
);

OAI221xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_4),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_0),
.B1(n_1),
.B2(n_6),
.Y(n_8)
);


endmodule