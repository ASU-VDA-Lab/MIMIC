module fake_netlist_607_1466_n_18 (n_0, n_4, n_1, n_2, n_3, n_18);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_18;

wire n_7;
wire n_11;
wire n_16;
wire n_8;
wire n_5;
wire n_15;
wire n_14;
wire n_17;
wire n_10;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

AND2x6_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_4),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_4),
.B(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_SL g8 ( 
.A(n_5),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_8),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_0),
.Y(n_10)
);

NOR2x1p5_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_6),
.Y(n_11)
);

INVxp67_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

NOR2x1_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_12),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_SL g14 ( 
.A1(n_11),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_SL g16 ( 
.A1(n_14),
.A2(n_1),
.B1(n_3),
.B2(n_10),
.C(n_6),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_16),
.B(n_3),
.Y(n_18)
);


endmodule