module fake_netlist_607_892_n_51 (n_11, n_8, n_15, n_3, n_21, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_51);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_51;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

INVx1_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_17),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

NOR2x1_ASAP7_75t_L g29 ( 
.A(n_15),
.B(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_23),
.B(n_18),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_23),
.B(n_19),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_SL g33 ( 
.A(n_24),
.B(n_19),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_26),
.A2(n_21),
.B1(n_1),
.B2(n_0),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_32),
.Y(n_35)
);

CKINVDCx9p33_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AO21x2_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_34),
.B(n_22),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_35),
.Y(n_39)
);

AND2x4_ASAP7_75t_SL g40 ( 
.A(n_37),
.B(n_32),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_31),
.B1(n_27),
.B2(n_24),
.Y(n_41)
);

OAI21xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_29),
.B(n_28),
.Y(n_42)
);

AOI211xp5_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_30),
.B(n_25),
.C(n_38),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_38),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_38),
.B1(n_40),
.B2(n_21),
.C(n_2),
.Y(n_45)
);

OAI211xp5_ASAP7_75t_SL g46 ( 
.A1(n_43),
.A2(n_7),
.B(n_4),
.C(n_3),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_12),
.B1(n_11),
.B2(n_8),
.Y(n_49)
);

XOR2xp5_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_13),
.Y(n_50)
);

AOI221xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_49),
.B1(n_46),
.B2(n_14),
.C(n_20),
.Y(n_51)
);


endmodule