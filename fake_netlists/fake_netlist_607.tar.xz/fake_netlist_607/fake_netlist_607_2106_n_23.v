module fake_netlist_607_2106_n_23 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_23);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_23;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_19;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

OAI21xp33_ASAP7_75t_SL g12 ( 
.A1(n_6),
.A2(n_4),
.B(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_1),
.B(n_7),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI211x1_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_9),
.B(n_8),
.C(n_5),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_14),
.Y(n_19)
);

NOR4xp25_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_13),
.C(n_12),
.D(n_17),
.Y(n_20)
);

NAND3xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_7),
.C(n_10),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_11),
.Y(n_23)
);


endmodule