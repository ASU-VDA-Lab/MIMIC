module fake_netlist_607_666_n_6 (n_1, n_0, n_6);

input n_1;
input n_0;

output n_6;

wire n_5;
wire n_4;
wire n_2;
wire n_3;

INVx2_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

HB1xp67_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

NAND2x1_ASAP7_75t_SL g4 ( 
.A(n_3),
.B(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);


endmodule