module fake_netlist_607_1630_n_7 (n_1, n_2, n_3, n_0, n_7);

input n_1;
input n_2;
input n_3;
input n_0;

output n_7;

wire n_5;
wire n_6;
wire n_4;

OAI21x1_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_4)
);

NOR2xp67_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

OAI221xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_0),
.B1(n_1),
.B2(n_4),
.C(n_5),
.Y(n_7)
);


endmodule