module fake_netlist_607_2189_n_21 (n_5, n_0, n_4, n_1, n_2, n_3, n_21);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_21;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_7;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_2),
.A2(n_4),
.B1(n_1),
.B2(n_5),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_L g8 ( 
.A1(n_2),
.A2(n_5),
.B(n_1),
.Y(n_8)
);

OR2x6_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_0),
.Y(n_9)
);

A2O1A1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_4),
.B(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_6),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_9),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_13),
.B(n_11),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_10),
.B(n_7),
.C(n_13),
.Y(n_17)
);

NAND4xp75_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.C(n_9),
.D(n_7),
.Y(n_18)
);

NAND4xp25_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_15),
.C(n_9),
.D(n_5),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_19),
.B(n_18),
.Y(n_21)
);


endmodule