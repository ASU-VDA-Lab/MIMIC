module fake_netlist_607_1489_n_57 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_57);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_57;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_52;
wire n_24;
wire n_51;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

INVx2_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_SL g22 ( 
.A1(n_16),
.A2(n_13),
.B1(n_5),
.B2(n_12),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_19),
.B(n_0),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_9),
.B(n_3),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_20),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_21),
.Y(n_30)
);

NOR2xp67_ASAP7_75t_L g31 ( 
.A(n_23),
.B(n_1),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_24),
.Y(n_32)
);

AO221x2_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_22),
.B1(n_26),
.B2(n_25),
.C(n_2),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

OAI21x1_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_27),
.B(n_7),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_32),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

NAND2x1p5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_35),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_33),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_33),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_SL g43 ( 
.A(n_39),
.B(n_36),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_30),
.Y(n_44)
);

AOI21xp33_ASAP7_75t_SL g45 ( 
.A1(n_42),
.A2(n_40),
.B(n_29),
.Y(n_45)
);

INVxp67_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

O2A1O1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_32),
.B(n_30),
.C(n_31),
.Y(n_47)
);

AOI222xp33_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_33),
.B1(n_32),
.B2(n_35),
.C1(n_10),
.C2(n_8),
.Y(n_48)
);

OAI221xp5_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_11),
.B1(n_10),
.B2(n_16),
.C(n_17),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_11),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

CKINVDCx11_ASAP7_75t_R g52 ( 
.A(n_45),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_47),
.Y(n_53)
);

OAI31xp67_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_19),
.A3(n_18),
.B(n_17),
.Y(n_54)
);

OAI22x1_ASAP7_75t_L g55 ( 
.A1(n_50),
.A2(n_18),
.B1(n_51),
.B2(n_49),
.Y(n_55)
);

NOR3xp33_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_50),
.C(n_54),
.Y(n_56)
);

OAI22xp33_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_55),
.B1(n_50),
.B2(n_53),
.Y(n_57)
);


endmodule