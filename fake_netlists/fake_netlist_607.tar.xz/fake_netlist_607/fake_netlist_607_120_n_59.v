module fake_netlist_607_120_n_59 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_59);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_59;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_58;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

BUFx3_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_SL g20 ( 
.A1(n_15),
.A2(n_16),
.B1(n_5),
.B2(n_0),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_11),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_3),
.B(n_16),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_14),
.B(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_6),
.B(n_9),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_3),
.B(n_18),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_21),
.A2(n_10),
.B1(n_2),
.B2(n_1),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_21),
.B(n_19),
.C(n_25),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_26),
.B(n_24),
.Y(n_34)
);

OAI21x1_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_26),
.B(n_24),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_31),
.Y(n_36)
);

NAND2x1_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_32),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_SL g38 ( 
.A1(n_35),
.A2(n_20),
.B1(n_22),
.B2(n_23),
.Y(n_38)
);

CKINVDCx16_ASAP7_75t_R g39 ( 
.A(n_36),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_36),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_34),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_37),
.B(n_35),
.Y(n_42)
);

AOI32xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_23),
.A3(n_22),
.B1(n_24),
.B2(n_27),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_32),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_39),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_20),
.B1(n_28),
.B2(n_23),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_44),
.B(n_21),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_SL g48 ( 
.A(n_45),
.B(n_21),
.Y(n_48)
);

OAI21xp33_ASAP7_75t_L g49 ( 
.A1(n_43),
.A2(n_29),
.B(n_21),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_26),
.Y(n_50)
);

OR3x2_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_2),
.C(n_1),
.Y(n_51)
);

BUFx2_ASAP7_75t_L g52 ( 
.A(n_46),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_48),
.Y(n_53)
);

NOR3x1_ASAP7_75t_L g54 ( 
.A(n_47),
.B(n_27),
.C(n_10),
.Y(n_54)
);

OA22x2_ASAP7_75t_L g55 ( 
.A1(n_50),
.A2(n_21),
.B1(n_32),
.B2(n_17),
.Y(n_55)
);

OAI22xp5_ASAP7_75t_L g56 ( 
.A1(n_51),
.A2(n_29),
.B1(n_18),
.B2(n_7),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_50),
.Y(n_57)
);

OAI21x1_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_57),
.B(n_55),
.Y(n_58)
);

AOI322xp5_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_52),
.A3(n_53),
.B1(n_54),
.B2(n_12),
.C1(n_8),
.C2(n_13),
.Y(n_59)
);


endmodule