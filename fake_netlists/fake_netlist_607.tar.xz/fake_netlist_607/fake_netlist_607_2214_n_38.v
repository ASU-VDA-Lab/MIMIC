module fake_netlist_607_2214_n_38 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_17, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_38);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_17;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_38;

wire n_31;
wire n_37;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

AOI21x1_ASAP7_75t_L g18 ( 
.A1(n_9),
.A2(n_8),
.B(n_11),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_17),
.B(n_14),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_12),
.B(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_3),
.B(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

AO22x1_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_16),
.B1(n_5),
.B2(n_4),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_21),
.A2(n_17),
.B(n_5),
.C(n_0),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_21),
.A2(n_6),
.B(n_1),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_24),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_29),
.B(n_27),
.C(n_20),
.Y(n_32)
);

AOI221x1_ASAP7_75t_SL g33 ( 
.A1(n_31),
.A2(n_19),
.B1(n_18),
.B2(n_22),
.C(n_7),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

OAI21xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_20),
.B(n_18),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_35),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_15),
.B1(n_33),
.B2(n_37),
.Y(n_38)
);


endmodule