module fake_netlist_607_1683_n_48 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_48);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_48;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_36;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_42;
wire n_33;
wire n_41;

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_10),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_5),
.B(n_12),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_14),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_R g29 ( 
.A(n_0),
.B(n_20),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_4),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_18),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_25),
.B(n_32),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_25),
.A2(n_3),
.B(n_1),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_27),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_31),
.B1(n_32),
.B2(n_25),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_R g37 ( 
.A(n_33),
.B(n_26),
.Y(n_37)
);

AOI21xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_29),
.B(n_24),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_28),
.Y(n_39)
);

OAI22xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_32),
.B1(n_30),
.B2(n_34),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_19),
.B1(n_16),
.B2(n_8),
.C1(n_7),
.C2(n_6),
.Y(n_41)
);

NAND3xp33_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_38),
.C(n_16),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_11),
.B(n_9),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_19),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_17),
.B1(n_15),
.B2(n_13),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_21),
.B1(n_22),
.B2(n_47),
.Y(n_48)
);


endmodule