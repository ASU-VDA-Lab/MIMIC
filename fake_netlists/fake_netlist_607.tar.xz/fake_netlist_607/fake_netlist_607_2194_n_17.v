module fake_netlist_607_2194_n_17 (n_0, n_4, n_1, n_2, n_3, n_17);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_17;

wire n_7;
wire n_11;
wire n_16;
wire n_8;
wire n_5;
wire n_15;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

CKINVDCx20_ASAP7_75t_R g5 ( 
.A(n_1),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_2),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

CKINVDCx6p67_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_6),
.B1(n_8),
.B2(n_5),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_SL g13 ( 
.A1(n_11),
.A2(n_9),
.B(n_3),
.C(n_0),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_0),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_3),
.B(n_1),
.Y(n_16)
);

OAI33xp33_ASAP7_75t_R g17 ( 
.A1(n_16),
.A2(n_4),
.A3(n_14),
.B1(n_6),
.B2(n_13),
.B3(n_15),
.Y(n_17)
);


endmodule