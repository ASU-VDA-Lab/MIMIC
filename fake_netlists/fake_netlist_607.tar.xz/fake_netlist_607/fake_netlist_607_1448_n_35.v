module fake_netlist_607_1448_n_35 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_17, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_35);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_17;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_35;

wire n_31;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

INVx1_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_1),
.B(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_5),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_11),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_14),
.B1(n_3),
.B2(n_2),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_21),
.A2(n_14),
.B1(n_6),
.B2(n_4),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_L g28 ( 
.A(n_18),
.B(n_10),
.C(n_7),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_29),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_23),
.Y(n_31)
);

AOI211xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_26),
.B(n_28),
.C(n_20),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_22),
.B1(n_25),
.B2(n_19),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_13),
.B1(n_16),
.B2(n_33),
.Y(n_35)
);


endmodule