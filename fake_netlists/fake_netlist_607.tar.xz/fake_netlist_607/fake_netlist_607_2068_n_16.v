module fake_netlist_607_2068_n_16 (n_1, n_2, n_3, n_0, n_16);

input n_1;
input n_2;
input n_3;
input n_0;

output n_16;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_15;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;

AO22x2_ASAP7_75t_L g4 ( 
.A1(n_0),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_4)
);

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_0),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_0),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

INVxp67_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI21xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_7),
.B(n_4),
.Y(n_11)
);

OAI22xp33_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_7),
.B1(n_5),
.B2(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

A2O1A1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B(n_1),
.C(n_0),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_2),
.B1(n_13),
.B2(n_8),
.C1(n_9),
.C2(n_5),
.Y(n_16)
);


endmodule