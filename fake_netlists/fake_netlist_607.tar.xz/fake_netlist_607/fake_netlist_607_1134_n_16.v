module fake_netlist_607_1134_n_16 (n_0, n_4, n_1, n_2, n_3, n_16);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_16;

wire n_7;
wire n_11;
wire n_8;
wire n_5;
wire n_15;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

BUFx3_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

OAI21xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_6),
.Y(n_11)
);

NOR4xp25_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_5),
.C(n_6),
.D(n_0),
.Y(n_12)
);

NAND4xp25_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_5),
.C(n_6),
.D(n_1),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_6),
.B1(n_3),
.B2(n_2),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_6),
.C(n_3),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_3),
.B1(n_4),
.B2(n_9),
.C1(n_14),
.C2(n_7),
.Y(n_16)
);


endmodule