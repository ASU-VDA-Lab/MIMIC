module fake_netlist_903_815_n_26 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_26);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_26;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_10;

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

BUFx12f_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

AO32x1_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_9),
.A3(n_10),
.B1(n_11),
.B2(n_13),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_9),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_SL g18 ( 
.A(n_15),
.B(n_1),
.C(n_0),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_17),
.B(n_14),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

OAI21xp33_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_15),
.B(n_0),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_15),
.C(n_3),
.D(n_2),
.Y(n_23)
);

NOR2x1_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_22),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_6),
.B1(n_7),
.B2(n_22),
.C1(n_21),
.C2(n_18),
.Y(n_26)
);


endmodule