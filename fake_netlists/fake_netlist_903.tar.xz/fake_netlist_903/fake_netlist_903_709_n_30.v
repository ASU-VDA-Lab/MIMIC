module fake_netlist_903_709_n_30 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_30);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_30;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_6),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_1),
.B(n_7),
.Y(n_14)
);

NOR2xp67_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_1),
.Y(n_15)
);

NOR2x1_ASAP7_75t_SL g16 ( 
.A(n_13),
.B(n_9),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_11),
.B(n_10),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_10),
.B1(n_12),
.B2(n_13),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_14),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_23)
);

OAI211xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_20),
.B(n_16),
.C(n_2),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_16),
.B1(n_3),
.B2(n_2),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

AOI22x1_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_7),
.B1(n_8),
.B2(n_26),
.C1(n_28),
.C2(n_23),
.Y(n_30)
);


endmodule