module fake_netlist_619_2369_n_57 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_17, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_57);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_17;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_57;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_18;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_52;
wire n_24;
wire n_51;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

BUFx8_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

OA21x2_ASAP7_75t_L g26 ( 
.A1(n_15),
.A2(n_11),
.B(n_10),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_15),
.B(n_5),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_21),
.B(n_2),
.Y(n_29)
);

BUFx8_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_20),
.B(n_2),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_12),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_SL g34 ( 
.A(n_29),
.B(n_22),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_19),
.B(n_25),
.Y(n_35)
);

NAND2x1p5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_26),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_34),
.Y(n_39)
);

NAND2x1p5_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_23),
.Y(n_40)
);

OA21x2_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_25),
.B(n_28),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_38),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_38),
.Y(n_43)
);

O2A1O1Ixp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_32),
.B(n_27),
.C(n_18),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

AOI332xp33_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_23),
.A3(n_28),
.B1(n_22),
.B2(n_17),
.B3(n_13),
.C1(n_12),
.C2(n_20),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_38),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

NOR3xp33_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_40),
.C(n_30),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

AOI211xp5_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_24),
.B(n_31),
.C(n_38),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

INVx3_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

OR5x1_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_41),
.C(n_24),
.D(n_1),
.E(n_4),
.Y(n_55)
);

AOI222xp33_ASAP7_75t_SL g56 ( 
.A1(n_55),
.A2(n_52),
.B1(n_54),
.B2(n_53),
.C1(n_9),
.C2(n_8),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_54),
.B1(n_55),
.B2(n_52),
.Y(n_57)
);


endmodule