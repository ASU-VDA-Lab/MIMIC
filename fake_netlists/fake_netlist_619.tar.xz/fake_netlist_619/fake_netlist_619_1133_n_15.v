module fake_netlist_619_1133_n_15 (n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_15);

input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_15;

wire n_7;
wire n_11;
wire n_9;
wire n_8;
wire n_14;
wire n_10;
wire n_13;
wire n_12;

BUFx2_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVxp67_ASAP7_75t_SL g12 ( 
.A(n_11),
.Y(n_12)
);

NAND2x1_ASAP7_75t_SL g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B(n_10),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_15)
);


endmodule