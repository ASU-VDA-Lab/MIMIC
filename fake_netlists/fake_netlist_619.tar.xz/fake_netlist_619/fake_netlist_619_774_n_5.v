module fake_netlist_619_774_n_5 (n_1, n_0, n_5);

input n_1;
input n_0;

output n_5;

wire n_4;
wire n_2;
wire n_3;

INVx2_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVxp67_ASAP7_75t_SL g3 ( 
.A(n_2),
.Y(n_3)
);

NOR3xp33_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_1),
.C(n_0),
.Y(n_4)
);

XNOR2x1_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);


endmodule