module fake_netlist_619_2062_n_28 (n_7, n_9, n_11, n_8, n_5, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_28);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_28;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_27;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_13),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_14),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_3),
.B(n_2),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_SL g21 ( 
.A1(n_18),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B1(n_15),
.B2(n_18),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_16),
.Y(n_23)
);

AO22x1_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_17),
.B1(n_1),
.B2(n_0),
.Y(n_24)
);

AOI321xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_20),
.A3(n_6),
.B1(n_4),
.B2(n_7),
.C(n_5),
.Y(n_25)
);

AO22x2_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_7),
.B1(n_6),
.B2(n_9),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_26),
.B1(n_12),
.B2(n_10),
.Y(n_28)
);


endmodule