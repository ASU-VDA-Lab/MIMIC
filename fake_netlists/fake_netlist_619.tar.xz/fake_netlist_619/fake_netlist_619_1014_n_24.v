module fake_netlist_619_1014_n_24 (n_7, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_24);

input n_7;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_24;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_5),
.B(n_2),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_1),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_1),
.B(n_5),
.Y(n_12)
);

NOR2x1_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_6),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_13),
.B(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_10),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_12),
.B2(n_6),
.C(n_7),
.Y(n_18)
);

AOI211xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_12),
.B(n_9),
.C(n_0),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_19),
.B(n_2),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_21),
.B1(n_9),
.B2(n_3),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_9),
.B1(n_4),
.B2(n_3),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_8),
.B1(n_9),
.B2(n_22),
.Y(n_24)
);


endmodule