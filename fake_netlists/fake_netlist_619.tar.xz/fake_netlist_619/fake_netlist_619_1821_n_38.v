module fake_netlist_619_1821_n_38 (n_7, n_9, n_11, n_8, n_5, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_38);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_38;

wire n_31;
wire n_15;
wire n_37;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_5),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_R g19 ( 
.A(n_3),
.B(n_10),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

AO22x1_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_14),
.B1(n_13),
.B2(n_1),
.Y(n_23)
);

INVx2_ASAP7_75t_SL g24 ( 
.A(n_22),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_13),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_16),
.B(n_20),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

AND2x6_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_24),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_28),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_26),
.Y(n_34)
);

OAI211xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_23),
.B(n_28),
.C(n_19),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_35),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_36),
.Y(n_37)
);

AOI322xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_4),
.A3(n_7),
.B1(n_9),
.B2(n_33),
.C1(n_18),
.C2(n_24),
.Y(n_38)
);


endmodule