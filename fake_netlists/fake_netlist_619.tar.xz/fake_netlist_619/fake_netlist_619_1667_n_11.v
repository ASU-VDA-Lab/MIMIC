module fake_netlist_619_1667_n_11 (n_1, n_0, n_11);

input n_1;
input n_0;

output n_11;

wire n_7;
wire n_9;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_2;
wire n_3;

BUFx4f_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

NAND2xp33_ASAP7_75t_SL g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

AOI21xp5_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_2),
.Y(n_7)
);

OAI21xp33_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_3),
.B(n_0),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B(n_6),
.C(n_0),
.Y(n_9)
);

NAND3x1_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_1),
.C(n_0),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_10),
.B(n_1),
.Y(n_11)
);


endmodule