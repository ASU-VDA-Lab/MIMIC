module fake_netlist_619_2150_n_18 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_18);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_18;

wire n_11;
wire n_15;
wire n_10;
wire n_16;
wire n_14;
wire n_17;
wire n_13;
wire n_12;

NAND2xp33_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_7),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_3),
.B(n_2),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_5),
.B(n_8),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B1(n_10),
.B2(n_12),
.C(n_0),
.Y(n_14)
);

OAI321xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.A3(n_10),
.B1(n_11),
.B2(n_2),
.C(n_1),
.Y(n_15)
);

AOI211xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_16)
);

AOI21xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B(n_4),
.Y(n_17)
);

AOI211xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_6),
.B(n_7),
.C(n_16),
.Y(n_18)
);


endmodule