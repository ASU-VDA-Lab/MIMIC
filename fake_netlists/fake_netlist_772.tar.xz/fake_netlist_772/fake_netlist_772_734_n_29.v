module fake_netlist_772_734_n_29 (n_1, n_0, n_5, n_3, n_2, n_4, n_29);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_29;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_28;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVxp33_ASAP7_75t_SL g6 ( 
.A(n_1),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_5),
.Y(n_9)
);

NOR2x1p5_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_2),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_9),
.B(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

INVxp67_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_0),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_7),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_8),
.Y(n_16)
);

BUFx3_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_12),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_14),
.Y(n_20)
);

AOI211xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_17),
.B(n_6),
.C(n_10),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_17),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_10),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

O2A1O1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_21),
.B(n_20),
.C(n_1),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_4),
.Y(n_26)
);

XNOR2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_4),
.Y(n_27)
);

AND2x2_ASAP7_75t_SL g28 ( 
.A(n_26),
.B(n_25),
.Y(n_28)
);

OR2x2_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_28),
.Y(n_29)
);


endmodule