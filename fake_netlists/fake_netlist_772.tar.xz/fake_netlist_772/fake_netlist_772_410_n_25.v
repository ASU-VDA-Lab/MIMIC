module fake_netlist_772_410_n_25 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_4, n_8, n_25);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_4;
input n_8;

output n_25;

wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

NOR3xp33_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_4),
.C(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_9),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_7),
.A2(n_1),
.B1(n_6),
.B2(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

AOI31xp67_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_10),
.A3(n_5),
.B(n_4),
.Y(n_19)
);

INVx4_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_13),
.B(n_17),
.C(n_15),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_13),
.B1(n_19),
.B2(n_5),
.C(n_6),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_7),
.Y(n_25)
);


endmodule