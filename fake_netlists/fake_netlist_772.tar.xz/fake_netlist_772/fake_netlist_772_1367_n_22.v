module fake_netlist_772_1367_n_22 (n_1, n_0, n_3, n_2, n_4, n_22);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_22;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_5;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_14;

INVx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

BUFx10_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_3),
.Y(n_7)
);

INVxp67_ASAP7_75t_SL g8 ( 
.A(n_1),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_5),
.B(n_8),
.Y(n_9)
);

A2O1A1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_8),
.B(n_6),
.C(n_0),
.Y(n_10)
);

AO21x1_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_12),
.Y(n_15)
);

OAI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B(n_10),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_14),
.B(n_13),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_SL g19 ( 
.A(n_17),
.B(n_14),
.C(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_13),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_18),
.B(n_21),
.Y(n_22)
);


endmodule