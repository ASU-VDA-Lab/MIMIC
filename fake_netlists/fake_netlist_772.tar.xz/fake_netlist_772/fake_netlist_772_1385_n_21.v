module fake_netlist_772_1385_n_21 (n_1, n_0, n_3, n_2, n_4, n_21);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_21;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_5;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_14;

BUFx3_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

BUFx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

AOI21x1_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_2),
.B(n_0),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_12),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

CKINVDCx16_ASAP7_75t_R g16 ( 
.A(n_14),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_13),
.B(n_9),
.C(n_8),
.Y(n_18)
);

INVx2_ASAP7_75t_SL g19 ( 
.A(n_18),
.Y(n_19)
);

NOR2x1p5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_16),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.B(n_13),
.Y(n_21)
);


endmodule