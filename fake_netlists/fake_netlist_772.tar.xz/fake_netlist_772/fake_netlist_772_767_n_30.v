module fake_netlist_772_767_n_30 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_30);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_30;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_21;
wire n_22;

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_5),
.Y(n_16)
);

NOR2xp67_ASAP7_75t_L g17 ( 
.A(n_2),
.B(n_8),
.Y(n_17)
);

CKINVDCx11_ASAP7_75t_R g18 ( 
.A(n_13),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_15),
.B1(n_13),
.B2(n_0),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_19),
.A2(n_3),
.B(n_1),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_21),
.B1(n_18),
.B2(n_16),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

AOI211xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_17),
.B(n_16),
.C(n_23),
.Y(n_27)
);

AND3x1_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_7),
.C(n_6),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_14),
.B1(n_12),
.B2(n_11),
.Y(n_30)
);


endmodule