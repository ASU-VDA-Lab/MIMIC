module fake_netlist_772_120_n_55 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_3, n_14, n_55);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_3;
input n_14;

output n_55;

wire n_37;
wire n_45;
wire n_44;
wire n_20;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_50;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_49;
wire n_48;
wire n_43;
wire n_38;
wire n_54;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_53;
wire n_41;
wire n_21;
wire n_51;
wire n_32;
wire n_22;

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_6),
.B(n_4),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_12),
.B(n_8),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_10),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_24),
.B(n_17),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_18),
.B1(n_17),
.B2(n_0),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_29),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_30),
.A2(n_20),
.B(n_19),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

OAI31xp33_ASAP7_75t_L g41 ( 
.A1(n_35),
.A2(n_29),
.A3(n_34),
.B(n_31),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_38),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_41),
.Y(n_43)
);

NOR4xp25_ASAP7_75t_SL g44 ( 
.A(n_40),
.B(n_23),
.C(n_22),
.D(n_21),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_44),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_27),
.B1(n_37),
.B2(n_28),
.C(n_18),
.Y(n_48)
);

NAND2xp33_ASAP7_75t_R g49 ( 
.A(n_47),
.B(n_3),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_SL g50 ( 
.A(n_46),
.B(n_9),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_11),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_49),
.Y(n_52)
);

XNOR2x1_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_13),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

OAI33xp33_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_16),
.A3(n_53),
.B1(n_25),
.B2(n_52),
.B3(n_24),
.Y(n_55)
);


endmodule