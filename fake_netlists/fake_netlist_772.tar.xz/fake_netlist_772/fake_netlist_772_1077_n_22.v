module fake_netlist_772_1077_n_22 (n_1, n_0, n_3, n_2, n_4, n_22);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_22;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_5;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_14;

NOR2xp33_ASAP7_75t_SL g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

OAI21xp33_ASAP7_75t_SL g6 ( 
.A1(n_4),
.A2(n_3),
.B(n_1),
.Y(n_6)
);

INVx5_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_0),
.Y(n_8)
);

NOR2x1_ASAP7_75t_SL g9 ( 
.A(n_7),
.B(n_1),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_1),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_SL g12 ( 
.A(n_8),
.Y(n_12)
);

INVxp67_ASAP7_75t_SL g13 ( 
.A(n_9),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_5),
.C(n_6),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_9),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_13),
.B(n_12),
.C(n_11),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_12),
.B(n_11),
.Y(n_17)
);

OAI211xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_11),
.B(n_7),
.C(n_2),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

XNOR2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_2),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_2),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_4),
.B1(n_21),
.B2(n_18),
.Y(n_22)
);


endmodule