module fake_netlist_772_23_n_11 (n_1, n_2, n_0, n_11);

input n_1;
input n_2;
input n_0;

output n_11;

wire n_7;
wire n_10;
wire n_5;
wire n_6;
wire n_3;
wire n_9;
wire n_4;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

BUFx6f_ASAP7_75t_SL g4 ( 
.A(n_0),
.Y(n_4)
);

NAND3x1_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.C(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2x1p5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_1),
.Y(n_8)
);

NOR4xp75_ASAP7_75t_SL g9 ( 
.A(n_8),
.B(n_0),
.C(n_2),
.D(n_5),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_2),
.Y(n_11)
);


endmodule