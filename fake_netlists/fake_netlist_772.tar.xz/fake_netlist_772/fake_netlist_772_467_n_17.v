module fake_netlist_772_467_n_17 (n_1, n_2, n_0, n_17);

input n_1;
input n_2;
input n_0;

output n_17;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_5;
wire n_16;
wire n_6;
wire n_14;
wire n_3;
wire n_8;
wire n_12;
wire n_13;
wire n_4;
wire n_9;

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

XNOR2xp5_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

INVx5_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);

OA21x2_ASAP7_75t_L g7 ( 
.A1(n_3),
.A2(n_4),
.B(n_5),
.Y(n_7)
);

AOI21xp33_ASAP7_75t_L g8 ( 
.A1(n_3),
.A2(n_4),
.B(n_5),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

OAI221xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_8),
.B1(n_7),
.B2(n_5),
.C(n_6),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_5),
.B1(n_6),
.B2(n_2),
.C1(n_1),
.C2(n_0),
.Y(n_13)
);

O2A1O1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_0),
.Y(n_15)
);

XNOR2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_2),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_5),
.B1(n_13),
.B2(n_16),
.Y(n_17)
);


endmodule