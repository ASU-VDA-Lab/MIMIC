module fake_netlist_772_1539_n_18 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_18);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_18;

wire n_15;
wire n_16;
wire n_11;
wire n_17;
wire n_12;
wire n_10;
wire n_13;
wire n_14;

AND2x2_ASAP7_75t_SL g10 ( 
.A(n_3),
.B(n_6),
.Y(n_10)
);

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_4),
.B(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_10),
.B1(n_7),
.B2(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

NAND4xp25_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_7),
.C(n_11),
.D(n_5),
.Y(n_17)
);

OA22x2_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_9),
.B1(n_8),
.B2(n_11),
.Y(n_18)
);


endmodule