module fake_netlist_772_1166_n_22 (n_1, n_0, n_5, n_3, n_2, n_4, n_22);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_22;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_14;

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

INVx3_ASAP7_75t_SL g9 ( 
.A(n_6),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_8),
.B1(n_1),
.B2(n_0),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVxp67_ASAP7_75t_SL g13 ( 
.A(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_0),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_13),
.B1(n_14),
.B2(n_12),
.C(n_1),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_SL g18 ( 
.A1(n_15),
.A2(n_14),
.B1(n_3),
.B2(n_1),
.C(n_2),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_SL g19 ( 
.A1(n_17),
.A2(n_16),
.B(n_15),
.C(n_2),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_16),
.Y(n_20)
);

AO22x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B(n_3),
.Y(n_22)
);


endmodule