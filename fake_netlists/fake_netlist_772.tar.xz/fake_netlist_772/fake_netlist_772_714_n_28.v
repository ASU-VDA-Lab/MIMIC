module fake_netlist_772_714_n_28 (n_1, n_0, n_5, n_3, n_2, n_4, n_28);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_28;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_5),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_1),
.Y(n_10)
);

AO31x2_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_1),
.A3(n_0),
.B(n_4),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_0),
.Y(n_12)
);

OA21x2_ASAP7_75t_L g13 ( 
.A1(n_7),
.A2(n_1),
.B(n_4),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_6),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_11),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_13),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_17),
.C(n_14),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_6),
.B1(n_16),
.B2(n_11),
.C(n_13),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_SL g23 ( 
.A1(n_20),
.A2(n_11),
.B(n_13),
.C(n_19),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_11),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_SL g25 ( 
.A(n_23),
.B(n_10),
.C(n_12),
.Y(n_25)
);

NAND2xp33_ASAP7_75t_SL g26 ( 
.A(n_22),
.B(n_18),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

OA21x2_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_25),
.B(n_26),
.Y(n_28)
);


endmodule