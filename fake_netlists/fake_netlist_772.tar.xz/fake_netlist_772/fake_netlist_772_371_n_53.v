module fake_netlist_772_371_n_53 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_53);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_53;

wire n_37;
wire n_45;
wire n_44;
wire n_47;
wire n_52;
wire n_36;
wire n_29;
wire n_50;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_48;
wire n_43;
wire n_49;
wire n_38;
wire n_28;
wire n_30;
wire n_41;
wire n_51;
wire n_32;

INVx1_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_8),
.B(n_17),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

AND2x2_ASAP7_75t_SL g27 ( 
.A(n_7),
.B(n_6),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_15),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_14),
.Y(n_29)
);

NOR2x1_ASAP7_75t_L g30 ( 
.A(n_16),
.B(n_13),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_9),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_R g32 ( 
.A(n_4),
.B(n_19),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_1),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_32),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_18),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_27),
.A2(n_19),
.B1(n_18),
.B2(n_0),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_33),
.B(n_30),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_31),
.B(n_24),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_29),
.B1(n_26),
.B2(n_25),
.Y(n_40)
);

AOI33xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_35),
.A3(n_34),
.B1(n_29),
.B2(n_26),
.B3(n_2),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_29),
.B(n_26),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_40),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_38),
.B1(n_5),
.B2(n_3),
.Y(n_47)
);

A2O1A1Ixp33_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_21),
.B(n_20),
.C(n_12),
.Y(n_48)
);

INVx1_ASAP7_75t_SL g49 ( 
.A(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_22),
.B1(n_23),
.B2(n_52),
.Y(n_53)
);


endmodule