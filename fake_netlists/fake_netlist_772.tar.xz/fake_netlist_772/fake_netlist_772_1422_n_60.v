module fake_netlist_772_1422_n_60 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_3, n_14, n_60);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_3;
input n_14;

output n_60;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_20;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_49;
wire n_48;
wire n_43;
wire n_56;
wire n_38;
wire n_54;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_19;
wire n_59;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;

INVx3_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_0),
.B(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_14),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_3),
.B(n_5),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_20),
.A2(n_17),
.B1(n_16),
.B2(n_5),
.Y(n_30)
);

INVx5_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

BUFx12f_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_19),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_22),
.B(n_16),
.Y(n_34)
);

NAND2x1p5_ASAP7_75t_L g35 ( 
.A(n_24),
.B(n_17),
.Y(n_35)
);

AND2x6_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_25),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_31),
.B(n_26),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_29),
.B(n_27),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_28),
.B1(n_23),
.B2(n_21),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OAI211xp5_ASAP7_75t_SL g41 ( 
.A1(n_39),
.A2(n_30),
.B(n_32),
.C(n_35),
.Y(n_41)
);

OAI21x1_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_21),
.B(n_31),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_36),
.B1(n_37),
.B2(n_31),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_36),
.Y(n_44)
);

NAND2x1p5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_37),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

AOI21xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_42),
.B(n_33),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_R g48 ( 
.A(n_43),
.B(n_36),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

AOI21xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_33),
.B(n_36),
.Y(n_50)
);

AOI211xp5_ASAP7_75t_SL g51 ( 
.A1(n_46),
.A2(n_33),
.B(n_18),
.C(n_2),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_18),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

OAI211xp5_ASAP7_75t_SL g55 ( 
.A1(n_51),
.A2(n_48),
.B(n_13),
.C(n_10),
.Y(n_55)
);

HB1xp67_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_50),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

AOI22xp33_ASAP7_75t_SL g60 ( 
.A1(n_59),
.A2(n_55),
.B1(n_57),
.B2(n_58),
.Y(n_60)
);


endmodule