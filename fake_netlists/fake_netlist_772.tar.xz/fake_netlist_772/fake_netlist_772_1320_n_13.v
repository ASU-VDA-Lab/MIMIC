module fake_netlist_772_1320_n_13 (n_1, n_0, n_3, n_2, n_4, n_13);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_13;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_9;
wire n_12;
wire n_8;

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_3),
.Y(n_5)
);

OR2x6_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_2),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B1(n_2),
.B2(n_0),
.Y(n_11)
);

OAI22x1_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_4),
.B1(n_3),
.B2(n_7),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.C1(n_0),
.C2(n_1),
.Y(n_13)
);


endmodule