module fake_netlist_772_9_n_25 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_25);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_25;

wire n_20;
wire n_17;
wire n_12;
wire n_24;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_9;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

BUFx3_ASAP7_75t_SL g9 ( 
.A(n_5),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_3),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_10),
.B1(n_12),
.B2(n_9),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_SL g14 ( 
.A(n_12),
.B(n_4),
.C(n_1),
.Y(n_14)
);

CKINVDCx16_ASAP7_75t_R g15 ( 
.A(n_13),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_9),
.Y(n_17)
);

O2A1O1Ixp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_16),
.B(n_8),
.C(n_2),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_16),
.Y(n_20)
);

AOI21xp33_ASAP7_75t_SL g21 ( 
.A1(n_18),
.A2(n_15),
.B(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_6),
.B1(n_7),
.B2(n_23),
.Y(n_25)
);


endmodule