module fake_netlist_772_1239_n_312 (n_0, n_20, n_6, n_29, n_17, n_2, n_12, n_1, n_25, n_31, n_5, n_27, n_34, n_33, n_24, n_26, n_18, n_13, n_15, n_11, n_16, n_23, n_28, n_4, n_9, n_8, n_30, n_7, n_10, n_19, n_21, n_3, n_32, n_22, n_14, n_312);

input n_0;
input n_20;
input n_6;
input n_29;
input n_17;
input n_2;
input n_12;
input n_1;
input n_25;
input n_31;
input n_5;
input n_27;
input n_34;
input n_33;
input n_24;
input n_26;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_28;
input n_4;
input n_9;
input n_8;
input n_30;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_32;
input n_22;
input n_14;

output n_312;

wire n_36;
wire n_35;
wire n_100;
wire n_101;
wire n_232;
wire n_186;
wire n_187;
wire n_107;
wire n_222;
wire n_184;
wire n_179;
wire n_308;
wire n_301;
wire n_297;
wire n_181;
wire n_51;
wire n_255;
wire n_207;
wire n_143;
wire n_201;
wire n_216;
wire n_117;
wire n_279;
wire n_204;
wire n_128;
wire n_88;
wire n_275;
wire n_290;
wire n_155;
wire n_126;
wire n_82;
wire n_129;
wire n_150;
wire n_176;
wire n_167;
wire n_303;
wire n_234;
wire n_209;
wire n_294;
wire n_215;
wire n_56;
wire n_300;
wire n_236;
wire n_78;
wire n_161;
wire n_259;
wire n_149;
wire n_159;
wire n_240;
wire n_173;
wire n_141;
wire n_211;
wire n_154;
wire n_193;
wire n_113;
wire n_256;
wire n_239;
wire n_250;
wire n_191;
wire n_87;
wire n_120;
wire n_115;
wire n_264;
wire n_242;
wire n_221;
wire n_116;
wire n_254;
wire n_140;
wire n_287;
wire n_65;
wire n_283;
wire n_278;
wire n_73;
wire n_293;
wire n_271;
wire n_68;
wire n_273;
wire n_231;
wire n_311;
wire n_127;
wire n_166;
wire n_284;
wire n_53;
wire n_74;
wire n_146;
wire n_220;
wire n_182;
wire n_178;
wire n_168;
wire n_246;
wire n_280;
wire n_102;
wire n_302;
wire n_224;
wire n_62;
wire n_270;
wire n_169;
wire n_245;
wire n_175;
wire n_148;
wire n_202;
wire n_195;
wire n_217;
wire n_267;
wire n_152;
wire n_86;
wire n_266;
wire n_177;
wire n_298;
wire n_70;
wire n_125;
wire n_262;
wire n_69;
wire n_233;
wire n_137;
wire n_212;
wire n_145;
wire n_133;
wire n_194;
wire n_109;
wire n_157;
wire n_203;
wire n_260;
wire n_111;
wire n_307;
wire n_170;
wire n_47;
wire n_200;
wire n_288;
wire n_163;
wire n_130;
wire n_160;
wire n_97;
wire n_94;
wire n_39;
wire n_309;
wire n_136;
wire n_135;
wire n_296;
wire n_114;
wire n_223;
wire n_38;
wire n_99;
wire n_192;
wire n_60;
wire n_93;
wire n_247;
wire n_131;
wire n_252;
wire n_41;
wire n_299;
wire n_37;
wire n_63;
wire n_244;
wire n_291;
wire n_119;
wire n_42;
wire n_105;
wire n_225;
wire n_219;
wire n_132;
wire n_210;
wire n_213;
wire n_59;
wire n_104;
wire n_85;
wire n_106;
wire n_241;
wire n_253;
wire n_289;
wire n_268;
wire n_185;
wire n_249;
wire n_174;
wire n_199;
wire n_229;
wire n_214;
wire n_84;
wire n_103;
wire n_147;
wire n_164;
wire n_123;
wire n_198;
wire n_64;
wire n_188;
wire n_251;
wire n_92;
wire n_285;
wire n_295;
wire n_71;
wire n_258;
wire n_49;
wire n_142;
wire n_190;
wire n_110;
wire n_272;
wire n_118;
wire n_277;
wire n_205;
wire n_261;
wire n_50;
wire n_58;
wire n_108;
wire n_66;
wire n_263;
wire n_95;
wire n_98;
wire n_57;
wire n_134;
wire n_237;
wire n_238;
wire n_72;
wire n_183;
wire n_55;
wire n_281;
wire n_153;
wire n_40;
wire n_124;
wire n_48;
wire n_43;
wire n_158;
wire n_276;
wire n_67;
wire n_54;
wire n_257;
wire n_197;
wire n_227;
wire n_79;
wire n_89;
wire n_45;
wire n_83;
wire n_75;
wire n_165;
wire n_121;
wire n_96;
wire n_235;
wire n_180;
wire n_76;
wire n_171;
wire n_230;
wire n_156;
wire n_90;
wire n_139;
wire n_286;
wire n_151;
wire n_196;
wire n_228;
wire n_189;
wire n_292;
wire n_91;
wire n_305;
wire n_265;
wire n_122;
wire n_61;
wire n_218;
wire n_112;
wire n_310;
wire n_172;
wire n_44;
wire n_52;
wire n_77;
wire n_138;
wire n_248;
wire n_206;
wire n_282;
wire n_162;
wire n_274;
wire n_243;
wire n_46;
wire n_144;
wire n_81;
wire n_269;
wire n_304;
wire n_80;
wire n_208;
wire n_306;
wire n_226;

BUFx3_ASAP7_75t_L g35 ( 
.A(n_8),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_23),
.Y(n_36)
);

CKINVDCx14_ASAP7_75t_R g37 ( 
.A(n_5),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_2),
.Y(n_38)
);

CKINVDCx20_ASAP7_75t_R g39 ( 
.A(n_34),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_29),
.Y(n_40)
);

INVxp67_ASAP7_75t_SL g41 ( 
.A(n_10),
.Y(n_41)
);

INVxp67_ASAP7_75t_SL g42 ( 
.A(n_14),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_14),
.Y(n_43)
);

INVxp67_ASAP7_75t_L g44 ( 
.A(n_30),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_33),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_11),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_13),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_11),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_16),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_18),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_28),
.Y(n_51)
);

INVxp33_ASAP7_75t_SL g52 ( 
.A(n_19),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_12),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_9),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_12),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_38),
.B(n_0),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_37),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_38),
.Y(n_58)
);

BUFx10_ASAP7_75t_L g59 ( 
.A(n_50),
.Y(n_59)
);

BUFx6f_ASAP7_75t_L g60 ( 
.A(n_38),
.Y(n_60)
);

CKINVDCx5p33_ASAP7_75t_R g61 ( 
.A(n_37),
.Y(n_61)
);

CKINVDCx20_ASAP7_75t_R g62 ( 
.A(n_39),
.Y(n_62)
);

XNOR2xp5_ASAP7_75t_L g63 ( 
.A(n_53),
.B(n_0),
.Y(n_63)
);

CKINVDCx5p33_ASAP7_75t_R g64 ( 
.A(n_39),
.Y(n_64)
);

CKINVDCx5p33_ASAP7_75t_R g65 ( 
.A(n_52),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_38),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_38),
.Y(n_67)
);

INVxp67_ASAP7_75t_L g68 ( 
.A(n_46),
.Y(n_68)
);

CKINVDCx5p33_ASAP7_75t_R g69 ( 
.A(n_52),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_35),
.Y(n_70)
);

CKINVDCx5p33_ASAP7_75t_R g71 ( 
.A(n_53),
.Y(n_71)
);

CKINVDCx5p33_ASAP7_75t_R g72 ( 
.A(n_48),
.Y(n_72)
);

INVx2_ASAP7_75t_L g73 ( 
.A(n_35),
.Y(n_73)
);

INVx4_ASAP7_75t_L g74 ( 
.A(n_35),
.Y(n_74)
);

NAND2xp5_ASAP7_75t_L g75 ( 
.A(n_68),
.B(n_44),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_58),
.Y(n_76)
);

CKINVDCx5p33_ASAP7_75t_R g77 ( 
.A(n_64),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_58),
.Y(n_78)
);

INVx2_ASAP7_75t_L g79 ( 
.A(n_60),
.Y(n_79)
);

INVxp67_ASAP7_75t_SL g80 ( 
.A(n_66),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_59),
.B(n_44),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_66),
.Y(n_82)
);

BUFx2_ASAP7_75t_L g83 ( 
.A(n_71),
.Y(n_83)
);

INVx4_ASAP7_75t_L g84 ( 
.A(n_74),
.Y(n_84)
);

NAND2xp5_ASAP7_75t_L g85 ( 
.A(n_59),
.B(n_36),
.Y(n_85)
);

INVxp67_ASAP7_75t_L g86 ( 
.A(n_72),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_67),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_67),
.Y(n_88)
);

NAND2x1p5_ASAP7_75t_L g89 ( 
.A(n_74),
.B(n_36),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_60),
.Y(n_90)
);

NAND2xp5_ASAP7_75t_L g91 ( 
.A(n_59),
.B(n_40),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_60),
.Y(n_92)
);

OAI22xp33_ASAP7_75t_L g93 ( 
.A1(n_57),
.A2(n_42),
.B1(n_41),
.B2(n_46),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_60),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_60),
.Y(n_95)
);

INVx2_ASAP7_75t_L g96 ( 
.A(n_60),
.Y(n_96)
);

NOR2xp33_ASAP7_75t_L g97 ( 
.A(n_65),
.B(n_40),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_59),
.B(n_45),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_74),
.B(n_61),
.Y(n_99)
);

HB1xp67_ASAP7_75t_L g100 ( 
.A(n_63),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_70),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_70),
.Y(n_102)
);

AOI21x1_ASAP7_75t_L g103 ( 
.A1(n_76),
.A2(n_56),
.B(n_73),
.Y(n_103)
);

NOR2xp33_ASAP7_75t_L g104 ( 
.A(n_81),
.B(n_69),
.Y(n_104)
);

AOI21xp5_ASAP7_75t_L g105 ( 
.A1(n_80),
.A2(n_74),
.B(n_73),
.Y(n_105)
);

INVx3_ASAP7_75t_L g106 ( 
.A(n_89),
.Y(n_106)
);

AOI21xp5_ASAP7_75t_L g107 ( 
.A1(n_99),
.A2(n_49),
.B(n_45),
.Y(n_107)
);

AOI21xp5_ASAP7_75t_L g108 ( 
.A1(n_98),
.A2(n_51),
.B(n_49),
.Y(n_108)
);

BUFx6f_ASAP7_75t_L g109 ( 
.A(n_89),
.Y(n_109)
);

AOI22xp5_ASAP7_75t_L g110 ( 
.A1(n_97),
.A2(n_93),
.B1(n_75),
.B2(n_85),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_91),
.B(n_51),
.Y(n_111)
);

AOI21xp5_ASAP7_75t_L g112 ( 
.A1(n_84),
.A2(n_43),
.B(n_47),
.Y(n_112)
);

OAI22xp5_ASAP7_75t_L g113 ( 
.A1(n_83),
.A2(n_62),
.B1(n_42),
.B2(n_41),
.Y(n_113)
);

A2O1A1Ixp33_ASAP7_75t_L g114 ( 
.A1(n_76),
.A2(n_43),
.B(n_54),
.C(n_47),
.Y(n_114)
);

AOI21xp5_ASAP7_75t_L g115 ( 
.A1(n_84),
.A2(n_43),
.B(n_54),
.Y(n_115)
);

AOI21xp5_ASAP7_75t_L g116 ( 
.A1(n_84),
.A2(n_55),
.B(n_63),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_78),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_78),
.Y(n_118)
);

NOR3xp33_ASAP7_75t_SL g119 ( 
.A(n_77),
.B(n_55),
.C(n_1),
.Y(n_119)
);

AOI21xp5_ASAP7_75t_L g120 ( 
.A1(n_82),
.A2(n_20),
.B(n_17),
.Y(n_120)
);

OAI21xp5_ASAP7_75t_L g121 ( 
.A1(n_82),
.A2(n_22),
.B(n_21),
.Y(n_121)
);

INVx2_ASAP7_75t_L g122 ( 
.A(n_101),
.Y(n_122)
);

NAND2xp5_ASAP7_75t_SL g123 ( 
.A(n_89),
.B(n_24),
.Y(n_123)
);

A2O1A1Ixp33_ASAP7_75t_L g124 ( 
.A1(n_87),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_124)
);

BUFx2_ASAP7_75t_L g125 ( 
.A(n_83),
.Y(n_125)
);

AOI21x1_ASAP7_75t_L g126 ( 
.A1(n_87),
.A2(n_26),
.B(n_25),
.Y(n_126)
);

AND2x4_ASAP7_75t_L g127 ( 
.A(n_86),
.B(n_3),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_88),
.Y(n_128)
);

AOI22xp5_ASAP7_75t_L g129 ( 
.A1(n_88),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_129)
);

AND2x4_ASAP7_75t_L g130 ( 
.A(n_101),
.B(n_4),
.Y(n_130)
);

NAND2xp5_ASAP7_75t_L g131 ( 
.A(n_84),
.B(n_6),
.Y(n_131)
);

AOI21xp5_ASAP7_75t_L g132 ( 
.A1(n_102),
.A2(n_31),
.B(n_27),
.Y(n_132)
);

INVx2_ASAP7_75t_L g133 ( 
.A(n_117),
.Y(n_133)
);

BUFx3_ASAP7_75t_L g134 ( 
.A(n_109),
.Y(n_134)
);

OAI22xp33_ASAP7_75t_L g135 ( 
.A1(n_129),
.A2(n_102),
.B1(n_100),
.B2(n_94),
.Y(n_135)
);

INVx2_ASAP7_75t_L g136 ( 
.A(n_118),
.Y(n_136)
);

NAND2xp5_ASAP7_75t_SL g137 ( 
.A(n_109),
.B(n_90),
.Y(n_137)
);

NAND2xp5_ASAP7_75t_L g138 ( 
.A(n_128),
.B(n_90),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_122),
.Y(n_139)
);

NOR2xp67_ASAP7_75t_L g140 ( 
.A(n_106),
.B(n_32),
.Y(n_140)
);

AND2x6_ASAP7_75t_L g141 ( 
.A(n_109),
.B(n_92),
.Y(n_141)
);

INVx1_ASAP7_75t_L g142 ( 
.A(n_130),
.Y(n_142)
);

BUFx3_ASAP7_75t_L g143 ( 
.A(n_106),
.Y(n_143)
);

OA21x2_ASAP7_75t_L g144 ( 
.A1(n_121),
.A2(n_120),
.B(n_132),
.Y(n_144)
);

AOI22x1_ASAP7_75t_L g145 ( 
.A1(n_120),
.A2(n_96),
.B1(n_94),
.B2(n_79),
.Y(n_145)
);

OAI21x1_ASAP7_75t_L g146 ( 
.A1(n_126),
.A2(n_96),
.B(n_94),
.Y(n_146)
);

INVx8_ASAP7_75t_L g147 ( 
.A(n_130),
.Y(n_147)
);

AO32x2_ASAP7_75t_L g148 ( 
.A1(n_113),
.A2(n_96),
.A3(n_9),
.B1(n_7),
.B2(n_8),
.Y(n_148)
);

AOI22xp33_ASAP7_75t_L g149 ( 
.A1(n_111),
.A2(n_95),
.B1(n_92),
.B2(n_79),
.Y(n_149)
);

CKINVDCx5p33_ASAP7_75t_R g150 ( 
.A(n_125),
.Y(n_150)
);

OAI222xp33_ASAP7_75t_L g151 ( 
.A1(n_108),
.A2(n_10),
.B1(n_7),
.B2(n_13),
.C1(n_15),
.C2(n_95),
.Y(n_151)
);

AND2x4_ASAP7_75t_L g152 ( 
.A(n_127),
.B(n_15),
.Y(n_152)
);

INVx2_ASAP7_75t_L g153 ( 
.A(n_103),
.Y(n_153)
);

AO21x2_ASAP7_75t_L g154 ( 
.A1(n_132),
.A2(n_124),
.B(n_123),
.Y(n_154)
);

AOI21xp5_ASAP7_75t_L g155 ( 
.A1(n_105),
.A2(n_107),
.B(n_108),
.Y(n_155)
);

NAND2xp33_ASAP7_75t_R g156 ( 
.A(n_150),
.B(n_119),
.Y(n_156)
);

OR2x2_ASAP7_75t_L g157 ( 
.A(n_147),
.B(n_110),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_133),
.Y(n_158)
);

INVx2_ASAP7_75t_L g159 ( 
.A(n_133),
.Y(n_159)
);

AO21x2_ASAP7_75t_L g160 ( 
.A1(n_146),
.A2(n_131),
.B(n_114),
.Y(n_160)
);

HB1xp67_ASAP7_75t_L g161 ( 
.A(n_147),
.Y(n_161)
);

AND2x2_ASAP7_75t_L g162 ( 
.A(n_133),
.B(n_136),
.Y(n_162)
);

AND2x2_ASAP7_75t_L g163 ( 
.A(n_136),
.B(n_127),
.Y(n_163)
);

NOR2xp33_ASAP7_75t_R g164 ( 
.A(n_147),
.B(n_104),
.Y(n_164)
);

AND2x2_ASAP7_75t_L g165 ( 
.A(n_136),
.B(n_116),
.Y(n_165)
);

OR2x2_ASAP7_75t_L g166 ( 
.A(n_147),
.B(n_152),
.Y(n_166)
);

OAI22xp33_ASAP7_75t_L g167 ( 
.A1(n_147),
.A2(n_115),
.B1(n_112),
.B2(n_105),
.Y(n_167)
);

INVx2_ASAP7_75t_L g168 ( 
.A(n_153),
.Y(n_168)
);

BUFx8_ASAP7_75t_L g169 ( 
.A(n_141),
.Y(n_169)
);

CKINVDCx16_ASAP7_75t_R g170 ( 
.A(n_152),
.Y(n_170)
);

AND2x2_ASAP7_75t_L g171 ( 
.A(n_170),
.B(n_152),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_158),
.Y(n_172)
);

HB1xp67_ASAP7_75t_L g173 ( 
.A(n_162),
.Y(n_173)
);

BUFx2_ASAP7_75t_L g174 ( 
.A(n_170),
.Y(n_174)
);

INVxp67_ASAP7_75t_L g175 ( 
.A(n_162),
.Y(n_175)
);

CKINVDCx20_ASAP7_75t_R g176 ( 
.A(n_169),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_158),
.Y(n_177)
);

NOR2xp33_ASAP7_75t_L g178 ( 
.A(n_157),
.B(n_135),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_159),
.Y(n_179)
);

AOI22xp33_ASAP7_75t_L g180 ( 
.A1(n_157),
.A2(n_152),
.B1(n_147),
.B2(n_135),
.Y(n_180)
);

NAND2xp5_ASAP7_75t_L g181 ( 
.A(n_165),
.B(n_147),
.Y(n_181)
);

INVx2_ASAP7_75t_L g182 ( 
.A(n_159),
.Y(n_182)
);

INVx3_ASAP7_75t_L g183 ( 
.A(n_169),
.Y(n_183)
);

INVx2_ASAP7_75t_L g184 ( 
.A(n_182),
.Y(n_184)
);

INVx2_ASAP7_75t_L g185 ( 
.A(n_182),
.Y(n_185)
);

AND2x2_ASAP7_75t_L g186 ( 
.A(n_173),
.B(n_159),
.Y(n_186)
);

OR2x2_ASAP7_75t_L g187 ( 
.A(n_173),
.B(n_168),
.Y(n_187)
);

AND2x4_ASAP7_75t_L g188 ( 
.A(n_183),
.B(n_168),
.Y(n_188)
);

NAND2xp5_ASAP7_75t_L g189 ( 
.A(n_178),
.B(n_152),
.Y(n_189)
);

INVx6_ASAP7_75t_L g190 ( 
.A(n_171),
.Y(n_190)
);

NAND2xp5_ASAP7_75t_L g191 ( 
.A(n_175),
.B(n_163),
.Y(n_191)
);

NAND2xp5_ASAP7_75t_L g192 ( 
.A(n_175),
.B(n_163),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_172),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_172),
.Y(n_194)
);

OR2x2_ASAP7_75t_L g195 ( 
.A(n_177),
.B(n_168),
.Y(n_195)
);

INVx1_ASAP7_75t_L g196 ( 
.A(n_177),
.Y(n_196)
);

INVx4_ASAP7_75t_L g197 ( 
.A(n_183),
.Y(n_197)
);

AND2x2_ASAP7_75t_L g198 ( 
.A(n_179),
.B(n_165),
.Y(n_198)
);

INVx1_ASAP7_75t_L g199 ( 
.A(n_179),
.Y(n_199)
);

NAND2xp5_ASAP7_75t_L g200 ( 
.A(n_193),
.B(n_182),
.Y(n_200)
);

INVx1_ASAP7_75t_L g201 ( 
.A(n_193),
.Y(n_201)
);

INVx2_ASAP7_75t_L g202 ( 
.A(n_184),
.Y(n_202)
);

AND2x2_ASAP7_75t_L g203 ( 
.A(n_198),
.B(n_181),
.Y(n_203)
);

INVx1_ASAP7_75t_L g204 ( 
.A(n_194),
.Y(n_204)
);

INVx1_ASAP7_75t_L g205 ( 
.A(n_194),
.Y(n_205)
);

INVxp67_ASAP7_75t_L g206 ( 
.A(n_199),
.Y(n_206)
);

AND2x4_ASAP7_75t_L g207 ( 
.A(n_188),
.B(n_183),
.Y(n_207)
);

NOR2xp33_ASAP7_75t_SL g208 ( 
.A(n_197),
.B(n_169),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_196),
.Y(n_209)
);

AND2x2_ASAP7_75t_L g210 ( 
.A(n_198),
.B(n_181),
.Y(n_210)
);

AND2x2_ASAP7_75t_L g211 ( 
.A(n_186),
.B(n_171),
.Y(n_211)
);

INVx1_ASAP7_75t_SL g212 ( 
.A(n_187),
.Y(n_212)
);

INVx1_ASAP7_75t_L g213 ( 
.A(n_196),
.Y(n_213)
);

INVx2_ASAP7_75t_SL g214 ( 
.A(n_197),
.Y(n_214)
);

AND2x2_ASAP7_75t_L g215 ( 
.A(n_186),
.B(n_171),
.Y(n_215)
);

INVx2_ASAP7_75t_L g216 ( 
.A(n_184),
.Y(n_216)
);

BUFx2_ASAP7_75t_L g217 ( 
.A(n_197),
.Y(n_217)
);

NOR2xp33_ASAP7_75t_R g218 ( 
.A(n_199),
.B(n_176),
.Y(n_218)
);

NAND2xp5_ASAP7_75t_L g219 ( 
.A(n_187),
.B(n_180),
.Y(n_219)
);

AND2x2_ASAP7_75t_L g220 ( 
.A(n_185),
.B(n_148),
.Y(n_220)
);

INVx1_ASAP7_75t_L g221 ( 
.A(n_195),
.Y(n_221)
);

OAI21xp5_ASAP7_75t_SL g222 ( 
.A1(n_217),
.A2(n_183),
.B(n_151),
.Y(n_222)
);

OAI221xp5_ASAP7_75t_L g223 ( 
.A1(n_208),
.A2(n_156),
.B1(n_189),
.B2(n_174),
.C(n_191),
.Y(n_223)
);

O2A1O1Ixp5_ASAP7_75t_L g224 ( 
.A1(n_207),
.A2(n_188),
.B(n_151),
.C(n_185),
.Y(n_224)
);

NOR2x1_ASAP7_75t_L g225 ( 
.A(n_217),
.B(n_195),
.Y(n_225)
);

AOI22xp5_ASAP7_75t_L g226 ( 
.A1(n_208),
.A2(n_190),
.B1(n_174),
.B2(n_192),
.Y(n_226)
);

OAI22xp5_ASAP7_75t_L g227 ( 
.A1(n_214),
.A2(n_190),
.B1(n_166),
.B2(n_188),
.Y(n_227)
);

OAI22xp33_ASAP7_75t_L g228 ( 
.A1(n_214),
.A2(n_190),
.B1(n_166),
.B2(n_188),
.Y(n_228)
);

NAND2xp5_ASAP7_75t_L g229 ( 
.A(n_203),
.B(n_190),
.Y(n_229)
);

INVx1_ASAP7_75t_L g230 ( 
.A(n_201),
.Y(n_230)
);

INVx1_ASAP7_75t_L g231 ( 
.A(n_201),
.Y(n_231)
);

OAI22xp5_ASAP7_75t_L g232 ( 
.A1(n_206),
.A2(n_142),
.B1(n_161),
.B2(n_153),
.Y(n_232)
);

INVx1_ASAP7_75t_L g233 ( 
.A(n_204),
.Y(n_233)
);

AOI22xp33_ASAP7_75t_L g234 ( 
.A1(n_203),
.A2(n_142),
.B1(n_154),
.B2(n_164),
.Y(n_234)
);

AOI32xp33_ASAP7_75t_L g235 ( 
.A1(n_210),
.A2(n_161),
.A3(n_167),
.B1(n_143),
.B2(n_139),
.Y(n_235)
);

OAI22xp5_ASAP7_75t_L g236 ( 
.A1(n_206),
.A2(n_153),
.B1(n_139),
.B2(n_143),
.Y(n_236)
);

OAI22xp5_ASAP7_75t_SL g237 ( 
.A1(n_218),
.A2(n_169),
.B1(n_144),
.B2(n_148),
.Y(n_237)
);

OR2x2_ASAP7_75t_L g238 ( 
.A(n_212),
.B(n_160),
.Y(n_238)
);

OAI31xp33_ASAP7_75t_L g239 ( 
.A1(n_207),
.A2(n_143),
.A3(n_148),
.B(n_134),
.Y(n_239)
);

INVx1_ASAP7_75t_L g240 ( 
.A(n_204),
.Y(n_240)
);

INVx1_ASAP7_75t_L g241 ( 
.A(n_205),
.Y(n_241)
);

INVx1_ASAP7_75t_L g242 ( 
.A(n_205),
.Y(n_242)
);

INVx1_ASAP7_75t_L g243 ( 
.A(n_209),
.Y(n_243)
);

INVx1_ASAP7_75t_L g244 ( 
.A(n_209),
.Y(n_244)
);

OR2x2_ASAP7_75t_L g245 ( 
.A(n_212),
.B(n_160),
.Y(n_245)
);

AOI221xp5_ASAP7_75t_L g246 ( 
.A1(n_213),
.A2(n_155),
.B1(n_149),
.B2(n_154),
.C(n_160),
.Y(n_246)
);

NAND2xp5_ASAP7_75t_L g247 ( 
.A(n_210),
.B(n_160),
.Y(n_247)
);

INVx1_ASAP7_75t_L g248 ( 
.A(n_230),
.Y(n_248)
);

OR2x2_ASAP7_75t_L g249 ( 
.A(n_247),
.B(n_245),
.Y(n_249)
);

NAND2xp5_ASAP7_75t_L g250 ( 
.A(n_231),
.B(n_221),
.Y(n_250)
);

NAND2xp5_ASAP7_75t_L g251 ( 
.A(n_233),
.B(n_221),
.Y(n_251)
);

INVx2_ASAP7_75t_L g252 ( 
.A(n_240),
.Y(n_252)
);

NAND2xp5_ASAP7_75t_L g253 ( 
.A(n_241),
.B(n_242),
.Y(n_253)
);

INVx1_ASAP7_75t_L g254 ( 
.A(n_243),
.Y(n_254)
);

NAND2xp5_ASAP7_75t_L g255 ( 
.A(n_244),
.B(n_213),
.Y(n_255)
);

INVx1_ASAP7_75t_L g256 ( 
.A(n_225),
.Y(n_256)
);

OR2x2_ASAP7_75t_L g257 ( 
.A(n_238),
.B(n_202),
.Y(n_257)
);

AND2x2_ASAP7_75t_L g258 ( 
.A(n_229),
.B(n_202),
.Y(n_258)
);

NOR2x1_ASAP7_75t_L g259 ( 
.A(n_222),
.B(n_207),
.Y(n_259)
);

INVx1_ASAP7_75t_L g260 ( 
.A(n_228),
.Y(n_260)
);

HB1xp67_ASAP7_75t_L g261 ( 
.A(n_227),
.Y(n_261)
);

AOI21xp5_ASAP7_75t_L g262 ( 
.A1(n_237),
.A2(n_200),
.B(n_207),
.Y(n_262)
);

OR2x2_ASAP7_75t_L g263 ( 
.A(n_228),
.B(n_202),
.Y(n_263)
);

AND2x2_ASAP7_75t_L g264 ( 
.A(n_234),
.B(n_216),
.Y(n_264)
);

INVx1_ASAP7_75t_L g265 ( 
.A(n_246),
.Y(n_265)
);

AOI21xp5_ASAP7_75t_L g266 ( 
.A1(n_224),
.A2(n_200),
.B(n_216),
.Y(n_266)
);

INVx1_ASAP7_75t_L g267 ( 
.A(n_232),
.Y(n_267)
);

OR2x2_ASAP7_75t_L g268 ( 
.A(n_234),
.B(n_216),
.Y(n_268)
);

NAND2xp5_ASAP7_75t_L g269 ( 
.A(n_235),
.B(n_211),
.Y(n_269)
);

NAND2xp5_ASAP7_75t_L g270 ( 
.A(n_226),
.B(n_211),
.Y(n_270)
);

AOI21xp5_ASAP7_75t_L g271 ( 
.A1(n_259),
.A2(n_239),
.B(n_224),
.Y(n_271)
);

AO221x1_ASAP7_75t_L g272 ( 
.A1(n_256),
.A2(n_236),
.B1(n_223),
.B2(n_148),
.C(n_220),
.Y(n_272)
);

AOI211xp5_ASAP7_75t_L g273 ( 
.A1(n_261),
.A2(n_219),
.B(n_215),
.C(n_220),
.Y(n_273)
);

AOI221xp5_ASAP7_75t_L g274 ( 
.A1(n_269),
.A2(n_219),
.B1(n_215),
.B2(n_155),
.C(n_154),
.Y(n_274)
);

INVx1_ASAP7_75t_L g275 ( 
.A(n_248),
.Y(n_275)
);

AOI211xp5_ASAP7_75t_L g276 ( 
.A1(n_265),
.A2(n_140),
.B(n_148),
.C(n_134),
.Y(n_276)
);

NOR2xp33_ASAP7_75t_L g277 ( 
.A(n_270),
.B(n_144),
.Y(n_277)
);

AOI221x1_ASAP7_75t_SL g278 ( 
.A1(n_260),
.A2(n_148),
.B1(n_140),
.B2(n_138),
.C(n_154),
.Y(n_278)
);

NOR2xp33_ASAP7_75t_SL g279 ( 
.A(n_262),
.B(n_134),
.Y(n_279)
);

A2O1A1Ixp33_ASAP7_75t_L g280 ( 
.A1(n_267),
.A2(n_148),
.B(n_146),
.C(n_138),
.Y(n_280)
);

OAI21xp33_ASAP7_75t_L g281 ( 
.A1(n_265),
.A2(n_249),
.B(n_258),
.Y(n_281)
);

A2O1A1Ixp33_ASAP7_75t_L g282 ( 
.A1(n_263),
.A2(n_148),
.B(n_146),
.C(n_149),
.Y(n_282)
);

NOR2xp33_ASAP7_75t_R g283 ( 
.A(n_258),
.B(n_141),
.Y(n_283)
);

OAI211xp5_ASAP7_75t_L g284 ( 
.A1(n_268),
.A2(n_145),
.B(n_144),
.C(n_137),
.Y(n_284)
);

OAI211xp5_ASAP7_75t_L g285 ( 
.A1(n_268),
.A2(n_145),
.B(n_144),
.C(n_137),
.Y(n_285)
);

A2O1A1Ixp33_ASAP7_75t_L g286 ( 
.A1(n_263),
.A2(n_154),
.B(n_144),
.C(n_141),
.Y(n_286)
);

OAI221xp5_ASAP7_75t_L g287 ( 
.A1(n_250),
.A2(n_141),
.B1(n_251),
.B2(n_249),
.C(n_254),
.Y(n_287)
);

O2A1O1Ixp33_ASAP7_75t_L g288 ( 
.A1(n_271),
.A2(n_253),
.B(n_255),
.C(n_266),
.Y(n_288)
);

OR2x2_ASAP7_75t_L g289 ( 
.A(n_281),
.B(n_257),
.Y(n_289)
);

INVx2_ASAP7_75t_L g290 ( 
.A(n_275),
.Y(n_290)
);

NOR3xp33_ASAP7_75t_L g291 ( 
.A(n_274),
.B(n_252),
.C(n_264),
.Y(n_291)
);

OAI22xp33_ASAP7_75t_SL g292 ( 
.A1(n_279),
.A2(n_252),
.B1(n_257),
.B2(n_264),
.Y(n_292)
);

INVx1_ASAP7_75t_L g293 ( 
.A(n_277),
.Y(n_293)
);

INVx1_ASAP7_75t_L g294 ( 
.A(n_277),
.Y(n_294)
);

AND2x2_ASAP7_75t_L g295 ( 
.A(n_273),
.B(n_141),
.Y(n_295)
);

OAI221xp5_ASAP7_75t_L g296 ( 
.A1(n_287),
.A2(n_141),
.B1(n_278),
.B2(n_276),
.C(n_286),
.Y(n_296)
);

OAI321xp33_ASAP7_75t_L g297 ( 
.A1(n_272),
.A2(n_141),
.A3(n_284),
.B1(n_285),
.B2(n_282),
.C(n_280),
.Y(n_297)
);

BUFx2_ASAP7_75t_L g298 ( 
.A(n_289),
.Y(n_298)
);

CKINVDCx16_ASAP7_75t_R g299 ( 
.A(n_295),
.Y(n_299)
);

INVx1_ASAP7_75t_L g300 ( 
.A(n_290),
.Y(n_300)
);

CKINVDCx20_ASAP7_75t_R g301 ( 
.A(n_293),
.Y(n_301)
);

CKINVDCx5p33_ASAP7_75t_R g302 ( 
.A(n_290),
.Y(n_302)
);

INVx1_ASAP7_75t_L g303 ( 
.A(n_294),
.Y(n_303)
);

OAI211xp5_ASAP7_75t_L g304 ( 
.A1(n_298),
.A2(n_288),
.B(n_296),
.C(n_291),
.Y(n_304)
);

OAI21xp5_ASAP7_75t_L g305 ( 
.A1(n_301),
.A2(n_297),
.B(n_292),
.Y(n_305)
);

OAI22x1_ASAP7_75t_L g306 ( 
.A1(n_302),
.A2(n_303),
.B1(n_289),
.B2(n_301),
.Y(n_306)
);

AOI31xp33_ASAP7_75t_SL g307 ( 
.A1(n_299),
.A2(n_283),
.A3(n_295),
.B(n_141),
.Y(n_307)
);

HB1xp67_ASAP7_75t_L g308 ( 
.A(n_306),
.Y(n_308)
);

AND2x2_ASAP7_75t_L g309 ( 
.A(n_305),
.B(n_302),
.Y(n_309)
);

INVx1_ASAP7_75t_L g310 ( 
.A(n_308),
.Y(n_310)
);

AOI22xp5_ASAP7_75t_SL g311 ( 
.A1(n_310),
.A2(n_309),
.B1(n_304),
.B2(n_307),
.Y(n_311)
);

A2O1A1Ixp33_ASAP7_75t_SL g312 ( 
.A1(n_311),
.A2(n_141),
.B(n_300),
.C(n_310),
.Y(n_312)
);


endmodule