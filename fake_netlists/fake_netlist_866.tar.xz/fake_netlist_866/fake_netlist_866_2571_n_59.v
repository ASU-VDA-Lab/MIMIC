module fake_netlist_866_2571_n_59 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_28, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_59);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_28;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_59;

wire n_49;
wire n_48;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_39;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_43;
wire n_37;
wire n_54;
wire n_42;
wire n_33;
wire n_56;
wire n_29;
wire n_30;
wire n_55;
wire n_52;
wire n_38;
wire n_35;
wire n_45;
wire n_46;
wire n_51;

OAI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_25),
.A2(n_17),
.B1(n_6),
.B2(n_3),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_22),
.B(n_26),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_1),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_10),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_14),
.B(n_16),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_7),
.B(n_20),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_0),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_21),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_4),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_24),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_28),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_34),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_29),
.A2(n_28),
.B1(n_5),
.B2(n_2),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

AND2x4_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_41),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_37),
.B(n_36),
.Y(n_45)
);

INVx4_ASAP7_75t_L g46 ( 
.A(n_40),
.Y(n_46)
);

INVx3_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

OAI221xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_42),
.B1(n_29),
.B2(n_31),
.C(n_32),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_50),
.B(n_44),
.Y(n_51)
);

OAI211xp5_ASAP7_75t_SL g52 ( 
.A1(n_49),
.A2(n_48),
.B(n_38),
.C(n_30),
.Y(n_52)
);

AOI211xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_44),
.B(n_35),
.C(n_33),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_54)
);

NAND3xp33_ASAP7_75t_SL g55 ( 
.A(n_53),
.B(n_13),
.C(n_12),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

INVxp67_ASAP7_75t_SL g57 ( 
.A(n_56),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

AOI322xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_15),
.A3(n_18),
.B1(n_19),
.B2(n_23),
.C1(n_27),
.C2(n_58),
.Y(n_59)
);


endmodule