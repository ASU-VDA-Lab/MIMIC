module fake_netlist_866_1866_n_10 (n_2, n_0, n_1, n_10);

input n_2;
input n_0;
input n_1;

output n_10;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_8;

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

OAI21xp33_ASAP7_75t_SL g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

AOI31xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_4),
.A3(n_1),
.B(n_0),
.Y(n_7)
);

NOR3xp33_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_4),
.C(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_8),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_2),
.B(n_6),
.Y(n_10)
);


endmodule