module fake_netlist_866_3847_n_9 (n_2, n_0, n_1, n_9);

input n_2;
input n_0;
input n_1;

output n_9;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVxp67_ASAP7_75t_SL g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AND4x1_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_2),
.C(n_5),
.D(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);


endmodule