module fake_netlist_866_1691_n_17 (n_4, n_2, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_2),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

AOI21xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_1),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_1),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_7),
.B(n_8),
.C(n_1),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_3),
.B(n_2),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_10),
.B1(n_3),
.B2(n_2),
.Y(n_13)
);

XOR2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_2),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_3),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_4),
.C(n_3),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_11),
.B2(n_15),
.Y(n_17)
);


endmodule