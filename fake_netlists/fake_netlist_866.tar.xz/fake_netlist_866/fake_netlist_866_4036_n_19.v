module fake_netlist_866_4036_n_19 (n_2, n_0, n_3, n_1, n_19);

input n_2;
input n_0;
input n_3;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_4;
wire n_7;
wire n_9;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_5;
wire n_11;
wire n_8;

OAI22xp5_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_0),
.B1(n_3),
.B2(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AO21x1_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_4),
.B(n_7),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_1),
.B(n_5),
.Y(n_10)
);

NOR2x1_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_7),
.Y(n_11)
);

NOR2x1_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

OAI21xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_8),
.B(n_10),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_13),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_9),
.B1(n_6),
.B2(n_10),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_6),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_1),
.B(n_17),
.Y(n_19)
);


endmodule