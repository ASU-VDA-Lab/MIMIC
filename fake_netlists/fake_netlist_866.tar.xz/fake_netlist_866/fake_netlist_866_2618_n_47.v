module fake_netlist_866_2618_n_47 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_47);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_47;

wire n_25;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_9),
.A2(n_6),
.B1(n_1),
.B2(n_3),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_14),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_16),
.B(n_8),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_20),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

NAND2x1p5_ASAP7_75t_L g27 ( 
.A(n_10),
.B(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_16),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_18),
.Y(n_30)
);

BUFx12f_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

A2O1A1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_26),
.B(n_23),
.C(n_24),
.Y(n_32)
);

NAND2x1p5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_26),
.Y(n_33)
);

OR2x2_ASAP7_75t_SL g34 ( 
.A(n_33),
.B(n_31),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_29),
.Y(n_37)
);

AOI21xp33_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_21),
.B(n_27),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_29),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_39),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_27),
.B(n_22),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND4xp75_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_19),
.C(n_5),
.D(n_4),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_19),
.B1(n_11),
.B2(n_7),
.Y(n_45)
);

AOI31xp67_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_17),
.A3(n_15),
.B(n_13),
.Y(n_46)
);

XOR2xp5_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_44),
.Y(n_47)
);


endmodule