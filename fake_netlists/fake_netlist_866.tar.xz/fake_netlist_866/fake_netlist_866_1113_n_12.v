module fake_netlist_866_1113_n_12 (n_2, n_0, n_3, n_1, n_12);

input n_2;
input n_0;
input n_3;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_9;
wire n_11;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_3),
.Y(n_4)
);

NAND2xp33_ASAP7_75t_R g5 ( 
.A(n_1),
.B(n_0),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_5),
.Y(n_6)
);

INVxp67_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_4),
.B(n_5),
.Y(n_9)
);

NOR2xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_10),
.Y(n_11)
);

AOI31xp67_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_1),
.A3(n_2),
.B(n_5),
.Y(n_12)
);


endmodule