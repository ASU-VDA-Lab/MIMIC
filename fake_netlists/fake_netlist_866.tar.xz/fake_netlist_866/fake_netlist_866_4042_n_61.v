module fake_netlist_866_4042_n_61 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_61);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_61;

wire n_49;
wire n_48;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_43;
wire n_37;
wire n_54;
wire n_42;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVxp67_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_12),
.B(n_23),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_26),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_9),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_0),
.B(n_3),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_1),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_4),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_7),
.B(n_8),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_6),
.B(n_22),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_21),
.Y(n_36)
);

BUFx3_ASAP7_75t_L g37 ( 
.A(n_16),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_24),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_33),
.B(n_23),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_33),
.B(n_24),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_28),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_32),
.B(n_25),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_38),
.B1(n_28),
.B2(n_27),
.C(n_36),
.Y(n_43)
);

NAND2x1p5_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_29),
.Y(n_44)
);

OAI21x1_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_35),
.B(n_34),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_42),
.B1(n_29),
.B2(n_37),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_44),
.Y(n_49)
);

OAI321xp33_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_30),
.A3(n_35),
.B1(n_34),
.B2(n_31),
.C(n_25),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

CKINVDCx20_ASAP7_75t_R g52 ( 
.A(n_51),
.Y(n_52)
);

OAI32xp33_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_30),
.A3(n_11),
.B1(n_2),
.B2(n_5),
.Y(n_53)
);

OAI321xp33_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_30),
.A3(n_15),
.B1(n_13),
.B2(n_17),
.C(n_14),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

XNOR2x1_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_18),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

AOI22xp5_ASAP7_75t_L g60 ( 
.A1(n_58),
.A2(n_57),
.B1(n_56),
.B2(n_19),
.Y(n_60)
);

XNOR2xp5_ASAP7_75t_L g61 ( 
.A(n_60),
.B(n_59),
.Y(n_61)
);


endmodule