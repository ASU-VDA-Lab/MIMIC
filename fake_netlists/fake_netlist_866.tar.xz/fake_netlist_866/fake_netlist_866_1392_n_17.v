module fake_netlist_866_1392_n_17 (n_2, n_0, n_3, n_1, n_17);

input n_2;
input n_0;
input n_3;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx4_ASAP7_75t_SL g5 ( 
.A(n_3),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

OA21x2_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_5),
.B(n_6),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OR2x6_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_6),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_6),
.B1(n_5),
.B2(n_0),
.C(n_1),
.Y(n_10)
);

OAI21xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B(n_5),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_7),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

INVxp67_ASAP7_75t_SL g14 ( 
.A(n_12),
.Y(n_14)
);

XNOR2x1_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_0),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_7),
.B1(n_1),
.B2(n_0),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_1),
.B1(n_3),
.B2(n_16),
.Y(n_17)
);


endmodule