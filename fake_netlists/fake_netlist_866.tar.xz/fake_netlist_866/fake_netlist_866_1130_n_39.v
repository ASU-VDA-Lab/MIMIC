module fake_netlist_866_1130_n_39 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_39);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_39;

wire n_25;
wire n_20;
wire n_36;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

INVx2_ASAP7_75t_SL g16 ( 
.A(n_11),
.Y(n_16)
);

AND2x6_ASAP7_75t_L g17 ( 
.A(n_4),
.B(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_18),
.A2(n_20),
.B1(n_17),
.B2(n_16),
.Y(n_27)
);

NAND2x1p5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_23),
.Y(n_28)
);

OA21x2_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_24),
.B(n_21),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_25),
.Y(n_30)
);

NAND2x1p5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_29),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_29),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_14),
.B1(n_17),
.B2(n_2),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_34)
);

AND4x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_12),
.C(n_10),
.D(n_9),
.Y(n_35)
);

INVx2_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

XNOR2xp5_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_36),
.Y(n_39)
);


endmodule