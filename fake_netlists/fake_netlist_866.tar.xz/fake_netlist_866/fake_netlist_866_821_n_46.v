module fake_netlist_866_821_n_46 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_46);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_46;

wire n_25;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

AND2x2_ASAP7_75t_SL g24 ( 
.A(n_7),
.B(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_1),
.B(n_18),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_17),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_0),
.Y(n_29)
);

O2A1O1Ixp5_ASAP7_75t_L g30 ( 
.A1(n_26),
.A2(n_5),
.B(n_3),
.C(n_2),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_16),
.Y(n_32)
);

AND2x6_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_26),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_29),
.B(n_25),
.Y(n_34)
);

INVxp67_ASAP7_75t_SL g35 ( 
.A(n_34),
.Y(n_35)
);

AOI222xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_31),
.B1(n_32),
.B2(n_24),
.C1(n_27),
.C2(n_29),
.Y(n_36)
);

INVxp67_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_24),
.Y(n_38)
);

NOR4xp25_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_23),
.C(n_22),
.D(n_33),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_16),
.Y(n_40)
);

OAI221xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_38),
.B1(n_19),
.B2(n_17),
.C(n_18),
.Y(n_41)
);

NOR4xp25_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_21),
.C(n_19),
.D(n_9),
.Y(n_42)
);

NAND4xp25_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_21),
.C(n_12),
.D(n_11),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_13),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_44),
.B1(n_20),
.B2(n_14),
.Y(n_46)
);


endmodule