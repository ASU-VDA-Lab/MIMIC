module fake_netlist_866_960_n_190 (n_48, n_49, n_25, n_20, n_15, n_13, n_2, n_36, n_47, n_17, n_57, n_14, n_50, n_22, n_41, n_4, n_7, n_23, n_34, n_40, n_28, n_39, n_44, n_9, n_53, n_31, n_32, n_26, n_24, n_43, n_37, n_19, n_42, n_3, n_54, n_33, n_12, n_0, n_56, n_29, n_6, n_30, n_18, n_10, n_55, n_16, n_21, n_5, n_35, n_38, n_11, n_52, n_27, n_1, n_45, n_8, n_46, n_51, n_190);

input n_48;
input n_49;
input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_36;
input n_47;
input n_17;
input n_57;
input n_14;
input n_50;
input n_22;
input n_41;
input n_4;
input n_7;
input n_23;
input n_34;
input n_40;
input n_28;
input n_39;
input n_44;
input n_9;
input n_53;
input n_31;
input n_32;
input n_26;
input n_24;
input n_43;
input n_37;
input n_19;
input n_42;
input n_3;
input n_54;
input n_33;
input n_12;
input n_0;
input n_56;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_55;
input n_16;
input n_21;
input n_5;
input n_35;
input n_38;
input n_11;
input n_52;
input n_27;
input n_1;
input n_45;
input n_8;
input n_46;
input n_51;

output n_190;

wire n_132;
wire n_97;
wire n_81;
wire n_182;
wire n_114;
wire n_130;
wire n_80;
wire n_166;
wire n_123;
wire n_173;
wire n_156;
wire n_126;
wire n_154;
wire n_78;
wire n_153;
wire n_187;
wire n_87;
wire n_167;
wire n_122;
wire n_96;
wire n_95;
wire n_59;
wire n_63;
wire n_94;
wire n_74;
wire n_64;
wire n_79;
wire n_177;
wire n_110;
wire n_61;
wire n_184;
wire n_86;
wire n_108;
wire n_163;
wire n_162;
wire n_158;
wire n_135;
wire n_171;
wire n_118;
wire n_127;
wire n_90;
wire n_76;
wire n_189;
wire n_160;
wire n_107;
wire n_125;
wire n_99;
wire n_151;
wire n_178;
wire n_72;
wire n_121;
wire n_73;
wire n_120;
wire n_103;
wire n_155;
wire n_145;
wire n_175;
wire n_185;
wire n_143;
wire n_170;
wire n_77;
wire n_161;
wire n_138;
wire n_137;
wire n_179;
wire n_116;
wire n_136;
wire n_102;
wire n_119;
wire n_89;
wire n_152;
wire n_70;
wire n_172;
wire n_131;
wire n_128;
wire n_133;
wire n_139;
wire n_142;
wire n_115;
wire n_109;
wire n_62;
wire n_144;
wire n_117;
wire n_84;
wire n_58;
wire n_68;
wire n_183;
wire n_146;
wire n_104;
wire n_105;
wire n_168;
wire n_106;
wire n_149;
wire n_188;
wire n_85;
wire n_164;
wire n_65;
wire n_159;
wire n_75;
wire n_140;
wire n_176;
wire n_67;
wire n_66;
wire n_101;
wire n_98;
wire n_91;
wire n_112;
wire n_129;
wire n_181;
wire n_157;
wire n_83;
wire n_60;
wire n_111;
wire n_169;
wire n_180;
wire n_93;
wire n_174;
wire n_150;
wire n_71;
wire n_92;
wire n_82;
wire n_186;
wire n_100;
wire n_69;
wire n_165;
wire n_88;
wire n_124;
wire n_113;
wire n_147;
wire n_141;
wire n_134;
wire n_148;

INVx1_ASAP7_75t_L g58 ( 
.A(n_40),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_46),
.Y(n_59)
);

BUFx2_ASAP7_75t_L g60 ( 
.A(n_38),
.Y(n_60)
);

CKINVDCx20_ASAP7_75t_R g61 ( 
.A(n_22),
.Y(n_61)
);

BUFx6f_ASAP7_75t_L g62 ( 
.A(n_37),
.Y(n_62)
);

CKINVDCx5p33_ASAP7_75t_R g63 ( 
.A(n_54),
.Y(n_63)
);

CKINVDCx14_ASAP7_75t_R g64 ( 
.A(n_49),
.Y(n_64)
);

INVxp67_ASAP7_75t_SL g65 ( 
.A(n_39),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_52),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_56),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_14),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_11),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_30),
.Y(n_70)
);

INVxp67_ASAP7_75t_SL g71 ( 
.A(n_1),
.Y(n_71)
);

INVxp33_ASAP7_75t_SL g72 ( 
.A(n_18),
.Y(n_72)
);

CKINVDCx16_ASAP7_75t_R g73 ( 
.A(n_28),
.Y(n_73)
);

CKINVDCx5p33_ASAP7_75t_R g74 ( 
.A(n_24),
.Y(n_74)
);

BUFx3_ASAP7_75t_L g75 ( 
.A(n_8),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_32),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_4),
.Y(n_77)
);

CKINVDCx5p33_ASAP7_75t_R g78 ( 
.A(n_55),
.Y(n_78)
);

INVxp67_ASAP7_75t_SL g79 ( 
.A(n_7),
.Y(n_79)
);

INVxp67_ASAP7_75t_SL g80 ( 
.A(n_47),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_45),
.Y(n_81)
);

CKINVDCx16_ASAP7_75t_R g82 ( 
.A(n_50),
.Y(n_82)
);

INVxp67_ASAP7_75t_SL g83 ( 
.A(n_48),
.Y(n_83)
);

CKINVDCx16_ASAP7_75t_R g84 ( 
.A(n_57),
.Y(n_84)
);

HB1xp67_ASAP7_75t_L g85 ( 
.A(n_10),
.Y(n_85)
);

CKINVDCx20_ASAP7_75t_R g86 ( 
.A(n_53),
.Y(n_86)
);

INVxp33_ASAP7_75t_SL g87 ( 
.A(n_51),
.Y(n_87)
);

HB1xp67_ASAP7_75t_L g88 ( 
.A(n_4),
.Y(n_88)
);

INVx2_ASAP7_75t_L g89 ( 
.A(n_33),
.Y(n_89)
);

CKINVDCx5p33_ASAP7_75t_R g90 ( 
.A(n_73),
.Y(n_90)
);

CKINVDCx5p33_ASAP7_75t_R g91 ( 
.A(n_82),
.Y(n_91)
);

CKINVDCx20_ASAP7_75t_R g92 ( 
.A(n_61),
.Y(n_92)
);

CKINVDCx5p33_ASAP7_75t_R g93 ( 
.A(n_84),
.Y(n_93)
);

BUFx10_ASAP7_75t_L g94 ( 
.A(n_85),
.Y(n_94)
);

CKINVDCx5p33_ASAP7_75t_R g95 ( 
.A(n_61),
.Y(n_95)
);

INVx2_ASAP7_75t_L g96 ( 
.A(n_68),
.Y(n_96)
);

NAND2x1p5_ASAP7_75t_L g97 ( 
.A(n_96),
.B(n_60),
.Y(n_97)
);

INVx1_ASAP7_75t_L g98 ( 
.A(n_96),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_94),
.B(n_64),
.Y(n_99)
);

AND2x6_ASAP7_75t_L g100 ( 
.A(n_94),
.B(n_75),
.Y(n_100)
);

NAND2xp5_ASAP7_75t_L g101 ( 
.A(n_99),
.B(n_90),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_98),
.Y(n_102)
);

AOI21xp5_ASAP7_75t_L g103 ( 
.A1(n_97),
.A2(n_89),
.B(n_68),
.Y(n_103)
);

OAI21x1_ASAP7_75t_L g104 ( 
.A1(n_103),
.A2(n_89),
.B(n_58),
.Y(n_104)
);

BUFx6f_ASAP7_75t_SL g105 ( 
.A(n_102),
.Y(n_105)
);

O2A1O1Ixp33_ASAP7_75t_SL g106 ( 
.A1(n_101),
.A2(n_67),
.B(n_66),
.C(n_59),
.Y(n_106)
);

NAND2xp5_ASAP7_75t_L g107 ( 
.A(n_103),
.B(n_100),
.Y(n_107)
);

INVxp33_ASAP7_75t_L g108 ( 
.A(n_107),
.Y(n_108)
);

HB1xp67_ASAP7_75t_L g109 ( 
.A(n_105),
.Y(n_109)
);

HB1xp67_ASAP7_75t_L g110 ( 
.A(n_105),
.Y(n_110)
);

AND2x2_ASAP7_75t_L g111 ( 
.A(n_104),
.B(n_95),
.Y(n_111)
);

AND2x2_ASAP7_75t_L g112 ( 
.A(n_106),
.B(n_92),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_105),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_108),
.Y(n_114)
);

HB1xp67_ASAP7_75t_L g115 ( 
.A(n_109),
.Y(n_115)
);

INVxp67_ASAP7_75t_SL g116 ( 
.A(n_109),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_113),
.Y(n_117)
);

AOI211xp5_ASAP7_75t_L g118 ( 
.A1(n_112),
.A2(n_88),
.B(n_93),
.C(n_91),
.Y(n_118)
);

INVx3_ASAP7_75t_L g119 ( 
.A(n_111),
.Y(n_119)
);

AOI22xp33_ASAP7_75t_L g120 ( 
.A1(n_110),
.A2(n_100),
.B1(n_72),
.B2(n_86),
.Y(n_120)
);

OA21x2_ASAP7_75t_L g121 ( 
.A1(n_111),
.A2(n_70),
.B(n_69),
.Y(n_121)
);

OR2x2_ASAP7_75t_L g122 ( 
.A(n_112),
.B(n_71),
.Y(n_122)
);

INVx1_ASAP7_75t_SL g123 ( 
.A(n_109),
.Y(n_123)
);

OA21x2_ASAP7_75t_L g124 ( 
.A1(n_111),
.A2(n_81),
.B(n_76),
.Y(n_124)
);

AND2x2_ASAP7_75t_L g125 ( 
.A(n_122),
.B(n_77),
.Y(n_125)
);

AND2x2_ASAP7_75t_L g126 ( 
.A(n_122),
.B(n_86),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_117),
.Y(n_127)
);

HB1xp67_ASAP7_75t_L g128 ( 
.A(n_119),
.Y(n_128)
);

OR2x2_ASAP7_75t_L g129 ( 
.A(n_123),
.B(n_0),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_114),
.Y(n_130)
);

OR2x2_ASAP7_75t_L g131 ( 
.A(n_116),
.B(n_0),
.Y(n_131)
);

AND2x2_ASAP7_75t_L g132 ( 
.A(n_119),
.B(n_64),
.Y(n_132)
);

INVx4_ASAP7_75t_L g133 ( 
.A(n_119),
.Y(n_133)
);

AND2x2_ASAP7_75t_L g134 ( 
.A(n_124),
.B(n_75),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_114),
.Y(n_135)
);

AND2x2_ASAP7_75t_L g136 ( 
.A(n_115),
.B(n_1),
.Y(n_136)
);

NAND2xp5_ASAP7_75t_L g137 ( 
.A(n_121),
.B(n_72),
.Y(n_137)
);

INVx2_ASAP7_75t_L g138 ( 
.A(n_121),
.Y(n_138)
);

INVx2_ASAP7_75t_L g139 ( 
.A(n_121),
.Y(n_139)
);

AND2x2_ASAP7_75t_L g140 ( 
.A(n_124),
.B(n_2),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_124),
.Y(n_141)
);

AND2x2_ASAP7_75t_L g142 ( 
.A(n_125),
.B(n_2),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_127),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_130),
.Y(n_144)
);

AND2x2_ASAP7_75t_L g145 ( 
.A(n_136),
.B(n_3),
.Y(n_145)
);

INVx1_ASAP7_75t_L g146 ( 
.A(n_135),
.Y(n_146)
);

HB1xp67_ASAP7_75t_L g147 ( 
.A(n_128),
.Y(n_147)
);

OAI33xp33_ASAP7_75t_L g148 ( 
.A1(n_131),
.A2(n_3),
.A3(n_78),
.B1(n_63),
.B2(n_74),
.B3(n_118),
.Y(n_148)
);

INVxp67_ASAP7_75t_L g149 ( 
.A(n_128),
.Y(n_149)
);

INVx1_ASAP7_75t_SL g150 ( 
.A(n_129),
.Y(n_150)
);

OR2x2_ASAP7_75t_L g151 ( 
.A(n_126),
.B(n_120),
.Y(n_151)
);

INVx2_ASAP7_75t_L g152 ( 
.A(n_138),
.Y(n_152)
);

NAND2xp5_ASAP7_75t_L g153 ( 
.A(n_140),
.B(n_100),
.Y(n_153)
);

NAND2xp5_ASAP7_75t_SL g154 ( 
.A(n_133),
.B(n_87),
.Y(n_154)
);

HB1xp67_ASAP7_75t_L g155 ( 
.A(n_133),
.Y(n_155)
);

OR2x2_ASAP7_75t_L g156 ( 
.A(n_133),
.B(n_138),
.Y(n_156)
);

AO21x2_ASAP7_75t_L g157 ( 
.A1(n_141),
.A2(n_79),
.B(n_65),
.Y(n_157)
);

INVxp67_ASAP7_75t_SL g158 ( 
.A(n_155),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_143),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_144),
.Y(n_160)
);

INVx1_ASAP7_75t_L g161 ( 
.A(n_146),
.Y(n_161)
);

AOI22xp5_ASAP7_75t_L g162 ( 
.A1(n_148),
.A2(n_132),
.B1(n_137),
.B2(n_134),
.Y(n_162)
);

NAND3xp33_ASAP7_75t_L g163 ( 
.A(n_151),
.B(n_137),
.C(n_134),
.Y(n_163)
);

AND2x2_ASAP7_75t_L g164 ( 
.A(n_150),
.B(n_139),
.Y(n_164)
);

AOI22xp33_ASAP7_75t_L g165 ( 
.A1(n_148),
.A2(n_139),
.B1(n_62),
.B2(n_80),
.Y(n_165)
);

NOR4xp25_ASAP7_75t_L g166 ( 
.A(n_142),
.B(n_83),
.C(n_62),
.D(n_5),
.Y(n_166)
);

INVx2_ASAP7_75t_L g167 ( 
.A(n_152),
.Y(n_167)
);

NOR2xp33_ASAP7_75t_L g168 ( 
.A(n_145),
.B(n_62),
.Y(n_168)
);

NOR3xp33_ASAP7_75t_SL g169 ( 
.A(n_168),
.B(n_153),
.C(n_154),
.Y(n_169)
);

INVx1_ASAP7_75t_L g170 ( 
.A(n_159),
.Y(n_170)
);

INVx3_ASAP7_75t_L g171 ( 
.A(n_167),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_160),
.Y(n_172)
);

OAI22xp5_ASAP7_75t_L g173 ( 
.A1(n_163),
.A2(n_149),
.B1(n_156),
.B2(n_147),
.Y(n_173)
);

OAI221xp5_ASAP7_75t_L g174 ( 
.A1(n_166),
.A2(n_149),
.B1(n_147),
.B2(n_62),
.C(n_157),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_161),
.Y(n_175)
);

NAND3xp33_ASAP7_75t_L g176 ( 
.A(n_174),
.B(n_165),
.C(n_164),
.Y(n_176)
);

AOI221xp5_ASAP7_75t_L g177 ( 
.A1(n_173),
.A2(n_166),
.B1(n_158),
.B2(n_162),
.C(n_157),
.Y(n_177)
);

NOR2xp33_ASAP7_75t_L g178 ( 
.A(n_170),
.B(n_6),
.Y(n_178)
);

NOR4xp25_ASAP7_75t_L g179 ( 
.A(n_172),
.B(n_13),
.C(n_12),
.D(n_9),
.Y(n_179)
);

AOI221xp5_ASAP7_75t_L g180 ( 
.A1(n_175),
.A2(n_16),
.B1(n_15),
.B2(n_17),
.C(n_19),
.Y(n_180)
);

OAI22xp5_ASAP7_75t_L g181 ( 
.A1(n_177),
.A2(n_171),
.B1(n_169),
.B2(n_20),
.Y(n_181)
);

NAND2xp5_ASAP7_75t_L g182 ( 
.A(n_176),
.B(n_171),
.Y(n_182)
);

NAND2xp5_ASAP7_75t_L g183 ( 
.A(n_178),
.B(n_21),
.Y(n_183)
);

OAI211xp5_ASAP7_75t_SL g184 ( 
.A1(n_182),
.A2(n_180),
.B(n_179),
.C(n_23),
.Y(n_184)
);

OAI211xp5_ASAP7_75t_SL g185 ( 
.A1(n_181),
.A2(n_27),
.B(n_26),
.C(n_25),
.Y(n_185)
);

BUFx2_ASAP7_75t_L g186 ( 
.A(n_184),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_186),
.Y(n_187)
);

NAND4xp25_ASAP7_75t_SL g188 ( 
.A(n_187),
.B(n_183),
.C(n_185),
.D(n_29),
.Y(n_188)
);

AOI222xp33_ASAP7_75t_L g189 ( 
.A1(n_188),
.A2(n_34),
.B1(n_31),
.B2(n_35),
.C1(n_41),
.C2(n_36),
.Y(n_189)
);

NAND4xp25_ASAP7_75t_L g190 ( 
.A(n_189),
.B(n_44),
.C(n_43),
.D(n_42),
.Y(n_190)
);


endmodule