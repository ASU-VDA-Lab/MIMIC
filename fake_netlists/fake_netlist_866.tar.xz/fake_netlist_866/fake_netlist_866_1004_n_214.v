module fake_netlist_866_1004_n_214 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_28, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_29, n_6, n_30, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_214);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_28;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_214;

wire n_49;
wire n_132;
wire n_97;
wire n_194;
wire n_81;
wire n_182;
wire n_114;
wire n_130;
wire n_80;
wire n_166;
wire n_123;
wire n_173;
wire n_156;
wire n_126;
wire n_154;
wire n_78;
wire n_153;
wire n_187;
wire n_195;
wire n_210;
wire n_87;
wire n_167;
wire n_122;
wire n_54;
wire n_96;
wire n_95;
wire n_56;
wire n_59;
wire n_63;
wire n_94;
wire n_74;
wire n_64;
wire n_79;
wire n_177;
wire n_110;
wire n_61;
wire n_184;
wire n_86;
wire n_43;
wire n_45;
wire n_108;
wire n_192;
wire n_48;
wire n_162;
wire n_163;
wire n_209;
wire n_196;
wire n_158;
wire n_135;
wire n_171;
wire n_47;
wire n_118;
wire n_127;
wire n_202;
wire n_90;
wire n_213;
wire n_76;
wire n_189;
wire n_160;
wire n_107;
wire n_125;
wire n_99;
wire n_151;
wire n_178;
wire n_72;
wire n_121;
wire n_73;
wire n_211;
wire n_37;
wire n_207;
wire n_42;
wire n_120;
wire n_103;
wire n_155;
wire n_145;
wire n_200;
wire n_175;
wire n_185;
wire n_52;
wire n_199;
wire n_143;
wire n_170;
wire n_77;
wire n_161;
wire n_190;
wire n_138;
wire n_51;
wire n_57;
wire n_137;
wire n_116;
wire n_136;
wire n_179;
wire n_102;
wire n_119;
wire n_89;
wire n_152;
wire n_70;
wire n_172;
wire n_131;
wire n_128;
wire n_133;
wire n_139;
wire n_142;
wire n_115;
wire n_109;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_117;
wire n_144;
wire n_53;
wire n_84;
wire n_58;
wire n_68;
wire n_183;
wire n_146;
wire n_104;
wire n_105;
wire n_168;
wire n_33;
wire n_106;
wire n_149;
wire n_188;
wire n_85;
wire n_205;
wire n_55;
wire n_164;
wire n_65;
wire n_159;
wire n_75;
wire n_140;
wire n_176;
wire n_67;
wire n_66;
wire n_101;
wire n_98;
wire n_91;
wire n_36;
wire n_204;
wire n_203;
wire n_50;
wire n_191;
wire n_112;
wire n_129;
wire n_198;
wire n_157;
wire n_181;
wire n_201;
wire n_83;
wire n_60;
wire n_39;
wire n_111;
wire n_32;
wire n_31;
wire n_169;
wire n_180;
wire n_93;
wire n_174;
wire n_150;
wire n_71;
wire n_208;
wire n_92;
wire n_82;
wire n_186;
wire n_100;
wire n_69;
wire n_193;
wire n_212;
wire n_165;
wire n_88;
wire n_124;
wire n_197;
wire n_113;
wire n_206;
wire n_147;
wire n_141;
wire n_134;
wire n_35;
wire n_148;
wire n_38;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_24),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_13),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_8),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_1),
.Y(n_35)
);

INVxp67_ASAP7_75t_SL g36 ( 
.A(n_25),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_0),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_4),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_17),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_21),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_3),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_16),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_18),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_L g45 ( 
.A(n_34),
.B(n_6),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_32),
.A2(n_15),
.B1(n_7),
.B2(n_6),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_33),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_33),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_32),
.B(n_7),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_38),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_38),
.Y(n_51)
);

BUFx6f_ASAP7_75t_SL g52 ( 
.A(n_39),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_39),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_48),
.Y(n_54)
);

NOR2xp33_ASAP7_75t_L g55 ( 
.A(n_47),
.B(n_35),
.Y(n_55)
);

BUFx8_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_48),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_47),
.Y(n_58)
);

BUFx3_ASAP7_75t_L g59 ( 
.A(n_50),
.Y(n_59)
);

NAND3xp33_ASAP7_75t_SL g60 ( 
.A(n_46),
.B(n_31),
.C(n_37),
.Y(n_60)
);

CKINVDCx16_ASAP7_75t_R g61 ( 
.A(n_52),
.Y(n_61)
);

NAND2x1p5_ASAP7_75t_L g62 ( 
.A(n_49),
.B(n_42),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_50),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_54),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_54),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_57),
.Y(n_66)
);

INVx2_ASAP7_75t_L g67 ( 
.A(n_57),
.Y(n_67)
);

AOI22xp5_ASAP7_75t_L g68 ( 
.A1(n_60),
.A2(n_49),
.B1(n_53),
.B2(n_51),
.Y(n_68)
);

NOR2xp33_ASAP7_75t_L g69 ( 
.A(n_62),
.B(n_52),
.Y(n_69)
);

CKINVDCx5p33_ASAP7_75t_R g70 ( 
.A(n_61),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_59),
.B(n_51),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_58),
.Y(n_72)
);

NAND2xp5_ASAP7_75t_L g73 ( 
.A(n_59),
.B(n_53),
.Y(n_73)
);

OAI21xp5_ASAP7_75t_L g74 ( 
.A1(n_58),
.A2(n_63),
.B(n_55),
.Y(n_74)
);

BUFx2_ASAP7_75t_L g75 ( 
.A(n_56),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_63),
.Y(n_76)
);

AND2x4_ASAP7_75t_L g77 ( 
.A(n_62),
.B(n_36),
.Y(n_77)
);

INVx2_ASAP7_75t_L g78 ( 
.A(n_72),
.Y(n_78)
);

INVx2_ASAP7_75t_L g79 ( 
.A(n_72),
.Y(n_79)
);

NAND2xp5_ASAP7_75t_L g80 ( 
.A(n_76),
.B(n_62),
.Y(n_80)
);

AOI21xp5_ASAP7_75t_L g81 ( 
.A1(n_76),
.A2(n_42),
.B(n_45),
.Y(n_81)
);

AND2x2_ASAP7_75t_L g82 ( 
.A(n_77),
.B(n_31),
.Y(n_82)
);

AND2x2_ASAP7_75t_L g83 ( 
.A(n_77),
.B(n_40),
.Y(n_83)
);

NAND2xp5_ASAP7_75t_L g84 ( 
.A(n_72),
.B(n_56),
.Y(n_84)
);

CKINVDCx11_ASAP7_75t_R g85 ( 
.A(n_75),
.Y(n_85)
);

A2O1A1Ixp33_ASAP7_75t_L g86 ( 
.A1(n_74),
.A2(n_66),
.B(n_64),
.C(n_68),
.Y(n_86)
);

INVx4_ASAP7_75t_SL g87 ( 
.A(n_75),
.Y(n_87)
);

HB1xp67_ASAP7_75t_L g88 ( 
.A(n_77),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_65),
.Y(n_89)
);

AND2x2_ASAP7_75t_L g90 ( 
.A(n_77),
.B(n_41),
.Y(n_90)
);

INVx2_ASAP7_75t_L g91 ( 
.A(n_78),
.Y(n_91)
);

INVxp67_ASAP7_75t_L g92 ( 
.A(n_82),
.Y(n_92)
);

NAND2xp5_ASAP7_75t_L g93 ( 
.A(n_82),
.B(n_68),
.Y(n_93)
);

OAI21xp5_ASAP7_75t_L g94 ( 
.A1(n_86),
.A2(n_74),
.B(n_64),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_89),
.Y(n_95)
);

AND2x2_ASAP7_75t_L g96 ( 
.A(n_89),
.B(n_65),
.Y(n_96)
);

AND2x2_ASAP7_75t_L g97 ( 
.A(n_80),
.B(n_65),
.Y(n_97)
);

AOI221xp5_ASAP7_75t_L g98 ( 
.A1(n_83),
.A2(n_70),
.B1(n_66),
.B2(n_73),
.C(n_71),
.Y(n_98)
);

AOI22xp5_ASAP7_75t_L g99 ( 
.A1(n_80),
.A2(n_88),
.B1(n_84),
.B2(n_69),
.Y(n_99)
);

NAND4xp25_ASAP7_75t_L g100 ( 
.A(n_83),
.B(n_44),
.C(n_43),
.D(n_67),
.Y(n_100)
);

AOI221xp5_ASAP7_75t_L g101 ( 
.A1(n_90),
.A2(n_67),
.B1(n_56),
.B2(n_15),
.C(n_16),
.Y(n_101)
);

INVxp67_ASAP7_75t_SL g102 ( 
.A(n_97),
.Y(n_102)
);

INVx2_ASAP7_75t_L g103 ( 
.A(n_91),
.Y(n_103)
);

OR2x6_ASAP7_75t_SL g104 ( 
.A(n_93),
.B(n_85),
.Y(n_104)
);

NOR2x1p5_ASAP7_75t_L g105 ( 
.A(n_100),
.B(n_84),
.Y(n_105)
);

NAND2xp5_ASAP7_75t_L g106 ( 
.A(n_92),
.B(n_90),
.Y(n_106)
);

HB1xp67_ASAP7_75t_L g107 ( 
.A(n_97),
.Y(n_107)
);

NAND2xp5_ASAP7_75t_L g108 ( 
.A(n_98),
.B(n_87),
.Y(n_108)
);

INVx2_ASAP7_75t_L g109 ( 
.A(n_91),
.Y(n_109)
);

AOI21xp5_ASAP7_75t_L g110 ( 
.A1(n_94),
.A2(n_79),
.B(n_78),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_103),
.Y(n_111)
);

NAND4xp25_ASAP7_75t_L g112 ( 
.A(n_106),
.B(n_101),
.C(n_81),
.D(n_99),
.Y(n_112)
);

INVx2_ASAP7_75t_L g113 ( 
.A(n_103),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_109),
.Y(n_114)
);

AO21x2_ASAP7_75t_L g115 ( 
.A1(n_110),
.A2(n_95),
.B(n_96),
.Y(n_115)
);

OA21x2_ASAP7_75t_L g116 ( 
.A1(n_109),
.A2(n_108),
.B(n_95),
.Y(n_116)
);

AND2x2_ASAP7_75t_L g117 ( 
.A(n_102),
.B(n_96),
.Y(n_117)
);

OR2x2_ASAP7_75t_L g118 ( 
.A(n_107),
.B(n_79),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_105),
.Y(n_119)
);

AOI21xp5_ASAP7_75t_L g120 ( 
.A1(n_113),
.A2(n_67),
.B(n_105),
.Y(n_120)
);

AND2x2_ASAP7_75t_L g121 ( 
.A(n_111),
.B(n_104),
.Y(n_121)
);

AND2x2_ASAP7_75t_L g122 ( 
.A(n_111),
.B(n_104),
.Y(n_122)
);

INVxp67_ASAP7_75t_L g123 ( 
.A(n_118),
.Y(n_123)
);

INVx1_ASAP7_75t_L g124 ( 
.A(n_117),
.Y(n_124)
);

OR2x2_ASAP7_75t_L g125 ( 
.A(n_117),
.B(n_17),
.Y(n_125)
);

OAI21xp33_ASAP7_75t_L g126 ( 
.A1(n_119),
.A2(n_19),
.B(n_18),
.Y(n_126)
);

OR2x2_ASAP7_75t_L g127 ( 
.A(n_117),
.B(n_19),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_119),
.B(n_87),
.Y(n_128)
);

NAND3xp33_ASAP7_75t_L g129 ( 
.A(n_112),
.B(n_56),
.C(n_20),
.Y(n_129)
);

AND2x2_ASAP7_75t_L g130 ( 
.A(n_114),
.B(n_20),
.Y(n_130)
);

BUFx2_ASAP7_75t_L g131 ( 
.A(n_116),
.Y(n_131)
);

AND2x2_ASAP7_75t_L g132 ( 
.A(n_124),
.B(n_116),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_131),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_131),
.Y(n_134)
);

INVx2_ASAP7_75t_L g135 ( 
.A(n_130),
.Y(n_135)
);

NOR2xp33_ASAP7_75t_L g136 ( 
.A(n_121),
.B(n_112),
.Y(n_136)
);

NAND2xp5_ASAP7_75t_L g137 ( 
.A(n_123),
.B(n_116),
.Y(n_137)
);

AND2x2_ASAP7_75t_L g138 ( 
.A(n_121),
.B(n_116),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_130),
.Y(n_139)
);

INVx2_ASAP7_75t_L g140 ( 
.A(n_125),
.Y(n_140)
);

AND2x2_ASAP7_75t_L g141 ( 
.A(n_122),
.B(n_116),
.Y(n_141)
);

INVx1_ASAP7_75t_L g142 ( 
.A(n_125),
.Y(n_142)
);

NAND2xp5_ASAP7_75t_L g143 ( 
.A(n_127),
.B(n_115),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_127),
.Y(n_144)
);

INVx2_ASAP7_75t_L g145 ( 
.A(n_128),
.Y(n_145)
);

OAI21xp5_ASAP7_75t_L g146 ( 
.A1(n_129),
.A2(n_118),
.B(n_114),
.Y(n_146)
);

NOR2xp33_ASAP7_75t_L g147 ( 
.A(n_122),
.B(n_22),
.Y(n_147)
);

AND2x2_ASAP7_75t_L g148 ( 
.A(n_120),
.B(n_115),
.Y(n_148)
);

AND2x2_ASAP7_75t_L g149 ( 
.A(n_126),
.B(n_115),
.Y(n_149)
);

XNOR2x1_ASAP7_75t_L g150 ( 
.A(n_141),
.B(n_22),
.Y(n_150)
);

NAND2xp5_ASAP7_75t_L g151 ( 
.A(n_142),
.B(n_115),
.Y(n_151)
);

NOR2xp33_ASAP7_75t_L g152 ( 
.A(n_136),
.B(n_23),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_132),
.Y(n_153)
);

BUFx2_ASAP7_75t_L g154 ( 
.A(n_133),
.Y(n_154)
);

INVx2_ASAP7_75t_SL g155 ( 
.A(n_138),
.Y(n_155)
);

NOR2xp33_ASAP7_75t_L g156 ( 
.A(n_147),
.B(n_23),
.Y(n_156)
);

NAND2xp33_ASAP7_75t_SL g157 ( 
.A(n_141),
.B(n_113),
.Y(n_157)
);

NOR2x1_ASAP7_75t_L g158 ( 
.A(n_146),
.B(n_113),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_132),
.Y(n_159)
);

NOR2xp33_ASAP7_75t_L g160 ( 
.A(n_142),
.B(n_24),
.Y(n_160)
);

NAND2xp5_ASAP7_75t_SL g161 ( 
.A(n_146),
.B(n_87),
.Y(n_161)
);

AND2x2_ASAP7_75t_L g162 ( 
.A(n_138),
.B(n_25),
.Y(n_162)
);

NAND2xp5_ASAP7_75t_L g163 ( 
.A(n_144),
.B(n_26),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_133),
.Y(n_164)
);

NOR2xp33_ASAP7_75t_L g165 ( 
.A(n_144),
.B(n_139),
.Y(n_165)
);

NAND2xp5_ASAP7_75t_L g166 ( 
.A(n_140),
.B(n_26),
.Y(n_166)
);

AND2x2_ASAP7_75t_L g167 ( 
.A(n_134),
.B(n_27),
.Y(n_167)
);

AOI22xp33_ASAP7_75t_L g168 ( 
.A1(n_139),
.A2(n_87),
.B1(n_29),
.B2(n_28),
.Y(n_168)
);

OR2x2_ASAP7_75t_L g169 ( 
.A(n_137),
.B(n_28),
.Y(n_169)
);

NOR2xp33_ASAP7_75t_L g170 ( 
.A(n_140),
.B(n_145),
.Y(n_170)
);

INVx2_ASAP7_75t_L g171 ( 
.A(n_164),
.Y(n_171)
);

NAND2xp5_ASAP7_75t_L g172 ( 
.A(n_162),
.B(n_140),
.Y(n_172)
);

AND2x2_ASAP7_75t_L g173 ( 
.A(n_155),
.B(n_134),
.Y(n_173)
);

HB1xp67_ASAP7_75t_L g174 ( 
.A(n_155),
.Y(n_174)
);

NAND2xp5_ASAP7_75t_L g175 ( 
.A(n_162),
.B(n_143),
.Y(n_175)
);

BUFx2_ASAP7_75t_L g176 ( 
.A(n_157),
.Y(n_176)
);

NAND3xp33_ASAP7_75t_L g177 ( 
.A(n_150),
.B(n_149),
.C(n_137),
.Y(n_177)
);

INVx1_ASAP7_75t_L g178 ( 
.A(n_154),
.Y(n_178)
);

AND2x2_ASAP7_75t_L g179 ( 
.A(n_153),
.B(n_148),
.Y(n_179)
);

NOR2x1_ASAP7_75t_L g180 ( 
.A(n_150),
.B(n_143),
.Y(n_180)
);

NAND2xp5_ASAP7_75t_L g181 ( 
.A(n_165),
.B(n_135),
.Y(n_181)
);

INVxp67_ASAP7_75t_L g182 ( 
.A(n_170),
.Y(n_182)
);

NOR2xp67_ASAP7_75t_L g183 ( 
.A(n_153),
.B(n_149),
.Y(n_183)
);

NAND2xp5_ASAP7_75t_L g184 ( 
.A(n_159),
.B(n_135),
.Y(n_184)
);

AOI21xp5_ASAP7_75t_L g185 ( 
.A1(n_161),
.A2(n_148),
.B(n_135),
.Y(n_185)
);

NOR3xp33_ASAP7_75t_L g186 ( 
.A(n_152),
.B(n_145),
.C(n_29),
.Y(n_186)
);

AND2x2_ASAP7_75t_L g187 ( 
.A(n_159),
.B(n_145),
.Y(n_187)
);

OR2x2_ASAP7_75t_L g188 ( 
.A(n_154),
.B(n_30),
.Y(n_188)
);

OAI22xp5_ASAP7_75t_L g189 ( 
.A1(n_180),
.A2(n_169),
.B1(n_158),
.B2(n_167),
.Y(n_189)
);

NOR3xp33_ASAP7_75t_L g190 ( 
.A(n_180),
.B(n_156),
.C(n_163),
.Y(n_190)
);

NAND4xp75_ASAP7_75t_L g191 ( 
.A(n_183),
.B(n_158),
.C(n_167),
.D(n_160),
.Y(n_191)
);

OAI22xp5_ASAP7_75t_L g192 ( 
.A1(n_177),
.A2(n_169),
.B1(n_166),
.B2(n_168),
.Y(n_192)
);

AND2x4_ASAP7_75t_L g193 ( 
.A(n_176),
.B(n_174),
.Y(n_193)
);

AND2x2_ASAP7_75t_L g194 ( 
.A(n_179),
.B(n_164),
.Y(n_194)
);

INVx1_ASAP7_75t_L g195 ( 
.A(n_187),
.Y(n_195)
);

AOI21xp5_ASAP7_75t_L g196 ( 
.A1(n_176),
.A2(n_151),
.B(n_30),
.Y(n_196)
);

NAND2xp5_ASAP7_75t_L g197 ( 
.A(n_179),
.B(n_182),
.Y(n_197)
);

AND4x1_ASAP7_75t_L g198 ( 
.A(n_186),
.B(n_9),
.C(n_5),
.D(n_2),
.Y(n_198)
);

NOR3x1_ASAP7_75t_L g199 ( 
.A(n_188),
.B(n_11),
.C(n_10),
.Y(n_199)
);

NOR2x1_ASAP7_75t_L g200 ( 
.A(n_193),
.B(n_188),
.Y(n_200)
);

AOI21xp5_ASAP7_75t_L g201 ( 
.A1(n_196),
.A2(n_185),
.B(n_175),
.Y(n_201)
);

AND2x4_ASAP7_75t_L g202 ( 
.A(n_193),
.B(n_178),
.Y(n_202)
);

NAND2x1p5_ASAP7_75t_L g203 ( 
.A(n_199),
.B(n_198),
.Y(n_203)
);

AOI211xp5_ASAP7_75t_SL g204 ( 
.A1(n_192),
.A2(n_178),
.B(n_172),
.C(n_173),
.Y(n_204)
);

INVx2_ASAP7_75t_L g205 ( 
.A(n_194),
.Y(n_205)
);

OR2x2_ASAP7_75t_L g206 ( 
.A(n_195),
.B(n_181),
.Y(n_206)
);

OR5x1_ASAP7_75t_L g207 ( 
.A(n_204),
.B(n_190),
.C(n_191),
.D(n_189),
.E(n_197),
.Y(n_207)
);

AOI22xp5_ASAP7_75t_L g208 ( 
.A1(n_200),
.A2(n_173),
.B1(n_187),
.B2(n_184),
.Y(n_208)
);

OAI22xp5_ASAP7_75t_SL g209 ( 
.A1(n_203),
.A2(n_171),
.B1(n_14),
.B2(n_12),
.Y(n_209)
);

AOI22xp5_ASAP7_75t_L g210 ( 
.A1(n_201),
.A2(n_171),
.B1(n_202),
.B2(n_205),
.Y(n_210)
);

XNOR2xp5_ASAP7_75t_L g211 ( 
.A(n_207),
.B(n_202),
.Y(n_211)
);

XNOR2x2_ASAP7_75t_L g212 ( 
.A(n_210),
.B(n_206),
.Y(n_212)
);

INVx1_ASAP7_75t_L g213 ( 
.A(n_212),
.Y(n_213)
);

AOI221xp5_ASAP7_75t_L g214 ( 
.A1(n_213),
.A2(n_211),
.B1(n_212),
.B2(n_209),
.C(n_208),
.Y(n_214)
);


endmodule