module fake_netlist_795_1788_n_55 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_17, n_9, n_2, n_12, n_13, n_4, n_8, n_55);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_17;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_55;

wire n_37;
wire n_45;
wire n_44;
wire n_20;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_50;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_18;
wire n_49;
wire n_48;
wire n_43;
wire n_38;
wire n_54;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_17),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_9),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_6),
.B(n_11),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

AOI21x1_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_19),
.B(n_24),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_25),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_21),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_28),
.B(n_19),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_32),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_34),
.B1(n_19),
.B2(n_25),
.Y(n_39)
);

NOR3xp33_ASAP7_75t_SL g40 ( 
.A(n_36),
.B(n_18),
.C(n_0),
.Y(n_40)
);

INVx2_ASAP7_75t_SL g41 ( 
.A(n_37),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_34),
.B(n_41),
.Y(n_42)
);

O2A1O1Ixp33_ASAP7_75t_SL g43 ( 
.A1(n_40),
.A2(n_22),
.B(n_1),
.C(n_0),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_SL g45 ( 
.A1(n_39),
.A2(n_22),
.B(n_20),
.Y(n_45)
);

OAI22x1_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_15),
.B1(n_5),
.B2(n_1),
.Y(n_46)
);

NOR3xp33_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_17),
.C(n_16),
.Y(n_47)
);

OA22x2_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_7),
.B1(n_4),
.B2(n_3),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_42),
.Y(n_49)
);

OA22x2_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_48),
.B1(n_47),
.B2(n_49),
.Y(n_50)
);

OAI221xp5_ASAP7_75t_SL g51 ( 
.A1(n_47),
.A2(n_20),
.B1(n_13),
.B2(n_10),
.C(n_12),
.Y(n_51)
);

CKINVDCx20_ASAP7_75t_R g52 ( 
.A(n_49),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

OAI21xp5_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_51),
.B(n_54),
.Y(n_55)
);


endmodule