module fake_netlist_795_544_n_162 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_162);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_162;

wire n_37;
wire n_55;
wire n_36;
wire n_116;
wire n_63;
wire n_140;
wire n_153;
wire n_65;
wire n_35;
wire n_100;
wire n_25;
wire n_40;
wire n_73;
wire n_119;
wire n_101;
wire n_42;
wire n_24;
wire n_105;
wire n_124;
wire n_107;
wire n_48;
wire n_43;
wire n_158;
wire n_68;
wire n_67;
wire n_54;
wire n_127;
wire n_132;
wire n_30;
wire n_59;
wire n_53;
wire n_79;
wire n_74;
wire n_104;
wire n_146;
wire n_85;
wire n_51;
wire n_89;
wire n_106;
wire n_102;
wire n_143;
wire n_45;
wire n_83;
wire n_62;
wire n_75;
wire n_31;
wire n_117;
wire n_121;
wire n_96;
wire n_76;
wire n_148;
wire n_128;
wire n_88;
wire n_84;
wire n_28;
wire n_155;
wire n_156;
wire n_152;
wire n_90;
wire n_103;
wire n_126;
wire n_139;
wire n_151;
wire n_147;
wire n_82;
wire n_86;
wire n_129;
wire n_123;
wire n_150;
wire n_64;
wire n_29;
wire n_92;
wire n_91;
wire n_70;
wire n_125;
wire n_69;
wire n_137;
wire n_71;
wire n_26;
wire n_145;
wire n_133;
wire n_49;
wire n_142;
wire n_109;
wire n_122;
wire n_56;
wire n_61;
wire n_78;
wire n_23;
wire n_112;
wire n_161;
wire n_157;
wire n_110;
wire n_118;
wire n_111;
wire n_149;
wire n_32;
wire n_47;
wire n_159;
wire n_44;
wire n_52;
wire n_77;
wire n_138;
wire n_130;
wire n_160;
wire n_50;
wire n_58;
wire n_108;
wire n_97;
wire n_66;
wire n_94;
wire n_27;
wire n_141;
wire n_34;
wire n_39;
wire n_46;
wire n_154;
wire n_33;
wire n_136;
wire n_135;
wire n_144;
wire n_113;
wire n_114;
wire n_81;
wire n_95;
wire n_98;
wire n_38;
wire n_99;
wire n_80;
wire n_87;
wire n_60;
wire n_115;
wire n_57;
wire n_120;
wire n_134;
wire n_93;
wire n_131;
wire n_41;
wire n_72;

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_11),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_20),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_0),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_11),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_2),
.Y(n_32)
);

BUFx3_ASAP7_75t_L g33 ( 
.A(n_8),
.Y(n_33)
);

INVxp33_ASAP7_75t_SL g34 ( 
.A(n_13),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_14),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_23),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_33),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_R g38 ( 
.A(n_30),
.B(n_25),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_33),
.B(n_23),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_33),
.B(n_5),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_33),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_34),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_37),
.A2(n_27),
.B(n_24),
.Y(n_43)
);

INVx2_ASAP7_75t_SL g44 ( 
.A(n_39),
.Y(n_44)
);

BUFx4f_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_37),
.B(n_30),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_38),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_L g48 ( 
.A(n_37),
.B(n_34),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_36),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_39),
.B(n_41),
.Y(n_50)
);

OR2x6_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_39),
.Y(n_51)
);

INVxp67_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

OAI21x1_ASAP7_75t_L g53 ( 
.A1(n_43),
.A2(n_41),
.B(n_36),
.Y(n_53)
);

AOI21xp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_39),
.B(n_41),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_49),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_50),
.Y(n_56)
);

OAI21xp5_ASAP7_75t_SL g57 ( 
.A1(n_48),
.A2(n_42),
.B(n_40),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_46),
.Y(n_58)
);

AOI21xp5_ASAP7_75t_L g59 ( 
.A1(n_50),
.A2(n_39),
.B(n_40),
.Y(n_59)
);

CKINVDCx5p33_ASAP7_75t_R g60 ( 
.A(n_47),
.Y(n_60)
);

OR2x2_ASAP7_75t_L g61 ( 
.A(n_52),
.B(n_44),
.Y(n_61)
);

AOI21xp5_ASAP7_75t_L g62 ( 
.A1(n_54),
.A2(n_45),
.B(n_44),
.Y(n_62)
);

OAI22xp5_ASAP7_75t_L g63 ( 
.A1(n_51),
.A2(n_44),
.B1(n_45),
.B2(n_42),
.Y(n_63)
);

AOI21xp5_ASAP7_75t_SL g64 ( 
.A1(n_51),
.A2(n_32),
.B(n_26),
.Y(n_64)
);

BUFx12f_ASAP7_75t_L g65 ( 
.A(n_60),
.Y(n_65)
);

AOI21xp5_ASAP7_75t_L g66 ( 
.A1(n_54),
.A2(n_45),
.B(n_43),
.Y(n_66)
);

O2A1O1Ixp5_ASAP7_75t_L g67 ( 
.A1(n_56),
.A2(n_45),
.B(n_49),
.C(n_46),
.Y(n_67)
);

O2A1O1Ixp33_ASAP7_75t_L g68 ( 
.A1(n_56),
.A2(n_57),
.B(n_52),
.C(n_55),
.Y(n_68)
);

OA21x2_ASAP7_75t_L g69 ( 
.A1(n_53),
.A2(n_49),
.B(n_26),
.Y(n_69)
);

CKINVDCx5p33_ASAP7_75t_R g70 ( 
.A(n_58),
.Y(n_70)
);

OR2x6_ASAP7_75t_L g71 ( 
.A(n_68),
.B(n_59),
.Y(n_71)
);

CKINVDCx5p33_ASAP7_75t_R g72 ( 
.A(n_65),
.Y(n_72)
);

AND2x2_ASAP7_75t_L g73 ( 
.A(n_61),
.B(n_55),
.Y(n_73)
);

HB1xp67_ASAP7_75t_L g74 ( 
.A(n_63),
.Y(n_74)
);

BUFx3_ASAP7_75t_L g75 ( 
.A(n_69),
.Y(n_75)
);

AND2x2_ASAP7_75t_L g76 ( 
.A(n_61),
.B(n_51),
.Y(n_76)
);

AOI21xp33_ASAP7_75t_L g77 ( 
.A1(n_67),
.A2(n_57),
.B(n_59),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_69),
.Y(n_78)
);

OA21x2_ASAP7_75t_L g79 ( 
.A1(n_66),
.A2(n_53),
.B(n_32),
.Y(n_79)
);

INVx2_ASAP7_75t_L g80 ( 
.A(n_71),
.Y(n_80)
);

AND2x2_ASAP7_75t_L g81 ( 
.A(n_73),
.B(n_70),
.Y(n_81)
);

BUFx6f_ASAP7_75t_L g82 ( 
.A(n_73),
.Y(n_82)
);

AND2x2_ASAP7_75t_L g83 ( 
.A(n_73),
.B(n_70),
.Y(n_83)
);

AND2x6_ASAP7_75t_SL g84 ( 
.A(n_71),
.B(n_24),
.Y(n_84)
);

INVx2_ASAP7_75t_L g85 ( 
.A(n_71),
.Y(n_85)
);

INVx2_ASAP7_75t_L g86 ( 
.A(n_71),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_82),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_82),
.Y(n_88)
);

AND2x2_ASAP7_75t_L g89 ( 
.A(n_82),
.B(n_74),
.Y(n_89)
);

NOR2xp33_ASAP7_75t_L g90 ( 
.A(n_81),
.B(n_47),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_85),
.Y(n_91)
);

NAND2xp5_ASAP7_75t_L g92 ( 
.A(n_83),
.B(n_73),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_85),
.Y(n_93)
);

OAI21xp5_ASAP7_75t_L g94 ( 
.A1(n_90),
.A2(n_77),
.B(n_74),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_91),
.Y(n_95)
);

INVx1_ASAP7_75t_L g96 ( 
.A(n_91),
.Y(n_96)
);

NAND3xp33_ASAP7_75t_SL g97 ( 
.A(n_92),
.B(n_29),
.C(n_72),
.Y(n_97)
);

AOI31xp33_ASAP7_75t_L g98 ( 
.A1(n_89),
.A2(n_74),
.A3(n_77),
.B(n_84),
.Y(n_98)
);

NAND2xp33_ASAP7_75t_SL g99 ( 
.A(n_88),
.B(n_73),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_93),
.Y(n_100)
);

NAND2xp5_ASAP7_75t_L g101 ( 
.A(n_89),
.B(n_88),
.Y(n_101)
);

NAND2xp5_ASAP7_75t_L g102 ( 
.A(n_87),
.B(n_76),
.Y(n_102)
);

NAND2xp5_ASAP7_75t_L g103 ( 
.A(n_101),
.B(n_84),
.Y(n_103)
);

AOI211xp5_ASAP7_75t_L g104 ( 
.A1(n_97),
.A2(n_35),
.B(n_31),
.C(n_27),
.Y(n_104)
);

NOR4xp25_ASAP7_75t_L g105 ( 
.A(n_98),
.B(n_35),
.C(n_31),
.D(n_77),
.Y(n_105)
);

NOR2xp33_ASAP7_75t_L g106 ( 
.A(n_102),
.B(n_71),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_95),
.Y(n_107)
);

AOI221xp5_ASAP7_75t_L g108 ( 
.A1(n_98),
.A2(n_94),
.B1(n_29),
.B2(n_28),
.C(n_64),
.Y(n_108)
);

O2A1O1Ixp5_ASAP7_75t_L g109 ( 
.A1(n_99),
.A2(n_86),
.B(n_80),
.C(n_76),
.Y(n_109)
);

A2O1A1Ixp33_ASAP7_75t_L g110 ( 
.A1(n_95),
.A2(n_76),
.B(n_53),
.C(n_71),
.Y(n_110)
);

OAI221xp5_ASAP7_75t_L g111 ( 
.A1(n_96),
.A2(n_71),
.B1(n_64),
.B2(n_72),
.C(n_76),
.Y(n_111)
);

NAND2xp5_ASAP7_75t_L g112 ( 
.A(n_96),
.B(n_100),
.Y(n_112)
);

NAND4xp25_ASAP7_75t_L g113 ( 
.A(n_100),
.B(n_76),
.C(n_75),
.D(n_78),
.Y(n_113)
);

NOR2x1_ASAP7_75t_L g114 ( 
.A(n_94),
.B(n_71),
.Y(n_114)
);

AOI21xp5_ASAP7_75t_L g115 ( 
.A1(n_94),
.A2(n_71),
.B(n_78),
.Y(n_115)
);

NOR2x1_ASAP7_75t_L g116 ( 
.A(n_111),
.B(n_71),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_107),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_112),
.Y(n_118)
);

NAND2xp5_ASAP7_75t_L g119 ( 
.A(n_103),
.B(n_75),
.Y(n_119)
);

NAND2xp33_ASAP7_75t_SL g120 ( 
.A(n_113),
.B(n_105),
.Y(n_120)
);

AND2x2_ASAP7_75t_L g121 ( 
.A(n_114),
.B(n_79),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_106),
.Y(n_122)
);

INVxp67_ASAP7_75t_L g123 ( 
.A(n_106),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_115),
.B(n_75),
.Y(n_124)
);

INVx1_ASAP7_75t_L g125 ( 
.A(n_110),
.Y(n_125)
);

INVx2_ASAP7_75t_L g126 ( 
.A(n_109),
.Y(n_126)
);

INVxp67_ASAP7_75t_L g127 ( 
.A(n_108),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_104),
.Y(n_128)
);

OR2x2_ASAP7_75t_L g129 ( 
.A(n_107),
.B(n_79),
.Y(n_129)
);

OAI21xp5_ASAP7_75t_L g130 ( 
.A1(n_105),
.A2(n_78),
.B(n_79),
.Y(n_130)
);

HB1xp67_ASAP7_75t_L g131 ( 
.A(n_107),
.Y(n_131)
);

NAND2xp5_ASAP7_75t_L g132 ( 
.A(n_122),
.B(n_78),
.Y(n_132)
);

NOR3xp33_ASAP7_75t_SL g133 ( 
.A(n_120),
.B(n_7),
.C(n_6),
.Y(n_133)
);

NAND4xp75_ASAP7_75t_L g134 ( 
.A(n_116),
.B(n_79),
.C(n_65),
.D(n_69),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_131),
.Y(n_135)
);

INVx1_ASAP7_75t_SL g136 ( 
.A(n_118),
.Y(n_136)
);

NAND2xp5_ASAP7_75t_L g137 ( 
.A(n_123),
.B(n_75),
.Y(n_137)
);

NAND3xp33_ASAP7_75t_L g138 ( 
.A(n_127),
.B(n_79),
.C(n_69),
.Y(n_138)
);

OR2x2_ASAP7_75t_L g139 ( 
.A(n_117),
.B(n_79),
.Y(n_139)
);

AOI22xp5_ASAP7_75t_L g140 ( 
.A1(n_120),
.A2(n_79),
.B1(n_75),
.B2(n_51),
.Y(n_140)
);

NOR2xp33_ASAP7_75t_L g141 ( 
.A(n_128),
.B(n_8),
.Y(n_141)
);

NOR3x2_ASAP7_75t_L g142 ( 
.A(n_129),
.B(n_12),
.C(n_10),
.Y(n_142)
);

OAI211xp5_ASAP7_75t_L g143 ( 
.A1(n_128),
.A2(n_14),
.B(n_13),
.C(n_10),
.Y(n_143)
);

NAND4xp75_ASAP7_75t_L g144 ( 
.A(n_119),
.B(n_79),
.C(n_16),
.D(n_15),
.Y(n_144)
);

AOI22xp33_ASAP7_75t_SL g145 ( 
.A1(n_143),
.A2(n_125),
.B1(n_126),
.B2(n_121),
.Y(n_145)
);

NOR2x1_ASAP7_75t_L g146 ( 
.A(n_135),
.B(n_125),
.Y(n_146)
);

CKINVDCx20_ASAP7_75t_R g147 ( 
.A(n_141),
.Y(n_147)
);

AOI22xp33_ASAP7_75t_L g148 ( 
.A1(n_140),
.A2(n_126),
.B1(n_121),
.B2(n_124),
.Y(n_148)
);

OAI22xp5_ASAP7_75t_L g149 ( 
.A1(n_133),
.A2(n_129),
.B1(n_130),
.B2(n_51),
.Y(n_149)
);

INVx2_ASAP7_75t_SL g150 ( 
.A(n_136),
.Y(n_150)
);

OAI221xp5_ASAP7_75t_SL g151 ( 
.A1(n_143),
.A2(n_17),
.B1(n_16),
.B2(n_18),
.C(n_19),
.Y(n_151)
);

AND2x4_ASAP7_75t_L g152 ( 
.A(n_139),
.B(n_18),
.Y(n_152)
);

AOI322xp5_ASAP7_75t_L g153 ( 
.A1(n_133),
.A2(n_22),
.A3(n_21),
.B1(n_20),
.B2(n_3),
.C1(n_1),
.C2(n_4),
.Y(n_153)
);

OA22x2_ASAP7_75t_L g154 ( 
.A1(n_150),
.A2(n_142),
.B1(n_137),
.B2(n_132),
.Y(n_154)
);

AOI21xp5_ASAP7_75t_L g155 ( 
.A1(n_151),
.A2(n_138),
.B(n_144),
.Y(n_155)
);

OAI21xp5_ASAP7_75t_L g156 ( 
.A1(n_145),
.A2(n_134),
.B(n_62),
.Y(n_156)
);

AOI22xp5_ASAP7_75t_L g157 ( 
.A1(n_148),
.A2(n_51),
.B1(n_22),
.B2(n_21),
.Y(n_157)
);

CKINVDCx12_ASAP7_75t_R g158 ( 
.A(n_147),
.Y(n_158)
);

AOI22xp33_ASAP7_75t_SL g159 ( 
.A1(n_154),
.A2(n_149),
.B1(n_152),
.B2(n_153),
.Y(n_159)
);

AOI21x1_ASAP7_75t_L g160 ( 
.A1(n_155),
.A2(n_146),
.B(n_152),
.Y(n_160)
);

OAI21x1_ASAP7_75t_SL g161 ( 
.A1(n_160),
.A2(n_156),
.B(n_157),
.Y(n_161)
);

AOI221xp5_ASAP7_75t_L g162 ( 
.A1(n_161),
.A2(n_159),
.B1(n_160),
.B2(n_158),
.C(n_45),
.Y(n_162)
);


endmodule