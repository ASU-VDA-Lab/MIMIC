module fake_netlist_795_1109_n_5 (n_1, n_0, n_5);

input n_1;
input n_0;

output n_5;

wire n_3;
wire n_2;
wire n_4;

BUFx3_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

AOI21xp33_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_5)
);


endmodule