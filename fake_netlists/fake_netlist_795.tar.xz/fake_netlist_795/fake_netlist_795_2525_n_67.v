module fake_netlist_795_2525_n_67 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_14, n_67);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_14;

output n_67;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_64;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_63;
wire n_62;
wire n_65;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_66;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_48;
wire n_43;
wire n_49;
wire n_56;
wire n_38;
wire n_54;
wire n_61;
wire n_60;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_59;
wire n_53;
wire n_41;
wire n_51;
wire n_32;
wire n_22;

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_10),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_16),
.A2(n_0),
.B1(n_13),
.B2(n_18),
.Y(n_24)
);

AND2x2_ASAP7_75t_SL g25 ( 
.A(n_5),
.B(n_14),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_11),
.A2(n_17),
.B1(n_20),
.B2(n_19),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_3),
.B(n_2),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_12),
.B(n_16),
.Y(n_31)
);

NAND2x1_ASAP7_75t_L g32 ( 
.A(n_21),
.B(n_1),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_26),
.B(n_2),
.Y(n_33)
);

BUFx8_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_23),
.B(n_3),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_27),
.B(n_17),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_29),
.B(n_30),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_28),
.B(n_20),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_31),
.Y(n_39)
);

AOI21xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_22),
.B(n_32),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_34),
.B(n_31),
.Y(n_41)
);

AOI22x1_ASAP7_75t_L g42 ( 
.A1(n_36),
.A2(n_24),
.B1(n_25),
.B2(n_32),
.Y(n_42)
);

OA21x2_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_35),
.B(n_33),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_25),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

AND2x2_ASAP7_75t_SL g48 ( 
.A(n_45),
.B(n_42),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_44),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

INVx3_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_48),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

AOI21xp33_ASAP7_75t_SL g54 ( 
.A1(n_49),
.A2(n_42),
.B(n_48),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_50),
.A2(n_48),
.B(n_44),
.Y(n_55)
);

AOI211x1_ASAP7_75t_L g56 ( 
.A1(n_50),
.A2(n_44),
.B(n_45),
.C(n_43),
.Y(n_56)
);

NOR2x1p5_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_45),
.Y(n_57)
);

NOR3xp33_ASAP7_75t_L g58 ( 
.A(n_54),
.B(n_45),
.C(n_52),
.Y(n_58)
);

NAND3xp33_ASAP7_75t_SL g59 ( 
.A(n_55),
.B(n_43),
.C(n_21),
.Y(n_59)
);

NAND4xp25_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_51),
.C(n_43),
.D(n_4),
.Y(n_60)
);

AND4x1_ASAP7_75t_L g61 ( 
.A(n_58),
.B(n_43),
.C(n_9),
.D(n_7),
.Y(n_61)
);

NOR4xp75_ASAP7_75t_L g62 ( 
.A(n_59),
.B(n_43),
.C(n_51),
.D(n_57),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_60),
.Y(n_63)
);

XNOR2xp5_ASAP7_75t_L g64 ( 
.A(n_61),
.B(n_43),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_63),
.Y(n_65)
);

OAI22x1_ASAP7_75t_L g66 ( 
.A1(n_64),
.A2(n_63),
.B1(n_62),
.B2(n_51),
.Y(n_66)
);

OAI21xp5_ASAP7_75t_SL g67 ( 
.A1(n_66),
.A2(n_64),
.B(n_65),
.Y(n_67)
);


endmodule