module fake_netlist_795_956_n_16 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_16);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_16;

wire n_15;
wire n_11;
wire n_12;
wire n_8;
wire n_9;
wire n_10;
wire n_13;
wire n_14;

AND2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_3),
.A2(n_0),
.B1(n_5),
.B2(n_7),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_8),
.B(n_10),
.Y(n_11)
);

NAND4xp25_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_6),
.C(n_4),
.D(n_1),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

XNOR2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B(n_6),
.Y(n_16)
);


endmodule