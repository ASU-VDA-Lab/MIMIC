module fake_netlist_795_1837_n_25 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_25);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_25;

wire n_20;
wire n_17;
wire n_12;
wire n_24;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_2),
.B(n_1),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_9),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

OAI21x1_ASAP7_75t_SL g16 ( 
.A1(n_14),
.A2(n_4),
.B(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_11),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_5),
.B(n_4),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AND2x4_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

AND5x1_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.C(n_16),
.D(n_19),
.E(n_6),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OAI21x1_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_15),
.B(n_10),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_13),
.B1(n_6),
.B2(n_7),
.Y(n_25)
);


endmodule