module fake_netlist_795_386_n_26 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_26);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_26;

wire n_20;
wire n_17;
wire n_12;
wire n_25;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_23;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_9),
.B(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_3),
.Y(n_16)
);

OAI22x1_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_R g19 ( 
.A(n_17),
.B(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

OAI32xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_18),
.A3(n_19),
.B1(n_13),
.B2(n_11),
.Y(n_21)
);

AOI33xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_10),
.A3(n_13),
.B1(n_11),
.B2(n_6),
.B3(n_5),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

INVxp33_ASAP7_75t_SL g24 ( 
.A(n_22),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.C(n_1),
.Y(n_25)
);

INVxp67_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);


endmodule