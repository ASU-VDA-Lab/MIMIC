module fake_netlist_795_897_n_243 (n_0, n_20, n_6, n_29, n_17, n_2, n_12, n_1, n_25, n_31, n_5, n_27, n_24, n_26, n_18, n_13, n_15, n_11, n_16, n_23, n_28, n_4, n_9, n_8, n_30, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_243);

input n_0;
input n_20;
input n_6;
input n_29;
input n_17;
input n_2;
input n_12;
input n_1;
input n_25;
input n_31;
input n_5;
input n_27;
input n_24;
input n_26;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_28;
input n_4;
input n_9;
input n_8;
input n_30;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_243;

wire n_37;
wire n_221;
wire n_183;
wire n_55;
wire n_36;
wire n_116;
wire n_63;
wire n_140;
wire n_153;
wire n_65;
wire n_35;
wire n_100;
wire n_40;
wire n_73;
wire n_119;
wire n_101;
wire n_232;
wire n_42;
wire n_105;
wire n_124;
wire n_186;
wire n_187;
wire n_107;
wire n_48;
wire n_43;
wire n_158;
wire n_68;
wire n_231;
wire n_67;
wire n_222;
wire n_225;
wire n_184;
wire n_54;
wire n_179;
wire n_127;
wire n_219;
wire n_132;
wire n_166;
wire n_210;
wire n_213;
wire n_197;
wire n_59;
wire n_53;
wire n_227;
wire n_79;
wire n_181;
wire n_74;
wire n_104;
wire n_146;
wire n_85;
wire n_51;
wire n_89;
wire n_106;
wire n_178;
wire n_182;
wire n_168;
wire n_102;
wire n_143;
wire n_207;
wire n_241;
wire n_45;
wire n_224;
wire n_83;
wire n_201;
wire n_220;
wire n_62;
wire n_75;
wire n_165;
wire n_216;
wire n_117;
wire n_121;
wire n_96;
wire n_169;
wire n_235;
wire n_180;
wire n_185;
wire n_76;
wire n_174;
wire n_199;
wire n_204;
wire n_148;
wire n_175;
wire n_128;
wire n_202;
wire n_229;
wire n_88;
wire n_171;
wire n_214;
wire n_84;
wire n_195;
wire n_155;
wire n_217;
wire n_230;
wire n_156;
wire n_152;
wire n_90;
wire n_103;
wire n_126;
wire n_147;
wire n_151;
wire n_139;
wire n_164;
wire n_86;
wire n_82;
wire n_129;
wire n_123;
wire n_196;
wire n_150;
wire n_177;
wire n_198;
wire n_176;
wire n_64;
wire n_228;
wire n_188;
wire n_167;
wire n_92;
wire n_189;
wire n_91;
wire n_234;
wire n_70;
wire n_125;
wire n_69;
wire n_137;
wire n_233;
wire n_71;
wire n_209;
wire n_212;
wire n_215;
wire n_145;
wire n_133;
wire n_49;
wire n_194;
wire n_142;
wire n_109;
wire n_122;
wire n_56;
wire n_236;
wire n_61;
wire n_78;
wire n_218;
wire n_112;
wire n_161;
wire n_157;
wire n_190;
wire n_110;
wire n_203;
wire n_118;
wire n_111;
wire n_149;
wire n_32;
wire n_170;
wire n_47;
wire n_200;
wire n_205;
wire n_163;
wire n_172;
wire n_159;
wire n_44;
wire n_52;
wire n_77;
wire n_138;
wire n_130;
wire n_160;
wire n_206;
wire n_58;
wire n_50;
wire n_108;
wire n_162;
wire n_240;
wire n_97;
wire n_66;
wire n_173;
wire n_94;
wire n_141;
wire n_34;
wire n_39;
wire n_211;
wire n_46;
wire n_154;
wire n_33;
wire n_136;
wire n_193;
wire n_135;
wire n_144;
wire n_113;
wire n_114;
wire n_81;
wire n_239;
wire n_95;
wire n_98;
wire n_223;
wire n_38;
wire n_80;
wire n_99;
wire n_191;
wire n_87;
wire n_192;
wire n_60;
wire n_115;
wire n_57;
wire n_120;
wire n_208;
wire n_134;
wire n_93;
wire n_131;
wire n_237;
wire n_226;
wire n_41;
wire n_242;
wire n_238;
wire n_72;

CKINVDCx14_ASAP7_75t_R g32 ( 
.A(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_8),
.Y(n_33)
);

INVxp67_ASAP7_75t_SL g34 ( 
.A(n_31),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_10),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_28),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_17),
.Y(n_37)
);

INVxp67_ASAP7_75t_L g38 ( 
.A(n_14),
.Y(n_38)
);

CKINVDCx16_ASAP7_75t_R g39 ( 
.A(n_26),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_31),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_15),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_12),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_27),
.Y(n_43)
);

CKINVDCx16_ASAP7_75t_R g44 ( 
.A(n_16),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_32),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_39),
.Y(n_46)
);

BUFx6f_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

BUFx3_ASAP7_75t_L g48 ( 
.A(n_41),
.Y(n_48)
);

CKINVDCx20_ASAP7_75t_R g49 ( 
.A(n_39),
.Y(n_49)
);

CKINVDCx20_ASAP7_75t_R g50 ( 
.A(n_44),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_32),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_45),
.Y(n_52)
);

AND2x4_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_40),
.Y(n_53)
);

BUFx3_ASAP7_75t_L g54 ( 
.A(n_48),
.Y(n_54)
);

NAND2x1p5_ASAP7_75t_L g55 ( 
.A(n_47),
.B(n_42),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_48),
.B(n_42),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_SL g57 ( 
.A(n_45),
.B(n_44),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_48),
.B(n_40),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_47),
.Y(n_59)
);

INVxp67_ASAP7_75t_SL g60 ( 
.A(n_47),
.Y(n_60)
);

NAND2x1p5_ASAP7_75t_L g61 ( 
.A(n_47),
.B(n_40),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_54),
.B(n_51),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_SL g63 ( 
.A(n_57),
.B(n_51),
.Y(n_63)
);

BUFx3_ASAP7_75t_L g64 ( 
.A(n_54),
.Y(n_64)
);

OAI21xp33_ASAP7_75t_SL g65 ( 
.A1(n_58),
.A2(n_56),
.B(n_57),
.Y(n_65)
);

AOI22xp5_ASAP7_75t_L g66 ( 
.A1(n_53),
.A2(n_34),
.B1(n_43),
.B2(n_33),
.Y(n_66)
);

BUFx2_ASAP7_75t_L g67 ( 
.A(n_52),
.Y(n_67)
);

OAI22xp5_ASAP7_75t_L g68 ( 
.A1(n_52),
.A2(n_34),
.B1(n_43),
.B2(n_33),
.Y(n_68)
);

A2O1A1Ixp33_ASAP7_75t_SL g69 ( 
.A1(n_56),
.A2(n_38),
.B(n_36),
.C(n_35),
.Y(n_69)
);

AOI22xp5_ASAP7_75t_L g70 ( 
.A1(n_54),
.A2(n_53),
.B1(n_49),
.B2(n_46),
.Y(n_70)
);

AOI21xp5_ASAP7_75t_L g71 ( 
.A1(n_60),
.A2(n_47),
.B(n_38),
.Y(n_71)
);

AOI21xp5_ASAP7_75t_L g72 ( 
.A1(n_60),
.A2(n_47),
.B(n_35),
.Y(n_72)
);

INVx4_ASAP7_75t_L g73 ( 
.A(n_55),
.Y(n_73)
);

INVxp67_ASAP7_75t_L g74 ( 
.A(n_58),
.Y(n_74)
);

OAI21x1_ASAP7_75t_L g75 ( 
.A1(n_72),
.A2(n_55),
.B(n_61),
.Y(n_75)
);

OAI22xp5_ASAP7_75t_L g76 ( 
.A1(n_66),
.A2(n_74),
.B1(n_70),
.B2(n_58),
.Y(n_76)
);

AND2x2_ASAP7_75t_L g77 ( 
.A(n_65),
.B(n_53),
.Y(n_77)
);

AOI21xp5_ASAP7_75t_L g78 ( 
.A1(n_65),
.A2(n_56),
.B(n_53),
.Y(n_78)
);

NOR2xp33_ASAP7_75t_SL g79 ( 
.A(n_73),
.B(n_55),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_71),
.Y(n_80)
);

AND2x4_ASAP7_75t_L g81 ( 
.A(n_66),
.B(n_53),
.Y(n_81)
);

AOI21x1_ASAP7_75t_L g82 ( 
.A1(n_62),
.A2(n_59),
.B(n_53),
.Y(n_82)
);

OA21x2_ASAP7_75t_L g83 ( 
.A1(n_63),
.A2(n_37),
.B(n_36),
.Y(n_83)
);

AOI22xp33_ASAP7_75t_SL g84 ( 
.A1(n_68),
.A2(n_50),
.B1(n_49),
.B2(n_46),
.Y(n_84)
);

INVx3_ASAP7_75t_L g85 ( 
.A(n_73),
.Y(n_85)
);

AOI22xp33_ASAP7_75t_SL g86 ( 
.A1(n_76),
.A2(n_50),
.B1(n_81),
.B2(n_79),
.Y(n_86)
);

OR2x6_ASAP7_75t_L g87 ( 
.A(n_81),
.B(n_73),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_80),
.Y(n_88)
);

NAND2xp33_ASAP7_75t_R g89 ( 
.A(n_83),
.B(n_67),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_80),
.Y(n_90)
);

OAI22xp33_ASAP7_75t_L g91 ( 
.A1(n_76),
.A2(n_67),
.B1(n_64),
.B2(n_54),
.Y(n_91)
);

INVx2_ASAP7_75t_L g92 ( 
.A(n_80),
.Y(n_92)
);

OR2x2_ASAP7_75t_L g93 ( 
.A(n_87),
.B(n_76),
.Y(n_93)
);

AOI22xp33_ASAP7_75t_L g94 ( 
.A1(n_86),
.A2(n_81),
.B1(n_77),
.B2(n_76),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_92),
.Y(n_95)
);

INVx2_ASAP7_75t_SL g96 ( 
.A(n_87),
.Y(n_96)
);

INVxp67_ASAP7_75t_L g97 ( 
.A(n_89),
.Y(n_97)
);

OAI21xp5_ASAP7_75t_L g98 ( 
.A1(n_88),
.A2(n_78),
.B(n_77),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_88),
.Y(n_99)
);

NAND2x1p5_ASAP7_75t_L g100 ( 
.A(n_96),
.B(n_85),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_99),
.Y(n_101)
);

AND2x4_ASAP7_75t_L g102 ( 
.A(n_96),
.B(n_87),
.Y(n_102)
);

INVx2_ASAP7_75t_L g103 ( 
.A(n_95),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_99),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_94),
.B(n_81),
.Y(n_105)
);

AOI22xp5_ASAP7_75t_L g106 ( 
.A1(n_94),
.A2(n_84),
.B1(n_87),
.B2(n_91),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_99),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_95),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_95),
.Y(n_109)
);

AND2x2_ASAP7_75t_L g110 ( 
.A(n_93),
.B(n_81),
.Y(n_110)
);

INVx1_ASAP7_75t_SL g111 ( 
.A(n_102),
.Y(n_111)
);

OR2x2_ASAP7_75t_L g112 ( 
.A(n_108),
.B(n_93),
.Y(n_112)
);

NOR2xp33_ASAP7_75t_L g113 ( 
.A(n_106),
.B(n_84),
.Y(n_113)
);

INVx2_ASAP7_75t_L g114 ( 
.A(n_101),
.Y(n_114)
);

AOI22xp33_ASAP7_75t_L g115 ( 
.A1(n_105),
.A2(n_93),
.B1(n_84),
.B2(n_81),
.Y(n_115)
);

AND2x4_ASAP7_75t_L g116 ( 
.A(n_102),
.B(n_96),
.Y(n_116)
);

AND2x2_ASAP7_75t_L g117 ( 
.A(n_101),
.B(n_98),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_107),
.Y(n_118)
);

INVx2_ASAP7_75t_L g119 ( 
.A(n_107),
.Y(n_119)
);

AND2x2_ASAP7_75t_SL g120 ( 
.A(n_102),
.B(n_79),
.Y(n_120)
);

NOR2x1p5_ASAP7_75t_L g121 ( 
.A(n_102),
.B(n_92),
.Y(n_121)
);

INVx1_ASAP7_75t_SL g122 ( 
.A(n_103),
.Y(n_122)
);

AND2x2_ASAP7_75t_L g123 ( 
.A(n_104),
.B(n_98),
.Y(n_123)
);

OR2x2_ASAP7_75t_L g124 ( 
.A(n_108),
.B(n_97),
.Y(n_124)
);

CKINVDCx16_ASAP7_75t_R g125 ( 
.A(n_110),
.Y(n_125)
);

AOI222xp33_ASAP7_75t_L g126 ( 
.A1(n_110),
.A2(n_37),
.B1(n_81),
.B2(n_97),
.C1(n_77),
.C2(n_96),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_109),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_109),
.B(n_95),
.Y(n_128)
);

AOI22xp33_ASAP7_75t_L g129 ( 
.A1(n_103),
.A2(n_81),
.B1(n_83),
.B2(n_77),
.Y(n_129)
);

OR2x2_ASAP7_75t_L g130 ( 
.A(n_112),
.B(n_83),
.Y(n_130)
);

AOI221xp5_ASAP7_75t_L g131 ( 
.A1(n_113),
.A2(n_81),
.B1(n_69),
.B2(n_47),
.C(n_77),
.Y(n_131)
);

INVx2_ASAP7_75t_SL g132 ( 
.A(n_121),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_118),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_118),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_118),
.Y(n_135)
);

NAND2xp33_ASAP7_75t_L g136 ( 
.A(n_115),
.B(n_90),
.Y(n_136)
);

OR2x2_ASAP7_75t_L g137 ( 
.A(n_112),
.B(n_111),
.Y(n_137)
);

OAI21xp5_ASAP7_75t_SL g138 ( 
.A1(n_113),
.A2(n_78),
.B(n_100),
.Y(n_138)
);

NAND3xp33_ASAP7_75t_L g139 ( 
.A(n_115),
.B(n_83),
.C(n_47),
.Y(n_139)
);

NAND2xp5_ASAP7_75t_L g140 ( 
.A(n_123),
.B(n_92),
.Y(n_140)
);

AO22x1_ASAP7_75t_L g141 ( 
.A1(n_116),
.A2(n_90),
.B1(n_47),
.B2(n_80),
.Y(n_141)
);

OAI22xp33_ASAP7_75t_L g142 ( 
.A1(n_125),
.A2(n_87),
.B1(n_83),
.B2(n_79),
.Y(n_142)
);

NOR2xp33_ASAP7_75t_L g143 ( 
.A(n_125),
.B(n_83),
.Y(n_143)
);

AO22x2_ASAP7_75t_L g144 ( 
.A1(n_112),
.A2(n_78),
.B1(n_83),
.B2(n_100),
.Y(n_144)
);

AOI322xp5_ASAP7_75t_L g145 ( 
.A1(n_120),
.A2(n_1),
.A3(n_0),
.B1(n_4),
.B2(n_5),
.C1(n_2),
.C2(n_3),
.Y(n_145)
);

OAI31xp33_ASAP7_75t_L g146 ( 
.A1(n_121),
.A2(n_78),
.A3(n_129),
.B(n_116),
.Y(n_146)
);

AOI22xp5_ASAP7_75t_L g147 ( 
.A1(n_120),
.A2(n_83),
.B1(n_79),
.B2(n_100),
.Y(n_147)
);

NAND3xp33_ASAP7_75t_L g148 ( 
.A(n_126),
.B(n_83),
.C(n_59),
.Y(n_148)
);

OR2x2_ASAP7_75t_L g149 ( 
.A(n_111),
.B(n_125),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_114),
.Y(n_150)
);

NAND2xp5_ASAP7_75t_L g151 ( 
.A(n_123),
.B(n_83),
.Y(n_151)
);

AOI221xp5_ASAP7_75t_L g152 ( 
.A1(n_117),
.A2(n_61),
.B1(n_55),
.B2(n_59),
.C(n_0),
.Y(n_152)
);

AND2x2_ASAP7_75t_L g153 ( 
.A(n_116),
.B(n_61),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_114),
.Y(n_154)
);

AOI22xp5_ASAP7_75t_L g155 ( 
.A1(n_120),
.A2(n_126),
.B1(n_121),
.B2(n_116),
.Y(n_155)
);

OAI21xp5_ASAP7_75t_L g156 ( 
.A1(n_129),
.A2(n_82),
.B(n_75),
.Y(n_156)
);

AOI22xp5_ASAP7_75t_L g157 ( 
.A1(n_120),
.A2(n_116),
.B1(n_123),
.B2(n_124),
.Y(n_157)
);

NAND2xp5_ASAP7_75t_L g158 ( 
.A(n_140),
.B(n_123),
.Y(n_158)
);

AOI21xp5_ASAP7_75t_L g159 ( 
.A1(n_136),
.A2(n_120),
.B(n_85),
.Y(n_159)
);

INVxp67_ASAP7_75t_L g160 ( 
.A(n_149),
.Y(n_160)
);

INVx1_ASAP7_75t_L g161 ( 
.A(n_133),
.Y(n_161)
);

INVxp67_ASAP7_75t_L g162 ( 
.A(n_137),
.Y(n_162)
);

AND2x4_ASAP7_75t_SL g163 ( 
.A(n_132),
.B(n_116),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_134),
.Y(n_164)
);

NAND2xp5_ASAP7_75t_L g165 ( 
.A(n_140),
.B(n_138),
.Y(n_165)
);

INVx1_ASAP7_75t_L g166 ( 
.A(n_135),
.Y(n_166)
);

INVx1_ASAP7_75t_L g167 ( 
.A(n_150),
.Y(n_167)
);

OR2x2_ASAP7_75t_L g168 ( 
.A(n_154),
.B(n_114),
.Y(n_168)
);

AND2x2_ASAP7_75t_L g169 ( 
.A(n_157),
.B(n_114),
.Y(n_169)
);

INVx1_ASAP7_75t_L g170 ( 
.A(n_130),
.Y(n_170)
);

NOR2x1_ASAP7_75t_L g171 ( 
.A(n_143),
.B(n_124),
.Y(n_171)
);

NAND2xp5_ASAP7_75t_L g172 ( 
.A(n_151),
.B(n_117),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_144),
.Y(n_173)
);

INVxp67_ASAP7_75t_L g174 ( 
.A(n_153),
.Y(n_174)
);

OAI22x1_ASAP7_75t_L g175 ( 
.A1(n_155),
.A2(n_119),
.B1(n_117),
.B2(n_127),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_144),
.Y(n_176)
);

AND2x4_ASAP7_75t_L g177 ( 
.A(n_151),
.B(n_119),
.Y(n_177)
);

NAND2xp5_ASAP7_75t_L g178 ( 
.A(n_145),
.B(n_117),
.Y(n_178)
);

INVx1_ASAP7_75t_SL g179 ( 
.A(n_147),
.Y(n_179)
);

INVx1_ASAP7_75t_L g180 ( 
.A(n_144),
.Y(n_180)
);

NAND2xp5_ASAP7_75t_L g181 ( 
.A(n_146),
.B(n_119),
.Y(n_181)
);

OR2x2_ASAP7_75t_L g182 ( 
.A(n_142),
.B(n_119),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_141),
.Y(n_183)
);

NAND2xp5_ASAP7_75t_L g184 ( 
.A(n_131),
.B(n_124),
.Y(n_184)
);

NAND2xp5_ASAP7_75t_SL g185 ( 
.A(n_139),
.B(n_152),
.Y(n_185)
);

INVx1_ASAP7_75t_L g186 ( 
.A(n_156),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_156),
.Y(n_187)
);

OAI22xp5_ASAP7_75t_L g188 ( 
.A1(n_148),
.A2(n_127),
.B1(n_128),
.B2(n_122),
.Y(n_188)
);

AOI222xp33_ASAP7_75t_L g189 ( 
.A1(n_185),
.A2(n_127),
.B1(n_122),
.B2(n_3),
.C1(n_2),
.C2(n_1),
.Y(n_189)
);

AOI221x1_ASAP7_75t_L g190 ( 
.A1(n_183),
.A2(n_128),
.B1(n_6),
.B2(n_4),
.C(n_5),
.Y(n_190)
);

OAI21xp5_ASAP7_75t_SL g191 ( 
.A1(n_178),
.A2(n_61),
.B(n_6),
.Y(n_191)
);

AOI322xp5_ASAP7_75t_L g192 ( 
.A1(n_185),
.A2(n_8),
.A3(n_7),
.B1(n_11),
.B2(n_13),
.C1(n_9),
.C2(n_10),
.Y(n_192)
);

NAND2xp5_ASAP7_75t_L g193 ( 
.A(n_165),
.B(n_177),
.Y(n_193)
);

AOI221xp5_ASAP7_75t_L g194 ( 
.A1(n_173),
.A2(n_9),
.B1(n_7),
.B2(n_11),
.C(n_13),
.Y(n_194)
);

INVx1_ASAP7_75t_L g195 ( 
.A(n_161),
.Y(n_195)
);

OAI221xp5_ASAP7_75t_SL g196 ( 
.A1(n_176),
.A2(n_17),
.B1(n_16),
.B2(n_18),
.C(n_19),
.Y(n_196)
);

AOI222xp33_ASAP7_75t_L g197 ( 
.A1(n_184),
.A2(n_19),
.B1(n_18),
.B2(n_20),
.C1(n_22),
.C2(n_21),
.Y(n_197)
);

NAND2xp5_ASAP7_75t_L g198 ( 
.A(n_177),
.B(n_20),
.Y(n_198)
);

INVx1_ASAP7_75t_L g199 ( 
.A(n_164),
.Y(n_199)
);

XNOR2xp5_ASAP7_75t_L g200 ( 
.A(n_175),
.B(n_21),
.Y(n_200)
);

NAND4xp25_ASAP7_75t_L g201 ( 
.A(n_180),
.B(n_24),
.C(n_23),
.D(n_22),
.Y(n_201)
);

AOI221xp5_ASAP7_75t_L g202 ( 
.A1(n_176),
.A2(n_25),
.B1(n_23),
.B2(n_26),
.C(n_27),
.Y(n_202)
);

OAI21xp33_ASAP7_75t_L g203 ( 
.A1(n_175),
.A2(n_181),
.B(n_179),
.Y(n_203)
);

OAI33xp33_ASAP7_75t_L g204 ( 
.A1(n_166),
.A2(n_28),
.A3(n_25),
.B1(n_29),
.B2(n_30),
.B3(n_59),
.Y(n_204)
);

NAND2xp5_ASAP7_75t_SL g205 ( 
.A(n_171),
.B(n_61),
.Y(n_205)
);

AOI221xp5_ASAP7_75t_L g206 ( 
.A1(n_186),
.A2(n_30),
.B1(n_29),
.B2(n_55),
.C(n_64),
.Y(n_206)
);

AOI221xp5_ASAP7_75t_L g207 ( 
.A1(n_187),
.A2(n_75),
.B1(n_82),
.B2(n_85),
.C(n_188),
.Y(n_207)
);

AOI31xp33_ASAP7_75t_L g208 ( 
.A1(n_160),
.A2(n_162),
.A3(n_159),
.B(n_182),
.Y(n_208)
);

NOR2x1_ASAP7_75t_L g209 ( 
.A(n_183),
.B(n_85),
.Y(n_209)
);

INVx1_ASAP7_75t_L g210 ( 
.A(n_167),
.Y(n_210)
);

OAI221xp5_ASAP7_75t_L g211 ( 
.A1(n_170),
.A2(n_75),
.B1(n_82),
.B2(n_85),
.C(n_182),
.Y(n_211)
);

AOI221xp5_ASAP7_75t_SL g212 ( 
.A1(n_174),
.A2(n_75),
.B1(n_82),
.B2(n_85),
.C(n_158),
.Y(n_212)
);

NAND2xp5_ASAP7_75t_SL g213 ( 
.A(n_193),
.B(n_208),
.Y(n_213)
);

NOR3xp33_ASAP7_75t_L g214 ( 
.A(n_191),
.B(n_169),
.C(n_172),
.Y(n_214)
);

NOR2x1_ASAP7_75t_L g215 ( 
.A(n_198),
.B(n_168),
.Y(n_215)
);

OAI22xp5_ASAP7_75t_L g216 ( 
.A1(n_196),
.A2(n_177),
.B1(n_169),
.B2(n_163),
.Y(n_216)
);

NAND2xp5_ASAP7_75t_L g217 ( 
.A(n_195),
.B(n_168),
.Y(n_217)
);

OAI21xp5_ASAP7_75t_L g218 ( 
.A1(n_200),
.A2(n_82),
.B(n_75),
.Y(n_218)
);

NAND2xp5_ASAP7_75t_L g219 ( 
.A(n_199),
.B(n_163),
.Y(n_219)
);

AOI22xp5_ASAP7_75t_L g220 ( 
.A1(n_197),
.A2(n_201),
.B1(n_200),
.B2(n_189),
.Y(n_220)
);

AOI22xp33_ASAP7_75t_L g221 ( 
.A1(n_204),
.A2(n_75),
.B1(n_85),
.B2(n_194),
.Y(n_221)
);

INVx2_ASAP7_75t_L g222 ( 
.A(n_210),
.Y(n_222)
);

NOR2x1_ASAP7_75t_L g223 ( 
.A(n_209),
.B(n_85),
.Y(n_223)
);

INVxp33_ASAP7_75t_L g224 ( 
.A(n_203),
.Y(n_224)
);

NOR2xp33_ASAP7_75t_L g225 ( 
.A(n_205),
.B(n_85),
.Y(n_225)
);

AND2x2_ASAP7_75t_L g226 ( 
.A(n_212),
.B(n_205),
.Y(n_226)
);

OR2x2_ASAP7_75t_L g227 ( 
.A(n_217),
.B(n_211),
.Y(n_227)
);

HB1xp67_ASAP7_75t_L g228 ( 
.A(n_222),
.Y(n_228)
);

BUFx2_ASAP7_75t_L g229 ( 
.A(n_215),
.Y(n_229)
);

NAND2xp5_ASAP7_75t_L g230 ( 
.A(n_226),
.B(n_224),
.Y(n_230)
);

OAI21xp5_ASAP7_75t_SL g231 ( 
.A1(n_220),
.A2(n_192),
.B(n_202),
.Y(n_231)
);

AOI221xp5_ASAP7_75t_L g232 ( 
.A1(n_214),
.A2(n_190),
.B1(n_206),
.B2(n_207),
.C(n_221),
.Y(n_232)
);

HB1xp67_ASAP7_75t_L g233 ( 
.A(n_219),
.Y(n_233)
);

BUFx2_ASAP7_75t_L g234 ( 
.A(n_216),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_228),
.Y(n_235)
);

NAND2xp5_ASAP7_75t_SL g236 ( 
.A(n_230),
.B(n_213),
.Y(n_236)
);

INVx2_ASAP7_75t_L g237 ( 
.A(n_233),
.Y(n_237)
);

OAI21xp5_ASAP7_75t_L g238 ( 
.A1(n_231),
.A2(n_221),
.B(n_190),
.Y(n_238)
);

AOI21xp5_ASAP7_75t_L g239 ( 
.A1(n_238),
.A2(n_236),
.B(n_234),
.Y(n_239)
);

OAI22xp5_ASAP7_75t_L g240 ( 
.A1(n_237),
.A2(n_232),
.B1(n_227),
.B2(n_233),
.Y(n_240)
);

AOI211xp5_ASAP7_75t_L g241 ( 
.A1(n_240),
.A2(n_237),
.B(n_235),
.C(n_218),
.Y(n_241)
);

AOI22xp33_ASAP7_75t_R g242 ( 
.A1(n_241),
.A2(n_239),
.B1(n_235),
.B2(n_229),
.Y(n_242)
);

AOI22xp5_ASAP7_75t_L g243 ( 
.A1(n_242),
.A2(n_223),
.B1(n_225),
.B2(n_240),
.Y(n_243)
);


endmodule