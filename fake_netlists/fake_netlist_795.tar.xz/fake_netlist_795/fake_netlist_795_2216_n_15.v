module fake_netlist_795_2216_n_15 (n_1, n_0, n_5, n_3, n_2, n_4, n_15);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_15;

wire n_7;
wire n_10;
wire n_11;
wire n_6;
wire n_14;
wire n_8;
wire n_12;
wire n_13;
wire n_9;

AND2x6_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_2),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_3),
.B1(n_0),
.B2(n_2),
.Y(n_7)
);

NAND3xp33_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_4),
.C(n_3),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_6),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_11),
.B(n_9),
.Y(n_13)
);

AOI21xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_8),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_0),
.B1(n_1),
.B2(n_5),
.C1(n_9),
.C2(n_6),
.Y(n_15)
);


endmodule