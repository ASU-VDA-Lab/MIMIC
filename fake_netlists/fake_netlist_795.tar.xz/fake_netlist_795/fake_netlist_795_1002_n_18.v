module fake_netlist_795_1002_n_18 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_18);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_18;

wire n_15;
wire n_11;
wire n_16;
wire n_17;
wire n_12;
wire n_9;
wire n_10;
wire n_13;
wire n_14;

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_3),
.B1(n_6),
.B2(n_4),
.Y(n_9)
);

BUFx6f_ASAP7_75t_SL g10 ( 
.A(n_6),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

AOI211x1_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_5),
.B(n_4),
.C(n_1),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI211xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B(n_7),
.C(n_1),
.Y(n_15)
);

NAND2x1p5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_7),
.B(n_0),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_8),
.Y(n_18)
);


endmodule