module fake_netlist_795_676_n_7 (n_1, n_2, n_0, n_7);

input n_1;
input n_2;
input n_0;

output n_7;

wire n_5;
wire n_6;
wire n_3;
wire n_4;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

OR2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);

NOR4xp25_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.C(n_1),
.D(n_0),
.Y(n_5)
);

NOR2x1p5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);


endmodule