module fake_netlist_795_1658_n_30 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_30);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_30;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_27;
wire n_26;
wire n_24;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_21;
wire n_22;

INVx2_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_1),
.A2(n_14),
.B(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_13),
.B1(n_11),
.B2(n_0),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_20),
.B(n_21),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

OAI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_16),
.B1(n_18),
.B2(n_11),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_27),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_SL g29 ( 
.A(n_28),
.B(n_4),
.C(n_2),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_R g30 ( 
.A1(n_29),
.A2(n_7),
.B1(n_6),
.B2(n_10),
.C(n_12),
.Y(n_30)
);


endmodule