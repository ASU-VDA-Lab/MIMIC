module fake_netlist_795_1362_n_19 (n_1, n_0, n_5, n_3, n_2, n_4, n_19);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_19;

wire n_6;
wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_14;

OR2x2_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_5),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_1),
.B(n_2),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_8),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_8),
.Y(n_12)
);

OAI22xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_8),
.B1(n_9),
.B2(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

NOR4xp25_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_14),
.C(n_11),
.D(n_9),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_16)
);

INVx4_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

OAI222xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_4),
.B1(n_17),
.B2(n_6),
.C1(n_13),
.C2(n_7),
.Y(n_19)
);


endmodule