module fake_netlist_795_2429_n_17 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_17);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_17;

wire n_15;
wire n_11;
wire n_16;
wire n_12;
wire n_9;
wire n_10;
wire n_13;
wire n_14;

INVx3_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

AND2x6_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_1),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_0),
.B(n_7),
.Y(n_11)
);

NOR4xp25_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.C(n_6),
.D(n_4),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI32xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.A3(n_10),
.B1(n_6),
.B2(n_2),
.Y(n_14)
);

AND4x1_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.C(n_8),
.D(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);


endmodule