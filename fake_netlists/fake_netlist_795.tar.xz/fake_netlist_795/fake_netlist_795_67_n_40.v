module fake_netlist_795_67_n_40 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_40);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_40;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_12;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_10;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_3),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_4),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

CKINVDCx6p67_ASAP7_75t_R g21 ( 
.A(n_17),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_R g22 ( 
.A(n_20),
.B(n_11),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

O2A1O1Ixp33_ASAP7_75t_SL g24 ( 
.A1(n_19),
.A2(n_12),
.B(n_15),
.C(n_13),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_21),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_29),
.B1(n_31),
.B2(n_27),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_10),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_22),
.B1(n_2),
.B2(n_1),
.Y(n_34)
);

NOR2xp67_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_22),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_6),
.B1(n_7),
.B2(n_35),
.Y(n_38)
);

CKINVDCx20_ASAP7_75t_R g39 ( 
.A(n_36),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_7),
.B1(n_36),
.B2(n_39),
.Y(n_40)
);


endmodule