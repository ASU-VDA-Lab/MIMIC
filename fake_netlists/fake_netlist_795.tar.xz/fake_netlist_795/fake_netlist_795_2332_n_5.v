module fake_netlist_795_2332_n_5 (n_1, n_2, n_0, n_5);

input n_1;
input n_2;
input n_0;

output n_5;

wire n_3;
wire n_4;

AND2x2_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

OR2x2_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_0),
.Y(n_4)
);

OAI211xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_5)
);


endmodule