module fake_netlist_795_1191_n_22 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_22);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_22;

wire n_20;
wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_10;
wire n_19;
wire n_21;
wire n_14;

BUFx3_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_11),
.Y(n_13)
);

NAND2x1p5_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

NAND4xp25_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.C(n_12),
.D(n_10),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_3),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_8),
.C(n_7),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);


endmodule