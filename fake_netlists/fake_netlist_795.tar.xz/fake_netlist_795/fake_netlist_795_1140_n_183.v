module fake_netlist_795_1140_n_183 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_25, n_5, n_27, n_24, n_26, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_183);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_25;
input n_5;
input n_27;
input n_24;
input n_26;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_183;

wire n_37;
wire n_55;
wire n_36;
wire n_116;
wire n_63;
wire n_140;
wire n_153;
wire n_65;
wire n_35;
wire n_100;
wire n_40;
wire n_73;
wire n_119;
wire n_101;
wire n_42;
wire n_105;
wire n_124;
wire n_107;
wire n_48;
wire n_43;
wire n_158;
wire n_68;
wire n_67;
wire n_54;
wire n_179;
wire n_127;
wire n_132;
wire n_166;
wire n_30;
wire n_59;
wire n_53;
wire n_79;
wire n_181;
wire n_74;
wire n_104;
wire n_146;
wire n_85;
wire n_51;
wire n_89;
wire n_106;
wire n_168;
wire n_178;
wire n_182;
wire n_102;
wire n_143;
wire n_45;
wire n_83;
wire n_62;
wire n_75;
wire n_165;
wire n_31;
wire n_117;
wire n_121;
wire n_96;
wire n_169;
wire n_180;
wire n_76;
wire n_174;
wire n_148;
wire n_175;
wire n_128;
wire n_88;
wire n_171;
wire n_84;
wire n_28;
wire n_155;
wire n_156;
wire n_152;
wire n_90;
wire n_103;
wire n_126;
wire n_139;
wire n_151;
wire n_147;
wire n_164;
wire n_86;
wire n_82;
wire n_129;
wire n_123;
wire n_150;
wire n_177;
wire n_176;
wire n_64;
wire n_29;
wire n_167;
wire n_92;
wire n_91;
wire n_70;
wire n_125;
wire n_69;
wire n_137;
wire n_71;
wire n_145;
wire n_133;
wire n_49;
wire n_142;
wire n_109;
wire n_122;
wire n_56;
wire n_61;
wire n_78;
wire n_112;
wire n_161;
wire n_157;
wire n_110;
wire n_118;
wire n_111;
wire n_149;
wire n_32;
wire n_170;
wire n_47;
wire n_163;
wire n_172;
wire n_159;
wire n_44;
wire n_52;
wire n_77;
wire n_138;
wire n_130;
wire n_160;
wire n_50;
wire n_58;
wire n_108;
wire n_162;
wire n_97;
wire n_66;
wire n_173;
wire n_94;
wire n_141;
wire n_34;
wire n_39;
wire n_46;
wire n_154;
wire n_33;
wire n_136;
wire n_135;
wire n_144;
wire n_113;
wire n_114;
wire n_81;
wire n_95;
wire n_98;
wire n_38;
wire n_80;
wire n_99;
wire n_87;
wire n_60;
wire n_115;
wire n_57;
wire n_120;
wire n_134;
wire n_93;
wire n_131;
wire n_41;
wire n_72;

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_1),
.Y(n_28)
);

INVxp33_ASAP7_75t_SL g29 ( 
.A(n_27),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_10),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_8),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_23),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_19),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_0),
.Y(n_36)
);

INVxp33_ASAP7_75t_SL g37 ( 
.A(n_22),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_15),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_11),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_1),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_20),
.Y(n_41)
);

INVxp33_ASAP7_75t_L g42 ( 
.A(n_33),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_33),
.Y(n_43)
);

BUFx10_ASAP7_75t_L g44 ( 
.A(n_33),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

NAND2xp33_ASAP7_75t_SL g46 ( 
.A(n_41),
.B(n_20),
.Y(n_46)
);

INVx2_ASAP7_75t_SL g47 ( 
.A(n_41),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_SL g48 ( 
.A(n_29),
.B(n_20),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_31),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_43),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_28),
.Y(n_51)
);

NAND3xp33_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_32),
.C(n_31),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_SL g53 ( 
.A(n_44),
.B(n_29),
.Y(n_53)
);

OAI21xp33_ASAP7_75t_L g54 ( 
.A1(n_42),
.A2(n_32),
.B(n_31),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_43),
.Y(n_55)
);

OAI21xp5_ASAP7_75t_L g56 ( 
.A1(n_42),
.A2(n_35),
.B(n_32),
.Y(n_56)
);

AOI22xp33_ASAP7_75t_L g57 ( 
.A1(n_46),
.A2(n_37),
.B1(n_38),
.B2(n_35),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_46),
.A2(n_37),
.B1(n_36),
.B2(n_30),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_48),
.B1(n_36),
.B2(n_34),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_50),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_50),
.Y(n_61)
);

OAI21xp5_ASAP7_75t_L g62 ( 
.A1(n_52),
.A2(n_47),
.B(n_43),
.Y(n_62)
);

A2O1A1Ixp33_ASAP7_75t_L g63 ( 
.A1(n_56),
.A2(n_52),
.B(n_54),
.C(n_58),
.Y(n_63)
);

AOI21xp5_ASAP7_75t_L g64 ( 
.A1(n_51),
.A2(n_53),
.B(n_54),
.Y(n_64)
);

A2O1A1Ixp33_ASAP7_75t_L g65 ( 
.A1(n_58),
.A2(n_47),
.B(n_38),
.C(n_35),
.Y(n_65)
);

BUFx3_ASAP7_75t_L g66 ( 
.A(n_50),
.Y(n_66)
);

NAND2xp5_ASAP7_75t_L g67 ( 
.A(n_55),
.B(n_44),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_SL g68 ( 
.A(n_55),
.B(n_44),
.Y(n_68)
);

AO31x2_ASAP7_75t_L g69 ( 
.A1(n_55),
.A2(n_45),
.A3(n_43),
.B(n_38),
.Y(n_69)
);

NAND2xp5_ASAP7_75t_L g70 ( 
.A(n_64),
.B(n_44),
.Y(n_70)
);

O2A1O1Ixp33_ASAP7_75t_L g71 ( 
.A1(n_63),
.A2(n_47),
.B(n_49),
.C(n_45),
.Y(n_71)
);

OAI31xp33_ASAP7_75t_L g72 ( 
.A1(n_65),
.A2(n_40),
.A3(n_39),
.B(n_49),
.Y(n_72)
);

A2O1A1Ixp33_ASAP7_75t_L g73 ( 
.A1(n_64),
.A2(n_40),
.B(n_39),
.C(n_45),
.Y(n_73)
);

INVx2_ASAP7_75t_L g74 ( 
.A(n_60),
.Y(n_74)
);

NAND2xp5_ASAP7_75t_L g75 ( 
.A(n_62),
.B(n_60),
.Y(n_75)
);

OAI22xp5_ASAP7_75t_L g76 ( 
.A1(n_59),
.A2(n_40),
.B1(n_39),
.B2(n_49),
.Y(n_76)
);

O2A1O1Ixp33_ASAP7_75t_L g77 ( 
.A1(n_62),
.A2(n_45),
.B(n_44),
.C(n_21),
.Y(n_77)
);

AOI21xp5_ASAP7_75t_L g78 ( 
.A1(n_67),
.A2(n_68),
.B(n_61),
.Y(n_78)
);

CKINVDCx20_ASAP7_75t_R g79 ( 
.A(n_59),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_61),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_75),
.B(n_67),
.Y(n_81)
);

INVx2_ASAP7_75t_L g82 ( 
.A(n_74),
.Y(n_82)
);

AOI22xp33_ASAP7_75t_L g83 ( 
.A1(n_76),
.A2(n_44),
.B1(n_66),
.B2(n_69),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_74),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_80),
.Y(n_85)
);

OR2x2_ASAP7_75t_L g86 ( 
.A(n_76),
.B(n_69),
.Y(n_86)
);

AND2x2_ASAP7_75t_L g87 ( 
.A(n_75),
.B(n_69),
.Y(n_87)
);

INVx2_ASAP7_75t_SL g88 ( 
.A(n_80),
.Y(n_88)
);

AND2x2_ASAP7_75t_L g89 ( 
.A(n_73),
.B(n_74),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_85),
.Y(n_90)
);

BUFx2_ASAP7_75t_L g91 ( 
.A(n_89),
.Y(n_91)
);

NAND2xp5_ASAP7_75t_L g92 ( 
.A(n_85),
.B(n_81),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_85),
.Y(n_93)
);

HB1xp67_ASAP7_75t_L g94 ( 
.A(n_88),
.Y(n_94)
);

INVx3_ASAP7_75t_L g95 ( 
.A(n_88),
.Y(n_95)
);

INVx2_ASAP7_75t_L g96 ( 
.A(n_88),
.Y(n_96)
);

INVx2_ASAP7_75t_SL g97 ( 
.A(n_88),
.Y(n_97)
);

AND2x2_ASAP7_75t_L g98 ( 
.A(n_91),
.B(n_87),
.Y(n_98)
);

AND2x2_ASAP7_75t_L g99 ( 
.A(n_91),
.B(n_87),
.Y(n_99)
);

NAND2xp5_ASAP7_75t_L g100 ( 
.A(n_92),
.B(n_81),
.Y(n_100)
);

HB1xp67_ASAP7_75t_L g101 ( 
.A(n_94),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_90),
.Y(n_102)
);

INVx1_ASAP7_75t_SL g103 ( 
.A(n_91),
.Y(n_103)
);

NAND2xp5_ASAP7_75t_L g104 ( 
.A(n_92),
.B(n_91),
.Y(n_104)
);

INVx2_ASAP7_75t_L g105 ( 
.A(n_96),
.Y(n_105)
);

NAND2xp5_ASAP7_75t_L g106 ( 
.A(n_104),
.B(n_79),
.Y(n_106)
);

OAI222xp33_ASAP7_75t_L g107 ( 
.A1(n_103),
.A2(n_77),
.B1(n_86),
.B2(n_92),
.C1(n_83),
.C2(n_71),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_102),
.Y(n_108)
);

INVx2_ASAP7_75t_SL g109 ( 
.A(n_101),
.Y(n_109)
);

NAND2xp5_ASAP7_75t_L g110 ( 
.A(n_104),
.B(n_100),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_100),
.B(n_98),
.Y(n_111)
);

AOI22xp5_ASAP7_75t_L g112 ( 
.A1(n_103),
.A2(n_89),
.B1(n_81),
.B2(n_87),
.Y(n_112)
);

O2A1O1Ixp33_ASAP7_75t_L g113 ( 
.A1(n_101),
.A2(n_77),
.B(n_72),
.C(n_94),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_102),
.Y(n_114)
);

OR2x2_ASAP7_75t_L g115 ( 
.A(n_99),
.B(n_86),
.Y(n_115)
);

AOI22xp5_ASAP7_75t_L g116 ( 
.A1(n_106),
.A2(n_99),
.B1(n_98),
.B2(n_89),
.Y(n_116)
);

OR2x2_ASAP7_75t_L g117 ( 
.A(n_115),
.B(n_98),
.Y(n_117)
);

OAI221xp5_ASAP7_75t_SL g118 ( 
.A1(n_113),
.A2(n_72),
.B1(n_71),
.B2(n_83),
.C(n_86),
.Y(n_118)
);

NAND3xp33_ASAP7_75t_L g119 ( 
.A(n_109),
.B(n_86),
.C(n_89),
.Y(n_119)
);

AOI221xp5_ASAP7_75t_L g120 ( 
.A1(n_107),
.A2(n_93),
.B1(n_90),
.B2(n_99),
.C(n_70),
.Y(n_120)
);

OAI32xp33_ASAP7_75t_L g121 ( 
.A1(n_108),
.A2(n_90),
.A3(n_93),
.B1(n_70),
.B2(n_94),
.Y(n_121)
);

NAND2xp5_ASAP7_75t_L g122 ( 
.A(n_110),
.B(n_105),
.Y(n_122)
);

AOI21xp5_ASAP7_75t_L g123 ( 
.A1(n_112),
.A2(n_97),
.B(n_96),
.Y(n_123)
);

AOI211xp5_ASAP7_75t_L g124 ( 
.A1(n_108),
.A2(n_93),
.B(n_90),
.C(n_44),
.Y(n_124)
);

AOI222xp33_ASAP7_75t_L g125 ( 
.A1(n_111),
.A2(n_93),
.B1(n_87),
.B2(n_24),
.C1(n_22),
.C2(n_21),
.Y(n_125)
);

AOI221xp5_ASAP7_75t_L g126 ( 
.A1(n_109),
.A2(n_105),
.B1(n_78),
.B2(n_96),
.C(n_97),
.Y(n_126)
);

AOI222xp33_ASAP7_75t_L g127 ( 
.A1(n_114),
.A2(n_24),
.B1(n_22),
.B2(n_25),
.C1(n_27),
.C2(n_26),
.Y(n_127)
);

NOR2xp33_ASAP7_75t_L g128 ( 
.A(n_114),
.B(n_95),
.Y(n_128)
);

HB1xp67_ASAP7_75t_L g129 ( 
.A(n_115),
.Y(n_129)
);

AND2x2_ASAP7_75t_L g130 ( 
.A(n_129),
.B(n_105),
.Y(n_130)
);

NAND2xp5_ASAP7_75t_L g131 ( 
.A(n_128),
.B(n_122),
.Y(n_131)
);

NAND2xp5_ASAP7_75t_L g132 ( 
.A(n_128),
.B(n_96),
.Y(n_132)
);

INVx2_ASAP7_75t_SL g133 ( 
.A(n_117),
.Y(n_133)
);

INVx2_ASAP7_75t_SL g134 ( 
.A(n_119),
.Y(n_134)
);

NAND2xp5_ASAP7_75t_L g135 ( 
.A(n_120),
.B(n_123),
.Y(n_135)
);

INVx2_ASAP7_75t_SL g136 ( 
.A(n_116),
.Y(n_136)
);

OAI221xp5_ASAP7_75t_L g137 ( 
.A1(n_125),
.A2(n_97),
.B1(n_95),
.B2(n_96),
.C(n_78),
.Y(n_137)
);

INVx2_ASAP7_75t_L g138 ( 
.A(n_121),
.Y(n_138)
);

NAND3xp33_ASAP7_75t_L g139 ( 
.A(n_127),
.B(n_84),
.C(n_82),
.Y(n_139)
);

INVx1_ASAP7_75t_L g140 ( 
.A(n_126),
.Y(n_140)
);

NAND2xp5_ASAP7_75t_L g141 ( 
.A(n_124),
.B(n_96),
.Y(n_141)
);

NOR2x1p5_ASAP7_75t_L g142 ( 
.A(n_118),
.B(n_95),
.Y(n_142)
);

AND2x2_ASAP7_75t_L g143 ( 
.A(n_129),
.B(n_97),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_128),
.Y(n_144)
);

NAND3xp33_ASAP7_75t_L g145 ( 
.A(n_127),
.B(n_84),
.C(n_82),
.Y(n_145)
);

INVxp67_ASAP7_75t_SL g146 ( 
.A(n_128),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_133),
.Y(n_147)
);

XNOR2x1_ASAP7_75t_L g148 ( 
.A(n_142),
.B(n_24),
.Y(n_148)
);

AND2x2_ASAP7_75t_L g149 ( 
.A(n_133),
.B(n_25),
.Y(n_149)
);

OAI322xp33_ASAP7_75t_SL g150 ( 
.A1(n_135),
.A2(n_27),
.A3(n_26),
.B1(n_25),
.B2(n_2),
.C1(n_0),
.C2(n_3),
.Y(n_150)
);

NAND2xp33_ASAP7_75t_SL g151 ( 
.A(n_142),
.B(n_97),
.Y(n_151)
);

OR2x2_ASAP7_75t_L g152 ( 
.A(n_133),
.B(n_26),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_130),
.Y(n_153)
);

NOR5xp2_ASAP7_75t_L g154 ( 
.A(n_137),
.B(n_3),
.C(n_2),
.D(n_4),
.E(n_5),
.Y(n_154)
);

OAI21xp5_ASAP7_75t_L g155 ( 
.A1(n_135),
.A2(n_134),
.B(n_140),
.Y(n_155)
);

OAI322xp33_ASAP7_75t_SL g156 ( 
.A1(n_138),
.A2(n_5),
.A3(n_4),
.B1(n_8),
.B2(n_9),
.C1(n_6),
.C2(n_7),
.Y(n_156)
);

OAI321xp33_ASAP7_75t_L g157 ( 
.A1(n_134),
.A2(n_84),
.A3(n_82),
.B1(n_9),
.B2(n_7),
.C(n_6),
.Y(n_157)
);

OAI311xp33_ASAP7_75t_L g158 ( 
.A1(n_137),
.A2(n_11),
.A3(n_10),
.B1(n_12),
.C1(n_13),
.Y(n_158)
);

NAND2xp5_ASAP7_75t_L g159 ( 
.A(n_131),
.B(n_12),
.Y(n_159)
);

NOR2xp67_ASAP7_75t_L g160 ( 
.A(n_134),
.B(n_13),
.Y(n_160)
);

AOI22xp5_ASAP7_75t_L g161 ( 
.A1(n_136),
.A2(n_95),
.B1(n_84),
.B2(n_82),
.Y(n_161)
);

A2O1A1Ixp33_ASAP7_75t_L g162 ( 
.A1(n_156),
.A2(n_136),
.B(n_138),
.C(n_140),
.Y(n_162)
);

AOI322xp5_ASAP7_75t_L g163 ( 
.A1(n_156),
.A2(n_150),
.A3(n_136),
.B1(n_159),
.B2(n_138),
.C1(n_149),
.C2(n_151),
.Y(n_163)
);

AND2x2_ASAP7_75t_L g164 ( 
.A(n_153),
.B(n_146),
.Y(n_164)
);

OAI22xp5_ASAP7_75t_L g165 ( 
.A1(n_148),
.A2(n_141),
.B1(n_146),
.B2(n_144),
.Y(n_165)
);

NOR3xp33_ASAP7_75t_L g166 ( 
.A(n_155),
.B(n_139),
.C(n_145),
.Y(n_166)
);

AOI322xp5_ASAP7_75t_L g167 ( 
.A1(n_150),
.A2(n_141),
.A3(n_144),
.B1(n_131),
.B2(n_143),
.C1(n_132),
.C2(n_130),
.Y(n_167)
);

AOI322xp5_ASAP7_75t_L g168 ( 
.A1(n_149),
.A2(n_143),
.A3(n_132),
.B1(n_130),
.B2(n_15),
.C1(n_14),
.C2(n_16),
.Y(n_168)
);

OAI31xp33_ASAP7_75t_L g169 ( 
.A1(n_158),
.A2(n_139),
.A3(n_145),
.B(n_143),
.Y(n_169)
);

AOI221xp5_ASAP7_75t_L g170 ( 
.A1(n_157),
.A2(n_16),
.B1(n_14),
.B2(n_17),
.C(n_18),
.Y(n_170)
);

AOI221xp5_ASAP7_75t_SL g171 ( 
.A1(n_147),
.A2(n_23),
.B1(n_18),
.B2(n_17),
.C(n_95),
.Y(n_171)
);

OAI322xp33_ASAP7_75t_L g172 ( 
.A1(n_148),
.A2(n_66),
.A3(n_69),
.B1(n_95),
.B2(n_152),
.C1(n_153),
.C2(n_147),
.Y(n_172)
);

INVxp67_ASAP7_75t_L g173 ( 
.A(n_165),
.Y(n_173)
);

BUFx4f_ASAP7_75t_L g174 ( 
.A(n_171),
.Y(n_174)
);

AOI21x1_ASAP7_75t_L g175 ( 
.A1(n_164),
.A2(n_160),
.B(n_163),
.Y(n_175)
);

OAI22xp5_ASAP7_75t_L g176 ( 
.A1(n_162),
.A2(n_160),
.B1(n_161),
.B2(n_154),
.Y(n_176)
);

NAND3xp33_ASAP7_75t_L g177 ( 
.A(n_166),
.B(n_161),
.C(n_95),
.Y(n_177)
);

OAI22xp5_ASAP7_75t_L g178 ( 
.A1(n_173),
.A2(n_170),
.B1(n_169),
.B2(n_172),
.Y(n_178)
);

NAND2xp5_ASAP7_75t_L g179 ( 
.A(n_173),
.B(n_167),
.Y(n_179)
);

OAI22xp5_ASAP7_75t_SL g180 ( 
.A1(n_176),
.A2(n_168),
.B1(n_95),
.B2(n_69),
.Y(n_180)
);

AOI21xp33_ASAP7_75t_L g181 ( 
.A1(n_178),
.A2(n_174),
.B(n_177),
.Y(n_181)
);

OR2x2_ASAP7_75t_L g182 ( 
.A(n_179),
.B(n_175),
.Y(n_182)
);

AOI22xp5_ASAP7_75t_L g183 ( 
.A1(n_182),
.A2(n_180),
.B1(n_181),
.B2(n_174),
.Y(n_183)
);


endmodule