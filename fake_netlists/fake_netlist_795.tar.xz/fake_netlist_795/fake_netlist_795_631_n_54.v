module fake_netlist_795_631_n_54 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_54);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_54;

wire n_37;
wire n_45;
wire n_44;
wire n_20;
wire n_52;
wire n_29;
wire n_36;
wire n_17;
wire n_50;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_18;
wire n_48;
wire n_43;
wire n_49;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;
wire n_47;

INVx3_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_8),
.B(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_1),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_10),
.Y(n_23)
);

INVx6_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

BUFx12f_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_17),
.B(n_0),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_21),
.B(n_19),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

AO21x2_ASAP7_75t_L g31 ( 
.A1(n_26),
.A2(n_20),
.B(n_17),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_25),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_27),
.Y(n_34)
);

OAI21xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_22),
.B(n_26),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_31),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_34),
.Y(n_39)
);

OAI21xp33_ASAP7_75t_SL g40 ( 
.A1(n_36),
.A2(n_32),
.B(n_35),
.Y(n_40)
);

XOR2xp5_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_23),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_22),
.B1(n_18),
.B2(n_17),
.C(n_23),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_18),
.B(n_7),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_9),
.Y(n_45)
);

NAND3xp33_ASAP7_75t_SL g46 ( 
.A(n_43),
.B(n_24),
.C(n_0),
.Y(n_46)
);

NAND4xp75_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_5),
.C(n_4),
.D(n_1),
.Y(n_47)
);

OAI211xp5_ASAP7_75t_L g48 ( 
.A1(n_41),
.A2(n_18),
.B(n_16),
.C(n_6),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_18),
.Y(n_50)
);

NAND2x1_ASAP7_75t_L g51 ( 
.A(n_45),
.B(n_47),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_46),
.B1(n_16),
.B2(n_11),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

AOI222xp33_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_12),
.B1(n_14),
.B2(n_15),
.C1(n_50),
.C2(n_53),
.Y(n_54)
);


endmodule