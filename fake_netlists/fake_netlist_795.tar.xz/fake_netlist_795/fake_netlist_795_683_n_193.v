module fake_netlist_795_683_n_193 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_24, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_193);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_24;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_193;

wire n_37;
wire n_183;
wire n_55;
wire n_36;
wire n_116;
wire n_63;
wire n_140;
wire n_153;
wire n_65;
wire n_35;
wire n_100;
wire n_25;
wire n_40;
wire n_73;
wire n_119;
wire n_101;
wire n_42;
wire n_105;
wire n_124;
wire n_186;
wire n_187;
wire n_107;
wire n_48;
wire n_43;
wire n_158;
wire n_68;
wire n_67;
wire n_184;
wire n_54;
wire n_179;
wire n_127;
wire n_132;
wire n_166;
wire n_30;
wire n_59;
wire n_53;
wire n_79;
wire n_181;
wire n_74;
wire n_104;
wire n_146;
wire n_85;
wire n_51;
wire n_89;
wire n_106;
wire n_168;
wire n_178;
wire n_182;
wire n_102;
wire n_143;
wire n_45;
wire n_83;
wire n_62;
wire n_75;
wire n_165;
wire n_31;
wire n_117;
wire n_121;
wire n_96;
wire n_169;
wire n_180;
wire n_185;
wire n_76;
wire n_174;
wire n_148;
wire n_175;
wire n_128;
wire n_88;
wire n_171;
wire n_84;
wire n_28;
wire n_155;
wire n_156;
wire n_152;
wire n_90;
wire n_103;
wire n_126;
wire n_139;
wire n_151;
wire n_147;
wire n_164;
wire n_82;
wire n_86;
wire n_129;
wire n_123;
wire n_150;
wire n_177;
wire n_176;
wire n_64;
wire n_29;
wire n_188;
wire n_167;
wire n_92;
wire n_189;
wire n_91;
wire n_70;
wire n_125;
wire n_69;
wire n_137;
wire n_71;
wire n_26;
wire n_145;
wire n_133;
wire n_49;
wire n_142;
wire n_109;
wire n_122;
wire n_56;
wire n_61;
wire n_78;
wire n_112;
wire n_161;
wire n_157;
wire n_190;
wire n_110;
wire n_118;
wire n_111;
wire n_149;
wire n_32;
wire n_170;
wire n_47;
wire n_163;
wire n_172;
wire n_159;
wire n_44;
wire n_52;
wire n_77;
wire n_138;
wire n_130;
wire n_160;
wire n_50;
wire n_58;
wire n_108;
wire n_162;
wire n_97;
wire n_66;
wire n_173;
wire n_94;
wire n_27;
wire n_141;
wire n_34;
wire n_39;
wire n_46;
wire n_154;
wire n_33;
wire n_136;
wire n_135;
wire n_144;
wire n_113;
wire n_114;
wire n_81;
wire n_95;
wire n_98;
wire n_38;
wire n_80;
wire n_99;
wire n_192;
wire n_87;
wire n_191;
wire n_60;
wire n_115;
wire n_57;
wire n_120;
wire n_134;
wire n_93;
wire n_131;
wire n_41;
wire n_72;

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_0),
.Y(n_25)
);

INVxp33_ASAP7_75t_SL g26 ( 
.A(n_13),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_3),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_19),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_8),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_16),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_23),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_1),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_19),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_14),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_20),
.Y(n_38)
);

INVx3_ASAP7_75t_L g39 ( 
.A(n_27),
.Y(n_39)
);

INVxp67_ASAP7_75t_SL g40 ( 
.A(n_28),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_28),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_38),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_29),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_27),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_29),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_31),
.Y(n_46)
);

INVx4_ASAP7_75t_L g47 ( 
.A(n_35),
.Y(n_47)
);

NAND2xp33_ASAP7_75t_L g48 ( 
.A(n_31),
.B(n_32),
.Y(n_48)
);

NOR2x1_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_25),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_26),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_44),
.Y(n_51)
);

AND3x1_ASAP7_75t_L g52 ( 
.A(n_41),
.B(n_33),
.C(n_32),
.Y(n_52)
);

BUFx6f_ASAP7_75t_L g53 ( 
.A(n_44),
.Y(n_53)
);

NAND3xp33_ASAP7_75t_SL g54 ( 
.A(n_41),
.B(n_42),
.C(n_38),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_39),
.B(n_33),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_43),
.Y(n_56)
);

BUFx6f_ASAP7_75t_L g57 ( 
.A(n_44),
.Y(n_57)
);

INVx4_ASAP7_75t_L g58 ( 
.A(n_47),
.Y(n_58)
);

AOI21xp5_ASAP7_75t_L g59 ( 
.A1(n_48),
.A2(n_37),
.B(n_34),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_44),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_56),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_50),
.B(n_47),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_L g63 ( 
.A(n_59),
.B(n_47),
.Y(n_63)
);

NOR2xp67_ASAP7_75t_L g64 ( 
.A(n_58),
.B(n_47),
.Y(n_64)
);

NOR2xp67_ASAP7_75t_L g65 ( 
.A(n_54),
.B(n_47),
.Y(n_65)
);

AO31x2_ASAP7_75t_L g66 ( 
.A1(n_55),
.A2(n_59),
.A3(n_44),
.B(n_56),
.Y(n_66)
);

INVxp67_ASAP7_75t_L g67 ( 
.A(n_55),
.Y(n_67)
);

AO22x2_ASAP7_75t_L g68 ( 
.A1(n_54),
.A2(n_40),
.B1(n_42),
.B2(n_39),
.Y(n_68)
);

AOI21xp5_ASAP7_75t_L g69 ( 
.A1(n_58),
.A2(n_48),
.B(n_40),
.Y(n_69)
);

AOI21xp5_ASAP7_75t_L g70 ( 
.A1(n_58),
.A2(n_40),
.B(n_39),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_58),
.B(n_47),
.Y(n_71)
);

NAND3x1_ASAP7_75t_L g72 ( 
.A(n_49),
.B(n_37),
.C(n_41),
.Y(n_72)
);

NOR2xp33_ASAP7_75t_L g73 ( 
.A(n_49),
.B(n_42),
.Y(n_73)
);

HB1xp67_ASAP7_75t_L g74 ( 
.A(n_52),
.Y(n_74)
);

INVx2_ASAP7_75t_L g75 ( 
.A(n_61),
.Y(n_75)
);

AOI221x1_ASAP7_75t_SL g76 ( 
.A1(n_73),
.A2(n_46),
.B1(n_43),
.B2(n_52),
.C(n_45),
.Y(n_76)
);

OAI22xp5_ASAP7_75t_L g77 ( 
.A1(n_68),
.A2(n_45),
.B1(n_43),
.B2(n_39),
.Y(n_77)
);

NOR2xp67_ASAP7_75t_L g78 ( 
.A(n_69),
.B(n_39),
.Y(n_78)
);

AND2x2_ASAP7_75t_L g79 ( 
.A(n_67),
.B(n_45),
.Y(n_79)
);

HB1xp67_ASAP7_75t_L g80 ( 
.A(n_74),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_61),
.Y(n_81)
);

AND2x2_ASAP7_75t_L g82 ( 
.A(n_68),
.B(n_43),
.Y(n_82)
);

OAI22xp5_ASAP7_75t_L g83 ( 
.A1(n_68),
.A2(n_39),
.B1(n_30),
.B2(n_46),
.Y(n_83)
);

OR2x2_ASAP7_75t_L g84 ( 
.A(n_66),
.B(n_70),
.Y(n_84)
);

AOI21x1_ASAP7_75t_SL g85 ( 
.A1(n_63),
.A2(n_57),
.B(n_53),
.Y(n_85)
);

AOI211xp5_ASAP7_75t_L g86 ( 
.A1(n_65),
.A2(n_46),
.B(n_39),
.C(n_51),
.Y(n_86)
);

AND2x2_ASAP7_75t_L g87 ( 
.A(n_79),
.B(n_82),
.Y(n_87)
);

AND2x2_ASAP7_75t_L g88 ( 
.A(n_79),
.B(n_68),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_75),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_75),
.Y(n_90)
);

INVx2_ASAP7_75t_L g91 ( 
.A(n_75),
.Y(n_91)
);

BUFx6f_ASAP7_75t_L g92 ( 
.A(n_84),
.Y(n_92)
);

INVx2_ASAP7_75t_L g93 ( 
.A(n_81),
.Y(n_93)
);

AND2x2_ASAP7_75t_L g94 ( 
.A(n_79),
.B(n_66),
.Y(n_94)
);

AND2x4_ASAP7_75t_L g95 ( 
.A(n_82),
.B(n_66),
.Y(n_95)
);

AND2x4_ASAP7_75t_L g96 ( 
.A(n_95),
.B(n_82),
.Y(n_96)
);

INVx3_ASAP7_75t_L g97 ( 
.A(n_93),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_94),
.B(n_81),
.Y(n_98)
);

INVx4_ASAP7_75t_SL g99 ( 
.A(n_92),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_91),
.Y(n_100)
);

AND2x6_ASAP7_75t_SL g101 ( 
.A(n_88),
.B(n_76),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_93),
.Y(n_102)
);

AND2x4_ASAP7_75t_L g103 ( 
.A(n_95),
.B(n_84),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_102),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_102),
.Y(n_105)
);

AOI322xp5_ASAP7_75t_SL g106 ( 
.A1(n_101),
.A2(n_88),
.A3(n_30),
.B1(n_36),
.B2(n_76),
.C1(n_72),
.C2(n_83),
.Y(n_106)
);

NAND2xp5_ASAP7_75t_L g107 ( 
.A(n_96),
.B(n_87),
.Y(n_107)
);

NOR2xp67_ASAP7_75t_L g108 ( 
.A(n_102),
.B(n_80),
.Y(n_108)
);

INVx2_ASAP7_75t_SL g109 ( 
.A(n_97),
.Y(n_109)
);

BUFx2_ASAP7_75t_L g110 ( 
.A(n_96),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_97),
.Y(n_111)
);

NAND2xp5_ASAP7_75t_L g112 ( 
.A(n_96),
.B(n_87),
.Y(n_112)
);

NOR2xp33_ASAP7_75t_L g113 ( 
.A(n_112),
.B(n_87),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_104),
.Y(n_114)
);

INVxp67_ASAP7_75t_L g115 ( 
.A(n_108),
.Y(n_115)
);

INVx1_ASAP7_75t_SL g116 ( 
.A(n_107),
.Y(n_116)
);

OAI22xp5_ASAP7_75t_L g117 ( 
.A1(n_106),
.A2(n_72),
.B1(n_98),
.B2(n_83),
.Y(n_117)
);

NAND2xp5_ASAP7_75t_L g118 ( 
.A(n_110),
.B(n_88),
.Y(n_118)
);

INVx2_ASAP7_75t_L g119 ( 
.A(n_104),
.Y(n_119)
);

INVxp67_ASAP7_75t_L g120 ( 
.A(n_110),
.Y(n_120)
);

INVx1_ASAP7_75t_L g121 ( 
.A(n_105),
.Y(n_121)
);

AOI221xp5_ASAP7_75t_L g122 ( 
.A1(n_106),
.A2(n_77),
.B1(n_94),
.B2(n_98),
.C(n_93),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_105),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_111),
.B(n_94),
.Y(n_124)
);

INVx2_ASAP7_75t_SL g125 ( 
.A(n_109),
.Y(n_125)
);

AOI322xp5_ASAP7_75t_L g126 ( 
.A1(n_111),
.A2(n_101),
.A3(n_96),
.B1(n_98),
.B2(n_95),
.C1(n_93),
.C2(n_89),
.Y(n_126)
);

AOI322xp5_ASAP7_75t_L g127 ( 
.A1(n_122),
.A2(n_96),
.A3(n_101),
.B1(n_6),
.B2(n_7),
.C1(n_4),
.C2(n_5),
.Y(n_127)
);

OAI221xp5_ASAP7_75t_L g128 ( 
.A1(n_117),
.A2(n_77),
.B1(n_86),
.B2(n_62),
.C(n_109),
.Y(n_128)
);

AOI221x1_ASAP7_75t_L g129 ( 
.A1(n_114),
.A2(n_97),
.B1(n_90),
.B2(n_89),
.C(n_95),
.Y(n_129)
);

NAND4xp25_ASAP7_75t_L g130 ( 
.A(n_115),
.B(n_86),
.C(n_96),
.D(n_95),
.Y(n_130)
);

NAND2xp5_ASAP7_75t_L g131 ( 
.A(n_116),
.B(n_95),
.Y(n_131)
);

NOR3xp33_ASAP7_75t_L g132 ( 
.A(n_113),
.B(n_97),
.C(n_90),
.Y(n_132)
);

AOI21xp5_ASAP7_75t_L g133 ( 
.A1(n_125),
.A2(n_103),
.B(n_92),
.Y(n_133)
);

AOI21xp5_ASAP7_75t_L g134 ( 
.A1(n_125),
.A2(n_103),
.B(n_92),
.Y(n_134)
);

NAND3xp33_ASAP7_75t_L g135 ( 
.A(n_126),
.B(n_91),
.C(n_51),
.Y(n_135)
);

AOI22xp5_ASAP7_75t_L g136 ( 
.A1(n_118),
.A2(n_103),
.B1(n_99),
.B2(n_92),
.Y(n_136)
);

AOI21xp5_ASAP7_75t_L g137 ( 
.A1(n_124),
.A2(n_103),
.B(n_92),
.Y(n_137)
);

AOI222xp33_ASAP7_75t_L g138 ( 
.A1(n_120),
.A2(n_103),
.B1(n_99),
.B2(n_92),
.C1(n_97),
.C2(n_91),
.Y(n_138)
);

AOI22xp5_ASAP7_75t_L g139 ( 
.A1(n_119),
.A2(n_103),
.B1(n_99),
.B2(n_92),
.Y(n_139)
);

NAND2xp5_ASAP7_75t_L g140 ( 
.A(n_119),
.B(n_92),
.Y(n_140)
);

NOR2x1_ASAP7_75t_L g141 ( 
.A(n_114),
.B(n_97),
.Y(n_141)
);

OAI32xp33_ASAP7_75t_L g142 ( 
.A1(n_121),
.A2(n_91),
.A3(n_9),
.B1(n_7),
.B2(n_8),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_121),
.Y(n_143)
);

AOI22xp5_ASAP7_75t_L g144 ( 
.A1(n_123),
.A2(n_99),
.B1(n_78),
.B2(n_100),
.Y(n_144)
);

O2A1O1Ixp33_ASAP7_75t_L g145 ( 
.A1(n_123),
.A2(n_100),
.B(n_60),
.C(n_51),
.Y(n_145)
);

NAND2xp5_ASAP7_75t_L g146 ( 
.A(n_143),
.B(n_99),
.Y(n_146)
);

NAND2xp5_ASAP7_75t_L g147 ( 
.A(n_140),
.B(n_99),
.Y(n_147)
);

INVxp33_ASAP7_75t_L g148 ( 
.A(n_131),
.Y(n_148)
);

OR2x2_ASAP7_75t_L g149 ( 
.A(n_137),
.B(n_100),
.Y(n_149)
);

NAND2xp5_ASAP7_75t_L g150 ( 
.A(n_132),
.B(n_99),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_141),
.Y(n_151)
);

XOR2x2_ASAP7_75t_L g152 ( 
.A(n_127),
.B(n_9),
.Y(n_152)
);

INVxp67_ASAP7_75t_SL g153 ( 
.A(n_133),
.Y(n_153)
);

NOR3xp33_ASAP7_75t_L g154 ( 
.A(n_130),
.B(n_60),
.C(n_100),
.Y(n_154)
);

OAI21xp5_ASAP7_75t_L g155 ( 
.A1(n_142),
.A2(n_60),
.B(n_78),
.Y(n_155)
);

NAND2xp5_ASAP7_75t_L g156 ( 
.A(n_134),
.B(n_99),
.Y(n_156)
);

OR2x2_ASAP7_75t_L g157 ( 
.A(n_136),
.B(n_66),
.Y(n_157)
);

AND2x2_ASAP7_75t_L g158 ( 
.A(n_139),
.B(n_66),
.Y(n_158)
);

NOR2xp67_ASAP7_75t_L g159 ( 
.A(n_144),
.B(n_10),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_129),
.Y(n_160)
);

OR2x2_ASAP7_75t_L g161 ( 
.A(n_135),
.B(n_10),
.Y(n_161)
);

OAI32xp33_ASAP7_75t_L g162 ( 
.A1(n_128),
.A2(n_13),
.A3(n_12),
.B1(n_14),
.B2(n_15),
.Y(n_162)
);

NAND3xp33_ASAP7_75t_L g163 ( 
.A(n_128),
.B(n_53),
.C(n_57),
.Y(n_163)
);

NAND2xp5_ASAP7_75t_SL g164 ( 
.A(n_148),
.B(n_138),
.Y(n_164)
);

NOR3xp33_ASAP7_75t_L g165 ( 
.A(n_162),
.B(n_145),
.C(n_12),
.Y(n_165)
);

NOR2xp67_ASAP7_75t_L g166 ( 
.A(n_151),
.B(n_16),
.Y(n_166)
);

AND2x4_ASAP7_75t_L g167 ( 
.A(n_146),
.B(n_153),
.Y(n_167)
);

NOR2x1p5_ASAP7_75t_L g168 ( 
.A(n_161),
.B(n_53),
.Y(n_168)
);

AOI211xp5_ASAP7_75t_L g169 ( 
.A1(n_159),
.A2(n_20),
.B(n_18),
.C(n_17),
.Y(n_169)
);

NAND4xp25_ASAP7_75t_L g170 ( 
.A(n_161),
.B(n_21),
.C(n_18),
.D(n_17),
.Y(n_170)
);

NOR2x1p5_ASAP7_75t_L g171 ( 
.A(n_150),
.B(n_156),
.Y(n_171)
);

OAI211xp5_ASAP7_75t_L g172 ( 
.A1(n_160),
.A2(n_24),
.B(n_22),
.C(n_21),
.Y(n_172)
);

HB1xp67_ASAP7_75t_L g173 ( 
.A(n_149),
.Y(n_173)
);

NOR4xp75_ASAP7_75t_SL g174 ( 
.A(n_147),
.B(n_24),
.C(n_85),
.D(n_2),
.Y(n_174)
);

NOR2xp33_ASAP7_75t_L g175 ( 
.A(n_148),
.B(n_149),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_158),
.Y(n_176)
);

OAI322xp33_ASAP7_75t_L g177 ( 
.A1(n_176),
.A2(n_152),
.A3(n_163),
.B1(n_157),
.B2(n_158),
.C1(n_57),
.C2(n_53),
.Y(n_177)
);

INVx1_ASAP7_75t_L g178 ( 
.A(n_173),
.Y(n_178)
);

A2O1A1Ixp33_ASAP7_75t_L g179 ( 
.A1(n_169),
.A2(n_152),
.B(n_154),
.C(n_155),
.Y(n_179)
);

AOI32xp33_ASAP7_75t_L g180 ( 
.A1(n_165),
.A2(n_11),
.A3(n_85),
.B1(n_71),
.B2(n_57),
.Y(n_180)
);

AOI22x1_ASAP7_75t_L g181 ( 
.A1(n_171),
.A2(n_168),
.B1(n_167),
.B2(n_173),
.Y(n_181)
);

AOI322xp5_ASAP7_75t_L g182 ( 
.A1(n_164),
.A2(n_175),
.A3(n_170),
.B1(n_167),
.B2(n_172),
.C1(n_174),
.C2(n_166),
.Y(n_182)
);

NOR2xp33_ASAP7_75t_L g183 ( 
.A(n_175),
.B(n_53),
.Y(n_183)
);

NOR2xp67_ASAP7_75t_L g184 ( 
.A(n_173),
.B(n_53),
.Y(n_184)
);

XNOR2x1_ASAP7_75t_L g185 ( 
.A(n_181),
.B(n_64),
.Y(n_185)
);

NOR2xp33_ASAP7_75t_L g186 ( 
.A(n_178),
.B(n_177),
.Y(n_186)
);

AOI21xp5_ASAP7_75t_L g187 ( 
.A1(n_179),
.A2(n_57),
.B(n_64),
.Y(n_187)
);

INVxp67_ASAP7_75t_SL g188 ( 
.A(n_184),
.Y(n_188)
);

AOI21xp5_ASAP7_75t_L g189 ( 
.A1(n_180),
.A2(n_57),
.B(n_183),
.Y(n_189)
);

XNOR2xp5_ASAP7_75t_L g190 ( 
.A(n_185),
.B(n_182),
.Y(n_190)
);

OR2x6_ASAP7_75t_L g191 ( 
.A(n_189),
.B(n_183),
.Y(n_191)
);

OA21x2_ASAP7_75t_L g192 ( 
.A1(n_190),
.A2(n_186),
.B(n_188),
.Y(n_192)
);

AOI221xp5_ASAP7_75t_L g193 ( 
.A1(n_192),
.A2(n_57),
.B1(n_187),
.B2(n_191),
.C(n_190),
.Y(n_193)
);


endmodule