module fake_netlist_631_156_n_45 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_17, n_16, n_19, n_45);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_17;
input n_16;
input n_19;

output n_45;

wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_22;
wire n_38;
wire n_36;
wire n_23;
wire n_42;
wire n_29;
wire n_21;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_24;

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_1),
.B(n_6),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_5),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

XNOR2xp5_ASAP7_75t_L g27 ( 
.A(n_13),
.B(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_21),
.A2(n_16),
.B1(n_2),
.B2(n_0),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_21),
.A2(n_25),
.B1(n_28),
.B2(n_22),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_SL g31 ( 
.A(n_22),
.B(n_16),
.C(n_2),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OAI33xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_28),
.A3(n_26),
.B1(n_24),
.B2(n_29),
.B3(n_23),
.Y(n_34)
);

OAI321xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_26),
.A3(n_25),
.B1(n_27),
.B2(n_20),
.C(n_19),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_32),
.B1(n_25),
.B2(n_27),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_25),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_35),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_20),
.Y(n_39)
);

OAI221xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_4),
.B1(n_3),
.B2(n_7),
.C(n_8),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVxp67_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_11),
.B1(n_10),
.B2(n_12),
.C(n_14),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_SL g45 ( 
.A1(n_44),
.A2(n_40),
.B1(n_43),
.B2(n_15),
.Y(n_45)
);


endmodule