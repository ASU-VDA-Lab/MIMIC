module fake_netlist_631_36_n_41 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_41);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_41;

wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_38;
wire n_36;
wire n_23;
wire n_29;
wire n_37;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_15),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_22),
.B(n_6),
.Y(n_25)
);

OA21x2_ASAP7_75t_L g26 ( 
.A1(n_19),
.A2(n_5),
.B(n_16),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_4),
.B(n_12),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_11),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_0),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_8),
.B(n_17),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_13),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_18),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AOI33xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_27),
.A3(n_30),
.B1(n_33),
.B2(n_25),
.B3(n_26),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_35),
.B(n_23),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_33),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_R g38 ( 
.A(n_37),
.B(n_24),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_38),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_R g40 ( 
.A1(n_39),
.A2(n_29),
.B1(n_28),
.B2(n_1),
.C(n_3),
.Y(n_40)
);

AOI322xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_9),
.A3(n_7),
.B1(n_20),
.B2(n_21),
.C1(n_10),
.C2(n_14),
.Y(n_41)
);


endmodule