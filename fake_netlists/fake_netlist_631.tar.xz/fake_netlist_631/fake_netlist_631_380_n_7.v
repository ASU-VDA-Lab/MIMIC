module fake_netlist_631_380_n_7 (n_2, n_0, n_1, n_7);

input n_2;
input n_0;
input n_1;

output n_7;

wire n_5;
wire n_4;
wire n_3;
wire n_6;

AND2x2_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_SL g4 ( 
.A(n_3),
.Y(n_4)
);

NAND4xp25_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.C(n_1),
.D(n_0),
.Y(n_5)
);

NOR3xp33_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.C(n_0),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B1(n_2),
.B2(n_4),
.Y(n_7)
);


endmodule