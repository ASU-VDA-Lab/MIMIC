module fake_netlist_631_858_n_30 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_10, n_6, n_30);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_10;
input n_6;

output n_30;

wire n_18;
wire n_13;
wire n_25;
wire n_20;
wire n_22;
wire n_11;
wire n_15;
wire n_23;
wire n_12;
wire n_14;
wire n_29;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_9),
.B1(n_1),
.B2(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AO22x1_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_2),
.Y(n_17)
);

OR2x6_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_12),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_18),
.B1(n_14),
.B2(n_11),
.Y(n_21)
);

AOI21xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_4),
.B(n_3),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_23)
);

INVxp67_ASAP7_75t_SL g24 ( 
.A(n_22),
.Y(n_24)
);

BUFx4f_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_23),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_9),
.B1(n_27),
.B2(n_28),
.Y(n_30)
);


endmodule