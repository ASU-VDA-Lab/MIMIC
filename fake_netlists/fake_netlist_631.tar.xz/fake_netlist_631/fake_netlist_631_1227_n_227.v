module fake_netlist_631_1227_n_227 (n_0, n_18, n_1, n_13, n_7, n_25, n_30, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_23, n_4, n_8, n_12, n_14, n_6, n_29, n_5, n_21, n_27, n_17, n_16, n_26, n_19, n_28, n_24, n_227);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_25;
input n_30;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_23;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_29;
input n_5;
input n_21;
input n_27;
input n_17;
input n_16;
input n_26;
input n_19;
input n_28;
input n_24;

output n_227;

wire n_69;
wire n_94;
wire n_92;
wire n_77;
wire n_216;
wire n_173;
wire n_106;
wire n_148;
wire n_225;
wire n_71;
wire n_179;
wire n_140;
wire n_49;
wire n_175;
wire n_96;
wire n_51;
wire n_85;
wire n_73;
wire n_194;
wire n_200;
wire n_68;
wire n_78;
wire n_177;
wire n_226;
wire n_154;
wire n_219;
wire n_99;
wire n_135;
wire n_142;
wire n_187;
wire n_55;
wire n_127;
wire n_101;
wire n_207;
wire n_121;
wire n_137;
wire n_221;
wire n_198;
wire n_126;
wire n_64;
wire n_214;
wire n_134;
wire n_197;
wire n_149;
wire n_61;
wire n_191;
wire n_158;
wire n_46;
wire n_141;
wire n_87;
wire n_176;
wire n_112;
wire n_167;
wire n_168;
wire n_63;
wire n_83;
wire n_211;
wire n_120;
wire n_34;
wire n_195;
wire n_218;
wire n_163;
wire n_131;
wire n_222;
wire n_209;
wire n_54;
wire n_81;
wire n_32;
wire n_202;
wire n_65;
wire n_170;
wire n_33;
wire n_162;
wire n_165;
wire n_151;
wire n_150;
wire n_155;
wire n_188;
wire n_193;
wire n_206;
wire n_57;
wire n_205;
wire n_72;
wire n_82;
wire n_60;
wire n_47;
wire n_164;
wire n_42;
wire n_88;
wire n_66;
wire n_114;
wire n_130;
wire n_143;
wire n_48;
wire n_111;
wire n_107;
wire n_59;
wire n_118;
wire n_35;
wire n_133;
wire n_50;
wire n_113;
wire n_203;
wire n_102;
wire n_159;
wire n_174;
wire n_171;
wire n_224;
wire n_204;
wire n_181;
wire n_53;
wire n_39;
wire n_185;
wire n_117;
wire n_115;
wire n_104;
wire n_98;
wire n_76;
wire n_129;
wire n_157;
wire n_144;
wire n_67;
wire n_190;
wire n_44;
wire n_31;
wire n_199;
wire n_103;
wire n_38;
wire n_128;
wire n_123;
wire n_212;
wire n_184;
wire n_210;
wire n_36;
wire n_161;
wire n_147;
wire n_119;
wire n_132;
wire n_52;
wire n_213;
wire n_105;
wire n_178;
wire n_217;
wire n_56;
wire n_139;
wire n_215;
wire n_37;
wire n_136;
wire n_182;
wire n_95;
wire n_84;
wire n_125;
wire n_124;
wire n_160;
wire n_62;
wire n_145;
wire n_220;
wire n_153;
wire n_183;
wire n_116;
wire n_189;
wire n_74;
wire n_223;
wire n_192;
wire n_93;
wire n_146;
wire n_41;
wire n_100;
wire n_201;
wire n_110;
wire n_108;
wire n_152;
wire n_196;
wire n_45;
wire n_109;
wire n_58;
wire n_90;
wire n_180;
wire n_186;
wire n_86;
wire n_166;
wire n_70;
wire n_80;
wire n_169;
wire n_138;
wire n_208;
wire n_75;
wire n_91;
wire n_172;
wire n_43;
wire n_89;
wire n_97;
wire n_40;
wire n_156;
wire n_79;
wire n_122;

INVxp67_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_18),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_12),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_22),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_5),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_24),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_3),
.Y(n_39)
);

CKINVDCx20_ASAP7_75t_R g40 ( 
.A(n_6),
.Y(n_40)
);

CKINVDCx16_ASAP7_75t_R g41 ( 
.A(n_10),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_29),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_33),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_36),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_35),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_35),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_41),
.Y(n_47)
);

BUFx6f_ASAP7_75t_L g48 ( 
.A(n_34),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_32),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_32),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_43),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_45),
.Y(n_54)
);

INVxp67_ASAP7_75t_L g55 ( 
.A(n_47),
.Y(n_55)
);

AND2x4_ASAP7_75t_L g56 ( 
.A(n_46),
.B(n_32),
.Y(n_56)
);

BUFx6f_ASAP7_75t_SL g57 ( 
.A(n_48),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_L g58 ( 
.A(n_47),
.B(n_41),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_49),
.Y(n_59)
);

NOR3xp33_ASAP7_75t_SL g60 ( 
.A(n_58),
.B(n_38),
.C(n_37),
.Y(n_60)
);

AOI21xp5_ASAP7_75t_L g61 ( 
.A1(n_51),
.A2(n_46),
.B(n_48),
.Y(n_61)
);

AOI21x1_ASAP7_75t_SL g62 ( 
.A1(n_51),
.A2(n_48),
.B(n_46),
.Y(n_62)
);

INVx5_ASAP7_75t_L g63 ( 
.A(n_56),
.Y(n_63)
);

AOI21xp5_ASAP7_75t_L g64 ( 
.A1(n_52),
.A2(n_48),
.B(n_34),
.Y(n_64)
);

O2A1O1Ixp33_ASAP7_75t_L g65 ( 
.A1(n_49),
.A2(n_39),
.B(n_38),
.C(n_37),
.Y(n_65)
);

O2A1O1Ixp33_ASAP7_75t_L g66 ( 
.A1(n_50),
.A2(n_54),
.B(n_56),
.C(n_52),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_50),
.Y(n_67)
);

BUFx6f_ASAP7_75t_L g68 ( 
.A(n_54),
.Y(n_68)
);

NOR2xp33_ASAP7_75t_L g69 ( 
.A(n_55),
.B(n_33),
.Y(n_69)
);

NAND2xp5_ASAP7_75t_L g70 ( 
.A(n_56),
.B(n_48),
.Y(n_70)
);

INVxp67_ASAP7_75t_SL g71 ( 
.A(n_56),
.Y(n_71)
);

OAI21x1_ASAP7_75t_L g72 ( 
.A1(n_62),
.A2(n_42),
.B(n_39),
.Y(n_72)
);

OR2x2_ASAP7_75t_L g73 ( 
.A(n_69),
.B(n_53),
.Y(n_73)
);

CKINVDCx16_ASAP7_75t_R g74 ( 
.A(n_68),
.Y(n_74)
);

AND2x2_ASAP7_75t_L g75 ( 
.A(n_71),
.B(n_56),
.Y(n_75)
);

NOR2xp33_ASAP7_75t_R g76 ( 
.A(n_59),
.B(n_55),
.Y(n_76)
);

AND2x4_ASAP7_75t_L g77 ( 
.A(n_63),
.B(n_42),
.Y(n_77)
);

OAI21x1_ASAP7_75t_L g78 ( 
.A1(n_64),
.A2(n_66),
.B(n_61),
.Y(n_78)
);

AOI22xp33_ASAP7_75t_L g79 ( 
.A1(n_59),
.A2(n_67),
.B1(n_68),
.B2(n_48),
.Y(n_79)
);

NAND2xp5_ASAP7_75t_L g80 ( 
.A(n_67),
.B(n_48),
.Y(n_80)
);

OAI22xp5_ASAP7_75t_L g81 ( 
.A1(n_60),
.A2(n_31),
.B1(n_40),
.B2(n_53),
.Y(n_81)
);

BUFx3_ASAP7_75t_L g82 ( 
.A(n_68),
.Y(n_82)
);

AND2x2_ASAP7_75t_L g83 ( 
.A(n_75),
.B(n_70),
.Y(n_83)
);

CKINVDCx5p33_ASAP7_75t_R g84 ( 
.A(n_76),
.Y(n_84)
);

NOR3xp33_ASAP7_75t_SL g85 ( 
.A(n_81),
.B(n_65),
.C(n_70),
.Y(n_85)
);

NOR2xp33_ASAP7_75t_R g86 ( 
.A(n_74),
.B(n_44),
.Y(n_86)
);

OR2x6_ASAP7_75t_L g87 ( 
.A(n_82),
.B(n_77),
.Y(n_87)
);

NAND2xp5_ASAP7_75t_L g88 ( 
.A(n_75),
.B(n_68),
.Y(n_88)
);

INVx2_ASAP7_75t_L g89 ( 
.A(n_72),
.Y(n_89)
);

INVx3_ASAP7_75t_L g90 ( 
.A(n_87),
.Y(n_90)
);

NAND2xp5_ASAP7_75t_L g91 ( 
.A(n_83),
.B(n_75),
.Y(n_91)
);

NAND2xp5_ASAP7_75t_L g92 ( 
.A(n_83),
.B(n_73),
.Y(n_92)
);

OAI21x1_ASAP7_75t_L g93 ( 
.A1(n_89),
.A2(n_72),
.B(n_78),
.Y(n_93)
);

INVxp67_ASAP7_75t_L g94 ( 
.A(n_84),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_87),
.Y(n_95)
);

NAND2xp5_ASAP7_75t_L g96 ( 
.A(n_83),
.B(n_88),
.Y(n_96)
);

AND2x2_ASAP7_75t_L g97 ( 
.A(n_96),
.B(n_85),
.Y(n_97)
);

INVxp67_ASAP7_75t_SL g98 ( 
.A(n_96),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_91),
.B(n_88),
.Y(n_99)
);

OR2x2_ASAP7_75t_L g100 ( 
.A(n_92),
.B(n_95),
.Y(n_100)
);

AND2x2_ASAP7_75t_L g101 ( 
.A(n_91),
.B(n_85),
.Y(n_101)
);

OR2x2_ASAP7_75t_L g102 ( 
.A(n_95),
.B(n_73),
.Y(n_102)
);

OR2x2_ASAP7_75t_L g103 ( 
.A(n_90),
.B(n_73),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_93),
.Y(n_104)
);

AND2x2_ASAP7_75t_L g105 ( 
.A(n_90),
.B(n_77),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_93),
.Y(n_106)
);

AND2x2_ASAP7_75t_L g107 ( 
.A(n_97),
.B(n_89),
.Y(n_107)
);

AND2x2_ASAP7_75t_L g108 ( 
.A(n_97),
.B(n_89),
.Y(n_108)
);

INVx2_ASAP7_75t_L g109 ( 
.A(n_104),
.Y(n_109)
);

NAND2xp5_ASAP7_75t_L g110 ( 
.A(n_98),
.B(n_90),
.Y(n_110)
);

AND2x2_ASAP7_75t_L g111 ( 
.A(n_101),
.B(n_72),
.Y(n_111)
);

NAND2xp5_ASAP7_75t_L g112 ( 
.A(n_99),
.B(n_75),
.Y(n_112)
);

OR2x2_ASAP7_75t_L g113 ( 
.A(n_104),
.B(n_78),
.Y(n_113)
);

NAND2xp33_ASAP7_75t_L g114 ( 
.A(n_101),
.B(n_79),
.Y(n_114)
);

NOR3xp33_ASAP7_75t_L g115 ( 
.A(n_103),
.B(n_81),
.C(n_73),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_106),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_106),
.Y(n_117)
);

NOR2xp33_ASAP7_75t_L g118 ( 
.A(n_103),
.B(n_73),
.Y(n_118)
);

AND2x4_ASAP7_75t_L g119 ( 
.A(n_105),
.B(n_87),
.Y(n_119)
);

NAND2xp5_ASAP7_75t_L g120 ( 
.A(n_99),
.B(n_75),
.Y(n_120)
);

INVx1_ASAP7_75t_L g121 ( 
.A(n_100),
.Y(n_121)
);

AND2x2_ASAP7_75t_L g122 ( 
.A(n_100),
.B(n_72),
.Y(n_122)
);

AND2x2_ASAP7_75t_L g123 ( 
.A(n_105),
.B(n_72),
.Y(n_123)
);

NOR2xp33_ASAP7_75t_L g124 ( 
.A(n_118),
.B(n_102),
.Y(n_124)
);

NAND2x1_ASAP7_75t_L g125 ( 
.A(n_116),
.B(n_102),
.Y(n_125)
);

O2A1O1Ixp33_ASAP7_75t_L g126 ( 
.A1(n_115),
.A2(n_81),
.B(n_65),
.C(n_31),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_116),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_121),
.B(n_94),
.Y(n_128)
);

NAND2xp5_ASAP7_75t_L g129 ( 
.A(n_121),
.B(n_44),
.Y(n_129)
);

OAI21xp5_ASAP7_75t_L g130 ( 
.A1(n_114),
.A2(n_78),
.B(n_61),
.Y(n_130)
);

AOI22xp5_ASAP7_75t_L g131 ( 
.A1(n_115),
.A2(n_74),
.B1(n_87),
.B2(n_77),
.Y(n_131)
);

A2O1A1Ixp33_ASAP7_75t_L g132 ( 
.A1(n_114),
.A2(n_78),
.B(n_64),
.C(n_79),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_110),
.Y(n_133)
);

AOI21xp33_ASAP7_75t_L g134 ( 
.A1(n_110),
.A2(n_80),
.B(n_87),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_117),
.Y(n_135)
);

OAI22xp33_ASAP7_75t_SL g136 ( 
.A1(n_118),
.A2(n_120),
.B1(n_112),
.B2(n_119),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_117),
.Y(n_137)
);

NAND2xp5_ASAP7_75t_L g138 ( 
.A(n_120),
.B(n_86),
.Y(n_138)
);

AOI21xp5_ASAP7_75t_L g139 ( 
.A1(n_112),
.A2(n_113),
.B(n_109),
.Y(n_139)
);

OAI321xp33_ASAP7_75t_L g140 ( 
.A1(n_111),
.A2(n_80),
.A3(n_87),
.B1(n_79),
.B2(n_68),
.C(n_76),
.Y(n_140)
);

OAI21xp5_ASAP7_75t_SL g141 ( 
.A1(n_119),
.A2(n_111),
.B(n_107),
.Y(n_141)
);

NAND4xp25_ASAP7_75t_L g142 ( 
.A(n_111),
.B(n_77),
.C(n_80),
.D(n_76),
.Y(n_142)
);

AO22x1_ASAP7_75t_L g143 ( 
.A1(n_119),
.A2(n_77),
.B1(n_86),
.B2(n_0),
.Y(n_143)
);

AOI22xp5_ASAP7_75t_L g144 ( 
.A1(n_119),
.A2(n_74),
.B1(n_87),
.B2(n_77),
.Y(n_144)
);

AOI22xp33_ASAP7_75t_L g145 ( 
.A1(n_119),
.A2(n_77),
.B1(n_78),
.B2(n_68),
.Y(n_145)
);

OAI22xp5_ASAP7_75t_L g146 ( 
.A1(n_107),
.A2(n_74),
.B1(n_82),
.B2(n_77),
.Y(n_146)
);

AND2x2_ASAP7_75t_L g147 ( 
.A(n_107),
.B(n_0),
.Y(n_147)
);

INVx3_ASAP7_75t_L g148 ( 
.A(n_109),
.Y(n_148)
);

NAND2xp5_ASAP7_75t_L g149 ( 
.A(n_108),
.B(n_1),
.Y(n_149)
);

NAND2xp5_ASAP7_75t_L g150 ( 
.A(n_133),
.B(n_108),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_127),
.Y(n_151)
);

INVxp67_ASAP7_75t_SL g152 ( 
.A(n_125),
.Y(n_152)
);

INVx1_ASAP7_75t_SL g153 ( 
.A(n_128),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_135),
.Y(n_154)
);

AND2x2_ASAP7_75t_L g155 ( 
.A(n_148),
.B(n_109),
.Y(n_155)
);

AND2x2_ASAP7_75t_L g156 ( 
.A(n_148),
.B(n_109),
.Y(n_156)
);

NAND2xp5_ASAP7_75t_L g157 ( 
.A(n_124),
.B(n_108),
.Y(n_157)
);

INVx2_ASAP7_75t_L g158 ( 
.A(n_148),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_137),
.Y(n_159)
);

OAI221xp5_ASAP7_75t_L g160 ( 
.A1(n_126),
.A2(n_122),
.B1(n_113),
.B2(n_123),
.C(n_117),
.Y(n_160)
);

INVx1_ASAP7_75t_L g161 ( 
.A(n_139),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_141),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_149),
.Y(n_163)
);

OR2x2_ASAP7_75t_L g164 ( 
.A(n_147),
.B(n_113),
.Y(n_164)
);

INVx1_ASAP7_75t_L g165 ( 
.A(n_130),
.Y(n_165)
);

NAND2xp5_ASAP7_75t_L g166 ( 
.A(n_124),
.B(n_122),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_L g167 ( 
.A(n_136),
.B(n_122),
.Y(n_167)
);

NAND2xp5_ASAP7_75t_L g168 ( 
.A(n_129),
.B(n_138),
.Y(n_168)
);

NAND2xp5_ASAP7_75t_L g169 ( 
.A(n_134),
.B(n_123),
.Y(n_169)
);

OR2x2_ASAP7_75t_L g170 ( 
.A(n_132),
.B(n_123),
.Y(n_170)
);

NAND2xp5_ASAP7_75t_L g171 ( 
.A(n_131),
.B(n_1),
.Y(n_171)
);

AND2x2_ASAP7_75t_L g172 ( 
.A(n_132),
.B(n_2),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_145),
.Y(n_173)
);

INVxp67_ASAP7_75t_L g174 ( 
.A(n_142),
.Y(n_174)
);

NAND2xp5_ASAP7_75t_L g175 ( 
.A(n_145),
.B(n_143),
.Y(n_175)
);

NAND2x1_ASAP7_75t_SL g176 ( 
.A(n_144),
.B(n_140),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_146),
.Y(n_177)
);

OAI221xp5_ASAP7_75t_L g178 ( 
.A1(n_171),
.A2(n_3),
.B1(n_2),
.B2(n_4),
.C(n_5),
.Y(n_178)
);

AOI222xp33_ASAP7_75t_L g179 ( 
.A1(n_172),
.A2(n_6),
.B1(n_4),
.B2(n_7),
.C1(n_15),
.C2(n_11),
.Y(n_179)
);

AOI221xp5_ASAP7_75t_SL g180 ( 
.A1(n_172),
.A2(n_11),
.B1(n_7),
.B2(n_15),
.C(n_16),
.Y(n_180)
);

AOI21xp5_ASAP7_75t_L g181 ( 
.A1(n_160),
.A2(n_82),
.B(n_63),
.Y(n_181)
);

OAI211xp5_ASAP7_75t_L g182 ( 
.A1(n_175),
.A2(n_18),
.B(n_17),
.C(n_16),
.Y(n_182)
);

AOI221xp5_ASAP7_75t_SL g183 ( 
.A1(n_162),
.A2(n_19),
.B1(n_17),
.B2(n_20),
.C(n_21),
.Y(n_183)
);

OAI211xp5_ASAP7_75t_L g184 ( 
.A1(n_176),
.A2(n_23),
.B(n_22),
.C(n_19),
.Y(n_184)
);

AOI221xp5_ASAP7_75t_L g185 ( 
.A1(n_161),
.A2(n_24),
.B1(n_23),
.B2(n_25),
.C(n_26),
.Y(n_185)
);

OAI31xp33_ASAP7_75t_L g186 ( 
.A1(n_174),
.A2(n_27),
.A3(n_26),
.B(n_25),
.Y(n_186)
);

AOI21xp33_ASAP7_75t_L g187 ( 
.A1(n_152),
.A2(n_29),
.B(n_28),
.Y(n_187)
);

HB1xp67_ASAP7_75t_L g188 ( 
.A(n_156),
.Y(n_188)
);

AOI221x1_ASAP7_75t_L g189 ( 
.A1(n_163),
.A2(n_165),
.B1(n_168),
.B2(n_173),
.C(n_161),
.Y(n_189)
);

NAND2xp5_ASAP7_75t_L g190 ( 
.A(n_163),
.B(n_28),
.Y(n_190)
);

AOI221xp5_ASAP7_75t_L g191 ( 
.A1(n_165),
.A2(n_173),
.B1(n_162),
.B2(n_167),
.C(n_151),
.Y(n_191)
);

NAND2xp5_ASAP7_75t_L g192 ( 
.A(n_153),
.B(n_30),
.Y(n_192)
);

INVx2_ASAP7_75t_L g193 ( 
.A(n_158),
.Y(n_193)
);

OAI21xp5_ASAP7_75t_SL g194 ( 
.A1(n_170),
.A2(n_30),
.B(n_8),
.Y(n_194)
);

NAND4xp25_ASAP7_75t_L g195 ( 
.A(n_170),
.B(n_82),
.C(n_13),
.D(n_9),
.Y(n_195)
);

INVx1_ASAP7_75t_L g196 ( 
.A(n_151),
.Y(n_196)
);

OAI222xp33_ASAP7_75t_L g197 ( 
.A1(n_169),
.A2(n_14),
.B1(n_57),
.B2(n_63),
.C1(n_82),
.C2(n_164),
.Y(n_197)
);

OAI221xp5_ASAP7_75t_SL g198 ( 
.A1(n_177),
.A2(n_157),
.B1(n_164),
.B2(n_166),
.C(n_150),
.Y(n_198)
);

AOI211xp5_ASAP7_75t_L g199 ( 
.A1(n_177),
.A2(n_82),
.B(n_63),
.C(n_57),
.Y(n_199)
);

OAI211xp5_ASAP7_75t_SL g200 ( 
.A1(n_154),
.A2(n_57),
.B(n_63),
.C(n_159),
.Y(n_200)
);

AOI31xp33_ASAP7_75t_L g201 ( 
.A1(n_191),
.A2(n_159),
.A3(n_154),
.B(n_176),
.Y(n_201)
);

NOR2x1_ASAP7_75t_L g202 ( 
.A(n_196),
.B(n_158),
.Y(n_202)
);

INVx1_ASAP7_75t_L g203 ( 
.A(n_196),
.Y(n_203)
);

XOR2xp5_ASAP7_75t_L g204 ( 
.A(n_192),
.B(n_155),
.Y(n_204)
);

AOI22xp5_ASAP7_75t_L g205 ( 
.A1(n_183),
.A2(n_184),
.B1(n_180),
.B2(n_182),
.Y(n_205)
);

O2A1O1Ixp33_ASAP7_75t_L g206 ( 
.A1(n_178),
.A2(n_186),
.B(n_194),
.C(n_195),
.Y(n_206)
);

INVx4_ASAP7_75t_L g207 ( 
.A(n_193),
.Y(n_207)
);

XOR2xp5_ASAP7_75t_L g208 ( 
.A(n_190),
.B(n_188),
.Y(n_208)
);

OAI321xp33_ASAP7_75t_L g209 ( 
.A1(n_185),
.A2(n_198),
.A3(n_181),
.B1(n_200),
.B2(n_199),
.C(n_186),
.Y(n_209)
);

OAI21xp5_ASAP7_75t_L g210 ( 
.A1(n_189),
.A2(n_179),
.B(n_187),
.Y(n_210)
);

AOI22xp5_ASAP7_75t_L g211 ( 
.A1(n_199),
.A2(n_194),
.B1(n_184),
.B2(n_195),
.Y(n_211)
);

AOI21xp5_ASAP7_75t_L g212 ( 
.A1(n_197),
.A2(n_181),
.B(n_195),
.Y(n_212)
);

HB1xp67_ASAP7_75t_L g213 ( 
.A(n_203),
.Y(n_213)
);

CKINVDCx16_ASAP7_75t_R g214 ( 
.A(n_211),
.Y(n_214)
);

CKINVDCx20_ASAP7_75t_R g215 ( 
.A(n_204),
.Y(n_215)
);

CKINVDCx5p33_ASAP7_75t_R g216 ( 
.A(n_208),
.Y(n_216)
);

INVx1_ASAP7_75t_L g217 ( 
.A(n_202),
.Y(n_217)
);

INVx2_ASAP7_75t_L g218 ( 
.A(n_207),
.Y(n_218)
);

NAND2xp5_ASAP7_75t_L g219 ( 
.A(n_213),
.B(n_210),
.Y(n_219)
);

AND2x2_ASAP7_75t_L g220 ( 
.A(n_218),
.B(n_207),
.Y(n_220)
);

AOI221xp5_ASAP7_75t_L g221 ( 
.A1(n_214),
.A2(n_201),
.B1(n_206),
.B2(n_209),
.C(n_205),
.Y(n_221)
);

OAI22xp5_ASAP7_75t_SL g222 ( 
.A1(n_214),
.A2(n_205),
.B1(n_189),
.B2(n_212),
.Y(n_222)
);

INVx1_ASAP7_75t_L g223 ( 
.A(n_219),
.Y(n_223)
);

AOI21xp5_ASAP7_75t_L g224 ( 
.A1(n_221),
.A2(n_222),
.B(n_216),
.Y(n_224)
);

INVx1_ASAP7_75t_L g225 ( 
.A(n_223),
.Y(n_225)
);

AOI22xp5_ASAP7_75t_SL g226 ( 
.A1(n_225),
.A2(n_224),
.B1(n_215),
.B2(n_220),
.Y(n_226)
);

AOI21xp5_ASAP7_75t_L g227 ( 
.A1(n_226),
.A2(n_218),
.B(n_217),
.Y(n_227)
);


endmodule