module fake_netlist_631_3050_n_18 (n_5, n_0, n_1, n_4, n_3, n_2, n_18);

input n_5;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_18;

wire n_7;
wire n_9;
wire n_15;
wire n_8;
wire n_14;
wire n_16;
wire n_17;
wire n_10;
wire n_12;
wire n_6;
wire n_13;
wire n_11;

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_9),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_5),
.B(n_4),
.Y(n_12)
);

OR2x6_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_8),
.Y(n_13)
);

AO21x2_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_6),
.B(n_7),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_14),
.Y(n_15)
);

AOI211xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_6),
.B(n_13),
.C(n_14),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_2),
.B1(n_10),
.B2(n_12),
.C1(n_13),
.C2(n_11),
.Y(n_18)
);


endmodule