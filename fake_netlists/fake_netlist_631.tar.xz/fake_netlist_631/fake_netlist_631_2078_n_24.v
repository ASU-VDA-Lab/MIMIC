module fake_netlist_631_2078_n_24 (n_2, n_3, n_0, n_1, n_24);

input n_2;
input n_3;
input n_0;
input n_1;

output n_24;

wire n_18;
wire n_13;
wire n_7;
wire n_10;
wire n_20;
wire n_22;
wire n_11;
wire n_9;
wire n_15;
wire n_23;
wire n_4;
wire n_8;
wire n_12;
wire n_14;
wire n_6;
wire n_5;
wire n_21;
wire n_17;
wire n_16;
wire n_19;

BUFx10_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

NAND2x1p5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_3),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

NAND2x1p5_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

OAI33xp33_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_4),
.A3(n_8),
.B1(n_6),
.B2(n_1),
.B3(n_2),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_13),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_12),
.Y(n_18)
);

NAND4xp25_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_13),
.C(n_4),
.D(n_6),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.B1(n_12),
.B2(n_15),
.C(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_12),
.B(n_9),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_SL g23 ( 
.A(n_20),
.B(n_21),
.C(n_22),
.D(n_9),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_R g24 ( 
.A1(n_23),
.A2(n_10),
.B1(n_14),
.B2(n_20),
.Y(n_24)
);


endmodule