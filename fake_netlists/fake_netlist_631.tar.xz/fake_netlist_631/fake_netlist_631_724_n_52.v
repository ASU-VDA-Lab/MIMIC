module fake_netlist_631_724_n_52 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_52);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_52;

wire n_34;
wire n_49;
wire n_39;
wire n_51;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_38;
wire n_45;
wire n_36;
wire n_47;
wire n_23;
wire n_42;
wire n_29;
wire n_48;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_24;
wire n_50;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_12),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_2),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_16),
.B(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_16),
.B(n_6),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_R g30 ( 
.A(n_7),
.B(n_3),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_4),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_17),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_18),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_24),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_23),
.B1(n_28),
.B2(n_29),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_33),
.B(n_26),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_36),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_35),
.Y(n_42)
);

NOR4xp25_ASAP7_75t_SL g43 ( 
.A(n_42),
.B(n_39),
.C(n_30),
.D(n_23),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_40),
.B1(n_34),
.B2(n_25),
.C(n_26),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_SL g47 ( 
.A1(n_44),
.A2(n_19),
.B1(n_18),
.B2(n_0),
.C(n_1),
.Y(n_47)
);

NAND3xp33_ASAP7_75t_SL g48 ( 
.A(n_46),
.B(n_19),
.C(n_5),
.Y(n_48)
);

AND2x4_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_8),
.Y(n_49)
);

OAI222xp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_47),
.B1(n_14),
.B2(n_11),
.C1(n_15),
.C2(n_13),
.Y(n_50)
);

INVxp67_ASAP7_75t_SL g51 ( 
.A(n_49),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_SL g52 ( 
.A1(n_51),
.A2(n_20),
.B1(n_22),
.B2(n_50),
.Y(n_52)
);


endmodule