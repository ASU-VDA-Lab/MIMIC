module fake_netlist_631_2088_n_5 (n_0, n_1, n_5);

input n_0;
input n_1;

output n_5;

wire n_4;
wire n_3;
wire n_2;

BUFx6f_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

O2A1O1Ixp33_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_2),
.C(n_0),
.Y(n_4)
);

AOI21xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_1),
.B(n_3),
.Y(n_5)
);


endmodule