module fake_netlist_631_0_n_53 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_53);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_53;

wire n_34;
wire n_49;
wire n_39;
wire n_51;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_41;
wire n_31;
wire n_38;
wire n_45;
wire n_36;
wire n_47;
wire n_23;
wire n_42;
wire n_52;
wire n_29;
wire n_48;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_24;
wire n_50;

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_16),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_16),
.B(n_10),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_R g30 ( 
.A(n_14),
.B(n_5),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_8),
.B(n_22),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_1),
.B(n_2),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_17),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

AND2x6_ASAP7_75t_L g35 ( 
.A(n_24),
.B(n_0),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

OAI211xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_23),
.B(n_29),
.C(n_25),
.Y(n_37)
);

CKINVDCx6p67_ASAP7_75t_R g38 ( 
.A(n_35),
.Y(n_38)
);

NOR2x1_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_36),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_33),
.C(n_28),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_38),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_32),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_32),
.B1(n_31),
.B2(n_30),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_17),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_19),
.B1(n_18),
.B2(n_3),
.C(n_6),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_13),
.B1(n_11),
.B2(n_7),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_47),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

AOI211xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_21),
.B(n_20),
.C(n_15),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_52),
.C(n_49),
.Y(n_53)
);


endmodule