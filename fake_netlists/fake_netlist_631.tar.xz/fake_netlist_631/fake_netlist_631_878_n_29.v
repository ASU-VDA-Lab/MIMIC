module fake_netlist_631_878_n_29 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_11, n_29);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_11;

output n_29;

wire n_18;
wire n_13;
wire n_25;
wire n_20;
wire n_22;
wire n_15;
wire n_23;
wire n_14;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_1),
.A2(n_2),
.B1(n_7),
.B2(n_9),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_5),
.B(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_11),
.Y(n_20)
);

AND2x4_ASAP7_75t_SL g21 ( 
.A(n_14),
.B(n_11),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_16),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_20),
.B(n_18),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_21),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_17),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_3),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);


endmodule