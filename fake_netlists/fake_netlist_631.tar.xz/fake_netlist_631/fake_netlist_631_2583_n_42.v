module fake_netlist_631_2583_n_42 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_17, n_16, n_19, n_42);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_17;
input n_16;
input n_19;

output n_42;

wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_41;
wire n_20;
wire n_22;
wire n_38;
wire n_36;
wire n_23;
wire n_29;
wire n_21;
wire n_37;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_24;

AND2x4_ASAP7_75t_L g20 ( 
.A(n_6),
.B(n_11),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_12),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_23),
.B(n_24),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_13),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_SL g31 ( 
.A(n_25),
.B(n_19),
.C(n_13),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_19),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_28),
.B(n_27),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_34),
.B1(n_20),
.B2(n_35),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_31),
.Y(n_37)
);

OAI221xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_22),
.B1(n_4),
.B2(n_1),
.C(n_2),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

NOR3xp33_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_9),
.C(n_8),
.Y(n_40)
);

CKINVDCx20_ASAP7_75t_R g41 ( 
.A(n_40),
.Y(n_41)
);

OAI211xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_18),
.B(n_17),
.C(n_15),
.Y(n_42)
);


endmodule