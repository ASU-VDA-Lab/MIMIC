module fake_netlist_631_3096_n_27 (n_5, n_0, n_1, n_4, n_3, n_2, n_27);

input n_5;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;

output n_27;

wire n_18;
wire n_13;
wire n_7;
wire n_25;
wire n_10;
wire n_20;
wire n_22;
wire n_11;
wire n_9;
wire n_15;
wire n_23;
wire n_8;
wire n_12;
wire n_6;
wire n_14;
wire n_21;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_24;

NOR3xp33_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_5),
.C(n_1),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_3),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_1),
.B(n_4),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_7),
.B(n_1),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_2),
.B1(n_0),
.B2(n_3),
.C(n_4),
.Y(n_12)
);

OR2x6_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_8),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_13),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_6),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_15),
.B(n_13),
.C(n_0),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_13),
.B(n_18),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_15),
.B1(n_13),
.B2(n_0),
.C(n_2),
.Y(n_21)
);

NOR3x1_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_15),
.C(n_2),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_15),
.C(n_13),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_15),
.B1(n_4),
.B2(n_2),
.C(n_3),
.Y(n_24)
);

OAI211xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_24),
.B(n_22),
.C(n_4),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_5),
.B(n_20),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_5),
.B(n_25),
.Y(n_27)
);


endmodule