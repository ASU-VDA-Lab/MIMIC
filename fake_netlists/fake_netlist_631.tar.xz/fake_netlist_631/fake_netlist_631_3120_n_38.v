module fake_netlist_631_3120_n_38 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_13, n_11, n_38);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_13;
input n_11;

output n_38;

wire n_18;
wire n_34;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_22;
wire n_20;
wire n_36;
wire n_15;
wire n_23;
wire n_14;
wire n_29;
wire n_21;
wire n_37;
wire n_27;
wire n_35;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_3),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_4),
.B(n_1),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_18),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_SL g23 ( 
.A(n_17),
.B(n_0),
.Y(n_23)
);

BUFx10_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_20),
.B1(n_19),
.B2(n_15),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_14),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_22),
.C(n_23),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_28),
.Y(n_30)
);

XNOR2x1_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_0),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_24),
.Y(n_32)
);

OAI21xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_24),
.B(n_20),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_24),
.B1(n_20),
.B2(n_1),
.C(n_4),
.Y(n_34)
);

OAI221xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_20),
.B1(n_7),
.B2(n_5),
.C(n_6),
.Y(n_35)
);

CKINVDCx12_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

AOI322xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_35),
.A3(n_7),
.B1(n_5),
.B2(n_9),
.C1(n_8),
.C2(n_13),
.Y(n_38)
);


endmodule