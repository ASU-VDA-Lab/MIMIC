module fake_netlist_631_2812_n_21 (n_5, n_0, n_1, n_4, n_3, n_2, n_6, n_21);

input n_5;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;
input n_6;

output n_21;

wire n_18;
wire n_13;
wire n_7;
wire n_10;
wire n_20;
wire n_11;
wire n_9;
wire n_15;
wire n_8;
wire n_12;
wire n_14;
wire n_17;
wire n_16;
wire n_19;

AOI21x1_ASAP7_75t_L g7 ( 
.A1(n_0),
.A2(n_5),
.B(n_4),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_1),
.B(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_7),
.A2(n_6),
.B(n_5),
.Y(n_13)
);

AOI21x1_ASAP7_75t_L g14 ( 
.A1(n_7),
.A2(n_3),
.B(n_0),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_10),
.B(n_8),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_11),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_10),
.C(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OAI222xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B1(n_19),
.B2(n_15),
.C1(n_8),
.C2(n_10),
.Y(n_21)
);


endmodule