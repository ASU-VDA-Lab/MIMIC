module fake_netlist_631_1986_n_58 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_22, n_11, n_9, n_15, n_23, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_24, n_58);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_22;
input n_11;
input n_9;
input n_15;
input n_23;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;
input n_24;

output n_58;

wire n_53;
wire n_34;
wire n_49;
wire n_39;
wire n_51;
wire n_54;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_38;
wire n_45;
wire n_57;
wire n_36;
wire n_55;
wire n_47;
wire n_42;
wire n_52;
wire n_29;
wire n_48;
wire n_56;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_50;

NAND2xp33_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_2),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_24),
.A2(n_16),
.B1(n_18),
.B2(n_19),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_0),
.B(n_20),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_1),
.B(n_5),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_9),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_22),
.B(n_10),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_6),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_4),
.A2(n_20),
.B1(n_7),
.B2(n_13),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_31),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_30),
.B(n_17),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_30),
.Y(n_38)
);

BUFx4f_ASAP7_75t_SL g39 ( 
.A(n_36),
.Y(n_39)
);

OA21x2_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_27),
.B(n_28),
.Y(n_40)
);

OA21x2_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_38),
.B(n_35),
.Y(n_41)
);

NAND4xp25_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_25),
.C(n_27),
.D(n_34),
.Y(n_42)
);

OAI221xp5_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_26),
.B1(n_36),
.B2(n_33),
.C(n_32),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_41),
.Y(n_44)
);

INVx2_ASAP7_75t_SL g45 ( 
.A(n_43),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_36),
.B1(n_28),
.B2(n_33),
.C(n_32),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_39),
.B1(n_41),
.B2(n_17),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_18),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_50),
.B(n_21),
.Y(n_51)
);

AOI211xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_11),
.B(n_8),
.C(n_3),
.Y(n_52)
);

AND4x1_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_15),
.C(n_14),
.D(n_12),
.Y(n_53)
);

INVx6_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_55),
.Y(n_57)
);

OAI22xp33_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_23),
.B1(n_52),
.B2(n_56),
.Y(n_58)
);


endmodule