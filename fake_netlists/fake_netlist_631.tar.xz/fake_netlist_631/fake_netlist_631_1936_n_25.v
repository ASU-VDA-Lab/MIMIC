module fake_netlist_631_1936_n_25 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_10, n_6, n_11, n_25);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_10;
input n_6;
input n_11;

output n_25;

wire n_18;
wire n_13;
wire n_22;
wire n_20;
wire n_15;
wire n_23;
wire n_12;
wire n_14;
wire n_21;
wire n_17;
wire n_16;
wire n_19;
wire n_24;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_7),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_16),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_13),
.A2(n_14),
.B1(n_16),
.B2(n_12),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_12),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_19),
.B1(n_4),
.B2(n_1),
.Y(n_21)
);

NAND4xp25_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_5),
.C(n_4),
.D(n_1),
.Y(n_22)
);

OAI22xp33_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_6),
.B1(n_5),
.B2(n_2),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_6),
.B1(n_10),
.B2(n_8),
.Y(n_25)
);


endmodule