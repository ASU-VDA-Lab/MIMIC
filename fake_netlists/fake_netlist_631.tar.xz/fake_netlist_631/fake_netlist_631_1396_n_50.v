module fake_netlist_631_1396_n_50 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_50);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_50;

wire n_34;
wire n_49;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_22;
wire n_38;
wire n_45;
wire n_36;
wire n_47;
wire n_23;
wire n_42;
wire n_29;
wire n_48;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_24;

INVx2_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_5),
.B(n_10),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_4),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_19),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_25),
.B(n_26),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_22),
.B(n_16),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_28),
.B1(n_23),
.B2(n_31),
.Y(n_36)
);

NAND3xp33_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_24),
.C(n_27),
.Y(n_37)
);

OAI21x1_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_27),
.B(n_34),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_32),
.B(n_18),
.C(n_16),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_32),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_18),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

OAI22xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_9),
.B(n_8),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_R g46 ( 
.A1(n_44),
.A2(n_17),
.B1(n_15),
.B2(n_14),
.Y(n_46)
);

INVxp67_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_47),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_48),
.A2(n_20),
.B1(n_21),
.B2(n_49),
.Y(n_50)
);


endmodule