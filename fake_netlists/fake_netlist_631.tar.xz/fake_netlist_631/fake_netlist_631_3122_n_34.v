module fake_netlist_631_3122_n_34 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_16, n_10, n_6, n_13, n_11, n_34);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_16;
input n_10;
input n_6;
input n_13;
input n_11;

output n_34;

wire n_18;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_20;
wire n_22;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_26;
wire n_17;
wire n_19;
wire n_28;
wire n_24;

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_5),
.B(n_8),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_13),
.B(n_4),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_19),
.A2(n_15),
.B1(n_5),
.B2(n_4),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_18),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_21),
.Y(n_25)
);

OR2x6_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_18),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

OAI21xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B(n_17),
.Y(n_29)
);

O2A1O1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_22),
.B(n_17),
.C(n_15),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_16),
.B1(n_2),
.B2(n_0),
.Y(n_32)
);

OAI22x1_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_7),
.B1(n_6),
.B2(n_3),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_R g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_11),
.B2(n_9),
.C(n_10),
.Y(n_34)
);


endmodule