module fake_netlist_631_3075_n_42 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_12, n_10, n_6, n_13, n_11, n_42);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_10;
input n_6;
input n_13;
input n_11;

output n_42;

wire n_18;
wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_41;
wire n_22;
wire n_20;
wire n_38;
wire n_36;
wire n_23;
wire n_15;
wire n_14;
wire n_29;
wire n_21;
wire n_37;
wire n_27;
wire n_35;
wire n_17;
wire n_26;
wire n_16;
wire n_19;
wire n_28;
wire n_40;
wire n_24;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_1),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

NAND2xp33_ASAP7_75t_R g16 ( 
.A(n_11),
.B(n_1),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_11),
.B(n_3),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_7),
.B(n_6),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_4),
.B1(n_2),
.B2(n_0),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_19),
.A2(n_7),
.B1(n_5),
.B2(n_4),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_20),
.B(n_19),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_26),
.B(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

NAND3x1_ASAP7_75t_SL g30 ( 
.A(n_27),
.B(n_22),
.C(n_16),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_28),
.Y(n_33)
);

NAND3xp33_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_25),
.C(n_22),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_27),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_34),
.B(n_31),
.Y(n_36)
);

AOI322xp5_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_15),
.A3(n_21),
.B1(n_17),
.B2(n_30),
.C1(n_16),
.C2(n_24),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

CKINVDCx20_ASAP7_75t_R g39 ( 
.A(n_35),
.Y(n_39)
);

XNOR2xp5_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_12),
.Y(n_40)
);

OAI22x1_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_R g42 ( 
.A1(n_41),
.A2(n_13),
.B1(n_40),
.B2(n_37),
.Y(n_42)
);


endmodule