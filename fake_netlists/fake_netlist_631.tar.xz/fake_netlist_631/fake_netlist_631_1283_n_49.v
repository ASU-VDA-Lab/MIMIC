module fake_netlist_631_1283_n_49 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_49);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_49;

wire n_34;
wire n_39;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_31;
wire n_41;
wire n_22;
wire n_38;
wire n_45;
wire n_36;
wire n_47;
wire n_23;
wire n_42;
wire n_29;
wire n_48;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_24;

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_6),
.B(n_15),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_3),
.A2(n_10),
.B1(n_8),
.B2(n_17),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

BUFx8_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_2),
.A2(n_14),
.B1(n_1),
.B2(n_20),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_L g28 ( 
.A(n_17),
.B(n_7),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_16),
.B(n_13),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_16),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_25),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_22),
.B(n_28),
.Y(n_33)
);

OA21x2_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_30),
.B(n_29),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_33),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_24),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_27),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_26),
.B1(n_19),
.B2(n_18),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_39),
.B(n_5),
.Y(n_43)
);

NOR2x1_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_26),
.Y(n_44)
);

INVx2_ASAP7_75t_SL g45 ( 
.A(n_44),
.Y(n_45)
);

NAND3x1_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_18),
.C(n_9),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AND3x2_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_46),
.C(n_11),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_21),
.B(n_12),
.Y(n_49)
);


endmodule