module fake_netlist_631_1941_n_18 (n_5, n_7, n_0, n_1, n_4, n_3, n_2, n_6, n_18);

input n_5;
input n_7;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;
input n_6;

output n_18;

wire n_9;
wire n_15;
wire n_8;
wire n_12;
wire n_14;
wire n_13;
wire n_17;
wire n_16;
wire n_10;
wire n_11;

INVx1_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

NAND2xp33_ASAP7_75t_R g10 ( 
.A(n_0),
.B(n_3),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B1(n_10),
.B2(n_1),
.Y(n_12)
);

AO31x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.A3(n_2),
.B(n_1),
.Y(n_13)
);

AND3x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_3),
.C(n_2),
.Y(n_14)
);

OAI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B1(n_6),
.B2(n_4),
.C1(n_7),
.C2(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B1(n_13),
.B2(n_5),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_16),
.B1(n_7),
.B2(n_6),
.Y(n_18)
);


endmodule