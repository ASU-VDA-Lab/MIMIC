module fake_netlist_631_2510_n_16 (n_5, n_7, n_0, n_1, n_4, n_3, n_2, n_6, n_16);

input n_5;
input n_7;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;
input n_6;

output n_16;

wire n_9;
wire n_15;
wire n_8;
wire n_12;
wire n_14;
wire n_13;
wire n_10;
wire n_11;

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_3),
.B(n_2),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B1(n_6),
.B2(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);


endmodule