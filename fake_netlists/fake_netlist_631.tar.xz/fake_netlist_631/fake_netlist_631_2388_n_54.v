module fake_netlist_631_2388_n_54 (n_0, n_18, n_1, n_13, n_7, n_3, n_2, n_10, n_20, n_11, n_9, n_15, n_4, n_8, n_12, n_14, n_6, n_5, n_21, n_17, n_16, n_19, n_54);

input n_0;
input n_18;
input n_1;
input n_13;
input n_7;
input n_3;
input n_2;
input n_10;
input n_20;
input n_11;
input n_9;
input n_15;
input n_4;
input n_8;
input n_12;
input n_14;
input n_6;
input n_5;
input n_21;
input n_17;
input n_16;
input n_19;

output n_54;

wire n_53;
wire n_34;
wire n_49;
wire n_39;
wire n_51;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_44;
wire n_41;
wire n_31;
wire n_22;
wire n_38;
wire n_45;
wire n_36;
wire n_47;
wire n_23;
wire n_42;
wire n_52;
wire n_29;
wire n_48;
wire n_37;
wire n_43;
wire n_27;
wire n_35;
wire n_26;
wire n_28;
wire n_40;
wire n_46;
wire n_24;
wire n_50;

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_1),
.B(n_9),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_15),
.B(n_2),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_7),
.B(n_13),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_20),
.Y(n_27)
);

INVx4_ASAP7_75t_L g28 ( 
.A(n_4),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_0),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_5),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_26),
.B(n_19),
.C(n_18),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_18),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

NAND2x1p5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_28),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_35),
.B(n_23),
.Y(n_37)
);

A2O1A1Ixp33_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_23),
.B(n_22),
.C(n_25),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_28),
.Y(n_39)
);

BUFx3_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_38),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_32),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

O2A1O1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_31),
.B(n_27),
.C(n_19),
.Y(n_47)
);

XOR2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_3),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_6),
.Y(n_49)
);

OAI211xp5_ASAP7_75t_SL g50 ( 
.A1(n_47),
.A2(n_12),
.B(n_11),
.C(n_10),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

BUFx2_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_50),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_SL g54 ( 
.A1(n_53),
.A2(n_52),
.B1(n_17),
.B2(n_14),
.Y(n_54)
);


endmodule