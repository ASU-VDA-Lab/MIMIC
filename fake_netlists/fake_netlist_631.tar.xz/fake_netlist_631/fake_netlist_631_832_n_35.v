module fake_netlist_631_832_n_35 (n_5, n_7, n_0, n_9, n_1, n_15, n_4, n_3, n_2, n_8, n_12, n_14, n_10, n_6, n_13, n_11, n_35);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_15;
input n_4;
input n_3;
input n_2;
input n_8;
input n_12;
input n_14;
input n_10;
input n_6;
input n_13;
input n_11;

output n_35;

wire n_18;
wire n_34;
wire n_25;
wire n_30;
wire n_32;
wire n_33;
wire n_31;
wire n_22;
wire n_20;
wire n_23;
wire n_29;
wire n_21;
wire n_27;
wire n_17;
wire n_26;
wire n_16;
wire n_19;
wire n_28;
wire n_24;

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_13),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_1),
.B(n_9),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_6),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_15),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_20),
.B(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_22),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_26),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_16),
.B1(n_24),
.B2(n_25),
.Y(n_29)
);

NOR2xp67_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_0),
.Y(n_30)
);

AOI321xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_15),
.A3(n_16),
.B1(n_25),
.B2(n_4),
.C(n_3),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_10),
.B1(n_8),
.B2(n_5),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_11),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_32),
.C(n_14),
.Y(n_35)
);


endmodule