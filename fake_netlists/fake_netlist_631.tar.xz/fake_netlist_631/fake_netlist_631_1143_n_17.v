module fake_netlist_631_1143_n_17 (n_5, n_7, n_0, n_1, n_4, n_3, n_2, n_6, n_17);

input n_5;
input n_7;
input n_0;
input n_1;
input n_4;
input n_3;
input n_2;
input n_6;

output n_17;

wire n_9;
wire n_15;
wire n_8;
wire n_12;
wire n_14;
wire n_13;
wire n_16;
wire n_10;
wire n_11;

INVx1_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVxp67_ASAP7_75t_SL g9 ( 
.A(n_5),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_3),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_8),
.B(n_6),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_9),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B1(n_7),
.B2(n_6),
.C(n_2),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OAI31xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.A3(n_7),
.B(n_4),
.Y(n_17)
);


endmodule