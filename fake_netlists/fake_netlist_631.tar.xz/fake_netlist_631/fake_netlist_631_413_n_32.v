module fake_netlist_631_413_n_32 (n_5, n_7, n_0, n_9, n_1, n_4, n_3, n_2, n_8, n_10, n_6, n_32);

input n_5;
input n_7;
input n_0;
input n_9;
input n_1;
input n_4;
input n_3;
input n_2;
input n_8;
input n_10;
input n_6;

output n_32;

wire n_18;
wire n_13;
wire n_25;
wire n_30;
wire n_31;
wire n_22;
wire n_20;
wire n_11;
wire n_15;
wire n_23;
wire n_12;
wire n_14;
wire n_29;
wire n_21;
wire n_27;
wire n_17;
wire n_16;
wire n_26;
wire n_19;
wire n_28;
wire n_24;

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_3),
.B(n_0),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_11),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_16),
.B1(n_12),
.B2(n_14),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_16),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_16),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_16),
.B1(n_13),
.B2(n_22),
.C1(n_2),
.C2(n_0),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_16),
.B1(n_13),
.B2(n_2),
.C(n_4),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_SL g28 ( 
.A1(n_26),
.A2(n_16),
.B1(n_6),
.B2(n_5),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

XNOR2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_5),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_7),
.B1(n_6),
.B2(n_8),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_7),
.B1(n_10),
.B2(n_31),
.Y(n_32)
);


endmodule