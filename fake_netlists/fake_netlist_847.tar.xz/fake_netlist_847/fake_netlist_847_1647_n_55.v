module fake_netlist_847_1647_n_55 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_55);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_55;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

XNOR2xp5_ASAP7_75t_L g19 ( 
.A(n_10),
.B(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_6),
.B(n_17),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_11),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_18),
.B(n_1),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

OR2x4_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_2),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_25),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_24),
.Y(n_31)
);

OA21x2_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_22),
.B(n_23),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_21),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_21),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_23),
.Y(n_38)
);

AOI21xp33_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_19),
.B(n_24),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_35),
.B1(n_19),
.B2(n_18),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_38),
.Y(n_41)
);

NAND4xp25_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_29),
.C(n_36),
.D(n_3),
.Y(n_42)
);

OAI21xp5_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_37),
.B(n_3),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_37),
.B1(n_18),
.B2(n_28),
.Y(n_44)
);

AOI31xp33_ASAP7_75t_L g45 ( 
.A1(n_39),
.A2(n_16),
.A3(n_5),
.B(n_4),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

INVx2_ASAP7_75t_SL g47 ( 
.A(n_44),
.Y(n_47)
);

NAND3xp33_ASAP7_75t_SL g48 ( 
.A(n_43),
.B(n_16),
.C(n_5),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_42),
.A2(n_18),
.B1(n_28),
.B2(n_9),
.C(n_13),
.Y(n_49)
);

NOR3xp33_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_28),
.C(n_14),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

CKINVDCx20_ASAP7_75t_R g53 ( 
.A(n_51),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_49),
.B1(n_28),
.B2(n_15),
.Y(n_54)
);

AOI22xp5_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_52),
.B1(n_50),
.B2(n_54),
.Y(n_55)
);


endmodule