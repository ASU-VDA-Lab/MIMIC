module fake_netlist_847_551_n_28 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_28);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

INVx2_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_0),
.B(n_4),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_5),
.B(n_4),
.C(n_1),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_9),
.B(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_13),
.B1(n_20),
.B2(n_17),
.C(n_15),
.Y(n_23)
);

NAND4xp75_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_22),
.C(n_15),
.D(n_1),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_17),
.Y(n_25)
);

OA21x2_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_17),
.B(n_10),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_17),
.B1(n_7),
.B2(n_5),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_25),
.B1(n_7),
.B2(n_12),
.Y(n_28)
);


endmodule