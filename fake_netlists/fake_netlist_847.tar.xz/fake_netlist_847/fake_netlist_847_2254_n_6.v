module fake_netlist_847_2254_n_6 (n_2, n_0, n_1, n_6);

input n_2;
input n_0;
input n_1;

output n_6;

wire n_4;
wire n_5;
wire n_3;

OAI21x1_ASAP7_75t_L g3 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_3)
);

OAI21x1_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

OAI21xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

OAI22xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B1(n_4),
.B2(n_3),
.Y(n_6)
);


endmodule