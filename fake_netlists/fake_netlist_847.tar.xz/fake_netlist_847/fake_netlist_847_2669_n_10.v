module fake_netlist_847_2669_n_10 (n_2, n_0, n_1, n_10);

input n_2;
input n_0;
input n_1;

output n_10;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_8;

NOR2xp33_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

INVx5_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

OAI322xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_3),
.A3(n_5),
.B1(n_2),
.B2(n_4),
.C1(n_0),
.C2(n_1),
.Y(n_7)
);

NOR3xp33_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_0),
.C(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_2),
.B1(n_4),
.B2(n_7),
.Y(n_10)
);


endmodule