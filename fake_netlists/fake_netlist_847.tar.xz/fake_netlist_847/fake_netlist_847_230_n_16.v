module fake_netlist_847_230_n_16 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_16);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_15;
wire n_13;
wire n_14;
wire n_12;
wire n_10;
wire n_11;
wire n_9;
wire n_8;

OR2x2_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_5),
.Y(n_8)
);

INVxp67_ASAP7_75t_SL g9 ( 
.A(n_1),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

CKINVDCx11_ASAP7_75t_R g11 ( 
.A(n_10),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B(n_8),
.Y(n_12)
);

AOI31xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.A3(n_6),
.B(n_4),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B(n_3),
.Y(n_16)
);


endmodule