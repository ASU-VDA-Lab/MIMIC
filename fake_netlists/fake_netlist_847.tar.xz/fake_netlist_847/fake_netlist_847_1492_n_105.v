module fake_netlist_847_1492_n_105 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_28, n_9, n_31, n_32, n_26, n_24, n_19, n_3, n_33, n_12, n_0, n_29, n_6, n_30, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_105);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_28;
input n_9;
input n_31;
input n_32;
input n_26;
input n_24;
input n_19;
input n_3;
input n_33;
input n_12;
input n_0;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_105;

wire n_49;
wire n_97;
wire n_81;
wire n_80;
wire n_78;
wire n_87;
wire n_54;
wire n_96;
wire n_95;
wire n_56;
wire n_59;
wire n_63;
wire n_94;
wire n_74;
wire n_64;
wire n_79;
wire n_61;
wire n_86;
wire n_43;
wire n_45;
wire n_48;
wire n_47;
wire n_90;
wire n_76;
wire n_99;
wire n_72;
wire n_73;
wire n_37;
wire n_42;
wire n_103;
wire n_52;
wire n_77;
wire n_51;
wire n_57;
wire n_102;
wire n_89;
wire n_70;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_53;
wire n_84;
wire n_58;
wire n_68;
wire n_104;
wire n_85;
wire n_55;
wire n_65;
wire n_75;
wire n_67;
wire n_66;
wire n_101;
wire n_98;
wire n_91;
wire n_36;
wire n_50;
wire n_83;
wire n_60;
wire n_39;
wire n_93;
wire n_71;
wire n_92;
wire n_82;
wire n_100;
wire n_69;
wire n_88;
wire n_35;
wire n_38;
wire n_46;

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_18),
.Y(n_34)
);

BUFx12f_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx5_ASAP7_75t_L g36 ( 
.A(n_30),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_1),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_1),
.A2(n_2),
.B1(n_27),
.B2(n_29),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_23),
.Y(n_39)
);

BUFx3_ASAP7_75t_L g40 ( 
.A(n_28),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_15),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_21),
.Y(n_42)
);

BUFx6f_ASAP7_75t_L g43 ( 
.A(n_25),
.Y(n_43)
);

BUFx6f_ASAP7_75t_L g44 ( 
.A(n_32),
.Y(n_44)
);

INVx3_ASAP7_75t_L g45 ( 
.A(n_31),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_3),
.B(n_12),
.Y(n_46)
);

AND2x4_ASAP7_75t_L g47 ( 
.A(n_10),
.B(n_16),
.Y(n_47)
);

BUFx6f_ASAP7_75t_L g48 ( 
.A(n_5),
.Y(n_48)
);

BUFx6f_ASAP7_75t_L g49 ( 
.A(n_9),
.Y(n_49)
);

BUFx6f_ASAP7_75t_L g50 ( 
.A(n_11),
.Y(n_50)
);

INVx5_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

AOI21xp5_ASAP7_75t_L g52 ( 
.A1(n_41),
.A2(n_7),
.B(n_6),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_SL g53 ( 
.A(n_45),
.B(n_0),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_42),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_37),
.Y(n_55)
);

BUFx6f_ASAP7_75t_SL g56 ( 
.A(n_47),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_39),
.B(n_0),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_L g58 ( 
.A(n_36),
.B(n_2),
.Y(n_58)
);

AO32x2_ASAP7_75t_L g59 ( 
.A1(n_52),
.A2(n_38),
.A3(n_47),
.B1(n_57),
.B2(n_53),
.Y(n_59)
);

INVx3_ASAP7_75t_L g60 ( 
.A(n_54),
.Y(n_60)
);

OAI21x1_ASAP7_75t_L g61 ( 
.A1(n_55),
.A2(n_39),
.B(n_46),
.Y(n_61)
);

A2O1A1Ixp33_ASAP7_75t_L g62 ( 
.A1(n_58),
.A2(n_40),
.B(n_37),
.C(n_36),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_L g63 ( 
.A(n_51),
.B(n_40),
.Y(n_63)
);

INVx3_ASAP7_75t_L g64 ( 
.A(n_61),
.Y(n_64)
);

INVx3_ASAP7_75t_L g65 ( 
.A(n_60),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_63),
.Y(n_66)
);

AO21x2_ASAP7_75t_L g67 ( 
.A1(n_62),
.A2(n_38),
.B(n_56),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_65),
.B(n_59),
.Y(n_68)
);

OR2x2_ASAP7_75t_L g69 ( 
.A(n_65),
.B(n_51),
.Y(n_69)
);

OR2x2_ASAP7_75t_L g70 ( 
.A(n_65),
.B(n_51),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_64),
.Y(n_71)
);

AND2x2_ASAP7_75t_L g72 ( 
.A(n_67),
.B(n_59),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_68),
.Y(n_73)
);

AND2x4_ASAP7_75t_L g74 ( 
.A(n_72),
.B(n_66),
.Y(n_74)
);

NAND2xp5_ASAP7_75t_L g75 ( 
.A(n_71),
.B(n_64),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_70),
.Y(n_76)
);

HB1xp67_ASAP7_75t_L g77 ( 
.A(n_69),
.Y(n_77)
);

OR2x2_ASAP7_75t_L g78 ( 
.A(n_71),
.B(n_67),
.Y(n_78)
);

OAI21xp5_ASAP7_75t_L g79 ( 
.A1(n_78),
.A2(n_66),
.B(n_59),
.Y(n_79)
);

O2A1O1Ixp33_ASAP7_75t_L g80 ( 
.A1(n_77),
.A2(n_56),
.B(n_35),
.C(n_3),
.Y(n_80)
);

HB1xp67_ASAP7_75t_L g81 ( 
.A(n_74),
.Y(n_81)
);

AOI22xp5_ASAP7_75t_L g82 ( 
.A1(n_76),
.A2(n_44),
.B1(n_43),
.B2(n_34),
.Y(n_82)
);

OR2x2_ASAP7_75t_L g83 ( 
.A(n_73),
.B(n_4),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_74),
.Y(n_84)
);

OAI21xp5_ASAP7_75t_SL g85 ( 
.A1(n_75),
.A2(n_43),
.B(n_34),
.Y(n_85)
);

NOR2xp33_ASAP7_75t_L g86 ( 
.A(n_80),
.B(n_83),
.Y(n_86)
);

NOR2xp33_ASAP7_75t_L g87 ( 
.A(n_81),
.B(n_4),
.Y(n_87)
);

NOR2xp67_ASAP7_75t_SL g88 ( 
.A(n_85),
.B(n_75),
.Y(n_88)
);

NOR4xp25_ASAP7_75t_L g89 ( 
.A(n_79),
.B(n_36),
.C(n_43),
.D(n_34),
.Y(n_89)
);

NOR2x1_ASAP7_75t_L g90 ( 
.A(n_79),
.B(n_84),
.Y(n_90)
);

OAI211xp5_ASAP7_75t_L g91 ( 
.A1(n_82),
.A2(n_36),
.B(n_48),
.C(n_44),
.Y(n_91)
);

NAND2xp5_ASAP7_75t_SL g92 ( 
.A(n_80),
.B(n_44),
.Y(n_92)
);

OR2x2_ASAP7_75t_L g93 ( 
.A(n_87),
.B(n_48),
.Y(n_93)
);

A2O1A1Ixp33_ASAP7_75t_L g94 ( 
.A1(n_86),
.A2(n_50),
.B(n_49),
.C(n_8),
.Y(n_94)
);

OAI211xp5_ASAP7_75t_L g95 ( 
.A1(n_92),
.A2(n_50),
.B(n_49),
.C(n_13),
.Y(n_95)
);

NOR2x1_ASAP7_75t_L g96 ( 
.A(n_91),
.B(n_50),
.Y(n_96)
);

OR2x2_ASAP7_75t_L g97 ( 
.A(n_89),
.B(n_14),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_90),
.B(n_88),
.Y(n_98)
);

CKINVDCx5p33_ASAP7_75t_R g99 ( 
.A(n_93),
.Y(n_99)
);

NAND4xp75_ASAP7_75t_L g100 ( 
.A(n_98),
.B(n_20),
.C(n_19),
.D(n_17),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_97),
.Y(n_101)
);

NAND4xp25_ASAP7_75t_L g102 ( 
.A(n_101),
.B(n_94),
.C(n_96),
.D(n_95),
.Y(n_102)
);

AO22x2_ASAP7_75t_L g103 ( 
.A1(n_100),
.A2(n_26),
.B1(n_24),
.B2(n_22),
.Y(n_103)
);

OR2x2_ASAP7_75t_L g104 ( 
.A(n_102),
.B(n_99),
.Y(n_104)
);

OR2x6_ASAP7_75t_L g105 ( 
.A(n_104),
.B(n_103),
.Y(n_105)
);


endmodule