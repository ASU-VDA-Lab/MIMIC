module fake_netlist_847_2263_n_29 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_29);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_29;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_0),
.B(n_6),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_8),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_17),
.B(n_7),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_18),
.B(n_7),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_16),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_21),
.B1(n_23),
.B2(n_13),
.C(n_14),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

NAND2x1_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_1),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_27),
.B1(n_18),
.B2(n_15),
.Y(n_28)
);

AOI222xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_9),
.B1(n_3),
.B2(n_10),
.C1(n_12),
.C2(n_11),
.Y(n_29)
);


endmodule