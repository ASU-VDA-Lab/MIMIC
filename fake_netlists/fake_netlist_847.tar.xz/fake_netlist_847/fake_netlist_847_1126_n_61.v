module fake_netlist_847_1126_n_61 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_61);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_61;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_6),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_7),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_3),
.B(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_4),
.B(n_11),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

BUFx4f_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_23),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_26),
.Y(n_34)
);

OA21x2_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_19),
.B(n_24),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_29),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_38),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_36),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_28),
.B(n_34),
.Y(n_41)
);

OAI221xp5_ASAP7_75t_SL g42 ( 
.A1(n_39),
.A2(n_30),
.B1(n_23),
.B2(n_27),
.C(n_29),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_32),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_30),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_40),
.Y(n_46)
);

AOI211xp5_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_22),
.B(n_25),
.C(n_41),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_41),
.B1(n_28),
.B2(n_32),
.Y(n_49)
);

AOI21xp5_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_43),
.B(n_28),
.Y(n_50)
);

OAI322xp33_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_20),
.A3(n_17),
.B1(n_18),
.B2(n_0),
.C1(n_5),
.C2(n_24),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_46),
.B(n_47),
.Y(n_52)
);

OR5x1_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_18),
.C(n_17),
.D(n_20),
.E(n_8),
.Y(n_53)
);

OAI21xp33_ASAP7_75t_L g54 ( 
.A1(n_47),
.A2(n_20),
.B(n_9),
.Y(n_54)
);

OA22x2_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

XNOR2x1_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_20),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_51),
.Y(n_58)
);

AOI22xp33_ASAP7_75t_SL g59 ( 
.A1(n_55),
.A2(n_50),
.B1(n_54),
.B2(n_20),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_56),
.B1(n_58),
.B2(n_59),
.Y(n_61)
);


endmodule