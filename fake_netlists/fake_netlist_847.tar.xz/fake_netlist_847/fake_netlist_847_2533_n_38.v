module fake_netlist_847_2533_n_38 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_38);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_38;

wire n_25;
wire n_36;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_27;

INVx3_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_8),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_20),
.B(n_16),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_19),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_11),
.Y(n_26)
);

CKINVDCx16_ASAP7_75t_R g27 ( 
.A(n_3),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_19),
.B1(n_4),
.B2(n_0),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_21),
.B(n_5),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_23),
.B(n_26),
.Y(n_30)
);

OAI21xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_22),
.B(n_23),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_24),
.B1(n_25),
.B2(n_6),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_30),
.Y(n_33)
);

NOR4xp25_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_31),
.C(n_9),
.D(n_7),
.Y(n_34)
);

NOR4xp25_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_13),
.C(n_12),
.D(n_10),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_35),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_36),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_17),
.B1(n_15),
.B2(n_14),
.Y(n_38)
);


endmodule