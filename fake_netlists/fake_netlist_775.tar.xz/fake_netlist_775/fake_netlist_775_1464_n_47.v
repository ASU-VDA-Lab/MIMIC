module fake_netlist_775_1464_n_47 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_47);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_47;

wire n_37;
wire n_45;
wire n_44;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_43;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_41;
wire n_32;
wire n_22;

INVx2_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_13),
.B(n_19),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_1),
.B(n_8),
.Y(n_28)
);

INVx5_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_22),
.B(n_19),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_25),
.B(n_21),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_29),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_29),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_30),
.Y(n_37)
);

AOI32xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_26),
.A3(n_28),
.B1(n_36),
.B2(n_23),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_28),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_27),
.B1(n_2),
.B2(n_0),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_7),
.B1(n_4),
.B2(n_3),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_10),
.Y(n_43)
);

XNOR2x1_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_12),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AO21x2_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_16),
.B(n_14),
.Y(n_46)
);

OAI22xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_44),
.B1(n_20),
.B2(n_18),
.Y(n_47)
);


endmodule