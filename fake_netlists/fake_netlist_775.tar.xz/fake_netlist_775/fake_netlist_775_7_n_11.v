module fake_netlist_775_7_n_11 (n_1, n_2, n_0, n_11);

input n_1;
input n_2;
input n_0;

output n_11;

wire n_7;
wire n_10;
wire n_5;
wire n_6;
wire n_3;
wire n_9;
wire n_4;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

NOR2xp67_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

AO21x2_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI21xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_6),
.B(n_2),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_2),
.B1(n_6),
.B2(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_10),
.Y(n_11)
);


endmodule