module fake_netlist_775_647_n_52 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_52);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_52;

wire n_37;
wire n_45;
wire n_44;
wire n_29;
wire n_36;
wire n_50;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_49;
wire n_48;
wire n_43;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;
wire n_47;

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_13),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_17),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_10),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_12),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_24),
.B(n_20),
.C(n_0),
.Y(n_32)
);

OR2x2_ASAP7_75t_SL g33 ( 
.A(n_28),
.B(n_2),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_22),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_25),
.Y(n_35)
);

INVx2_ASAP7_75t_SL g36 ( 
.A(n_35),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_23),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_34),
.B1(n_32),
.B2(n_21),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_30),
.C(n_27),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_31),
.Y(n_40)
);

NAND2x1p5_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_36),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_26),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_26),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OAI22xp33_ASAP7_75t_L g46 ( 
.A1(n_41),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_44),
.Y(n_47)
);

OAI21xp33_ASAP7_75t_SL g48 ( 
.A1(n_46),
.A2(n_8),
.B(n_6),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

NOR3xp33_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_14),
.C(n_11),
.Y(n_51)
);

NAND3xp33_ASAP7_75t_L g52 ( 
.A(n_51),
.B(n_50),
.C(n_18),
.Y(n_52)
);


endmodule