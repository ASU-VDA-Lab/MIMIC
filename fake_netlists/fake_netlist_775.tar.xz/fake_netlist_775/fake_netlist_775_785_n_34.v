module fake_netlist_775_785_n_34 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_34);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_34;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_31;
wire n_27;
wire n_33;
wire n_26;
wire n_24;
wire n_18;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_6),
.Y(n_17)
);

AO21x2_ASAP7_75t_L g18 ( 
.A1(n_2),
.A2(n_11),
.B(n_3),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_15),
.B(n_8),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_9),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_20),
.B(n_4),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_21),
.B(n_4),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_7),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_R g27 ( 
.A(n_23),
.B(n_19),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_24),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_17),
.B1(n_16),
.B2(n_27),
.C(n_18),
.Y(n_30)
);

INVx3_ASAP7_75t_SL g31 ( 
.A(n_30),
.Y(n_31)
);

CKINVDCx16_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_16),
.B2(n_7),
.Y(n_33)
);

AOI222xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_18),
.B1(n_13),
.B2(n_0),
.C1(n_14),
.C2(n_1),
.Y(n_34)
);


endmodule