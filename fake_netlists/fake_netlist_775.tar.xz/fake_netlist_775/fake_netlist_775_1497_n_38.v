module fake_netlist_775_1497_n_38 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_38);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_38;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_26;
wire n_24;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_4),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_12),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

OR2x6_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_0),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_14),
.B(n_0),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_17),
.B1(n_19),
.B2(n_15),
.C(n_14),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_19),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OAI22xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_26),
.B1(n_25),
.B2(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_22),
.C(n_26),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_SL g33 ( 
.A(n_31),
.B(n_18),
.C(n_26),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_21),
.C(n_1),
.Y(n_34)
);

XNOR2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_1),
.Y(n_35)
);

AND3x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_5),
.C(n_4),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.C(n_8),
.Y(n_37)
);

AOI322xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_36),
.A3(n_35),
.B1(n_7),
.B2(n_6),
.C1(n_11),
.C2(n_13),
.Y(n_38)
);


endmodule