module fake_netlist_775_1708_n_18 (n_1, n_0, n_3, n_2, n_4, n_18);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_18;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_5;
wire n_16;
wire n_6;
wire n_14;
wire n_17;
wire n_9;
wire n_12;
wire n_13;
wire n_8;

AND2x2_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_1),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx5_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

OAI321xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_6),
.A3(n_5),
.B1(n_7),
.B2(n_1),
.C(n_0),
.Y(n_12)
);

XNOR2x1_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_2),
.Y(n_13)
);

AOI211x1_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_7),
.B(n_4),
.C(n_3),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_7),
.B1(n_11),
.B2(n_4),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

OR2x6_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_7),
.Y(n_17)
);

OAI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_7),
.B1(n_11),
.B2(n_13),
.C1(n_16),
.C2(n_15),
.Y(n_18)
);


endmodule