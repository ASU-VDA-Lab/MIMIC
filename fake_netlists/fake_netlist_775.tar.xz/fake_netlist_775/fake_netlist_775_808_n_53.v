module fake_netlist_775_808_n_53 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_53);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_53;

wire n_37;
wire n_45;
wire n_44;
wire n_52;
wire n_36;
wire n_29;
wire n_50;
wire n_35;
wire n_25;
wire n_40;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_49;
wire n_48;
wire n_43;
wire n_38;
wire n_28;
wire n_30;
wire n_41;
wire n_51;
wire n_32;
wire n_47;

INVx1_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_0),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_2),
.B(n_16),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_1),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_23),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_9),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_18),
.Y(n_34)
);

INVx3_ASAP7_75t_SL g35 ( 
.A(n_26),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

INVx3_ASAP7_75t_SL g37 ( 
.A(n_32),
.Y(n_37)
);

OR2x6_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_29),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_35),
.Y(n_39)
);

AOI21xp5_ASAP7_75t_L g40 ( 
.A1(n_34),
.A2(n_28),
.B(n_27),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_34),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_37),
.Y(n_43)
);

INVxp67_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_42),
.Y(n_46)
);

OAI221xp5_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_39),
.B1(n_30),
.B2(n_25),
.C(n_31),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_SL g48 ( 
.A(n_46),
.B(n_33),
.Y(n_48)
);

AND2x4_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_3),
.Y(n_49)
);

NAND5xp2_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_19),
.C(n_18),
.D(n_4),
.E(n_5),
.Y(n_50)
);

XNOR2xp5_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_19),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_SL g52 ( 
.A1(n_50),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_52)
);

AOI322xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_12),
.A3(n_13),
.B1(n_14),
.B2(n_15),
.C1(n_21),
.C2(n_51),
.Y(n_53)
);


endmodule