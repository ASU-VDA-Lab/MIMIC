module fake_netlist_775_1147_n_62 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_62);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_62;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_20;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_49;
wire n_48;
wire n_43;
wire n_56;
wire n_38;
wire n_54;
wire n_61;
wire n_60;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_59;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;

AND2x4_ASAP7_75t_L g20 ( 
.A(n_8),
.B(n_3),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

INVx6_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_5),
.A2(n_10),
.B1(n_4),
.B2(n_0),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_27),
.B(n_0),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_25),
.A2(n_17),
.B1(n_16),
.B2(n_1),
.Y(n_31)
);

NAND2x1p5_ASAP7_75t_L g32 ( 
.A(n_20),
.B(n_11),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

INVx8_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_26),
.B(n_22),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_33),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_30),
.Y(n_39)
);

AOI211xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_31),
.B(n_27),
.C(n_28),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_36),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_SL g43 ( 
.A1(n_40),
.A2(n_38),
.B1(n_28),
.B2(n_21),
.C(n_39),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_39),
.B1(n_31),
.B2(n_20),
.Y(n_45)
);

BUFx3_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

AOI21xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_34),
.B(n_23),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

NOR3x1_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_24),
.C(n_1),
.Y(n_49)
);

OAI31xp33_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_34),
.A3(n_18),
.B(n_17),
.Y(n_50)
);

NAND3xp33_ASAP7_75t_SL g51 ( 
.A(n_50),
.B(n_43),
.C(n_34),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_46),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

OR5x1_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_43),
.C(n_19),
.D(n_28),
.E(n_12),
.Y(n_54)
);

OAI22xp5_ASAP7_75t_SL g55 ( 
.A1(n_47),
.A2(n_46),
.B1(n_28),
.B2(n_19),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_13),
.Y(n_57)
);

BUFx6f_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_51),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_SL g60 ( 
.A1(n_58),
.A2(n_59),
.B1(n_56),
.B2(n_57),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

XNOR2xp5_ASAP7_75t_L g62 ( 
.A(n_60),
.B(n_61),
.Y(n_62)
);


endmodule