module fake_netlist_775_2833_n_38 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_4, n_8, n_38);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_4;
input n_8;

output n_38;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_1),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_4),
.B(n_12),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_5),
.Y(n_18)
);

AO21x2_ASAP7_75t_L g19 ( 
.A1(n_6),
.A2(n_2),
.B(n_8),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_15),
.B(n_0),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_15),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_14),
.B(n_3),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_4),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_18),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_13),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_21),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_19),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_25),
.B1(n_26),
.B2(n_19),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_25),
.B1(n_26),
.B2(n_17),
.C(n_6),
.Y(n_30)
);

AOI221xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B1(n_17),
.B2(n_19),
.C(n_7),
.Y(n_31)
);

AO22x2_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_19),
.B1(n_7),
.B2(n_9),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

NOR4xp25_ASAP7_75t_SL g34 ( 
.A(n_31),
.B(n_10),
.C(n_30),
.D(n_20),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_SL g38 ( 
.A1(n_37),
.A2(n_34),
.B1(n_35),
.B2(n_36),
.Y(n_38)
);


endmodule