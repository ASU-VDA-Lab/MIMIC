module fake_netlist_775_2780_n_37 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_37);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_37;

wire n_20;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_26;
wire n_24;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_32;
wire n_22;

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_7),
.B(n_5),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_2),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_8),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_16),
.B(n_12),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_15),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

INVx4_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

NAND2x1p5_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_0),
.Y(n_28)
);

NOR2x1_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_16),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_27),
.B(n_22),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_28),
.B1(n_25),
.B2(n_23),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_20),
.B(n_30),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_17),
.B1(n_6),
.B2(n_1),
.C(n_4),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

OAI22x1_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_19),
.B1(n_14),
.B2(n_13),
.Y(n_37)
);


endmodule