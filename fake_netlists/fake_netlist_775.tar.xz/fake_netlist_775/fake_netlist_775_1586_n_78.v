module fake_netlist_775_1586_n_78 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_25, n_5, n_24, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_78);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_25;
input n_5;
input n_24;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_78;

wire n_37;
wire n_55;
wire n_36;
wire n_63;
wire n_65;
wire n_35;
wire n_40;
wire n_73;
wire n_42;
wire n_48;
wire n_43;
wire n_68;
wire n_67;
wire n_54;
wire n_30;
wire n_59;
wire n_53;
wire n_74;
wire n_51;
wire n_45;
wire n_62;
wire n_75;
wire n_31;
wire n_76;
wire n_28;
wire n_64;
wire n_29;
wire n_70;
wire n_69;
wire n_71;
wire n_26;
wire n_49;
wire n_56;
wire n_61;
wire n_32;
wire n_47;
wire n_44;
wire n_52;
wire n_77;
wire n_50;
wire n_58;
wire n_66;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_38;
wire n_60;
wire n_57;
wire n_41;
wire n_72;

INVx2_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_10),
.B(n_23),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_5),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_15),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_SL g35 ( 
.A1(n_23),
.A2(n_7),
.B1(n_9),
.B2(n_3),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_8),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_1),
.B(n_12),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_11),
.Y(n_38)
);

INVx4_ASAP7_75t_L g39 ( 
.A(n_17),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_34),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_19),
.Y(n_41)
);

BUFx6f_ASAP7_75t_L g42 ( 
.A(n_31),
.Y(n_42)
);

NAND2x1p5_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_2),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_38),
.B(n_22),
.Y(n_44)
);

INVx8_ASAP7_75t_L g45 ( 
.A(n_27),
.Y(n_45)
);

INVx3_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

OAI21x1_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_36),
.B(n_30),
.Y(n_47)
);

BUFx3_ASAP7_75t_L g48 ( 
.A(n_42),
.Y(n_48)
);

AO31x2_ASAP7_75t_L g49 ( 
.A1(n_44),
.A2(n_33),
.A3(n_39),
.B(n_26),
.Y(n_49)
);

AO21x2_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_44),
.B(n_41),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_46),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_49),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_49),
.Y(n_55)
);

INVx2_ASAP7_75t_SL g56 ( 
.A(n_50),
.Y(n_56)
);

OR2x2_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_40),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_55),
.Y(n_58)
);

OR2x2_ASAP7_75t_L g59 ( 
.A(n_53),
.B(n_46),
.Y(n_59)
);

INVx4_ASAP7_75t_L g60 ( 
.A(n_54),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_59),
.Y(n_61)
);

AOI22xp5_ASAP7_75t_L g62 ( 
.A1(n_60),
.A2(n_35),
.B1(n_56),
.B2(n_50),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_45),
.Y(n_63)
);

O2A1O1Ixp33_ASAP7_75t_L g64 ( 
.A1(n_57),
.A2(n_26),
.B(n_48),
.C(n_27),
.Y(n_64)
);

NAND2x1_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_37),
.Y(n_65)
);

NOR3x1_ASAP7_75t_L g66 ( 
.A(n_61),
.B(n_35),
.C(n_22),
.Y(n_66)
);

NAND3xp33_ASAP7_75t_SL g67 ( 
.A(n_64),
.B(n_45),
.C(n_48),
.Y(n_67)
);

A2O1A1Ixp33_ASAP7_75t_L g68 ( 
.A1(n_62),
.A2(n_32),
.B(n_29),
.C(n_28),
.Y(n_68)
);

NAND4xp25_ASAP7_75t_SL g69 ( 
.A(n_63),
.B(n_25),
.C(n_24),
.D(n_49),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_65),
.Y(n_70)
);

NOR2x1_ASAP7_75t_L g71 ( 
.A(n_70),
.B(n_29),
.Y(n_71)
);

AND2x4_ASAP7_75t_L g72 ( 
.A(n_66),
.B(n_4),
.Y(n_72)
);

NAND2xp5_ASAP7_75t_L g73 ( 
.A(n_68),
.B(n_28),
.Y(n_73)
);

NOR3xp33_ASAP7_75t_SL g74 ( 
.A(n_69),
.B(n_67),
.C(n_6),
.Y(n_74)
);

NAND2xp5_ASAP7_75t_L g75 ( 
.A(n_74),
.B(n_32),
.Y(n_75)
);

OAI22xp5_ASAP7_75t_L g76 ( 
.A1(n_72),
.A2(n_18),
.B1(n_16),
.B2(n_13),
.Y(n_76)
);

OAI21x1_ASAP7_75t_SL g77 ( 
.A1(n_75),
.A2(n_71),
.B(n_73),
.Y(n_77)
);

AOI21xp5_ASAP7_75t_L g78 ( 
.A1(n_77),
.A2(n_76),
.B(n_21),
.Y(n_78)
);


endmodule