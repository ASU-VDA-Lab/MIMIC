module fake_netlist_775_1293_n_24 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_24);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_24;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

AOI21x1_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_0),
.B(n_4),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_10),
.B(n_5),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_2),
.A2(n_4),
.B1(n_1),
.B2(n_9),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_7),
.B(n_8),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_7),
.B(n_6),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_7),
.B(n_6),
.C(n_0),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_14),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_18),
.B1(n_19),
.B2(n_13),
.C(n_15),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_12),
.B(n_6),
.C(n_1),
.Y(n_22)
);

OAI22x1_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_8),
.B1(n_3),
.B2(n_2),
.Y(n_23)
);

AOI321xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_3),
.A3(n_9),
.B1(n_11),
.B2(n_16),
.C(n_18),
.Y(n_24)
);


endmodule