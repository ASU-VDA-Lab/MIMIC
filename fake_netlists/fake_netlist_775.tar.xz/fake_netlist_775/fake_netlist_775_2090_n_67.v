module fake_netlist_775_2090_n_67 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_67);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_67;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_64;
wire n_52;
wire n_29;
wire n_36;
wire n_63;
wire n_62;
wire n_65;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_66;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_49;
wire n_48;
wire n_43;
wire n_56;
wire n_38;
wire n_54;
wire n_61;
wire n_60;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_59;
wire n_53;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;
wire n_47;

INVx1_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_8),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_10),
.B(n_2),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_3),
.B(n_4),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_0),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_21),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_22),
.B(n_0),
.Y(n_35)
);

AOI21xp33_ASAP7_75t_SL g36 ( 
.A1(n_31),
.A2(n_24),
.B(n_21),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_28),
.B(n_27),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_29),
.B(n_22),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

OAI211xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_36),
.B(n_24),
.C(n_26),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_36),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_32),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_34),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_34),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_41),
.Y(n_47)
);

OAI22xp33_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_41),
.B1(n_25),
.B2(n_30),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_41),
.B1(n_25),
.B2(n_33),
.Y(n_49)
);

NAND2xp33_ASAP7_75t_SL g50 ( 
.A(n_47),
.B(n_46),
.Y(n_50)
);

AOI21xp33_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_33),
.B(n_3),
.Y(n_51)
);

OAI21xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_33),
.B(n_8),
.Y(n_52)
);

INVx1_ASAP7_75t_SL g53 ( 
.A(n_45),
.Y(n_53)
);

NOR2x1_ASAP7_75t_L g54 ( 
.A(n_53),
.B(n_33),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_33),
.Y(n_55)
);

AND4x1_ASAP7_75t_L g56 ( 
.A(n_49),
.B(n_11),
.C(n_10),
.D(n_9),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_50),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_L g58 ( 
.A(n_50),
.B(n_9),
.Y(n_58)
);

OAI22x1_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_51),
.B1(n_13),
.B2(n_11),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

XOR2xp5_ASAP7_75t_L g61 ( 
.A(n_54),
.B(n_57),
.Y(n_61)
);

OR2x2_ASAP7_75t_L g62 ( 
.A(n_57),
.B(n_13),
.Y(n_62)
);

INVx2_ASAP7_75t_L g63 ( 
.A(n_55),
.Y(n_63)
);

AOI222xp33_ASAP7_75t_SL g64 ( 
.A1(n_60),
.A2(n_17),
.B1(n_16),
.B2(n_18),
.C1(n_20),
.C2(n_19),
.Y(n_64)
);

OAI22xp5_ASAP7_75t_L g65 ( 
.A1(n_61),
.A2(n_55),
.B1(n_17),
.B2(n_16),
.Y(n_65)
);

AOI22xp5_ASAP7_75t_L g66 ( 
.A1(n_59),
.A2(n_18),
.B1(n_7),
.B2(n_5),
.Y(n_66)
);

AOI322xp5_ASAP7_75t_L g67 ( 
.A1(n_64),
.A2(n_14),
.A3(n_59),
.B1(n_62),
.B2(n_63),
.C1(n_66),
.C2(n_65),
.Y(n_67)
);


endmodule