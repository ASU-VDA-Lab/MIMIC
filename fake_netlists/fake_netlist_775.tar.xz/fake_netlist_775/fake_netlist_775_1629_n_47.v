module fake_netlist_775_1629_n_47 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_47);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_47;

wire n_37;
wire n_45;
wire n_44;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_40;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_43;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_41;
wire n_32;
wire n_22;

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_0),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_11),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

OR2x6_ASAP7_75t_L g27 ( 
.A(n_4),
.B(n_2),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

AND2x6_ASAP7_75t_L g31 ( 
.A(n_17),
.B(n_13),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_SL g34 ( 
.A(n_22),
.B(n_16),
.C(n_15),
.Y(n_34)
);

INVx4_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

AOI21x1_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_26),
.B(n_25),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_29),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_35),
.Y(n_38)
);

BUFx3_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

NOR4xp25_ASAP7_75t_SL g41 ( 
.A(n_40),
.B(n_33),
.C(n_34),
.D(n_24),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_39),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_27),
.B1(n_34),
.B2(n_37),
.Y(n_43)
);

AOI211xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_30),
.B(n_23),
.C(n_40),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_44),
.B1(n_31),
.B2(n_21),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_R g46 ( 
.A1(n_45),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_46)
);

AOI322xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_31),
.A3(n_5),
.B1(n_3),
.B2(n_1),
.C1(n_9),
.C2(n_8),
.Y(n_47)
);


endmodule