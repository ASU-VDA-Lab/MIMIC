module fake_netlist_800_2242_n_25 (n_1, n_0, n_5, n_3, n_2, n_4, n_25);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_25;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_24;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_4),
.B(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

OAI33xp33_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_9),
.A3(n_8),
.B1(n_4),
.B2(n_0),
.B3(n_2),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_11),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_SL g17 ( 
.A1(n_13),
.A2(n_10),
.B(n_15),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

AND4x1_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_3),
.C(n_1),
.D(n_2),
.Y(n_19)
);

AOI222xp33_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_10),
.B1(n_12),
.B2(n_14),
.C1(n_3),
.C2(n_2),
.Y(n_20)
);

NOR2x1_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_10),
.Y(n_21)
);

OA21x2_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_12),
.B(n_16),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_SL g23 ( 
.A1(n_20),
.A2(n_3),
.B(n_12),
.Y(n_23)
);

OAI22x1_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_5),
.B1(n_19),
.B2(n_20),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_5),
.B1(n_22),
.B2(n_23),
.Y(n_25)
);


endmodule