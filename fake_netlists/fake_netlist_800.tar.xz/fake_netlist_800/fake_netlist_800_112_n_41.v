module fake_netlist_800_112_n_41 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_41);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_41;

wire n_37;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_24;
wire n_26;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_32;
wire n_22;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_18),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_16),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_2),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_11),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_24),
.A2(n_11),
.B1(n_12),
.B2(n_10),
.C(n_1),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_R g31 ( 
.A(n_28),
.B(n_27),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_30),
.B1(n_25),
.B2(n_23),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_33),
.Y(n_34)
);

A2O1A1Ixp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_32),
.B(n_21),
.C(n_15),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_17),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_35),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_14),
.B1(n_9),
.B2(n_3),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_5),
.B1(n_8),
.B2(n_0),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_SL g41 ( 
.A1(n_40),
.A2(n_39),
.B1(n_20),
.B2(n_6),
.Y(n_41)
);


endmodule