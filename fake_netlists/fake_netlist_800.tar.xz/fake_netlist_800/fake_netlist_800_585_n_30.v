module fake_netlist_800_585_n_30 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_30);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_30;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_27;
wire n_26;
wire n_24;
wire n_18;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_21;
wire n_22;

INVx1_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_13),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_4),
.Y(n_20)
);

NOR2x1p5_ASAP7_75t_L g21 ( 
.A(n_0),
.B(n_6),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_16),
.A2(n_1),
.B1(n_0),
.B2(n_15),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_19),
.B(n_11),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_21),
.B1(n_19),
.B2(n_18),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_17),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

AOI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_23),
.B1(n_20),
.B2(n_9),
.C1(n_12),
.C2(n_10),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_27),
.Y(n_28)
);

NOR2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_7),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_R g30 ( 
.A1(n_29),
.A2(n_2),
.B1(n_3),
.B2(n_8),
.Y(n_30)
);


endmodule