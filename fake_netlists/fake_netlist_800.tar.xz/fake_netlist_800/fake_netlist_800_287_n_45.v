module fake_netlist_800_287_n_45 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_45);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_45;

wire n_37;
wire n_44;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_12;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_13;
wire n_18;
wire n_43;
wire n_15;
wire n_16;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_41;
wire n_32;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_10),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_11),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_8),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_7),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_9),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_16),
.A2(n_4),
.B(n_6),
.Y(n_22)
);

OA21x2_ASAP7_75t_L g23 ( 
.A1(n_16),
.A2(n_6),
.B(n_7),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_12),
.B(n_10),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_20),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_13),
.B1(n_14),
.B2(n_17),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_21),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_24),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_21),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_27),
.B1(n_23),
.B2(n_26),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_26),
.Y(n_36)
);

OAI321xp33_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_24),
.A3(n_22),
.B1(n_23),
.B2(n_28),
.C(n_15),
.Y(n_37)
);

AOI211xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_34),
.B(n_22),
.C(n_19),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_1),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

XNOR2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_40),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_SL g45 ( 
.A1(n_44),
.A2(n_3),
.B1(n_43),
.B2(n_42),
.Y(n_45)
);


endmodule