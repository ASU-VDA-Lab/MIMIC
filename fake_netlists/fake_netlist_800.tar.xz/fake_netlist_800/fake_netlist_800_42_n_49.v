module fake_netlist_800_42_n_49 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_24, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_49);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_24;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_49;

wire n_37;
wire n_45;
wire n_44;
wire n_47;
wire n_36;
wire n_29;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_42;
wire n_48;
wire n_43;
wire n_38;
wire n_28;
wire n_30;
wire n_41;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_4),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_8),
.Y(n_26)
);

INVxp33_ASAP7_75t_SL g27 ( 
.A(n_2),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_24),
.B(n_19),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_16),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_14),
.Y(n_30)
);

NOR2xp67_ASAP7_75t_L g31 ( 
.A(n_3),
.B(n_5),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_12),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_15),
.Y(n_33)
);

OAI21xp33_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_31),
.B(n_27),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_30),
.A2(n_23),
.B(n_21),
.Y(n_35)
);

INVx4_ASAP7_75t_L g36 ( 
.A(n_25),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_R g37 ( 
.A(n_36),
.B(n_26),
.Y(n_37)
);

AO21x2_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_28),
.B(n_29),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_37),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

INVxp67_ASAP7_75t_SL g41 ( 
.A(n_40),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_34),
.B1(n_32),
.B2(n_12),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_18),
.C(n_13),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_22),
.B1(n_20),
.B2(n_10),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_44),
.Y(n_45)
);

CKINVDCx16_ASAP7_75t_R g46 ( 
.A(n_43),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_1),
.B1(n_7),
.B2(n_0),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_SL g48 ( 
.A1(n_46),
.A2(n_11),
.B1(n_17),
.B2(n_6),
.Y(n_48)
);

AO21x2_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_9),
.B(n_48),
.Y(n_49)
);


endmodule