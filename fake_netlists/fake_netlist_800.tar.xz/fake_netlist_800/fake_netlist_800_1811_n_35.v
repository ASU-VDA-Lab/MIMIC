module fake_netlist_800_1811_n_35 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_17, n_9, n_2, n_12, n_13, n_4, n_8, n_35);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_17;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_35;

wire n_20;
wire n_29;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_26;
wire n_24;
wire n_18;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_4),
.B(n_13),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

AOI21x1_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_16),
.B(n_2),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

OR2x6_ASAP7_75t_L g22 ( 
.A(n_6),
.B(n_3),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_17),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_16),
.C(n_8),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_22),
.Y(n_26)
);

AO32x2_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_22),
.A3(n_8),
.B1(n_18),
.B2(n_23),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

NAND2x1_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_22),
.Y(n_29)
);

AOI321xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_27),
.A3(n_19),
.B1(n_12),
.B2(n_15),
.C(n_14),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_27),
.B2(n_11),
.Y(n_33)
);

XNOR2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_5),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_34),
.B1(n_7),
.B2(n_0),
.Y(n_35)
);


endmodule