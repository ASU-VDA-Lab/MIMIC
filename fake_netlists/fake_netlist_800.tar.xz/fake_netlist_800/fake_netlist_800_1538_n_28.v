module fake_netlist_800_1538_n_28 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_28);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_28;

wire n_20;
wire n_17;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_21;
wire n_22;

INVx1_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_8),
.Y(n_18)
);

NOR2x1p5_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_4),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_2),
.B1(n_1),
.B2(n_4),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_SL g21 ( 
.A1(n_15),
.A2(n_2),
.B(n_1),
.C(n_3),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_17),
.C(n_21),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_19),
.B1(n_17),
.B2(n_16),
.Y(n_24)
);

NOR4xp25_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_3),
.C(n_18),
.D(n_13),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_6),
.B1(n_9),
.B2(n_5),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_7),
.B1(n_12),
.B2(n_11),
.Y(n_28)
);


endmodule