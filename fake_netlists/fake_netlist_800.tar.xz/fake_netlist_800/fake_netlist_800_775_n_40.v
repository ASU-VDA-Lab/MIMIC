module fake_netlist_800_775_n_40 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_40);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_40;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_26;
wire n_24;
wire n_18;
wire n_15;
wire n_16;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_11),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_5),
.B(n_13),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_SL g22 ( 
.A(n_18),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_15),
.B(n_1),
.Y(n_24)
);

AO31x2_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_17),
.A3(n_20),
.B(n_14),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_21),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_20),
.C(n_27),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_21),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_20),
.B1(n_14),
.B2(n_24),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_25),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_16),
.Y(n_33)
);

OAI21xp33_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_14),
.B(n_21),
.Y(n_34)
);

NOR4xp75_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_2),
.C(n_5),
.D(n_4),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

NAND5xp2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_34),
.C(n_2),
.D(n_4),
.E(n_0),
.Y(n_37)
);

AND2x2_ASAP7_75t_SL g38 ( 
.A(n_36),
.B(n_3),
.Y(n_38)
);

OAI221xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_21),
.B1(n_3),
.B2(n_0),
.C(n_6),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_38),
.C(n_8),
.Y(n_40)
);


endmodule