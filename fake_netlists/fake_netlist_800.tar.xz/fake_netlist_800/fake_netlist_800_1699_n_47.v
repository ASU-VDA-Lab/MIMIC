module fake_netlist_800_1699_n_47 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_47);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_47;

wire n_37;
wire n_45;
wire n_44;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_43;
wire n_38;
wire n_28;
wire n_30;
wire n_41;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_15),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_6),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_22),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_14),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_5),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_R g31 ( 
.A(n_18),
.B(n_16),
.Y(n_31)
);

O2A1O1Ixp5_ASAP7_75t_SL g32 ( 
.A1(n_29),
.A2(n_23),
.B(n_12),
.C(n_19),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_24),
.B(n_27),
.Y(n_33)
);

AOI21x1_ASAP7_75t_L g34 ( 
.A1(n_24),
.A2(n_28),
.B(n_31),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_26),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_30),
.B1(n_25),
.B2(n_32),
.Y(n_37)
);

NOR2xp67_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_11),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_SL g39 ( 
.A(n_38),
.B(n_35),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_12),
.B1(n_23),
.B2(n_8),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_17),
.B(n_20),
.Y(n_41)
);

NAND3xp33_ASAP7_75t_SL g42 ( 
.A(n_40),
.B(n_10),
.C(n_7),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

BUFx4f_ASAP7_75t_SL g44 ( 
.A(n_41),
.Y(n_44)
);

OAI31xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_3),
.A3(n_13),
.B(n_4),
.Y(n_45)
);

XNOR2x1_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_0),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_1),
.B1(n_2),
.B2(n_45),
.Y(n_47)
);


endmodule