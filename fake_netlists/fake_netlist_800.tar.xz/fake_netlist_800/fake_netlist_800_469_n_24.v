module fake_netlist_800_469_n_24 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_24);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_24;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_8;
wire n_9;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

XNOR2x2_ASAP7_75t_SL g7 ( 
.A(n_4),
.B(n_6),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_5),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_9),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_8),
.Y(n_12)
);

CKINVDCx14_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_1),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_1),
.Y(n_15)
);

AOI22x1_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_7),
.B1(n_13),
.B2(n_4),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_14),
.C(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_2),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_18),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_2),
.B(n_3),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_20),
.B1(n_22),
.B2(n_0),
.Y(n_24)
);


endmodule