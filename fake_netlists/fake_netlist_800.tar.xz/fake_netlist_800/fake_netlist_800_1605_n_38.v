module fake_netlist_800_1605_n_38 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_14, n_38);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_14;

output n_38;

wire n_37;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_23;
wire n_28;
wire n_30;
wire n_32;
wire n_22;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_9),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_10),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_19),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_1),
.B(n_21),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_20),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_2),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_0),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_12),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_28),
.B(n_22),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_SL g31 ( 
.A(n_29),
.B(n_25),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_24),
.B1(n_23),
.B2(n_12),
.C1(n_14),
.C2(n_16),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI21xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.B(n_15),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_SL g35 ( 
.A(n_34),
.B(n_18),
.C(n_13),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

OAI22x1_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_11),
.B1(n_8),
.B2(n_7),
.Y(n_37)
);

AOI222xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_4),
.B1(n_6),
.B2(n_5),
.C1(n_3),
.C2(n_17),
.Y(n_38)
);


endmodule