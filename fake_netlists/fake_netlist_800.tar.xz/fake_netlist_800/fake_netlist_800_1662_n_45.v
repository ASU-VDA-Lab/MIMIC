module fake_netlist_800_1662_n_45 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_4, n_8, n_45);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_4;
input n_8;

output n_45;

wire n_37;
wire n_44;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_18;
wire n_13;
wire n_43;
wire n_15;
wire n_16;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_41;
wire n_32;
wire n_22;
wire n_14;

BUFx2_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_2),
.B(n_5),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_4),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_9),
.B(n_7),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_3),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_18),
.B1(n_15),
.B2(n_16),
.C(n_20),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_15),
.B1(n_14),
.B2(n_17),
.Y(n_28)
);

OA21x2_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_25),
.B(n_23),
.Y(n_29)
);

OA222x2_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_22),
.B1(n_24),
.B2(n_27),
.C1(n_23),
.C2(n_21),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_25),
.Y(n_31)
);

NOR2x1p5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_31),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_29),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

XOR2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_33),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_34),
.B(n_22),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_22),
.B1(n_29),
.B2(n_1),
.C(n_0),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_22),
.B(n_29),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NOR3xp33_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_22),
.C(n_11),
.Y(n_41)
);

XOR2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_6),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_8),
.B1(n_41),
.B2(n_43),
.Y(n_45)
);


endmodule