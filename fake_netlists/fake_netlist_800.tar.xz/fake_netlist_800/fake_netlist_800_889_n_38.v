module fake_netlist_800_889_n_38 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_38);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_38;

wire n_37;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_26;
wire n_24;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_32;
wire n_22;

INVx2_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_13),
.B(n_9),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_4),
.B(n_10),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_0),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_21),
.B(n_23),
.Y(n_28)
);

O2A1O1Ixp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_15),
.B(n_12),
.C(n_14),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_19),
.B(n_7),
.Y(n_30)
);

AND2x4_ASAP7_75t_SL g31 ( 
.A(n_28),
.B(n_22),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_30),
.B1(n_27),
.B2(n_31),
.C(n_11),
.Y(n_34)
);

AOI21xp33_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_2),
.B(n_5),
.Y(n_35)
);

INVxp67_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_36),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_R g38 ( 
.A1(n_37),
.A2(n_6),
.B1(n_16),
.B2(n_1),
.C(n_3),
.Y(n_38)
);


endmodule