module fake_netlist_800_666_n_36 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_36);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_36;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

INVx3_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

NAND2xp33_ASAP7_75t_R g13 ( 
.A(n_4),
.B(n_10),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_11),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

NOR2xp67_ASAP7_75t_L g22 ( 
.A(n_12),
.B(n_6),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_21),
.B(n_18),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_R g25 ( 
.A(n_20),
.B(n_15),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_20),
.Y(n_26)
);

INVxp67_ASAP7_75t_SL g27 ( 
.A(n_23),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_26),
.B(n_24),
.Y(n_28)
);

O2A1O1Ixp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_19),
.B(n_25),
.C(n_22),
.Y(n_29)
);

NOR4xp25_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_26),
.C(n_16),
.D(n_27),
.Y(n_30)
);

AOI321xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_26),
.A3(n_13),
.B1(n_17),
.B2(n_14),
.C(n_1),
.Y(n_31)
);

NOR2x1_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_31),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_31),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_31),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_16),
.B1(n_6),
.B2(n_0),
.Y(n_35)
);

AOI222xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_2),
.B1(n_8),
.B2(n_9),
.C1(n_34),
.C2(n_33),
.Y(n_36)
);


endmodule