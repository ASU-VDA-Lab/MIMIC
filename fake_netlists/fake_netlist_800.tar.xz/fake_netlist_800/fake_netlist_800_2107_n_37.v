module fake_netlist_800_2107_n_37 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_37);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_37;

wire n_20;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_26;
wire n_24;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_32;
wire n_22;

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_7),
.B(n_9),
.Y(n_20)
);

XOR2xp5_ASAP7_75t_L g21 ( 
.A(n_8),
.B(n_12),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_3),
.B(n_6),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_14),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_5),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

NAND3xp33_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_11),
.C(n_16),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_20),
.A2(n_19),
.B(n_17),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_25),
.Y(n_31)
);

INVx3_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

AOI221xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_27),
.B1(n_21),
.B2(n_31),
.C(n_24),
.Y(n_33)
);

AOI211xp5_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_11),
.B(n_22),
.C(n_13),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_2),
.C(n_10),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_0),
.B1(n_18),
.B2(n_4),
.Y(n_37)
);


endmodule