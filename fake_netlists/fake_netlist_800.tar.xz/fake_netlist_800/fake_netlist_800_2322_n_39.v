module fake_netlist_800_2322_n_39 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_39);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_39;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_26;
wire n_24;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_32;
wire n_22;

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_3),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_15),
.B(n_19),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_R g25 ( 
.A(n_7),
.B(n_17),
.Y(n_25)
);

NOR2xp67_ASAP7_75t_L g26 ( 
.A(n_13),
.B(n_2),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_8),
.B1(n_18),
.B2(n_11),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_22),
.B(n_8),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_21),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_20),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AND4x1_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_27),
.C(n_25),
.D(n_30),
.Y(n_34)
);

NOR4xp25_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_31),
.C(n_24),
.D(n_9),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI22x1_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_12),
.B1(n_4),
.B2(n_6),
.Y(n_37)
);

XNOR2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_37),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_1),
.B1(n_16),
.B2(n_0),
.Y(n_39)
);


endmodule