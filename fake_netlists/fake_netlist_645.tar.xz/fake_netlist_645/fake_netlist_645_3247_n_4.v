module fake_netlist_645_3247_n_4 (n_0, n_4);

input n_0;

output n_4;

wire n_3;
wire n_1;
wire n_2;

INVxp67_ASAP7_75t_SL g1 ( 
.A(n_0),
.Y(n_1)
);

INVx1_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

OAI21x1_ASAP7_75t_L g3 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_3)
);

AOI22xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_0),
.B1(n_2),
.B2(n_1),
.Y(n_4)
);


endmodule