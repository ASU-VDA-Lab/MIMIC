module fake_netlist_645_1410_n_18 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_18);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_18;

wire n_17;
wire n_14;
wire n_10;
wire n_11;
wire n_9;
wire n_15;
wire n_13;
wire n_16;
wire n_12;

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_4),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_6),
.Y(n_10)
);

OAI21xp33_ASAP7_75t_SL g11 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.Y(n_11)
);

AOI221x1_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_7),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);

NAND4xp25_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.C(n_11),
.D(n_7),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B1(n_7),
.B2(n_3),
.C(n_4),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_14),
.B1(n_8),
.B2(n_5),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_8),
.B2(n_5),
.Y(n_18)
);


endmodule