module fake_netlist_645_2767_n_37 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_37);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_37;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_10;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_9;
wire n_32;
wire n_13;
wire n_8;

CKINVDCx20_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_6),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_7),
.B(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

OAI21x1_ASAP7_75t_SL g15 ( 
.A1(n_11),
.A2(n_6),
.B(n_0),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_16)
);

INVx5_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_9),
.B(n_1),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_3),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_13),
.B(n_12),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_23),
.Y(n_27)
);

INVxp67_ASAP7_75t_SL g28 ( 
.A(n_25),
.Y(n_28)
);

NAND4xp25_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_16),
.C(n_23),
.D(n_12),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_16),
.B1(n_13),
.B2(n_8),
.C(n_17),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_30),
.A2(n_17),
.B1(n_28),
.B2(n_26),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_29),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_33),
.B1(n_32),
.B2(n_26),
.Y(n_34)
);

AO22x2_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_10),
.B1(n_21),
.B2(n_3),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_22),
.B1(n_17),
.B2(n_10),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_34),
.A2(n_35),
.B1(n_36),
.B2(n_22),
.Y(n_37)
);


endmodule