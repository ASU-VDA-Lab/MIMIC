module fake_netlist_645_5899_n_40 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_40);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_40;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_11;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_39;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_1),
.B(n_10),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_3),
.B(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_0),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_5),
.B1(n_4),
.B2(n_0),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_22)
);

BUFx12f_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_18),
.A2(n_12),
.B1(n_15),
.B2(n_14),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_15),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_19),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_9),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AO21x1_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_22),
.B(n_20),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_28),
.B(n_29),
.Y(n_32)
);

AOI222xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_23),
.B1(n_27),
.B2(n_24),
.C1(n_28),
.C2(n_29),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_27),
.B1(n_28),
.B2(n_13),
.C(n_29),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_32),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_27),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_35),
.B1(n_37),
.B2(n_29),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_23),
.B1(n_26),
.B2(n_6),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_SL g40 ( 
.A1(n_39),
.A2(n_7),
.B1(n_23),
.B2(n_38),
.Y(n_40)
);


endmodule