module fake_netlist_645_5400_n_4 (n_0, n_4);

input n_0;

output n_4;

wire n_3;
wire n_1;
wire n_2;

INVx2_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

AND2x2_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

NAND3xp33_ASAP7_75t_SL g3 ( 
.A(n_2),
.B(n_0),
.C(n_1),
.Y(n_3)
);

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_3),
.Y(n_4)
);


endmodule