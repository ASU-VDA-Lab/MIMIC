module fake_netlist_645_5544_n_30 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_30);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_30;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_11;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_12;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_26;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_3),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_5),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_0),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_11),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_14),
.B1(n_15),
.B2(n_13),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_18),
.B1(n_12),
.B2(n_1),
.C(n_2),
.Y(n_24)
);

AOI221x1_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_4),
.B1(n_3),
.B2(n_6),
.C(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_6),
.Y(n_27)
);

INVx2_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

NOR2x1_ASAP7_75t_R g29 ( 
.A(n_26),
.B(n_12),
.Y(n_29)
);

AOI322xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_8),
.A3(n_9),
.B1(n_10),
.B2(n_29),
.C1(n_12),
.C2(n_16),
.Y(n_30)
);


endmodule