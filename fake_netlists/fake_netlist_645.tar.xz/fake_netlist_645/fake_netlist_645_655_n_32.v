module fake_netlist_645_655_n_32 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_32);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_32;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_9;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_6),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_6),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_2),
.B(n_6),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_2),
.B(n_3),
.Y(n_14)
);

INVx5_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_13),
.B(n_4),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_4),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_7),
.B(n_4),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_15),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_20),
.B1(n_16),
.B2(n_18),
.Y(n_24)
);

OAI22xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_20),
.B1(n_13),
.B2(n_9),
.Y(n_25)
);

AOI322xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_12),
.A3(n_11),
.B1(n_10),
.B2(n_14),
.C1(n_7),
.C2(n_15),
.Y(n_26)
);

OAI321xp33_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_14),
.A3(n_19),
.B1(n_3),
.B2(n_1),
.C(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_26),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_21),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_27),
.B(n_21),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_28),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_5),
.B1(n_8),
.B2(n_30),
.Y(n_32)
);


endmodule