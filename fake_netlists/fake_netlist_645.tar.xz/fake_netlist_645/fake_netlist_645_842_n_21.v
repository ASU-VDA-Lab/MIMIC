module fake_netlist_645_842_n_21 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_21);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_15;
wire n_11;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_5),
.B(n_0),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_2),
.B(n_1),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_5),
.B(n_7),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_12),
.B(n_13),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_6),
.B(n_4),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.B(n_16),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_7),
.C(n_6),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_10),
.B1(n_8),
.B2(n_3),
.Y(n_21)
);


endmodule