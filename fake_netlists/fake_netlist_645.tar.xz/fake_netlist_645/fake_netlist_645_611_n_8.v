module fake_netlist_645_611_n_8 (n_1, n_0, n_8);

input n_1;
input n_0;

output n_8;

wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_6;
wire n_3;

AND2x2_ASAP7_75t_L g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

CKINVDCx20_ASAP7_75t_R g3 ( 
.A(n_2),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);

NOR2xp67_ASAP7_75t_SL g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

AOI221xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_4),
.C(n_3),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);

OR2x6_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_0),
.Y(n_8)
);


endmodule