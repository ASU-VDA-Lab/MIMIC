module fake_netlist_645_5587_n_14 (n_4, n_1, n_2, n_0, n_5, n_3, n_14);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_14;

wire n_7;
wire n_13;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;
wire n_9;

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_4),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B(n_2),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_0),
.B2(n_3),
.C(n_5),
.Y(n_12)
);

XOR2x1_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_0),
.Y(n_13)
);

OR2x6_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_1),
.Y(n_14)
);


endmodule