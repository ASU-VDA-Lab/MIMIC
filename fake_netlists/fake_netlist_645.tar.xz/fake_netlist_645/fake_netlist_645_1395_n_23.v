module fake_netlist_645_1395_n_23 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_23);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_23;

wire n_18;
wire n_19;
wire n_11;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_4),
.A2(n_5),
.B1(n_7),
.B2(n_9),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_12),
.B(n_3),
.Y(n_14)
);

OAI22x1_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_17),
.Y(n_19)
);

AOI211x1_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_13),
.B(n_16),
.C(n_11),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

AOI22x1_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_8),
.B1(n_6),
.B2(n_2),
.Y(n_22)
);

AO21x2_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B(n_10),
.Y(n_23)
);


endmodule