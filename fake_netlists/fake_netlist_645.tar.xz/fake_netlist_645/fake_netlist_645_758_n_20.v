module fake_netlist_645_758_n_20 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_20);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_20;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_9),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_5),
.C(n_6),
.Y(n_11)
);

AO221x1_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_3),
.B1(n_0),
.B2(n_6),
.C(n_2),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_4),
.B(n_8),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_13),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_1),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_12),
.Y(n_17)
);

O2A1O1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_16),
.B(n_10),
.C(n_11),
.Y(n_18)
);

XNOR2x1_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_11),
.B(n_4),
.Y(n_20)
);


endmodule