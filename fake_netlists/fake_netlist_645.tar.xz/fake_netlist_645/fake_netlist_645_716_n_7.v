module fake_netlist_645_716_n_7 (n_4, n_1, n_2, n_0, n_3, n_7);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_7;

wire n_5;
wire n_6;

OAI221xp5_ASAP7_75t_L g5 ( 
.A1(n_1),
.A2(n_2),
.B1(n_4),
.B2(n_0),
.C(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B1(n_2),
.B2(n_5),
.Y(n_7)
);


endmodule