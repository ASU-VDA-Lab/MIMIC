module fake_netlist_645_5554_n_8 (n_1, n_2, n_0, n_8);

input n_1;
input n_2;
input n_0;

output n_8;

wire n_4;
wire n_7;
wire n_5;
wire n_6;
wire n_3;

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

BUFx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NOR3xp33_ASAP7_75t_SL g7 ( 
.A(n_6),
.B(n_4),
.C(n_1),
.Y(n_7)
);

OAI22xp5_ASAP7_75t_SL g8 ( 
.A1(n_7),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_8)
);


endmodule