module fake_netlist_645_824_n_29 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_29);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_29;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_26;
wire n_9;
wire n_13;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_3),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_1),
.Y(n_11)
);

NOR2xp67_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_3),
.Y(n_12)
);

A2O1A1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.B(n_1),
.C(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_7),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_10),
.A2(n_7),
.B(n_0),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_10),
.A2(n_7),
.B(n_1),
.Y(n_16)
);

AO22x2_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_10),
.B1(n_12),
.B2(n_2),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_18),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_17),
.C(n_11),
.D(n_9),
.Y(n_23)
);

AOI222xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_20),
.B1(n_21),
.B2(n_17),
.C1(n_3),
.C2(n_2),
.Y(n_24)
);

NAND4xp25_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_21),
.C(n_20),
.D(n_17),
.Y(n_25)
);

AOI322xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_21),
.A3(n_20),
.B1(n_5),
.B2(n_6),
.C1(n_2),
.C2(n_4),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_25),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_28)
);

AOI222xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_5),
.B1(n_26),
.B2(n_11),
.C1(n_9),
.C2(n_8),
.Y(n_29)
);


endmodule