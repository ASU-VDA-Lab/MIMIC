module fake_netlist_716_2205_n_25 (n_1, n_2, n_0, n_3, n_4, n_25);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_25;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_7;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_8;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_6;
wire n_19;
wire n_5;

INVx2_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_3),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVxp67_ASAP7_75t_SL g11 ( 
.A(n_8),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_6),
.Y(n_12)
);

INVxp67_ASAP7_75t_SL g13 ( 
.A(n_9),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_9),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_13),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_10),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_7),
.B1(n_9),
.B2(n_10),
.C(n_14),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_18),
.Y(n_20)
);

NAND4xp75_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_2),
.C(n_3),
.D(n_0),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_2),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_20),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_10),
.B1(n_21),
.B2(n_23),
.Y(n_25)
);


endmodule