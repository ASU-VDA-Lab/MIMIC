module fake_netlist_716_725_n_30 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_6, n_14, n_0, n_3, n_4, n_5, n_30);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_30;

wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_18;
wire n_28;
wire n_25;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

AND2x6_ASAP7_75t_L g15 ( 
.A(n_4),
.B(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_8),
.B(n_1),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_9),
.A2(n_5),
.B(n_12),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_11),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_7),
.B(n_6),
.Y(n_21)
);

CKINVDCx6p67_ASAP7_75t_R g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_22),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_15),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_19),
.B1(n_17),
.B2(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_3),
.B1(n_13),
.B2(n_0),
.Y(n_30)
);


endmodule