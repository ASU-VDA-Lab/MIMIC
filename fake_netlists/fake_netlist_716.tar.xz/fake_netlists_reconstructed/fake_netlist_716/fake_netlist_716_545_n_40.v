module fake_netlist_716_545_n_40 (n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_40);

input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_40;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_39;
wire n_25;
wire n_12;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_38;
wire n_34;
wire n_16;
wire n_22;
wire n_19;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_10),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_4),
.B(n_3),
.Y(n_13)
);

INVxp67_ASAP7_75t_SL g14 ( 
.A(n_6),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_1),
.B(n_4),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_8),
.B1(n_7),
.B2(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_1),
.C(n_3),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_7),
.B(n_9),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_13),
.A2(n_15),
.B(n_19),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_8),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

NAND2x1_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_18),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_23),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_22),
.Y(n_31)
);

NAND4xp75_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_23),
.C(n_17),
.D(n_12),
.Y(n_32)
);

AOI221xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_20),
.B1(n_14),
.B2(n_17),
.C(n_12),
.Y(n_33)
);

OAI322xp33_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_20),
.A3(n_18),
.B1(n_26),
.B2(n_2),
.C1(n_9),
.C2(n_0),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_32),
.B(n_29),
.Y(n_35)
);

NOR2x1_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_27),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_27),
.B1(n_18),
.B2(n_22),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_35),
.A2(n_18),
.B1(n_21),
.B2(n_37),
.Y(n_39)
);

AOI31xp67_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_18),
.A3(n_21),
.B(n_39),
.Y(n_40)
);


endmodule