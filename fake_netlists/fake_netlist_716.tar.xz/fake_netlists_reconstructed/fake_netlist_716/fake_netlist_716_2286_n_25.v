module fake_netlist_716_2286_n_25 (n_12, n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_25);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_25;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_23;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_8),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_3),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_7),
.B(n_12),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_5),
.C(n_12),
.Y(n_17)
);

CKINVDCx10_ASAP7_75t_R g18 ( 
.A(n_15),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI321xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_18),
.A3(n_15),
.B1(n_5),
.B2(n_13),
.C(n_14),
.Y(n_22)
);

OAI21x1_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_9),
.B(n_6),
.Y(n_23)
);

AND3x1_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_11),
.C(n_10),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_25)
);


endmodule