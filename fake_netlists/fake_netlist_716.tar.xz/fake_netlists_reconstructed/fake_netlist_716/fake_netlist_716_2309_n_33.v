module fake_netlist_716_2309_n_33 (n_3, n_14, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_5, n_33);

input n_3;
input n_14;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_5;

output n_33;

wire n_32;
wire n_30;
wire n_20;
wire n_27;
wire n_24;
wire n_29;
wire n_31;
wire n_28;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_22;
wire n_19;

INVx3_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_7),
.B(n_4),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_9),
.Y(n_22)
);

AO22x2_ASAP7_75t_L g23 ( 
.A1(n_0),
.A2(n_17),
.B1(n_2),
.B2(n_15),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_20),
.B(n_21),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_16),
.B1(n_13),
.B2(n_14),
.Y(n_26)
);

CKINVDCx16_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_22),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_25),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_24),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

OAI22x1_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_19),
.B1(n_10),
.B2(n_8),
.Y(n_32)
);

AOI222xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_18),
.B1(n_5),
.B2(n_6),
.C1(n_1),
.C2(n_3),
.Y(n_33)
);


endmodule