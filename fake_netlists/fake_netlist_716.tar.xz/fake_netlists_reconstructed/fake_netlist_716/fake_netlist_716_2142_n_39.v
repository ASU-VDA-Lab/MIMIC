module fake_netlist_716_2142_n_39 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_19, n_5, n_39);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_19;
input n_5;

output n_39;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_27;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_31;
wire n_28;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_38;
wire n_34;
wire n_22;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

NOR2xp67_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_10),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_18),
.Y(n_25)
);

NAND2xp33_ASAP7_75t_R g26 ( 
.A(n_14),
.B(n_4),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_9),
.B(n_6),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_2),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_24),
.B(n_11),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_11),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_16),
.B(n_13),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_25),
.B1(n_21),
.B2(n_22),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_28),
.B1(n_27),
.B2(n_31),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

A2O1A1Ixp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_32),
.B(n_27),
.C(n_26),
.Y(n_35)
);

OAI221xp5_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_20),
.B1(n_12),
.B2(n_8),
.C(n_17),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_36),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_37),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_0),
.B1(n_1),
.B2(n_7),
.Y(n_39)
);


endmodule