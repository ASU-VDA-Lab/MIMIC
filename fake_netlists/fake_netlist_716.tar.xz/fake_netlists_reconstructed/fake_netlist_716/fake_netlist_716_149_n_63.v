module fake_netlist_716_149_n_63 (n_3, n_14, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_5, n_63);

input n_3;
input n_14;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_5;

output n_63;

wire n_60;
wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_61;
wire n_30;
wire n_35;
wire n_54;
wire n_20;
wire n_27;
wire n_36;
wire n_24;
wire n_37;
wire n_29;
wire n_41;
wire n_55;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_57;
wire n_25;
wire n_46;
wire n_23;
wire n_56;
wire n_47;
wire n_21;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_62;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_59;
wire n_22;
wire n_19;

INVx1_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_15),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_0),
.B(n_9),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_1),
.B(n_8),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_3),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_26),
.B(n_16),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

OR2x6_ASAP7_75t_L g32 ( 
.A(n_27),
.B(n_18),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_24),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_22),
.B(n_19),
.Y(n_35)
);

BUFx3_ASAP7_75t_L g36 ( 
.A(n_31),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_27),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_30),
.B(n_31),
.Y(n_38)
);

AO21x2_ASAP7_75t_L g39 ( 
.A1(n_30),
.A2(n_29),
.B(n_28),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_33),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_38),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_36),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_38),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_40),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_39),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_42),
.B1(n_39),
.B2(n_43),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_R g49 ( 
.A(n_45),
.B(n_20),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_39),
.Y(n_50)
);

INVx3_ASAP7_75t_L g51 ( 
.A(n_44),
.Y(n_51)
);

AOI221x1_ASAP7_75t_SL g52 ( 
.A1(n_49),
.A2(n_20),
.B1(n_32),
.B2(n_39),
.C(n_14),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_SL g53 ( 
.A(n_50),
.B(n_36),
.Y(n_53)
);

OR2x2_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_32),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_48),
.A2(n_23),
.B(n_31),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_53),
.Y(n_56)
);

NOR3xp33_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_32),
.C(n_17),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_SL g58 ( 
.A(n_52),
.B(n_32),
.Y(n_58)
);

OAI22x1_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_21),
.B1(n_11),
.B2(n_7),
.Y(n_59)
);

HB1xp67_ASAP7_75t_L g60 ( 
.A(n_56),
.Y(n_60)
);

NOR4xp25_ASAP7_75t_SL g61 ( 
.A(n_57),
.B(n_21),
.C(n_13),
.D(n_6),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_60),
.Y(n_62)
);

AOI22x1_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_59),
.B1(n_61),
.B2(n_2),
.Y(n_63)
);


endmodule