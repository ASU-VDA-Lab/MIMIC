module fake_netlist_716_213_n_43 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_6, n_19, n_5, n_43);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_6;
input n_19;
input n_5;

output n_43;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_24;
wire n_37;
wire n_29;
wire n_41;
wire n_31;
wire n_28;
wire n_39;
wire n_25;
wire n_23;
wire n_26;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_22;

INVx1_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_8),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_15),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_10),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_10),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_21),
.B1(n_18),
.B2(n_11),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_30),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_23),
.B1(n_24),
.B2(n_22),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

OAI21xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_34),
.B(n_32),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_26),
.B1(n_25),
.B2(n_9),
.C(n_7),
.Y(n_37)
);

NOR4xp25_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_14),
.C(n_6),
.D(n_13),
.Y(n_38)
);

INVxp67_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_3),
.B1(n_17),
.B2(n_5),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_41),
.B1(n_2),
.B2(n_1),
.Y(n_43)
);


endmodule