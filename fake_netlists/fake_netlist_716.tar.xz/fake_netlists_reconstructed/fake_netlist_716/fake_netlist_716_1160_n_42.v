module fake_netlist_716_1160_n_42 (n_12, n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_42);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_42;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_39;
wire n_25;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_38;
wire n_34;
wire n_40;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

NOR2xp67_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_2),
.Y(n_15)
);

BUFx2_ASAP7_75t_SL g16 ( 
.A(n_7),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_9),
.B(n_0),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_2),
.A2(n_3),
.B1(n_4),
.B2(n_5),
.Y(n_19)
);

AOI22x1_ASAP7_75t_SL g20 ( 
.A1(n_6),
.A2(n_11),
.B1(n_12),
.B2(n_9),
.Y(n_20)
);

NOR2x1p5_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_7),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_15),
.A2(n_19),
.B1(n_13),
.B2(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

OAI21x1_ASAP7_75t_SL g27 ( 
.A1(n_22),
.A2(n_14),
.B(n_23),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_21),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_17),
.Y(n_29)
);

NAND4xp25_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_26),
.C(n_27),
.D(n_18),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_28),
.C(n_20),
.Y(n_32)
);

INVxp67_ASAP7_75t_SL g33 ( 
.A(n_31),
.Y(n_33)
);

AOI211xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_28),
.B(n_33),
.C(n_17),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_28),
.B1(n_13),
.B2(n_29),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_32),
.A2(n_28),
.B1(n_27),
.B2(n_16),
.Y(n_36)
);

NAND4xp75_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_34),
.C(n_36),
.D(n_6),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

OAI221xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_37),
.B1(n_4),
.B2(n_0),
.C(n_3),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_29),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_SL g41 ( 
.A1(n_39),
.A2(n_1),
.B1(n_29),
.B2(n_40),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_1),
.B1(n_29),
.B2(n_39),
.C(n_18),
.Y(n_42)
);


endmodule