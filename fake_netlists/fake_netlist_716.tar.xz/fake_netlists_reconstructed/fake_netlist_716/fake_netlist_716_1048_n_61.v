module fake_netlist_716_1048_n_61 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_6, n_19, n_5, n_61);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_6;
input n_19;
input n_5;

output n_61;

wire n_60;
wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_27;
wire n_36;
wire n_37;
wire n_29;
wire n_24;
wire n_41;
wire n_55;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_57;
wire n_25;
wire n_22;
wire n_46;
wire n_23;
wire n_56;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_40;
wire n_34;
wire n_51;
wire n_59;
wire n_26;

INVx1_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_0),
.B(n_19),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_14),
.B(n_20),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

OA21x2_ASAP7_75t_L g30 ( 
.A1(n_10),
.A2(n_2),
.B(n_16),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_8),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_11),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_18),
.B(n_5),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_28),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_29),
.B(n_17),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_27),
.B(n_26),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_22),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_21),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_27),
.Y(n_39)
);

OAI21x1_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_30),
.B(n_32),
.Y(n_40)
);

OAI21x1_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_30),
.B(n_32),
.Y(n_41)
);

OAI21x1_ASAP7_75t_L g42 ( 
.A1(n_37),
.A2(n_30),
.B(n_24),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_35),
.A2(n_22),
.B(n_33),
.Y(n_43)
);

INVx4_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_39),
.Y(n_45)
);

OAI21xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_40),
.B(n_41),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_34),
.Y(n_47)
);

OAI21xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_40),
.B(n_41),
.Y(n_48)
);

AOI21xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_44),
.B(n_31),
.Y(n_49)
);

OAI21xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_47),
.B(n_25),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

AOI21xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_23),
.B(n_25),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_23),
.Y(n_53)
);

NAND3xp33_ASAP7_75t_SL g54 ( 
.A(n_52),
.B(n_21),
.C(n_17),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

A2O1A1Ixp33_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_31),
.B(n_23),
.C(n_19),
.Y(n_56)
);

AO21x2_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_31),
.B(n_13),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

HB1xp67_ASAP7_75t_L g59 ( 
.A(n_58),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_SL g60 ( 
.A1(n_56),
.A2(n_7),
.B1(n_12),
.B2(n_15),
.Y(n_60)
);

AOI21xp33_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_57),
.B(n_59),
.Y(n_61)
);


endmodule