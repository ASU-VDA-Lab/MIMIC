module fake_netlist_716_468_n_22 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_22);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_22;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_19;

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

OR2x6_ASAP7_75t_L g14 ( 
.A(n_1),
.B(n_2),
.Y(n_14)
);

A2O1A1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.C(n_3),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.B(n_11),
.C(n_13),
.Y(n_19)
);

OA22x2_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_10),
.B1(n_0),
.B2(n_8),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);


endmodule