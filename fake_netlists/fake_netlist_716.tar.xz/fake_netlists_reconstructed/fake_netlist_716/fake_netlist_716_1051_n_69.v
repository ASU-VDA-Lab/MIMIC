module fake_netlist_716_1051_n_69 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_19, n_5, n_69);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_19;
input n_5;

output n_69;

wire n_60;
wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_61;
wire n_30;
wire n_63;
wire n_35;
wire n_54;
wire n_68;
wire n_27;
wire n_36;
wire n_24;
wire n_37;
wire n_29;
wire n_41;
wire n_66;
wire n_55;
wire n_43;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_31;
wire n_57;
wire n_65;
wire n_25;
wire n_22;
wire n_46;
wire n_23;
wire n_56;
wire n_21;
wire n_47;
wire n_67;
wire n_44;
wire n_42;
wire n_53;
wire n_64;
wire n_62;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_59;
wire n_26;

INVx3_ASAP7_75t_L g21 ( 
.A(n_7),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_10),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_19),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_15),
.B(n_8),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_11),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_4),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_21),
.A2(n_30),
.B(n_29),
.C(n_24),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_21),
.B(n_18),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_26),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_26),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_28),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_35),
.Y(n_41)
);

INVx3_ASAP7_75t_SL g42 ( 
.A(n_38),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_36),
.A2(n_27),
.B1(n_28),
.B2(n_32),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_34),
.A2(n_27),
.B1(n_32),
.B2(n_25),
.Y(n_44)
);

OA21x2_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_33),
.B(n_37),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_40),
.B(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_42),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_23),
.B1(n_22),
.B2(n_38),
.Y(n_48)
);

BUFx3_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

OR2x2_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_48),
.Y(n_50)
);

INVx4_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

INVx5_ASAP7_75t_L g52 ( 
.A(n_45),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_45),
.Y(n_54)
);

OAI21xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_48),
.B(n_31),
.Y(n_55)
);

INVx1_ASAP7_75t_SL g56 ( 
.A(n_49),
.Y(n_56)
);

INVx1_ASAP7_75t_SL g57 ( 
.A(n_56),
.Y(n_57)
);

OAI22xp33_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_52),
.B1(n_51),
.B2(n_38),
.Y(n_58)
);

INVxp67_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_54),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_L g61 ( 
.A1(n_53),
.A2(n_52),
.B1(n_14),
.B2(n_0),
.Y(n_61)
);

NAND5xp2_ASAP7_75t_L g62 ( 
.A(n_61),
.B(n_53),
.C(n_10),
.D(n_20),
.E(n_12),
.Y(n_62)
);

INVx1_ASAP7_75t_SL g63 ( 
.A(n_57),
.Y(n_63)
);

NAND5xp2_ASAP7_75t_L g64 ( 
.A(n_60),
.B(n_17),
.C(n_6),
.D(n_16),
.E(n_1),
.Y(n_64)
);

BUFx2_ASAP7_75t_L g65 ( 
.A(n_59),
.Y(n_65)
);

AO221x1_ASAP7_75t_L g66 ( 
.A1(n_62),
.A2(n_2),
.B1(n_5),
.B2(n_58),
.C(n_64),
.Y(n_66)
);

CKINVDCx20_ASAP7_75t_R g67 ( 
.A(n_63),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_65),
.Y(n_68)
);

OAI22xp5_ASAP7_75t_L g69 ( 
.A1(n_67),
.A2(n_65),
.B1(n_68),
.B2(n_66),
.Y(n_69)
);


endmodule