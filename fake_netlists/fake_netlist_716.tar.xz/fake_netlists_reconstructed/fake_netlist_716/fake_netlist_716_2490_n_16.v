module fake_netlist_716_2490_n_16 (n_0, n_3, n_2, n_1, n_16);

input n_0;
input n_3;
input n_2;
input n_1;

output n_16;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_15;
wire n_14;
wire n_6;
wire n_4;
wire n_5;

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

OA21x2_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B(n_1),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_4),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.B(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_9),
.B2(n_6),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_9),
.B(n_1),
.C(n_0),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_11),
.B2(n_0),
.C(n_3),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_9),
.B(n_3),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_9),
.B1(n_15),
.B2(n_11),
.Y(n_16)
);


endmodule