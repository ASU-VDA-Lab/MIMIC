module fake_netlist_716_1915_n_27 (n_1, n_2, n_0, n_3, n_4, n_27);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_27;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_7;
wire n_18;
wire n_11;
wire n_9;
wire n_25;
wire n_12;
wire n_8;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_6;
wire n_19;
wire n_5;

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_0),
.B(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_1),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_2),
.B(n_3),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_2),
.B(n_3),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_5),
.B(n_7),
.C(n_1),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

BUFx3_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_9),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_11),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_9),
.B1(n_14),
.B2(n_13),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_7),
.B1(n_12),
.B2(n_15),
.C(n_14),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_15),
.B(n_10),
.Y(n_21)
);

AND4x1_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_0),
.C(n_10),
.D(n_18),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_21),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

OAI22x1_ASAP7_75t_L g26 ( 
.A1(n_22),
.A2(n_24),
.B1(n_23),
.B2(n_16),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_26),
.Y(n_27)
);


endmodule