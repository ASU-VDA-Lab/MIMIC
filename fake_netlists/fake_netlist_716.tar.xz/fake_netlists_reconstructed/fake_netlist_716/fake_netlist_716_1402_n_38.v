module fake_netlist_716_1402_n_38 (n_3, n_14, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_5, n_38);

input n_3;
input n_14;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_5;

output n_38;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_31;
wire n_28;
wire n_25;
wire n_22;
wire n_23;
wire n_21;
wire n_34;
wire n_26;
wire n_19;

INVx2_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_12),
.B(n_14),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_11),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_13),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_4),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_22),
.A2(n_24),
.B(n_26),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_19),
.A2(n_7),
.B(n_9),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_25),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_23),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_33),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_28),
.B1(n_10),
.B2(n_0),
.Y(n_35)
);

AOI22x1_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_17),
.B1(n_6),
.B2(n_16),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_36),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_3),
.B1(n_5),
.B2(n_18),
.Y(n_38)
);


endmodule