module fake_netlist_716_399_n_11 (n_0, n_2, n_1, n_11);

input n_0;
input n_2;
input n_1;

output n_11;

wire n_8;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_3;
wire n_4;
wire n_5;

CKINVDCx5p33_ASAP7_75t_R g3 ( 
.A(n_0),
.Y(n_3)
);

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_4),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

OAI32xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_6),
.A3(n_5),
.B1(n_4),
.B2(n_0),
.Y(n_8)
);

NOR3xp33_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_2),
.C(n_1),
.Y(n_9)
);

XNOR2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_2),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_4),
.B(n_6),
.Y(n_11)
);


endmodule