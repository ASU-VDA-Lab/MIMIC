module fake_netlist_716_2195_n_44 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_6, n_19, n_5, n_44);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_6;
input n_19;
input n_5;

output n_44;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_24;
wire n_29;
wire n_37;
wire n_41;
wire n_43;
wire n_31;
wire n_28;
wire n_39;
wire n_25;
wire n_23;
wire n_26;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_22;

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_9),
.B(n_8),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_19),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

NOR2x1p5_ASAP7_75t_L g26 ( 
.A(n_2),
.B(n_15),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_R g27 ( 
.A(n_12),
.B(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_3),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_13),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_SL g30 ( 
.A(n_25),
.B(n_17),
.C(n_10),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_22),
.A2(n_23),
.B(n_28),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_25),
.A2(n_21),
.B(n_19),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_29),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AOI21xp33_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_27),
.B(n_28),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_26),
.Y(n_38)
);

AOI211xp5_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_24),
.B(n_35),
.C(n_30),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_17),
.B1(n_10),
.B2(n_18),
.C(n_16),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_26),
.B1(n_18),
.B2(n_20),
.C(n_16),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_R g42 ( 
.A(n_39),
.B(n_11),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_42),
.Y(n_43)
);

AOI322xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_21),
.A3(n_20),
.B1(n_14),
.B2(n_1),
.C1(n_7),
.C2(n_5),
.Y(n_44)
);


endmodule