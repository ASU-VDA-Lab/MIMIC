module fake_netlist_716_1185_n_29 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_5, n_29);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_29;

wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_18;
wire n_28;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_22;
wire n_19;

NOR2x1p5_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_0),
.Y(n_17)
);

BUFx10_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_13),
.B(n_8),
.Y(n_20)
);

AND2x4_ASAP7_75t_SL g21 ( 
.A(n_18),
.B(n_11),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_19),
.B(n_14),
.Y(n_22)
);

AO21x2_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_20),
.B(n_17),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_21),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_9),
.B1(n_16),
.B2(n_10),
.C(n_7),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

XNOR2x1_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_3),
.Y(n_28)
);

OAI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_4),
.B1(n_6),
.B2(n_5),
.C(n_1),
.Y(n_29)
);


endmodule