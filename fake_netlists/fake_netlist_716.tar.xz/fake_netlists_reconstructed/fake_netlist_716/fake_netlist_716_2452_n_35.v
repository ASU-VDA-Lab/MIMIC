module fake_netlist_716_2452_n_35 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_17, n_5, n_35);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_17;
input n_5;

output n_35;

wire n_32;
wire n_33;
wire n_30;
wire n_20;
wire n_27;
wire n_24;
wire n_29;
wire n_31;
wire n_18;
wire n_28;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_34;
wire n_22;
wire n_19;

INVx1_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_6),
.B(n_0),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_9),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_14),
.B(n_8),
.C(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

OR2x6_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_23),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_22),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_26),
.B(n_28),
.C(n_19),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

NAND5xp2_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_16),
.C(n_15),
.D(n_17),
.E(n_7),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_2),
.B1(n_4),
.B2(n_5),
.Y(n_35)
);


endmodule