module fake_netlist_716_43_n_32 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_32);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_32;

wire n_30;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_11;
wire n_9;
wire n_25;
wire n_12;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

NAND2xp33_ASAP7_75t_R g10 ( 
.A(n_7),
.B(n_4),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_2),
.B(n_5),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

BUFx10_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

AOI21xp33_ASAP7_75t_L g15 ( 
.A1(n_10),
.A2(n_11),
.B(n_9),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_12),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_14),
.B(n_13),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_6),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_12),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_16),
.B(n_14),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_15),
.A2(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_19),
.B(n_17),
.Y(n_25)
);

OAI21xp33_ASAP7_75t_SL g26 ( 
.A1(n_24),
.A2(n_23),
.B(n_25),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_21),
.B1(n_23),
.B2(n_20),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_23),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_0),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_28),
.B1(n_29),
.B2(n_30),
.Y(n_32)
);


endmodule