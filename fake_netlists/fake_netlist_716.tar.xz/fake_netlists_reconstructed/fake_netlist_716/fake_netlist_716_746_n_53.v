module fake_netlist_716_746_n_53 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_5, n_53);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_53;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_43;
wire n_31;
wire n_18;
wire n_28;
wire n_39;
wire n_45;
wire n_52;
wire n_25;
wire n_46;
wire n_23;
wire n_21;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_22;
wire n_19;

INVx2_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

XOR2xp5_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_8),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_11),
.B(n_14),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_16),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_16),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_22),
.B(n_15),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_22),
.B1(n_17),
.B2(n_21),
.Y(n_30)
);

OAI21x1_ASAP7_75t_L g31 ( 
.A1(n_26),
.A2(n_19),
.B(n_22),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_27),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_28),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_31),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_25),
.B(n_18),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_22),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_18),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_34),
.B1(n_17),
.B2(n_20),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_34),
.B1(n_23),
.B2(n_17),
.Y(n_40)
);

INVxp67_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

INVxp33_ASAP7_75t_SL g42 ( 
.A(n_38),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_21),
.C(n_20),
.Y(n_43)
);

NAND4xp25_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_11),
.C(n_9),
.D(n_10),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_10),
.Y(n_45)
);

OAI322xp33_ASAP7_75t_SL g46 ( 
.A1(n_39),
.A2(n_12),
.A3(n_7),
.B1(n_0),
.B2(n_13),
.C1(n_3),
.C2(n_1),
.Y(n_46)
);

NAND4xp75_ASAP7_75t_L g47 ( 
.A(n_40),
.B(n_0),
.C(n_7),
.D(n_13),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_43),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_44),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_SL g52 ( 
.A1(n_51),
.A2(n_6),
.B1(n_50),
.B2(n_48),
.Y(n_52)
);

XNOR2xp5_ASAP7_75t_L g53 ( 
.A(n_52),
.B(n_49),
.Y(n_53)
);


endmodule