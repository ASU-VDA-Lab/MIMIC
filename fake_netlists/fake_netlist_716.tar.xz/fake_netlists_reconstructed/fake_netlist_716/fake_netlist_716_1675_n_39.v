module fake_netlist_716_1675_n_39 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_39);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_39;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_37;
wire n_29;
wire n_36;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_11;
wire n_9;
wire n_25;
wire n_12;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_26;
wire n_38;
wire n_34;
wire n_16;
wire n_22;
wire n_19;

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_8),
.B1(n_3),
.B2(n_0),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_1),
.C(n_0),
.Y(n_10)
);

INVx4_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_L g12 ( 
.A(n_5),
.B(n_1),
.C(n_4),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_6),
.B(n_5),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_7),
.B(n_2),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_9),
.A2(n_11),
.B1(n_12),
.B2(n_10),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_9),
.A2(n_14),
.B1(n_16),
.B2(n_11),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_14),
.B(n_15),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_17),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_17),
.B(n_20),
.Y(n_27)
);

BUFx12f_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_17),
.B(n_21),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_18),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_22),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_28),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_29),
.B1(n_25),
.B2(n_26),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_28),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_23),
.C(n_19),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_32),
.B(n_28),
.Y(n_36)
);

NAND5xp2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_24),
.C(n_19),
.D(n_27),
.E(n_28),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_36),
.Y(n_38)
);

OAI21xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_27),
.B(n_34),
.Y(n_39)
);


endmodule