module fake_netlist_716_172_n_37 (n_3, n_14, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_19, n_5, n_37);

input n_3;
input n_14;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_19;
input n_5;

output n_37;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_24;
wire n_36;
wire n_29;
wire n_31;
wire n_28;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_34;
wire n_22;

INVx1_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_19),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_2),
.B(n_14),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

O2A1O1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_10),
.B(n_12),
.C(n_13),
.Y(n_27)
);

OR2x6_ASAP7_75t_SL g28 ( 
.A(n_22),
.B(n_8),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_17),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_25),
.B1(n_23),
.B2(n_24),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_21),
.Y(n_32)
);

AOI221x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_27),
.B2(n_18),
.C(n_7),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_1),
.B(n_5),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_4),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_0),
.B1(n_6),
.B2(n_15),
.Y(n_37)
);


endmodule