module fake_netlist_716_827_n_12 (n_0, n_2, n_1, n_12);

input n_0;
input n_2;
input n_1;

output n_12;

wire n_8;
wire n_11;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_3;
wire n_4;
wire n_5;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

OA21x2_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_0),
.B(n_1),
.Y(n_8)
);

AOI221xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_6),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_9)
);

NOR3xp33_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_7),
.C(n_6),
.Y(n_10)
);

OA21x2_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B(n_0),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_2),
.B1(n_8),
.B2(n_10),
.Y(n_12)
);


endmodule