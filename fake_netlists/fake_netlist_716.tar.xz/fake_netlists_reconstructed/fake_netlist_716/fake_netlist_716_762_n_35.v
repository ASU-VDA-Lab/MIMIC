module fake_netlist_716_762_n_35 (n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_35);

input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_35;

wire n_32;
wire n_33;
wire n_30;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_25;
wire n_12;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_34;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_2),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_6),
.B(n_3),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_2),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_15),
.B1(n_12),
.B2(n_16),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_1),
.B1(n_5),
.B2(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_16),
.B1(n_17),
.B2(n_13),
.C1(n_14),
.C2(n_1),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_13),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_21),
.Y(n_24)
);

NOR2x1_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_17),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_24),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_SL g29 ( 
.A(n_28),
.B(n_24),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NAND4xp75_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_18),
.C(n_20),
.D(n_4),
.Y(n_31)
);

NOR2xp67_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_7),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

AOI322xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_16),
.A3(n_33),
.B1(n_4),
.B2(n_0),
.C1(n_11),
.C2(n_8),
.Y(n_35)
);


endmodule