module fake_netlist_716_719_n_73 (n_3, n_14, n_20, n_0, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_25, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_73);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_25;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_73;

wire n_60;
wire n_58;
wire n_32;
wire n_48;
wire n_33;
wire n_61;
wire n_72;
wire n_30;
wire n_63;
wire n_35;
wire n_54;
wire n_68;
wire n_27;
wire n_37;
wire n_29;
wire n_36;
wire n_41;
wire n_66;
wire n_55;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_57;
wire n_71;
wire n_65;
wire n_46;
wire n_70;
wire n_56;
wire n_47;
wire n_67;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_64;
wire n_62;
wire n_69;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_59;

AND2x4_ASAP7_75t_L g26 ( 
.A(n_10),
.B(n_3),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_8),
.B(n_25),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_18),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_17),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_0),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_20),
.B(n_15),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_11),
.B(n_1),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_16),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_23),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_5),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_27),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_34),
.A2(n_22),
.B1(n_13),
.B2(n_21),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_28),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_32),
.Y(n_42)
);

OAI21xp5_ASAP7_75t_L g43 ( 
.A1(n_29),
.A2(n_24),
.B(n_21),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_28),
.B(n_25),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_27),
.B1(n_37),
.B2(n_26),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_39),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_26),
.B1(n_38),
.B2(n_36),
.Y(n_47)
);

OAI21x1_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_35),
.B(n_36),
.Y(n_48)
);

BUFx2_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_45),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_40),
.Y(n_52)
);

INVxp67_ASAP7_75t_SL g53 ( 
.A(n_51),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

AOI22xp5_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_49),
.B1(n_47),
.B2(n_26),
.Y(n_55)
);

INVxp67_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_49),
.B1(n_48),
.B2(n_33),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_52),
.B(n_39),
.Y(n_58)
);

O2A1O1Ixp33_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_38),
.B(n_41),
.C(n_13),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

AOI221xp5_ASAP7_75t_L g61 ( 
.A1(n_55),
.A2(n_30),
.B1(n_31),
.B2(n_41),
.C(n_23),
.Y(n_61)
);

OAI21xp5_ASAP7_75t_L g62 ( 
.A1(n_57),
.A2(n_41),
.B(n_12),
.Y(n_62)
);

OAI21xp5_ASAP7_75t_L g63 ( 
.A1(n_57),
.A2(n_4),
.B(n_7),
.Y(n_63)
);

NAND3xp33_ASAP7_75t_SL g64 ( 
.A(n_61),
.B(n_59),
.C(n_63),
.Y(n_64)
);

AND2x4_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_9),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_62),
.Y(n_66)
);

INVx2_ASAP7_75t_SL g67 ( 
.A(n_60),
.Y(n_67)
);

BUFx2_ASAP7_75t_L g68 ( 
.A(n_60),
.Y(n_68)
);

OR3x1_ASAP7_75t_L g69 ( 
.A(n_64),
.B(n_2),
.C(n_6),
.Y(n_69)
);

OAI21xp5_ASAP7_75t_L g70 ( 
.A1(n_66),
.A2(n_14),
.B(n_67),
.Y(n_70)
);

OR3x2_ASAP7_75t_L g71 ( 
.A(n_68),
.B(n_37),
.C(n_32),
.Y(n_71)
);

INVx2_ASAP7_75t_SL g72 ( 
.A(n_71),
.Y(n_72)
);

AOI22xp5_ASAP7_75t_L g73 ( 
.A1(n_72),
.A2(n_69),
.B1(n_70),
.B2(n_65),
.Y(n_73)
);


endmodule