module fake_netlist_716_1996_n_71 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_5, n_71);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_71;

wire n_60;
wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_61;
wire n_30;
wire n_63;
wire n_54;
wire n_35;
wire n_68;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_66;
wire n_55;
wire n_43;
wire n_18;
wire n_31;
wire n_28;
wire n_39;
wire n_52;
wire n_45;
wire n_57;
wire n_65;
wire n_25;
wire n_22;
wire n_46;
wire n_70;
wire n_23;
wire n_56;
wire n_21;
wire n_47;
wire n_67;
wire n_44;
wire n_42;
wire n_53;
wire n_64;
wire n_62;
wire n_69;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_59;
wire n_26;
wire n_19;

INVx2_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_8),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_14),
.Y(n_22)
);

INVx6_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

AND2x6_ASAP7_75t_L g26 ( 
.A(n_10),
.B(n_7),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_13),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_11),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_28),
.B(n_8),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_21),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

AND2x6_ASAP7_75t_L g35 ( 
.A(n_17),
.B(n_3),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_23),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_24),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_18),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_25),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_29),
.Y(n_40)
);

BUFx4f_ASAP7_75t_L g41 ( 
.A(n_26),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_19),
.B(n_5),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_31),
.A2(n_22),
.B1(n_27),
.B2(n_26),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_34),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_33),
.B(n_34),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_38),
.B(n_20),
.Y(n_46)
);

OAI22xp33_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_36),
.B1(n_39),
.B2(n_40),
.Y(n_47)
);

OAI21x1_ASAP7_75t_L g48 ( 
.A1(n_32),
.A2(n_30),
.B(n_26),
.Y(n_48)
);

OR2x6_ASAP7_75t_L g49 ( 
.A(n_37),
.B(n_32),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_34),
.B(n_26),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_44),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_46),
.B(n_41),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_49),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_43),
.Y(n_56)
);

OR2x2_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_52),
.Y(n_57)
);

INVx5_ASAP7_75t_L g58 ( 
.A(n_51),
.Y(n_58)
);

NAND4xp25_ASAP7_75t_SL g59 ( 
.A(n_53),
.B(n_43),
.C(n_45),
.D(n_51),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_53),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_57),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_47),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_59),
.B(n_48),
.Y(n_63)
);

OAI322xp33_ASAP7_75t_L g64 ( 
.A1(n_61),
.A2(n_1),
.A3(n_4),
.B1(n_9),
.B2(n_35),
.C1(n_41),
.C2(n_60),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_60),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_63),
.Y(n_66)
);

O2A1O1Ixp5_ASAP7_75t_L g67 ( 
.A1(n_62),
.A2(n_35),
.B(n_63),
.C(n_56),
.Y(n_67)
);

NOR2x1_ASAP7_75t_L g68 ( 
.A(n_65),
.B(n_35),
.Y(n_68)
);

OR2x2_ASAP7_75t_L g69 ( 
.A(n_66),
.B(n_35),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_69),
.Y(n_70)
);

AOI22xp33_ASAP7_75t_SL g71 ( 
.A1(n_70),
.A2(n_64),
.B1(n_67),
.B2(n_68),
.Y(n_71)
);


endmodule