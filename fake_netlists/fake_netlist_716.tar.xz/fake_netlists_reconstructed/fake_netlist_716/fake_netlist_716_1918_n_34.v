module fake_netlist_716_1918_n_34 (n_3, n_14, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_5, n_34);

input n_3;
input n_14;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_5;

output n_34;

wire n_32;
wire n_33;
wire n_30;
wire n_20;
wire n_27;
wire n_24;
wire n_29;
wire n_31;
wire n_28;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_22;
wire n_19;

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_15),
.B(n_1),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_7),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

AND3x1_ASAP7_75t_L g22 ( 
.A(n_9),
.B(n_17),
.C(n_3),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_9),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_SL g25 ( 
.A(n_8),
.B(n_11),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_21),
.A2(n_25),
.B(n_20),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_27),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_22),
.B1(n_24),
.B2(n_21),
.C(n_19),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_16),
.B1(n_13),
.B2(n_14),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI22x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_10),
.B1(n_6),
.B2(n_5),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_0),
.B1(n_2),
.B2(n_4),
.Y(n_34)
);


endmodule