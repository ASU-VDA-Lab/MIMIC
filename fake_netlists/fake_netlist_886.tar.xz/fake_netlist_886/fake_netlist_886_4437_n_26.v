module fake_netlist_886_4437_n_26 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_26);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_26;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_20;
wire n_18;
wire n_17;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;

INVx2_ASAP7_75t_SL g13 ( 
.A(n_0),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_7),
.A2(n_1),
.B1(n_12),
.B2(n_3),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_6),
.C(n_8),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_2),
.B(n_4),
.Y(n_16)
);

BUFx10_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_4),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_5),
.B(n_10),
.C(n_9),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_16),
.B(n_14),
.Y(n_21)
);

NAND2x1_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_15),
.Y(n_22)
);

NAND3x1_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_20),
.C(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_21),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_21),
.B(n_11),
.Y(n_26)
);


endmodule