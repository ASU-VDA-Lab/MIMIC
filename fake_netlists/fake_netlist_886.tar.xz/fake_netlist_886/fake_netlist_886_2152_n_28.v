module fake_netlist_886_2152_n_28 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_28);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_28;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;

INVx2_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_3),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_4),
.B(n_2),
.Y(n_15)
);

AO21x1_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_5),
.B(n_4),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_SL g17 ( 
.A1(n_9),
.A2(n_6),
.B(n_5),
.Y(n_17)
);

CKINVDCx16_ASAP7_75t_R g18 ( 
.A(n_16),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

INVx3_ASAP7_75t_SL g20 ( 
.A(n_14),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_9),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_9),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_18),
.B1(n_20),
.B2(n_15),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_11),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_21),
.B1(n_22),
.B2(n_13),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_7),
.B1(n_21),
.B2(n_18),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_21),
.B1(n_26),
.B2(n_24),
.Y(n_28)
);


endmodule