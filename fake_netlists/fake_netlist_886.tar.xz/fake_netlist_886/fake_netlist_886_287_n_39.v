module fake_netlist_886_287_n_39 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_39);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_39;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_14;
wire n_35;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_11),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_3),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_5),
.B(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_14),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_16),
.B1(n_19),
.B2(n_20),
.C(n_14),
.Y(n_25)
);

INVxp67_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_15),
.B(n_21),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_23),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_21),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_29),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_20),
.B1(n_21),
.B2(n_1),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_32),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_21),
.C(n_4),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_R g36 ( 
.A1(n_32),
.A2(n_7),
.B1(n_4),
.B2(n_9),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI322xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_7),
.A3(n_10),
.B1(n_12),
.B2(n_13),
.C1(n_35),
.C2(n_37),
.Y(n_39)
);


endmodule