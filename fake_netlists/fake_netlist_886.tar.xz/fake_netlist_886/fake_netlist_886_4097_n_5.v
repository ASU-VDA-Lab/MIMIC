module fake_netlist_886_4097_n_5 (n_0, n_5);

input n_0;

output n_5;

wire n_2;
wire n_3;
wire n_4;
wire n_1;

INVx1_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

BUFx3_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

OA21x2_ASAP7_75t_L g3 ( 
.A1(n_2),
.A2(n_0),
.B(n_1),
.Y(n_3)
);

OR2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);

OR2x6_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);


endmodule