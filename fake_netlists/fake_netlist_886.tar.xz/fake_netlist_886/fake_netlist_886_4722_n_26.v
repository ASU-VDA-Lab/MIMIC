module fake_netlist_886_4722_n_26 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_26);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_26;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_10;
wire n_8;

OAI22xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B1(n_5),
.B2(n_6),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_6),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

AO21x2_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_7),
.B(n_0),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_9),
.B(n_7),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_10),
.B(n_11),
.C(n_1),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_R g15 ( 
.A(n_13),
.B(n_2),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);

NAND4xp25_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_14),
.C(n_15),
.D(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_12),
.B1(n_11),
.B2(n_3),
.C(n_4),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_4),
.Y(n_25)
);

OAI31xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_23),
.A3(n_24),
.B(n_5),
.Y(n_26)
);


endmodule