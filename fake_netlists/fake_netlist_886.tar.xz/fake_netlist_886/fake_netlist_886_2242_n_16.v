module fake_netlist_886_2242_n_16 (n_0, n_2, n_5, n_3, n_4, n_1, n_16);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_16;

wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_2),
.Y(n_7)
);

CKINVDCx20_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_1),
.Y(n_9)
);

AND2x6_ASAP7_75t_SL g10 ( 
.A(n_0),
.B(n_4),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

OA22x2_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_6),
.B1(n_8),
.B2(n_11),
.Y(n_14)
);

AO22x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);


endmodule