module fake_netlist_886_4714_n_26 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_26);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_26;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_13;
wire n_25;
wire n_14;
wire n_22;
wire n_10;

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_3),
.B1(n_5),
.B2(n_6),
.Y(n_10)
);

OR2x6_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_5),
.B(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_4),
.B(n_2),
.Y(n_16)
);

INVx4_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_13),
.B(n_15),
.Y(n_20)
);

NAND2x1_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_11),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_17),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_10),
.B1(n_17),
.B2(n_18),
.C(n_19),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AO22x1_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_19),
.B1(n_11),
.B2(n_4),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_9),
.B(n_22),
.Y(n_26)
);


endmodule