module fake_netlist_886_3926_n_25 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_25;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_1),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_7),
.B(n_5),
.Y(n_10)
);

INVx4_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

AO21x2_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_7),
.B(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

CKINVDCx11_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_6),
.B(n_3),
.C(n_2),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

NOR2x1_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_13),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_17),
.B(n_18),
.Y(n_22)
);

NOR2x1_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_21),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_9),
.B1(n_8),
.B2(n_13),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_13),
.B(n_16),
.Y(n_25)
);


endmodule