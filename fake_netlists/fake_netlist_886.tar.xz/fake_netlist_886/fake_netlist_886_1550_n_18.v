module fake_netlist_886_1550_n_18 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_18);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_18;

wire n_15;
wire n_11;
wire n_9;
wire n_17;
wire n_13;
wire n_16;
wire n_14;
wire n_10;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_8),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_6),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B(n_9),
.Y(n_15)
);

AND2x2_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_6),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_9),
.B(n_0),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_1),
.B1(n_2),
.B2(n_4),
.C1(n_7),
.C2(n_16),
.Y(n_18)
);


endmodule