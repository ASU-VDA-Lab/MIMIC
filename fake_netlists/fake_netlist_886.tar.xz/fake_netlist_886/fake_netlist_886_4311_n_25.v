module fake_netlist_886_4311_n_25 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_25;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

OR2x2_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_6),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_1),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_3),
.B(n_2),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_0),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_4),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_6),
.B(n_4),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_SL g14 ( 
.A1(n_10),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_R g15 ( 
.A(n_12),
.B(n_10),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_12),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.B1(n_13),
.B2(n_9),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_SL g20 ( 
.A1(n_18),
.A2(n_14),
.B(n_15),
.C(n_11),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_20),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_7),
.B1(n_2),
.B2(n_1),
.Y(n_23)
);

AOI22x1_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_7),
.B1(n_5),
.B2(n_3),
.Y(n_24)
);

A2O1A1Ixp33_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_23),
.B(n_21),
.C(n_5),
.Y(n_25)
);


endmodule