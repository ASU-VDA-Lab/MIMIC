module fake_netlist_886_3321_n_7 (n_0, n_1, n_2, n_7);

input n_0;
input n_1;
input n_2;

output n_7;

wire n_5;
wire n_3;
wire n_4;
wire n_6;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_SL g5 ( 
.A(n_4),
.Y(n_5)
);

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B1(n_2),
.B2(n_4),
.Y(n_7)
);


endmodule