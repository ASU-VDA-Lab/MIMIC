module fake_netlist_701_1377_n_49 (n_2, n_21, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_49);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_49;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_39;

BUFx2_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_4),
.B(n_3),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_10),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_22),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_24),
.B(n_19),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_27),
.B(n_26),
.Y(n_34)
);

AO21x2_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_29),
.B(n_23),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_30),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_31),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_19),
.B1(n_2),
.B2(n_0),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_8),
.B1(n_7),
.B2(n_11),
.C(n_12),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

NOR3xp33_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_14),
.C(n_13),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_15),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

XNOR2xp5_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_16),
.Y(n_48)
);

AOI22x1_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_47),
.B1(n_18),
.B2(n_17),
.Y(n_49)
);


endmodule