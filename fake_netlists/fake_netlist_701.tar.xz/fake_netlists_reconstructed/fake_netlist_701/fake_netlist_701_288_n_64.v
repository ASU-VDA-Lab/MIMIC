module fake_netlist_701_288_n_64 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_64);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_64;

wire n_54;
wire n_24;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_31;
wire n_23;
wire n_41;
wire n_46;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

OA21x2_ASAP7_75t_L g21 ( 
.A1(n_2),
.A2(n_13),
.B(n_0),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_15),
.B(n_20),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_11),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_7),
.Y(n_26)
);

OA21x2_ASAP7_75t_L g27 ( 
.A1(n_19),
.A2(n_8),
.B(n_3),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_18),
.Y(n_28)
);

BUFx12f_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_24),
.B(n_16),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_24),
.B(n_17),
.Y(n_31)
);

INVx5_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_29),
.Y(n_34)
);

OA21x2_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_23),
.B(n_22),
.Y(n_35)
);

AOI21x1_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_23),
.B(n_27),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_30),
.A2(n_23),
.B(n_21),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_32),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_25),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_SL g43 ( 
.A1(n_40),
.A2(n_21),
.B(n_27),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_38),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_21),
.B(n_27),
.Y(n_46)
);

OAI21xp33_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_30),
.B(n_28),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_42),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_29),
.B1(n_32),
.B2(n_26),
.Y(n_49)
);

NAND4xp25_ASAP7_75t_SL g50 ( 
.A(n_46),
.B(n_44),
.C(n_34),
.D(n_17),
.Y(n_50)
);

AOI21xp33_ASAP7_75t_L g51 ( 
.A1(n_44),
.A2(n_32),
.B(n_27),
.Y(n_51)
);

OAI211xp5_ASAP7_75t_SL g52 ( 
.A1(n_49),
.A2(n_20),
.B(n_36),
.C(n_21),
.Y(n_52)
);

AOI221xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_32),
.B1(n_6),
.B2(n_1),
.C(n_4),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_48),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_9),
.Y(n_55)
);

O2A1O1Ixp33_ASAP7_75t_L g56 ( 
.A1(n_49),
.A2(n_14),
.B(n_12),
.C(n_10),
.Y(n_56)
);

XNOR2x1_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_55),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_56),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_53),
.B(n_52),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_54),
.Y(n_60)
);

HB1xp67_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

AND2x4_ASAP7_75t_L g62 ( 
.A(n_60),
.B(n_59),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_57),
.Y(n_63)
);

AOI22x1_ASAP7_75t_L g64 ( 
.A1(n_61),
.A2(n_57),
.B1(n_63),
.B2(n_62),
.Y(n_64)
);


endmodule