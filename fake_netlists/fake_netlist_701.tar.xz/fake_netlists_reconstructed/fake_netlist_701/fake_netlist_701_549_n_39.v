module fake_netlist_701_549_n_39 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_39);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_39;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_9),
.B(n_8),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

AND2x6_ASAP7_75t_L g23 ( 
.A(n_14),
.B(n_16),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_15),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx5_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_23),
.B1(n_22),
.B2(n_17),
.Y(n_27)
);

AOI222xp33_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_21),
.B1(n_18),
.B2(n_20),
.C1(n_15),
.C2(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_31),
.B(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_6),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_12),
.B1(n_11),
.B2(n_7),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

XNOR2xp5_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_37),
.Y(n_39)
);


endmodule