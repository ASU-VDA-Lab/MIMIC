module fake_netlist_701_177_n_27 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_27);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_12;
wire n_8;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_7),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_4),
.B(n_5),
.Y(n_11)
);

NAND2xp33_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_4),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_3),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_13),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_12),
.B(n_11),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_14),
.B1(n_10),
.B2(n_16),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx4_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);


endmodule