module fake_netlist_701_36_n_44 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_44);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_44;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_19;
wire n_30;
wire n_25;
wire n_39;
wire n_14;

INVx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

AND2x2_ASAP7_75t_SL g17 ( 
.A(n_5),
.B(n_10),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_11),
.A2(n_3),
.B1(n_1),
.B2(n_7),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_2),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_0),
.Y(n_21)
);

INVxp67_ASAP7_75t_SL g22 ( 
.A(n_14),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_2),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_15),
.Y(n_24)
);

OA21x2_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_20),
.B(n_16),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_23),
.Y(n_26)
);

NOR2xp67_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_20),
.Y(n_27)
);

NAND4xp25_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_18),
.C(n_21),
.D(n_19),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_21),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_25),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_17),
.Y(n_32)
);

AOI21xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_17),
.B(n_21),
.Y(n_33)
);

AOI21xp33_ASAP7_75t_SL g34 ( 
.A1(n_31),
.A2(n_17),
.B(n_18),
.Y(n_34)
);

OAI31xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_21),
.A3(n_20),
.B(n_3),
.Y(n_35)
);

NOR4xp75_ASAP7_75t_SL g36 ( 
.A(n_35),
.B(n_30),
.C(n_5),
.D(n_4),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_4),
.Y(n_37)
);

AOI21xp33_ASAP7_75t_SL g38 ( 
.A1(n_34),
.A2(n_20),
.B(n_6),
.Y(n_38)
);

NOR2x1p5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_34),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_8),
.B(n_6),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI21xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_11),
.B(n_10),
.Y(n_43)
);

AO221x1_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_9),
.B1(n_12),
.B2(n_40),
.C(n_43),
.Y(n_44)
);


endmodule