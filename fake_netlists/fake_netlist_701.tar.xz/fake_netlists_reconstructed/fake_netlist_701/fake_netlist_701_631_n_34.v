module fake_netlist_701_631_n_34 (n_9, n_4, n_2, n_7, n_14, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_34);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_34;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_4),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_7),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_SL g21 ( 
.A(n_18),
.B(n_1),
.C(n_0),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

AOI21x1_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_15),
.B(n_19),
.Y(n_23)
);

INVx4_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NAND2xp33_ASAP7_75t_SL g26 ( 
.A(n_25),
.B(n_23),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_SL g28 ( 
.A(n_26),
.B(n_3),
.C(n_2),
.Y(n_28)
);

NAND2x1_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_17),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_10),
.C(n_9),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI222xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_20),
.B2(n_14),
.C1(n_13),
.C2(n_11),
.Y(n_34)
);


endmodule