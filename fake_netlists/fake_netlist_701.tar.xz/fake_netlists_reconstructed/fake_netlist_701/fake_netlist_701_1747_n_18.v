module fake_netlist_701_1747_n_18 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_18);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_9;
wire n_17;
wire n_7;
wire n_15;
wire n_11;
wire n_16;
wire n_8;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVxp67_ASAP7_75t_SL g7 ( 
.A(n_2),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AND2x2_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

AOI21xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_7),
.B(n_1),
.Y(n_14)
);

NOR2xp67_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_6),
.B1(n_5),
.B2(n_0),
.Y(n_18)
);


endmodule