module fake_netlist_701_2337_n_25 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_25);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_25;

wire n_24;
wire n_21;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_1),
.B(n_7),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

OAI33xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.A3(n_12),
.B1(n_9),
.B2(n_5),
.B3(n_4),
.Y(n_16)
);

NAND2xp33_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_10),
.B1(n_6),
.B2(n_5),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_6),
.B1(n_2),
.B2(n_0),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_R g25 ( 
.A(n_24),
.B(n_23),
.C(n_8),
.Y(n_25)
);


endmodule