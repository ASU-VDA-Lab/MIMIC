module fake_netlist_701_1149_n_9 (n_0, n_2, n_1, n_9);

input n_0;
input n_2;
input n_1;

output n_9;

wire n_4;
wire n_7;
wire n_3;
wire n_8;
wire n_5;
wire n_6;

AND2x6_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

INVx2_ASAP7_75t_SL g4 ( 
.A(n_2),
.Y(n_4)
);

AO21x2_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_4),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_3),
.Y(n_8)
);

OR2x6_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_1),
.Y(n_9)
);


endmodule