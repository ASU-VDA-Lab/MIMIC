module fake_netlist_701_1036_n_23 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_23);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_23;

wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_4),
.B1(n_5),
.B2(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_L g12 ( 
.A(n_1),
.B(n_2),
.C(n_3),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_4),
.B(n_9),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

AO31x2_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_11),
.A3(n_15),
.B(n_14),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_0),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.Y(n_19)
);

AO21x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_16),
.B(n_12),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx3_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_5),
.B(n_3),
.Y(n_23)
);


endmodule