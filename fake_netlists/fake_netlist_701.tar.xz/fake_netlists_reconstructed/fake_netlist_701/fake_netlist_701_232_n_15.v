module fake_netlist_701_232_n_15 (n_3, n_0, n_2, n_1, n_15);

input n_3;
input n_0;
input n_2;
input n_1;

output n_15;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_11;
wire n_12;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_13;

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_3),
.B(n_1),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_0),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

AOI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

AOI211xp5_ASAP7_75t_SL g8 ( 
.A1(n_6),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_1),
.Y(n_9)
);

AOI221x1_ASAP7_75t_SL g10 ( 
.A1(n_8),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_10)
);

OAI32xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_7),
.A3(n_3),
.B1(n_0),
.B2(n_2),
.Y(n_11)
);

NOR3xp33_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.C(n_8),
.Y(n_12)
);

NOR2xp67_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_2),
.Y(n_13)
);

NOR4xp25_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.C(n_11),
.D(n_2),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_3),
.B1(n_11),
.B2(n_12),
.C(n_10),
.Y(n_15)
);


endmodule