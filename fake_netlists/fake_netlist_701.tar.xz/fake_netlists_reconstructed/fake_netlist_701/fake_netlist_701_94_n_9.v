module fake_netlist_701_94_n_9 (n_0, n_2, n_1, n_9);

input n_0;
input n_2;
input n_1;

output n_9;

wire n_4;
wire n_7;
wire n_3;
wire n_8;
wire n_5;
wire n_6;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_2),
.B(n_0),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

NAND4xp25_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_2),
.C(n_1),
.D(n_5),
.Y(n_7)
);

XOR2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_8),
.B(n_1),
.Y(n_9)
);


endmodule