module fake_netlist_701_1680_n_52 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_52);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_52;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

AND2x4_ASAP7_75t_L g24 ( 
.A(n_2),
.B(n_15),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_23),
.B(n_22),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_10),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_5),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_6),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_0),
.A2(n_14),
.B1(n_16),
.B2(n_21),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_18),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_18),
.Y(n_35)
);

NOR3xp33_ASAP7_75t_SL g36 ( 
.A(n_32),
.B(n_19),
.C(n_1),
.Y(n_36)
);

INVx3_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_SL g38 ( 
.A1(n_33),
.A2(n_32),
.B1(n_31),
.B2(n_28),
.Y(n_38)
);

INVxp67_ASAP7_75t_R g39 ( 
.A(n_38),
.Y(n_39)
);

BUFx3_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_35),
.Y(n_41)
);

INVxp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_36),
.B1(n_39),
.B2(n_24),
.C(n_29),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_19),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_24),
.Y(n_47)
);

NOR3xp33_ASAP7_75t_SL g48 ( 
.A(n_46),
.B(n_25),
.C(n_3),
.Y(n_48)
);

NOR3xp33_ASAP7_75t_SL g49 ( 
.A(n_47),
.B(n_8),
.C(n_4),
.Y(n_49)
);

AO21x2_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_12),
.B(n_9),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_49),
.Y(n_51)
);

OAI22xp33_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_50),
.B1(n_20),
.B2(n_13),
.Y(n_52)
);


endmodule