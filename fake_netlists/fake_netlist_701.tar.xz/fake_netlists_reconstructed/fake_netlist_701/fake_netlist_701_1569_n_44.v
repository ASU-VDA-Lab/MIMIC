module fake_netlist_701_1569_n_44 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_44);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_44;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_8),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_3),
.B(n_0),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_10),
.Y(n_27)
);

BUFx8_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

OA22x2_ASAP7_75t_L g29 ( 
.A1(n_20),
.A2(n_18),
.B1(n_17),
.B2(n_1),
.Y(n_29)
);

INVx3_ASAP7_75t_SL g30 ( 
.A(n_24),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_R g31 ( 
.A(n_29),
.B(n_21),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_24),
.B1(n_23),
.B2(n_22),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_R g33 ( 
.A(n_31),
.B(n_17),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AOI31xp33_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_27),
.A3(n_25),
.B(n_28),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_30),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

O2A1O1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_26),
.B(n_4),
.C(n_2),
.Y(n_39)
);

NOR2xp67_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_5),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_SL g41 ( 
.A1(n_39),
.A2(n_37),
.B1(n_7),
.B2(n_6),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_40),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_R g43 ( 
.A1(n_41),
.A2(n_12),
.B1(n_11),
.B2(n_9),
.Y(n_43)
);

OAI221xp5_ASAP7_75t_R g44 ( 
.A1(n_43),
.A2(n_42),
.B1(n_15),
.B2(n_13),
.C(n_14),
.Y(n_44)
);


endmodule