module fake_netlist_701_715_n_55 (n_2, n_21, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_55);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_55;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_20),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_13),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_14),
.B(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_1),
.B(n_3),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_9),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_6),
.Y(n_31)
);

BUFx8_ASAP7_75t_L g32 ( 
.A(n_16),
.Y(n_32)
);

OR2x4_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_13),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_31),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_23),
.Y(n_35)
);

INVx2_ASAP7_75t_SL g36 ( 
.A(n_22),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_33),
.A2(n_24),
.B1(n_27),
.B2(n_28),
.Y(n_37)
);

NAND3xp33_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_35),
.C(n_36),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_25),
.B1(n_27),
.B2(n_30),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

NAND3xp33_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_32),
.C(n_30),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_37),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_20),
.Y(n_45)
);

OAI211xp5_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_30),
.B(n_21),
.C(n_0),
.Y(n_46)
);

INVx1_ASAP7_75t_SL g47 ( 
.A(n_44),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_46),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_21),
.Y(n_49)
);

NOR4xp25_ASAP7_75t_SL g50 ( 
.A(n_48),
.B(n_49),
.C(n_47),
.D(n_2),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_4),
.Y(n_51)
);

OA22x2_ASAP7_75t_L g52 ( 
.A1(n_47),
.A2(n_8),
.B1(n_7),
.B2(n_5),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);

AOI21xp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_11),
.B(n_10),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_51),
.B1(n_54),
.B2(n_50),
.Y(n_55)
);


endmodule