module fake_netlist_701_1897_n_35 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_35);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_35;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_34;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

A2O1A1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_18),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_22),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_17),
.B1(n_21),
.B2(n_20),
.C(n_19),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

NOR3xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_26),
.C(n_23),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_20),
.B(n_1),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_R g31 ( 
.A(n_29),
.B(n_2),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

BUFx4f_ASAP7_75t_SL g33 ( 
.A(n_30),
.Y(n_33)
);

NAND4xp75_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_7),
.C(n_6),
.D(n_3),
.Y(n_34)
);

AOI322xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_33),
.A3(n_11),
.B1(n_10),
.B2(n_5),
.C1(n_15),
.C2(n_12),
.Y(n_35)
);


endmodule