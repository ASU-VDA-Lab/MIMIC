module fake_netlist_701_2368_n_13 (n_3, n_0, n_2, n_1, n_13);

input n_3;
input n_0;
input n_2;
input n_1;

output n_13;

wire n_9;
wire n_4;
wire n_7;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AOI22xp33_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_5)
);

A2O1A1Ixp33_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_2),
.C(n_0),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI221xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_2),
.B1(n_3),
.B2(n_5),
.C(n_4),
.Y(n_9)
);

OAI21xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_3),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_11),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);


endmodule