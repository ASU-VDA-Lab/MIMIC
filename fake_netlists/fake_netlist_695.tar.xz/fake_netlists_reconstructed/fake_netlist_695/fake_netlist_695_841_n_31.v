module fake_netlist_695_841_n_31 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_31);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_31;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_29;
wire n_12;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_2),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_8),
.B(n_5),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

INVx4_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_6),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_6),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_7),
.B1(n_3),
.B2(n_0),
.Y(n_17)
);

AO22x2_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_7),
.B1(n_4),
.B2(n_3),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_7),
.B(n_5),
.C(n_4),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_18),
.Y(n_24)
);

AOI221x1_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_19),
.B1(n_18),
.B2(n_9),
.C(n_12),
.Y(n_25)
);

AOI211x1_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_11),
.B(n_22),
.C(n_20),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_22),
.Y(n_27)
);

NOR4xp25_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_23),
.C(n_17),
.D(n_10),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_8),
.B1(n_10),
.B2(n_21),
.C1(n_26),
.C2(n_29),
.Y(n_31)
);


endmodule