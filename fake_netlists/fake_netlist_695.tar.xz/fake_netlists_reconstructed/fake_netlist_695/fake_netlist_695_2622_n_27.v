module fake_netlist_695_2622_n_27 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_13;
wire n_11;
wire n_25;
wire n_19;
wire n_14;
wire n_12;

NOR2xp67_ASAP7_75t_L g11 ( 
.A(n_0),
.B(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_1),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_5),
.B(n_8),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_6),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_4),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_4),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AO21x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B(n_11),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_19),
.Y(n_23)
);

AO22x2_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_13),
.B1(n_15),
.B2(n_5),
.Y(n_24)
);

NOR2x1_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_2),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVxp67_ASAP7_75t_SL g27 ( 
.A(n_26),
.Y(n_27)
);


endmodule