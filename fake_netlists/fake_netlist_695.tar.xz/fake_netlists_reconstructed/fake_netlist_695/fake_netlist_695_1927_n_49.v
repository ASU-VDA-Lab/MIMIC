module fake_netlist_695_1927_n_49 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_49);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_49;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_43;
wire n_37;
wire n_31;
wire n_23;
wire n_46;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_19;
wire n_39;
wire n_14;

INVx1_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_6),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

BUFx10_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_9),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_4),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_3),
.B(n_2),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_9),
.B(n_7),
.Y(n_22)
);

O2A1O1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_14),
.A2(n_5),
.B(n_1),
.C(n_0),
.Y(n_23)
);

A2O1A1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_21),
.B(n_14),
.C(n_15),
.Y(n_24)
);

OAI22x1_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_21),
.B1(n_18),
.B2(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_19),
.Y(n_27)
);

O2A1O1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_17),
.A2(n_5),
.B(n_1),
.C(n_0),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_17),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_27),
.B(n_17),
.Y(n_31)
);

NAND2xp33_ASAP7_75t_R g32 ( 
.A(n_26),
.B(n_22),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_25),
.A2(n_17),
.B1(n_22),
.B2(n_7),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_24),
.B(n_8),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_25),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_30),
.B(n_26),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_31),
.B(n_28),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_34),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_28),
.B(n_23),
.C(n_33),
.Y(n_39)
);

OAI21xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_35),
.B(n_32),
.Y(n_40)
);

O2A1O1Ixp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_11),
.B(n_10),
.C(n_8),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

INVxp67_ASAP7_75t_SL g43 ( 
.A(n_40),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_13),
.B(n_12),
.Y(n_45)
);

CKINVDCx16_ASAP7_75t_R g46 ( 
.A(n_42),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_41),
.Y(n_47)
);

INVx2_ASAP7_75t_SL g48 ( 
.A(n_44),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_11),
.B1(n_45),
.B2(n_47),
.Y(n_49)
);


endmodule