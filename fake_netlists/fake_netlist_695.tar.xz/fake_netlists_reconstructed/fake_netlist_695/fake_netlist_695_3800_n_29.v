module fake_netlist_695_3800_n_29 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_29);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_29;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_13;
wire n_28;
wire n_25;
wire n_19;
wire n_14;
wire n_12;

AND2x2_ASAP7_75t_L g12 ( 
.A(n_1),
.B(n_10),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_6),
.B(n_5),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND2x1p5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

AOI222xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_17),
.B1(n_16),
.B2(n_13),
.C1(n_19),
.C2(n_12),
.Y(n_23)
);

XOR2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_20),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_15),
.C(n_12),
.Y(n_25)
);

NOR3xp33_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_14),
.C(n_0),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_14),
.B1(n_6),
.B2(n_5),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_26),
.B1(n_14),
.B2(n_7),
.Y(n_28)
);

OAI222xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_7),
.B1(n_14),
.B2(n_9),
.C1(n_8),
.C2(n_3),
.Y(n_29)
);


endmodule