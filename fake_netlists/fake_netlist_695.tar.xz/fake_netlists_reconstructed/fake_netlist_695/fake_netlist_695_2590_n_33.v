module fake_netlist_695_2590_n_33 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_33);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_33;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_13),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

AOI21x1_ASAP7_75t_L g19 ( 
.A1(n_4),
.A2(n_0),
.B(n_15),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_11),
.B(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_8),
.B(n_3),
.Y(n_23)
);

OR2x6_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_0),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_1),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_18),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_16),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_27),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_23),
.B(n_22),
.Y(n_29)
);

OAI321xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_19),
.A3(n_20),
.B1(n_28),
.B2(n_17),
.C(n_21),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_30),
.B(n_1),
.Y(n_31)
);

OAI31xp67_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_5),
.A3(n_4),
.B(n_2),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_7),
.B1(n_6),
.B2(n_12),
.Y(n_33)
);


endmodule