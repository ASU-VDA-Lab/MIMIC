module fake_netlist_695_458_n_5 (n_0, n_2, n_1, n_5);

input n_0;
input n_2;
input n_1;

output n_5;

wire n_4;
wire n_3;

INVx3_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

AND2x2_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_0),
.Y(n_4)
);

AOI221xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C(n_0),
.Y(n_5)
);


endmodule