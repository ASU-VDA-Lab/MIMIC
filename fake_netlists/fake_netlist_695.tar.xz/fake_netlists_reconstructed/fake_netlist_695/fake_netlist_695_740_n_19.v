module fake_netlist_695_740_n_19 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_19);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_19;

wire n_17;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_13;
wire n_14;
wire n_12;

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_10),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_2),
.B(n_4),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_3),
.B(n_0),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

OAI322xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_4),
.A3(n_5),
.B1(n_6),
.B2(n_7),
.C1(n_8),
.C2(n_13),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_6),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);


endmodule