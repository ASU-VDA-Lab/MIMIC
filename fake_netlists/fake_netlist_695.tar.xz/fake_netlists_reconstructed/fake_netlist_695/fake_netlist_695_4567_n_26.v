module fake_netlist_695_4567_n_26 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_26);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_26;

wire n_24;
wire n_21;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_12;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

NAND2xp33_ASAP7_75t_R g10 ( 
.A(n_2),
.B(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_3),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_15),
.B(n_9),
.Y(n_16)
);

OAI21x1_ASAP7_75t_SL g17 ( 
.A1(n_15),
.A2(n_13),
.B(n_9),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_1),
.Y(n_18)
);

INVxp67_ASAP7_75t_SL g19 ( 
.A(n_18),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_13),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_17),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_20),
.B(n_17),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_14),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_6),
.Y(n_25)
);

AOI21xp33_ASAP7_75t_SL g26 ( 
.A1(n_24),
.A2(n_10),
.B(n_25),
.Y(n_26)
);


endmodule