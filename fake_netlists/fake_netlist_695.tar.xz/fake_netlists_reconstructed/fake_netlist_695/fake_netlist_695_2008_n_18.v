module fake_netlist_695_2008_n_18 (n_3, n_0, n_2, n_1, n_18);

input n_3;
input n_0;
input n_2;
input n_1;

output n_18;

wire n_9;
wire n_17;
wire n_4;
wire n_7;
wire n_15;
wire n_14;
wire n_11;
wire n_16;
wire n_12;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_13;

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_3),
.Y(n_5)
);

AOI22xp5_ASAP7_75t_SL g6 ( 
.A1(n_0),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

INVx4_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_5),
.Y(n_10)
);

OAI33xp33_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_9),
.A3(n_8),
.B1(n_6),
.B2(n_1),
.B3(n_0),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_2),
.B2(n_0),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_1),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_10),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_SL g17 ( 
.A(n_14),
.B(n_3),
.C(n_2),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_15),
.B1(n_14),
.B2(n_16),
.Y(n_18)
);


endmodule