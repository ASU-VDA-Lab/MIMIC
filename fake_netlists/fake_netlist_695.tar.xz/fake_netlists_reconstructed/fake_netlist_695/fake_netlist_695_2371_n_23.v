module fake_netlist_695_2371_n_23 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_23);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_23;

wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_13;
wire n_11;
wire n_19;
wire n_14;
wire n_12;

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_4),
.B1(n_7),
.B2(n_3),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_2),
.B(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_1),
.B(n_0),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_9),
.B(n_5),
.Y(n_17)
);

BUFx2_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.B1(n_15),
.B2(n_16),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_11),
.Y(n_20)
);

XOR2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_11),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_13),
.B(n_6),
.Y(n_23)
);


endmodule