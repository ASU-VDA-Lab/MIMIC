module fake_netlist_643_1560_n_55 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_55);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_55;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx1_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_SL g25 ( 
.A(n_9),
.B(n_4),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_11),
.B(n_21),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

AND3x1_ASAP7_75t_L g28 ( 
.A(n_5),
.B(n_18),
.C(n_1),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_12),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_22),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_0),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_13),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_8),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_27),
.Y(n_35)
);

NOR3xp33_ASAP7_75t_SL g36 ( 
.A(n_24),
.B(n_17),
.C(n_16),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_30),
.B(n_17),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_18),
.Y(n_38)
);

O2A1O1Ixp33_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_30),
.B(n_28),
.C(n_25),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_26),
.B1(n_29),
.B2(n_33),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_35),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_35),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_35),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_37),
.Y(n_44)
);

NOR3xp33_ASAP7_75t_SL g45 ( 
.A(n_44),
.B(n_34),
.C(n_33),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_42),
.Y(n_46)
);

NOR2xp67_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_34),
.Y(n_47)
);

OAI31xp33_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_26),
.A3(n_36),
.B(n_19),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_31),
.B1(n_21),
.B2(n_20),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_49),
.Y(n_50)
);

NAND3x2_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_20),
.C(n_2),
.Y(n_51)
);

XOR2xp5_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_3),
.Y(n_52)
);

OR3x2_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_10),
.C(n_7),
.Y(n_53)
);

OR3x1_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_15),
.C(n_14),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_23),
.B1(n_52),
.B2(n_54),
.Y(n_55)
);


endmodule