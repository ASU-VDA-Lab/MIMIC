module fake_netlist_643_2189_n_61 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_61);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_61;

wire n_36;
wire n_59;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_60;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_5),
.A2(n_6),
.B1(n_16),
.B2(n_11),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_13),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_3),
.B(n_16),
.Y(n_27)
);

NOR2x1_ASAP7_75t_L g28 ( 
.A(n_17),
.B(n_18),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_21),
.Y(n_30)
);

INVx3_ASAP7_75t_SL g31 ( 
.A(n_23),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

CKINVDCx11_ASAP7_75t_R g33 ( 
.A(n_26),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

OA21x2_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_29),
.B(n_25),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_27),
.B(n_22),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AO21x2_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_35),
.B(n_33),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_33),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

OAI21xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_40),
.B(n_37),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_41),
.A2(n_39),
.B1(n_28),
.B2(n_23),
.Y(n_47)
);

AOI31xp33_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_30),
.A3(n_18),
.B(n_17),
.Y(n_48)
);

INVx3_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_23),
.B1(n_20),
.B2(n_19),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_19),
.Y(n_52)
);

BUFx2_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

NOR3xp33_ASAP7_75t_L g54 ( 
.A(n_48),
.B(n_51),
.C(n_0),
.Y(n_54)
);

NOR3x2_ASAP7_75t_L g55 ( 
.A(n_48),
.B(n_7),
.C(n_4),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_9),
.Y(n_56)
);

AO22x2_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_57)
);

INVx1_ASAP7_75t_SL g58 ( 
.A(n_53),
.Y(n_58)
);

XNOR2x1_ASAP7_75t_L g59 ( 
.A(n_57),
.B(n_52),
.Y(n_59)
);

AOI21xp5_ASAP7_75t_L g60 ( 
.A1(n_56),
.A2(n_55),
.B(n_57),
.Y(n_60)
);

AOI21xp5_ASAP7_75t_SL g61 ( 
.A1(n_60),
.A2(n_58),
.B(n_59),
.Y(n_61)
);


endmodule