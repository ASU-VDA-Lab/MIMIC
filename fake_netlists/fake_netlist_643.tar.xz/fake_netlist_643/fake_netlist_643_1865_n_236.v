module fake_netlist_643_1865_n_236 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_27, n_2, n_26, n_9, n_13, n_8, n_6, n_236);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_27;
input n_2;
input n_26;
input n_9;
input n_13;
input n_8;
input n_6;

output n_236;

wire n_168;
wire n_99;
wire n_62;
wire n_90;
wire n_70;
wire n_101;
wire n_58;
wire n_38;
wire n_144;
wire n_155;
wire n_166;
wire n_139;
wire n_57;
wire n_84;
wire n_214;
wire n_35;
wire n_89;
wire n_209;
wire n_152;
wire n_116;
wire n_96;
wire n_172;
wire n_45;
wire n_107;
wire n_220;
wire n_218;
wire n_78;
wire n_235;
wire n_191;
wire n_66;
wire n_154;
wire n_164;
wire n_118;
wire n_60;
wire n_137;
wire n_189;
wire n_39;
wire n_197;
wire n_183;
wire n_173;
wire n_63;
wire n_190;
wire n_211;
wire n_206;
wire n_177;
wire n_192;
wire n_31;
wire n_194;
wire n_184;
wire n_187;
wire n_81;
wire n_37;
wire n_71;
wire n_124;
wire n_163;
wire n_91;
wire n_165;
wire n_121;
wire n_157;
wire n_201;
wire n_105;
wire n_92;
wire n_125;
wire n_117;
wire n_230;
wire n_136;
wire n_40;
wire n_217;
wire n_223;
wire n_110;
wire n_28;
wire n_170;
wire n_49;
wire n_207;
wire n_151;
wire n_53;
wire n_161;
wire n_77;
wire n_234;
wire n_75;
wire n_48;
wire n_180;
wire n_142;
wire n_232;
wire n_93;
wire n_199;
wire n_203;
wire n_181;
wire n_41;
wire n_143;
wire n_213;
wire n_65;
wire n_109;
wire n_33;
wire n_208;
wire n_122;
wire n_219;
wire n_119;
wire n_149;
wire n_43;
wire n_182;
wire n_227;
wire n_82;
wire n_204;
wire n_120;
wire n_85;
wire n_61;
wire n_176;
wire n_72;
wire n_229;
wire n_51;
wire n_160;
wire n_231;
wire n_226;
wire n_54;
wire n_86;
wire n_156;
wire n_68;
wire n_198;
wire n_130;
wire n_210;
wire n_140;
wire n_174;
wire n_233;
wire n_202;
wire n_167;
wire n_175;
wire n_195;
wire n_67;
wire n_112;
wire n_29;
wire n_179;
wire n_52;
wire n_50;
wire n_113;
wire n_169;
wire n_103;
wire n_104;
wire n_127;
wire n_162;
wire n_100;
wire n_150;
wire n_146;
wire n_129;
wire n_76;
wire n_83;
wire n_134;
wire n_196;
wire n_200;
wire n_106;
wire n_133;
wire n_225;
wire n_36;
wire n_59;
wire n_97;
wire n_34;
wire n_131;
wire n_64;
wire n_148;
wire n_44;
wire n_159;
wire n_228;
wire n_123;
wire n_141;
wire n_87;
wire n_145;
wire n_115;
wire n_79;
wire n_215;
wire n_30;
wire n_128;
wire n_205;
wire n_108;
wire n_126;
wire n_185;
wire n_73;
wire n_132;
wire n_56;
wire n_98;
wire n_69;
wire n_224;
wire n_147;
wire n_171;
wire n_94;
wire n_212;
wire n_221;
wire n_222;
wire n_193;
wire n_138;
wire n_46;
wire n_153;
wire n_42;
wire n_158;
wire n_216;
wire n_55;
wire n_102;
wire n_135;
wire n_95;
wire n_178;
wire n_74;
wire n_32;
wire n_186;
wire n_47;
wire n_188;
wire n_80;
wire n_88;
wire n_114;
wire n_111;

INVxp67_ASAP7_75t_SL g28 ( 
.A(n_13),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_0),
.Y(n_30)
);

INVxp67_ASAP7_75t_SL g31 ( 
.A(n_19),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_18),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_4),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_0),
.Y(n_34)
);

INVxp67_ASAP7_75t_SL g35 ( 
.A(n_26),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_13),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_24),
.Y(n_38)
);

CKINVDCx16_ASAP7_75t_R g39 ( 
.A(n_14),
.Y(n_39)
);

CKINVDCx20_ASAP7_75t_R g40 ( 
.A(n_17),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_39),
.B(n_1),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_33),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_33),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_33),
.Y(n_45)
);

INVx3_ASAP7_75t_L g46 ( 
.A(n_33),
.Y(n_46)
);

INVx3_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_L g48 ( 
.A1(n_41),
.A2(n_39),
.B1(n_36),
.B2(n_34),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_43),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_43),
.Y(n_50)
);

BUFx10_ASAP7_75t_L g51 ( 
.A(n_44),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_SL g52 ( 
.A(n_42),
.B(n_36),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_SL g53 ( 
.A(n_42),
.B(n_41),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_46),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_44),
.Y(n_55)
);

AND3x1_ASAP7_75t_L g56 ( 
.A(n_45),
.B(n_34),
.C(n_29),
.Y(n_56)
);

INVxp67_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

CKINVDCx20_ASAP7_75t_R g58 ( 
.A(n_48),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_SL g59 ( 
.A(n_56),
.B(n_30),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_50),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_50),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_55),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_L g63 ( 
.A(n_47),
.B(n_46),
.Y(n_63)
);

NOR2xp33_ASAP7_75t_L g64 ( 
.A(n_52),
.B(n_32),
.Y(n_64)
);

AND2x4_ASAP7_75t_L g65 ( 
.A(n_56),
.B(n_45),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_55),
.Y(n_66)
);

INVx3_ASAP7_75t_L g67 ( 
.A(n_47),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_51),
.B(n_46),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_47),
.Y(n_69)
);

NAND3xp33_ASAP7_75t_L g70 ( 
.A(n_69),
.B(n_48),
.C(n_47),
.Y(n_70)
);

AND2x2_ASAP7_75t_L g71 ( 
.A(n_65),
.B(n_51),
.Y(n_71)
);

HB1xp67_ASAP7_75t_L g72 ( 
.A(n_57),
.Y(n_72)
);

OAI221xp5_ASAP7_75t_L g73 ( 
.A1(n_64),
.A2(n_28),
.B1(n_32),
.B2(n_31),
.C(n_35),
.Y(n_73)
);

OR2x6_ASAP7_75t_L g74 ( 
.A(n_65),
.B(n_29),
.Y(n_74)
);

AOI21xp5_ASAP7_75t_L g75 ( 
.A1(n_69),
.A2(n_49),
.B(n_54),
.Y(n_75)
);

NOR2x1_ASAP7_75t_SL g76 ( 
.A(n_68),
.B(n_60),
.Y(n_76)
);

BUFx12f_ASAP7_75t_L g77 ( 
.A(n_65),
.Y(n_77)
);

NAND2xp5_ASAP7_75t_L g78 ( 
.A(n_68),
.B(n_51),
.Y(n_78)
);

AOI21xp5_ASAP7_75t_L g79 ( 
.A1(n_67),
.A2(n_49),
.B(n_54),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_60),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_80),
.B(n_61),
.Y(n_81)
);

OAI21x1_ASAP7_75t_L g82 ( 
.A1(n_79),
.A2(n_67),
.B(n_61),
.Y(n_82)
);

INVx2_ASAP7_75t_L g83 ( 
.A(n_80),
.Y(n_83)
);

OAI21x1_ASAP7_75t_L g84 ( 
.A1(n_75),
.A2(n_67),
.B(n_62),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_76),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_76),
.Y(n_86)
);

AO21x2_ASAP7_75t_L g87 ( 
.A1(n_78),
.A2(n_66),
.B(n_62),
.Y(n_87)
);

INVx2_ASAP7_75t_L g88 ( 
.A(n_74),
.Y(n_88)
);

NOR2xp33_ASAP7_75t_L g89 ( 
.A(n_88),
.B(n_72),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_83),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_83),
.Y(n_91)
);

AND2x2_ASAP7_75t_L g92 ( 
.A(n_88),
.B(n_71),
.Y(n_92)
);

AND2x2_ASAP7_75t_L g93 ( 
.A(n_88),
.B(n_71),
.Y(n_93)
);

INVx1_ASAP7_75t_L g94 ( 
.A(n_83),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_83),
.Y(n_95)
);

AOI221xp5_ASAP7_75t_L g96 ( 
.A1(n_89),
.A2(n_73),
.B1(n_58),
.B2(n_59),
.C(n_57),
.Y(n_96)
);

OAI22xp5_ASAP7_75t_L g97 ( 
.A1(n_94),
.A2(n_81),
.B1(n_88),
.B2(n_74),
.Y(n_97)
);

INVx2_ASAP7_75t_L g98 ( 
.A(n_94),
.Y(n_98)
);

INVx1_ASAP7_75t_SL g99 ( 
.A(n_93),
.Y(n_99)
);

INVx1_ASAP7_75t_SL g100 ( 
.A(n_93),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_90),
.Y(n_101)
);

OAI21xp33_ASAP7_75t_L g102 ( 
.A1(n_92),
.A2(n_74),
.B(n_65),
.Y(n_102)
);

OR2x2_ASAP7_75t_L g103 ( 
.A(n_92),
.B(n_87),
.Y(n_103)
);

INVx2_ASAP7_75t_L g104 ( 
.A(n_95),
.Y(n_104)
);

AND2x2_ASAP7_75t_L g105 ( 
.A(n_95),
.B(n_74),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_101),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_98),
.Y(n_107)
);

INVx1_ASAP7_75t_SL g108 ( 
.A(n_99),
.Y(n_108)
);

AND2x4_ASAP7_75t_L g109 ( 
.A(n_100),
.B(n_91),
.Y(n_109)
);

NOR2xp33_ASAP7_75t_L g110 ( 
.A(n_102),
.B(n_77),
.Y(n_110)
);

OR2x2_ASAP7_75t_L g111 ( 
.A(n_103),
.B(n_87),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_98),
.Y(n_112)
);

AND2x2_ASAP7_75t_L g113 ( 
.A(n_105),
.B(n_74),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_104),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_104),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_105),
.Y(n_116)
);

INVx2_ASAP7_75t_SL g117 ( 
.A(n_103),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_97),
.Y(n_118)
);

OR2x2_ASAP7_75t_L g119 ( 
.A(n_96),
.B(n_87),
.Y(n_119)
);

INVx2_ASAP7_75t_L g120 ( 
.A(n_98),
.Y(n_120)
);

OR2x2_ASAP7_75t_L g121 ( 
.A(n_103),
.B(n_87),
.Y(n_121)
);

INVx2_ASAP7_75t_L g122 ( 
.A(n_98),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_101),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_108),
.B(n_116),
.Y(n_124)
);

CKINVDCx20_ASAP7_75t_R g125 ( 
.A(n_113),
.Y(n_125)
);

OR2x2_ASAP7_75t_L g126 ( 
.A(n_117),
.B(n_87),
.Y(n_126)
);

INVx2_ASAP7_75t_L g127 ( 
.A(n_120),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_106),
.Y(n_128)
);

OR2x4_ASAP7_75t_L g129 ( 
.A(n_119),
.B(n_110),
.Y(n_129)
);

NOR2xp67_ASAP7_75t_SL g130 ( 
.A(n_119),
.B(n_77),
.Y(n_130)
);

INVx2_ASAP7_75t_L g131 ( 
.A(n_120),
.Y(n_131)
);

INVx1_ASAP7_75t_L g132 ( 
.A(n_123),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_107),
.Y(n_133)
);

AND2x2_ASAP7_75t_L g134 ( 
.A(n_117),
.B(n_37),
.Y(n_134)
);

AND2x2_ASAP7_75t_L g135 ( 
.A(n_111),
.B(n_37),
.Y(n_135)
);

NAND3x1_ASAP7_75t_SL g136 ( 
.A(n_113),
.B(n_110),
.C(n_77),
.Y(n_136)
);

OR2x2_ASAP7_75t_L g137 ( 
.A(n_111),
.B(n_84),
.Y(n_137)
);

AND2x2_ASAP7_75t_L g138 ( 
.A(n_121),
.B(n_84),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_112),
.Y(n_139)
);

INVx1_ASAP7_75t_L g140 ( 
.A(n_114),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_115),
.Y(n_141)
);

AND2x4_ASAP7_75t_L g142 ( 
.A(n_122),
.B(n_85),
.Y(n_142)
);

AND2x2_ASAP7_75t_L g143 ( 
.A(n_121),
.B(n_84),
.Y(n_143)
);

NOR2xp33_ASAP7_75t_L g144 ( 
.A(n_109),
.B(n_38),
.Y(n_144)
);

AND2x2_ASAP7_75t_L g145 ( 
.A(n_122),
.B(n_84),
.Y(n_145)
);

NAND2xp5_ASAP7_75t_L g146 ( 
.A(n_109),
.B(n_70),
.Y(n_146)
);

OR2x2_ASAP7_75t_L g147 ( 
.A(n_118),
.B(n_82),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_109),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_106),
.Y(n_149)
);

NOR2xp33_ASAP7_75t_L g150 ( 
.A(n_124),
.B(n_144),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_128),
.Y(n_151)
);

NAND2xp5_ASAP7_75t_L g152 ( 
.A(n_135),
.B(n_28),
.Y(n_152)
);

INVx2_ASAP7_75t_L g153 ( 
.A(n_127),
.Y(n_153)
);

AND2x2_ASAP7_75t_L g154 ( 
.A(n_143),
.B(n_82),
.Y(n_154)
);

INVx1_ASAP7_75t_L g155 ( 
.A(n_132),
.Y(n_155)
);

INVx3_ASAP7_75t_L g156 ( 
.A(n_142),
.Y(n_156)
);

NAND2xp5_ASAP7_75t_L g157 ( 
.A(n_135),
.B(n_134),
.Y(n_157)
);

NAND2xp5_ASAP7_75t_L g158 ( 
.A(n_134),
.B(n_31),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_149),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_133),
.Y(n_160)
);

OR2x2_ASAP7_75t_L g161 ( 
.A(n_137),
.B(n_82),
.Y(n_161)
);

AND2x2_ASAP7_75t_L g162 ( 
.A(n_143),
.B(n_35),
.Y(n_162)
);

AND2x2_ASAP7_75t_L g163 ( 
.A(n_138),
.B(n_85),
.Y(n_163)
);

NAND2xp5_ASAP7_75t_L g164 ( 
.A(n_139),
.B(n_85),
.Y(n_164)
);

INVx1_ASAP7_75t_L g165 ( 
.A(n_140),
.Y(n_165)
);

INVx1_ASAP7_75t_L g166 ( 
.A(n_141),
.Y(n_166)
);

INVx1_ASAP7_75t_L g167 ( 
.A(n_127),
.Y(n_167)
);

INVx1_ASAP7_75t_SL g168 ( 
.A(n_125),
.Y(n_168)
);

AND2x2_ASAP7_75t_L g169 ( 
.A(n_138),
.B(n_86),
.Y(n_169)
);

NAND2xp5_ASAP7_75t_L g170 ( 
.A(n_146),
.B(n_86),
.Y(n_170)
);

INVx1_ASAP7_75t_L g171 ( 
.A(n_131),
.Y(n_171)
);

OR2x2_ASAP7_75t_L g172 ( 
.A(n_137),
.B(n_86),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_131),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_148),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_145),
.Y(n_175)
);

OR2x2_ASAP7_75t_L g176 ( 
.A(n_126),
.B(n_81),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_145),
.Y(n_177)
);

NAND2xp5_ASAP7_75t_L g178 ( 
.A(n_125),
.B(n_1),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_147),
.Y(n_179)
);

NOR3xp33_ASAP7_75t_L g180 ( 
.A(n_158),
.B(n_136),
.C(n_70),
.Y(n_180)
);

NAND2xp5_ASAP7_75t_L g181 ( 
.A(n_162),
.B(n_129),
.Y(n_181)
);

NAND4xp25_ASAP7_75t_L g182 ( 
.A(n_152),
.B(n_147),
.C(n_126),
.D(n_142),
.Y(n_182)
);

NAND2xp5_ASAP7_75t_L g183 ( 
.A(n_162),
.B(n_129),
.Y(n_183)
);

O2A1O1Ixp33_ASAP7_75t_SL g184 ( 
.A1(n_157),
.A2(n_40),
.B(n_38),
.C(n_129),
.Y(n_184)
);

NOR3xp33_ASAP7_75t_L g185 ( 
.A(n_178),
.B(n_136),
.C(n_66),
.Y(n_185)
);

INVx1_ASAP7_75t_L g186 ( 
.A(n_151),
.Y(n_186)
);

NAND3x1_ASAP7_75t_L g187 ( 
.A(n_150),
.B(n_130),
.C(n_2),
.Y(n_187)
);

NAND4xp75_ASAP7_75t_L g188 ( 
.A(n_170),
.B(n_130),
.C(n_63),
.D(n_2),
.Y(n_188)
);

INVx1_ASAP7_75t_L g189 ( 
.A(n_155),
.Y(n_189)
);

AND2x2_ASAP7_75t_L g190 ( 
.A(n_156),
.B(n_142),
.Y(n_190)
);

INVx2_ASAP7_75t_SL g191 ( 
.A(n_159),
.Y(n_191)
);

AND2x2_ASAP7_75t_L g192 ( 
.A(n_156),
.B(n_3),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_160),
.Y(n_193)
);

NAND2xp5_ASAP7_75t_L g194 ( 
.A(n_165),
.B(n_3),
.Y(n_194)
);

AOI221xp5_ASAP7_75t_L g195 ( 
.A1(n_179),
.A2(n_40),
.B1(n_6),
.B2(n_4),
.C(n_5),
.Y(n_195)
);

OAI21xp33_ASAP7_75t_SL g196 ( 
.A1(n_179),
.A2(n_6),
.B(n_5),
.Y(n_196)
);

NAND2xp5_ASAP7_75t_L g197 ( 
.A(n_166),
.B(n_7),
.Y(n_197)
);

NAND3xp33_ASAP7_75t_L g198 ( 
.A(n_172),
.B(n_63),
.C(n_54),
.Y(n_198)
);

INVx1_ASAP7_75t_L g199 ( 
.A(n_167),
.Y(n_199)
);

AOI211xp5_ASAP7_75t_L g200 ( 
.A1(n_168),
.A2(n_9),
.B(n_8),
.C(n_7),
.Y(n_200)
);

OAI221xp5_ASAP7_75t_SL g201 ( 
.A1(n_172),
.A2(n_9),
.B1(n_8),
.B2(n_10),
.C(n_11),
.Y(n_201)
);

INVxp33_ASAP7_75t_L g202 ( 
.A(n_163),
.Y(n_202)
);

INVx2_ASAP7_75t_SL g203 ( 
.A(n_156),
.Y(n_203)
);

INVx1_ASAP7_75t_L g204 ( 
.A(n_199),
.Y(n_204)
);

OAI22xp33_ASAP7_75t_SL g205 ( 
.A1(n_181),
.A2(n_183),
.B1(n_201),
.B2(n_194),
.Y(n_205)
);

OAI22xp5_ASAP7_75t_L g206 ( 
.A1(n_187),
.A2(n_177),
.B1(n_175),
.B2(n_161),
.Y(n_206)
);

NAND2xp5_ASAP7_75t_L g207 ( 
.A(n_191),
.B(n_154),
.Y(n_207)
);

AOI21xp33_ASAP7_75t_L g208 ( 
.A1(n_196),
.A2(n_174),
.B(n_161),
.Y(n_208)
);

NAND2xp5_ASAP7_75t_L g209 ( 
.A(n_186),
.B(n_154),
.Y(n_209)
);

O2A1O1Ixp33_ASAP7_75t_L g210 ( 
.A1(n_201),
.A2(n_164),
.B(n_176),
.C(n_163),
.Y(n_210)
);

OAI32xp33_ASAP7_75t_L g211 ( 
.A1(n_185),
.A2(n_176),
.A3(n_173),
.B1(n_167),
.B2(n_171),
.Y(n_211)
);

AOI22xp33_ASAP7_75t_L g212 ( 
.A1(n_180),
.A2(n_169),
.B1(n_173),
.B2(n_153),
.Y(n_212)
);

NOR2xp67_ASAP7_75t_L g213 ( 
.A(n_203),
.B(n_153),
.Y(n_213)
);

NOR2x1_ASAP7_75t_L g214 ( 
.A(n_189),
.B(n_169),
.Y(n_214)
);

AOI322xp5_ASAP7_75t_L g215 ( 
.A1(n_195),
.A2(n_11),
.A3(n_10),
.B1(n_12),
.B2(n_15),
.C1(n_14),
.C2(n_67),
.Y(n_215)
);

AND2x2_ASAP7_75t_L g216 ( 
.A(n_202),
.B(n_12),
.Y(n_216)
);

OAI21xp5_ASAP7_75t_L g217 ( 
.A1(n_188),
.A2(n_15),
.B(n_16),
.Y(n_217)
);

NAND3xp33_ASAP7_75t_SL g218 ( 
.A(n_200),
.B(n_22),
.C(n_21),
.Y(n_218)
);

AND3x4_ASAP7_75t_L g219 ( 
.A(n_214),
.B(n_185),
.C(n_180),
.Y(n_219)
);

INVx1_ASAP7_75t_L g220 ( 
.A(n_204),
.Y(n_220)
);

NOR2x1_ASAP7_75t_L g221 ( 
.A(n_206),
.B(n_197),
.Y(n_221)
);

AND2x2_ASAP7_75t_L g222 ( 
.A(n_207),
.B(n_190),
.Y(n_222)
);

INVx1_ASAP7_75t_L g223 ( 
.A(n_209),
.Y(n_223)
);

HB1xp67_ASAP7_75t_L g224 ( 
.A(n_213),
.Y(n_224)
);

NOR2xp67_ASAP7_75t_L g225 ( 
.A(n_212),
.B(n_193),
.Y(n_225)
);

XNOR2x1_ASAP7_75t_L g226 ( 
.A(n_216),
.B(n_192),
.Y(n_226)
);

INVx3_ASAP7_75t_SL g227 ( 
.A(n_226),
.Y(n_227)
);

AND2x4_ASAP7_75t_L g228 ( 
.A(n_220),
.B(n_198),
.Y(n_228)
);

AOI22xp33_ASAP7_75t_L g229 ( 
.A1(n_219),
.A2(n_218),
.B1(n_217),
.B2(n_182),
.Y(n_229)
);

AOI222xp33_ASAP7_75t_L g230 ( 
.A1(n_221),
.A2(n_211),
.B1(n_215),
.B2(n_205),
.C1(n_184),
.C2(n_210),
.Y(n_230)
);

OR5x1_ASAP7_75t_L g231 ( 
.A(n_230),
.B(n_219),
.C(n_224),
.D(n_225),
.E(n_223),
.Y(n_231)
);

NAND3xp33_ASAP7_75t_SL g232 ( 
.A(n_229),
.B(n_227),
.C(n_210),
.Y(n_232)
);

OAI222xp33_ASAP7_75t_L g233 ( 
.A1(n_231),
.A2(n_224),
.B1(n_228),
.B2(n_222),
.C1(n_184),
.C2(n_208),
.Y(n_233)
);

AOI22xp33_ASAP7_75t_SL g234 ( 
.A1(n_233),
.A2(n_232),
.B1(n_228),
.B2(n_51),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_234),
.Y(n_235)
);

AOI21xp5_ASAP7_75t_L g236 ( 
.A1(n_235),
.A2(n_25),
.B(n_23),
.Y(n_236)
);


endmodule