module fake_netlist_643_1180_n_231 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_28, n_11, n_15, n_7, n_30, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_27, n_2, n_29, n_26, n_9, n_13, n_8, n_6, n_231);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_28;
input n_11;
input n_15;
input n_7;
input n_30;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_27;
input n_2;
input n_29;
input n_26;
input n_9;
input n_13;
input n_8;
input n_6;

output n_231;

wire n_168;
wire n_99;
wire n_70;
wire n_62;
wire n_90;
wire n_101;
wire n_38;
wire n_58;
wire n_144;
wire n_166;
wire n_155;
wire n_139;
wire n_57;
wire n_84;
wire n_214;
wire n_35;
wire n_89;
wire n_209;
wire n_152;
wire n_116;
wire n_96;
wire n_172;
wire n_45;
wire n_107;
wire n_220;
wire n_218;
wire n_78;
wire n_191;
wire n_66;
wire n_154;
wire n_164;
wire n_118;
wire n_60;
wire n_137;
wire n_39;
wire n_197;
wire n_189;
wire n_173;
wire n_183;
wire n_63;
wire n_190;
wire n_211;
wire n_206;
wire n_177;
wire n_192;
wire n_31;
wire n_194;
wire n_184;
wire n_187;
wire n_81;
wire n_37;
wire n_71;
wire n_124;
wire n_163;
wire n_91;
wire n_165;
wire n_121;
wire n_157;
wire n_201;
wire n_105;
wire n_92;
wire n_125;
wire n_117;
wire n_230;
wire n_136;
wire n_40;
wire n_217;
wire n_223;
wire n_110;
wire n_170;
wire n_49;
wire n_207;
wire n_151;
wire n_53;
wire n_161;
wire n_77;
wire n_75;
wire n_48;
wire n_180;
wire n_142;
wire n_93;
wire n_199;
wire n_203;
wire n_181;
wire n_41;
wire n_143;
wire n_213;
wire n_65;
wire n_109;
wire n_33;
wire n_208;
wire n_122;
wire n_219;
wire n_119;
wire n_149;
wire n_43;
wire n_182;
wire n_227;
wire n_82;
wire n_204;
wire n_120;
wire n_85;
wire n_61;
wire n_176;
wire n_72;
wire n_229;
wire n_51;
wire n_160;
wire n_226;
wire n_54;
wire n_86;
wire n_156;
wire n_68;
wire n_198;
wire n_130;
wire n_210;
wire n_140;
wire n_174;
wire n_202;
wire n_167;
wire n_175;
wire n_195;
wire n_67;
wire n_112;
wire n_179;
wire n_52;
wire n_50;
wire n_113;
wire n_169;
wire n_103;
wire n_104;
wire n_127;
wire n_162;
wire n_100;
wire n_150;
wire n_129;
wire n_146;
wire n_76;
wire n_83;
wire n_134;
wire n_200;
wire n_196;
wire n_106;
wire n_133;
wire n_225;
wire n_36;
wire n_59;
wire n_97;
wire n_34;
wire n_131;
wire n_64;
wire n_148;
wire n_44;
wire n_159;
wire n_228;
wire n_123;
wire n_141;
wire n_87;
wire n_115;
wire n_145;
wire n_79;
wire n_215;
wire n_128;
wire n_205;
wire n_108;
wire n_126;
wire n_185;
wire n_73;
wire n_132;
wire n_56;
wire n_98;
wire n_69;
wire n_224;
wire n_147;
wire n_171;
wire n_94;
wire n_221;
wire n_212;
wire n_222;
wire n_193;
wire n_138;
wire n_46;
wire n_153;
wire n_42;
wire n_158;
wire n_216;
wire n_55;
wire n_102;
wire n_135;
wire n_95;
wire n_178;
wire n_74;
wire n_32;
wire n_186;
wire n_47;
wire n_188;
wire n_80;
wire n_88;
wire n_114;
wire n_111;

INVxp33_ASAP7_75t_SL g31 ( 
.A(n_5),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_7),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_3),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_15),
.B(n_7),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_17),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_9),
.Y(n_38)
);

INVxp67_ASAP7_75t_SL g39 ( 
.A(n_27),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_8),
.Y(n_40)
);

INVxp67_ASAP7_75t_L g41 ( 
.A(n_10),
.Y(n_41)
);

BUFx6f_ASAP7_75t_SL g42 ( 
.A(n_11),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_32),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_37),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_35),
.B(n_6),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_38),
.Y(n_46)
);

BUFx10_ASAP7_75t_L g47 ( 
.A(n_42),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_36),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_43),
.Y(n_49)
);

INVxp67_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

AND2x4_ASAP7_75t_L g51 ( 
.A(n_43),
.B(n_37),
.Y(n_51)
);

AND2x4_ASAP7_75t_L g52 ( 
.A(n_45),
.B(n_37),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_44),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_44),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_44),
.Y(n_55)
);

AO22x2_ASAP7_75t_L g56 ( 
.A1(n_48),
.A2(n_36),
.B1(n_33),
.B2(n_32),
.Y(n_56)
);

NOR2xp33_ASAP7_75t_L g57 ( 
.A(n_47),
.B(n_31),
.Y(n_57)
);

INVx3_ASAP7_75t_L g58 ( 
.A(n_47),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_50),
.B(n_47),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_50),
.B(n_47),
.Y(n_60)
);

BUFx2_ASAP7_75t_L g61 ( 
.A(n_56),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_52),
.B(n_47),
.Y(n_62)
);

CKINVDCx20_ASAP7_75t_R g63 ( 
.A(n_57),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_52),
.B(n_35),
.Y(n_64)
);

BUFx6f_ASAP7_75t_L g65 ( 
.A(n_51),
.Y(n_65)
);

NOR2x1p5_ASAP7_75t_SL g66 ( 
.A(n_53),
.B(n_40),
.Y(n_66)
);

OAI22xp5_ASAP7_75t_L g67 ( 
.A1(n_56),
.A2(n_48),
.B1(n_39),
.B2(n_33),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_52),
.B(n_40),
.Y(n_68)
);

INVx2_ASAP7_75t_L g69 ( 
.A(n_53),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_53),
.Y(n_70)
);

NAND2x1p5_ASAP7_75t_L g71 ( 
.A(n_52),
.B(n_37),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_69),
.Y(n_72)
);

AOI21xp5_ASAP7_75t_L g73 ( 
.A1(n_68),
.A2(n_52),
.B(n_54),
.Y(n_73)
);

BUFx6f_ASAP7_75t_L g74 ( 
.A(n_65),
.Y(n_74)
);

AOI22xp33_ASAP7_75t_L g75 ( 
.A1(n_61),
.A2(n_56),
.B1(n_51),
.B2(n_34),
.Y(n_75)
);

OAI21x1_ASAP7_75t_L g76 ( 
.A1(n_71),
.A2(n_64),
.B(n_69),
.Y(n_76)
);

OA21x2_ASAP7_75t_L g77 ( 
.A1(n_70),
.A2(n_54),
.B(n_49),
.Y(n_77)
);

INVx2_ASAP7_75t_L g78 ( 
.A(n_70),
.Y(n_78)
);

OA21x2_ASAP7_75t_L g79 ( 
.A1(n_60),
.A2(n_49),
.B(n_54),
.Y(n_79)
);

NOR2xp67_ASAP7_75t_SL g80 ( 
.A(n_65),
.B(n_58),
.Y(n_80)
);

O2A1O1Ixp33_ASAP7_75t_SL g81 ( 
.A1(n_67),
.A2(n_62),
.B(n_34),
.C(n_41),
.Y(n_81)
);

CKINVDCx5p33_ASAP7_75t_R g82 ( 
.A(n_63),
.Y(n_82)
);

CKINVDCx20_ASAP7_75t_R g83 ( 
.A(n_82),
.Y(n_83)
);

BUFx6f_ASAP7_75t_L g84 ( 
.A(n_74),
.Y(n_84)
);

INVx2_ASAP7_75t_L g85 ( 
.A(n_72),
.Y(n_85)
);

CKINVDCx5p33_ASAP7_75t_R g86 ( 
.A(n_82),
.Y(n_86)
);

AO31x2_ASAP7_75t_L g87 ( 
.A1(n_73),
.A2(n_61),
.A3(n_55),
.B(n_53),
.Y(n_87)
);

OAI22xp33_ASAP7_75t_L g88 ( 
.A1(n_74),
.A2(n_63),
.B1(n_65),
.B2(n_71),
.Y(n_88)
);

BUFx3_ASAP7_75t_L g89 ( 
.A(n_74),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_85),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_85),
.Y(n_91)
);

OAI211xp5_ASAP7_75t_L g92 ( 
.A1(n_86),
.A2(n_75),
.B(n_81),
.C(n_59),
.Y(n_92)
);

OAI22xp33_ASAP7_75t_L g93 ( 
.A1(n_88),
.A2(n_46),
.B1(n_57),
.B2(n_59),
.Y(n_93)
);

OAI21x1_ASAP7_75t_L g94 ( 
.A1(n_85),
.A2(n_76),
.B(n_73),
.Y(n_94)
);

A2O1A1Ixp33_ASAP7_75t_L g95 ( 
.A1(n_89),
.A2(n_66),
.B(n_75),
.C(n_76),
.Y(n_95)
);

OAI21x1_ASAP7_75t_SL g96 ( 
.A1(n_84),
.A2(n_79),
.B(n_77),
.Y(n_96)
);

AND2x2_ASAP7_75t_L g97 ( 
.A(n_90),
.B(n_87),
.Y(n_97)
);

AND2x2_ASAP7_75t_L g98 ( 
.A(n_90),
.B(n_87),
.Y(n_98)
);

AND2x2_ASAP7_75t_L g99 ( 
.A(n_91),
.B(n_87),
.Y(n_99)
);

INVxp67_ASAP7_75t_SL g100 ( 
.A(n_91),
.Y(n_100)
);

AND2x2_ASAP7_75t_L g101 ( 
.A(n_92),
.B(n_87),
.Y(n_101)
);

AND2x2_ASAP7_75t_L g102 ( 
.A(n_95),
.B(n_87),
.Y(n_102)
);

HB1xp67_ASAP7_75t_L g103 ( 
.A(n_94),
.Y(n_103)
);

OR2x2_ASAP7_75t_L g104 ( 
.A(n_93),
.B(n_87),
.Y(n_104)
);

INVx2_ASAP7_75t_L g105 ( 
.A(n_94),
.Y(n_105)
);

BUFx3_ASAP7_75t_L g106 ( 
.A(n_96),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_97),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_97),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_100),
.Y(n_109)
);

HB1xp67_ASAP7_75t_L g110 ( 
.A(n_98),
.Y(n_110)
);

AND2x2_ASAP7_75t_L g111 ( 
.A(n_98),
.B(n_87),
.Y(n_111)
);

OR2x2_ASAP7_75t_L g112 ( 
.A(n_99),
.B(n_87),
.Y(n_112)
);

INVxp67_ASAP7_75t_L g113 ( 
.A(n_99),
.Y(n_113)
);

AND2x2_ASAP7_75t_L g114 ( 
.A(n_101),
.B(n_79),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_103),
.Y(n_115)
);

NOR2xp33_ASAP7_75t_L g116 ( 
.A(n_106),
.B(n_83),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_105),
.Y(n_117)
);

AND2x2_ASAP7_75t_L g118 ( 
.A(n_101),
.B(n_79),
.Y(n_118)
);

NAND2xp5_ASAP7_75t_L g119 ( 
.A(n_100),
.B(n_56),
.Y(n_119)
);

OR2x2_ASAP7_75t_L g120 ( 
.A(n_104),
.B(n_79),
.Y(n_120)
);

INVx1_ASAP7_75t_L g121 ( 
.A(n_105),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_105),
.Y(n_122)
);

AOI22xp33_ASAP7_75t_L g123 ( 
.A1(n_104),
.A2(n_56),
.B1(n_88),
.B2(n_83),
.Y(n_123)
);

AOI22xp33_ASAP7_75t_L g124 ( 
.A1(n_102),
.A2(n_56),
.B1(n_79),
.B2(n_42),
.Y(n_124)
);

NAND2xp5_ASAP7_75t_L g125 ( 
.A(n_119),
.B(n_102),
.Y(n_125)
);

OR2x2_ASAP7_75t_L g126 ( 
.A(n_107),
.B(n_106),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_109),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_113),
.B(n_81),
.Y(n_128)
);

NOR2x1_ASAP7_75t_L g129 ( 
.A(n_116),
.B(n_106),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_115),
.Y(n_130)
);

NOR3xp33_ASAP7_75t_L g131 ( 
.A(n_115),
.B(n_51),
.C(n_55),
.Y(n_131)
);

NAND2xp5_ASAP7_75t_L g132 ( 
.A(n_107),
.B(n_108),
.Y(n_132)
);

OA21x2_ASAP7_75t_L g133 ( 
.A1(n_117),
.A2(n_96),
.B(n_76),
.Y(n_133)
);

AND2x2_ASAP7_75t_L g134 ( 
.A(n_111),
.B(n_79),
.Y(n_134)
);

AOI21xp33_ASAP7_75t_L g135 ( 
.A1(n_124),
.A2(n_76),
.B(n_77),
.Y(n_135)
);

AOI22xp5_ASAP7_75t_L g136 ( 
.A1(n_123),
.A2(n_42),
.B1(n_51),
.B2(n_58),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_110),
.Y(n_137)
);

OAI22xp5_ASAP7_75t_SL g138 ( 
.A1(n_108),
.A2(n_37),
.B1(n_51),
.B2(n_6),
.Y(n_138)
);

OR2x2_ASAP7_75t_L g139 ( 
.A(n_112),
.B(n_77),
.Y(n_139)
);

INVx2_ASAP7_75t_L g140 ( 
.A(n_117),
.Y(n_140)
);

AND2x2_ASAP7_75t_L g141 ( 
.A(n_111),
.B(n_77),
.Y(n_141)
);

INVxp67_ASAP7_75t_L g142 ( 
.A(n_118),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_121),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_121),
.Y(n_144)
);

A2O1A1Ixp33_ASAP7_75t_L g145 ( 
.A1(n_120),
.A2(n_80),
.B(n_114),
.C(n_118),
.Y(n_145)
);

OAI22xp33_ASAP7_75t_SL g146 ( 
.A1(n_112),
.A2(n_71),
.B1(n_16),
.B2(n_15),
.Y(n_146)
);

INVx5_ASAP7_75t_L g147 ( 
.A(n_114),
.Y(n_147)
);

BUFx2_ASAP7_75t_SL g148 ( 
.A(n_122),
.Y(n_148)
);

AOI22xp33_ASAP7_75t_SL g149 ( 
.A1(n_120),
.A2(n_37),
.B1(n_84),
.B2(n_58),
.Y(n_149)
);

NAND2xp5_ASAP7_75t_L g150 ( 
.A(n_122),
.B(n_77),
.Y(n_150)
);

NAND2xp5_ASAP7_75t_L g151 ( 
.A(n_137),
.B(n_16),
.Y(n_151)
);

INVxp67_ASAP7_75t_SL g152 ( 
.A(n_130),
.Y(n_152)
);

INVx2_ASAP7_75t_L g153 ( 
.A(n_140),
.Y(n_153)
);

AND2x2_ASAP7_75t_L g154 ( 
.A(n_147),
.B(n_17),
.Y(n_154)
);

NAND2xp5_ASAP7_75t_L g155 ( 
.A(n_125),
.B(n_18),
.Y(n_155)
);

NOR2xp33_ASAP7_75t_L g156 ( 
.A(n_129),
.B(n_18),
.Y(n_156)
);

INVxp67_ASAP7_75t_L g157 ( 
.A(n_132),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_127),
.Y(n_158)
);

OR2x2_ASAP7_75t_L g159 ( 
.A(n_142),
.B(n_19),
.Y(n_159)
);

NAND2xp5_ASAP7_75t_L g160 ( 
.A(n_128),
.B(n_19),
.Y(n_160)
);

INVx2_ASAP7_75t_L g161 ( 
.A(n_140),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_143),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_144),
.Y(n_163)
);

NOR2x1_ASAP7_75t_L g164 ( 
.A(n_148),
.B(n_89),
.Y(n_164)
);

NAND2xp5_ASAP7_75t_L g165 ( 
.A(n_134),
.B(n_141),
.Y(n_165)
);

NAND2xp5_ASAP7_75t_SL g166 ( 
.A(n_146),
.B(n_84),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_L g167 ( 
.A(n_134),
.B(n_20),
.Y(n_167)
);

CKINVDCx20_ASAP7_75t_R g168 ( 
.A(n_138),
.Y(n_168)
);

NAND2xp5_ASAP7_75t_L g169 ( 
.A(n_141),
.B(n_21),
.Y(n_169)
);

INVx1_ASAP7_75t_L g170 ( 
.A(n_126),
.Y(n_170)
);

NAND4xp25_ASAP7_75t_L g171 ( 
.A(n_136),
.B(n_23),
.C(n_22),
.D(n_21),
.Y(n_171)
);

INVxp67_ASAP7_75t_L g172 ( 
.A(n_126),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_133),
.Y(n_173)
);

OR2x2_ASAP7_75t_L g174 ( 
.A(n_139),
.B(n_145),
.Y(n_174)
);

NAND2xp33_ASAP7_75t_SL g175 ( 
.A(n_139),
.B(n_84),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_150),
.Y(n_176)
);

AND2x2_ASAP7_75t_L g177 ( 
.A(n_147),
.B(n_22),
.Y(n_177)
);

INVx1_ASAP7_75t_SL g178 ( 
.A(n_147),
.Y(n_178)
);

AOI221xp5_ASAP7_75t_L g179 ( 
.A1(n_168),
.A2(n_145),
.B1(n_131),
.B2(n_135),
.C(n_149),
.Y(n_179)
);

NAND2xp5_ASAP7_75t_L g180 ( 
.A(n_157),
.B(n_147),
.Y(n_180)
);

OAI221xp5_ASAP7_75t_L g181 ( 
.A1(n_171),
.A2(n_160),
.B1(n_156),
.B2(n_166),
.C(n_155),
.Y(n_181)
);

OAI21xp5_ASAP7_75t_L g182 ( 
.A1(n_168),
.A2(n_133),
.B(n_77),
.Y(n_182)
);

NOR3xp33_ASAP7_75t_L g183 ( 
.A(n_167),
.B(n_78),
.C(n_72),
.Y(n_183)
);

OAI222xp33_ASAP7_75t_L g184 ( 
.A1(n_169),
.A2(n_80),
.B1(n_25),
.B2(n_23),
.C1(n_26),
.C2(n_24),
.Y(n_184)
);

NAND4xp25_ASAP7_75t_SL g185 ( 
.A(n_174),
.B(n_177),
.C(n_154),
.D(n_151),
.Y(n_185)
);

AOI211xp5_ASAP7_75t_L g186 ( 
.A1(n_154),
.A2(n_26),
.B(n_25),
.C(n_24),
.Y(n_186)
);

NOR4xp25_ASAP7_75t_L g187 ( 
.A(n_159),
.B(n_29),
.C(n_28),
.D(n_27),
.Y(n_187)
);

AOI21xp5_ASAP7_75t_L g188 ( 
.A1(n_175),
.A2(n_133),
.B(n_84),
.Y(n_188)
);

AND2x4_ASAP7_75t_L g189 ( 
.A(n_170),
.B(n_89),
.Y(n_189)
);

NAND2xp5_ASAP7_75t_L g190 ( 
.A(n_170),
.B(n_28),
.Y(n_190)
);

NOR4xp25_ASAP7_75t_L g191 ( 
.A(n_159),
.B(n_158),
.C(n_177),
.D(n_162),
.Y(n_191)
);

AOI221x1_ASAP7_75t_L g192 ( 
.A1(n_176),
.A2(n_163),
.B1(n_175),
.B2(n_173),
.C(n_153),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_163),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_152),
.Y(n_194)
);

OAI22xp5_ASAP7_75t_L g195 ( 
.A1(n_174),
.A2(n_84),
.B1(n_77),
.B2(n_74),
.Y(n_195)
);

OAI21xp5_ASAP7_75t_L g196 ( 
.A1(n_164),
.A2(n_80),
.B(n_58),
.Y(n_196)
);

OAI22xp5_ASAP7_75t_L g197 ( 
.A1(n_165),
.A2(n_172),
.B1(n_178),
.B2(n_153),
.Y(n_197)
);

NAND4xp75_ASAP7_75t_L g198 ( 
.A(n_173),
.B(n_66),
.C(n_30),
.D(n_72),
.Y(n_198)
);

INVx1_ASAP7_75t_L g199 ( 
.A(n_161),
.Y(n_199)
);

NAND3xp33_ASAP7_75t_SL g200 ( 
.A(n_161),
.B(n_30),
.C(n_72),
.Y(n_200)
);

AOI21xp33_ASAP7_75t_SL g201 ( 
.A1(n_160),
.A2(n_1),
.B(n_0),
.Y(n_201)
);

INVxp67_ASAP7_75t_L g202 ( 
.A(n_190),
.Y(n_202)
);

AND2x2_ASAP7_75t_L g203 ( 
.A(n_197),
.B(n_84),
.Y(n_203)
);

AND2x2_ASAP7_75t_L g204 ( 
.A(n_180),
.B(n_84),
.Y(n_204)
);

AND2x2_ASAP7_75t_L g205 ( 
.A(n_199),
.B(n_194),
.Y(n_205)
);

AOI222xp33_ASAP7_75t_L g206 ( 
.A1(n_181),
.A2(n_184),
.B1(n_200),
.B2(n_179),
.C1(n_182),
.C2(n_187),
.Y(n_206)
);

NAND3xp33_ASAP7_75t_L g207 ( 
.A(n_186),
.B(n_78),
.C(n_74),
.Y(n_207)
);

NAND2xp5_ASAP7_75t_L g208 ( 
.A(n_193),
.B(n_78),
.Y(n_208)
);

AOI21xp5_ASAP7_75t_L g209 ( 
.A1(n_200),
.A2(n_188),
.B(n_196),
.Y(n_209)
);

OAI211xp5_ASAP7_75t_L g210 ( 
.A1(n_191),
.A2(n_192),
.B(n_188),
.C(n_201),
.Y(n_210)
);

OAI22xp33_ASAP7_75t_SL g211 ( 
.A1(n_185),
.A2(n_58),
.B1(n_78),
.B2(n_2),
.Y(n_211)
);

NAND2xp5_ASAP7_75t_L g212 ( 
.A(n_195),
.B(n_74),
.Y(n_212)
);

NAND3x1_ASAP7_75t_L g213 ( 
.A(n_183),
.B(n_12),
.C(n_4),
.Y(n_213)
);

NAND2xp5_ASAP7_75t_L g214 ( 
.A(n_189),
.B(n_74),
.Y(n_214)
);

NAND2xp5_ASAP7_75t_L g215 ( 
.A(n_189),
.B(n_74),
.Y(n_215)
);

NOR4xp25_ASAP7_75t_L g216 ( 
.A(n_210),
.B(n_198),
.C(n_14),
.D(n_13),
.Y(n_216)
);

CKINVDCx5p33_ASAP7_75t_R g217 ( 
.A(n_202),
.Y(n_217)
);

BUFx2_ASAP7_75t_L g218 ( 
.A(n_204),
.Y(n_218)
);

HB1xp67_ASAP7_75t_L g219 ( 
.A(n_205),
.Y(n_219)
);

HB1xp67_ASAP7_75t_L g220 ( 
.A(n_203),
.Y(n_220)
);

CKINVDCx16_ASAP7_75t_R g221 ( 
.A(n_214),
.Y(n_221)
);

CKINVDCx5p33_ASAP7_75t_R g222 ( 
.A(n_215),
.Y(n_222)
);

NOR3xp33_ASAP7_75t_L g223 ( 
.A(n_221),
.B(n_211),
.C(n_207),
.Y(n_223)
);

INVx3_ASAP7_75t_L g224 ( 
.A(n_218),
.Y(n_224)
);

AOI22xp5_ASAP7_75t_L g225 ( 
.A1(n_216),
.A2(n_206),
.B1(n_209),
.B2(n_213),
.Y(n_225)
);

AOI31xp33_ASAP7_75t_L g226 ( 
.A1(n_217),
.A2(n_212),
.A3(n_208),
.B(n_74),
.Y(n_226)
);

HB1xp67_ASAP7_75t_L g227 ( 
.A(n_224),
.Y(n_227)
);

OAI22xp5_ASAP7_75t_L g228 ( 
.A1(n_225),
.A2(n_221),
.B1(n_220),
.B2(n_218),
.Y(n_228)
);

OAI211xp5_ASAP7_75t_L g229 ( 
.A1(n_228),
.A2(n_216),
.B(n_223),
.C(n_212),
.Y(n_229)
);

AOI22xp33_ASAP7_75t_SL g230 ( 
.A1(n_229),
.A2(n_227),
.B1(n_222),
.B2(n_219),
.Y(n_230)
);

AOI22xp5_ASAP7_75t_L g231 ( 
.A1(n_230),
.A2(n_208),
.B1(n_226),
.B2(n_65),
.Y(n_231)
);


endmodule