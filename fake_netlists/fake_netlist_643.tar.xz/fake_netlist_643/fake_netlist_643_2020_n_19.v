module fake_netlist_643_2020_n_19 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_19);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_19;

wire n_18;
wire n_10;
wire n_11;
wire n_15;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;

INVx4_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI21x1_ASAP7_75t_L g10 ( 
.A1(n_0),
.A2(n_6),
.B(n_2),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVxp33_ASAP7_75t_SL g12 ( 
.A(n_5),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.B(n_4),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_11),
.C(n_9),
.Y(n_14)
);

NOR2x1_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_9),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_4),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_7),
.Y(n_17)
);

XOR2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_1),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_10),
.B(n_3),
.Y(n_19)
);


endmodule