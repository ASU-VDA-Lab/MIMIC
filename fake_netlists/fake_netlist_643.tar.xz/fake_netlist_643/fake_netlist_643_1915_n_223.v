module fake_netlist_643_1915_n_223 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_28, n_11, n_15, n_7, n_30, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_27, n_2, n_29, n_31, n_26, n_9, n_32, n_13, n_8, n_6, n_223);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_28;
input n_11;
input n_15;
input n_7;
input n_30;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_27;
input n_2;
input n_29;
input n_31;
input n_26;
input n_9;
input n_32;
input n_13;
input n_8;
input n_6;

output n_223;

wire n_168;
wire n_99;
wire n_62;
wire n_70;
wire n_90;
wire n_101;
wire n_58;
wire n_38;
wire n_144;
wire n_155;
wire n_166;
wire n_139;
wire n_57;
wire n_84;
wire n_214;
wire n_35;
wire n_89;
wire n_209;
wire n_152;
wire n_116;
wire n_96;
wire n_172;
wire n_45;
wire n_107;
wire n_220;
wire n_218;
wire n_78;
wire n_191;
wire n_66;
wire n_164;
wire n_154;
wire n_118;
wire n_60;
wire n_137;
wire n_39;
wire n_189;
wire n_197;
wire n_173;
wire n_183;
wire n_63;
wire n_190;
wire n_211;
wire n_206;
wire n_177;
wire n_192;
wire n_194;
wire n_184;
wire n_187;
wire n_81;
wire n_37;
wire n_71;
wire n_124;
wire n_163;
wire n_91;
wire n_165;
wire n_121;
wire n_157;
wire n_201;
wire n_105;
wire n_92;
wire n_125;
wire n_117;
wire n_136;
wire n_40;
wire n_217;
wire n_110;
wire n_170;
wire n_49;
wire n_207;
wire n_151;
wire n_53;
wire n_161;
wire n_77;
wire n_75;
wire n_48;
wire n_180;
wire n_142;
wire n_93;
wire n_199;
wire n_203;
wire n_181;
wire n_41;
wire n_143;
wire n_213;
wire n_65;
wire n_109;
wire n_33;
wire n_208;
wire n_122;
wire n_219;
wire n_119;
wire n_149;
wire n_43;
wire n_182;
wire n_82;
wire n_204;
wire n_120;
wire n_85;
wire n_61;
wire n_176;
wire n_72;
wire n_51;
wire n_160;
wire n_54;
wire n_86;
wire n_156;
wire n_68;
wire n_198;
wire n_130;
wire n_210;
wire n_140;
wire n_174;
wire n_202;
wire n_167;
wire n_175;
wire n_195;
wire n_67;
wire n_112;
wire n_179;
wire n_52;
wire n_50;
wire n_113;
wire n_169;
wire n_104;
wire n_103;
wire n_127;
wire n_162;
wire n_100;
wire n_150;
wire n_129;
wire n_146;
wire n_83;
wire n_76;
wire n_134;
wire n_200;
wire n_196;
wire n_106;
wire n_133;
wire n_36;
wire n_59;
wire n_97;
wire n_34;
wire n_131;
wire n_64;
wire n_148;
wire n_44;
wire n_159;
wire n_123;
wire n_141;
wire n_87;
wire n_115;
wire n_145;
wire n_79;
wire n_215;
wire n_128;
wire n_205;
wire n_108;
wire n_126;
wire n_185;
wire n_73;
wire n_132;
wire n_56;
wire n_98;
wire n_69;
wire n_147;
wire n_171;
wire n_94;
wire n_212;
wire n_221;
wire n_222;
wire n_193;
wire n_138;
wire n_46;
wire n_153;
wire n_42;
wire n_158;
wire n_216;
wire n_55;
wire n_102;
wire n_135;
wire n_95;
wire n_178;
wire n_74;
wire n_186;
wire n_47;
wire n_188;
wire n_80;
wire n_88;
wire n_114;
wire n_111;

INVx1_ASAP7_75t_L g33 ( 
.A(n_19),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_5),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_10),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_30),
.Y(n_38)
);

INVxp33_ASAP7_75t_SL g39 ( 
.A(n_20),
.Y(n_39)
);

INVx3_ASAP7_75t_L g40 ( 
.A(n_15),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_8),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_27),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_18),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_20),
.Y(n_44)
);

INVxp33_ASAP7_75t_SL g45 ( 
.A(n_26),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_3),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_40),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_41),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_37),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_40),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_46),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_39),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_47),
.B(n_40),
.Y(n_53)
);

NAND3x1_ASAP7_75t_L g54 ( 
.A(n_47),
.B(n_40),
.C(n_35),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_40),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_47),
.Y(n_56)
);

BUFx6f_ASAP7_75t_L g57 ( 
.A(n_49),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_47),
.Y(n_58)
);

BUFx6f_ASAP7_75t_L g59 ( 
.A(n_49),
.Y(n_59)
);

CKINVDCx20_ASAP7_75t_R g60 ( 
.A(n_48),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_53),
.B(n_50),
.Y(n_61)
);

AOI22xp5_ASAP7_75t_L g62 ( 
.A1(n_54),
.A2(n_52),
.B1(n_45),
.B2(n_39),
.Y(n_62)
);

NOR2xp33_ASAP7_75t_R g63 ( 
.A(n_60),
.B(n_48),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_53),
.B(n_50),
.Y(n_64)
);

AO32x1_ASAP7_75t_L g65 ( 
.A1(n_53),
.A2(n_49),
.A3(n_43),
.B1(n_35),
.B2(n_36),
.Y(n_65)
);

NOR2xp33_ASAP7_75t_L g66 ( 
.A(n_56),
.B(n_51),
.Y(n_66)
);

INVx2_ASAP7_75t_L g67 ( 
.A(n_57),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_57),
.Y(n_68)
);

A2O1A1Ixp33_ASAP7_75t_L g69 ( 
.A1(n_56),
.A2(n_49),
.B(n_36),
.C(n_35),
.Y(n_69)
);

A2O1A1Ixp33_ASAP7_75t_L g70 ( 
.A1(n_58),
.A2(n_49),
.B(n_43),
.C(n_36),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_58),
.B(n_51),
.Y(n_71)
);

OAI22xp33_ASAP7_75t_L g72 ( 
.A1(n_62),
.A2(n_44),
.B1(n_43),
.B2(n_33),
.Y(n_72)
);

AOI21x1_ASAP7_75t_L g73 ( 
.A1(n_64),
.A2(n_55),
.B(n_58),
.Y(n_73)
);

INVx2_ASAP7_75t_L g74 ( 
.A(n_67),
.Y(n_74)
);

INVx2_ASAP7_75t_L g75 ( 
.A(n_68),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_61),
.B(n_57),
.Y(n_76)
);

OAI21x1_ASAP7_75t_L g77 ( 
.A1(n_71),
.A2(n_54),
.B(n_55),
.Y(n_77)
);

INVxp67_ASAP7_75t_L g78 ( 
.A(n_66),
.Y(n_78)
);

OR2x2_ASAP7_75t_L g79 ( 
.A(n_66),
.B(n_52),
.Y(n_79)
);

OAI21x1_ASAP7_75t_L g80 ( 
.A1(n_65),
.A2(n_54),
.B(n_37),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_70),
.B(n_57),
.Y(n_81)
);

NOR3xp33_ASAP7_75t_SL g82 ( 
.A(n_72),
.B(n_69),
.C(n_44),
.Y(n_82)
);

CKINVDCx16_ASAP7_75t_R g83 ( 
.A(n_79),
.Y(n_83)
);

CKINVDCx5p33_ASAP7_75t_R g84 ( 
.A(n_78),
.Y(n_84)
);

BUFx3_ASAP7_75t_L g85 ( 
.A(n_77),
.Y(n_85)
);

INVx2_ASAP7_75t_L g86 ( 
.A(n_74),
.Y(n_86)
);

OR2x2_ASAP7_75t_L g87 ( 
.A(n_79),
.B(n_44),
.Y(n_87)
);

NOR2xp33_ASAP7_75t_L g88 ( 
.A(n_78),
.B(n_45),
.Y(n_88)
);

AND2x2_ASAP7_75t_L g89 ( 
.A(n_77),
.B(n_80),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_86),
.Y(n_90)
);

A2O1A1Ixp33_ASAP7_75t_L g91 ( 
.A1(n_88),
.A2(n_79),
.B(n_77),
.C(n_81),
.Y(n_91)
);

CKINVDCx20_ASAP7_75t_R g92 ( 
.A(n_83),
.Y(n_92)
);

AOI22xp33_ASAP7_75t_L g93 ( 
.A1(n_88),
.A2(n_72),
.B1(n_84),
.B2(n_87),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_86),
.Y(n_94)
);

OAI211xp5_ASAP7_75t_L g95 ( 
.A1(n_87),
.A2(n_63),
.B(n_42),
.C(n_60),
.Y(n_95)
);

AND2x2_ASAP7_75t_L g96 ( 
.A(n_87),
.B(n_76),
.Y(n_96)
);

NOR4xp25_ASAP7_75t_SL g97 ( 
.A(n_91),
.B(n_84),
.C(n_34),
.D(n_33),
.Y(n_97)
);

AND2x2_ASAP7_75t_L g98 ( 
.A(n_96),
.B(n_83),
.Y(n_98)
);

NAND2x1_ASAP7_75t_SL g99 ( 
.A(n_96),
.B(n_89),
.Y(n_99)
);

NOR2xp67_ASAP7_75t_L g100 ( 
.A(n_90),
.B(n_86),
.Y(n_100)
);

OR2x2_ASAP7_75t_L g101 ( 
.A(n_93),
.B(n_83),
.Y(n_101)
);

INVx2_ASAP7_75t_L g102 ( 
.A(n_90),
.Y(n_102)
);

NOR2xp33_ASAP7_75t_L g103 ( 
.A(n_95),
.B(n_87),
.Y(n_103)
);

NAND2xp5_ASAP7_75t_L g104 ( 
.A(n_90),
.B(n_94),
.Y(n_104)
);

INVxp67_ASAP7_75t_L g105 ( 
.A(n_98),
.Y(n_105)
);

NAND2xp5_ASAP7_75t_L g106 ( 
.A(n_104),
.B(n_94),
.Y(n_106)
);

NAND3xp33_ASAP7_75t_L g107 ( 
.A(n_103),
.B(n_82),
.C(n_34),
.Y(n_107)
);

AND2x2_ASAP7_75t_L g108 ( 
.A(n_102),
.B(n_89),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_102),
.Y(n_109)
);

INVx1_ASAP7_75t_SL g110 ( 
.A(n_98),
.Y(n_110)
);

AND2x4_ASAP7_75t_L g111 ( 
.A(n_102),
.B(n_94),
.Y(n_111)
);

INVx2_ASAP7_75t_L g112 ( 
.A(n_104),
.Y(n_112)
);

INVx2_ASAP7_75t_L g113 ( 
.A(n_99),
.Y(n_113)
);

INVx2_ASAP7_75t_SL g114 ( 
.A(n_99),
.Y(n_114)
);

INVx2_ASAP7_75t_L g115 ( 
.A(n_101),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_100),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_101),
.Y(n_117)
);

AND2x2_ASAP7_75t_L g118 ( 
.A(n_97),
.B(n_89),
.Y(n_118)
);

AOI21xp5_ASAP7_75t_L g119 ( 
.A1(n_107),
.A2(n_97),
.B(n_100),
.Y(n_119)
);

INVx1_ASAP7_75t_L g120 ( 
.A(n_109),
.Y(n_120)
);

AOI21xp5_ASAP7_75t_L g121 ( 
.A1(n_107),
.A2(n_106),
.B(n_116),
.Y(n_121)
);

INVx2_ASAP7_75t_L g122 ( 
.A(n_109),
.Y(n_122)
);

OAI221xp5_ASAP7_75t_L g123 ( 
.A1(n_105),
.A2(n_82),
.B1(n_38),
.B2(n_37),
.C(n_81),
.Y(n_123)
);

AOI22xp33_ASAP7_75t_L g124 ( 
.A1(n_117),
.A2(n_115),
.B1(n_110),
.B2(n_105),
.Y(n_124)
);

AOI221xp5_ASAP7_75t_L g125 ( 
.A1(n_118),
.A2(n_42),
.B1(n_82),
.B2(n_38),
.C(n_63),
.Y(n_125)
);

NAND2xp5_ASAP7_75t_L g126 ( 
.A(n_110),
.B(n_92),
.Y(n_126)
);

OAI221xp5_ASAP7_75t_L g127 ( 
.A1(n_114),
.A2(n_38),
.B1(n_85),
.B2(n_76),
.C(n_74),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_108),
.B(n_112),
.Y(n_128)
);

INVx1_ASAP7_75t_L g129 ( 
.A(n_108),
.Y(n_129)
);

NAND2xp5_ASAP7_75t_L g130 ( 
.A(n_108),
.B(n_89),
.Y(n_130)
);

INVx1_ASAP7_75t_L g131 ( 
.A(n_112),
.Y(n_131)
);

INVx1_ASAP7_75t_L g132 ( 
.A(n_112),
.Y(n_132)
);

NOR4xp25_ASAP7_75t_L g133 ( 
.A(n_118),
.B(n_86),
.C(n_65),
.D(n_0),
.Y(n_133)
);

INVx3_ASAP7_75t_L g134 ( 
.A(n_113),
.Y(n_134)
);

AOI222xp33_ASAP7_75t_L g135 ( 
.A1(n_115),
.A2(n_80),
.B1(n_2),
.B2(n_0),
.C1(n_3),
.C2(n_1),
.Y(n_135)
);

INVx1_ASAP7_75t_L g136 ( 
.A(n_113),
.Y(n_136)
);

OAI21xp33_ASAP7_75t_L g137 ( 
.A1(n_118),
.A2(n_115),
.B(n_117),
.Y(n_137)
);

INVx2_ASAP7_75t_L g138 ( 
.A(n_111),
.Y(n_138)
);

AOI221xp5_ASAP7_75t_L g139 ( 
.A1(n_115),
.A2(n_85),
.B1(n_59),
.B2(n_57),
.C(n_74),
.Y(n_139)
);

NOR2xp33_ASAP7_75t_L g140 ( 
.A(n_126),
.B(n_1),
.Y(n_140)
);

NAND2xp5_ASAP7_75t_L g141 ( 
.A(n_129),
.B(n_117),
.Y(n_141)
);

NAND2xp5_ASAP7_75t_L g142 ( 
.A(n_129),
.B(n_111),
.Y(n_142)
);

AND2x2_ASAP7_75t_L g143 ( 
.A(n_138),
.B(n_113),
.Y(n_143)
);

NOR2xp33_ASAP7_75t_R g144 ( 
.A(n_134),
.B(n_114),
.Y(n_144)
);

NAND2xp5_ASAP7_75t_L g145 ( 
.A(n_128),
.B(n_111),
.Y(n_145)
);

INVx1_ASAP7_75t_L g146 ( 
.A(n_120),
.Y(n_146)
);

NAND2xp5_ASAP7_75t_L g147 ( 
.A(n_121),
.B(n_131),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_120),
.Y(n_148)
);

OAI22x1_ASAP7_75t_L g149 ( 
.A1(n_136),
.A2(n_114),
.B1(n_116),
.B2(n_111),
.Y(n_149)
);

INVx2_ASAP7_75t_L g150 ( 
.A(n_122),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_122),
.Y(n_151)
);

NAND2xp5_ASAP7_75t_L g152 ( 
.A(n_131),
.B(n_111),
.Y(n_152)
);

OAI221xp5_ASAP7_75t_SL g153 ( 
.A1(n_125),
.A2(n_135),
.B1(n_123),
.B2(n_137),
.C(n_133),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_136),
.Y(n_154)
);

INVx1_ASAP7_75t_L g155 ( 
.A(n_132),
.Y(n_155)
);

OAI21xp33_ASAP7_75t_SL g156 ( 
.A1(n_135),
.A2(n_80),
.B(n_106),
.Y(n_156)
);

HB1xp67_ASAP7_75t_L g157 ( 
.A(n_132),
.Y(n_157)
);

OR2x2_ASAP7_75t_L g158 ( 
.A(n_138),
.B(n_137),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_134),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_134),
.Y(n_160)
);

NAND2xp5_ASAP7_75t_L g161 ( 
.A(n_130),
.B(n_85),
.Y(n_161)
);

NOR2x1p5_ASAP7_75t_L g162 ( 
.A(n_124),
.B(n_85),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_133),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_119),
.Y(n_164)
);

OR2x2_ASAP7_75t_L g165 ( 
.A(n_127),
.B(n_85),
.Y(n_165)
);

OAI211xp5_ASAP7_75t_L g166 ( 
.A1(n_156),
.A2(n_139),
.B(n_4),
.C(n_2),
.Y(n_166)
);

OAI211xp5_ASAP7_75t_SL g167 ( 
.A1(n_163),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_167)
);

INVxp67_ASAP7_75t_L g168 ( 
.A(n_140),
.Y(n_168)
);

NAND3xp33_ASAP7_75t_SL g169 ( 
.A(n_163),
.B(n_7),
.C(n_6),
.Y(n_169)
);

AOI31xp33_ASAP7_75t_L g170 ( 
.A1(n_164),
.A2(n_9),
.A3(n_8),
.B(n_7),
.Y(n_170)
);

INVx1_ASAP7_75t_L g171 ( 
.A(n_146),
.Y(n_171)
);

NOR2xp33_ASAP7_75t_L g172 ( 
.A(n_146),
.B(n_9),
.Y(n_172)
);

AND2x2_ASAP7_75t_L g173 ( 
.A(n_143),
.B(n_10),
.Y(n_173)
);

AOI222xp33_ASAP7_75t_L g174 ( 
.A1(n_164),
.A2(n_12),
.B1(n_11),
.B2(n_13),
.C1(n_15),
.C2(n_14),
.Y(n_174)
);

NOR2xp33_ASAP7_75t_R g175 ( 
.A(n_142),
.B(n_11),
.Y(n_175)
);

AOI211xp5_ASAP7_75t_L g176 ( 
.A1(n_153),
.A2(n_14),
.B(n_13),
.C(n_12),
.Y(n_176)
);

OAI21xp5_ASAP7_75t_SL g177 ( 
.A1(n_147),
.A2(n_17),
.B(n_16),
.Y(n_177)
);

AND3x2_ASAP7_75t_L g178 ( 
.A(n_157),
.B(n_86),
.C(n_74),
.Y(n_178)
);

NAND2x2_ASAP7_75t_L g179 ( 
.A(n_162),
.B(n_73),
.Y(n_179)
);

AOI211xp5_ASAP7_75t_L g180 ( 
.A1(n_154),
.A2(n_18),
.B(n_17),
.C(n_16),
.Y(n_180)
);

AOI222xp33_ASAP7_75t_L g181 ( 
.A1(n_161),
.A2(n_21),
.B1(n_19),
.B2(n_22),
.C1(n_24),
.C2(n_23),
.Y(n_181)
);

AOI221xp5_ASAP7_75t_L g182 ( 
.A1(n_148),
.A2(n_23),
.B1(n_22),
.B2(n_24),
.C(n_25),
.Y(n_182)
);

AOI221xp5_ASAP7_75t_L g183 ( 
.A1(n_148),
.A2(n_27),
.B1(n_26),
.B2(n_25),
.C(n_57),
.Y(n_183)
);

NOR4xp25_ASAP7_75t_L g184 ( 
.A(n_154),
.B(n_65),
.C(n_75),
.D(n_29),
.Y(n_184)
);

NOR2xp33_ASAP7_75t_R g185 ( 
.A(n_165),
.B(n_73),
.Y(n_185)
);

INVxp67_ASAP7_75t_SL g186 ( 
.A(n_159),
.Y(n_186)
);

NAND2xp5_ASAP7_75t_SL g187 ( 
.A(n_144),
.B(n_75),
.Y(n_187)
);

AOI21xp5_ASAP7_75t_L g188 ( 
.A1(n_165),
.A2(n_65),
.B(n_75),
.Y(n_188)
);

OAI221xp5_ASAP7_75t_L g189 ( 
.A1(n_159),
.A2(n_75),
.B1(n_73),
.B2(n_57),
.C(n_59),
.Y(n_189)
);

NAND3xp33_ASAP7_75t_SL g190 ( 
.A(n_176),
.B(n_155),
.C(n_158),
.Y(n_190)
);

INVxp67_ASAP7_75t_L g191 ( 
.A(n_172),
.Y(n_191)
);

A2O1A1Ixp33_ASAP7_75t_L g192 ( 
.A1(n_177),
.A2(n_158),
.B(n_141),
.C(n_160),
.Y(n_192)
);

INVx2_ASAP7_75t_SL g193 ( 
.A(n_171),
.Y(n_193)
);

NAND3xp33_ASAP7_75t_SL g194 ( 
.A(n_181),
.B(n_155),
.C(n_160),
.Y(n_194)
);

NOR2x1_ASAP7_75t_L g195 ( 
.A(n_166),
.B(n_151),
.Y(n_195)
);

OAI211xp5_ASAP7_75t_L g196 ( 
.A1(n_180),
.A2(n_152),
.B(n_145),
.C(n_143),
.Y(n_196)
);

OAI22xp5_ASAP7_75t_L g197 ( 
.A1(n_179),
.A2(n_150),
.B1(n_149),
.B2(n_57),
.Y(n_197)
);

AND2x2_ASAP7_75t_L g198 ( 
.A(n_186),
.B(n_173),
.Y(n_198)
);

NAND2x1_ASAP7_75t_SL g199 ( 
.A(n_172),
.B(n_150),
.Y(n_199)
);

NAND4xp25_ASAP7_75t_L g200 ( 
.A(n_174),
.B(n_149),
.C(n_32),
.D(n_31),
.Y(n_200)
);

AOI21xp33_ASAP7_75t_L g201 ( 
.A1(n_170),
.A2(n_59),
.B(n_167),
.Y(n_201)
);

NOR2x1_ASAP7_75t_L g202 ( 
.A(n_187),
.B(n_59),
.Y(n_202)
);

AOI222xp33_ASAP7_75t_L g203 ( 
.A1(n_182),
.A2(n_59),
.B1(n_169),
.B2(n_183),
.C1(n_168),
.C2(n_175),
.Y(n_203)
);

OAI21xp5_ASAP7_75t_L g204 ( 
.A1(n_188),
.A2(n_59),
.B(n_184),
.Y(n_204)
);

AOI221xp5_ASAP7_75t_L g205 ( 
.A1(n_185),
.A2(n_189),
.B1(n_179),
.B2(n_59),
.C(n_178),
.Y(n_205)
);

HB1xp67_ASAP7_75t_L g206 ( 
.A(n_193),
.Y(n_206)
);

CKINVDCx20_ASAP7_75t_R g207 ( 
.A(n_191),
.Y(n_207)
);

AND2x4_ASAP7_75t_L g208 ( 
.A(n_198),
.B(n_185),
.Y(n_208)
);

NOR3xp33_ASAP7_75t_L g209 ( 
.A(n_190),
.B(n_59),
.C(n_200),
.Y(n_209)
);

BUFx2_ASAP7_75t_L g210 ( 
.A(n_199),
.Y(n_210)
);

CKINVDCx5p33_ASAP7_75t_R g211 ( 
.A(n_194),
.Y(n_211)
);

CKINVDCx16_ASAP7_75t_R g212 ( 
.A(n_195),
.Y(n_212)
);

OAI221xp5_ASAP7_75t_L g213 ( 
.A1(n_192),
.A2(n_196),
.B1(n_203),
.B2(n_201),
.C(n_197),
.Y(n_213)
);

INVx1_ASAP7_75t_SL g214 ( 
.A(n_202),
.Y(n_214)
);

OAI31xp33_ASAP7_75t_L g215 ( 
.A1(n_213),
.A2(n_203),
.A3(n_205),
.B(n_204),
.Y(n_215)
);

INVx2_ASAP7_75t_L g216 ( 
.A(n_210),
.Y(n_216)
);

OAI22x1_ASAP7_75t_L g217 ( 
.A1(n_211),
.A2(n_210),
.B1(n_212),
.B2(n_208),
.Y(n_217)
);

HB1xp67_ASAP7_75t_L g218 ( 
.A(n_208),
.Y(n_218)
);

BUFx2_ASAP7_75t_L g219 ( 
.A(n_216),
.Y(n_219)
);

OAI22x1_ASAP7_75t_L g220 ( 
.A1(n_218),
.A2(n_212),
.B1(n_208),
.B2(n_206),
.Y(n_220)
);

NAND4xp25_ASAP7_75t_L g221 ( 
.A(n_219),
.B(n_215),
.C(n_209),
.D(n_217),
.Y(n_221)
);

AOI22xp5_ASAP7_75t_L g222 ( 
.A1(n_221),
.A2(n_220),
.B1(n_218),
.B2(n_208),
.Y(n_222)
);

NAND4xp25_ASAP7_75t_L g223 ( 
.A(n_222),
.B(n_207),
.C(n_214),
.D(n_221),
.Y(n_223)
);


endmodule