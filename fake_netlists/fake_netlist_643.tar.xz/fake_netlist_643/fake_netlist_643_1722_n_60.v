module fake_netlist_643_1722_n_60 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_60);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_60;

wire n_36;
wire n_59;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx1_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_11),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_0),
.B(n_17),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_24),
.B(n_1),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_30),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_32),
.B1(n_31),
.B2(n_23),
.Y(n_39)
);

NAND4xp25_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_25),
.C(n_27),
.D(n_20),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_34),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_34),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_34),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_40),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

OAI211xp5_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_35),
.B(n_20),
.C(n_25),
.Y(n_47)
);

AOI221x1_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_25),
.B1(n_27),
.B2(n_22),
.C(n_21),
.Y(n_48)
);

NAND2xp33_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_43),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_43),
.Y(n_50)
);

OAI322xp33_ASAP7_75t_L g51 ( 
.A1(n_45),
.A2(n_26),
.A3(n_27),
.B1(n_21),
.B2(n_3),
.C1(n_2),
.C2(n_16),
.Y(n_51)
);

NOR2xp33_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_3),
.Y(n_52)
);

NAND4xp25_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_18),
.C(n_17),
.D(n_16),
.Y(n_53)
);

NOR2x1_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_21),
.Y(n_54)
);

NOR3x2_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_18),
.C(n_7),
.Y(n_55)
);

OAI221xp5_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_49),
.B1(n_21),
.B2(n_9),
.C(n_12),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_52),
.Y(n_58)
);

AOI22xp33_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_55),
.B1(n_21),
.B2(n_14),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_58),
.B1(n_57),
.B2(n_15),
.Y(n_60)
);


endmodule