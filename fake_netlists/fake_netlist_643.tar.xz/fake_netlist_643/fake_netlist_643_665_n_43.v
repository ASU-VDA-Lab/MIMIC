module fake_netlist_643_665_n_43 (n_9, n_4, n_7, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_43);

input n_9;
input n_4;
input n_7;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_43;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_39;
wire n_14;
wire n_21;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

BUFx2_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

INVxp33_ASAP7_75t_SL g15 ( 
.A(n_6),
.Y(n_15)
);

CKINVDCx11_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_3),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_7),
.A2(n_5),
.B(n_1),
.Y(n_19)
);

OA21x2_ASAP7_75t_L g20 ( 
.A1(n_11),
.A2(n_0),
.B(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

OAI21x1_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_19),
.B(n_20),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_19),
.B(n_20),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_14),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_24),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_24),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_29),
.B(n_15),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_30),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_18),
.B1(n_22),
.B2(n_21),
.C(n_17),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_18),
.B1(n_20),
.B2(n_19),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND4xp25_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_25),
.C(n_32),
.D(n_16),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_20),
.B1(n_19),
.B2(n_26),
.Y(n_38)
);

NOR3xp33_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_26),
.C(n_27),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

OR4x1_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_12),
.C(n_4),
.D(n_2),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_41),
.B1(n_10),
.B2(n_8),
.Y(n_43)
);


endmodule