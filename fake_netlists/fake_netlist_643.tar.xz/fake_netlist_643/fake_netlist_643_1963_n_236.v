module fake_netlist_643_1963_n_236 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_28, n_11, n_15, n_7, n_30, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_27, n_2, n_29, n_31, n_26, n_33, n_9, n_32, n_13, n_8, n_6, n_236);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_28;
input n_11;
input n_15;
input n_7;
input n_30;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_27;
input n_2;
input n_29;
input n_31;
input n_26;
input n_33;
input n_9;
input n_32;
input n_13;
input n_8;
input n_6;

output n_236;

wire n_168;
wire n_99;
wire n_62;
wire n_70;
wire n_90;
wire n_101;
wire n_58;
wire n_38;
wire n_144;
wire n_155;
wire n_166;
wire n_139;
wire n_57;
wire n_84;
wire n_214;
wire n_35;
wire n_89;
wire n_209;
wire n_152;
wire n_116;
wire n_96;
wire n_172;
wire n_45;
wire n_107;
wire n_220;
wire n_218;
wire n_78;
wire n_235;
wire n_191;
wire n_66;
wire n_154;
wire n_164;
wire n_118;
wire n_60;
wire n_137;
wire n_39;
wire n_189;
wire n_197;
wire n_173;
wire n_183;
wire n_63;
wire n_190;
wire n_211;
wire n_206;
wire n_177;
wire n_192;
wire n_194;
wire n_184;
wire n_187;
wire n_81;
wire n_37;
wire n_71;
wire n_124;
wire n_163;
wire n_91;
wire n_165;
wire n_121;
wire n_157;
wire n_201;
wire n_105;
wire n_92;
wire n_125;
wire n_117;
wire n_230;
wire n_136;
wire n_40;
wire n_223;
wire n_217;
wire n_110;
wire n_170;
wire n_49;
wire n_207;
wire n_151;
wire n_53;
wire n_161;
wire n_77;
wire n_234;
wire n_75;
wire n_48;
wire n_180;
wire n_142;
wire n_232;
wire n_93;
wire n_199;
wire n_203;
wire n_181;
wire n_41;
wire n_143;
wire n_213;
wire n_65;
wire n_109;
wire n_208;
wire n_122;
wire n_219;
wire n_119;
wire n_149;
wire n_43;
wire n_182;
wire n_227;
wire n_82;
wire n_204;
wire n_120;
wire n_85;
wire n_61;
wire n_176;
wire n_72;
wire n_229;
wire n_51;
wire n_160;
wire n_231;
wire n_226;
wire n_54;
wire n_86;
wire n_156;
wire n_68;
wire n_198;
wire n_130;
wire n_210;
wire n_140;
wire n_174;
wire n_233;
wire n_202;
wire n_167;
wire n_175;
wire n_195;
wire n_67;
wire n_112;
wire n_179;
wire n_52;
wire n_50;
wire n_113;
wire n_169;
wire n_103;
wire n_104;
wire n_127;
wire n_162;
wire n_100;
wire n_150;
wire n_146;
wire n_129;
wire n_83;
wire n_76;
wire n_134;
wire n_200;
wire n_196;
wire n_106;
wire n_133;
wire n_225;
wire n_36;
wire n_59;
wire n_97;
wire n_34;
wire n_131;
wire n_64;
wire n_148;
wire n_44;
wire n_159;
wire n_228;
wire n_123;
wire n_141;
wire n_87;
wire n_145;
wire n_115;
wire n_79;
wire n_215;
wire n_128;
wire n_205;
wire n_108;
wire n_126;
wire n_185;
wire n_73;
wire n_132;
wire n_56;
wire n_98;
wire n_69;
wire n_224;
wire n_147;
wire n_171;
wire n_94;
wire n_212;
wire n_221;
wire n_222;
wire n_193;
wire n_138;
wire n_46;
wire n_153;
wire n_42;
wire n_158;
wire n_216;
wire n_55;
wire n_102;
wire n_135;
wire n_95;
wire n_178;
wire n_74;
wire n_186;
wire n_47;
wire n_188;
wire n_80;
wire n_88;
wire n_114;
wire n_111;

INVxp33_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_6),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

CKINVDCx16_ASAP7_75t_R g38 ( 
.A(n_19),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_27),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_21),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_26),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_7),
.Y(n_42)
);

CKINVDCx20_ASAP7_75t_R g43 ( 
.A(n_28),
.Y(n_43)
);

INVx1_ASAP7_75t_SL g44 ( 
.A(n_5),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_16),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_15),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_2),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_35),
.Y(n_48)
);

INVxp67_ASAP7_75t_L g49 ( 
.A(n_35),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_42),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_43),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_42),
.B(n_0),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_36),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_53),
.B(n_36),
.Y(n_54)
);

BUFx6f_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

INVx8_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_49),
.B(n_47),
.Y(n_57)
);

BUFx2_ASAP7_75t_L g58 ( 
.A(n_48),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_49),
.B(n_47),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_53),
.Y(n_60)
);

BUFx3_ASAP7_75t_L g61 ( 
.A(n_50),
.Y(n_61)
);

NOR2xp33_ASAP7_75t_L g62 ( 
.A(n_48),
.B(n_34),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_L g63 ( 
.A(n_60),
.B(n_37),
.Y(n_63)
);

BUFx3_ASAP7_75t_L g64 ( 
.A(n_61),
.Y(n_64)
);

AO221x1_ASAP7_75t_L g65 ( 
.A1(n_58),
.A2(n_50),
.B1(n_40),
.B2(n_37),
.C(n_39),
.Y(n_65)
);

OR2x6_ASAP7_75t_L g66 ( 
.A(n_56),
.B(n_52),
.Y(n_66)
);

BUFx6f_ASAP7_75t_L g67 ( 
.A(n_55),
.Y(n_67)
);

BUFx10_ASAP7_75t_L g68 ( 
.A(n_62),
.Y(n_68)
);

NOR3xp33_ASAP7_75t_SL g69 ( 
.A(n_54),
.B(n_46),
.C(n_38),
.Y(n_69)
);

AND2x4_ASAP7_75t_L g70 ( 
.A(n_59),
.B(n_52),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_60),
.B(n_39),
.Y(n_71)
);

AND2x4_ASAP7_75t_L g72 ( 
.A(n_59),
.B(n_52),
.Y(n_72)
);

BUFx2_ASAP7_75t_L g73 ( 
.A(n_58),
.Y(n_73)
);

BUFx3_ASAP7_75t_L g74 ( 
.A(n_61),
.Y(n_74)
);

INVx2_ASAP7_75t_L g75 ( 
.A(n_55),
.Y(n_75)
);

BUFx6f_ASAP7_75t_L g76 ( 
.A(n_67),
.Y(n_76)
);

BUFx2_ASAP7_75t_L g77 ( 
.A(n_73),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_71),
.Y(n_78)
);

AOI21xp5_ASAP7_75t_L g79 ( 
.A1(n_75),
.A2(n_54),
.B(n_60),
.Y(n_79)
);

INVx5_ASAP7_75t_L g80 ( 
.A(n_67),
.Y(n_80)
);

A2O1A1Ixp33_ASAP7_75t_L g81 ( 
.A1(n_70),
.A2(n_57),
.B(n_61),
.C(n_40),
.Y(n_81)
);

BUFx6f_ASAP7_75t_L g82 ( 
.A(n_67),
.Y(n_82)
);

INVxp67_ASAP7_75t_L g83 ( 
.A(n_73),
.Y(n_83)
);

AOI22xp5_ASAP7_75t_L g84 ( 
.A1(n_70),
.A2(n_57),
.B1(n_38),
.B2(n_55),
.Y(n_84)
);

INVx3_ASAP7_75t_L g85 ( 
.A(n_75),
.Y(n_85)
);

INVx2_ASAP7_75t_L g86 ( 
.A(n_75),
.Y(n_86)
);

OAI22xp33_ASAP7_75t_L g87 ( 
.A1(n_84),
.A2(n_73),
.B1(n_66),
.B2(n_64),
.Y(n_87)
);

NAND2xp33_ASAP7_75t_SL g88 ( 
.A(n_77),
.B(n_69),
.Y(n_88)
);

OAI22xp5_ASAP7_75t_L g89 ( 
.A1(n_84),
.A2(n_66),
.B1(n_70),
.B2(n_72),
.Y(n_89)
);

AOI21xp5_ASAP7_75t_L g90 ( 
.A1(n_78),
.A2(n_74),
.B(n_64),
.Y(n_90)
);

AND2x4_ASAP7_75t_L g91 ( 
.A(n_77),
.B(n_70),
.Y(n_91)
);

AOI221xp5_ASAP7_75t_L g92 ( 
.A1(n_83),
.A2(n_70),
.B1(n_72),
.B2(n_44),
.C(n_69),
.Y(n_92)
);

INVx2_ASAP7_75t_L g93 ( 
.A(n_86),
.Y(n_93)
);

BUFx6f_ASAP7_75t_L g94 ( 
.A(n_76),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_93),
.Y(n_95)
);

AOI222xp33_ASAP7_75t_L g96 ( 
.A1(n_92),
.A2(n_72),
.B1(n_68),
.B2(n_65),
.C1(n_78),
.C2(n_81),
.Y(n_96)
);

INVx4_ASAP7_75t_L g97 ( 
.A(n_94),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_91),
.B(n_72),
.Y(n_98)
);

BUFx3_ASAP7_75t_L g99 ( 
.A(n_94),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_94),
.Y(n_100)
);

INVxp67_ASAP7_75t_L g101 ( 
.A(n_91),
.Y(n_101)
);

INVx2_ASAP7_75t_L g102 ( 
.A(n_95),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_95),
.Y(n_103)
);

AOI22xp33_ASAP7_75t_L g104 ( 
.A1(n_96),
.A2(n_68),
.B1(n_88),
.B2(n_56),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_98),
.Y(n_105)
);

HB1xp67_ASAP7_75t_L g106 ( 
.A(n_101),
.Y(n_106)
);

NAND2xp5_ASAP7_75t_L g107 ( 
.A(n_98),
.B(n_68),
.Y(n_107)
);

OAI322xp33_ASAP7_75t_L g108 ( 
.A1(n_101),
.A2(n_87),
.A3(n_89),
.B1(n_45),
.B2(n_41),
.C1(n_63),
.C2(n_71),
.Y(n_108)
);

NAND2xp5_ASAP7_75t_L g109 ( 
.A(n_96),
.B(n_68),
.Y(n_109)
);

OR2x6_ASAP7_75t_L g110 ( 
.A(n_97),
.B(n_99),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_103),
.Y(n_111)
);

OR2x6_ASAP7_75t_L g112 ( 
.A(n_110),
.B(n_109),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_103),
.Y(n_113)
);

INVx2_ASAP7_75t_L g114 ( 
.A(n_102),
.Y(n_114)
);

AOI221xp5_ASAP7_75t_L g115 ( 
.A1(n_108),
.A2(n_72),
.B1(n_65),
.B2(n_56),
.C(n_90),
.Y(n_115)
);

OAI33xp33_ASAP7_75t_L g116 ( 
.A1(n_105),
.A2(n_63),
.A3(n_65),
.B1(n_100),
.B2(n_41),
.B3(n_68),
.Y(n_116)
);

OR2x2_ASAP7_75t_L g117 ( 
.A(n_102),
.B(n_100),
.Y(n_117)
);

AND2x2_ASAP7_75t_L g118 ( 
.A(n_110),
.B(n_100),
.Y(n_118)
);

AND2x2_ASAP7_75t_L g119 ( 
.A(n_110),
.B(n_99),
.Y(n_119)
);

OR2x2_ASAP7_75t_L g120 ( 
.A(n_106),
.B(n_86),
.Y(n_120)
);

AND2x2_ASAP7_75t_L g121 ( 
.A(n_110),
.B(n_99),
.Y(n_121)
);

NAND2xp5_ASAP7_75t_L g122 ( 
.A(n_107),
.B(n_56),
.Y(n_122)
);

AND2x2_ASAP7_75t_L g123 ( 
.A(n_104),
.B(n_99),
.Y(n_123)
);

INVx1_ASAP7_75t_SL g124 ( 
.A(n_106),
.Y(n_124)
);

INVx1_ASAP7_75t_L g125 ( 
.A(n_103),
.Y(n_125)
);

OAI31xp33_ASAP7_75t_L g126 ( 
.A1(n_122),
.A2(n_74),
.A3(n_64),
.B(n_66),
.Y(n_126)
);

HB1xp67_ASAP7_75t_L g127 ( 
.A(n_117),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_124),
.B(n_56),
.Y(n_128)
);

INVx1_ASAP7_75t_L g129 ( 
.A(n_113),
.Y(n_129)
);

INVx2_ASAP7_75t_L g130 ( 
.A(n_111),
.Y(n_130)
);

INVx1_ASAP7_75t_L g131 ( 
.A(n_111),
.Y(n_131)
);

AND2x2_ASAP7_75t_L g132 ( 
.A(n_125),
.B(n_97),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_125),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_114),
.Y(n_134)
);

INVxp67_ASAP7_75t_L g135 ( 
.A(n_117),
.Y(n_135)
);

NAND2xp5_ASAP7_75t_L g136 ( 
.A(n_120),
.B(n_97),
.Y(n_136)
);

OAI221xp5_ASAP7_75t_L g137 ( 
.A1(n_115),
.A2(n_66),
.B1(n_97),
.B2(n_79),
.C(n_74),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_114),
.Y(n_138)
);

NAND3xp33_ASAP7_75t_L g139 ( 
.A(n_120),
.B(n_66),
.C(n_55),
.Y(n_139)
);

OR2x2_ASAP7_75t_L g140 ( 
.A(n_112),
.B(n_55),
.Y(n_140)
);

NOR2x1_ASAP7_75t_L g141 ( 
.A(n_112),
.B(n_97),
.Y(n_141)
);

BUFx3_ASAP7_75t_L g142 ( 
.A(n_119),
.Y(n_142)
);

NAND2x1p5_ASAP7_75t_L g143 ( 
.A(n_121),
.B(n_85),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_112),
.Y(n_144)
);

AOI21xp5_ASAP7_75t_L g145 ( 
.A1(n_112),
.A2(n_66),
.B(n_80),
.Y(n_145)
);

INVx1_ASAP7_75t_L g146 ( 
.A(n_118),
.Y(n_146)
);

NOR2x1_ASAP7_75t_SL g147 ( 
.A(n_123),
.B(n_76),
.Y(n_147)
);

NAND2xp5_ASAP7_75t_L g148 ( 
.A(n_135),
.B(n_118),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_131),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_131),
.Y(n_150)
);

OAI22xp33_ASAP7_75t_L g151 ( 
.A1(n_137),
.A2(n_139),
.B1(n_136),
.B2(n_123),
.Y(n_151)
);

NAND2xp5_ASAP7_75t_L g152 ( 
.A(n_127),
.B(n_119),
.Y(n_152)
);

NAND2xp5_ASAP7_75t_L g153 ( 
.A(n_146),
.B(n_121),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_130),
.Y(n_154)
);

NAND2xp5_ASAP7_75t_L g155 ( 
.A(n_146),
.B(n_0),
.Y(n_155)
);

INVxp67_ASAP7_75t_L g156 ( 
.A(n_128),
.Y(n_156)
);

AOI22xp33_ASAP7_75t_L g157 ( 
.A1(n_126),
.A2(n_116),
.B1(n_85),
.B2(n_55),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_130),
.Y(n_158)
);

CKINVDCx16_ASAP7_75t_R g159 ( 
.A(n_142),
.Y(n_159)
);

HB1xp67_ASAP7_75t_L g160 ( 
.A(n_133),
.Y(n_160)
);

OAI21xp33_ASAP7_75t_L g161 ( 
.A1(n_144),
.A2(n_132),
.B(n_129),
.Y(n_161)
);

OAI22xp5_ASAP7_75t_L g162 ( 
.A1(n_145),
.A2(n_144),
.B1(n_143),
.B2(n_141),
.Y(n_162)
);

NOR2xp33_ASAP7_75t_L g163 ( 
.A(n_132),
.B(n_1),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_134),
.Y(n_164)
);

AOI21xp33_ASAP7_75t_L g165 ( 
.A1(n_140),
.A2(n_85),
.B(n_1),
.Y(n_165)
);

INVx2_ASAP7_75t_L g166 ( 
.A(n_134),
.Y(n_166)
);

INVx1_ASAP7_75t_L g167 ( 
.A(n_138),
.Y(n_167)
);

NAND2xp5_ASAP7_75t_SL g168 ( 
.A(n_140),
.B(n_85),
.Y(n_168)
);

INVx1_ASAP7_75t_L g169 ( 
.A(n_138),
.Y(n_169)
);

OR2x2_ASAP7_75t_L g170 ( 
.A(n_142),
.B(n_2),
.Y(n_170)
);

AOI322xp5_ASAP7_75t_L g171 ( 
.A1(n_147),
.A2(n_4),
.A3(n_3),
.B1(n_7),
.B2(n_8),
.C1(n_5),
.C2(n_6),
.Y(n_171)
);

AOI21xp5_ASAP7_75t_L g172 ( 
.A1(n_147),
.A2(n_82),
.B(n_76),
.Y(n_172)
);

NAND2xp5_ASAP7_75t_L g173 ( 
.A(n_143),
.B(n_3),
.Y(n_173)
);

OR2x2_ASAP7_75t_L g174 ( 
.A(n_143),
.B(n_4),
.Y(n_174)
);

NAND2xp5_ASAP7_75t_L g175 ( 
.A(n_156),
.B(n_160),
.Y(n_175)
);

NAND2xp5_ASAP7_75t_L g176 ( 
.A(n_160),
.B(n_8),
.Y(n_176)
);

BUFx2_ASAP7_75t_L g177 ( 
.A(n_149),
.Y(n_177)
);

NAND2xp5_ASAP7_75t_L g178 ( 
.A(n_150),
.B(n_154),
.Y(n_178)
);

NOR3xp33_ASAP7_75t_SL g179 ( 
.A(n_163),
.B(n_173),
.C(n_155),
.Y(n_179)
);

INVx1_ASAP7_75t_L g180 ( 
.A(n_158),
.Y(n_180)
);

AOI21xp33_ASAP7_75t_L g181 ( 
.A1(n_174),
.A2(n_10),
.B(n_9),
.Y(n_181)
);

NAND2xp5_ASAP7_75t_L g182 ( 
.A(n_153),
.B(n_9),
.Y(n_182)
);

INVxp33_ASAP7_75t_L g183 ( 
.A(n_152),
.Y(n_183)
);

INVx1_ASAP7_75t_L g184 ( 
.A(n_164),
.Y(n_184)
);

NAND3xp33_ASAP7_75t_L g185 ( 
.A(n_171),
.B(n_82),
.C(n_76),
.Y(n_185)
);

NAND2xp5_ASAP7_75t_L g186 ( 
.A(n_167),
.B(n_10),
.Y(n_186)
);

XOR2xp5_ASAP7_75t_L g187 ( 
.A(n_159),
.B(n_11),
.Y(n_187)
);

OAI21xp33_ASAP7_75t_L g188 ( 
.A1(n_161),
.A2(n_12),
.B(n_11),
.Y(n_188)
);

INVx2_ASAP7_75t_L g189 ( 
.A(n_169),
.Y(n_189)
);

NOR2x1_ASAP7_75t_L g190 ( 
.A(n_163),
.B(n_76),
.Y(n_190)
);

INVxp67_ASAP7_75t_L g191 ( 
.A(n_148),
.Y(n_191)
);

OAI221xp5_ASAP7_75t_L g192 ( 
.A1(n_170),
.A2(n_13),
.B1(n_12),
.B2(n_14),
.C(n_15),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_166),
.B(n_162),
.Y(n_193)
);

NAND2xp5_ASAP7_75t_L g194 ( 
.A(n_151),
.B(n_13),
.Y(n_194)
);

NOR3xp33_ASAP7_75t_SL g195 ( 
.A(n_151),
.B(n_14),
.C(n_17),
.Y(n_195)
);

OR2x2_ASAP7_75t_L g196 ( 
.A(n_168),
.B(n_76),
.Y(n_196)
);

NAND2xp5_ASAP7_75t_L g197 ( 
.A(n_168),
.B(n_18),
.Y(n_197)
);

NAND4xp25_ASAP7_75t_L g198 ( 
.A(n_165),
.B(n_23),
.C(n_22),
.D(n_20),
.Y(n_198)
);

AND2x2_ASAP7_75t_L g199 ( 
.A(n_172),
.B(n_82),
.Y(n_199)
);

NAND2xp5_ASAP7_75t_SL g200 ( 
.A(n_175),
.B(n_157),
.Y(n_200)
);

OAI31xp33_ASAP7_75t_L g201 ( 
.A1(n_194),
.A2(n_157),
.A3(n_29),
.B(n_25),
.Y(n_201)
);

AND2x2_ASAP7_75t_L g202 ( 
.A(n_183),
.B(n_31),
.Y(n_202)
);

NAND2xp5_ASAP7_75t_L g203 ( 
.A(n_177),
.B(n_82),
.Y(n_203)
);

NOR2x1_ASAP7_75t_L g204 ( 
.A(n_177),
.B(n_82),
.Y(n_204)
);

OR2x2_ASAP7_75t_L g205 ( 
.A(n_191),
.B(n_82),
.Y(n_205)
);

NAND2xp5_ASAP7_75t_SL g206 ( 
.A(n_193),
.B(n_67),
.Y(n_206)
);

XNOR2x1_ASAP7_75t_L g207 ( 
.A(n_187),
.B(n_33),
.Y(n_207)
);

AOI211xp5_ASAP7_75t_L g208 ( 
.A1(n_192),
.A2(n_67),
.B(n_80),
.C(n_181),
.Y(n_208)
);

XNOR2x1_ASAP7_75t_L g209 ( 
.A(n_190),
.B(n_67),
.Y(n_209)
);

INVx1_ASAP7_75t_L g210 ( 
.A(n_184),
.Y(n_210)
);

INVx1_ASAP7_75t_L g211 ( 
.A(n_189),
.Y(n_211)
);

INVx1_ASAP7_75t_L g212 ( 
.A(n_189),
.Y(n_212)
);

INVx1_ASAP7_75t_L g213 ( 
.A(n_178),
.Y(n_213)
);

NAND2xp33_ASAP7_75t_SL g214 ( 
.A(n_195),
.B(n_179),
.Y(n_214)
);

NAND2xp5_ASAP7_75t_L g215 ( 
.A(n_193),
.B(n_67),
.Y(n_215)
);

AND2x2_ASAP7_75t_L g216 ( 
.A(n_213),
.B(n_183),
.Y(n_216)
);

INVx1_ASAP7_75t_L g217 ( 
.A(n_210),
.Y(n_217)
);

HB1xp67_ASAP7_75t_L g218 ( 
.A(n_211),
.Y(n_218)
);

AO22x1_ASAP7_75t_L g219 ( 
.A1(n_204),
.A2(n_176),
.B1(n_182),
.B2(n_186),
.Y(n_219)
);

AOI21xp33_ASAP7_75t_SL g220 ( 
.A1(n_206),
.A2(n_200),
.B(n_209),
.Y(n_220)
);

NOR3xp33_ASAP7_75t_L g221 ( 
.A(n_214),
.B(n_188),
.C(n_198),
.Y(n_221)
);

NAND3x1_ASAP7_75t_SL g222 ( 
.A(n_201),
.B(n_199),
.C(n_185),
.Y(n_222)
);

OAI22x1_ASAP7_75t_L g223 ( 
.A1(n_200),
.A2(n_180),
.B1(n_199),
.B2(n_197),
.Y(n_223)
);

INVx1_ASAP7_75t_L g224 ( 
.A(n_212),
.Y(n_224)
);

AOI22xp33_ASAP7_75t_L g225 ( 
.A1(n_221),
.A2(n_214),
.B1(n_206),
.B2(n_209),
.Y(n_225)
);

NOR2xp33_ASAP7_75t_L g226 ( 
.A(n_219),
.B(n_220),
.Y(n_226)
);

AOI221xp5_ASAP7_75t_L g227 ( 
.A1(n_223),
.A2(n_208),
.B1(n_215),
.B2(n_203),
.C(n_202),
.Y(n_227)
);

O2A1O1Ixp33_ASAP7_75t_L g228 ( 
.A1(n_221),
.A2(n_205),
.B(n_196),
.C(n_207),
.Y(n_228)
);

NAND3xp33_ASAP7_75t_L g229 ( 
.A(n_217),
.B(n_196),
.C(n_80),
.Y(n_229)
);

HB1xp67_ASAP7_75t_L g230 ( 
.A(n_226),
.Y(n_230)
);

OAI211xp5_ASAP7_75t_L g231 ( 
.A1(n_225),
.A2(n_222),
.B(n_218),
.C(n_224),
.Y(n_231)
);

INVx3_ASAP7_75t_L g232 ( 
.A(n_231),
.Y(n_232)
);

INVx1_ASAP7_75t_L g233 ( 
.A(n_232),
.Y(n_233)
);

AND3x4_ASAP7_75t_L g234 ( 
.A(n_233),
.B(n_232),
.C(n_230),
.Y(n_234)
);

AOI22xp5_ASAP7_75t_L g235 ( 
.A1(n_234),
.A2(n_232),
.B1(n_227),
.B2(n_229),
.Y(n_235)
);

AOI221x1_ASAP7_75t_L g236 ( 
.A1(n_235),
.A2(n_216),
.B1(n_228),
.B2(n_218),
.C(n_80),
.Y(n_236)
);


endmodule