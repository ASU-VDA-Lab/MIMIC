module fake_netlist_643_391_n_47 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_47);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_47;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_23;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_13),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_12),
.B(n_8),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_7),
.B(n_11),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_9),
.Y(n_28)
);

AO22x1_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_19),
.B1(n_18),
.B2(n_0),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_SL g30 ( 
.A(n_22),
.B(n_18),
.C(n_1),
.Y(n_30)
);

INVx4_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_20),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_28),
.C(n_24),
.Y(n_33)
);

CKINVDCx6p67_ASAP7_75t_R g34 ( 
.A(n_31),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_34),
.B(n_32),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_SL g36 ( 
.A(n_33),
.B(n_30),
.C(n_25),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_31),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_26),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_21),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_27),
.Y(n_42)
);

HB1xp67_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AND2x4_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_3),
.Y(n_44)
);

AO22x2_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_42),
.B1(n_15),
.B2(n_10),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_16),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_17),
.B1(n_46),
.B2(n_42),
.Y(n_47)
);


endmodule