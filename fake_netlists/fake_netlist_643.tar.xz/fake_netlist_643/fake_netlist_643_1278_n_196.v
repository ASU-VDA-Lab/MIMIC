module fake_netlist_643_1278_n_196 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_26, n_9, n_13, n_8, n_6, n_196);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_26;
input n_9;
input n_13;
input n_8;
input n_6;

output n_196;

wire n_168;
wire n_99;
wire n_62;
wire n_70;
wire n_90;
wire n_101;
wire n_38;
wire n_58;
wire n_144;
wire n_166;
wire n_155;
wire n_139;
wire n_57;
wire n_84;
wire n_35;
wire n_89;
wire n_152;
wire n_116;
wire n_96;
wire n_172;
wire n_45;
wire n_107;
wire n_78;
wire n_191;
wire n_66;
wire n_154;
wire n_164;
wire n_118;
wire n_60;
wire n_137;
wire n_39;
wire n_189;
wire n_173;
wire n_183;
wire n_63;
wire n_190;
wire n_177;
wire n_192;
wire n_31;
wire n_194;
wire n_184;
wire n_187;
wire n_81;
wire n_37;
wire n_71;
wire n_124;
wire n_163;
wire n_91;
wire n_165;
wire n_121;
wire n_157;
wire n_105;
wire n_92;
wire n_125;
wire n_117;
wire n_136;
wire n_40;
wire n_110;
wire n_28;
wire n_170;
wire n_49;
wire n_151;
wire n_53;
wire n_161;
wire n_77;
wire n_75;
wire n_48;
wire n_180;
wire n_142;
wire n_93;
wire n_181;
wire n_41;
wire n_143;
wire n_109;
wire n_65;
wire n_33;
wire n_122;
wire n_119;
wire n_149;
wire n_43;
wire n_182;
wire n_82;
wire n_120;
wire n_85;
wire n_61;
wire n_176;
wire n_72;
wire n_51;
wire n_160;
wire n_54;
wire n_86;
wire n_156;
wire n_68;
wire n_130;
wire n_140;
wire n_174;
wire n_167;
wire n_175;
wire n_195;
wire n_27;
wire n_67;
wire n_112;
wire n_29;
wire n_179;
wire n_52;
wire n_50;
wire n_113;
wire n_169;
wire n_104;
wire n_103;
wire n_127;
wire n_162;
wire n_100;
wire n_150;
wire n_129;
wire n_146;
wire n_76;
wire n_83;
wire n_134;
wire n_106;
wire n_133;
wire n_36;
wire n_59;
wire n_97;
wire n_34;
wire n_131;
wire n_64;
wire n_148;
wire n_44;
wire n_159;
wire n_123;
wire n_141;
wire n_87;
wire n_145;
wire n_115;
wire n_79;
wire n_30;
wire n_128;
wire n_108;
wire n_126;
wire n_185;
wire n_73;
wire n_132;
wire n_56;
wire n_98;
wire n_69;
wire n_147;
wire n_171;
wire n_94;
wire n_193;
wire n_138;
wire n_46;
wire n_153;
wire n_42;
wire n_158;
wire n_55;
wire n_102;
wire n_135;
wire n_95;
wire n_178;
wire n_74;
wire n_32;
wire n_186;
wire n_47;
wire n_188;
wire n_80;
wire n_88;
wire n_114;
wire n_111;

BUFx3_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_0),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_20),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_16),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_14),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_1),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_19),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_15),
.Y(n_37)
);

INVxp33_ASAP7_75t_L g38 ( 
.A(n_25),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_8),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_7),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_31),
.B(n_0),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_31),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_37),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_29),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_29),
.B(n_1),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_40),
.B(n_2),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_45),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_37),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_SL g49 ( 
.A(n_41),
.B(n_38),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_44),
.B(n_40),
.Y(n_50)
);

INVx3_ASAP7_75t_L g51 ( 
.A(n_43),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_43),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_46),
.Y(n_53)
);

OR2x2_ASAP7_75t_L g54 ( 
.A(n_45),
.B(n_28),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_46),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_51),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_L g58 ( 
.A(n_49),
.B(n_42),
.Y(n_58)
);

INVxp67_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

BUFx3_ASAP7_75t_L g60 ( 
.A(n_47),
.Y(n_60)
);

BUFx3_ASAP7_75t_L g61 ( 
.A(n_47),
.Y(n_61)
);

NOR2xp33_ASAP7_75t_L g62 ( 
.A(n_53),
.B(n_46),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_50),
.B(n_46),
.Y(n_63)
);

HB1xp67_ASAP7_75t_L g64 ( 
.A(n_54),
.Y(n_64)
);

CKINVDCx6p67_ASAP7_75t_R g65 ( 
.A(n_60),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_62),
.B(n_51),
.Y(n_66)
);

O2A1O1Ixp33_ASAP7_75t_L g67 ( 
.A1(n_56),
.A2(n_61),
.B(n_60),
.C(n_59),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_60),
.B(n_50),
.Y(n_68)
);

BUFx6f_ASAP7_75t_L g69 ( 
.A(n_61),
.Y(n_69)
);

AND2x4_ASAP7_75t_L g70 ( 
.A(n_61),
.B(n_27),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_57),
.Y(n_71)
);

O2A1O1Ixp5_ASAP7_75t_SL g72 ( 
.A1(n_55),
.A2(n_52),
.B(n_51),
.C(n_48),
.Y(n_72)
);

AO21x2_ASAP7_75t_L g73 ( 
.A1(n_56),
.A2(n_33),
.B(n_32),
.Y(n_73)
);

INVx2_ASAP7_75t_L g74 ( 
.A(n_71),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_71),
.Y(n_75)
);

OAI22xp5_ASAP7_75t_L g76 ( 
.A1(n_69),
.A2(n_63),
.B1(n_64),
.B2(n_58),
.Y(n_76)
);

AO21x1_ASAP7_75t_SL g77 ( 
.A1(n_66),
.A2(n_55),
.B(n_34),
.Y(n_77)
);

INVx2_ASAP7_75t_L g78 ( 
.A(n_71),
.Y(n_78)
);

INVx2_ASAP7_75t_SL g79 ( 
.A(n_69),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_68),
.Y(n_80)
);

HB1xp67_ASAP7_75t_L g81 ( 
.A(n_69),
.Y(n_81)
);

AND2x2_ASAP7_75t_L g82 ( 
.A(n_80),
.B(n_68),
.Y(n_82)
);

BUFx6f_ASAP7_75t_L g83 ( 
.A(n_79),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_75),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_75),
.Y(n_85)
);

INVx2_ASAP7_75t_L g86 ( 
.A(n_74),
.Y(n_86)
);

CKINVDCx20_ASAP7_75t_R g87 ( 
.A(n_76),
.Y(n_87)
);

HB1xp67_ASAP7_75t_L g88 ( 
.A(n_81),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_84),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_85),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_82),
.Y(n_91)
);

INVx2_ASAP7_75t_L g92 ( 
.A(n_86),
.Y(n_92)
);

NOR2xp33_ASAP7_75t_L g93 ( 
.A(n_87),
.B(n_69),
.Y(n_93)
);

AOI21xp33_ASAP7_75t_SL g94 ( 
.A1(n_88),
.A2(n_39),
.B(n_70),
.Y(n_94)
);

AND2x2_ASAP7_75t_L g95 ( 
.A(n_86),
.B(n_70),
.Y(n_95)
);

AND2x2_ASAP7_75t_L g96 ( 
.A(n_91),
.B(n_77),
.Y(n_96)
);

AND2x2_ASAP7_75t_L g97 ( 
.A(n_90),
.B(n_95),
.Y(n_97)
);

INVx1_ASAP7_75t_L g98 ( 
.A(n_92),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_92),
.Y(n_99)
);

BUFx12f_ASAP7_75t_L g100 ( 
.A(n_95),
.Y(n_100)
);

AND2x2_ASAP7_75t_L g101 ( 
.A(n_93),
.B(n_77),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_93),
.Y(n_102)
);

AND2x2_ASAP7_75t_L g103 ( 
.A(n_94),
.B(n_73),
.Y(n_103)
);

INVxp67_ASAP7_75t_SL g104 ( 
.A(n_93),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_89),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_105),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_105),
.Y(n_107)
);

NOR2xp33_ASAP7_75t_L g108 ( 
.A(n_102),
.B(n_87),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_98),
.Y(n_109)
);

OR2x2_ASAP7_75t_L g110 ( 
.A(n_102),
.B(n_73),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_97),
.B(n_73),
.Y(n_111)
);

INVx2_ASAP7_75t_L g112 ( 
.A(n_98),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_97),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_99),
.Y(n_114)
);

AND2x2_ASAP7_75t_L g115 ( 
.A(n_96),
.B(n_73),
.Y(n_115)
);

NAND2xp5_ASAP7_75t_L g116 ( 
.A(n_104),
.B(n_96),
.Y(n_116)
);

OR2x2_ASAP7_75t_L g117 ( 
.A(n_101),
.B(n_74),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_101),
.Y(n_118)
);

AND2x2_ASAP7_75t_L g119 ( 
.A(n_103),
.B(n_83),
.Y(n_119)
);

AND2x2_ASAP7_75t_L g120 ( 
.A(n_103),
.B(n_83),
.Y(n_120)
);

AND2x2_ASAP7_75t_L g121 ( 
.A(n_100),
.B(n_83),
.Y(n_121)
);

AND2x2_ASAP7_75t_L g122 ( 
.A(n_100),
.B(n_83),
.Y(n_122)
);

AND2x2_ASAP7_75t_L g123 ( 
.A(n_96),
.B(n_36),
.Y(n_123)
);

INVx1_ASAP7_75t_SL g124 ( 
.A(n_122),
.Y(n_124)
);

NAND2xp5_ASAP7_75t_L g125 ( 
.A(n_113),
.B(n_116),
.Y(n_125)
);

AND2x2_ASAP7_75t_L g126 ( 
.A(n_118),
.B(n_27),
.Y(n_126)
);

AND2x2_ASAP7_75t_L g127 ( 
.A(n_120),
.B(n_72),
.Y(n_127)
);

BUFx2_ASAP7_75t_L g128 ( 
.A(n_119),
.Y(n_128)
);

INVx1_ASAP7_75t_L g129 ( 
.A(n_106),
.Y(n_129)
);

AND2x2_ASAP7_75t_L g130 ( 
.A(n_119),
.B(n_72),
.Y(n_130)
);

OR2x2_ASAP7_75t_L g131 ( 
.A(n_107),
.B(n_2),
.Y(n_131)
);

CKINVDCx5p33_ASAP7_75t_R g132 ( 
.A(n_122),
.Y(n_132)
);

NAND2xp5_ASAP7_75t_L g133 ( 
.A(n_123),
.B(n_67),
.Y(n_133)
);

BUFx2_ASAP7_75t_L g134 ( 
.A(n_120),
.Y(n_134)
);

INVx2_ASAP7_75t_L g135 ( 
.A(n_112),
.Y(n_135)
);

OR2x2_ASAP7_75t_L g136 ( 
.A(n_115),
.B(n_3),
.Y(n_136)
);

NOR3xp33_ASAP7_75t_L g137 ( 
.A(n_123),
.B(n_67),
.C(n_51),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_109),
.Y(n_138)
);

AND2x2_ASAP7_75t_L g139 ( 
.A(n_115),
.B(n_4),
.Y(n_139)
);

INVx2_ASAP7_75t_L g140 ( 
.A(n_112),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_114),
.Y(n_141)
);

NAND2xp5_ASAP7_75t_L g142 ( 
.A(n_108),
.B(n_117),
.Y(n_142)
);

OR2x2_ASAP7_75t_L g143 ( 
.A(n_111),
.B(n_4),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_110),
.Y(n_144)
);

AND2x2_ASAP7_75t_L g145 ( 
.A(n_110),
.B(n_5),
.Y(n_145)
);

AOI22x1_ASAP7_75t_L g146 ( 
.A1(n_121),
.A2(n_35),
.B1(n_30),
.B2(n_69),
.Y(n_146)
);

INVx2_ASAP7_75t_L g147 ( 
.A(n_135),
.Y(n_147)
);

NAND2xp5_ASAP7_75t_SL g148 ( 
.A(n_144),
.B(n_142),
.Y(n_148)
);

AND2x2_ASAP7_75t_L g149 ( 
.A(n_128),
.B(n_121),
.Y(n_149)
);

XOR2xp5_ASAP7_75t_L g150 ( 
.A(n_132),
.B(n_108),
.Y(n_150)
);

NAND2xp5_ASAP7_75t_L g151 ( 
.A(n_125),
.B(n_5),
.Y(n_151)
);

AND3x1_ASAP7_75t_L g152 ( 
.A(n_139),
.B(n_145),
.C(n_126),
.Y(n_152)
);

AND2x2_ASAP7_75t_L g153 ( 
.A(n_128),
.B(n_6),
.Y(n_153)
);

NAND2xp5_ASAP7_75t_L g154 ( 
.A(n_129),
.B(n_6),
.Y(n_154)
);

XNOR2x2_ASAP7_75t_L g155 ( 
.A(n_136),
.B(n_7),
.Y(n_155)
);

NOR2x1p5_ASAP7_75t_L g156 ( 
.A(n_136),
.B(n_65),
.Y(n_156)
);

AOI21xp5_ASAP7_75t_L g157 ( 
.A1(n_133),
.A2(n_66),
.B(n_78),
.Y(n_157)
);

INVxp67_ASAP7_75t_SL g158 ( 
.A(n_144),
.Y(n_158)
);

NOR3xp33_ASAP7_75t_L g159 ( 
.A(n_143),
.B(n_63),
.C(n_78),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_138),
.Y(n_160)
);

NOR2x1_ASAP7_75t_L g161 ( 
.A(n_131),
.B(n_69),
.Y(n_161)
);

NAND2xp5_ASAP7_75t_L g162 ( 
.A(n_141),
.B(n_8),
.Y(n_162)
);

NAND3xp33_ASAP7_75t_L g163 ( 
.A(n_137),
.B(n_57),
.C(n_9),
.Y(n_163)
);

NAND2xp5_ASAP7_75t_L g164 ( 
.A(n_145),
.B(n_57),
.Y(n_164)
);

HAxp5_ASAP7_75t_SL g165 ( 
.A(n_146),
.B(n_139),
.CON(n_165),
.SN(n_165)
);

NAND4xp25_ASAP7_75t_L g166 ( 
.A(n_131),
.B(n_65),
.C(n_11),
.D(n_10),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_SL g167 ( 
.A(n_132),
.B(n_65),
.Y(n_167)
);

NOR3x1_ASAP7_75t_L g168 ( 
.A(n_134),
.B(n_124),
.C(n_126),
.Y(n_168)
);

OAI21xp5_ASAP7_75t_SL g169 ( 
.A1(n_165),
.A2(n_134),
.B(n_127),
.Y(n_169)
);

AOI221xp5_ASAP7_75t_L g170 ( 
.A1(n_152),
.A2(n_130),
.B1(n_127),
.B2(n_135),
.C(n_140),
.Y(n_170)
);

INVx1_ASAP7_75t_L g171 ( 
.A(n_160),
.Y(n_171)
);

A2O1A1Ixp33_ASAP7_75t_L g172 ( 
.A1(n_166),
.A2(n_146),
.B(n_13),
.C(n_12),
.Y(n_172)
);

NOR2x1_ASAP7_75t_L g173 ( 
.A(n_148),
.B(n_17),
.Y(n_173)
);

NAND2xp5_ASAP7_75t_L g174 ( 
.A(n_158),
.B(n_18),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_158),
.Y(n_175)
);

INVx1_ASAP7_75t_SL g176 ( 
.A(n_149),
.Y(n_176)
);

AOI21xp33_ASAP7_75t_L g177 ( 
.A1(n_154),
.A2(n_162),
.B(n_151),
.Y(n_177)
);

NAND2xp5_ASAP7_75t_L g178 ( 
.A(n_147),
.B(n_21),
.Y(n_178)
);

NAND2xp5_ASAP7_75t_L g179 ( 
.A(n_164),
.B(n_22),
.Y(n_179)
);

INVx2_ASAP7_75t_SL g180 ( 
.A(n_153),
.Y(n_180)
);

NAND3xp33_ASAP7_75t_SL g181 ( 
.A(n_169),
.B(n_150),
.C(n_159),
.Y(n_181)
);

INVx1_ASAP7_75t_L g182 ( 
.A(n_171),
.Y(n_182)
);

NOR3xp33_ASAP7_75t_L g183 ( 
.A(n_177),
.B(n_163),
.C(n_159),
.Y(n_183)
);

OAI22xp5_ASAP7_75t_SL g184 ( 
.A1(n_180),
.A2(n_155),
.B1(n_161),
.B2(n_168),
.Y(n_184)
);

NOR3xp33_ASAP7_75t_L g185 ( 
.A(n_177),
.B(n_172),
.C(n_170),
.Y(n_185)
);

NOR2x1_ASAP7_75t_L g186 ( 
.A(n_175),
.B(n_156),
.Y(n_186)
);

AND3x4_ASAP7_75t_L g187 ( 
.A(n_173),
.B(n_167),
.C(n_157),
.Y(n_187)
);

HB1xp67_ASAP7_75t_L g188 ( 
.A(n_182),
.Y(n_188)
);

AOI22xp5_ASAP7_75t_L g189 ( 
.A1(n_185),
.A2(n_179),
.B1(n_174),
.B2(n_176),
.Y(n_189)
);

XOR2xp5_ASAP7_75t_L g190 ( 
.A(n_181),
.B(n_178),
.Y(n_190)
);

INVx1_ASAP7_75t_L g191 ( 
.A(n_188),
.Y(n_191)
);

NAND5xp2_ASAP7_75t_L g192 ( 
.A(n_189),
.B(n_183),
.C(n_184),
.D(n_187),
.E(n_186),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_191),
.Y(n_193)
);

NAND2xp5_ASAP7_75t_SL g194 ( 
.A(n_193),
.B(n_191),
.Y(n_194)
);

INVx1_ASAP7_75t_L g195 ( 
.A(n_194),
.Y(n_195)
);

AOI21xp5_ASAP7_75t_L g196 ( 
.A1(n_195),
.A2(n_192),
.B(n_190),
.Y(n_196)
);


endmodule