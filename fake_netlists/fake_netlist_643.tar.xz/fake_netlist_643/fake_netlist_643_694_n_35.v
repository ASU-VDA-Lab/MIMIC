module fake_netlist_643_694_n_35 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_35);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_35;

wire n_18;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

NOR2xp67_ASAP7_75t_L g20 ( 
.A(n_3),
.B(n_5),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_9),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_8),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

O2A1O1Ixp5_ASAP7_75t_L g25 ( 
.A1(n_16),
.A2(n_15),
.B(n_14),
.C(n_13),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_17),
.A2(n_24),
.B(n_19),
.C(n_18),
.Y(n_26)
);

AOI21x1_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_15),
.B(n_14),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_30),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_29),
.B1(n_17),
.B2(n_21),
.C(n_23),
.Y(n_32)
);

NAND4xp25_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_20),
.C(n_27),
.D(n_22),
.Y(n_33)
);

XNOR2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_2),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_35)
);


endmodule