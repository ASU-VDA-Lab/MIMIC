module fake_netlist_643_1762_n_12 (n_3, n_1, n_2, n_0, n_12);

input n_3;
input n_1;
input n_2;
input n_0;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_11;
wire n_8;
wire n_6;

AOI22xp5_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_R g5 ( 
.A(n_1),
.B(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI221xp5_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_2),
.B1(n_6),
.B2(n_7),
.C(n_4),
.Y(n_9)
);

NOR2x1_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_7),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_10),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_6),
.B(n_7),
.Y(n_12)
);


endmodule