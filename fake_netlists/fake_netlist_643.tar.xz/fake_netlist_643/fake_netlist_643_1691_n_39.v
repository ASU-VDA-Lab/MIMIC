module fake_netlist_643_1691_n_39 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_39);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_39;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_8),
.Y(n_23)
);

AOI21x1_ASAP7_75t_L g24 ( 
.A1(n_11),
.A2(n_5),
.B(n_9),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_18),
.B(n_4),
.Y(n_25)
);

OAI222xp33_ASAP7_75t_L g26 ( 
.A1(n_20),
.A2(n_6),
.B1(n_3),
.B2(n_1),
.C1(n_7),
.C2(n_2),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_10),
.Y(n_27)
);

CKINVDCx6p67_ASAP7_75t_R g28 ( 
.A(n_27),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_22),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_29),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

NAND4xp25_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_19),
.C(n_17),
.D(n_21),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_SL g34 ( 
.A(n_32),
.B(n_26),
.Y(n_34)
);

OAI21xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_25),
.B(n_24),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_23),
.B1(n_14),
.B2(n_13),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_37),
.A2(n_15),
.B1(n_23),
.B2(n_38),
.Y(n_39)
);


endmodule