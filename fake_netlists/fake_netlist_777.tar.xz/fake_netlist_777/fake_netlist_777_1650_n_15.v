module fake_netlist_777_1650_n_15 (n_1, n_2, n_0, n_15);

input n_1;
input n_2;
input n_0;

output n_15;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_14;
wire n_3;
wire n_9;
wire n_12;
wire n_13;
wire n_4;
wire n_8;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

BUFx4f_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_4),
.Y(n_9)
);

O2A1O1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_4),
.B(n_5),
.C(n_1),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_1),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_5),
.B1(n_2),
.B2(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

OAI222xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_0),
.B1(n_2),
.B2(n_14),
.C1(n_12),
.C2(n_3),
.Y(n_15)
);


endmodule