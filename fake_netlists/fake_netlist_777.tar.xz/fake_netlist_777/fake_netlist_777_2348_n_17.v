module fake_netlist_777_2348_n_17 (n_1, n_2, n_3, n_0, n_17);

input n_1;
input n_2;
input n_3;
input n_0;

output n_17;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_5;
wire n_16;
wire n_6;
wire n_14;
wire n_8;
wire n_12;
wire n_13;
wire n_4;
wire n_9;

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_4),
.Y(n_9)
);

INVxp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_1),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_11),
.B(n_13),
.C(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_5),
.B(n_0),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_2),
.B1(n_3),
.B2(n_15),
.C1(n_10),
.C2(n_14),
.Y(n_17)
);


endmodule