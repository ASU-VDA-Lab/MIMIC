module fake_netlist_777_1447_n_18 (n_1, n_2, n_3, n_0, n_18);

input n_1;
input n_2;
input n_3;
input n_0;

output n_18;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_5;
wire n_16;
wire n_6;
wire n_14;
wire n_8;
wire n_17;
wire n_12;
wire n_13;
wire n_4;
wire n_9;

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

OAI21xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

OAI211xp5_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI22xp33_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_6),
.B1(n_2),
.B2(n_1),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_7),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_2),
.Y(n_13)
);

NAND4xp25_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_8),
.C(n_9),
.D(n_10),
.Y(n_14)
);

OAI221xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_8),
.B1(n_6),
.B2(n_9),
.C(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OR3x1_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_3),
.C(n_6),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_6),
.B1(n_16),
.B2(n_12),
.Y(n_18)
);


endmodule