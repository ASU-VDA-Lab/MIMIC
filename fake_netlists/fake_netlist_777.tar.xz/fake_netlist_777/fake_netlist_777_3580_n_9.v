module fake_netlist_777_3580_n_9 (n_1, n_2, n_0, n_9);

input n_1;
input n_2;
input n_0;

output n_9;

wire n_7;
wire n_5;
wire n_6;
wire n_3;
wire n_4;
wire n_8;

AND2x6_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

AOI22xp33_ASAP7_75t_SL g4 ( 
.A1(n_3),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

OAI32xp33_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_3),
.A3(n_2),
.B1(n_0),
.B2(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_3),
.Y(n_7)
);

XNOR2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_0),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_2),
.B(n_7),
.Y(n_9)
);


endmodule