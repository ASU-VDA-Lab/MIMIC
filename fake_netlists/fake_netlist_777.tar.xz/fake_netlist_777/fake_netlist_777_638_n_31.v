module fake_netlist_777_638_n_31 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_31);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_31;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_28;
wire n_9;
wire n_30;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_SL g9 ( 
.A(n_7),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_3),
.Y(n_10)
);

INVx5_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_8),
.B(n_1),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_5),
.B(n_4),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_5),
.B(n_4),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_10),
.A2(n_6),
.B(n_13),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_10),
.A2(n_14),
.B(n_13),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_11),
.Y(n_20)
);

AND2x4_ASAP7_75t_SL g21 ( 
.A(n_17),
.B(n_14),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI21xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_20),
.B(n_21),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_16),
.B1(n_9),
.B2(n_11),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_24),
.Y(n_27)
);

NAND4xp75_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_11),
.C(n_15),
.D(n_17),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVxp67_ASAP7_75t_SL g30 ( 
.A(n_28),
.Y(n_30)
);

OAI21xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_11),
.B(n_29),
.Y(n_31)
);


endmodule