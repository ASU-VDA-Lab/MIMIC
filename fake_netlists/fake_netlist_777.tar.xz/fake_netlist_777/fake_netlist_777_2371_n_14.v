module fake_netlist_777_2371_n_14 (n_1, n_2, n_0, n_14);

input n_1;
input n_2;
input n_0;

output n_14;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_3;
wire n_9;
wire n_12;
wire n_13;
wire n_4;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_2),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_2),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.B1(n_7),
.B2(n_0),
.C(n_1),
.Y(n_10)
);

INVxp67_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NOR2xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_7),
.C(n_0),
.Y(n_13)
);

OAI21xp33_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_1),
.B(n_13),
.Y(n_14)
);


endmodule