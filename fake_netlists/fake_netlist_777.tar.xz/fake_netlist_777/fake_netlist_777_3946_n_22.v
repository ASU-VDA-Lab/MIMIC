module fake_netlist_777_3946_n_22 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_22);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_22;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_21;
wire n_14;

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_4),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_3),
.B(n_0),
.Y(n_16)
);

AND2x2_ASAP7_75t_SL g17 ( 
.A(n_15),
.B(n_14),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

OAI21xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_17),
.B(n_13),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_9),
.B(n_7),
.Y(n_22)
);


endmodule