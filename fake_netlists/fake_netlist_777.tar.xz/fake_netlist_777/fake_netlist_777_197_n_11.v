module fake_netlist_777_197_n_11 (n_1, n_0, n_11);

input n_1;
input n_0;

output n_11;

wire n_7;
wire n_10;
wire n_5;
wire n_6;
wire n_3;
wire n_9;
wire n_2;
wire n_4;
wire n_8;

INVx1_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

INVx4_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

OR2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_1),
.Y(n_4)
);

OA21x2_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_3),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AOI221xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_6),
.B1(n_2),
.B2(n_3),
.C(n_0),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.B1(n_5),
.B2(n_0),
.Y(n_10)
);

AOI21xp33_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_1),
.B(n_4),
.Y(n_11)
);


endmodule