module fake_netlist_777_4463_n_7 (n_1, n_2, n_0, n_7);

input n_1;
input n_2;
input n_0;

output n_7;

wire n_5;
wire n_6;
wire n_3;
wire n_4;

AND2x2_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

AND2x4_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);

A2O1A1O1Ixp25_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B(n_1),
.C(n_2),
.D(n_3),
.Y(n_5)
);

INVxp67_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);

OAI22xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_2),
.B1(n_4),
.B2(n_5),
.Y(n_7)
);


endmodule