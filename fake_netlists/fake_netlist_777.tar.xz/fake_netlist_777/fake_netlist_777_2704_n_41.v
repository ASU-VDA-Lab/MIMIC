module fake_netlist_777_2704_n_41 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_41);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_41;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_12;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_2),
.B(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_3),
.B(n_9),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_8),
.B(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_4),
.B(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_1),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_14),
.B(n_0),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_12),
.B(n_19),
.Y(n_23)
);

O2A1O1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_24)
);

AO21x1_ASAP7_75t_L g25 ( 
.A1(n_18),
.A2(n_7),
.B(n_6),
.Y(n_25)
);

OAI222xp33_ASAP7_75t_L g26 ( 
.A1(n_22),
.A2(n_13),
.B1(n_15),
.B2(n_16),
.C1(n_20),
.C2(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_25),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_15),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_29),
.Y(n_32)
);

AOI21xp33_ASAP7_75t_SL g33 ( 
.A1(n_30),
.A2(n_29),
.B(n_28),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

OAI21x1_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_27),
.B(n_28),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_30),
.Y(n_36)
);

NAND2x1_ASAP7_75t_SL g37 ( 
.A(n_34),
.B(n_30),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

CKINVDCx20_ASAP7_75t_R g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_26),
.B1(n_31),
.B2(n_35),
.C1(n_37),
.C2(n_40),
.Y(n_41)
);


endmodule