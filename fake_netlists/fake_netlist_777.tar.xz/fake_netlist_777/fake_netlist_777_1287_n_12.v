module fake_netlist_777_1287_n_12 (n_1, n_0, n_3, n_2, n_4, n_12);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_12;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_9;
wire n_8;

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_0),
.B(n_3),
.Y(n_5)
);

AOI21xp5_ASAP7_75t_L g6 ( 
.A1(n_2),
.A2(n_0),
.B(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_SL g7 ( 
.A(n_4),
.B(n_1),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

O2A1O1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B(n_7),
.C(n_5),
.Y(n_11)
);

OA22x2_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_9),
.B2(n_10),
.Y(n_12)
);


endmodule