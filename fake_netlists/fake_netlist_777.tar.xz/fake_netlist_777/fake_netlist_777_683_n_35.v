module fake_netlist_777_683_n_35 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_35);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_35;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_26;
wire n_24;
wire n_18;
wire n_13;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_10),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_11),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_9),
.Y(n_16)
);

AOI21x1_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_3),
.B(n_8),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_0),
.Y(n_19)
);

AND2x6_ASAP7_75t_SL g20 ( 
.A(n_15),
.B(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_2),
.B(n_1),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_SL g23 ( 
.A1(n_19),
.A2(n_18),
.B(n_17),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_21),
.B(n_16),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

INVxp67_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_14),
.B1(n_12),
.B2(n_15),
.C(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_23),
.B1(n_13),
.B2(n_22),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_24),
.Y(n_30)
);

O2A1O1Ixp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_17),
.B(n_20),
.C(n_1),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OA22x2_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_20),
.B1(n_31),
.B2(n_17),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_6),
.B1(n_7),
.B2(n_34),
.Y(n_35)
);


endmodule