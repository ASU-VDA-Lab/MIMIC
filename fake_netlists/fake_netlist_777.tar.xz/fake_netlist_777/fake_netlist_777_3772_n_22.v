module fake_netlist_777_3772_n_22 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_22);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_22;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_21;
wire n_14;

CKINVDCx6p67_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_10),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_5),
.Y(n_13)
);

OAI21xp33_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_1),
.B(n_4),
.Y(n_14)
);

OR2x6_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_7),
.Y(n_15)
);

CKINVDCx14_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.C(n_14),
.Y(n_19)
);

NOR4xp75_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_13),
.C(n_6),
.D(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2x1p5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_8),
.Y(n_22)
);


endmodule