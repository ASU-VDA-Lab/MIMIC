module fake_netlist_777_1390_n_16 (n_1, n_2, n_3, n_0, n_16);

input n_1;
input n_2;
input n_3;
input n_0;

output n_16;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_5;
wire n_6;
wire n_14;
wire n_9;
wire n_12;
wire n_13;
wire n_4;
wire n_8;

INVx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_1),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.Y(n_8)
);

NAND2x1p5_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_1),
.Y(n_9)
);

INVxp67_ASAP7_75t_SL g10 ( 
.A(n_7),
.Y(n_10)
);

AO21x2_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_5),
.B(n_0),
.Y(n_11)
);

AOI321xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_8),
.A3(n_3),
.B1(n_0),
.B2(n_2),
.C(n_9),
.Y(n_12)
);

NOR4xp25_ASAP7_75t_SL g13 ( 
.A(n_10),
.B(n_11),
.C(n_2),
.D(n_8),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_11),
.B1(n_13),
.B2(n_10),
.C(n_8),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B(n_10),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);


endmodule