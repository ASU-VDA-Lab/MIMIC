module fake_netlist_639_2385_n_55 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_55);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_55;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_23;
wire n_48;
wire n_39;
wire n_17;
wire n_22;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

AND2x4_ASAP7_75t_L g17 ( 
.A(n_8),
.B(n_5),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_10),
.B(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_16),
.B(n_7),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

NAND2x1p5_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_19),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_26),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_18),
.B(n_20),
.C(n_24),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_27),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_25),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

OAI211xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_31),
.B(n_28),
.C(n_21),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_35),
.Y(n_38)
);

NOR2x1_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_19),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

INVxp67_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

NOR2x1_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_37),
.Y(n_42)
);

OAI221xp5_ASAP7_75t_SL g43 ( 
.A1(n_38),
.A2(n_22),
.B1(n_35),
.B2(n_17),
.C(n_15),
.Y(n_43)
);

INVx1_ASAP7_75t_SL g44 ( 
.A(n_38),
.Y(n_44)
);

OAI22x1_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_17),
.B1(n_22),
.B2(n_14),
.Y(n_45)
);

CKINVDCx16_ASAP7_75t_R g46 ( 
.A(n_44),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_8),
.Y(n_47)
);

NAND4xp25_ASAP7_75t_SL g48 ( 
.A(n_43),
.B(n_15),
.C(n_6),
.D(n_1),
.Y(n_48)
);

NOR3xp33_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_47),
.C(n_46),
.Y(n_49)
);

XOR2xp5_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_9),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_46),
.Y(n_51)
);

AND2x4_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_2),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

OAI21x1_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_4),
.B(n_11),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_SL g55 ( 
.A1(n_54),
.A2(n_51),
.B1(n_52),
.B2(n_53),
.Y(n_55)
);


endmodule