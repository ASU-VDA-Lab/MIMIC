module fake_netlist_639_2353_n_12 (n_4, n_1, n_2, n_0, n_3, n_12);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_12;

wire n_7;
wire n_5;
wire n_10;
wire n_11;
wire n_8;
wire n_6;
wire n_9;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

AND2x4_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_4),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_SL g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI211xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B(n_6),
.C(n_0),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_2),
.C(n_3),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI21xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_2),
.B(n_3),
.Y(n_12)
);


endmodule