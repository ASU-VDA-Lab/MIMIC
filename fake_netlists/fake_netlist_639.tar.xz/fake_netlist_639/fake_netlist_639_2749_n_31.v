module fake_netlist_639_2749_n_31 (n_4, n_1, n_2, n_0, n_5, n_3, n_31);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_31;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_11;
wire n_7;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_26;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

AND2x2_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_5),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_3),
.Y(n_10)
);

O2A1O1Ixp5_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_1),
.B(n_3),
.C(n_0),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_10),
.Y(n_13)
);

OAI21xp33_ASAP7_75t_SL g14 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_8),
.B1(n_6),
.B2(n_9),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_8),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_9),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_9),
.Y(n_20)
);

OAI21xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_20),
.B(n_18),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_15),
.B(n_10),
.C(n_12),
.Y(n_22)
);

AOI222xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_12),
.B1(n_7),
.B2(n_21),
.C1(n_15),
.C2(n_20),
.Y(n_23)
);

AOI21xp33_ASAP7_75t_SL g24 ( 
.A1(n_21),
.A2(n_7),
.B(n_9),
.Y(n_24)
);

AOI221x1_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_11),
.B1(n_5),
.B2(n_4),
.C(n_2),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_11),
.C(n_5),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_25),
.Y(n_28)
);

AOI21xp33_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_28),
.B(n_2),
.Y(n_29)
);

OAI21xp5_ASAP7_75t_SL g30 ( 
.A1(n_26),
.A2(n_25),
.B(n_4),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_27),
.B2(n_4),
.Y(n_31)
);


endmodule