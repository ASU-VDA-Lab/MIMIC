module fake_netlist_639_2454_n_63 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_63);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_63;

wire n_36;
wire n_59;
wire n_62;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_60;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;
wire n_61;

AND2x2_ASAP7_75t_L g20 ( 
.A(n_0),
.B(n_11),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_1),
.B(n_8),
.Y(n_22)
);

AND2x6_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_15),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_17),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_3),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_10),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_21),
.B(n_18),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_26),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_29),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_20),
.B(n_22),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_30),
.B(n_23),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_30),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_34),
.Y(n_39)
);

BUFx3_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_34),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_27),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_SL g45 ( 
.A1(n_42),
.A2(n_43),
.B(n_41),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_40),
.B1(n_36),
.B2(n_23),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

NOR2x1p5_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_40),
.Y(n_50)
);

AOI222xp33_ASAP7_75t_L g51 ( 
.A1(n_45),
.A2(n_33),
.B1(n_26),
.B2(n_23),
.C1(n_22),
.C2(n_30),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_46),
.B(n_23),
.Y(n_52)
);

NOR4xp75_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_33),
.C(n_16),
.D(n_9),
.Y(n_53)
);

NOR2x1_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_48),
.Y(n_54)
);

NOR3xp33_ASAP7_75t_SL g55 ( 
.A(n_49),
.B(n_17),
.C(n_9),
.Y(n_55)
);

NOR3xp33_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_16),
.C(n_12),
.Y(n_56)
);

NAND3xp33_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_28),
.C(n_24),
.Y(n_57)
);

BUFx2_ASAP7_75t_SL g58 ( 
.A(n_54),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_24),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

AOI22x1_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_53),
.B1(n_13),
.B2(n_14),
.Y(n_61)
);

OAI22xp5_ASAP7_75t_L g62 ( 
.A1(n_59),
.A2(n_5),
.B1(n_7),
.B2(n_2),
.Y(n_62)
);

NAND3xp33_ASAP7_75t_R g63 ( 
.A(n_61),
.B(n_60),
.C(n_62),
.Y(n_63)
);


endmodule