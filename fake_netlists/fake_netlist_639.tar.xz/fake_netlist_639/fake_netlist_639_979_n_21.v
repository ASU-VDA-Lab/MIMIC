module fake_netlist_639_979_n_21 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_21);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_11;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

INVxp67_ASAP7_75t_SL g13 ( 
.A(n_9),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_5),
.B1(n_10),
.B2(n_6),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND4xp25_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.C(n_4),
.D(n_3),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_1),
.Y(n_19)
);

XNOR2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_0),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_2),
.B1(n_19),
.B2(n_17),
.Y(n_21)
);


endmodule