module fake_netlist_639_1389_n_47 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_47);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_47;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_23;
wire n_39;
wire n_22;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

INVx1_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_7),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

AND2x2_ASAP7_75t_SL g23 ( 
.A(n_12),
.B(n_17),
.Y(n_23)
);

AND2x6_ASAP7_75t_L g24 ( 
.A(n_13),
.B(n_2),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_5),
.B(n_11),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

AND2x6_ASAP7_75t_L g28 ( 
.A(n_8),
.B(n_6),
.Y(n_28)
);

AND2x2_ASAP7_75t_SL g29 ( 
.A(n_23),
.B(n_19),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_19),
.B1(n_10),
.B2(n_15),
.Y(n_30)
);

A2O1A1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_21),
.A2(n_10),
.B(n_3),
.C(n_1),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_27),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI31xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_30),
.A3(n_26),
.B(n_20),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

OAI211xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.B(n_21),
.C(n_22),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_16),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_24),
.C(n_28),
.Y(n_43)
);

AO21x2_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_42),
.B(n_28),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

INVx2_ASAP7_75t_SL g46 ( 
.A(n_45),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_44),
.B1(n_25),
.B2(n_4),
.Y(n_47)
);


endmodule