module fake_netlist_639_308_n_54 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_54);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_54;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx3_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_8),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_13),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_12),
.B(n_21),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_6),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_7),
.B(n_2),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_9),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_5),
.B(n_18),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

OAI22xp33_ASAP7_75t_SL g38 ( 
.A1(n_34),
.A2(n_25),
.B1(n_28),
.B2(n_26),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_25),
.B1(n_30),
.B2(n_31),
.Y(n_39)
);

OAI222xp33_ASAP7_75t_L g40 ( 
.A1(n_35),
.A2(n_33),
.B1(n_31),
.B2(n_23),
.C1(n_12),
.C2(n_22),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_36),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_43),
.Y(n_45)
);

INVxp67_ASAP7_75t_SL g46 ( 
.A(n_44),
.Y(n_46)
);

OAI32xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_41),
.A3(n_40),
.B1(n_23),
.B2(n_22),
.Y(n_47)
);

OAI22xp33_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_24),
.B1(n_15),
.B2(n_14),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_R g49 ( 
.A(n_47),
.B(n_20),
.Y(n_49)
);

NAND4xp75_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_24),
.C(n_46),
.D(n_10),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_11),
.B1(n_4),
.B2(n_3),
.Y(n_51)
);

OAI21xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_51),
.B(n_49),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_1),
.B1(n_16),
.B2(n_0),
.Y(n_54)
);


endmodule