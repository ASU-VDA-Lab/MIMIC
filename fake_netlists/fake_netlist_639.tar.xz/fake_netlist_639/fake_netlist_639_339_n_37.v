module fake_netlist_639_339_n_37 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_11, n_8, n_6, n_3, n_37);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_11;
input n_8;
input n_6;
input n_3;

output n_37;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_13;

AND2x6_ASAP7_75t_L g12 ( 
.A(n_4),
.B(n_3),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_4),
.B(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_7),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

OAI21x1_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_19),
.B(n_16),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_12),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_12),
.B(n_7),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_17),
.B(n_18),
.Y(n_23)
);

OAI21xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_13),
.B(n_12),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_23),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_23),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_21),
.Y(n_28)
);

O2A1O1Ixp33_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_24),
.B(n_26),
.C(n_25),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

OAI21xp5_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_27),
.B(n_12),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_29),
.B(n_12),
.C(n_8),
.Y(n_33)
);

NAND2xp33_ASAP7_75t_R g34 ( 
.A(n_32),
.B(n_11),
.Y(n_34)
);

OR5x1_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_34),
.C(n_6),
.D(n_5),
.E(n_2),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_1),
.Y(n_36)
);

AOI222xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_36),
.B1(n_5),
.B2(n_0),
.C1(n_2),
.C2(n_1),
.Y(n_37)
);


endmodule