module fake_netlist_639_2848_n_26 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_26);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_26;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_13;

BUFx6f_ASAP7_75t_SL g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_11),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_5),
.A2(n_10),
.B(n_9),
.Y(n_17)
);

AO21x1_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_0),
.B(n_8),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_16),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_14),
.B1(n_17),
.B2(n_18),
.Y(n_23)
);

BUFx12f_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AO21x2_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_1),
.B(n_3),
.Y(n_25)
);

OAI31xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_0),
.A3(n_2),
.B(n_12),
.Y(n_26)
);


endmodule