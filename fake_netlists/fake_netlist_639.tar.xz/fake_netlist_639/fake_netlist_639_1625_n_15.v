module fake_netlist_639_1625_n_15 (n_3, n_1, n_2, n_0, n_15);

input n_3;
input n_1;
input n_2;
input n_0;

output n_15;

wire n_4;
wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;
wire n_9;

BUFx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_0),
.Y(n_6)
);

CKINVDCx6p67_ASAP7_75t_R g7 ( 
.A(n_5),
.Y(n_7)
);

BUFx3_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

OAI22xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_7),
.B1(n_6),
.B2(n_10),
.Y(n_11)
);

INVxp67_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

A2O1A1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_4),
.B(n_7),
.C(n_11),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI21xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_2),
.B(n_3),
.Y(n_15)
);


endmodule