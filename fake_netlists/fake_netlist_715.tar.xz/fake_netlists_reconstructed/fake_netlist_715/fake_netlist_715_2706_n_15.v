module fake_netlist_715_2706_n_15 (n_0, n_3, n_2, n_1, n_15);

input n_0;
input n_3;
input n_2;
input n_1;

output n_15;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_14;
wire n_6;
wire n_4;
wire n_5;

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

AND2x4_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVxp67_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

OAI31xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_6),
.A3(n_2),
.B(n_7),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_6),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AO22x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B1(n_2),
.B2(n_8),
.Y(n_13)
);

NAND2x1p5_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_7),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_SL g15 ( 
.A1(n_13),
.A2(n_3),
.B1(n_11),
.B2(n_14),
.Y(n_15)
);


endmodule