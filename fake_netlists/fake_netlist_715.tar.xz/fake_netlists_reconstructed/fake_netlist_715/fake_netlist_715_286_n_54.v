module fake_netlist_715_286_n_54 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_17, n_5, n_54);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_17;
input n_5;

output n_54;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_43;
wire n_18;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_52;
wire n_25;
wire n_46;
wire n_23;
wire n_21;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_22;
wire n_19;

AND2x2_ASAP7_75t_L g18 ( 
.A(n_1),
.B(n_13),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_4),
.B(n_9),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_SL g20 ( 
.A(n_5),
.B(n_9),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

BUFx8_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

OA21x2_ASAP7_75t_L g25 ( 
.A1(n_17),
.A2(n_10),
.B(n_0),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_SL g26 ( 
.A(n_20),
.B(n_18),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

OAI21xp33_ASAP7_75t_SL g29 ( 
.A1(n_18),
.A2(n_16),
.B(n_14),
.Y(n_29)
);

AO21x2_ASAP7_75t_L g30 ( 
.A1(n_26),
.A2(n_19),
.B(n_22),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_28),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_30),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_33),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_24),
.Y(n_38)
);

O2A1O1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_29),
.B(n_19),
.C(n_20),
.Y(n_39)
);

AOI21xp33_ASAP7_75t_SL g40 ( 
.A1(n_37),
.A2(n_29),
.B(n_36),
.Y(n_40)
);

INVx2_ASAP7_75t_SL g41 ( 
.A(n_38),
.Y(n_41)
);

CKINVDCx6p67_ASAP7_75t_R g42 ( 
.A(n_40),
.Y(n_42)
);

AOI322xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_24),
.A3(n_27),
.B1(n_21),
.B2(n_23),
.C1(n_16),
.C2(n_17),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_25),
.B1(n_21),
.B2(n_23),
.Y(n_44)
);

CKINVDCx16_ASAP7_75t_R g45 ( 
.A(n_44),
.Y(n_45)
);

NAND4xp75_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_25),
.C(n_12),
.D(n_15),
.Y(n_46)
);

NOR2x1_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_25),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_42),
.B(n_25),
.Y(n_48)
);

AO21x2_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_25),
.B(n_3),
.Y(n_49)
);

OAI21xp5_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_11),
.B(n_21),
.Y(n_50)
);

OAI22xp5_ASAP7_75t_SL g51 ( 
.A1(n_45),
.A2(n_21),
.B1(n_11),
.B2(n_2),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

XNOR2xp5_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_48),
.Y(n_53)
);

AOI322xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_8),
.A3(n_21),
.B1(n_47),
.B2(n_49),
.C1(n_50),
.C2(n_52),
.Y(n_54)
);


endmodule