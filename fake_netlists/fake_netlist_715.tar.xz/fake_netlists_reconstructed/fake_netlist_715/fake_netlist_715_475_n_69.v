module fake_netlist_715_475_n_69 (n_3, n_14, n_20, n_0, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_25, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_69);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_25;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_69;

wire n_60;
wire n_32;
wire n_33;
wire n_48;
wire n_61;
wire n_30;
wire n_63;
wire n_35;
wire n_54;
wire n_68;
wire n_27;
wire n_37;
wire n_36;
wire n_29;
wire n_41;
wire n_66;
wire n_55;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_57;
wire n_65;
wire n_46;
wire n_56;
wire n_47;
wire n_67;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_64;
wire n_62;
wire n_50;
wire n_38;
wire n_49;
wire n_40;
wire n_34;
wire n_51;
wire n_59;
wire n_58;

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_14),
.B(n_5),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_2),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_10),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_22),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_0),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_17),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_13),
.B(n_12),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_20),
.B(n_25),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_21),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_8),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_33),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_28),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_38),
.B(n_25),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_30),
.Y(n_43)
);

OAI21x1_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_26),
.B(n_35),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_39),
.Y(n_45)
);

OAI21x1_ASAP7_75t_L g46 ( 
.A1(n_40),
.A2(n_36),
.B(n_29),
.Y(n_46)
);

NOR2x1_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_32),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

AND2x4_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_42),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_31),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

OAI221xp5_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_27),
.B1(n_29),
.B2(n_34),
.C(n_41),
.Y(n_54)
);

NOR2x1_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_41),
.Y(n_55)
);

NOR2xp33_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_27),
.Y(n_56)
);

INVxp33_ASAP7_75t_SL g57 ( 
.A(n_55),
.Y(n_57)
);

XNOR2x1_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_46),
.Y(n_58)
);

NAND2xp33_ASAP7_75t_R g59 ( 
.A(n_53),
.B(n_46),
.Y(n_59)
);

NAND5xp2_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_13),
.C(n_24),
.D(n_23),
.E(n_18),
.Y(n_60)
);

OAI21xp33_ASAP7_75t_SL g61 ( 
.A1(n_58),
.A2(n_19),
.B(n_11),
.Y(n_61)
);

AOI21xp5_ASAP7_75t_L g62 ( 
.A1(n_57),
.A2(n_16),
.B(n_7),
.Y(n_62)
);

CKINVDCx5p33_ASAP7_75t_R g63 ( 
.A(n_59),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_63),
.Y(n_64)
);

NOR2xp33_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_61),
.Y(n_65)
);

AOI22xp33_ASAP7_75t_L g66 ( 
.A1(n_62),
.A2(n_3),
.B1(n_6),
.B2(n_4),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_64),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_65),
.Y(n_68)
);

AOI22xp33_ASAP7_75t_L g69 ( 
.A1(n_68),
.A2(n_67),
.B1(n_66),
.B2(n_1),
.Y(n_69)
);


endmodule