module fake_netlist_715_1197_n_17 (n_1, n_2, n_0, n_3, n_4, n_17);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_17;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_15;
wire n_16;
wire n_6;
wire n_14;
wire n_5;

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

A2O1A1Ixp33_ASAP7_75t_L g6 ( 
.A1(n_1),
.A2(n_2),
.B(n_3),
.C(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

AO31x2_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.A3(n_3),
.B(n_2),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_2),
.B(n_3),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_5),
.Y(n_10)
);

BUFx3_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AOI32xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.A3(n_9),
.B1(n_8),
.B2(n_0),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_8),
.B1(n_0),
.B2(n_4),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

OAI21xp33_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_11),
.B(n_8),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_11),
.B1(n_15),
.B2(n_10),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);


endmodule