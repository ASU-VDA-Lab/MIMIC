module fake_netlist_715_2873_n_44 (n_12, n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_44);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_44;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_13;
wire n_43;
wire n_31;
wire n_18;
wire n_39;
wire n_28;
wire n_25;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_12),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_2),
.B(n_4),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_9),
.Y(n_20)
);

NAND3xp33_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_12),
.C(n_9),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

BUFx12f_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_11),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

OAI22xp33_ASAP7_75t_L g27 ( 
.A1(n_21),
.A2(n_24),
.B1(n_25),
.B2(n_22),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_14),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_14),
.Y(n_31)
);

AOI33xp33_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_16),
.A3(n_15),
.B1(n_17),
.B2(n_10),
.B3(n_11),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AO21x2_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_27),
.B(n_26),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND3xp33_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_32),
.C(n_18),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_26),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

AND3x4_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_37),
.C(n_10),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

OR3x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_1),
.C(n_3),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_43),
.A2(n_28),
.B1(n_42),
.B2(n_41),
.Y(n_44)
);


endmodule