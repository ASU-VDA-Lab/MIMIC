module fake_netlist_715_2026_n_54 (n_3, n_14, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_5, n_54);

input n_3;
input n_14;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_5;

output n_54;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_24;
wire n_37;
wire n_29;
wire n_36;
wire n_41;
wire n_43;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_52;
wire n_25;
wire n_22;
wire n_46;
wire n_23;
wire n_21;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_26;
wire n_19;

INVx1_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_6),
.B(n_10),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_7),
.B(n_2),
.Y(n_21)
);

AOI22x1_ASAP7_75t_SL g22 ( 
.A1(n_16),
.A2(n_18),
.B1(n_17),
.B2(n_11),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_16),
.B(n_10),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_15),
.B(n_9),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_3),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_20),
.B(n_21),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_29),
.B(n_27),
.Y(n_34)
);

INVxp67_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_28),
.Y(n_37)
);

AND3x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_28),
.C(n_24),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_36),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_32),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_32),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_19),
.B1(n_25),
.B2(n_24),
.C(n_32),
.Y(n_44)
);

AO22x2_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_22),
.B1(n_40),
.B2(n_19),
.Y(n_45)
);

OAI211xp5_ASAP7_75t_SL g46 ( 
.A1(n_43),
.A2(n_29),
.B(n_22),
.C(n_36),
.Y(n_46)
);

AOI322xp5_ASAP7_75t_L g47 ( 
.A1(n_41),
.A2(n_23),
.A3(n_17),
.B1(n_13),
.B2(n_14),
.C1(n_11),
.C2(n_18),
.Y(n_47)
);

NAND4xp75_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_44),
.C(n_45),
.D(n_46),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_38),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_44),
.Y(n_50)
);

AOI222xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_33),
.B1(n_12),
.B2(n_9),
.C1(n_13),
.C2(n_14),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_0),
.B1(n_8),
.B2(n_33),
.Y(n_52)
);

XNOR2xp5_ASAP7_75t_L g53 ( 
.A(n_52),
.B(n_49),
.Y(n_53)
);

AOI221xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_51),
.B1(n_8),
.B2(n_0),
.C(n_4),
.Y(n_54)
);


endmodule