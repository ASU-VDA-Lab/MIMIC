module fake_netlist_715_1200_n_45 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_45);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_45;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_43;
wire n_18;
wire n_31;
wire n_28;
wire n_39;
wire n_25;
wire n_22;
wire n_23;
wire n_15;
wire n_21;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_16;
wire n_26;
wire n_19;

AND2x2_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_7),
.Y(n_14)
);

BUFx8_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

AND2x6_ASAP7_75t_L g16 ( 
.A(n_0),
.B(n_12),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_7),
.Y(n_21)
);

BUFx8_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_13),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_14),
.B(n_17),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_27),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_SL g33 ( 
.A(n_30),
.B(n_20),
.Y(n_33)
);

NOR4xp25_ASAP7_75t_SL g34 ( 
.A(n_33),
.B(n_22),
.C(n_25),
.D(n_16),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

AOI222xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_22),
.B1(n_16),
.B2(n_15),
.C1(n_11),
.C2(n_9),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI21xp5_ASAP7_75t_SL g38 ( 
.A1(n_35),
.A2(n_1),
.B(n_4),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NOR2x1_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_34),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_16),
.B(n_2),
.Y(n_41)
);

OAI21xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_38),
.B(n_16),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

NOR2xp67_ASAP7_75t_SL g45 ( 
.A(n_44),
.B(n_42),
.Y(n_45)
);


endmodule