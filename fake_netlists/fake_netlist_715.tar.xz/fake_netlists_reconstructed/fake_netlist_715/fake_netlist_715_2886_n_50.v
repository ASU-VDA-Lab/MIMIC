module fake_netlist_715_2886_n_50 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_5, n_50);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_50;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_43;
wire n_18;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_25;
wire n_22;
wire n_46;
wire n_23;
wire n_21;
wire n_47;
wire n_44;
wire n_42;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_26;
wire n_19;

INVx2_ASAP7_75t_SL g17 ( 
.A(n_8),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_7),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_9),
.B(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_2),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_16),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

INVx4_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_19),
.B1(n_17),
.B2(n_23),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_24),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_29),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_32),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_35),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_22),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

NAND2x1_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_21),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NOR3xp33_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_25),
.C(n_30),
.Y(n_46)
);

NOR3xp33_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_46),
.C(n_44),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_30),
.Y(n_48)
);

OR5x1_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_16),
.C(n_9),
.D(n_4),
.E(n_12),
.Y(n_49)
);

AOI322xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_48),
.A3(n_27),
.B1(n_11),
.B2(n_10),
.C1(n_6),
.C2(n_3),
.Y(n_50)
);


endmodule