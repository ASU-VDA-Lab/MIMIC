module fake_netlist_715_1816_n_22 (n_8, n_1, n_2, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_22);

input n_8;
input n_1;
input n_2;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_22;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_15;
wire n_21;
wire n_16;
wire n_19;

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_2),
.B(n_9),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_6),
.A2(n_2),
.B1(n_0),
.B2(n_4),
.Y(n_14)
);

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_11),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_1),
.B(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AOI32xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.A3(n_16),
.B1(n_13),
.B2(n_12),
.Y(n_18)
);

AND3x1_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.C(n_17),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.C(n_7),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_3),
.Y(n_21)
);

OR2x6_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_8),
.Y(n_22)
);


endmodule