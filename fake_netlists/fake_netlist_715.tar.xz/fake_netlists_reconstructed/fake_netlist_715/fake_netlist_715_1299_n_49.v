module fake_netlist_715_1299_n_49 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_19, n_5, n_49);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_19;
input n_5;

output n_49;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_24;
wire n_37;
wire n_29;
wire n_41;
wire n_43;
wire n_31;
wire n_39;
wire n_28;
wire n_45;
wire n_25;
wire n_46;
wire n_23;
wire n_21;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_22;

INVx1_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_19),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_12),
.B(n_0),
.Y(n_26)
);

AND3x2_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_1),
.C(n_10),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_2),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_7),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_26),
.B1(n_24),
.B2(n_22),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_22),
.B(n_20),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_25),
.B(n_20),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_32),
.Y(n_34)
);

AO32x2_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_27),
.A3(n_23),
.B1(n_25),
.B2(n_21),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_37),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

OAI21xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.B(n_33),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_28),
.B1(n_29),
.B2(n_30),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

AOI222xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_9),
.B1(n_19),
.B2(n_18),
.C1(n_4),
.C2(n_17),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_9),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_18),
.B1(n_8),
.B2(n_13),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_46),
.B1(n_6),
.B2(n_15),
.Y(n_49)
);


endmodule