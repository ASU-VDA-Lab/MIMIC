module fake_netlist_715_797_n_57 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_6, n_14, n_0, n_3, n_4, n_5, n_57);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_57;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_20;
wire n_27;
wire n_17;
wire n_37;
wire n_36;
wire n_29;
wire n_41;
wire n_24;
wire n_55;
wire n_43;
wire n_31;
wire n_18;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_25;
wire n_22;
wire n_46;
wire n_23;
wire n_56;
wire n_21;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_16;
wire n_26;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_14),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

CKINVDCx8_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_11),
.B(n_1),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_15),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_16),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_17),
.B(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_22),
.B(n_14),
.Y(n_29)
);

OA21x2_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_18),
.B(n_19),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_25),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_28),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_30),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_30),
.Y(n_40)
);

AOI21xp33_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_23),
.B(n_34),
.Y(n_41)
);

OAI21xp33_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_20),
.B(n_23),
.Y(n_42)
);

AOI21xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_42),
.B(n_39),
.Y(n_43)
);

AOI222xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_17),
.B1(n_22),
.B2(n_31),
.C1(n_27),
.C2(n_24),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_39),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_34),
.B1(n_30),
.B2(n_24),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

NOR3xp33_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_34),
.C(n_9),
.Y(n_48)
);

AND3x2_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_10),
.C(n_6),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_24),
.Y(n_50)
);

NOR3xp33_ASAP7_75t_L g51 ( 
.A(n_43),
.B(n_13),
.C(n_6),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_51),
.Y(n_53)
);

AOI21xp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_24),
.B(n_0),
.Y(n_54)
);

NOR3xp33_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_13),
.C(n_11),
.Y(n_55)
);

AOI222xp33_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_49),
.B1(n_55),
.B2(n_53),
.C1(n_54),
.C2(n_7),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_8),
.B1(n_5),
.B2(n_3),
.Y(n_57)
);


endmodule