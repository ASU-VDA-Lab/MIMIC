module fake_netlist_715_2645_n_89 (n_3, n_14, n_20, n_0, n_27, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_25, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_26, n_16, n_22, n_6, n_19, n_5, n_89);

input n_3;
input n_14;
input n_20;
input n_0;
input n_27;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_25;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_26;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_89;

wire n_68;
wire n_82;
wire n_37;
wire n_31;
wire n_39;
wire n_65;
wire n_56;
wire n_62;
wire n_69;
wire n_55;
wire n_60;
wire n_33;
wire n_61;
wire n_75;
wire n_79;
wire n_30;
wire n_54;
wire n_73;
wire n_77;
wire n_85;
wire n_70;
wire n_67;
wire n_81;
wire n_44;
wire n_74;
wire n_53;
wire n_64;
wire n_49;
wire n_40;
wire n_51;
wire n_59;
wire n_84;
wire n_32;
wire n_48;
wire n_35;
wire n_41;
wire n_76;
wire n_57;
wire n_43;
wire n_71;
wire n_80;
wire n_87;
wire n_42;
wire n_34;
wire n_58;
wire n_86;
wire n_72;
wire n_63;
wire n_36;
wire n_29;
wire n_66;
wire n_83;
wire n_45;
wire n_28;
wire n_52;
wire n_78;
wire n_46;
wire n_88;
wire n_47;
wire n_50;
wire n_38;

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_13),
.A2(n_20),
.B1(n_2),
.B2(n_9),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_7),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_14),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_12),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_5),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_1),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_11),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_8),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_16),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_17),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_15),
.B(n_25),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_6),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_30),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_29),
.B(n_27),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_27),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_32),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_29),
.B(n_42),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_40),
.B(n_24),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_34),
.B(n_24),
.Y(n_49)
);

BUFx6f_ASAP7_75t_L g50 ( 
.A(n_31),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_SL g51 ( 
.A1(n_44),
.A2(n_33),
.B1(n_39),
.B2(n_37),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

OAI21xp5_ASAP7_75t_SL g54 ( 
.A1(n_49),
.A2(n_33),
.B(n_38),
.Y(n_54)
);

BUFx12f_ASAP7_75t_L g55 ( 
.A(n_45),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_51),
.B(n_46),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_52),
.Y(n_59)
);

OAI32xp33_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_47),
.A3(n_48),
.B1(n_43),
.B2(n_52),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_59),
.Y(n_61)
);

NAND2x1p5_ASAP7_75t_SL g62 ( 
.A(n_57),
.B(n_54),
.Y(n_62)
);

INVxp67_ASAP7_75t_SL g63 ( 
.A(n_56),
.Y(n_63)
);

NAND4xp25_ASAP7_75t_L g64 ( 
.A(n_60),
.B(n_47),
.C(n_58),
.D(n_26),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_61),
.Y(n_65)
);

OAI22xp33_ASAP7_75t_L g66 ( 
.A1(n_63),
.A2(n_55),
.B1(n_35),
.B2(n_36),
.Y(n_66)
);

INVx2_ASAP7_75t_L g67 ( 
.A(n_61),
.Y(n_67)
);

OAI21xp33_ASAP7_75t_L g68 ( 
.A1(n_60),
.A2(n_62),
.B(n_36),
.Y(n_68)
);

NAND2xp5_ASAP7_75t_L g69 ( 
.A(n_65),
.B(n_62),
.Y(n_69)
);

OAI211xp5_ASAP7_75t_L g70 ( 
.A1(n_64),
.A2(n_68),
.B(n_67),
.C(n_28),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_66),
.Y(n_71)
);

AOI322xp5_ASAP7_75t_L g72 ( 
.A1(n_68),
.A2(n_55),
.A3(n_28),
.B1(n_23),
.B2(n_26),
.C1(n_14),
.C2(n_35),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_65),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_65),
.Y(n_74)
);

AND3x2_ASAP7_75t_L g75 ( 
.A(n_71),
.B(n_72),
.C(n_73),
.Y(n_75)
);

OR2x2_ASAP7_75t_L g76 ( 
.A(n_69),
.B(n_23),
.Y(n_76)
);

NOR2xp67_ASAP7_75t_L g77 ( 
.A(n_74),
.B(n_19),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_73),
.Y(n_78)
);

AOI22xp5_ASAP7_75t_L g79 ( 
.A1(n_70),
.A2(n_38),
.B1(n_36),
.B2(n_31),
.Y(n_79)
);

AND2x2_ASAP7_75t_L g80 ( 
.A(n_71),
.B(n_31),
.Y(n_80)
);

NOR4xp25_ASAP7_75t_L g81 ( 
.A(n_76),
.B(n_38),
.C(n_35),
.D(n_3),
.Y(n_81)
);

AND2x2_ASAP7_75t_L g82 ( 
.A(n_80),
.B(n_10),
.Y(n_82)
);

XOR2xp5_ASAP7_75t_L g83 ( 
.A(n_79),
.B(n_78),
.Y(n_83)
);

AOI21xp5_ASAP7_75t_SL g84 ( 
.A1(n_77),
.A2(n_75),
.B(n_50),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_75),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_85),
.Y(n_86)
);

OAI22xp5_ASAP7_75t_L g87 ( 
.A1(n_83),
.A2(n_18),
.B1(n_21),
.B2(n_0),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_81),
.Y(n_88)
);

AOI221xp5_ASAP7_75t_L g89 ( 
.A1(n_88),
.A2(n_84),
.B1(n_86),
.B2(n_87),
.C(n_82),
.Y(n_89)
);


endmodule