module fake_netlist_715_2421_n_13 (n_0, n_3, n_2, n_1, n_13);

input n_0;
input n_3;
input n_2;
input n_1;

output n_13;

wire n_12;
wire n_8;
wire n_11;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_4;
wire n_5;

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_2),
.B(n_3),
.Y(n_4)
);

BUFx3_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_2),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_5),
.B1(n_9),
.B2(n_8),
.C(n_3),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B1(n_2),
.B2(n_3),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_0),
.B1(n_1),
.B2(n_9),
.C1(n_10),
.C2(n_7),
.Y(n_13)
);


endmodule