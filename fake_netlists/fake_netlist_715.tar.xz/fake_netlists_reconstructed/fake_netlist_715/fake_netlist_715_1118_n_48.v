module fake_netlist_715_1118_n_48 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_6, n_14, n_0, n_3, n_4, n_5, n_48);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_48;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_43;
wire n_31;
wire n_18;
wire n_45;
wire n_28;
wire n_39;
wire n_25;
wire n_46;
wire n_23;
wire n_15;
wire n_21;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_16;
wire n_22;
wire n_19;

AND2x2_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_0),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_13),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_2),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_15),
.B(n_19),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_23),
.Y(n_26)
);

AO21x2_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_15),
.B(n_20),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

NOR2x1p5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_22),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_27),
.Y(n_30)
);

INVx2_ASAP7_75t_SL g31 ( 
.A(n_29),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_29),
.Y(n_32)
);

O2A1O1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_24),
.B(n_31),
.C(n_25),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_17),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_17),
.B1(n_21),
.B2(n_9),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

INVx3_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

NOR2x1_ASAP7_75t_SL g38 ( 
.A(n_35),
.B(n_21),
.Y(n_38)
);

CKINVDCx12_ASAP7_75t_R g39 ( 
.A(n_36),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_38),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_21),
.B1(n_5),
.B2(n_6),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_37),
.A2(n_21),
.B1(n_5),
.B2(n_6),
.C(n_1),
.Y(n_42)
);

NOR4xp25_ASAP7_75t_SL g43 ( 
.A(n_42),
.B(n_38),
.C(n_37),
.D(n_3),
.Y(n_43)
);

AOI21xp33_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_37),
.B(n_21),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_R g46 ( 
.A(n_45),
.B(n_39),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_3),
.B1(n_2),
.B2(n_4),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_44),
.A3(n_43),
.B1(n_46),
.B2(n_14),
.C1(n_7),
.C2(n_11),
.Y(n_48)
);


endmodule