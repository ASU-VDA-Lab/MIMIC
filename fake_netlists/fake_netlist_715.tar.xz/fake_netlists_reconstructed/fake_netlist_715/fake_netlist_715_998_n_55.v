module fake_netlist_715_998_n_55 (n_3, n_14, n_20, n_0, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_55);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_55;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_27;
wire n_37;
wire n_36;
wire n_29;
wire n_41;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_25;
wire n_46;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_26;

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_0),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_4),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_L g28 ( 
.A(n_14),
.B(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_3),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_6),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_10),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_7),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_26),
.B(n_12),
.Y(n_35)
);

A2O1A1Ixp33_ASAP7_75t_SL g36 ( 
.A1(n_32),
.A2(n_12),
.B(n_16),
.C(n_17),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_25),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_33),
.B(n_30),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AOI21x1_ASAP7_75t_L g40 ( 
.A1(n_34),
.A2(n_28),
.B(n_27),
.Y(n_40)
);

OR2x6_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_31),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_31),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_38),
.B1(n_36),
.B2(n_19),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_38),
.B1(n_22),
.B2(n_18),
.Y(n_48)
);

NOR2x1_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_23),
.Y(n_49)
);

NAND3xp33_ASAP7_75t_SL g50 ( 
.A(n_47),
.B(n_13),
.C(n_11),
.Y(n_50)
);

NAND2xp33_ASAP7_75t_R g51 ( 
.A(n_49),
.B(n_2),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

AOI21xp33_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_8),
.B(n_24),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_1),
.B1(n_9),
.B2(n_5),
.Y(n_54)
);

OR2x6_ASAP7_75t_L g55 ( 
.A(n_54),
.B(n_53),
.Y(n_55)
);


endmodule