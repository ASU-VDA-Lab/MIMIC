module fake_netlist_715_465_n_34 (n_8, n_1, n_2, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_34);

input n_8;
input n_1;
input n_2;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_34;

wire n_32;
wire n_33;
wire n_30;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_11;
wire n_25;
wire n_12;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

BUFx2_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

CKINVDCx8_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_11),
.B(n_15),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_14),
.B1(n_16),
.B2(n_13),
.C1(n_18),
.C2(n_8),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_14),
.B1(n_9),
.B2(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_16),
.B1(n_0),
.B2(n_6),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_16),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_9),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_3),
.B1(n_5),
.B2(n_1),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_3),
.B1(n_5),
.B2(n_1),
.C(n_4),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx8_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_27),
.Y(n_31)
);

OAI322xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_29),
.A3(n_25),
.B1(n_30),
.B2(n_10),
.C1(n_4),
.C2(n_8),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_7),
.B(n_33),
.Y(n_34)
);


endmodule