module fake_netlist_715_1674_n_49 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_6, n_19, n_5, n_49);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_6;
input n_19;
input n_5;

output n_49;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_37;
wire n_24;
wire n_29;
wire n_41;
wire n_43;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_25;
wire n_22;
wire n_46;
wire n_23;
wire n_47;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_26;

INVx2_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_10),
.B(n_8),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_11),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_3),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_11),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_7),
.Y(n_29)
);

BUFx3_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_25),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_29),
.B(n_21),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_27),
.B(n_23),
.Y(n_34)
);

O2A1O1Ixp33_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_23),
.B(n_26),
.C(n_21),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

OAI21xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_30),
.B(n_32),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_24),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_29),
.Y(n_39)
);

AOI21xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_35),
.B(n_15),
.Y(n_40)
);

OAI32xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_17),
.A3(n_14),
.B1(n_16),
.B2(n_13),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_18),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_9),
.B(n_6),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_SL g45 ( 
.A(n_42),
.B(n_1),
.C(n_5),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_SL g46 ( 
.A1(n_45),
.A2(n_42),
.B(n_19),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_46),
.B1(n_0),
.B2(n_2),
.Y(n_49)
);


endmodule