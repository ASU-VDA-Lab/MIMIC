module fake_netlist_715_691_n_24 (n_8, n_1, n_2, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_24);

input n_8;
input n_1;
input n_2;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_24;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_23;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

INVxp33_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_10),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_8),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_1),
.B(n_0),
.C(n_3),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_13),
.B(n_7),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_11),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_14),
.B1(n_12),
.B2(n_17),
.C(n_2),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_21),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_15),
.B1(n_2),
.B2(n_1),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_R g24 ( 
.A1(n_23),
.A2(n_4),
.B1(n_5),
.B2(n_6),
.Y(n_24)
);


endmodule