module fake_netlist_715_1171_n_26 (n_8, n_1, n_2, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_26);

input n_8;
input n_1;
input n_2;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_26;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_11;
wire n_25;
wire n_12;
wire n_23;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

XNOR2xp5_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_0),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_4),
.B(n_5),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_2),
.B(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_SL g17 ( 
.A1(n_13),
.A2(n_1),
.B(n_3),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_16),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_14),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NAND4xp25_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_19),
.C(n_11),
.D(n_12),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_20),
.B2(n_11),
.C(n_18),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_21),
.B(n_20),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_7),
.B1(n_10),
.B2(n_24),
.Y(n_26)
);


endmodule