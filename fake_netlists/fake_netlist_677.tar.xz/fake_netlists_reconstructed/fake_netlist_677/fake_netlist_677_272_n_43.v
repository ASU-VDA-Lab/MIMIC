module fake_netlist_677_272_n_43 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_43);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_43;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;

INVx1_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

INVx4_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_L g24 ( 
.A(n_5),
.B(n_18),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_23),
.B(n_26),
.Y(n_27)
);

O2A1O1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_15),
.B(n_11),
.C(n_14),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_19),
.A2(n_9),
.B1(n_6),
.B2(n_17),
.Y(n_29)
);

OAI21x1_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_25),
.B(n_22),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_20),
.B1(n_21),
.B2(n_4),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_2),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

BUFx8_ASAP7_75t_SL g36 ( 
.A(n_35),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_29),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_36),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_39),
.Y(n_40)
);

NOR3xp33_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_1),
.C(n_3),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);


endmodule