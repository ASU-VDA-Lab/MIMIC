module fake_netlist_677_1842_n_12 (n_3, n_0, n_2, n_1, n_12);

input n_3;
input n_0;
input n_2;
input n_1;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

OAI22xp33_ASAP7_75t_SL g4 ( 
.A1(n_1),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2x1p5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_2),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_2),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B1(n_3),
.B2(n_0),
.Y(n_9)
);

A2O1A1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_3),
.C(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_7),
.B2(n_9),
.Y(n_12)
);


endmodule