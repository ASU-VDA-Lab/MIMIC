module fake_netlist_677_1469_n_11 (n_3, n_0, n_2, n_1, n_11);

input n_3;
input n_0;
input n_2;
input n_1;

output n_11;

wire n_9;
wire n_4;
wire n_7;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

OAI22xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_4)
);

INVx4_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

A2O1A1Ixp33_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_0),
.B(n_2),
.C(n_3),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_5),
.B1(n_0),
.B2(n_2),
.Y(n_8)
);

OAI221xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.C(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_10),
.Y(n_11)
);


endmodule