module fake_netlist_677_167_n_51 (n_2, n_21, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_51);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_51;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_31;
wire n_23;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

INVx2_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_12),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_8),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_3),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_7),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_17),
.B(n_1),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

BUFx4f_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_24),
.B1(n_35),
.B2(n_33),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_32),
.A2(n_28),
.B1(n_30),
.B2(n_29),
.Y(n_37)
);

AO21x1_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_11),
.B(n_20),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_35),
.B1(n_34),
.B2(n_29),
.Y(n_39)
);

OAI31xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_11),
.A3(n_25),
.B(n_26),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_34),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_27),
.B(n_34),
.Y(n_43)
);

NOR3xp33_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_10),
.C(n_9),
.Y(n_44)
);

AOI322xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_2),
.A3(n_16),
.B1(n_14),
.B2(n_13),
.C1(n_5),
.C2(n_0),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_4),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_SL g47 ( 
.A(n_46),
.B(n_6),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

OR2x6_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_44),
.Y(n_50)
);

OAI21xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_18),
.B(n_49),
.Y(n_51)
);


endmodule