module fake_netlist_677_2456_n_56 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_56);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_56;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_16;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_19;
wire n_25;
wire n_48;
wire n_49;
wire n_13;
wire n_39;
wire n_14;
wire n_55;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_6),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_10),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_20),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_11),
.Y(n_23)
);

O2A1O1Ixp5_ASAP7_75t_L g24 ( 
.A1(n_13),
.A2(n_6),
.B(n_5),
.C(n_1),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_7),
.C(n_5),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_16),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_13),
.B(n_7),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_13),
.A2(n_5),
.B(n_4),
.Y(n_28)
);

NOR3xp33_ASAP7_75t_SL g29 ( 
.A(n_25),
.B(n_14),
.C(n_11),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_15),
.C(n_14),
.Y(n_31)
);

OR2x6_ASAP7_75t_L g32 ( 
.A(n_23),
.B(n_13),
.Y(n_32)
);

INVx8_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_R g34 ( 
.A(n_22),
.B(n_15),
.Y(n_34)
);

OR2x6_ASAP7_75t_L g35 ( 
.A(n_28),
.B(n_17),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_21),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_27),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_21),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_32),
.Y(n_39)
);

AND2x4_ASAP7_75t_SL g40 ( 
.A(n_32),
.B(n_18),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_39),
.B1(n_38),
.B2(n_36),
.Y(n_41)
);

AOI211xp5_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_31),
.B(n_34),
.C(n_30),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_29),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_29),
.B1(n_33),
.B2(n_12),
.Y(n_44)
);

NOR3xp33_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_24),
.C(n_19),
.Y(n_45)
);

NAND4xp25_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_33),
.C(n_0),
.D(n_4),
.Y(n_46)
);

AOI211xp5_ASAP7_75t_SL g47 ( 
.A1(n_43),
.A2(n_44),
.B(n_0),
.C(n_4),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_2),
.B(n_8),
.Y(n_48)
);

NOR2xp67_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_1),
.Y(n_49)
);

AO21x1_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_3),
.B(n_9),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_47),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_45),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

OAI22x1_ASAP7_75t_L g55 ( 
.A1(n_50),
.A2(n_3),
.B1(n_51),
.B2(n_52),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_49),
.B1(n_54),
.B2(n_53),
.Y(n_56)
);


endmodule