module fake_netlist_677_1507_n_22 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_22);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_22;

wire n_21;
wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_8;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_4),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_9),
.B(n_10),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_9),
.B(n_6),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_13),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_SL g15 ( 
.A(n_13),
.B(n_11),
.C(n_8),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B1(n_8),
.B2(n_14),
.C(n_2),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_1),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_2),
.B(n_3),
.C(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);


endmodule