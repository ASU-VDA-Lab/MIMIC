module fake_netlist_677_504_n_54 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_54);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_54;

wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_46;
wire n_31;
wire n_41;
wire n_29;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_14),
.A2(n_17),
.B(n_4),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_13),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_2),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_10),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_6),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_11),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_18),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_20),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_21),
.B(n_3),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_5),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_0),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

OR2x6_ASAP7_75t_L g37 ( 
.A(n_31),
.B(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_30),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_31),
.B(n_13),
.Y(n_39)
);

NAND2x1p5_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_33),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_35),
.Y(n_41)
);

OAI221xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_32),
.B1(n_27),
.B2(n_29),
.C(n_28),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_25),
.C(n_37),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_40),
.Y(n_46)
);

OA21x2_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_22),
.B(n_16),
.Y(n_47)
);

INVxp67_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_23),
.B1(n_15),
.B2(n_12),
.Y(n_49)
);

OAI22xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_8),
.B1(n_24),
.B2(n_9),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_50),
.Y(n_51)
);

BUFx2_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

CKINVDCx20_ASAP7_75t_R g53 ( 
.A(n_52),
.Y(n_53)
);

AOI22xp33_ASAP7_75t_SL g54 ( 
.A1(n_53),
.A2(n_51),
.B1(n_1),
.B2(n_7),
.Y(n_54)
);


endmodule