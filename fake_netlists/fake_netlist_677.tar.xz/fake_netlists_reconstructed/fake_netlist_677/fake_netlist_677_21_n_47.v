module fake_netlist_677_21_n_47 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_47);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_47;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_19;
wire n_25;
wire n_39;

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_3),
.A2(n_15),
.B(n_4),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_5),
.B(n_3),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_6),
.B(n_12),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_14),
.A2(n_2),
.B1(n_7),
.B2(n_13),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_18),
.B(n_9),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_16),
.B(n_11),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_16),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

OAI21x1_ASAP7_75t_SL g29 ( 
.A1(n_26),
.A2(n_17),
.B(n_21),
.Y(n_29)
);

AO31x2_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_24),
.A3(n_17),
.B(n_21),
.Y(n_30)
);

AO21x2_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_27),
.B(n_26),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_28),
.C(n_23),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_30),
.Y(n_38)
);

OAI211xp5_ASAP7_75t_SL g39 ( 
.A1(n_37),
.A2(n_32),
.B(n_29),
.C(n_30),
.Y(n_39)
);

OAI31xp33_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_27),
.A3(n_30),
.B(n_20),
.Y(n_40)
);

NOR3xp33_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_27),
.C(n_35),
.Y(n_41)
);

OAI221xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_38),
.B1(n_30),
.B2(n_19),
.C(n_9),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_30),
.Y(n_43)
);

OAI22x1_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_42),
.B1(n_41),
.B2(n_8),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_1),
.B(n_5),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

OAI22xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_45),
.B1(n_1),
.B2(n_0),
.Y(n_47)
);


endmodule