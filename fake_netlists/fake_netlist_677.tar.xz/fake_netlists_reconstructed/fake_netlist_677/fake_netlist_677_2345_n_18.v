module fake_netlist_677_2345_n_18 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_18);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_17;
wire n_9;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_1),
.B(n_5),
.Y(n_9)
);

INVx5_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

BUFx4f_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

NAND2x1p5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_7),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_6),
.B(n_4),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OR3x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.C(n_11),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_0),
.B(n_3),
.Y(n_18)
);


endmodule