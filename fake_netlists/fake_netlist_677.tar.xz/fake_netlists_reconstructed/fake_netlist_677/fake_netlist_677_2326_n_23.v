module fake_netlist_677_2326_n_23 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_23);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_23;

wire n_21;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_7;
wire n_12;
wire n_8;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

AOI22xp5_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_2),
.B1(n_5),
.B2(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_4),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_4),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_3),
.Y(n_11)
);

OA21x2_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_0),
.B(n_5),
.Y(n_12)
);

AOI21x1_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_0),
.B(n_11),
.Y(n_13)
);

INVx8_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx4_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_14),
.B1(n_11),
.B2(n_12),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_10),
.Y(n_18)
);

XNOR2x1_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_8),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_15),
.B1(n_16),
.B2(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_7),
.B1(n_16),
.B2(n_22),
.C(n_9),
.Y(n_23)
);


endmodule