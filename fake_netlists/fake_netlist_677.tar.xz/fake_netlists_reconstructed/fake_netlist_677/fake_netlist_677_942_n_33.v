module fake_netlist_677_942_n_33 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_33);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_33;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_12;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_6),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_8),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_12),
.B(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_19)
);

AOI21xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_15),
.B(n_11),
.Y(n_20)
);

OAI33xp33_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_11),
.A3(n_0),
.B1(n_8),
.B2(n_5),
.B3(n_10),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_18),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_2),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_23),
.C(n_7),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AOI331xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_2),
.A3(n_4),
.B1(n_1),
.B2(n_3),
.B3(n_9),
.C1(n_7),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_9),
.B1(n_4),
.B2(n_5),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

NAND3x1_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_1),
.C(n_3),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_29),
.B1(n_31),
.B2(n_26),
.Y(n_33)
);


endmodule