module fake_netlist_747_983_n_25 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_25);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_25;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_24;
wire n_10;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

BUFx3_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_2),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_0),
.Y(n_11)
);

INVxp67_ASAP7_75t_SL g12 ( 
.A(n_9),
.Y(n_12)
);

AO31x2_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_5),
.A3(n_4),
.B(n_1),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.Y(n_14)
);

AO32x2_ASAP7_75t_L g15 ( 
.A1(n_8),
.A2(n_6),
.A3(n_11),
.B1(n_9),
.B2(n_10),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_7),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

NAND4xp75_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_11),
.C(n_8),
.D(n_15),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B1(n_18),
.B2(n_9),
.Y(n_22)
);

NAND4xp75_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_15),
.C(n_19),
.D(n_13),
.Y(n_23)
);

XNOR2x1_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_6),
.Y(n_24)
);

AOI21xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_7),
.B(n_23),
.Y(n_25)
);


endmodule