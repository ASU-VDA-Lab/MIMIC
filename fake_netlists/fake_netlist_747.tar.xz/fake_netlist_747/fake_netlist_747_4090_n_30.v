module fake_netlist_747_4090_n_30 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_30);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_30;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_12;
wire n_29;

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_3),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_9),
.B(n_7),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_3),
.A2(n_2),
.B1(n_5),
.B2(n_8),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_L g16 ( 
.A(n_1),
.B(n_0),
.C(n_6),
.Y(n_16)
);

AOI21x1_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_1),
.B(n_0),
.Y(n_17)
);

INVx3_ASAP7_75t_SL g18 ( 
.A(n_14),
.Y(n_18)
);

BUFx10_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_10),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_20),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_19),
.B1(n_16),
.B2(n_15),
.C1(n_12),
.C2(n_14),
.Y(n_26)
);

OAI21xp33_ASAP7_75t_SL g27 ( 
.A1(n_25),
.A2(n_20),
.B(n_12),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_4),
.B1(n_19),
.B2(n_28),
.C1(n_16),
.C2(n_10),
.Y(n_30)
);


endmodule