module fake_netlist_747_2996_n_17 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_8, n_17);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_17;

wire n_14;
wire n_9;
wire n_16;
wire n_13;
wire n_11;
wire n_12;
wire n_15;
wire n_10;

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_5),
.B(n_4),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_7),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

AOI211xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_10),
.B(n_3),
.C(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_8),
.B(n_6),
.Y(n_17)
);


endmodule