module fake_netlist_747_1646_n_39 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_39);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_39;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_17),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_5),
.B(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_12),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

A2O1A1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_20),
.B(n_21),
.C(n_18),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_0),
.Y(n_26)
);

O2A1O1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_22),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_19),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_24),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_27),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_23),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_6),
.B(n_3),
.Y(n_32)
);

O2A1O1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B(n_4),
.C(n_1),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_32),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

NAND4xp75_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_17),
.C(n_5),
.D(n_7),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OAI321xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_9),
.A3(n_8),
.B1(n_11),
.B2(n_15),
.C(n_13),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_38),
.Y(n_39)
);


endmodule