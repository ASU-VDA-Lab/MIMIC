module fake_netlist_747_839_n_38 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_38);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_38;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_10;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_0),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

INVx5_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

OR2x6_ASAP7_75t_SL g20 ( 
.A(n_12),
.B(n_1),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_15),
.B(n_2),
.Y(n_21)
);

AO32x2_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_15),
.A3(n_16),
.B1(n_4),
.B2(n_5),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_11),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_SL g24 ( 
.A(n_21),
.B(n_14),
.C(n_13),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_18),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_19),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_18),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_18),
.B1(n_22),
.B2(n_20),
.Y(n_30)
);

A2O1A1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_22),
.B(n_27),
.C(n_4),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_6),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

AOI22x1_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_7),
.B1(n_9),
.B2(n_3),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_34),
.B1(n_35),
.B2(n_36),
.Y(n_38)
);


endmodule