module fake_netlist_747_1684_n_26 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_26);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_24;
wire n_10;
wire n_9;
wire n_25;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

OAI22x1_ASAP7_75t_L g7 ( 
.A1(n_1),
.A2(n_6),
.B1(n_4),
.B2(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_6),
.B(n_2),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

INVx5_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_1),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_9),
.A2(n_6),
.B(n_0),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_8),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_13),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_15),
.C(n_8),
.Y(n_20)
);

AOI211xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_14),
.B(n_12),
.C(n_7),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_19),
.Y(n_22)
);

NOR2x1_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_13),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_17),
.B1(n_11),
.B2(n_2),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_23),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_5),
.B(n_24),
.Y(n_26)
);


endmodule