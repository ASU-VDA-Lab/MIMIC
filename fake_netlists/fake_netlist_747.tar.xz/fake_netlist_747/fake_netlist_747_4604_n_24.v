module fake_netlist_747_4604_n_24 (n_1, n_2, n_3, n_4, n_5, n_0, n_24);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_24;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

BUFx3_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_0),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_1),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_2),
.B(n_0),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_6),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_6),
.B1(n_14),
.B2(n_8),
.C(n_7),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_8),
.B1(n_7),
.B2(n_14),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_17),
.B1(n_6),
.B2(n_11),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_6),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_22),
.B1(n_3),
.B2(n_2),
.Y(n_24)
);


endmodule