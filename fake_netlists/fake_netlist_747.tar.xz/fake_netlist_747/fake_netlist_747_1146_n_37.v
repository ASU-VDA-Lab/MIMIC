module fake_netlist_747_1146_n_37 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_8, n_37);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_37;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_9;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;
wire n_29;
wire n_32;

INVx3_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_1),
.B(n_4),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_9),
.B(n_1),
.Y(n_17)
);

OR2x6_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_4),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_9),
.B(n_14),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_12),
.B(n_17),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_12),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_15),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_22),
.Y(n_26)
);

INVxp33_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_18),
.Y(n_28)
);

OR2x2_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_18),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_29),
.Y(n_30)
);

OAI32xp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_23),
.A3(n_21),
.B1(n_5),
.B2(n_2),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_30),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_33),
.B1(n_35),
.B2(n_31),
.Y(n_37)
);


endmodule