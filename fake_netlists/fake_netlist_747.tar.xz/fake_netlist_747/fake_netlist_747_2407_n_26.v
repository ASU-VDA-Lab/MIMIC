module fake_netlist_747_2407_n_26 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_26);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_24;
wire n_10;
wire n_9;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;
wire n_8;

INVx2_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_3),
.Y(n_11)
);

BUFx10_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_4),
.Y(n_14)
);

AOI21x1_ASAP7_75t_SL g15 ( 
.A1(n_10),
.A2(n_5),
.B(n_4),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_5),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_11),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.C(n_11),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_20),
.B(n_18),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_12),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_24),
.B1(n_15),
.B2(n_12),
.Y(n_25)
);

OAI211xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_2),
.B(n_12),
.C(n_23),
.Y(n_26)
);


endmodule