module fake_netlist_747_2110_n_37 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_37);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_37;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_1),
.A2(n_12),
.B1(n_7),
.B2(n_15),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_14),
.A2(n_4),
.B(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

OA21x2_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_22),
.B(n_16),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_17),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_R g29 ( 
.A(n_28),
.B(n_26),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_29),
.B(n_23),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_17),
.B1(n_21),
.B2(n_3),
.Y(n_35)
);

XNOR2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_8),
.Y(n_36)
);

OAI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_10),
.B2(n_9),
.Y(n_37)
);


endmodule