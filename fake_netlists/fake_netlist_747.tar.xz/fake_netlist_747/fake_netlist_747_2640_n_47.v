module fake_netlist_747_2640_n_47 (n_12, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_47);

input n_12;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_47;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_15;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_2),
.B(n_9),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

INVx6_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_6),
.B(n_3),
.C(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_16),
.B(n_3),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

BUFx12f_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_26),
.B1(n_19),
.B2(n_18),
.C(n_20),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_24),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_19),
.B1(n_24),
.B2(n_31),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_30),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_30),
.Y(n_39)
);

INVxp67_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_29),
.Y(n_41)
);

INVxp67_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

BUFx3_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

CKINVDCx16_ASAP7_75t_R g44 ( 
.A(n_40),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_22),
.B(n_16),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

OAI321xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_4),
.A3(n_7),
.B1(n_12),
.B2(n_44),
.C(n_46),
.Y(n_47)
);


endmodule