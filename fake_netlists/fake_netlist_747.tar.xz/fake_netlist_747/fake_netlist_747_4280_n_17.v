module fake_netlist_747_4280_n_17 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_17);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;

output n_17;

wire n_14;
wire n_9;
wire n_16;
wire n_13;
wire n_11;
wire n_12;
wire n_15;
wire n_10;
wire n_8;

INVx4_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_1),
.B(n_5),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_0),
.B(n_4),
.Y(n_11)
);

INVx4_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

AOI31xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.A3(n_6),
.B(n_4),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_14),
.B(n_6),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_7),
.B1(n_8),
.B2(n_15),
.Y(n_17)
);


endmodule