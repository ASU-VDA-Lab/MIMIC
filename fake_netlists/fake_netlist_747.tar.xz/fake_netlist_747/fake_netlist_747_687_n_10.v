module fake_netlist_747_687_n_10 (n_0, n_2, n_1, n_3, n_10);

input n_0;
input n_2;
input n_1;
input n_3;

output n_10;

wire n_9;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

BUFx6f_ASAP7_75t_SL g4 ( 
.A(n_0),
.Y(n_4)
);

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_5),
.B1(n_3),
.B2(n_1),
.C(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_5),
.B1(n_3),
.B2(n_1),
.Y(n_10)
);


endmodule