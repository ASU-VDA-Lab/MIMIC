module fake_netlist_747_1330_n_39 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_39);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_39;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_3),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_3),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

XOR2x2_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_0),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_SL g22 ( 
.A(n_16),
.B(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_12),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_15),
.A2(n_6),
.B(n_5),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_16),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_16),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_R g28 ( 
.A(n_24),
.B(n_13),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_27),
.Y(n_31)
);

OAI22xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_28),
.B1(n_20),
.B2(n_16),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_28),
.B1(n_22),
.B2(n_25),
.Y(n_33)
);

O2A1O1Ixp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_29),
.B(n_22),
.C(n_33),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_31),
.B1(n_18),
.B2(n_14),
.C(n_17),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_35),
.Y(n_36)
);

CKINVDCx6p67_ASAP7_75t_R g37 ( 
.A(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_36),
.B1(n_10),
.B2(n_9),
.Y(n_39)
);


endmodule