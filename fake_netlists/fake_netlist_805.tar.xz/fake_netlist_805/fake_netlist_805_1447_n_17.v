module fake_netlist_805_1447_n_17 (n_2, n_0, n_3, n_1, n_17);

input n_2;
input n_0;
input n_3;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

AND2x6_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_0),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI21xp33_ASAP7_75t_L g6 ( 
.A1(n_2),
.A2(n_0),
.B(n_1),
.Y(n_6)
);

AOI222xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_3),
.C2(n_5),
.Y(n_7)
);

INVx4_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_7),
.C(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AND3x4_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_3),
.C(n_1),
.Y(n_13)
);

NOR4xp25_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_5),
.C(n_9),
.D(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_4),
.B1(n_10),
.B2(n_11),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_13),
.B2(n_15),
.Y(n_17)
);


endmodule