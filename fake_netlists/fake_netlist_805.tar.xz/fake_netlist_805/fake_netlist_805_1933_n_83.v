module fake_netlist_805_1933_n_83 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_28, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_29, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_83);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_28;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_29;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_83;

wire n_49;
wire n_81;
wire n_80;
wire n_78;
wire n_54;
wire n_56;
wire n_59;
wire n_63;
wire n_74;
wire n_64;
wire n_79;
wire n_61;
wire n_43;
wire n_45;
wire n_48;
wire n_47;
wire n_76;
wire n_72;
wire n_73;
wire n_37;
wire n_42;
wire n_52;
wire n_77;
wire n_51;
wire n_57;
wire n_70;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_53;
wire n_58;
wire n_68;
wire n_33;
wire n_55;
wire n_65;
wire n_75;
wire n_67;
wire n_66;
wire n_36;
wire n_50;
wire n_60;
wire n_39;
wire n_31;
wire n_32;
wire n_71;
wire n_82;
wire n_69;
wire n_30;
wire n_35;
wire n_38;
wire n_46;

INVx1_ASAP7_75t_L g30 ( 
.A(n_15),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_0),
.B(n_2),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_12),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_1),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_2),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_5),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_25),
.B(n_19),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_21),
.B(n_26),
.Y(n_38)
);

BUFx6f_ASAP7_75t_L g39 ( 
.A(n_23),
.Y(n_39)
);

OAI21x1_ASAP7_75t_L g40 ( 
.A1(n_27),
.A2(n_24),
.B(n_10),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_17),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_8),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_3),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_13),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_11),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_14),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_34),
.Y(n_47)
);

INVx2_ASAP7_75t_SL g48 ( 
.A(n_34),
.Y(n_48)
);

OR2x6_ASAP7_75t_L g49 ( 
.A(n_42),
.B(n_43),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_34),
.Y(n_50)
);

AND2x4_ASAP7_75t_SL g51 ( 
.A(n_35),
.B(n_16),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_34),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_42),
.B(n_1),
.Y(n_53)
);

INVx6_ASAP7_75t_L g54 ( 
.A(n_49),
.Y(n_54)
);

BUFx8_ASAP7_75t_L g55 ( 
.A(n_48),
.Y(n_55)
);

OAI21x1_ASAP7_75t_L g56 ( 
.A1(n_47),
.A2(n_40),
.B(n_37),
.Y(n_56)
);

OR2x2_ASAP7_75t_L g57 ( 
.A(n_50),
.B(n_45),
.Y(n_57)
);

OAI22xp33_ASAP7_75t_L g58 ( 
.A1(n_49),
.A2(n_45),
.B1(n_36),
.B2(n_33),
.Y(n_58)
);

BUFx3_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

AOI22xp33_ASAP7_75t_L g60 ( 
.A1(n_58),
.A2(n_31),
.B1(n_52),
.B2(n_53),
.Y(n_60)
);

BUFx2_ASAP7_75t_L g61 ( 
.A(n_54),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_56),
.Y(n_62)
);

AOI22xp5_ASAP7_75t_L g63 ( 
.A1(n_58),
.A2(n_31),
.B1(n_53),
.B2(n_52),
.Y(n_63)
);

OR2x2_ASAP7_75t_L g64 ( 
.A(n_61),
.B(n_57),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_62),
.Y(n_65)
);

NOR2xp33_ASAP7_75t_L g66 ( 
.A(n_59),
.B(n_51),
.Y(n_66)
);

NOR2xp33_ASAP7_75t_L g67 ( 
.A(n_64),
.B(n_59),
.Y(n_67)
);

NAND3xp33_ASAP7_75t_L g68 ( 
.A(n_66),
.B(n_60),
.C(n_63),
.Y(n_68)
);

NAND4xp25_ASAP7_75t_L g69 ( 
.A(n_66),
.B(n_31),
.C(n_44),
.D(n_30),
.Y(n_69)
);

AOI21xp5_ASAP7_75t_L g70 ( 
.A1(n_65),
.A2(n_62),
.B(n_32),
.Y(n_70)
);

O2A1O1Ixp33_ASAP7_75t_L g71 ( 
.A1(n_69),
.A2(n_44),
.B(n_46),
.C(n_38),
.Y(n_71)
);

AOI31xp33_ASAP7_75t_L g72 ( 
.A1(n_68),
.A2(n_38),
.A3(n_32),
.B(n_55),
.Y(n_72)
);

AOI21xp33_ASAP7_75t_L g73 ( 
.A1(n_67),
.A2(n_55),
.B(n_46),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_SL g74 ( 
.A(n_70),
.B(n_33),
.Y(n_74)
);

AOI32xp33_ASAP7_75t_L g75 ( 
.A1(n_67),
.A2(n_40),
.A3(n_6),
.B1(n_4),
.B2(n_5),
.Y(n_75)
);

OA21x2_ASAP7_75t_L g76 ( 
.A1(n_74),
.A2(n_41),
.B(n_39),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_71),
.Y(n_77)
);

OR2x2_ASAP7_75t_L g78 ( 
.A(n_72),
.B(n_7),
.Y(n_78)
);

NAND2xp5_ASAP7_75t_L g79 ( 
.A(n_73),
.B(n_75),
.Y(n_79)
);

AOI22xp5_ASAP7_75t_L g80 ( 
.A1(n_77),
.A2(n_36),
.B1(n_33),
.B2(n_39),
.Y(n_80)
);

OR3x2_ASAP7_75t_L g81 ( 
.A(n_78),
.B(n_9),
.C(n_8),
.Y(n_81)
);

AOI222xp33_ASAP7_75t_SL g82 ( 
.A1(n_81),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.C1(n_79),
.C2(n_36),
.Y(n_82)
);

AOI322xp5_ASAP7_75t_L g83 ( 
.A1(n_82),
.A2(n_80),
.A3(n_41),
.B1(n_76),
.B2(n_20),
.C1(n_18),
.C2(n_22),
.Y(n_83)
);


endmodule