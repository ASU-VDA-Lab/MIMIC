module fake_netlist_805_996_n_23 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_23);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

INVx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_9),
.B(n_11),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_R g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

NAND2x1_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

NOR4xp25_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_10),
.C(n_2),
.D(n_1),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_5),
.B(n_4),
.C(n_2),
.Y(n_17)
);

NAND4xp75_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_6),
.C(n_5),
.D(n_4),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI22x1_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_20),
.B1(n_7),
.B2(n_6),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_19),
.C(n_21),
.Y(n_23)
);


endmodule