module fake_netlist_805_873_n_36 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_36);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_36;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_27;

INVx2_ASAP7_75t_SL g12 ( 
.A(n_0),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_11),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_5),
.Y(n_18)
);

O2A1O1Ixp5_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_10),
.B(n_7),
.C(n_2),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_6),
.B(n_5),
.C(n_1),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_1),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_19),
.A2(n_12),
.B(n_14),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_21),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_22),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_18),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_24),
.Y(n_29)
);

NAND4xp25_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_20),
.C(n_23),
.D(n_28),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_24),
.B1(n_12),
.B2(n_13),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_12),
.C(n_16),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_32),
.B1(n_33),
.B2(n_24),
.Y(n_36)
);


endmodule