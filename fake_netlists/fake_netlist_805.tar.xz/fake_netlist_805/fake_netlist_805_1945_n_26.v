module fake_netlist_805_1945_n_26 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_26);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_9;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_1),
.A2(n_6),
.B1(n_4),
.B2(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_5),
.B(n_3),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_2),
.B(n_1),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_7),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_0),
.B1(n_4),
.B2(n_15),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_12),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_13),
.B1(n_11),
.B2(n_9),
.Y(n_18)
);

AO21x2_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_9),
.B(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.Y(n_22)
);

OA21x2_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_16),
.B(n_17),
.Y(n_23)
);

NOR2xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.Y(n_26)
);


endmodule