module fake_netlist_805_1866_n_14 (n_4, n_2, n_3, n_0, n_1, n_14);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

AOI22xp33_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_1),
.B1(n_0),
.B2(n_4),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_1),
.Y(n_6)
);

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_0),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_1),
.Y(n_9)
);

OR2x6_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_5),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_10),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_5),
.B2(n_10),
.C(n_2),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_4),
.B(n_3),
.Y(n_13)
);

XNOR2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);


endmodule