module fake_netlist_805_2405_n_34 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_34);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_27;

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_15),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

AND3x2_ASAP7_75t_L g22 ( 
.A(n_9),
.B(n_2),
.C(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_16),
.B1(n_15),
.B2(n_5),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_18),
.A2(n_17),
.B1(n_5),
.B2(n_1),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_21),
.B1(n_19),
.B2(n_20),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

NAND5xp2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_18),
.C(n_22),
.D(n_17),
.E(n_3),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_29),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_33)
);

OAI222xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_30),
.B1(n_32),
.B2(n_14),
.C1(n_13),
.C2(n_8),
.Y(n_34)
);


endmodule