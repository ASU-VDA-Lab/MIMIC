module fake_netlist_805_2023_n_40 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_40);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_40;

wire n_25;
wire n_36;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

AOI222xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.C1(n_1),
.C2(n_0),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_23),
.B(n_17),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_21),
.A2(n_18),
.B1(n_4),
.B2(n_2),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_SL g32 ( 
.A(n_28),
.B(n_25),
.C(n_24),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_26),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

OAI211xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_32),
.B(n_30),
.C(n_22),
.Y(n_35)
);

OAI211xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_22),
.B(n_8),
.C(n_6),
.Y(n_36)
);

XNOR2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_10),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

OAI22x1_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_SL g40 ( 
.A1(n_39),
.A2(n_38),
.B1(n_20),
.B2(n_19),
.Y(n_40)
);


endmodule