module fake_netlist_805_1488_n_34 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_34);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_6),
.Y(n_12)
);

INVx4_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

AOI211xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_4),
.B(n_2),
.C(n_0),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_0),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_16),
.B(n_12),
.Y(n_21)
);

OAI222xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_13),
.B1(n_19),
.B2(n_14),
.C1(n_11),
.C2(n_18),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_19),
.B1(n_13),
.B2(n_11),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_21),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_R g28 ( 
.A(n_26),
.B(n_2),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_16),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_7),
.B1(n_5),
.B2(n_4),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_7),
.C(n_5),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_32),
.A2(n_10),
.B1(n_28),
.B2(n_33),
.Y(n_34)
);


endmodule