module fake_netlist_667_1033_n_29 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_29);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_29;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_26;
wire n_9;
wire n_13;

NOR2x1p5_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_5),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_7),
.B(n_0),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_10),
.Y(n_17)
);

NAND2x1p5_ASAP7_75t_L g18 ( 
.A(n_9),
.B(n_7),
.Y(n_18)
);

AO32x2_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_2),
.A3(n_1),
.B1(n_3),
.B2(n_4),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_11),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_17),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_20),
.B1(n_17),
.B2(n_18),
.C(n_13),
.Y(n_24)
);

A2O1A1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_16),
.B(n_14),
.C(n_19),
.Y(n_25)
);

NAND3x1_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_19),
.C(n_1),
.Y(n_26)
);

NAND4xp75_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_19),
.C(n_16),
.D(n_2),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_8),
.B1(n_19),
.B2(n_27),
.Y(n_28)
);

AOI21xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_8),
.B(n_19),
.Y(n_29)
);


endmodule