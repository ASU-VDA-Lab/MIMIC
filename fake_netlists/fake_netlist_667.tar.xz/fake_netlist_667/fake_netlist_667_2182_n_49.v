module fake_netlist_667_2182_n_49 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_49);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_49;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_14),
.Y(n_24)
);

INVxp33_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_15),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_17),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_8),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_7),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_5),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_18),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_23),
.B(n_15),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_R g33 ( 
.A(n_22),
.B(n_1),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_23),
.B(n_16),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_SL g35 ( 
.A(n_26),
.B(n_17),
.C(n_16),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

OAI21xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_25),
.B(n_35),
.Y(n_38)
);

NOR4xp25_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_27),
.C(n_28),
.D(n_24),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_37),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_31),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_40),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_30),
.B1(n_33),
.B2(n_29),
.C(n_18),
.Y(n_44)
);

AOI211xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_29),
.B(n_3),
.C(n_2),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_29),
.B1(n_6),
.B2(n_4),
.Y(n_46)
);

AOI21xp33_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_10),
.B(n_9),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_46),
.Y(n_48)
);

OAI222xp33_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_47),
.B1(n_19),
.B2(n_11),
.C1(n_20),
.C2(n_12),
.Y(n_49)
);


endmodule