module fake_netlist_667_600_n_58 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_58);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_58;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_57;
wire n_24;
wire n_35;
wire n_54;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_16;
wire n_22;
wire n_17;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx4_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_10),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_14),
.B(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

BUFx8_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

AND3x1_ASAP7_75t_SL g27 ( 
.A(n_24),
.B(n_1),
.C(n_0),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_0),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_21),
.A2(n_14),
.B1(n_12),
.B2(n_3),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_15),
.B(n_12),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_15),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_15),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_31),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_28),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_SL g35 ( 
.A(n_30),
.B(n_17),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_28),
.A2(n_18),
.B1(n_25),
.B2(n_22),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_26),
.Y(n_37)
);

CKINVDCx12_ASAP7_75t_R g38 ( 
.A(n_34),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_33),
.A2(n_30),
.B1(n_29),
.B2(n_26),
.Y(n_39)
);

INVx3_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_35),
.B(n_30),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_35),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_36),
.Y(n_44)
);

NOR4xp25_ASAP7_75t_SL g45 ( 
.A(n_41),
.B(n_18),
.C(n_19),
.D(n_16),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

INVx2_ASAP7_75t_SL g47 ( 
.A(n_44),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_42),
.Y(n_49)
);

OAI21xp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_39),
.B(n_40),
.Y(n_50)
);

AOI221xp5_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_40),
.B1(n_27),
.B2(n_23),
.C(n_45),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_47),
.A2(n_40),
.B1(n_25),
.B2(n_8),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_R g53 ( 
.A(n_47),
.B(n_49),
.Y(n_53)
);

NOR3xp33_ASAP7_75t_SL g54 ( 
.A(n_51),
.B(n_25),
.C(n_9),
.Y(n_54)
);

NAND2x1p5_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_52),
.Y(n_55)
);

CKINVDCx5p33_ASAP7_75t_R g56 ( 
.A(n_50),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_55),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_55),
.B1(n_54),
.B2(n_56),
.Y(n_58)
);


endmodule