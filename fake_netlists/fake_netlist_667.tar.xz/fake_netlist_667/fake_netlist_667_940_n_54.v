module fake_netlist_667_940_n_54 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_54);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_54;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_23;
wire n_48;
wire n_16;
wire n_22;
wire n_39;
wire n_17;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx2_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_4),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_16),
.B(n_0),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_0),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

OAI222xp33_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_19),
.B1(n_23),
.B2(n_22),
.C1(n_17),
.C2(n_20),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_L g32 ( 
.A1(n_26),
.A2(n_19),
.B1(n_23),
.B2(n_1),
.C(n_4),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_28),
.B(n_1),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

NOR2x1p5_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_29),
.Y(n_35)
);

OAI31xp33_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_25),
.A3(n_6),
.B(n_5),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_R g37 ( 
.A(n_33),
.B(n_7),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_33),
.Y(n_38)
);

NOR4xp25_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_32),
.C(n_25),
.D(n_33),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_35),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

AO22x2_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_7),
.B1(n_9),
.B2(n_3),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_R g45 ( 
.A(n_41),
.B(n_12),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

NAND3xp33_ASAP7_75t_L g47 ( 
.A(n_41),
.B(n_30),
.C(n_29),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_45),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_29),
.Y(n_50)
);

OR3x2_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_15),
.C(n_30),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

AOI322xp5_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_30),
.A3(n_48),
.B1(n_50),
.B2(n_51),
.C1(n_53),
.C2(n_49),
.Y(n_54)
);


endmodule