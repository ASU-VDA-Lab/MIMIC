module fake_netlist_667_2322_n_35 (n_9, n_4, n_7, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_35);

input n_9;
input n_4;
input n_7;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_35;

wire n_18;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

INVx1_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_2),
.B(n_1),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_17),
.B(n_7),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_18),
.Y(n_23)
);

NAND2x1p5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_8),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_15),
.Y(n_27)
);

AND2x2_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_22),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_23),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_24),
.B(n_28),
.C(n_21),
.Y(n_31)
);

AO22x2_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_16),
.B1(n_1),
.B2(n_0),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_15),
.B1(n_5),
.B2(n_4),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_32),
.B1(n_13),
.B2(n_10),
.Y(n_35)
);


endmodule