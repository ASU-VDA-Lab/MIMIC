module fake_netlist_667_2447_n_20 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_20);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_20;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

INVxp33_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

OR2x6_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_2),
.Y(n_11)
);

OR2x6_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_4),
.Y(n_12)
);

INVx4_ASAP7_75t_SL g13 ( 
.A(n_6),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_11),
.B1(n_13),
.B2(n_7),
.Y(n_15)
);

NOR2x1_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_12),
.B1(n_14),
.B2(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_8),
.B(n_5),
.Y(n_20)
);


endmodule