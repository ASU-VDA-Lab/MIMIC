module fake_netlist_667_1387_n_46 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_46);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_46;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_8),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_5),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_0),
.B(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_22),
.B(n_17),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_1),
.Y(n_31)
);

BUFx4f_ASAP7_75t_SL g32 ( 
.A(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

OR2x6_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_32),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_30),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_29),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_36),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

NAND2xp33_ASAP7_75t_SL g42 ( 
.A(n_40),
.B(n_41),
.Y(n_42)
);

AOI222xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_27),
.B1(n_23),
.B2(n_20),
.C1(n_26),
.C2(n_21),
.Y(n_43)
);

OAI221xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_43),
.B1(n_27),
.B2(n_3),
.C(n_6),
.Y(n_44)
);

CKINVDCx20_ASAP7_75t_R g45 ( 
.A(n_44),
.Y(n_45)
);

AOI322xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_11),
.A3(n_10),
.B1(n_15),
.B2(n_16),
.C1(n_12),
.C2(n_14),
.Y(n_46)
);


endmodule