module fake_netlist_667_63_n_48 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_48);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_48;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx2_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_6),
.B(n_1),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_R g25 ( 
.A(n_7),
.B(n_4),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_19),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_10),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_R g29 ( 
.A(n_19),
.B(n_14),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_9),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_16),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_16),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_30),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_24),
.B(n_23),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_32),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_31),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_31),
.B1(n_29),
.B2(n_28),
.C(n_25),
.Y(n_37)
);

AND2x4_ASAP7_75t_SL g38 ( 
.A(n_37),
.B(n_27),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NAND2xp33_ASAP7_75t_SL g40 ( 
.A(n_39),
.B(n_27),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

NOR2x1p5_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_27),
.Y(n_42)
);

AOI21xp33_ASAP7_75t_SL g43 ( 
.A1(n_40),
.A2(n_18),
.B(n_0),
.Y(n_43)
);

CKINVDCx16_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

AOI211xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_18),
.B(n_5),
.C(n_2),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_8),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_11),
.A3(n_12),
.B1(n_13),
.B2(n_20),
.C1(n_21),
.C2(n_46),
.Y(n_48)
);


endmodule