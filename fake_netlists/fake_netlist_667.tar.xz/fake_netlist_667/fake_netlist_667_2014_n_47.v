module fake_netlist_667_2014_n_47 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_47);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_47;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_23;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

NAND2xp33_ASAP7_75t_R g20 ( 
.A(n_5),
.B(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

OA21x2_ASAP7_75t_L g22 ( 
.A1(n_11),
.A2(n_16),
.B(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

INVxp33_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

INVx5_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_18),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_28),
.Y(n_29)
);

BUFx4_ASAP7_75t_SL g30 ( 
.A(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_24),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

NAND2x1p5_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_22),
.Y(n_33)
);

NAND3xp33_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_27),
.C(n_23),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_31),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_30),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_25),
.Y(n_37)
);

NOR3xp33_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_20),
.C(n_16),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_26),
.Y(n_39)
);

XNOR2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_18),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_SL g41 ( 
.A1(n_40),
.A2(n_32),
.B(n_22),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_SL g42 ( 
.A1(n_39),
.A2(n_26),
.B1(n_19),
.B2(n_1),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_26),
.B1(n_4),
.B2(n_3),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_9),
.B1(n_7),
.B2(n_6),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_12),
.B1(n_15),
.B2(n_45),
.Y(n_47)
);


endmodule