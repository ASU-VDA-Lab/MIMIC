module fake_netlist_667_1005_n_37 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_37);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_37;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_10;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_9;
wire n_32;
wire n_13;
wire n_8;

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_1),
.C(n_0),
.Y(n_15)
);

AOI21x1_ASAP7_75t_L g16 ( 
.A1(n_9),
.A2(n_2),
.B(n_0),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

OAI22x1_ASAP7_75t_L g18 ( 
.A1(n_8),
.A2(n_4),
.B1(n_2),
.B2(n_0),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_SL g19 ( 
.A1(n_11),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_19)
);

AOI21x1_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_14),
.B(n_10),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_4),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_6),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_18),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_20),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_21),
.A2(n_15),
.B1(n_19),
.B2(n_16),
.Y(n_28)
);

A2O1A1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_23),
.B(n_22),
.C(n_24),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_24),
.B1(n_22),
.B2(n_16),
.C(n_6),
.Y(n_30)
);

OAI221xp5_ASAP7_75t_L g31 ( 
.A1(n_25),
.A2(n_3),
.B1(n_7),
.B2(n_22),
.C(n_26),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_30),
.C(n_25),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_26),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_32),
.Y(n_35)
);

AO21x2_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_22),
.B(n_33),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_SL g37 ( 
.A(n_35),
.B(n_36),
.Y(n_37)
);


endmodule