module fake_netlist_667_1302_n_4 (n_1, n_0, n_4);

input n_1;
input n_0;

output n_4;

wire n_2;
wire n_3;

INVx2_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

XNOR2x1_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

INVx3_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);


endmodule