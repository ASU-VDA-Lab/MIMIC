module fake_netlist_667_537_n_3 (n_1, n_0, n_3);

input n_1;
input n_0;

output n_3;

wire n_2;

AND2x4_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

AOI21xp5_ASAP7_75t_L g3 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_3)
);


endmodule