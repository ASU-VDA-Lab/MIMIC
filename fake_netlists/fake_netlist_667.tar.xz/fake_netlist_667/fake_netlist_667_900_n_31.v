module fake_netlist_667_900_n_31 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_31);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_31;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_26;
wire n_13;

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

OR2x6_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_7),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_7),
.B1(n_1),
.B2(n_0),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_10),
.B(n_14),
.C(n_11),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_16),
.Y(n_23)
);

NOR4xp25_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_18),
.C(n_14),
.D(n_10),
.Y(n_24)
);

NAND4xp25_ASAP7_75t_SL g25 ( 
.A(n_23),
.B(n_16),
.C(n_21),
.D(n_15),
.Y(n_25)
);

OAI211xp5_ASAP7_75t_SL g26 ( 
.A1(n_24),
.A2(n_22),
.B(n_15),
.C(n_2),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_SL g27 ( 
.A(n_25),
.B(n_3),
.Y(n_27)
);

NAND2x1p5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_4),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_6),
.B2(n_5),
.Y(n_31)
);


endmodule