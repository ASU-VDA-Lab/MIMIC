module fake_netlist_667_344_n_40 (n_9, n_4, n_7, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_40);

input n_9;
input n_4;
input n_7;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_40;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_39;
wire n_17;
wire n_14;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_11),
.B(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

BUFx6f_ASAP7_75t_SL g23 ( 
.A(n_14),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_0),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx2_ASAP7_75t_SL g28 ( 
.A(n_26),
.Y(n_28)
);

AOI211xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_22),
.B(n_20),
.C(n_25),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

INVxp67_ASAP7_75t_SL g33 ( 
.A(n_32),
.Y(n_33)
);

INVx3_ASAP7_75t_SL g34 ( 
.A(n_31),
.Y(n_34)
);

OAI22x1_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_23),
.B1(n_21),
.B2(n_18),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

CKINVDCx12_ASAP7_75t_R g37 ( 
.A(n_35),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_2),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_37),
.B1(n_12),
.B2(n_7),
.Y(n_40)
);


endmodule