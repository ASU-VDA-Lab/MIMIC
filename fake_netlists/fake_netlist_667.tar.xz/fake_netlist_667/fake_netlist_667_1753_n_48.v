module fake_netlist_667_1753_n_48 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_48);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_48;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_23;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx1_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_11),
.A2(n_7),
.B1(n_2),
.B2(n_16),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

INVx4_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

AND2x2_ASAP7_75t_SL g27 ( 
.A(n_9),
.B(n_3),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_10),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_5),
.Y(n_29)
);

NAND3xp33_ASAP7_75t_SL g30 ( 
.A(n_22),
.B(n_17),
.C(n_16),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_17),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_18),
.Y(n_32)
);

NOR2xp67_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_21),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_SL g34 ( 
.A1(n_30),
.A2(n_21),
.B(n_24),
.C(n_29),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_31),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_27),
.Y(n_38)
);

OAI322xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_25),
.A3(n_28),
.B1(n_23),
.B2(n_18),
.C1(n_19),
.C2(n_0),
.Y(n_39)
);

INVxp33_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

INVx2_ASAP7_75t_SL g41 ( 
.A(n_40),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_19),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_28),
.B1(n_23),
.B2(n_4),
.C(n_8),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_SL g45 ( 
.A(n_44),
.B(n_41),
.Y(n_45)
);

NAND4xp25_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_28),
.C(n_23),
.D(n_15),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_SL g47 ( 
.A(n_45),
.B(n_46),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);


endmodule