module fake_netlist_667_1957_n_59 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_59);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_59;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx2_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_16),
.Y(n_20)
);

AND2x6_ASAP7_75t_L g21 ( 
.A(n_0),
.B(n_6),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_22),
.B(n_0),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_19),
.B(n_14),
.Y(n_31)
);

INVx5_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_28),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_26),
.B(n_24),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_33),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_33),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

OAI221xp5_ASAP7_75t_SL g42 ( 
.A1(n_40),
.A2(n_31),
.B1(n_20),
.B2(n_25),
.C(n_27),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_SL g43 ( 
.A(n_41),
.B(n_20),
.C(n_36),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_39),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_33),
.B1(n_29),
.B2(n_35),
.C(n_32),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_33),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_33),
.Y(n_48)
);

NAND5xp2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_21),
.C(n_17),
.D(n_15),
.E(n_16),
.Y(n_49)
);

AOI321xp33_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_33),
.A3(n_44),
.B1(n_18),
.B2(n_17),
.C(n_15),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_34),
.B(n_32),
.Y(n_51)
);

NOR4xp75_ASAP7_75t_SL g52 ( 
.A(n_49),
.B(n_18),
.C(n_21),
.D(n_1),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_29),
.C(n_35),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_34),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_2),
.Y(n_55)
);

AOI22xp33_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_32),
.B1(n_9),
.B2(n_4),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_55),
.Y(n_57)
);

OAI22xp5_ASAP7_75t_SL g58 ( 
.A1(n_54),
.A2(n_51),
.B1(n_11),
.B2(n_10),
.Y(n_58)
);

AOI22xp33_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_32),
.B1(n_56),
.B2(n_57),
.Y(n_59)
);


endmodule