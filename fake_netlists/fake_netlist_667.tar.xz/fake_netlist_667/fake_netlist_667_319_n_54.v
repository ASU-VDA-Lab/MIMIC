module fake_netlist_667_319_n_54 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_54);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_54;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

NAND2x1_ASAP7_75t_L g26 ( 
.A(n_2),
.B(n_22),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_14),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_17),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_13),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_19),
.B(n_11),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_4),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_1),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_34),
.B(n_0),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

NOR2xp67_ASAP7_75t_L g37 ( 
.A(n_27),
.B(n_16),
.Y(n_37)
);

INVxp67_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_30),
.B1(n_33),
.B2(n_31),
.Y(n_40)
);

OAI33xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_32),
.A3(n_40),
.B1(n_37),
.B2(n_35),
.B3(n_26),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_29),
.B1(n_25),
.B2(n_16),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_18),
.Y(n_43)
);

INVxp67_ASAP7_75t_SL g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_18),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_43),
.Y(n_47)
);

NAND3xp33_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_25),
.C(n_23),
.Y(n_48)
);

NOR4xp25_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_23),
.C(n_25),
.D(n_6),
.Y(n_49)
);

NAND3xp33_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_8),
.C(n_7),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_47),
.Y(n_51)
);

BUFx6f_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

INVx1_ASAP7_75t_SL g53 ( 
.A(n_51),
.Y(n_53)
);

AOI322xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_52),
.A3(n_50),
.B1(n_12),
.B2(n_21),
.C1(n_9),
.C2(n_10),
.Y(n_54)
);


endmodule