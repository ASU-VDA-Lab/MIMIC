module fake_netlist_667_2002_n_13 (n_4, n_1, n_2, n_0, n_3, n_13);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_13;

wire n_7;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;
wire n_9;

INVx2_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

CKINVDCx16_ASAP7_75t_R g6 ( 
.A(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

OAI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B1(n_4),
.B2(n_0),
.C(n_2),
.Y(n_10)
);

NAND4xp75_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_4),
.C(n_2),
.D(n_0),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NAND2x1p5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_3),
.Y(n_13)
);


endmodule