module fake_netlist_667_1841_n_53 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_53);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_53;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_23;
wire n_48;
wire n_39;
wire n_17;
wire n_22;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_9),
.A2(n_7),
.B(n_3),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_16),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_11),
.B(n_16),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_5),
.B(n_12),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_1),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_5),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_19),
.B(n_14),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

OAI21x1_ASAP7_75t_L g29 ( 
.A1(n_25),
.A2(n_17),
.B(n_23),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_24),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

INVx2_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_27),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_27),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_32),
.Y(n_36)
);

INVx3_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_35),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_31),
.B1(n_24),
.B2(n_19),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_29),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_19),
.Y(n_41)
);

INVx8_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_SL g43 ( 
.A1(n_40),
.A2(n_37),
.B(n_21),
.C(n_14),
.Y(n_43)
);

XOR2x2_ASAP7_75t_L g44 ( 
.A(n_38),
.B(n_15),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_21),
.Y(n_45)
);

NOR2x1p5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_21),
.Y(n_46)
);

AND2x4_ASAP7_75t_L g47 ( 
.A(n_41),
.B(n_37),
.Y(n_47)
);

NAND3xp33_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_22),
.C(n_17),
.Y(n_48)
);

NOR2xp67_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_48),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_42),
.B1(n_47),
.B2(n_22),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_29),
.B1(n_22),
.B2(n_15),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

OA331x2_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_50),
.A3(n_49),
.B1(n_22),
.B2(n_2),
.B3(n_0),
.C1(n_6),
.Y(n_53)
);


endmodule