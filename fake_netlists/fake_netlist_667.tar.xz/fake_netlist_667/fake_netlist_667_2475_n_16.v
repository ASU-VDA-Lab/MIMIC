module fake_netlist_667_2475_n_16 (n_4, n_1, n_2, n_0, n_3, n_16);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_16;

wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_12;
wire n_10;
wire n_11;
wire n_8;
wire n_15;
wire n_6;
wire n_9;

INVx4_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_2),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI211xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_7),
.B(n_5),
.C(n_0),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_5),
.Y(n_12)
);

OAI22xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B1(n_10),
.B2(n_0),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_12),
.B1(n_10),
.B2(n_1),
.C(n_2),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_1),
.C(n_3),
.Y(n_15)
);

AOI31xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.A3(n_4),
.B(n_3),
.Y(n_16)
);


endmodule