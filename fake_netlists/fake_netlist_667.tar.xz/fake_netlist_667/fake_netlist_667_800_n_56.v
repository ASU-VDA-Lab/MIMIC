module fake_netlist_667_800_n_56 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_56);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_56;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_40;
wire n_54;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_5),
.B(n_6),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_23),
.A2(n_0),
.B1(n_8),
.B2(n_10),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_1),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_9),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_11),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_16),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_16),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_17),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_17),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_30),
.B(n_24),
.Y(n_38)
);

INVxp67_ASAP7_75t_L g39 ( 
.A(n_29),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_35),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_37),
.Y(n_41)
);

NAND3xp33_ASAP7_75t_SL g42 ( 
.A(n_38),
.B(n_28),
.C(n_32),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_38),
.B1(n_36),
.B2(n_27),
.Y(n_43)
);

INVx1_ASAP7_75t_SL g44 ( 
.A(n_40),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_40),
.Y(n_45)
);

INVxp67_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AOI21xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_41),
.B(n_28),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_33),
.A3(n_26),
.B1(n_24),
.B2(n_31),
.C1(n_2),
.C2(n_3),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

OAI21x1_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_31),
.B(n_4),
.Y(n_52)
);

NOR3xp33_ASAP7_75t_SL g53 ( 
.A(n_49),
.B(n_31),
.C(n_7),
.Y(n_53)
);

AOI211xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_18),
.B(n_14),
.C(n_12),
.Y(n_54)
);

HB1xp67_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

AOI322xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_53),
.A3(n_54),
.B1(n_21),
.B2(n_22),
.C1(n_19),
.C2(n_20),
.Y(n_56)
);


endmodule