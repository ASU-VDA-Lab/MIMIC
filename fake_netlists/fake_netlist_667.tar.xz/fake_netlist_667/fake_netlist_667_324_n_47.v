module fake_netlist_667_324_n_47 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_47);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_47;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_45;
wire n_23;
wire n_16;
wire n_22;
wire n_39;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_13;
wire n_43;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_1),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

INVx4_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_13),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_17),
.Y(n_25)
);

AOI21xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_16),
.B(n_15),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_14),
.B1(n_23),
.B2(n_21),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_26),
.A2(n_18),
.B1(n_25),
.B2(n_22),
.Y(n_30)
);

NOR4xp25_ASAP7_75t_SL g31 ( 
.A(n_27),
.B(n_20),
.C(n_15),
.D(n_5),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_27),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AOI321xp33_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_19),
.A3(n_18),
.B1(n_20),
.B2(n_22),
.C(n_34),
.Y(n_38)
);

AOI211x1_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_7),
.B(n_6),
.C(n_19),
.Y(n_39)
);

NAND2xp33_ASAP7_75t_SL g40 ( 
.A(n_36),
.B(n_6),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

BUFx4f_ASAP7_75t_SL g42 ( 
.A(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

NOR2x1p5_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_2),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_38),
.B1(n_9),
.B2(n_3),
.Y(n_45)
);

XOR2x2_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_11),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_12),
.B1(n_43),
.B2(n_46),
.Y(n_47)
);


endmodule