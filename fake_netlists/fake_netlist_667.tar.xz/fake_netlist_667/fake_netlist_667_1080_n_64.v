module fake_netlist_667_1080_n_64 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_64);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_64;

wire n_36;
wire n_59;
wire n_19;
wire n_62;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_60;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_63;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;
wire n_61;

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_17),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_SL g21 ( 
.A(n_13),
.B(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_2),
.B(n_0),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_15),
.B(n_1),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_4),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_7),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_19),
.B(n_5),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_25),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_29),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_29),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_30),
.Y(n_38)
);

NAND2x1_ASAP7_75t_L g39 ( 
.A(n_30),
.B(n_23),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_31),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_26),
.B1(n_32),
.B2(n_22),
.Y(n_41)
);

INVxp67_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

OAI222xp33_ASAP7_75t_L g43 ( 
.A1(n_38),
.A2(n_24),
.B1(n_21),
.B2(n_28),
.C1(n_16),
.C2(n_5),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_40),
.B(n_21),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_32),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_17),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_44),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_50),
.Y(n_52)
);

INVxp33_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_46),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_48),
.A2(n_35),
.B(n_30),
.Y(n_55)
);

AOI21xp5_ASAP7_75t_L g56 ( 
.A1(n_49),
.A2(n_35),
.B(n_3),
.Y(n_56)
);

INVx4_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

INVx1_ASAP7_75t_SL g58 ( 
.A(n_53),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_54),
.B(n_18),
.Y(n_59)
);

NOR2xp67_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_18),
.Y(n_60)
);

BUFx2_ASAP7_75t_L g61 ( 
.A(n_55),
.Y(n_61)
);

AOI22xp33_ASAP7_75t_L g62 ( 
.A1(n_59),
.A2(n_35),
.B1(n_10),
.B2(n_9),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_61),
.Y(n_63)
);

AOI222xp33_ASAP7_75t_L g64 ( 
.A1(n_63),
.A2(n_12),
.B1(n_57),
.B2(n_58),
.C1(n_60),
.C2(n_62),
.Y(n_64)
);


endmodule