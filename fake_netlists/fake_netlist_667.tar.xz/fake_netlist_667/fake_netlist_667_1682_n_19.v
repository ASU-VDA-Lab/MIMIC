module fake_netlist_667_1682_n_19 (n_4, n_1, n_2, n_0, n_5, n_3, n_19);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_19;

wire n_18;
wire n_10;
wire n_15;
wire n_11;
wire n_7;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_5),
.B(n_3),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_0),
.Y(n_10)
);

AOI22x1_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_0),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

NOR2x1p5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_7),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_10),
.B(n_8),
.C(n_6),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_13),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B(n_11),
.C(n_13),
.Y(n_17)
);

OA22x2_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_1),
.B2(n_2),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B(n_16),
.Y(n_19)
);


endmodule