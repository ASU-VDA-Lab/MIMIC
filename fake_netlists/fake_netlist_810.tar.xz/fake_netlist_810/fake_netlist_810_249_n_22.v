module fake_netlist_810_249_n_22 (n_4, n_2, n_3, n_0, n_1, n_22);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

BUFx10_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

INVxp33_ASAP7_75t_SL g9 ( 
.A(n_8),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_7),
.B(n_0),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

INVx5_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_6),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_9),
.B1(n_12),
.B2(n_11),
.Y(n_17)
);

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_15),
.Y(n_21)
);

AOI21x1_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_20),
.B(n_15),
.Y(n_22)
);


endmodule