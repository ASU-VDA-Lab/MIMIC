module fake_netlist_810_137_n_26 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_26);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;

INVx1_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_8),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_6),
.B(n_3),
.Y(n_14)
);

OA21x2_ASAP7_75t_L g15 ( 
.A1(n_9),
.A2(n_0),
.B(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_12),
.B(n_1),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_5),
.B(n_4),
.C(n_1),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_13),
.C(n_16),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AND4x1_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_7),
.C(n_6),
.D(n_4),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B1(n_13),
.B2(n_14),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

OR3x1_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_7),
.C(n_15),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_15),
.B1(n_24),
.B2(n_23),
.Y(n_26)
);


endmodule