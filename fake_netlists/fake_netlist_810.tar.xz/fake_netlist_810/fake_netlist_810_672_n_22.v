module fake_netlist_810_672_n_22 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_22);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_21;
wire n_16;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_11),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_2),
.B(n_9),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

AO21x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B(n_1),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NAND2x1p5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_13),
.Y(n_19)
);

AOI221x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_16),
.B1(n_7),
.B2(n_4),
.C(n_5),
.Y(n_20)
);

AOI21xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B(n_12),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_10),
.B1(n_8),
.B2(n_6),
.Y(n_22)
);


endmodule