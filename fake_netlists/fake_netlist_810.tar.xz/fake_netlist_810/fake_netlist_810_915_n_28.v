module fake_netlist_810_915_n_28 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_28);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B(n_13),
.C(n_14),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_4),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_20),
.Y(n_22)
);

OAI321xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.A3(n_15),
.B1(n_6),
.B2(n_5),
.C(n_4),
.Y(n_23)
);

AOI311xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_7),
.A3(n_6),
.B(n_17),
.C(n_1),
.Y(n_24)
);

INVx3_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_24),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_9),
.B1(n_8),
.B2(n_3),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_25),
.C(n_11),
.Y(n_28)
);


endmodule