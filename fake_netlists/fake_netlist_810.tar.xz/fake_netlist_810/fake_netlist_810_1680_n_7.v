module fake_netlist_810_1680_n_7 (n_0, n_1, n_7);

input n_0;
input n_1;

output n_7;

wire n_6;
wire n_4;
wire n_2;
wire n_5;
wire n_3;

NOR2xp67_ASAP7_75t_L g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

BUFx3_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx3_ASAP7_75t_R g4 ( 
.A(n_3),
.Y(n_4)
);

NAND3xp33_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_3),
.C(n_0),
.Y(n_5)
);

OAI211xp5_ASAP7_75t_SL g6 ( 
.A1(n_5),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_0),
.B1(n_1),
.B2(n_5),
.Y(n_7)
);


endmodule