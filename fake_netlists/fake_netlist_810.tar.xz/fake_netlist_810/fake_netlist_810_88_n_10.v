module fake_netlist_810_88_n_10 (n_2, n_0, n_1, n_10);

input n_2;
input n_0;
input n_1;

output n_10;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_8;

INVx6_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

BUFx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

CKINVDCx11_ASAP7_75t_R g5 ( 
.A(n_4),
.Y(n_5)
);

OR2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

OAI22xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_9)
);

AOI222xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_2),
.B1(n_3),
.B2(n_8),
.C1(n_7),
.C2(n_5),
.Y(n_10)
);


endmodule