module fake_netlist_810_1516_n_41 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_41);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_41;

wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;

INVx3_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_11),
.Y(n_15)
);

NOR2xp67_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_4),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_9),
.B(n_0),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_0),
.A2(n_8),
.B1(n_1),
.B2(n_12),
.Y(n_19)
);

BUFx10_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_1),
.B(n_11),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_14),
.B(n_2),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_18),
.A2(n_5),
.B(n_2),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_L g25 ( 
.A1(n_14),
.A2(n_6),
.B(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_20),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_22),
.B(n_19),
.C(n_17),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_26),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_25),
.Y(n_31)
);

OAI21xp33_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_25),
.B(n_23),
.Y(n_32)
);

OAI211xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_24),
.B(n_15),
.C(n_21),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_27),
.B1(n_21),
.B2(n_17),
.Y(n_34)
);

AOI21xp33_ASAP7_75t_L g35 ( 
.A1(n_30),
.A2(n_31),
.B(n_16),
.Y(n_35)
);

OAI211xp5_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_20),
.B(n_16),
.C(n_6),
.Y(n_36)
);

NOR3x1_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_20),
.C(n_7),
.Y(n_37)
);

NAND3xp33_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_20),
.C(n_10),
.Y(n_38)
);

INVxp67_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_38),
.B(n_40),
.Y(n_41)
);


endmodule