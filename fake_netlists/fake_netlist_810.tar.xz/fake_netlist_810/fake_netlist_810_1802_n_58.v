module fake_netlist_810_1802_n_58 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_58);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_58;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_30;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_5),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_0),
.B(n_7),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_5),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_26),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_24),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

AOI21xp33_ASAP7_75t_SL g35 ( 
.A1(n_31),
.A2(n_25),
.B(n_23),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_29),
.A2(n_20),
.B1(n_22),
.B2(n_21),
.Y(n_37)
);

AOI21xp33_ASAP7_75t_SL g38 ( 
.A1(n_30),
.A2(n_17),
.B(n_16),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_SL g39 ( 
.A(n_36),
.B(n_33),
.C(n_27),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_33),
.Y(n_40)
);

NOR4xp25_ASAP7_75t_SL g41 ( 
.A(n_38),
.B(n_18),
.C(n_16),
.D(n_30),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_39),
.B(n_35),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_41),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_32),
.Y(n_46)
);

XOR2x2_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_1),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_22),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_R g50 ( 
.A(n_45),
.B(n_2),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_47),
.Y(n_51)
);

AOI211xp5_ASAP7_75t_L g52 ( 
.A1(n_46),
.A2(n_6),
.B(n_4),
.C(n_3),
.Y(n_52)
);

INVx1_ASAP7_75t_SL g53 ( 
.A(n_51),
.Y(n_53)
);

AND3x2_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_48),
.C(n_8),
.Y(n_54)
);

INVx1_ASAP7_75t_SL g55 ( 
.A(n_50),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_55),
.Y(n_56)
);

NOR2x1_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_52),
.Y(n_57)
);

OAI221xp5_ASAP7_75t_R g58 ( 
.A1(n_57),
.A2(n_9),
.B1(n_15),
.B2(n_54),
.C(n_56),
.Y(n_58)
);


endmodule