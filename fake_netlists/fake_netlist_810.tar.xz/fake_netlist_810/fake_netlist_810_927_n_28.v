module fake_netlist_810_927_n_28 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_28);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_6),
.Y(n_12)
);

BUFx10_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_10),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_11),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_4),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_13),
.B(n_1),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_15),
.B(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

AO22x1_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B1(n_12),
.B2(n_16),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_22),
.B1(n_20),
.B2(n_13),
.C(n_3),
.Y(n_24)
);

NOR2x1_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_13),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_5),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_26),
.B1(n_6),
.B2(n_5),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_28)
);


endmodule