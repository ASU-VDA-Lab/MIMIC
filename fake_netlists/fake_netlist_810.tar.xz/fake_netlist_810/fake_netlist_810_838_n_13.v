module fake_netlist_810_838_n_13 (n_4, n_2, n_3, n_0, n_1, n_13);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_13;

wire n_6;
wire n_10;
wire n_7;
wire n_5;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

AO32x2_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.A3(n_0),
.B1(n_2),
.B2(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B1(n_6),
.B2(n_0),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.Y(n_10)
);

O2A1O1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B(n_1),
.C(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_1),
.B(n_4),
.Y(n_13)
);


endmodule