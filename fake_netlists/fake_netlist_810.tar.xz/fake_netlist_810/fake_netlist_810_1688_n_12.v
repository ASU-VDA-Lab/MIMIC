module fake_netlist_810_1688_n_12 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_12);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_12;

wire n_10;
wire n_11;
wire n_9;
wire n_8;

OA21x2_ASAP7_75t_L g8 ( 
.A1(n_3),
.A2(n_2),
.B(n_7),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_0),
.A2(n_6),
.B(n_5),
.C(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI321xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.A3(n_6),
.B1(n_10),
.B2(n_7),
.C(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule