module fake_netlist_810_1525_n_43 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_43);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_43;

wire n_25;
wire n_36;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_0),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_3),
.B(n_8),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_4),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_2),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_20),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_21),
.Y(n_30)
);

AOI21x1_ASAP7_75t_L g31 ( 
.A1(n_26),
.A2(n_6),
.B(n_1),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_24),
.A2(n_22),
.B(n_18),
.C(n_7),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_23),
.A2(n_10),
.B(n_9),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_SL g34 ( 
.A1(n_32),
.A2(n_29),
.B1(n_30),
.B2(n_25),
.Y(n_34)
);

INVx4_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_33),
.B(n_27),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_18),
.Y(n_37)
);

INVxp67_ASAP7_75t_SL g38 ( 
.A(n_37),
.Y(n_38)
);

AOI222xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_27),
.B1(n_28),
.B2(n_36),
.C1(n_22),
.C2(n_11),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_36),
.C(n_27),
.Y(n_40)
);

AOI211xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_28),
.B(n_39),
.C(n_12),
.Y(n_41)
);

OAI22xp33_ASAP7_75t_SL g42 ( 
.A1(n_41),
.A2(n_28),
.B1(n_14),
.B2(n_13),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_43)
);


endmodule