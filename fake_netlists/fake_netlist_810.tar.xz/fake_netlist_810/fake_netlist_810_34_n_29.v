module fake_netlist_810_34_n_29 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_29);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_29;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

BUFx3_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_3),
.Y(n_12)
);

BUFx8_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_9),
.B(n_8),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_7),
.B(n_6),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_12),
.B(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_R g24 ( 
.A(n_22),
.B(n_15),
.Y(n_24)
);

AOI21xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_19),
.B(n_20),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_16),
.B(n_23),
.C(n_20),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_11),
.B1(n_13),
.B2(n_5),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_13),
.B1(n_5),
.B2(n_2),
.Y(n_29)
);


endmodule