module fake_netlist_810_1705_n_29 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_29);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_29;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_1),
.B(n_10),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_9),
.B(n_6),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

NAND3x1_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_14),
.C(n_6),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_16),
.B(n_18),
.Y(n_23)
);

NAND2x1_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_7),
.Y(n_24)
);

OAI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_15),
.B1(n_4),
.B2(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_27),
.Y(n_28)
);

AOI222xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_25),
.B1(n_15),
.B2(n_12),
.C1(n_8),
.C2(n_5),
.Y(n_29)
);


endmodule