module fake_netlist_684_1395_n_237 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_31, n_29, n_8, n_0, n_4, n_28, n_3, n_11, n_19, n_30, n_25, n_10, n_13, n_14, n_12, n_237);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_31;
input n_29;
input n_8;
input n_0;
input n_4;
input n_28;
input n_3;
input n_11;
input n_19;
input n_30;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_237;

wire n_61;
wire n_99;
wire n_210;
wire n_115;
wire n_233;
wire n_219;
wire n_110;
wire n_148;
wire n_86;
wire n_147;
wire n_171;
wire n_230;
wire n_102;
wire n_40;
wire n_66;
wire n_165;
wire n_88;
wire n_235;
wire n_47;
wire n_119;
wire n_196;
wire n_35;
wire n_175;
wire n_52;
wire n_220;
wire n_213;
wire n_71;
wire n_162;
wire n_150;
wire n_234;
wire n_157;
wire n_179;
wire n_121;
wire n_182;
wire n_60;
wire n_189;
wire n_33;
wire n_89;
wire n_114;
wire n_181;
wire n_194;
wire n_211;
wire n_212;
wire n_112;
wire n_197;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_113;
wire n_83;
wire n_229;
wire n_131;
wire n_45;
wire n_204;
wire n_124;
wire n_158;
wire n_163;
wire n_130;
wire n_156;
wire n_64;
wire n_190;
wire n_146;
wire n_85;
wire n_136;
wire n_58;
wire n_218;
wire n_62;
wire n_200;
wire n_76;
wire n_63;
wire n_184;
wire n_70;
wire n_224;
wire n_69;
wire n_101;
wire n_141;
wire n_123;
wire n_53;
wire n_109;
wire n_231;
wire n_168;
wire n_173;
wire n_74;
wire n_188;
wire n_160;
wire n_176;
wire n_209;
wire n_226;
wire n_144;
wire n_170;
wire n_187;
wire n_208;
wire n_164;
wire n_94;
wire n_149;
wire n_81;
wire n_75;
wire n_161;
wire n_55;
wire n_192;
wire n_111;
wire n_54;
wire n_78;
wire n_207;
wire n_44;
wire n_38;
wire n_174;
wire n_203;
wire n_199;
wire n_91;
wire n_167;
wire n_42;
wire n_106;
wire n_236;
wire n_116;
wire n_127;
wire n_34;
wire n_225;
wire n_100;
wire n_145;
wire n_43;
wire n_84;
wire n_177;
wire n_37;
wire n_51;
wire n_191;
wire n_68;
wire n_140;
wire n_92;
wire n_195;
wire n_129;
wire n_90;
wire n_169;
wire n_143;
wire n_32;
wire n_77;
wire n_82;
wire n_117;
wire n_134;
wire n_152;
wire n_180;
wire n_228;
wire n_128;
wire n_202;
wire n_172;
wire n_93;
wire n_193;
wire n_97;
wire n_118;
wire n_186;
wire n_214;
wire n_216;
wire n_95;
wire n_98;
wire n_103;
wire n_135;
wire n_222;
wire n_125;
wire n_122;
wire n_79;
wire n_178;
wire n_154;
wire n_104;
wire n_105;
wire n_215;
wire n_139;
wire n_133;
wire n_183;
wire n_155;
wire n_120;
wire n_217;
wire n_137;
wire n_46;
wire n_73;
wire n_87;
wire n_41;
wire n_205;
wire n_185;
wire n_56;
wire n_159;
wire n_72;
wire n_65;
wire n_107;
wire n_80;
wire n_132;
wire n_232;
wire n_227;
wire n_138;
wire n_151;
wire n_153;
wire n_201;
wire n_36;
wire n_142;
wire n_126;
wire n_223;
wire n_221;
wire n_206;
wire n_49;
wire n_57;
wire n_96;
wire n_166;
wire n_198;
wire n_108;

INVxp67_ASAP7_75t_SL g32 ( 
.A(n_28),
.Y(n_32)
);

INVxp33_ASAP7_75t_SL g33 ( 
.A(n_25),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_11),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_7),
.Y(n_36)
);

NOR2xp67_ASAP7_75t_L g37 ( 
.A(n_18),
.B(n_23),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_13),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_20),
.Y(n_39)
);

INVxp67_ASAP7_75t_SL g40 ( 
.A(n_2),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_18),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_0),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_10),
.Y(n_43)
);

INVxp67_ASAP7_75t_SL g44 ( 
.A(n_3),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_26),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_33),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_34),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_35),
.B(n_0),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_33),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_43),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_36),
.Y(n_51)
);

NOR2xp33_ASAP7_75t_R g52 ( 
.A(n_34),
.B(n_21),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_32),
.Y(n_53)
);

NAND2xp33_ASAP7_75t_R g54 ( 
.A(n_34),
.B(n_1),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_36),
.Y(n_56)
);

NAND2x1p5_ASAP7_75t_L g57 ( 
.A(n_48),
.B(n_35),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_51),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_48),
.Y(n_59)
);

INVxp67_ASAP7_75t_L g60 ( 
.A(n_50),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_47),
.Y(n_61)
);

INVx4_ASAP7_75t_L g62 ( 
.A(n_53),
.Y(n_62)
);

NOR2xp33_ASAP7_75t_L g63 ( 
.A(n_49),
.B(n_45),
.Y(n_63)
);

INVx2_ASAP7_75t_L g64 ( 
.A(n_47),
.Y(n_64)
);

NOR2xp33_ASAP7_75t_L g65 ( 
.A(n_49),
.B(n_45),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_47),
.Y(n_66)
);

BUFx2_ASAP7_75t_L g67 ( 
.A(n_46),
.Y(n_67)
);

INVx4_ASAP7_75t_SL g68 ( 
.A(n_52),
.Y(n_68)
);

INVx2_ASAP7_75t_L g69 ( 
.A(n_47),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_61),
.Y(n_70)
);

NOR2xp33_ASAP7_75t_L g71 ( 
.A(n_62),
.B(n_59),
.Y(n_71)
);

OAI22xp5_ASAP7_75t_L g72 ( 
.A1(n_57),
.A2(n_48),
.B1(n_65),
.B2(n_63),
.Y(n_72)
);

OAI22xp5_ASAP7_75t_L g73 ( 
.A1(n_63),
.A2(n_44),
.B1(n_40),
.B2(n_39),
.Y(n_73)
);

BUFx8_ASAP7_75t_SL g74 ( 
.A(n_67),
.Y(n_74)
);

NAND2xp5_ASAP7_75t_L g75 ( 
.A(n_56),
.B(n_32),
.Y(n_75)
);

AND2x2_ASAP7_75t_L g76 ( 
.A(n_62),
.B(n_39),
.Y(n_76)
);

OAI22xp5_ASAP7_75t_L g77 ( 
.A1(n_65),
.A2(n_58),
.B1(n_55),
.B2(n_60),
.Y(n_77)
);

NAND2xp5_ASAP7_75t_L g78 ( 
.A(n_61),
.B(n_52),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_64),
.Y(n_79)
);

AND2x2_ASAP7_75t_L g80 ( 
.A(n_55),
.B(n_39),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_64),
.Y(n_81)
);

A2O1A1Ixp33_ASAP7_75t_L g82 ( 
.A1(n_66),
.A2(n_42),
.B(n_41),
.C(n_36),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_66),
.Y(n_83)
);

OR2x2_ASAP7_75t_L g84 ( 
.A(n_72),
.B(n_58),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_79),
.Y(n_85)
);

BUFx3_ASAP7_75t_L g86 ( 
.A(n_70),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_79),
.Y(n_87)
);

NOR2xp33_ASAP7_75t_L g88 ( 
.A(n_72),
.B(n_68),
.Y(n_88)
);

OAI21x1_ASAP7_75t_L g89 ( 
.A1(n_77),
.A2(n_69),
.B(n_45),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_81),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_81),
.Y(n_91)
);

OAI21x1_ASAP7_75t_L g92 ( 
.A1(n_77),
.A2(n_36),
.B(n_41),
.Y(n_92)
);

AOI211xp5_ASAP7_75t_L g93 ( 
.A1(n_73),
.A2(n_38),
.B(n_42),
.C(n_37),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_70),
.Y(n_94)
);

AO21x2_ASAP7_75t_L g95 ( 
.A1(n_82),
.A2(n_78),
.B(n_75),
.Y(n_95)
);

INVx1_ASAP7_75t_L g96 ( 
.A(n_85),
.Y(n_96)
);

NAND2xp33_ASAP7_75t_R g97 ( 
.A(n_88),
.B(n_71),
.Y(n_97)
);

AND2x2_ASAP7_75t_L g98 ( 
.A(n_85),
.B(n_76),
.Y(n_98)
);

OR2x2_ASAP7_75t_L g99 ( 
.A(n_84),
.B(n_75),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_94),
.Y(n_100)
);

INVx2_ASAP7_75t_L g101 ( 
.A(n_94),
.Y(n_101)
);

AND2x2_ASAP7_75t_L g102 ( 
.A(n_85),
.B(n_76),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_96),
.Y(n_103)
);

INVx2_ASAP7_75t_L g104 ( 
.A(n_100),
.Y(n_104)
);

A2O1A1Ixp33_ASAP7_75t_L g105 ( 
.A1(n_102),
.A2(n_88),
.B(n_84),
.C(n_92),
.Y(n_105)
);

NAND3xp33_ASAP7_75t_L g106 ( 
.A(n_97),
.B(n_93),
.C(n_54),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_96),
.Y(n_107)
);

NAND2xp5_ASAP7_75t_L g108 ( 
.A(n_98),
.B(n_102),
.Y(n_108)
);

INVx2_ASAP7_75t_L g109 ( 
.A(n_100),
.Y(n_109)
);

INVx2_ASAP7_75t_L g110 ( 
.A(n_100),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_103),
.B(n_99),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_103),
.Y(n_112)
);

NOR2xp33_ASAP7_75t_L g113 ( 
.A(n_106),
.B(n_74),
.Y(n_113)
);

AND2x4_ASAP7_75t_L g114 ( 
.A(n_107),
.B(n_101),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_107),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_104),
.Y(n_116)
);

AND2x2_ASAP7_75t_L g117 ( 
.A(n_108),
.B(n_101),
.Y(n_117)
);

OR2x2_ASAP7_75t_L g118 ( 
.A(n_104),
.B(n_101),
.Y(n_118)
);

INVxp67_ASAP7_75t_SL g119 ( 
.A(n_109),
.Y(n_119)
);

INVx1_ASAP7_75t_L g120 ( 
.A(n_109),
.Y(n_120)
);

NAND2xp5_ASAP7_75t_L g121 ( 
.A(n_105),
.B(n_99),
.Y(n_121)
);

AND2x4_ASAP7_75t_L g122 ( 
.A(n_110),
.B(n_85),
.Y(n_122)
);

HB1xp67_ASAP7_75t_L g123 ( 
.A(n_110),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_103),
.B(n_102),
.Y(n_124)
);

INVx1_ASAP7_75t_L g125 ( 
.A(n_112),
.Y(n_125)
);

OR2x6_ASAP7_75t_L g126 ( 
.A(n_121),
.B(n_89),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_112),
.Y(n_127)
);

BUFx3_ASAP7_75t_L g128 ( 
.A(n_123),
.Y(n_128)
);

AND2x2_ASAP7_75t_L g129 ( 
.A(n_119),
.B(n_89),
.Y(n_129)
);

NAND2xp5_ASAP7_75t_L g130 ( 
.A(n_115),
.B(n_92),
.Y(n_130)
);

AND2x2_ASAP7_75t_L g131 ( 
.A(n_119),
.B(n_89),
.Y(n_131)
);

INVx1_ASAP7_75t_L g132 ( 
.A(n_115),
.Y(n_132)
);

INVx2_ASAP7_75t_L g133 ( 
.A(n_116),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_116),
.Y(n_134)
);

AND2x2_ASAP7_75t_L g135 ( 
.A(n_120),
.B(n_89),
.Y(n_135)
);

INVx1_ASAP7_75t_L g136 ( 
.A(n_120),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_114),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_114),
.Y(n_138)
);

INVx2_ASAP7_75t_L g139 ( 
.A(n_118),
.Y(n_139)
);

INVx1_ASAP7_75t_SL g140 ( 
.A(n_118),
.Y(n_140)
);

NAND2x1p5_ASAP7_75t_L g141 ( 
.A(n_122),
.B(n_89),
.Y(n_141)
);

NAND3x1_ASAP7_75t_L g142 ( 
.A(n_113),
.B(n_90),
.C(n_87),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_114),
.Y(n_143)
);

NOR2x1p5_ASAP7_75t_L g144 ( 
.A(n_121),
.B(n_87),
.Y(n_144)
);

INVxp33_ASAP7_75t_L g145 ( 
.A(n_117),
.Y(n_145)
);

INVx3_ASAP7_75t_L g146 ( 
.A(n_122),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_122),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_122),
.Y(n_148)
);

AOI22xp5_ASAP7_75t_SL g149 ( 
.A1(n_145),
.A2(n_111),
.B1(n_124),
.B2(n_117),
.Y(n_149)
);

AOI21xp33_ASAP7_75t_L g150 ( 
.A1(n_142),
.A2(n_95),
.B(n_92),
.Y(n_150)
);

NAND2xp5_ASAP7_75t_L g151 ( 
.A(n_140),
.B(n_95),
.Y(n_151)
);

OAI21xp5_ASAP7_75t_L g152 ( 
.A1(n_142),
.A2(n_80),
.B(n_91),
.Y(n_152)
);

NAND2xp5_ASAP7_75t_L g153 ( 
.A(n_140),
.B(n_125),
.Y(n_153)
);

CKINVDCx5p33_ASAP7_75t_R g154 ( 
.A(n_128),
.Y(n_154)
);

NAND2xp5_ASAP7_75t_L g155 ( 
.A(n_125),
.B(n_95),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_127),
.Y(n_156)
);

INVxp67_ASAP7_75t_L g157 ( 
.A(n_128),
.Y(n_157)
);

OAI21xp5_ASAP7_75t_L g158 ( 
.A1(n_142),
.A2(n_94),
.B(n_78),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_132),
.Y(n_159)
);

OR2x2_ASAP7_75t_L g160 ( 
.A(n_128),
.B(n_1),
.Y(n_160)
);

AOI21xp5_ASAP7_75t_L g161 ( 
.A1(n_129),
.A2(n_94),
.B(n_86),
.Y(n_161)
);

OAI322xp33_ASAP7_75t_L g162 ( 
.A1(n_134),
.A2(n_3),
.A3(n_2),
.B1(n_6),
.B2(n_7),
.C1(n_4),
.C2(n_5),
.Y(n_162)
);

OAI22xp5_ASAP7_75t_L g163 ( 
.A1(n_144),
.A2(n_86),
.B1(n_83),
.B2(n_70),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_133),
.Y(n_164)
);

INVx2_ASAP7_75t_L g165 ( 
.A(n_133),
.Y(n_165)
);

INVx1_ASAP7_75t_L g166 ( 
.A(n_134),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_L g167 ( 
.A(n_139),
.B(n_4),
.Y(n_167)
);

INVx1_ASAP7_75t_L g168 ( 
.A(n_136),
.Y(n_168)
);

NOR3xp33_ASAP7_75t_L g169 ( 
.A(n_130),
.B(n_9),
.C(n_8),
.Y(n_169)
);

AOI21xp5_ASAP7_75t_R g170 ( 
.A1(n_126),
.A2(n_13),
.B(n_12),
.Y(n_170)
);

AND2x4_ASAP7_75t_L g171 ( 
.A(n_137),
.B(n_138),
.Y(n_171)
);

NAND2xp5_ASAP7_75t_L g172 ( 
.A(n_139),
.B(n_14),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_136),
.Y(n_173)
);

O2A1O1Ixp33_ASAP7_75t_SL g174 ( 
.A1(n_130),
.A2(n_17),
.B(n_16),
.C(n_15),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_156),
.Y(n_175)
);

AND2x2_ASAP7_75t_L g176 ( 
.A(n_171),
.B(n_126),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_156),
.Y(n_177)
);

AND2x2_ASAP7_75t_L g178 ( 
.A(n_171),
.B(n_126),
.Y(n_178)
);

AND2x2_ASAP7_75t_L g179 ( 
.A(n_171),
.B(n_126),
.Y(n_179)
);

AND2x2_ASAP7_75t_L g180 ( 
.A(n_164),
.B(n_126),
.Y(n_180)
);

INVx2_ASAP7_75t_L g181 ( 
.A(n_164),
.Y(n_181)
);

INVxp67_ASAP7_75t_L g182 ( 
.A(n_154),
.Y(n_182)
);

OR2x2_ASAP7_75t_L g183 ( 
.A(n_153),
.B(n_137),
.Y(n_183)
);

OR2x2_ASAP7_75t_L g184 ( 
.A(n_151),
.B(n_138),
.Y(n_184)
);

INVx2_ASAP7_75t_SL g185 ( 
.A(n_154),
.Y(n_185)
);

NAND2xp5_ASAP7_75t_L g186 ( 
.A(n_155),
.B(n_135),
.Y(n_186)
);

NAND2xp5_ASAP7_75t_L g187 ( 
.A(n_166),
.B(n_135),
.Y(n_187)
);

INVx1_ASAP7_75t_L g188 ( 
.A(n_159),
.Y(n_188)
);

INVxp67_ASAP7_75t_L g189 ( 
.A(n_149),
.Y(n_189)
);

NAND3xp33_ASAP7_75t_L g190 ( 
.A(n_169),
.B(n_131),
.C(n_129),
.Y(n_190)
);

AND2x2_ASAP7_75t_L g191 ( 
.A(n_165),
.B(n_131),
.Y(n_191)
);

INVx1_ASAP7_75t_L g192 ( 
.A(n_168),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_173),
.Y(n_193)
);

INVxp67_ASAP7_75t_SL g194 ( 
.A(n_157),
.Y(n_194)
);

AND2x4_ASAP7_75t_SL g195 ( 
.A(n_170),
.B(n_146),
.Y(n_195)
);

INVx1_ASAP7_75t_L g196 ( 
.A(n_160),
.Y(n_196)
);

NAND2xp5_ASAP7_75t_SL g197 ( 
.A(n_158),
.B(n_146),
.Y(n_197)
);

INVx2_ASAP7_75t_L g198 ( 
.A(n_167),
.Y(n_198)
);

NAND2xp5_ASAP7_75t_L g199 ( 
.A(n_172),
.B(n_147),
.Y(n_199)
);

NOR2xp33_ASAP7_75t_SL g200 ( 
.A(n_163),
.B(n_141),
.Y(n_200)
);

NAND2xp5_ASAP7_75t_L g201 ( 
.A(n_161),
.B(n_147),
.Y(n_201)
);

NAND2xp5_ASAP7_75t_L g202 ( 
.A(n_196),
.B(n_148),
.Y(n_202)
);

NAND2xp5_ASAP7_75t_SL g203 ( 
.A(n_200),
.B(n_146),
.Y(n_203)
);

AOI221xp5_ASAP7_75t_L g204 ( 
.A1(n_190),
.A2(n_162),
.B1(n_174),
.B2(n_150),
.C(n_152),
.Y(n_204)
);

OAI211xp5_ASAP7_75t_L g205 ( 
.A1(n_182),
.A2(n_143),
.B(n_19),
.C(n_22),
.Y(n_205)
);

INVx1_ASAP7_75t_SL g206 ( 
.A(n_185),
.Y(n_206)
);

INVx2_ASAP7_75t_SL g207 ( 
.A(n_185),
.Y(n_207)
);

OAI211xp5_ASAP7_75t_L g208 ( 
.A1(n_194),
.A2(n_30),
.B(n_29),
.C(n_27),
.Y(n_208)
);

OAI21xp33_ASAP7_75t_SL g209 ( 
.A1(n_197),
.A2(n_31),
.B(n_176),
.Y(n_209)
);

AOI211xp5_ASAP7_75t_SL g210 ( 
.A1(n_176),
.A2(n_178),
.B(n_179),
.C(n_201),
.Y(n_210)
);

OAI22xp5_ASAP7_75t_L g211 ( 
.A1(n_195),
.A2(n_186),
.B1(n_178),
.B2(n_179),
.Y(n_211)
);

AND2x2_ASAP7_75t_L g212 ( 
.A(n_191),
.B(n_180),
.Y(n_212)
);

AOI221xp5_ASAP7_75t_L g213 ( 
.A1(n_198),
.A2(n_193),
.B1(n_192),
.B2(n_188),
.C(n_187),
.Y(n_213)
);

OAI211xp5_ASAP7_75t_SL g214 ( 
.A1(n_198),
.A2(n_199),
.B(n_183),
.C(n_184),
.Y(n_214)
);

AOI321xp33_ASAP7_75t_L g215 ( 
.A1(n_180),
.A2(n_186),
.A3(n_191),
.B1(n_184),
.B2(n_177),
.C(n_175),
.Y(n_215)
);

NAND2xp5_ASAP7_75t_SL g216 ( 
.A(n_195),
.B(n_181),
.Y(n_216)
);

CKINVDCx20_ASAP7_75t_R g217 ( 
.A(n_206),
.Y(n_217)
);

INVx1_ASAP7_75t_L g218 ( 
.A(n_214),
.Y(n_218)
);

XOR2xp5_ASAP7_75t_L g219 ( 
.A(n_211),
.B(n_207),
.Y(n_219)
);

INVx1_ASAP7_75t_L g220 ( 
.A(n_202),
.Y(n_220)
);

INVxp67_ASAP7_75t_L g221 ( 
.A(n_213),
.Y(n_221)
);

AOI22xp5_ASAP7_75t_L g222 ( 
.A1(n_209),
.A2(n_216),
.B1(n_203),
.B2(n_205),
.Y(n_222)
);

AOI222xp33_ASAP7_75t_L g223 ( 
.A1(n_203),
.A2(n_189),
.B1(n_204),
.B2(n_190),
.C1(n_216),
.C2(n_214),
.Y(n_223)
);

NAND3xp33_ASAP7_75t_L g224 ( 
.A(n_215),
.B(n_210),
.C(n_208),
.Y(n_224)
);

NOR2x1p5_ASAP7_75t_L g225 ( 
.A(n_224),
.B(n_212),
.Y(n_225)
);

NOR2xp33_ASAP7_75t_R g226 ( 
.A(n_217),
.B(n_218),
.Y(n_226)
);

NAND2xp33_ASAP7_75t_L g227 ( 
.A(n_219),
.B(n_222),
.Y(n_227)
);

BUFx8_ASAP7_75t_SL g228 ( 
.A(n_220),
.Y(n_228)
);

CKINVDCx16_ASAP7_75t_R g229 ( 
.A(n_223),
.Y(n_229)
);

CKINVDCx5p33_ASAP7_75t_R g230 ( 
.A(n_221),
.Y(n_230)
);

INVx1_ASAP7_75t_SL g231 ( 
.A(n_228),
.Y(n_231)
);

CKINVDCx5p33_ASAP7_75t_R g232 ( 
.A(n_226),
.Y(n_232)
);

OAI22xp5_ASAP7_75t_L g233 ( 
.A1(n_232),
.A2(n_229),
.B1(n_225),
.B2(n_221),
.Y(n_233)
);

BUFx2_ASAP7_75t_L g234 ( 
.A(n_231),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_234),
.Y(n_235)
);

AOI22xp33_ASAP7_75t_L g236 ( 
.A1(n_235),
.A2(n_229),
.B1(n_233),
.B2(n_225),
.Y(n_236)
);

AOI21xp5_ASAP7_75t_L g237 ( 
.A1(n_236),
.A2(n_227),
.B(n_230),
.Y(n_237)
);


endmodule