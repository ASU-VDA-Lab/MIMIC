module fake_netlist_684_2874_n_70 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_70);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_70;

wire n_54;
wire n_50;
wire n_24;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_66;
wire n_47;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_46;
wire n_31;
wire n_41;
wire n_69;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_68;
wire n_33;
wire n_65;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_67;
wire n_39;
wire n_55;

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_10),
.B(n_1),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_0),
.B(n_13),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_20),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_7),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_10),
.A2(n_14),
.B1(n_9),
.B2(n_20),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_18),
.B(n_15),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_17),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_11),
.B(n_18),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_11),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_4),
.B(n_21),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_30),
.B(n_2),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_32),
.A2(n_17),
.B1(n_16),
.B2(n_8),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_8),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_28),
.A2(n_5),
.B(n_3),
.Y(n_39)
);

AOI21xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_25),
.B(n_28),
.Y(n_40)
);

AOI21x1_ASAP7_75t_SL g41 ( 
.A1(n_38),
.A2(n_25),
.B(n_35),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_33),
.B1(n_35),
.B2(n_30),
.Y(n_42)
);

BUFx6f_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

OA21x2_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_26),
.B(n_25),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_42),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_44),
.Y(n_48)
);

INVx2_ASAP7_75t_SL g49 ( 
.A(n_47),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_43),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_50),
.Y(n_51)
);

OAI311xp33_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_29),
.A3(n_37),
.B1(n_27),
.C1(n_33),
.Y(n_52)
);

OAI221xp5_ASAP7_75t_L g53 ( 
.A1(n_48),
.A2(n_29),
.B1(n_43),
.B2(n_34),
.C(n_44),
.Y(n_53)
);

AOI321xp33_ASAP7_75t_L g54 ( 
.A1(n_48),
.A2(n_34),
.A3(n_33),
.B1(n_24),
.B2(n_26),
.C(n_46),
.Y(n_54)
);

O2A1O1Ixp5_ASAP7_75t_L g55 ( 
.A1(n_50),
.A2(n_46),
.B(n_47),
.C(n_43),
.Y(n_55)
);

NOR4xp25_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_48),
.C(n_21),
.D(n_16),
.Y(n_56)
);

AOI211xp5_ASAP7_75t_L g57 ( 
.A1(n_52),
.A2(n_31),
.B(n_36),
.C(n_48),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_50),
.Y(n_58)
);

NAND4xp75_ASAP7_75t_L g59 ( 
.A(n_51),
.B(n_44),
.C(n_49),
.D(n_22),
.Y(n_59)
);

OAI211xp5_ASAP7_75t_L g60 ( 
.A1(n_54),
.A2(n_31),
.B(n_43),
.C(n_49),
.Y(n_60)
);

OAI221xp5_ASAP7_75t_SL g61 ( 
.A1(n_54),
.A2(n_49),
.B1(n_31),
.B2(n_22),
.C(n_23),
.Y(n_61)
);

NOR4xp75_ASAP7_75t_L g62 ( 
.A(n_59),
.B(n_23),
.C(n_31),
.D(n_6),
.Y(n_62)
);

AND3x2_ASAP7_75t_L g63 ( 
.A(n_57),
.B(n_51),
.C(n_50),
.Y(n_63)
);

NAND4xp75_ASAP7_75t_L g64 ( 
.A(n_58),
.B(n_55),
.C(n_49),
.D(n_31),
.Y(n_64)
);

NAND4xp75_ASAP7_75t_L g65 ( 
.A(n_58),
.B(n_56),
.C(n_61),
.D(n_60),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_65),
.Y(n_66)
);

AND2x2_ASAP7_75t_SL g67 ( 
.A(n_63),
.B(n_50),
.Y(n_67)
);

OAI22xp5_ASAP7_75t_L g68 ( 
.A1(n_64),
.A2(n_49),
.B1(n_50),
.B2(n_62),
.Y(n_68)
);

AOI22xp5_ASAP7_75t_L g69 ( 
.A1(n_66),
.A2(n_49),
.B1(n_50),
.B2(n_67),
.Y(n_69)
);

AOI221xp5_ASAP7_75t_L g70 ( 
.A1(n_69),
.A2(n_50),
.B1(n_68),
.B2(n_66),
.C(n_56),
.Y(n_70)
);


endmodule