module fake_netlist_684_2894_n_305 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_35, n_34, n_16, n_26, n_1, n_5, n_7, n_23, n_31, n_29, n_33, n_8, n_0, n_4, n_32, n_28, n_3, n_11, n_19, n_30, n_25, n_10, n_13, n_14, n_12, n_305);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_35;
input n_34;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_31;
input n_29;
input n_33;
input n_8;
input n_0;
input n_4;
input n_32;
input n_28;
input n_3;
input n_11;
input n_19;
input n_30;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_305;

wire n_61;
wire n_99;
wire n_210;
wire n_115;
wire n_233;
wire n_219;
wire n_264;
wire n_110;
wire n_148;
wire n_301;
wire n_278;
wire n_86;
wire n_147;
wire n_171;
wire n_230;
wire n_102;
wire n_40;
wire n_66;
wire n_165;
wire n_88;
wire n_235;
wire n_47;
wire n_119;
wire n_175;
wire n_196;
wire n_259;
wire n_260;
wire n_243;
wire n_52;
wire n_220;
wire n_213;
wire n_71;
wire n_150;
wire n_162;
wire n_234;
wire n_252;
wire n_157;
wire n_179;
wire n_284;
wire n_121;
wire n_182;
wire n_60;
wire n_189;
wire n_261;
wire n_89;
wire n_114;
wire n_181;
wire n_194;
wire n_211;
wire n_212;
wire n_112;
wire n_197;
wire n_256;
wire n_59;
wire n_48;
wire n_246;
wire n_262;
wire n_271;
wire n_67;
wire n_39;
wire n_50;
wire n_113;
wire n_83;
wire n_229;
wire n_131;
wire n_45;
wire n_204;
wire n_124;
wire n_158;
wire n_163;
wire n_130;
wire n_156;
wire n_272;
wire n_64;
wire n_190;
wire n_298;
wire n_146;
wire n_85;
wire n_277;
wire n_136;
wire n_58;
wire n_218;
wire n_288;
wire n_62;
wire n_200;
wire n_76;
wire n_63;
wire n_184;
wire n_265;
wire n_70;
wire n_224;
wire n_69;
wire n_101;
wire n_141;
wire n_123;
wire n_249;
wire n_53;
wire n_275;
wire n_267;
wire n_109;
wire n_231;
wire n_173;
wire n_168;
wire n_74;
wire n_250;
wire n_209;
wire n_160;
wire n_176;
wire n_188;
wire n_226;
wire n_144;
wire n_296;
wire n_304;
wire n_285;
wire n_244;
wire n_170;
wire n_187;
wire n_208;
wire n_164;
wire n_295;
wire n_94;
wire n_270;
wire n_149;
wire n_75;
wire n_81;
wire n_161;
wire n_55;
wire n_192;
wire n_281;
wire n_111;
wire n_245;
wire n_54;
wire n_78;
wire n_291;
wire n_207;
wire n_44;
wire n_248;
wire n_38;
wire n_303;
wire n_174;
wire n_203;
wire n_199;
wire n_91;
wire n_167;
wire n_42;
wire n_106;
wire n_236;
wire n_116;
wire n_127;
wire n_238;
wire n_225;
wire n_258;
wire n_100;
wire n_266;
wire n_145;
wire n_43;
wire n_263;
wire n_84;
wire n_287;
wire n_177;
wire n_37;
wire n_51;
wire n_240;
wire n_191;
wire n_292;
wire n_68;
wire n_140;
wire n_92;
wire n_247;
wire n_241;
wire n_195;
wire n_289;
wire n_251;
wire n_129;
wire n_90;
wire n_143;
wire n_169;
wire n_276;
wire n_77;
wire n_117;
wire n_82;
wire n_134;
wire n_152;
wire n_180;
wire n_228;
wire n_128;
wire n_202;
wire n_172;
wire n_93;
wire n_193;
wire n_118;
wire n_97;
wire n_186;
wire n_280;
wire n_214;
wire n_216;
wire n_95;
wire n_98;
wire n_103;
wire n_293;
wire n_282;
wire n_135;
wire n_222;
wire n_279;
wire n_125;
wire n_122;
wire n_79;
wire n_178;
wire n_154;
wire n_237;
wire n_104;
wire n_283;
wire n_294;
wire n_105;
wire n_215;
wire n_139;
wire n_133;
wire n_183;
wire n_155;
wire n_120;
wire n_242;
wire n_297;
wire n_217;
wire n_302;
wire n_274;
wire n_254;
wire n_137;
wire n_46;
wire n_73;
wire n_87;
wire n_41;
wire n_205;
wire n_185;
wire n_56;
wire n_159;
wire n_255;
wire n_290;
wire n_107;
wire n_65;
wire n_80;
wire n_132;
wire n_72;
wire n_227;
wire n_232;
wire n_138;
wire n_257;
wire n_273;
wire n_268;
wire n_151;
wire n_299;
wire n_153;
wire n_201;
wire n_36;
wire n_142;
wire n_126;
wire n_269;
wire n_253;
wire n_223;
wire n_221;
wire n_206;
wire n_49;
wire n_57;
wire n_300;
wire n_96;
wire n_239;
wire n_166;
wire n_286;
wire n_198;
wire n_108;

INVx1_ASAP7_75t_L g36 ( 
.A(n_11),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_23),
.Y(n_37)
);

INVx4_ASAP7_75t_R g38 ( 
.A(n_18),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_21),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_11),
.Y(n_40)
);

INVxp33_ASAP7_75t_L g41 ( 
.A(n_6),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_2),
.Y(n_42)
);

CKINVDCx16_ASAP7_75t_R g43 ( 
.A(n_4),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_13),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_14),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_34),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_19),
.Y(n_47)
);

INVxp67_ASAP7_75t_L g48 ( 
.A(n_24),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_37),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_43),
.B(n_0),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_37),
.Y(n_51)
);

AND2x6_ASAP7_75t_L g52 ( 
.A(n_39),
.B(n_16),
.Y(n_52)
);

BUFx6f_ASAP7_75t_L g53 ( 
.A(n_39),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_36),
.B(n_0),
.Y(n_54)
);

INVx3_ASAP7_75t_L g55 ( 
.A(n_46),
.Y(n_55)
);

BUFx6f_ASAP7_75t_L g56 ( 
.A(n_46),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_47),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

INVx1_ASAP7_75t_SL g59 ( 
.A(n_50),
.Y(n_59)
);

AND2x2_ASAP7_75t_L g60 ( 
.A(n_50),
.B(n_41),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_53),
.Y(n_61)
);

AOI22xp5_ASAP7_75t_L g62 ( 
.A1(n_50),
.A2(n_43),
.B1(n_42),
.B2(n_36),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_53),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_53),
.Y(n_64)
);

NOR2x1p5_ASAP7_75t_L g65 ( 
.A(n_54),
.B(n_44),
.Y(n_65)
);

NAND2x1p5_ASAP7_75t_L g66 ( 
.A(n_49),
.B(n_47),
.Y(n_66)
);

BUFx6f_ASAP7_75t_L g67 ( 
.A(n_53),
.Y(n_67)
);

NOR2x1p5_ASAP7_75t_L g68 ( 
.A(n_54),
.B(n_44),
.Y(n_68)
);

AND2x6_ASAP7_75t_L g69 ( 
.A(n_49),
.B(n_45),
.Y(n_69)
);

AND2x4_ASAP7_75t_L g70 ( 
.A(n_49),
.B(n_40),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_53),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_53),
.Y(n_72)
);

INVx2_ASAP7_75t_SL g73 ( 
.A(n_55),
.Y(n_73)
);

AND2x4_ASAP7_75t_L g74 ( 
.A(n_57),
.B(n_40),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_73),
.Y(n_75)
);

AND2x4_ASAP7_75t_L g76 ( 
.A(n_68),
.B(n_65),
.Y(n_76)
);

OR2x6_ASAP7_75t_L g77 ( 
.A(n_66),
.B(n_45),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_73),
.Y(n_78)
);

AND2x6_ASAP7_75t_L g79 ( 
.A(n_70),
.B(n_59),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_66),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_67),
.Y(n_81)
);

NAND2xp5_ASAP7_75t_L g82 ( 
.A(n_66),
.B(n_55),
.Y(n_82)
);

HB1xp67_ASAP7_75t_L g83 ( 
.A(n_69),
.Y(n_83)
);

AND2x4_ASAP7_75t_L g84 ( 
.A(n_74),
.B(n_57),
.Y(n_84)
);

AND2x4_ASAP7_75t_SL g85 ( 
.A(n_60),
.B(n_55),
.Y(n_85)
);

NOR2xp33_ASAP7_75t_L g86 ( 
.A(n_60),
.B(n_55),
.Y(n_86)
);

INVx1_ASAP7_75t_SL g87 ( 
.A(n_69),
.Y(n_87)
);

BUFx6f_ASAP7_75t_L g88 ( 
.A(n_67),
.Y(n_88)
);

INVx3_ASAP7_75t_L g89 ( 
.A(n_69),
.Y(n_89)
);

INVx3_ASAP7_75t_L g90 ( 
.A(n_69),
.Y(n_90)
);

INVxp67_ASAP7_75t_SL g91 ( 
.A(n_70),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_69),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_69),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_75),
.Y(n_94)
);

AOI22xp5_ASAP7_75t_L g95 ( 
.A1(n_77),
.A2(n_62),
.B1(n_69),
.B2(n_74),
.Y(n_95)
);

INVx1_ASAP7_75t_L g96 ( 
.A(n_91),
.Y(n_96)
);

NAND2xp5_ASAP7_75t_L g97 ( 
.A(n_85),
.B(n_74),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_85),
.B(n_74),
.Y(n_98)
);

AOI22xp5_ASAP7_75t_L g99 ( 
.A1(n_77),
.A2(n_70),
.B1(n_52),
.B2(n_55),
.Y(n_99)
);

BUFx4f_ASAP7_75t_L g100 ( 
.A(n_77),
.Y(n_100)
);

BUFx8_ASAP7_75t_L g101 ( 
.A(n_79),
.Y(n_101)
);

NOR2xp33_ASAP7_75t_L g102 ( 
.A(n_76),
.B(n_70),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_91),
.Y(n_103)
);

AO21x1_ASAP7_75t_L g104 ( 
.A1(n_82),
.A2(n_51),
.B(n_58),
.Y(n_104)
);

AOI22xp33_ASAP7_75t_SL g105 ( 
.A1(n_79),
.A2(n_52),
.B1(n_51),
.B2(n_53),
.Y(n_105)
);

NAND2xp5_ASAP7_75t_L g106 ( 
.A(n_85),
.B(n_51),
.Y(n_106)
);

INVx3_ASAP7_75t_L g107 ( 
.A(n_77),
.Y(n_107)
);

INVx3_ASAP7_75t_L g108 ( 
.A(n_77),
.Y(n_108)
);

OR2x2_ASAP7_75t_L g109 ( 
.A(n_96),
.B(n_77),
.Y(n_109)
);

INVx2_ASAP7_75t_L g110 ( 
.A(n_94),
.Y(n_110)
);

AOI21xp33_ASAP7_75t_L g111 ( 
.A1(n_104),
.A2(n_86),
.B(n_80),
.Y(n_111)
);

INVx2_ASAP7_75t_L g112 ( 
.A(n_94),
.Y(n_112)
);

AOI22xp33_ASAP7_75t_L g113 ( 
.A1(n_100),
.A2(n_79),
.B1(n_84),
.B2(n_76),
.Y(n_113)
);

INVxp67_ASAP7_75t_L g114 ( 
.A(n_100),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_96),
.Y(n_115)
);

INVxp33_ASAP7_75t_L g116 ( 
.A(n_102),
.Y(n_116)
);

BUFx3_ASAP7_75t_L g117 ( 
.A(n_100),
.Y(n_117)
);

OAI22xp33_ASAP7_75t_L g118 ( 
.A1(n_95),
.A2(n_80),
.B1(n_82),
.B2(n_51),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_110),
.Y(n_119)
);

AOI22xp33_ASAP7_75t_L g120 ( 
.A1(n_116),
.A2(n_79),
.B1(n_76),
.B2(n_101),
.Y(n_120)
);

AOI22xp33_ASAP7_75t_SL g121 ( 
.A1(n_117),
.A2(n_101),
.B1(n_108),
.B2(n_107),
.Y(n_121)
);

OAI21xp5_ASAP7_75t_L g122 ( 
.A1(n_111),
.A2(n_99),
.B(n_105),
.Y(n_122)
);

AOI22xp33_ASAP7_75t_L g123 ( 
.A1(n_118),
.A2(n_79),
.B1(n_76),
.B2(n_101),
.Y(n_123)
);

HB1xp67_ASAP7_75t_L g124 ( 
.A(n_109),
.Y(n_124)
);

INVx1_ASAP7_75t_L g125 ( 
.A(n_110),
.Y(n_125)
);

BUFx2_ASAP7_75t_L g126 ( 
.A(n_109),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_110),
.Y(n_127)
);

INVx2_ASAP7_75t_L g128 ( 
.A(n_112),
.Y(n_128)
);

NAND2xp5_ASAP7_75t_L g129 ( 
.A(n_119),
.B(n_115),
.Y(n_129)
);

OAI21xp5_ASAP7_75t_L g130 ( 
.A1(n_122),
.A2(n_111),
.B(n_118),
.Y(n_130)
);

INVx2_ASAP7_75t_L g131 ( 
.A(n_128),
.Y(n_131)
);

INVx1_ASAP7_75t_SL g132 ( 
.A(n_128),
.Y(n_132)
);

BUFx2_ASAP7_75t_L g133 ( 
.A(n_128),
.Y(n_133)
);

OAI33xp33_ASAP7_75t_L g134 ( 
.A1(n_119),
.A2(n_48),
.A3(n_115),
.B1(n_98),
.B2(n_97),
.B3(n_106),
.Y(n_134)
);

BUFx3_ASAP7_75t_L g135 ( 
.A(n_125),
.Y(n_135)
);

INVx1_ASAP7_75t_L g136 ( 
.A(n_125),
.Y(n_136)
);

AO22x1_ASAP7_75t_L g137 ( 
.A1(n_126),
.A2(n_117),
.B1(n_114),
.B2(n_107),
.Y(n_137)
);

OA21x2_ASAP7_75t_L g138 ( 
.A1(n_122),
.A2(n_104),
.B(n_112),
.Y(n_138)
);

AOI21xp5_ASAP7_75t_L g139 ( 
.A1(n_127),
.A2(n_112),
.B(n_107),
.Y(n_139)
);

OAI211xp5_ASAP7_75t_SL g140 ( 
.A1(n_120),
.A2(n_113),
.B(n_114),
.C(n_108),
.Y(n_140)
);

BUFx2_ASAP7_75t_L g141 ( 
.A(n_127),
.Y(n_141)
);

INVx4_ASAP7_75t_L g142 ( 
.A(n_126),
.Y(n_142)
);

OAI221xp5_ASAP7_75t_L g143 ( 
.A1(n_123),
.A2(n_113),
.B1(n_103),
.B2(n_117),
.C(n_108),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_124),
.Y(n_144)
);

INVx2_ASAP7_75t_SL g145 ( 
.A(n_121),
.Y(n_145)
);

INVxp67_ASAP7_75t_SL g146 ( 
.A(n_141),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_136),
.Y(n_147)
);

NOR3xp33_ASAP7_75t_L g148 ( 
.A(n_134),
.B(n_121),
.C(n_103),
.Y(n_148)
);

OAI211xp5_ASAP7_75t_L g149 ( 
.A1(n_145),
.A2(n_56),
.B(n_61),
.C(n_58),
.Y(n_149)
);

AND2x2_ASAP7_75t_L g150 ( 
.A(n_141),
.B(n_133),
.Y(n_150)
);

NAND4xp25_ASAP7_75t_SL g151 ( 
.A(n_143),
.B(n_3),
.C(n_2),
.D(n_1),
.Y(n_151)
);

AOI221xp5_ASAP7_75t_SL g152 ( 
.A1(n_144),
.A2(n_56),
.B1(n_64),
.B2(n_61),
.C(n_63),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_136),
.Y(n_153)
);

AND2x4_ASAP7_75t_L g154 ( 
.A(n_135),
.B(n_56),
.Y(n_154)
);

INVx2_ASAP7_75t_L g155 ( 
.A(n_131),
.Y(n_155)
);

AND2x2_ASAP7_75t_L g156 ( 
.A(n_133),
.B(n_56),
.Y(n_156)
);

OAI211xp5_ASAP7_75t_SL g157 ( 
.A1(n_144),
.A2(n_71),
.B(n_64),
.C(n_63),
.Y(n_157)
);

OAI21xp5_ASAP7_75t_L g158 ( 
.A1(n_139),
.A2(n_79),
.B(n_52),
.Y(n_158)
);

INVx5_ASAP7_75t_SL g159 ( 
.A(n_131),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_135),
.Y(n_160)
);

CKINVDCx16_ASAP7_75t_R g161 ( 
.A(n_145),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_135),
.Y(n_162)
);

INVx4_ASAP7_75t_L g163 ( 
.A(n_142),
.Y(n_163)
);

OAI31xp33_ASAP7_75t_L g164 ( 
.A1(n_145),
.A2(n_84),
.A3(n_79),
.B(n_87),
.Y(n_164)
);

INVx1_ASAP7_75t_SL g165 ( 
.A(n_132),
.Y(n_165)
);

AND2x2_ASAP7_75t_L g166 ( 
.A(n_132),
.B(n_56),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_L g167 ( 
.A(n_129),
.B(n_79),
.Y(n_167)
);

NAND2xp5_ASAP7_75t_L g168 ( 
.A(n_129),
.B(n_79),
.Y(n_168)
);

INVx1_ASAP7_75t_L g169 ( 
.A(n_131),
.Y(n_169)
);

OAI22xp5_ASAP7_75t_L g170 ( 
.A1(n_143),
.A2(n_84),
.B1(n_87),
.B2(n_83),
.Y(n_170)
);

OR2x2_ASAP7_75t_L g171 ( 
.A(n_142),
.B(n_56),
.Y(n_171)
);

OAI31xp33_ASAP7_75t_L g172 ( 
.A1(n_140),
.A2(n_84),
.A3(n_78),
.B(n_75),
.Y(n_172)
);

AND2x2_ASAP7_75t_L g173 ( 
.A(n_138),
.B(n_56),
.Y(n_173)
);

OR2x2_ASAP7_75t_L g174 ( 
.A(n_161),
.B(n_142),
.Y(n_174)
);

INVxp67_ASAP7_75t_L g175 ( 
.A(n_146),
.Y(n_175)
);

HB1xp67_ASAP7_75t_L g176 ( 
.A(n_150),
.Y(n_176)
);

NAND2xp5_ASAP7_75t_L g177 ( 
.A(n_147),
.B(n_142),
.Y(n_177)
);

INVx1_ASAP7_75t_L g178 ( 
.A(n_147),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_153),
.Y(n_179)
);

NAND2xp5_ASAP7_75t_L g180 ( 
.A(n_153),
.B(n_130),
.Y(n_180)
);

INVx1_ASAP7_75t_L g181 ( 
.A(n_169),
.Y(n_181)
);

NOR4xp75_ASAP7_75t_L g182 ( 
.A(n_158),
.B(n_130),
.C(n_3),
.D(n_1),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_169),
.Y(n_183)
);

NAND2x1p5_ASAP7_75t_L g184 ( 
.A(n_163),
.B(n_139),
.Y(n_184)
);

AND2x2_ASAP7_75t_L g185 ( 
.A(n_150),
.B(n_138),
.Y(n_185)
);

NOR2x1_ASAP7_75t_L g186 ( 
.A(n_163),
.B(n_140),
.Y(n_186)
);

OR2x6_ASAP7_75t_L g187 ( 
.A(n_163),
.B(n_137),
.Y(n_187)
);

AOI221xp5_ASAP7_75t_L g188 ( 
.A1(n_151),
.A2(n_56),
.B1(n_137),
.B2(n_71),
.C(n_67),
.Y(n_188)
);

OAI22xp33_ASAP7_75t_L g189 ( 
.A1(n_161),
.A2(n_138),
.B1(n_83),
.B2(n_89),
.Y(n_189)
);

INVx1_ASAP7_75t_L g190 ( 
.A(n_160),
.Y(n_190)
);

AND2x2_ASAP7_75t_L g191 ( 
.A(n_155),
.B(n_138),
.Y(n_191)
);

AOI22xp33_ASAP7_75t_L g192 ( 
.A1(n_148),
.A2(n_138),
.B1(n_52),
.B2(n_67),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_160),
.Y(n_193)
);

INVx2_ASAP7_75t_L g194 ( 
.A(n_155),
.Y(n_194)
);

OR2x2_ASAP7_75t_L g195 ( 
.A(n_165),
.B(n_4),
.Y(n_195)
);

INVx2_ASAP7_75t_L g196 ( 
.A(n_173),
.Y(n_196)
);

NAND2x1_ASAP7_75t_SL g197 ( 
.A(n_162),
.B(n_5),
.Y(n_197)
);

OR2x2_ASAP7_75t_L g198 ( 
.A(n_162),
.B(n_5),
.Y(n_198)
);

O2A1O1Ixp33_ASAP7_75t_L g199 ( 
.A1(n_172),
.A2(n_72),
.B(n_93),
.C(n_92),
.Y(n_199)
);

AND2x2_ASAP7_75t_L g200 ( 
.A(n_156),
.B(n_6),
.Y(n_200)
);

AND2x2_ASAP7_75t_L g201 ( 
.A(n_156),
.B(n_7),
.Y(n_201)
);

INVx3_ASAP7_75t_SL g202 ( 
.A(n_154),
.Y(n_202)
);

INVx2_ASAP7_75t_L g203 ( 
.A(n_173),
.Y(n_203)
);

NAND2xp5_ASAP7_75t_L g204 ( 
.A(n_167),
.B(n_168),
.Y(n_204)
);

INVx2_ASAP7_75t_L g205 ( 
.A(n_166),
.Y(n_205)
);

OAI33xp33_ASAP7_75t_L g206 ( 
.A1(n_170),
.A2(n_8),
.A3(n_7),
.B1(n_9),
.B2(n_12),
.B3(n_10),
.Y(n_206)
);

OR2x2_ASAP7_75t_L g207 ( 
.A(n_159),
.B(n_8),
.Y(n_207)
);

INVx1_ASAP7_75t_L g208 ( 
.A(n_171),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_171),
.Y(n_209)
);

AOI211xp5_ASAP7_75t_L g210 ( 
.A1(n_172),
.A2(n_67),
.B(n_72),
.C(n_9),
.Y(n_210)
);

INVx1_ASAP7_75t_L g211 ( 
.A(n_178),
.Y(n_211)
);

NAND2x1_ASAP7_75t_L g212 ( 
.A(n_187),
.B(n_154),
.Y(n_212)
);

AOI22xp33_ASAP7_75t_L g213 ( 
.A1(n_206),
.A2(n_164),
.B1(n_154),
.B2(n_159),
.Y(n_213)
);

INVx1_ASAP7_75t_L g214 ( 
.A(n_179),
.Y(n_214)
);

INVx1_ASAP7_75t_L g215 ( 
.A(n_190),
.Y(n_215)
);

AOI22xp5_ASAP7_75t_L g216 ( 
.A1(n_186),
.A2(n_154),
.B1(n_159),
.B2(n_149),
.Y(n_216)
);

INVx1_ASAP7_75t_L g217 ( 
.A(n_193),
.Y(n_217)
);

INVx1_ASAP7_75t_L g218 ( 
.A(n_176),
.Y(n_218)
);

NAND2xp5_ASAP7_75t_L g219 ( 
.A(n_208),
.B(n_159),
.Y(n_219)
);

OR2x2_ASAP7_75t_L g220 ( 
.A(n_209),
.B(n_166),
.Y(n_220)
);

NOR3xp33_ASAP7_75t_L g221 ( 
.A(n_195),
.B(n_152),
.C(n_157),
.Y(n_221)
);

NOR2xp33_ASAP7_75t_L g222 ( 
.A(n_195),
.B(n_10),
.Y(n_222)
);

INVx1_ASAP7_75t_SL g223 ( 
.A(n_202),
.Y(n_223)
);

INVx1_ASAP7_75t_L g224 ( 
.A(n_181),
.Y(n_224)
);

INVx2_ASAP7_75t_L g225 ( 
.A(n_194),
.Y(n_225)
);

AND2x2_ASAP7_75t_L g226 ( 
.A(n_185),
.B(n_164),
.Y(n_226)
);

OAI322xp33_ASAP7_75t_L g227 ( 
.A1(n_198),
.A2(n_13),
.A3(n_12),
.B1(n_14),
.B2(n_15),
.C1(n_78),
.C2(n_38),
.Y(n_227)
);

INVx1_ASAP7_75t_L g228 ( 
.A(n_183),
.Y(n_228)
);

INVx1_ASAP7_75t_L g229 ( 
.A(n_177),
.Y(n_229)
);

CKINVDCx16_ASAP7_75t_R g230 ( 
.A(n_174),
.Y(n_230)
);

CKINVDCx16_ASAP7_75t_R g231 ( 
.A(n_174),
.Y(n_231)
);

AOI22xp33_ASAP7_75t_L g232 ( 
.A1(n_201),
.A2(n_52),
.B1(n_93),
.B2(n_92),
.Y(n_232)
);

AND2x2_ASAP7_75t_L g233 ( 
.A(n_185),
.B(n_15),
.Y(n_233)
);

INVx1_ASAP7_75t_L g234 ( 
.A(n_175),
.Y(n_234)
);

OAI221xp5_ASAP7_75t_L g235 ( 
.A1(n_210),
.A2(n_89),
.B1(n_90),
.B2(n_81),
.C(n_52),
.Y(n_235)
);

OAI221xp5_ASAP7_75t_L g236 ( 
.A1(n_197),
.A2(n_89),
.B1(n_90),
.B2(n_81),
.C(n_52),
.Y(n_236)
);

XNOR2xp5_ASAP7_75t_L g237 ( 
.A(n_182),
.B(n_17),
.Y(n_237)
);

AND2x2_ASAP7_75t_L g238 ( 
.A(n_202),
.B(n_20),
.Y(n_238)
);

A2O1A1Ixp33_ASAP7_75t_L g239 ( 
.A1(n_188),
.A2(n_90),
.B(n_89),
.C(n_22),
.Y(n_239)
);

INVx1_ASAP7_75t_L g240 ( 
.A(n_198),
.Y(n_240)
);

AND2x2_ASAP7_75t_L g241 ( 
.A(n_205),
.B(n_25),
.Y(n_241)
);

OR2x2_ASAP7_75t_L g242 ( 
.A(n_205),
.B(n_26),
.Y(n_242)
);

NAND2xp5_ASAP7_75t_L g243 ( 
.A(n_180),
.B(n_52),
.Y(n_243)
);

NAND4xp25_ASAP7_75t_L g244 ( 
.A(n_192),
.B(n_90),
.C(n_81),
.D(n_52),
.Y(n_244)
);

OAI21xp33_ASAP7_75t_L g245 ( 
.A1(n_192),
.A2(n_28),
.B(n_27),
.Y(n_245)
);

INVx1_ASAP7_75t_L g246 ( 
.A(n_194),
.Y(n_246)
);

NAND2xp5_ASAP7_75t_L g247 ( 
.A(n_229),
.B(n_191),
.Y(n_247)
);

AOI322xp5_ASAP7_75t_L g248 ( 
.A1(n_230),
.A2(n_201),
.A3(n_200),
.B1(n_189),
.B2(n_204),
.C1(n_191),
.C2(n_196),
.Y(n_248)
);

OAI22xp5_ASAP7_75t_L g249 ( 
.A1(n_231),
.A2(n_187),
.B1(n_207),
.B2(n_200),
.Y(n_249)
);

OAI32xp33_ASAP7_75t_L g250 ( 
.A1(n_223),
.A2(n_207),
.A3(n_184),
.B1(n_196),
.B2(n_203),
.Y(n_250)
);

NAND2xp5_ASAP7_75t_L g251 ( 
.A(n_233),
.B(n_203),
.Y(n_251)
);

NAND2xp5_ASAP7_75t_L g252 ( 
.A(n_233),
.B(n_187),
.Y(n_252)
);

NAND2x1_ASAP7_75t_L g253 ( 
.A(n_218),
.B(n_187),
.Y(n_253)
);

INVx1_ASAP7_75t_L g254 ( 
.A(n_211),
.Y(n_254)
);

NOR2xp33_ASAP7_75t_L g255 ( 
.A(n_234),
.B(n_184),
.Y(n_255)
);

AOI21xp33_ASAP7_75t_L g256 ( 
.A1(n_222),
.A2(n_199),
.B(n_29),
.Y(n_256)
);

OAI22xp5_ASAP7_75t_L g257 ( 
.A1(n_212),
.A2(n_32),
.B1(n_31),
.B2(n_30),
.Y(n_257)
);

NOR2x1_ASAP7_75t_L g258 ( 
.A(n_238),
.B(n_33),
.Y(n_258)
);

INVx1_ASAP7_75t_L g259 ( 
.A(n_214),
.Y(n_259)
);

INVx1_ASAP7_75t_L g260 ( 
.A(n_215),
.Y(n_260)
);

NOR2xp33_ASAP7_75t_R g261 ( 
.A(n_237),
.B(n_35),
.Y(n_261)
);

INVx1_ASAP7_75t_L g262 ( 
.A(n_217),
.Y(n_262)
);

AND2x2_ASAP7_75t_L g263 ( 
.A(n_226),
.B(n_52),
.Y(n_263)
);

NAND2xp5_ASAP7_75t_L g264 ( 
.A(n_240),
.B(n_52),
.Y(n_264)
);

INVx1_ASAP7_75t_L g265 ( 
.A(n_224),
.Y(n_265)
);

INVx1_ASAP7_75t_L g266 ( 
.A(n_228),
.Y(n_266)
);

INVx2_ASAP7_75t_L g267 ( 
.A(n_225),
.Y(n_267)
);

INVx1_ASAP7_75t_L g268 ( 
.A(n_246),
.Y(n_268)
);

AND2x2_ASAP7_75t_L g269 ( 
.A(n_226),
.B(n_88),
.Y(n_269)
);

OR2x2_ASAP7_75t_L g270 ( 
.A(n_220),
.B(n_88),
.Y(n_270)
);

OR2x2_ASAP7_75t_L g271 ( 
.A(n_225),
.B(n_88),
.Y(n_271)
);

INVx1_ASAP7_75t_L g272 ( 
.A(n_254),
.Y(n_272)
);

A2O1A1O1Ixp25_ASAP7_75t_L g273 ( 
.A1(n_249),
.A2(n_222),
.B(n_235),
.C(n_245),
.D(n_239),
.Y(n_273)
);

NAND2xp5_ASAP7_75t_L g274 ( 
.A(n_247),
.B(n_219),
.Y(n_274)
);

OAI211xp5_ASAP7_75t_L g275 ( 
.A1(n_248),
.A2(n_213),
.B(n_216),
.C(n_221),
.Y(n_275)
);

INVx1_ASAP7_75t_L g276 ( 
.A(n_259),
.Y(n_276)
);

BUFx12f_ASAP7_75t_L g277 ( 
.A(n_261),
.Y(n_277)
);

AOI211xp5_ASAP7_75t_L g278 ( 
.A1(n_250),
.A2(n_227),
.B(n_221),
.C(n_244),
.Y(n_278)
);

NAND2xp5_ASAP7_75t_L g279 ( 
.A(n_260),
.B(n_213),
.Y(n_279)
);

AOI21xp5_ASAP7_75t_L g280 ( 
.A1(n_253),
.A2(n_239),
.B(n_241),
.Y(n_280)
);

OAI22xp5_ASAP7_75t_SL g281 ( 
.A1(n_252),
.A2(n_236),
.B1(n_242),
.B2(n_232),
.Y(n_281)
);

NAND2xp5_ASAP7_75t_L g282 ( 
.A(n_262),
.B(n_243),
.Y(n_282)
);

NAND2xp5_ASAP7_75t_SL g283 ( 
.A(n_258),
.B(n_255),
.Y(n_283)
);

OAI32xp33_ASAP7_75t_SL g284 ( 
.A1(n_261),
.A2(n_88),
.A3(n_232),
.B1(n_266),
.B2(n_265),
.Y(n_284)
);

NAND2xp5_ASAP7_75t_L g285 ( 
.A(n_268),
.B(n_88),
.Y(n_285)
);

XOR2x1_ASAP7_75t_L g286 ( 
.A(n_277),
.B(n_257),
.Y(n_286)
);

BUFx8_ASAP7_75t_SL g287 ( 
.A(n_277),
.Y(n_287)
);

OAI21xp5_ASAP7_75t_SL g288 ( 
.A1(n_275),
.A2(n_256),
.B(n_255),
.Y(n_288)
);

O2A1O1Ixp33_ASAP7_75t_L g289 ( 
.A1(n_278),
.A2(n_263),
.B(n_264),
.C(n_269),
.Y(n_289)
);

AOI322xp5_ASAP7_75t_L g290 ( 
.A1(n_279),
.A2(n_251),
.A3(n_263),
.B1(n_269),
.B2(n_267),
.C1(n_270),
.C2(n_271),
.Y(n_290)
);

NOR2x1p5_ASAP7_75t_L g291 ( 
.A(n_274),
.B(n_267),
.Y(n_291)
);

INVx1_ASAP7_75t_L g292 ( 
.A(n_272),
.Y(n_292)
);

NOR2x1_ASAP7_75t_L g293 ( 
.A(n_283),
.B(n_88),
.Y(n_293)
);

HB1xp67_ASAP7_75t_L g294 ( 
.A(n_292),
.Y(n_294)
);

AOI221xp5_ASAP7_75t_L g295 ( 
.A1(n_288),
.A2(n_284),
.B1(n_276),
.B2(n_281),
.C(n_282),
.Y(n_295)
);

NAND2xp5_ASAP7_75t_L g296 ( 
.A(n_290),
.B(n_283),
.Y(n_296)
);

OAI211xp5_ASAP7_75t_SL g297 ( 
.A1(n_289),
.A2(n_280),
.B(n_273),
.C(n_285),
.Y(n_297)
);

NOR2x1_ASAP7_75t_L g298 ( 
.A(n_297),
.B(n_293),
.Y(n_298)
);

NOR2xp67_ASAP7_75t_L g299 ( 
.A(n_296),
.B(n_286),
.Y(n_299)
);

HB1xp67_ASAP7_75t_L g300 ( 
.A(n_298),
.Y(n_300)
);

OAI22x1_ASAP7_75t_L g301 ( 
.A1(n_300),
.A2(n_287),
.B1(n_299),
.B2(n_294),
.Y(n_301)
);

INVx3_ASAP7_75t_L g302 ( 
.A(n_301),
.Y(n_302)
);

INVx1_ASAP7_75t_L g303 ( 
.A(n_302),
.Y(n_303)
);

AOI22x1_ASAP7_75t_L g304 ( 
.A1(n_303),
.A2(n_302),
.B1(n_291),
.B2(n_295),
.Y(n_304)
);

AOI21xp5_ASAP7_75t_L g305 ( 
.A1(n_304),
.A2(n_289),
.B(n_88),
.Y(n_305)
);


endmodule