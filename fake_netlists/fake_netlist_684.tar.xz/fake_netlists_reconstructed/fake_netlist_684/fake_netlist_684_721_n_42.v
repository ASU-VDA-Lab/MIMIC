module fake_netlist_684_721_n_42 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_42);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_42;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_22;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_31;
wire n_23;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;

INVx3_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_15),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_11),
.B(n_13),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_18),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

BUFx4f_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_21),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_29),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_SL g32 ( 
.A1(n_30),
.A2(n_25),
.B1(n_26),
.B2(n_24),
.C(n_20),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_27),
.B1(n_23),
.B2(n_18),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_SL g34 ( 
.A(n_32),
.B(n_4),
.C(n_0),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_33),
.C(n_5),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_34),
.B(n_8),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_37),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_38),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AOI322xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_40),
.A3(n_12),
.B1(n_10),
.B2(n_9),
.C1(n_16),
.C2(n_14),
.Y(n_42)
);


endmodule