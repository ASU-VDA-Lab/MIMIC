module fake_netlist_684_2534_n_60 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_60);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_60;

wire n_54;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_40;
wire n_42;
wire n_47;
wire n_58;
wire n_35;
wire n_34;
wire n_52;
wire n_43;
wire n_37;
wire n_51;
wire n_46;
wire n_41;
wire n_31;
wire n_29;
wire n_56;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_17),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_22),
.A2(n_8),
.B1(n_0),
.B2(n_19),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_12),
.Y(n_30)
);

AND2x4_ASAP7_75t_SL g31 ( 
.A(n_2),
.B(n_11),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_7),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_14),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_10),
.B(n_23),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_6),
.B(n_9),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_25),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_33),
.B(n_24),
.Y(n_40)
);

BUFx3_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

AND3x1_ASAP7_75t_L g42 ( 
.A(n_29),
.B(n_34),
.C(n_30),
.Y(n_42)
);

AO21x2_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_28),
.B(n_37),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx2_ASAP7_75t_SL g45 ( 
.A(n_39),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_42),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_40),
.Y(n_47)
);

OR2x6_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_38),
.Y(n_48)
);

INVx1_ASAP7_75t_SL g49 ( 
.A(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

OA21x2_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_43),
.B(n_32),
.Y(n_51)
);

NOR2x1_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_43),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_27),
.Y(n_53)
);

NOR4xp25_ASAP7_75t_L g54 ( 
.A(n_53),
.B(n_27),
.C(n_51),
.D(n_31),
.Y(n_54)
);

AOI211xp5_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_32),
.B(n_51),
.C(n_1),
.Y(n_55)
);

XOR2x1_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_3),
.Y(n_56)
);

INVxp67_ASAP7_75t_SL g57 ( 
.A(n_56),
.Y(n_57)
);

INVx2_ASAP7_75t_SL g58 ( 
.A(n_54),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_55),
.B1(n_5),
.B2(n_4),
.Y(n_59)
);

AOI322xp5_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_58),
.A3(n_16),
.B1(n_15),
.B2(n_13),
.C1(n_20),
.C2(n_18),
.Y(n_60)
);


endmodule