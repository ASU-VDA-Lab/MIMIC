module fake_netlist_684_1850_n_57 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_57);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_57;

wire n_54;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_52;
wire n_43;
wire n_37;
wire n_51;
wire n_46;
wire n_31;
wire n_41;
wire n_29;
wire n_56;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_48;
wire n_49;
wire n_39;
wire n_55;

INVx1_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_4),
.B(n_8),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_10),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_16),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_17),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_14),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_19),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_5),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_0),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_15),
.B(n_23),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_28),
.B(n_30),
.Y(n_38)
);

NOR3xp33_ASAP7_75t_L g39 ( 
.A(n_33),
.B(n_2),
.C(n_1),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_3),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_34),
.Y(n_41)
);

OR2x6_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_36),
.Y(n_42)
);

CKINVDCx11_ASAP7_75t_R g43 ( 
.A(n_40),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_37),
.B(n_29),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_32),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_43),
.Y(n_47)
);

OAI33xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_39),
.A3(n_31),
.B1(n_9),
.B2(n_7),
.B3(n_6),
.Y(n_48)
);

INVx2_ASAP7_75t_SL g49 ( 
.A(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_51)
);

AOI221xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_21),
.B1(n_20),
.B2(n_22),
.C(n_24),
.Y(n_52)
);

CKINVDCx20_ASAP7_75t_R g53 ( 
.A(n_51),
.Y(n_53)
);

NOR2xp33_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_25),
.Y(n_54)
);

HB1xp67_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

CKINVDCx20_ASAP7_75t_R g56 ( 
.A(n_54),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_26),
.B1(n_27),
.B2(n_55),
.Y(n_57)
);


endmodule