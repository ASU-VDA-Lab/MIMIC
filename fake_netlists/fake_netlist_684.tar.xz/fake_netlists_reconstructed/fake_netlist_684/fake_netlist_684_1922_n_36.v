module fake_netlist_684_1922_n_36 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_36);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_36;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

BUFx2_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

INVx4_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_24),
.B(n_20),
.C(n_17),
.Y(n_27)
);

AOI33xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_22),
.A3(n_15),
.B1(n_19),
.B2(n_25),
.B3(n_21),
.Y(n_28)
);

AO21x1_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.B(n_25),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_15),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_0),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OAI222xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_9),
.B1(n_7),
.B2(n_10),
.C1(n_12),
.C2(n_11),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_34),
.B1(n_14),
.B2(n_13),
.Y(n_36)
);


endmodule