module fake_netlist_684_3316_n_44 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_44);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_44;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

INVx1_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

BUFx10_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_7),
.B(n_20),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_2),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_14),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

INVxp67_ASAP7_75t_SL g30 ( 
.A(n_21),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_18),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_27),
.B1(n_23),
.B2(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

INVxp67_ASAP7_75t_SL g34 ( 
.A(n_33),
.Y(n_34)
);

OAI221xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_31),
.B1(n_25),
.B2(n_26),
.C(n_28),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_35),
.Y(n_37)
);

AOI221x1_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_19),
.B1(n_18),
.B2(n_26),
.C(n_28),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_19),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_1),
.Y(n_40)
);

NOR3xp33_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_4),
.C(n_3),
.Y(n_41)
);

AOI211x1_ASAP7_75t_SL g42 ( 
.A1(n_39),
.A2(n_10),
.B(n_9),
.C(n_8),
.Y(n_42)
);

AND2x4_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_11),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_43),
.A2(n_42),
.B1(n_16),
.B2(n_12),
.Y(n_44)
);


endmodule