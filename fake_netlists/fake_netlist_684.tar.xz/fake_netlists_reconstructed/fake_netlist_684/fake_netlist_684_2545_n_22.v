module fake_netlist_684_2545_n_22 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_22);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_22;

wire n_21;
wire n_17;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_9),
.B(n_3),
.Y(n_10)
);

CKINVDCx16_ASAP7_75t_R g11 ( 
.A(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx16_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

BUFx6f_ASAP7_75t_SL g14 ( 
.A(n_12),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_6),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_6),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_7),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OAI22x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_7),
.B1(n_14),
.B2(n_10),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_8),
.B1(n_4),
.B2(n_2),
.Y(n_22)
);


endmodule