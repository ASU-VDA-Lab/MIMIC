module fake_netlist_684_3318_n_42 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_42);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_42;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_19;
wire n_30;
wire n_25;
wire n_13;
wire n_39;
wire n_14;

INVx2_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_4),
.B(n_8),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_14),
.B(n_0),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_14),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_15),
.A2(n_12),
.B1(n_6),
.B2(n_5),
.Y(n_22)
);

AOI21x1_ASAP7_75t_L g23 ( 
.A1(n_13),
.A2(n_11),
.B(n_5),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_13),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_18),
.B(n_17),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_21),
.B(n_17),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_19),
.B(n_16),
.Y(n_29)
);

INVx5_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_19),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_29),
.B1(n_28),
.B2(n_27),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_29),
.B1(n_28),
.B2(n_22),
.Y(n_35)
);

AND2x2_ASAP7_75t_SL g36 ( 
.A(n_31),
.B(n_28),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_35),
.Y(n_37)
);

NAND4xp25_ASAP7_75t_SL g38 ( 
.A(n_36),
.B(n_22),
.C(n_27),
.D(n_33),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

OAI21xp5_ASAP7_75t_SL g40 ( 
.A1(n_37),
.A2(n_33),
.B(n_26),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

AOI222xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_24),
.B1(n_30),
.B2(n_35),
.C1(n_39),
.C2(n_36),
.Y(n_42)
);


endmodule