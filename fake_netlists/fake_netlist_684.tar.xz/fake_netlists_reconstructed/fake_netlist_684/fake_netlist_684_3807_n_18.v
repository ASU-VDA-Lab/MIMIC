module fake_netlist_684_3807_n_18 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_18);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_17;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_SL g10 ( 
.A(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_3),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_12),
.B(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B1(n_7),
.B2(n_6),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B(n_6),
.C(n_1),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_9),
.B(n_5),
.C(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);


endmodule