module fake_netlist_684_881_n_10 (n_0, n_1, n_10);

input n_0;
input n_1;

output n_10;

wire n_9;
wire n_4;
wire n_2;
wire n_7;
wire n_3;
wire n_8;
wire n_5;
wire n_6;

INVxp67_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

INVx4_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_3),
.Y(n_5)
);

AND2x4_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_2),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_7),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule