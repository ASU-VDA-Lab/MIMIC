module fake_netlist_684_1400_n_48 (n_2, n_21, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_48);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_48;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

INVx2_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_19),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_4),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_14),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_21),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_12),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_25),
.B(n_22),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_33),
.B1(n_23),
.B2(n_26),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_27),
.B1(n_24),
.B2(n_30),
.C(n_19),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_30),
.B1(n_3),
.B2(n_0),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_5),
.Y(n_38)
);

CKINVDCx16_ASAP7_75t_R g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

BUFx3_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

XNOR2xp5_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_40),
.Y(n_42)
);

HB1xp67_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_8),
.B1(n_7),
.B2(n_9),
.C(n_11),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_43),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_13),
.A3(n_15),
.B1(n_16),
.B2(n_17),
.C1(n_18),
.C2(n_46),
.Y(n_48)
);


endmodule