module fake_netlist_684_3089_n_90 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_90);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_90;

wire n_24;
wire n_61;
wire n_27;
wire n_86;
wire n_40;
wire n_66;
wire n_88;
wire n_47;
wire n_35;
wire n_52;
wire n_71;
wire n_60;
wire n_33;
wire n_89;
wire n_30;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_83;
wire n_45;
wire n_64;
wire n_85;
wire n_58;
wire n_62;
wire n_76;
wire n_63;
wire n_70;
wire n_69;
wire n_53;
wire n_74;
wire n_28;
wire n_75;
wire n_81;
wire n_55;
wire n_54;
wire n_78;
wire n_44;
wire n_38;
wire n_42;
wire n_34;
wire n_26;
wire n_43;
wire n_84;
wire n_37;
wire n_51;
wire n_23;
wire n_68;
wire n_32;
wire n_77;
wire n_82;
wire n_79;
wire n_46;
wire n_31;
wire n_73;
wire n_41;
wire n_87;
wire n_29;
wire n_56;
wire n_72;
wire n_65;
wire n_80;
wire n_36;
wire n_25;
wire n_49;
wire n_57;

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_7),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_10),
.A2(n_6),
.B1(n_16),
.B2(n_20),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_13),
.B(n_21),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_12),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_3),
.Y(n_33)
);

BUFx12f_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_SL g35 ( 
.A1(n_17),
.A2(n_15),
.B1(n_0),
.B2(n_20),
.Y(n_35)
);

BUFx12f_ASAP7_75t_L g36 ( 
.A(n_11),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_L g37 ( 
.A(n_4),
.B(n_10),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_26),
.B(n_3),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_33),
.A2(n_16),
.B1(n_11),
.B2(n_8),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_24),
.B(n_8),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_24),
.B(n_17),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_L g43 ( 
.A(n_29),
.B(n_18),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_25),
.B(n_18),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_25),
.B(n_22),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_30),
.Y(n_46)
);

OR2x6_ASAP7_75t_L g47 ( 
.A(n_34),
.B(n_1),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_38),
.B(n_26),
.Y(n_48)
);

OAI21x1_ASAP7_75t_L g49 ( 
.A1(n_42),
.A2(n_23),
.B(n_28),
.Y(n_49)
);

BUFx6f_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_38),
.B(n_39),
.Y(n_51)
);

A2O1A1Ixp33_ASAP7_75t_L g52 ( 
.A1(n_39),
.A2(n_26),
.B(n_27),
.C(n_32),
.Y(n_52)
);

AOI21x1_ASAP7_75t_L g53 ( 
.A1(n_46),
.A2(n_28),
.B(n_30),
.Y(n_53)
);

O2A1O1Ixp33_ASAP7_75t_SL g54 ( 
.A1(n_44),
.A2(n_27),
.B(n_37),
.C(n_30),
.Y(n_54)
);

OR2x2_ASAP7_75t_SL g55 ( 
.A(n_54),
.B(n_35),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_48),
.Y(n_56)
);

BUFx3_ASAP7_75t_L g57 ( 
.A(n_49),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_48),
.Y(n_58)
);

AO21x2_ASAP7_75t_L g59 ( 
.A1(n_53),
.A2(n_44),
.B(n_41),
.Y(n_59)
);

HB1xp67_ASAP7_75t_L g60 ( 
.A(n_49),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_57),
.Y(n_61)
);

AND2x2_ASAP7_75t_L g62 ( 
.A(n_56),
.B(n_58),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_60),
.Y(n_63)
);

AND2x2_ASAP7_75t_L g64 ( 
.A(n_60),
.B(n_52),
.Y(n_64)
);

OR2x2_ASAP7_75t_L g65 ( 
.A(n_55),
.B(n_57),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_62),
.B(n_51),
.Y(n_66)
);

OAI21xp33_ASAP7_75t_L g67 ( 
.A1(n_63),
.A2(n_47),
.B(n_43),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_62),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_65),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_65),
.Y(n_70)
);

AOI221xp5_ASAP7_75t_SL g71 ( 
.A1(n_67),
.A2(n_64),
.B1(n_35),
.B2(n_40),
.C(n_51),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_68),
.Y(n_72)
);

INVx1_ASAP7_75t_SL g73 ( 
.A(n_69),
.Y(n_73)
);

OAI21xp33_ASAP7_75t_L g74 ( 
.A1(n_66),
.A2(n_47),
.B(n_43),
.Y(n_74)
);

OAI22xp33_ASAP7_75t_L g75 ( 
.A1(n_70),
.A2(n_47),
.B1(n_36),
.B2(n_34),
.Y(n_75)
);

AOI21xp33_ASAP7_75t_L g76 ( 
.A1(n_68),
.A2(n_64),
.B(n_61),
.Y(n_76)
);

A2O1A1Ixp33_ASAP7_75t_L g77 ( 
.A1(n_74),
.A2(n_39),
.B(n_61),
.C(n_45),
.Y(n_77)
);

NAND2xp5_ASAP7_75t_L g78 ( 
.A(n_71),
.B(n_59),
.Y(n_78)
);

AOI211x1_ASAP7_75t_L g79 ( 
.A1(n_75),
.A2(n_53),
.B(n_36),
.C(n_59),
.Y(n_79)
);

NAND5xp2_ASAP7_75t_L g80 ( 
.A(n_76),
.B(n_30),
.C(n_31),
.D(n_50),
.E(n_72),
.Y(n_80)
);

AOI22xp5_ASAP7_75t_L g81 ( 
.A1(n_73),
.A2(n_31),
.B1(n_30),
.B2(n_50),
.Y(n_81)
);

NAND2xp5_ASAP7_75t_SL g82 ( 
.A(n_72),
.B(n_30),
.Y(n_82)
);

AND2x2_ASAP7_75t_L g83 ( 
.A(n_78),
.B(n_31),
.Y(n_83)
);

NAND2xp5_ASAP7_75t_L g84 ( 
.A(n_79),
.B(n_31),
.Y(n_84)
);

AOI22xp5_ASAP7_75t_L g85 ( 
.A1(n_82),
.A2(n_31),
.B1(n_50),
.B2(n_77),
.Y(n_85)
);

HB1xp67_ASAP7_75t_L g86 ( 
.A(n_82),
.Y(n_86)
);

INVxp33_ASAP7_75t_SL g87 ( 
.A(n_86),
.Y(n_87)
);

OAI22x1_ASAP7_75t_SL g88 ( 
.A1(n_84),
.A2(n_80),
.B1(n_31),
.B2(n_81),
.Y(n_88)
);

OAI211xp5_ASAP7_75t_L g89 ( 
.A1(n_87),
.A2(n_83),
.B(n_85),
.C(n_50),
.Y(n_89)
);

AND3x1_ASAP7_75t_L g90 ( 
.A(n_89),
.B(n_88),
.C(n_50),
.Y(n_90)
);


endmodule