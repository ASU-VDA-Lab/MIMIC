module fake_netlist_684_2168_n_32 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_32);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_32;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_12;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_5),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_9),
.B(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

INVx4_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_1),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_15),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_SL g19 ( 
.A1(n_17),
.A2(n_13),
.B1(n_12),
.B2(n_10),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_11),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_14),
.B1(n_16),
.B2(n_9),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.B1(n_20),
.B2(n_9),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_23),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_9),
.Y(n_26)
);

OAI31xp33_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_24),
.A3(n_2),
.B(n_1),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_4),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_6),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_29),
.B1(n_7),
.B2(n_6),
.Y(n_32)
);


endmodule