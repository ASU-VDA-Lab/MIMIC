module fake_netlist_684_1844_n_270 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_31, n_29, n_8, n_0, n_4, n_32, n_28, n_3, n_11, n_19, n_30, n_25, n_10, n_13, n_14, n_12, n_270);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_31;
input n_29;
input n_8;
input n_0;
input n_4;
input n_32;
input n_28;
input n_3;
input n_11;
input n_19;
input n_30;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_270;

wire n_61;
wire n_99;
wire n_210;
wire n_115;
wire n_233;
wire n_219;
wire n_264;
wire n_110;
wire n_148;
wire n_86;
wire n_147;
wire n_171;
wire n_230;
wire n_102;
wire n_40;
wire n_66;
wire n_165;
wire n_88;
wire n_235;
wire n_47;
wire n_119;
wire n_175;
wire n_35;
wire n_196;
wire n_243;
wire n_260;
wire n_259;
wire n_52;
wire n_220;
wire n_213;
wire n_71;
wire n_150;
wire n_162;
wire n_234;
wire n_252;
wire n_157;
wire n_179;
wire n_121;
wire n_182;
wire n_60;
wire n_189;
wire n_261;
wire n_33;
wire n_89;
wire n_114;
wire n_181;
wire n_194;
wire n_211;
wire n_212;
wire n_112;
wire n_197;
wire n_256;
wire n_59;
wire n_48;
wire n_246;
wire n_262;
wire n_67;
wire n_39;
wire n_50;
wire n_83;
wire n_113;
wire n_229;
wire n_131;
wire n_45;
wire n_204;
wire n_124;
wire n_158;
wire n_163;
wire n_130;
wire n_156;
wire n_64;
wire n_190;
wire n_146;
wire n_85;
wire n_136;
wire n_58;
wire n_218;
wire n_62;
wire n_200;
wire n_76;
wire n_63;
wire n_184;
wire n_265;
wire n_70;
wire n_224;
wire n_69;
wire n_101;
wire n_141;
wire n_123;
wire n_249;
wire n_53;
wire n_267;
wire n_109;
wire n_231;
wire n_168;
wire n_173;
wire n_74;
wire n_250;
wire n_209;
wire n_160;
wire n_176;
wire n_188;
wire n_226;
wire n_144;
wire n_244;
wire n_170;
wire n_187;
wire n_208;
wire n_164;
wire n_94;
wire n_149;
wire n_75;
wire n_81;
wire n_161;
wire n_55;
wire n_192;
wire n_111;
wire n_245;
wire n_54;
wire n_78;
wire n_207;
wire n_44;
wire n_248;
wire n_38;
wire n_174;
wire n_203;
wire n_199;
wire n_91;
wire n_167;
wire n_42;
wire n_106;
wire n_236;
wire n_116;
wire n_127;
wire n_34;
wire n_238;
wire n_225;
wire n_258;
wire n_100;
wire n_266;
wire n_145;
wire n_43;
wire n_263;
wire n_84;
wire n_177;
wire n_37;
wire n_51;
wire n_240;
wire n_191;
wire n_68;
wire n_140;
wire n_92;
wire n_247;
wire n_241;
wire n_195;
wire n_251;
wire n_129;
wire n_90;
wire n_143;
wire n_169;
wire n_77;
wire n_82;
wire n_117;
wire n_152;
wire n_134;
wire n_180;
wire n_228;
wire n_128;
wire n_202;
wire n_172;
wire n_93;
wire n_193;
wire n_118;
wire n_97;
wire n_186;
wire n_214;
wire n_216;
wire n_95;
wire n_98;
wire n_103;
wire n_135;
wire n_222;
wire n_125;
wire n_122;
wire n_79;
wire n_178;
wire n_154;
wire n_237;
wire n_104;
wire n_105;
wire n_215;
wire n_139;
wire n_183;
wire n_133;
wire n_155;
wire n_120;
wire n_242;
wire n_217;
wire n_254;
wire n_137;
wire n_46;
wire n_73;
wire n_41;
wire n_87;
wire n_205;
wire n_56;
wire n_159;
wire n_185;
wire n_257;
wire n_255;
wire n_72;
wire n_65;
wire n_80;
wire n_107;
wire n_132;
wire n_227;
wire n_232;
wire n_138;
wire n_268;
wire n_151;
wire n_153;
wire n_201;
wire n_36;
wire n_142;
wire n_126;
wire n_269;
wire n_253;
wire n_223;
wire n_221;
wire n_206;
wire n_49;
wire n_57;
wire n_96;
wire n_239;
wire n_166;
wire n_198;
wire n_108;

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_10),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_6),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_19),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_9),
.Y(n_39)
);

BUFx3_ASAP7_75t_L g40 ( 
.A(n_13),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_1),
.Y(n_41)
);

INVxp33_ASAP7_75t_SL g42 ( 
.A(n_13),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_15),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_15),
.Y(n_44)
);

INVxp67_ASAP7_75t_SL g45 ( 
.A(n_17),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_38),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_44),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_44),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_33),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_44),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_42),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_42),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_47),
.B(n_33),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_50),
.Y(n_54)
);

NAND2x1p5_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_40),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_49),
.B(n_35),
.Y(n_56)
);

OR2x2_ASAP7_75t_SL g57 ( 
.A(n_50),
.B(n_37),
.Y(n_57)
);

NOR3xp33_ASAP7_75t_L g58 ( 
.A(n_51),
.B(n_34),
.C(n_45),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_48),
.B(n_34),
.Y(n_59)
);

INVx3_ASAP7_75t_L g60 ( 
.A(n_49),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_52),
.Y(n_61)
);

HB1xp67_ASAP7_75t_L g62 ( 
.A(n_46),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_46),
.Y(n_63)
);

AO22x2_ASAP7_75t_L g64 ( 
.A1(n_49),
.A2(n_45),
.B1(n_36),
.B2(n_35),
.Y(n_64)
);

INVxp67_ASAP7_75t_L g65 ( 
.A(n_50),
.Y(n_65)
);

AOI22xp5_ASAP7_75t_L g66 ( 
.A1(n_50),
.A2(n_38),
.B1(n_39),
.B2(n_37),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_60),
.Y(n_67)
);

O2A1O1Ixp5_ASAP7_75t_L g68 ( 
.A1(n_54),
.A2(n_36),
.B(n_41),
.C(n_39),
.Y(n_68)
);

AOI21xp5_ASAP7_75t_L g69 ( 
.A1(n_54),
.A2(n_43),
.B(n_41),
.Y(n_69)
);

NOR2xp33_ASAP7_75t_L g70 ( 
.A(n_61),
.B(n_40),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_60),
.Y(n_71)
);

NAND3xp33_ASAP7_75t_SL g72 ( 
.A(n_58),
.B(n_43),
.C(n_40),
.Y(n_72)
);

INVxp67_ASAP7_75t_L g73 ( 
.A(n_64),
.Y(n_73)
);

NOR2xp67_ASAP7_75t_L g74 ( 
.A(n_60),
.B(n_23),
.Y(n_74)
);

NAND2xp5_ASAP7_75t_L g75 ( 
.A(n_60),
.B(n_40),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_55),
.B(n_24),
.Y(n_76)
);

NAND2xp5_ASAP7_75t_SL g77 ( 
.A(n_61),
.B(n_25),
.Y(n_77)
);

O2A1O1Ixp33_ASAP7_75t_SL g78 ( 
.A1(n_56),
.A2(n_29),
.B(n_28),
.C(n_26),
.Y(n_78)
);

CKINVDCx5p33_ASAP7_75t_R g79 ( 
.A(n_62),
.Y(n_79)
);

A2O1A1Ixp33_ASAP7_75t_L g80 ( 
.A1(n_56),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_80)
);

BUFx6f_ASAP7_75t_L g81 ( 
.A(n_55),
.Y(n_81)
);

OAI21x1_ASAP7_75t_L g82 ( 
.A1(n_55),
.A2(n_31),
.B(n_30),
.Y(n_82)
);

BUFx2_ASAP7_75t_L g83 ( 
.A(n_64),
.Y(n_83)
);

NAND2xp5_ASAP7_75t_L g84 ( 
.A(n_64),
.B(n_53),
.Y(n_84)
);

OAI21x1_ASAP7_75t_L g85 ( 
.A1(n_82),
.A2(n_59),
.B(n_66),
.Y(n_85)
);

INVx5_ASAP7_75t_L g86 ( 
.A(n_81),
.Y(n_86)
);

INVx3_ASAP7_75t_L g87 ( 
.A(n_81),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_67),
.Y(n_88)
);

AOI22xp33_ASAP7_75t_L g89 ( 
.A1(n_83),
.A2(n_64),
.B1(n_66),
.B2(n_65),
.Y(n_89)
);

OAI21x1_ASAP7_75t_L g90 ( 
.A1(n_82),
.A2(n_64),
.B(n_57),
.Y(n_90)
);

OAI21xp5_ASAP7_75t_L g91 ( 
.A1(n_68),
.A2(n_57),
.B(n_63),
.Y(n_91)
);

NAND2x1p5_ASAP7_75t_L g92 ( 
.A(n_83),
.B(n_63),
.Y(n_92)
);

AO21x2_ASAP7_75t_L g93 ( 
.A1(n_80),
.A2(n_84),
.B(n_69),
.Y(n_93)
);

AOI21xp5_ASAP7_75t_L g94 ( 
.A1(n_69),
.A2(n_2),
.B(n_0),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_81),
.Y(n_95)
);

INVx3_ASAP7_75t_L g96 ( 
.A(n_81),
.Y(n_96)
);

INVx1_ASAP7_75t_L g97 ( 
.A(n_67),
.Y(n_97)
);

AO21x2_ASAP7_75t_L g98 ( 
.A1(n_84),
.A2(n_4),
.B(n_3),
.Y(n_98)
);

OR2x2_ASAP7_75t_L g99 ( 
.A(n_89),
.B(n_79),
.Y(n_99)
);

AND2x4_ASAP7_75t_L g100 ( 
.A(n_86),
.B(n_81),
.Y(n_100)
);

AOI22xp33_ASAP7_75t_L g101 ( 
.A1(n_89),
.A2(n_72),
.B1(n_73),
.B2(n_70),
.Y(n_101)
);

BUFx2_ASAP7_75t_L g102 ( 
.A(n_86),
.Y(n_102)
);

INVx2_ASAP7_75t_L g103 ( 
.A(n_88),
.Y(n_103)
);

NAND2xp5_ASAP7_75t_L g104 ( 
.A(n_89),
.B(n_73),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_91),
.B(n_72),
.Y(n_105)
);

BUFx2_ASAP7_75t_L g106 ( 
.A(n_86),
.Y(n_106)
);

AOI22xp5_ASAP7_75t_L g107 ( 
.A1(n_91),
.A2(n_71),
.B1(n_81),
.B2(n_75),
.Y(n_107)
);

OAI221xp5_ASAP7_75t_L g108 ( 
.A1(n_99),
.A2(n_91),
.B1(n_92),
.B2(n_94),
.C(n_68),
.Y(n_108)
);

BUFx2_ASAP7_75t_L g109 ( 
.A(n_100),
.Y(n_109)
);

BUFx2_ASAP7_75t_L g110 ( 
.A(n_100),
.Y(n_110)
);

INVx4_ASAP7_75t_L g111 ( 
.A(n_100),
.Y(n_111)
);

OAI22xp33_ASAP7_75t_L g112 ( 
.A1(n_99),
.A2(n_92),
.B1(n_86),
.B2(n_91),
.Y(n_112)
);

INVx2_ASAP7_75t_L g113 ( 
.A(n_103),
.Y(n_113)
);

NAND2xp5_ASAP7_75t_L g114 ( 
.A(n_104),
.B(n_92),
.Y(n_114)
);

BUFx2_ASAP7_75t_L g115 ( 
.A(n_100),
.Y(n_115)
);

NAND2xp5_ASAP7_75t_L g116 ( 
.A(n_101),
.B(n_92),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_113),
.Y(n_117)
);

INVx2_ASAP7_75t_L g118 ( 
.A(n_113),
.Y(n_118)
);

NOR2xp33_ASAP7_75t_SL g119 ( 
.A(n_112),
.B(n_86),
.Y(n_119)
);

INVx2_ASAP7_75t_L g120 ( 
.A(n_111),
.Y(n_120)
);

AND2x4_ASAP7_75t_L g121 ( 
.A(n_111),
.B(n_103),
.Y(n_121)
);

INVxp67_ASAP7_75t_L g122 ( 
.A(n_109),
.Y(n_122)
);

BUFx2_ASAP7_75t_L g123 ( 
.A(n_111),
.Y(n_123)
);

NAND3x1_ASAP7_75t_L g124 ( 
.A(n_116),
.B(n_94),
.C(n_107),
.Y(n_124)
);

NAND2xp5_ASAP7_75t_L g125 ( 
.A(n_114),
.B(n_105),
.Y(n_125)
);

AND2x2_ASAP7_75t_L g126 ( 
.A(n_111),
.B(n_102),
.Y(n_126)
);

OR2x2_ASAP7_75t_L g127 ( 
.A(n_109),
.B(n_102),
.Y(n_127)
);

INVx2_ASAP7_75t_L g128 ( 
.A(n_110),
.Y(n_128)
);

AND2x2_ASAP7_75t_L g129 ( 
.A(n_110),
.B(n_106),
.Y(n_129)
);

OR2x2_ASAP7_75t_L g130 ( 
.A(n_125),
.B(n_115),
.Y(n_130)
);

INVx1_ASAP7_75t_L g131 ( 
.A(n_117),
.Y(n_131)
);

HB1xp67_ASAP7_75t_L g132 ( 
.A(n_118),
.Y(n_132)
);

AND2x4_ASAP7_75t_L g133 ( 
.A(n_118),
.B(n_115),
.Y(n_133)
);

NOR3xp33_ASAP7_75t_L g134 ( 
.A(n_122),
.B(n_108),
.C(n_94),
.Y(n_134)
);

OR2x2_ASAP7_75t_L g135 ( 
.A(n_125),
.B(n_98),
.Y(n_135)
);

INVx1_ASAP7_75t_L g136 ( 
.A(n_117),
.Y(n_136)
);

AND2x2_ASAP7_75t_L g137 ( 
.A(n_118),
.B(n_98),
.Y(n_137)
);

AND2x2_ASAP7_75t_L g138 ( 
.A(n_128),
.B(n_98),
.Y(n_138)
);

INVx3_ASAP7_75t_L g139 ( 
.A(n_124),
.Y(n_139)
);

NOR2x1_ASAP7_75t_L g140 ( 
.A(n_123),
.B(n_98),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_128),
.Y(n_141)
);

INVx2_ASAP7_75t_L g142 ( 
.A(n_124),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_128),
.Y(n_143)
);

AND2x2_ASAP7_75t_L g144 ( 
.A(n_120),
.B(n_98),
.Y(n_144)
);

INVx1_ASAP7_75t_L g145 ( 
.A(n_124),
.Y(n_145)
);

OAI221xp5_ASAP7_75t_L g146 ( 
.A1(n_119),
.A2(n_92),
.B1(n_94),
.B2(n_106),
.C(n_107),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_120),
.Y(n_147)
);

HB1xp67_ASAP7_75t_L g148 ( 
.A(n_120),
.Y(n_148)
);

AND2x2_ASAP7_75t_L g149 ( 
.A(n_121),
.B(n_98),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_123),
.Y(n_150)
);

OAI31xp33_ASAP7_75t_L g151 ( 
.A1(n_119),
.A2(n_92),
.A3(n_97),
.B(n_88),
.Y(n_151)
);

OR2x2_ASAP7_75t_L g152 ( 
.A(n_127),
.B(n_121),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_131),
.Y(n_153)
);

NAND2xp5_ASAP7_75t_L g154 ( 
.A(n_130),
.B(n_98),
.Y(n_154)
);

XOR2x2_ASAP7_75t_L g155 ( 
.A(n_152),
.B(n_92),
.Y(n_155)
);

OAI21xp5_ASAP7_75t_L g156 ( 
.A1(n_140),
.A2(n_85),
.B(n_90),
.Y(n_156)
);

AOI21xp33_ASAP7_75t_L g157 ( 
.A1(n_140),
.A2(n_98),
.B(n_93),
.Y(n_157)
);

NAND2xp5_ASAP7_75t_L g158 ( 
.A(n_130),
.B(n_98),
.Y(n_158)
);

AOI22xp5_ASAP7_75t_L g159 ( 
.A1(n_134),
.A2(n_121),
.B1(n_126),
.B2(n_129),
.Y(n_159)
);

XNOR2xp5_ASAP7_75t_L g160 ( 
.A(n_152),
.B(n_126),
.Y(n_160)
);

A2O1A1Ixp33_ASAP7_75t_L g161 ( 
.A1(n_151),
.A2(n_90),
.B(n_85),
.C(n_121),
.Y(n_161)
);

AOI21xp5_ASAP7_75t_L g162 ( 
.A1(n_151),
.A2(n_90),
.B(n_85),
.Y(n_162)
);

INVxp33_ASAP7_75t_L g163 ( 
.A(n_148),
.Y(n_163)
);

NAND2xp5_ASAP7_75t_L g164 ( 
.A(n_131),
.B(n_129),
.Y(n_164)
);

OAI22xp5_ASAP7_75t_L g165 ( 
.A1(n_146),
.A2(n_127),
.B1(n_92),
.B2(n_86),
.Y(n_165)
);

AND2x2_ASAP7_75t_L g166 ( 
.A(n_149),
.B(n_90),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_L g167 ( 
.A(n_136),
.B(n_135),
.Y(n_167)
);

NAND2xp5_ASAP7_75t_L g168 ( 
.A(n_136),
.B(n_85),
.Y(n_168)
);

OAI322xp33_ASAP7_75t_L g169 ( 
.A1(n_135),
.A2(n_75),
.A3(n_77),
.B1(n_5),
.B2(n_6),
.C1(n_3),
.C2(n_4),
.Y(n_169)
);

INVx1_ASAP7_75t_L g170 ( 
.A(n_141),
.Y(n_170)
);

NAND3xp33_ASAP7_75t_L g171 ( 
.A(n_134),
.B(n_86),
.C(n_78),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_141),
.Y(n_172)
);

OAI22xp5_ASAP7_75t_L g173 ( 
.A1(n_146),
.A2(n_86),
.B1(n_96),
.B2(n_87),
.Y(n_173)
);

O2A1O1Ixp33_ASAP7_75t_L g174 ( 
.A1(n_145),
.A2(n_93),
.B(n_97),
.C(n_88),
.Y(n_174)
);

HB1xp67_ASAP7_75t_L g175 ( 
.A(n_148),
.Y(n_175)
);

NAND4xp25_ASAP7_75t_L g176 ( 
.A(n_145),
.B(n_74),
.C(n_76),
.D(n_5),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_143),
.Y(n_177)
);

NOR2xp33_ASAP7_75t_L g178 ( 
.A(n_150),
.B(n_7),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_132),
.Y(n_179)
);

INVx1_ASAP7_75t_L g180 ( 
.A(n_143),
.Y(n_180)
);

NAND2xp5_ASAP7_75t_L g181 ( 
.A(n_138),
.B(n_85),
.Y(n_181)
);

AOI33xp33_ASAP7_75t_L g182 ( 
.A1(n_149),
.A2(n_8),
.A3(n_7),
.B1(n_9),
.B2(n_11),
.B3(n_10),
.Y(n_182)
);

AND2x2_ASAP7_75t_L g183 ( 
.A(n_149),
.B(n_90),
.Y(n_183)
);

AND2x2_ASAP7_75t_L g184 ( 
.A(n_166),
.B(n_142),
.Y(n_184)
);

OR2x2_ASAP7_75t_L g185 ( 
.A(n_167),
.B(n_132),
.Y(n_185)
);

OAI21xp33_ASAP7_75t_L g186 ( 
.A1(n_182),
.A2(n_142),
.B(n_139),
.Y(n_186)
);

NAND2xp5_ASAP7_75t_SL g187 ( 
.A(n_182),
.B(n_150),
.Y(n_187)
);

NAND2xp5_ASAP7_75t_L g188 ( 
.A(n_160),
.B(n_144),
.Y(n_188)
);

NOR2xp67_ASAP7_75t_SL g189 ( 
.A(n_176),
.B(n_86),
.Y(n_189)
);

NOR2xp33_ASAP7_75t_L g190 ( 
.A(n_178),
.B(n_8),
.Y(n_190)
);

INVx1_ASAP7_75t_L g191 ( 
.A(n_153),
.Y(n_191)
);

INVx1_ASAP7_75t_SL g192 ( 
.A(n_160),
.Y(n_192)
);

INVxp67_ASAP7_75t_L g193 ( 
.A(n_175),
.Y(n_193)
);

INVx1_ASAP7_75t_L g194 ( 
.A(n_170),
.Y(n_194)
);

INVx2_ASAP7_75t_L g195 ( 
.A(n_172),
.Y(n_195)
);

INVx1_ASAP7_75t_L g196 ( 
.A(n_177),
.Y(n_196)
);

NAND3xp33_ASAP7_75t_L g197 ( 
.A(n_174),
.B(n_142),
.C(n_147),
.Y(n_197)
);

AND2x2_ASAP7_75t_L g198 ( 
.A(n_166),
.B(n_144),
.Y(n_198)
);

INVxp67_ASAP7_75t_L g199 ( 
.A(n_179),
.Y(n_199)
);

INVx1_ASAP7_75t_L g200 ( 
.A(n_180),
.Y(n_200)
);

AND2x2_ASAP7_75t_L g201 ( 
.A(n_183),
.B(n_144),
.Y(n_201)
);

AOI21xp5_ASAP7_75t_L g202 ( 
.A1(n_161),
.A2(n_147),
.B(n_137),
.Y(n_202)
);

NOR2xp33_ASAP7_75t_L g203 ( 
.A(n_164),
.B(n_11),
.Y(n_203)
);

NOR2xp33_ASAP7_75t_L g204 ( 
.A(n_158),
.B(n_12),
.Y(n_204)
);

HB1xp67_ASAP7_75t_L g205 ( 
.A(n_163),
.Y(n_205)
);

NOR2xp33_ASAP7_75t_L g206 ( 
.A(n_154),
.B(n_12),
.Y(n_206)
);

AOI22xp33_ASAP7_75t_R g207 ( 
.A1(n_179),
.A2(n_17),
.B1(n_16),
.B2(n_14),
.Y(n_207)
);

NAND2xp5_ASAP7_75t_L g208 ( 
.A(n_183),
.B(n_138),
.Y(n_208)
);

NOR3xp33_ASAP7_75t_L g209 ( 
.A(n_169),
.B(n_139),
.C(n_85),
.Y(n_209)
);

NOR2xp33_ASAP7_75t_L g210 ( 
.A(n_159),
.B(n_14),
.Y(n_210)
);

INVxp67_ASAP7_75t_L g211 ( 
.A(n_168),
.Y(n_211)
);

NAND2xp5_ASAP7_75t_L g212 ( 
.A(n_163),
.B(n_138),
.Y(n_212)
);

OR2x2_ASAP7_75t_L g213 ( 
.A(n_181),
.B(n_137),
.Y(n_213)
);

NAND2xp5_ASAP7_75t_L g214 ( 
.A(n_155),
.B(n_137),
.Y(n_214)
);

NOR2xp33_ASAP7_75t_L g215 ( 
.A(n_157),
.B(n_16),
.Y(n_215)
);

NAND3xp33_ASAP7_75t_SL g216 ( 
.A(n_192),
.B(n_161),
.C(n_162),
.Y(n_216)
);

CKINVDCx14_ASAP7_75t_R g217 ( 
.A(n_185),
.Y(n_217)
);

AOI221x1_ASAP7_75t_L g218 ( 
.A1(n_209),
.A2(n_156),
.B1(n_173),
.B2(n_165),
.C(n_139),
.Y(n_218)
);

AOI21xp33_ASAP7_75t_L g219 ( 
.A1(n_210),
.A2(n_204),
.B(n_206),
.Y(n_219)
);

NAND2xp5_ASAP7_75t_L g220 ( 
.A(n_193),
.B(n_155),
.Y(n_220)
);

INVx1_ASAP7_75t_L g221 ( 
.A(n_191),
.Y(n_221)
);

INVx2_ASAP7_75t_L g222 ( 
.A(n_195),
.Y(n_222)
);

NAND5xp2_ASAP7_75t_L g223 ( 
.A(n_186),
.B(n_139),
.C(n_76),
.D(n_88),
.E(n_97),
.Y(n_223)
);

O2A1O1Ixp5_ASAP7_75t_L g224 ( 
.A1(n_187),
.A2(n_133),
.B(n_171),
.C(n_87),
.Y(n_224)
);

AOI211x1_ASAP7_75t_L g225 ( 
.A1(n_189),
.A2(n_20),
.B(n_19),
.C(n_18),
.Y(n_225)
);

AOI221xp5_ASAP7_75t_L g226 ( 
.A1(n_203),
.A2(n_133),
.B1(n_93),
.B2(n_97),
.C(n_87),
.Y(n_226)
);

NAND2xp5_ASAP7_75t_L g227 ( 
.A(n_199),
.B(n_211),
.Y(n_227)
);

AOI22xp33_ASAP7_75t_SL g228 ( 
.A1(n_214),
.A2(n_133),
.B1(n_90),
.B2(n_86),
.Y(n_228)
);

OAI211xp5_ASAP7_75t_L g229 ( 
.A1(n_190),
.A2(n_86),
.B(n_82),
.C(n_74),
.Y(n_229)
);

O2A1O1Ixp33_ASAP7_75t_L g230 ( 
.A1(n_215),
.A2(n_93),
.B(n_133),
.C(n_87),
.Y(n_230)
);

AOI221xp5_ASAP7_75t_L g231 ( 
.A1(n_188),
.A2(n_133),
.B1(n_93),
.B2(n_87),
.C(n_96),
.Y(n_231)
);

OAI321xp33_ASAP7_75t_L g232 ( 
.A1(n_197),
.A2(n_95),
.A3(n_21),
.B1(n_18),
.B2(n_20),
.C(n_93),
.Y(n_232)
);

NAND3xp33_ASAP7_75t_L g233 ( 
.A(n_205),
.B(n_86),
.C(n_95),
.Y(n_233)
);

OAI21xp33_ASAP7_75t_L g234 ( 
.A1(n_184),
.A2(n_212),
.B(n_208),
.Y(n_234)
);

HB1xp67_ASAP7_75t_L g235 ( 
.A(n_185),
.Y(n_235)
);

NAND4xp25_ASAP7_75t_L g236 ( 
.A(n_202),
.B(n_21),
.C(n_71),
.D(n_87),
.Y(n_236)
);

AOI221xp5_ASAP7_75t_L g237 ( 
.A1(n_191),
.A2(n_93),
.B1(n_96),
.B2(n_87),
.C(n_95),
.Y(n_237)
);

NAND3xp33_ASAP7_75t_SL g238 ( 
.A(n_189),
.B(n_95),
.C(n_86),
.Y(n_238)
);

OAI211xp5_ASAP7_75t_SL g239 ( 
.A1(n_194),
.A2(n_96),
.B(n_87),
.C(n_95),
.Y(n_239)
);

NAND4xp75_ASAP7_75t_L g240 ( 
.A(n_184),
.B(n_95),
.C(n_93),
.D(n_86),
.Y(n_240)
);

NOR2x1p5_ASAP7_75t_L g241 ( 
.A(n_216),
.B(n_213),
.Y(n_241)
);

NOR2xp33_ASAP7_75t_L g242 ( 
.A(n_217),
.B(n_196),
.Y(n_242)
);

NAND4xp75_ASAP7_75t_L g243 ( 
.A(n_218),
.B(n_200),
.C(n_196),
.D(n_198),
.Y(n_243)
);

AOI21xp5_ASAP7_75t_L g244 ( 
.A1(n_236),
.A2(n_195),
.B(n_200),
.Y(n_244)
);

NOR2x1p5_ASAP7_75t_L g245 ( 
.A(n_238),
.B(n_213),
.Y(n_245)
);

AND2x4_ASAP7_75t_L g246 ( 
.A(n_235),
.B(n_227),
.Y(n_246)
);

OR2x2_ASAP7_75t_L g247 ( 
.A(n_234),
.B(n_201),
.Y(n_247)
);

AOI22xp33_ASAP7_75t_L g248 ( 
.A1(n_223),
.A2(n_201),
.B1(n_198),
.B2(n_93),
.Y(n_248)
);

AOI21xp33_ASAP7_75t_SL g249 ( 
.A1(n_219),
.A2(n_207),
.B(n_87),
.Y(n_249)
);

AOI222xp33_ASAP7_75t_L g250 ( 
.A1(n_226),
.A2(n_86),
.B1(n_96),
.B2(n_220),
.C1(n_231),
.C2(n_232),
.Y(n_250)
);

AND2x2_ASAP7_75t_L g251 ( 
.A(n_217),
.B(n_86),
.Y(n_251)
);

AOI22xp5_ASAP7_75t_L g252 ( 
.A1(n_233),
.A2(n_96),
.B1(n_240),
.B2(n_228),
.Y(n_252)
);

O2A1O1Ixp5_ASAP7_75t_L g253 ( 
.A1(n_224),
.A2(n_96),
.B(n_229),
.C(n_221),
.Y(n_253)
);

A2O1A1Ixp33_ASAP7_75t_L g254 ( 
.A1(n_230),
.A2(n_96),
.B(n_239),
.C(n_237),
.Y(n_254)
);

CKINVDCx5p33_ASAP7_75t_R g255 ( 
.A(n_246),
.Y(n_255)
);

BUFx2_ASAP7_75t_L g256 ( 
.A(n_246),
.Y(n_256)
);

INVx1_ASAP7_75t_L g257 ( 
.A(n_247),
.Y(n_257)
);

AOI211xp5_ASAP7_75t_L g258 ( 
.A1(n_249),
.A2(n_225),
.B(n_222),
.C(n_96),
.Y(n_258)
);

CKINVDCx5p33_ASAP7_75t_R g259 ( 
.A(n_251),
.Y(n_259)
);

NAND2xp5_ASAP7_75t_L g260 ( 
.A(n_241),
.B(n_222),
.Y(n_260)
);

BUFx2_ASAP7_75t_L g261 ( 
.A(n_242),
.Y(n_261)
);

INVx2_ASAP7_75t_L g262 ( 
.A(n_256),
.Y(n_262)
);

NOR3xp33_ASAP7_75t_L g263 ( 
.A(n_258),
.B(n_243),
.C(n_253),
.Y(n_263)
);

NAND4xp25_ASAP7_75t_L g264 ( 
.A(n_258),
.B(n_250),
.C(n_253),
.D(n_248),
.Y(n_264)
);

AOI221xp5_ASAP7_75t_L g265 ( 
.A1(n_257),
.A2(n_244),
.B1(n_254),
.B2(n_252),
.C(n_245),
.Y(n_265)
);

AND2x2_ASAP7_75t_L g266 ( 
.A(n_262),
.B(n_256),
.Y(n_266)
);

AOI22xp5_ASAP7_75t_L g267 ( 
.A1(n_263),
.A2(n_261),
.B1(n_255),
.B2(n_257),
.Y(n_267)
);

INVx1_ASAP7_75t_L g268 ( 
.A(n_266),
.Y(n_268)
);

AOI22xp5_ASAP7_75t_L g269 ( 
.A1(n_268),
.A2(n_267),
.B1(n_264),
.B2(n_265),
.Y(n_269)
);

AOI22xp5_ASAP7_75t_L g270 ( 
.A1(n_269),
.A2(n_261),
.B1(n_260),
.B2(n_259),
.Y(n_270)
);


endmodule