module fake_netlist_684_2846_n_80 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_80);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_80;

wire n_24;
wire n_61;
wire n_27;
wire n_40;
wire n_66;
wire n_47;
wire n_35;
wire n_52;
wire n_71;
wire n_60;
wire n_33;
wire n_30;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_45;
wire n_64;
wire n_58;
wire n_62;
wire n_76;
wire n_63;
wire n_70;
wire n_69;
wire n_53;
wire n_74;
wire n_28;
wire n_75;
wire n_55;
wire n_54;
wire n_78;
wire n_44;
wire n_38;
wire n_42;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_68;
wire n_32;
wire n_77;
wire n_21;
wire n_79;
wire n_22;
wire n_46;
wire n_31;
wire n_73;
wire n_41;
wire n_29;
wire n_56;
wire n_72;
wire n_65;
wire n_36;
wire n_25;
wire n_49;
wire n_57;

INVx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_0),
.B(n_14),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_5),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_11),
.B(n_7),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_0),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_19),
.A2(n_8),
.B1(n_4),
.B2(n_6),
.Y(n_31)
);

AND2x2_ASAP7_75t_SL g32 ( 
.A(n_3),
.B(n_7),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_6),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_24),
.B(n_5),
.Y(n_36)
);

O2A1O1Ixp33_ASAP7_75t_L g37 ( 
.A1(n_24),
.A2(n_10),
.B(n_9),
.C(n_8),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_21),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_21),
.A2(n_15),
.B1(n_13),
.B2(n_12),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_29),
.B(n_25),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_21),
.B(n_13),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_25),
.B(n_16),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

INVx2_ASAP7_75t_SL g44 ( 
.A(n_40),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_34),
.A2(n_32),
.B1(n_31),
.B2(n_27),
.Y(n_45)
);

O2A1O1Ixp33_ASAP7_75t_SL g46 ( 
.A1(n_42),
.A2(n_29),
.B(n_27),
.C(n_26),
.Y(n_46)
);

OAI21x1_ASAP7_75t_SL g47 ( 
.A1(n_34),
.A2(n_23),
.B(n_22),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_36),
.A2(n_25),
.B(n_22),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_41),
.B(n_25),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_43),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_43),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_44),
.B(n_22),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_44),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_49),
.Y(n_54)
);

AND2x4_ASAP7_75t_L g55 ( 
.A(n_54),
.B(n_35),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_50),
.Y(n_56)
);

NOR2x1_ASAP7_75t_L g57 ( 
.A(n_51),
.B(n_45),
.Y(n_57)
);

OR2x2_ASAP7_75t_L g58 ( 
.A(n_52),
.B(n_45),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_57),
.Y(n_59)
);

OR2x2_ASAP7_75t_L g60 ( 
.A(n_58),
.B(n_49),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_55),
.B(n_47),
.Y(n_61)
);

AND2x2_ASAP7_75t_L g62 ( 
.A(n_55),
.B(n_35),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_56),
.B(n_58),
.Y(n_63)
);

O2A1O1Ixp33_ASAP7_75t_L g64 ( 
.A1(n_61),
.A2(n_47),
.B(n_46),
.C(n_37),
.Y(n_64)
);

O2A1O1Ixp33_ASAP7_75t_L g65 ( 
.A1(n_60),
.A2(n_56),
.B(n_48),
.C(n_23),
.Y(n_65)
);

AOI21xp5_ASAP7_75t_L g66 ( 
.A1(n_59),
.A2(n_30),
.B(n_23),
.Y(n_66)
);

OAI221xp5_ASAP7_75t_L g67 ( 
.A1(n_62),
.A2(n_38),
.B1(n_39),
.B2(n_30),
.C(n_28),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_63),
.B(n_30),
.Y(n_68)
);

AOI211x1_ASAP7_75t_SL g69 ( 
.A1(n_66),
.A2(n_68),
.B(n_33),
.C(n_28),
.Y(n_69)
);

NAND2xp5_ASAP7_75t_L g70 ( 
.A(n_64),
.B(n_62),
.Y(n_70)
);

NAND3xp33_ASAP7_75t_L g71 ( 
.A(n_67),
.B(n_59),
.C(n_28),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_68),
.Y(n_72)
);

NAND5xp2_ASAP7_75t_L g73 ( 
.A(n_65),
.B(n_63),
.C(n_18),
.D(n_16),
.E(n_17),
.Y(n_73)
);

AND2x4_ASAP7_75t_L g74 ( 
.A(n_72),
.B(n_28),
.Y(n_74)
);

AND3x2_ASAP7_75t_L g75 ( 
.A(n_73),
.B(n_17),
.C(n_28),
.Y(n_75)
);

AOI22xp5_ASAP7_75t_L g76 ( 
.A1(n_70),
.A2(n_28),
.B1(n_33),
.B2(n_71),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_74),
.Y(n_77)
);

OAI22xp33_ASAP7_75t_SL g78 ( 
.A1(n_74),
.A2(n_72),
.B1(n_69),
.B2(n_33),
.Y(n_78)
);

OAI222xp33_ASAP7_75t_L g79 ( 
.A1(n_77),
.A2(n_33),
.B1(n_75),
.B2(n_76),
.C1(n_74),
.C2(n_70),
.Y(n_79)
);

AOI22xp5_ASAP7_75t_SL g80 ( 
.A1(n_79),
.A2(n_77),
.B1(n_78),
.B2(n_33),
.Y(n_80)
);


endmodule