module fake_netlist_684_1370_n_33 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_33);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_33;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_8),
.B(n_3),
.Y(n_14)
);

AND2x6_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_1),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_5),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_0),
.B(n_2),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

BUFx12f_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_20),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_21),
.B1(n_19),
.B2(n_14),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_17),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_22),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_22),
.Y(n_27)
);

OAI32xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_16),
.A3(n_15),
.B1(n_25),
.B2(n_4),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

NAND5xp2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_7),
.C(n_6),
.D(n_4),
.E(n_11),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_7),
.B2(n_12),
.Y(n_33)
);


endmodule