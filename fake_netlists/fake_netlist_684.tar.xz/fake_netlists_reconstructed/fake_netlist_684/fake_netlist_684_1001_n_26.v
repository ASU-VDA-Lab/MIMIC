module fake_netlist_684_1001_n_26 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_26);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_26;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_12;
wire n_11;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

INVx5_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_R g13 ( 
.A1(n_8),
.A2(n_5),
.B1(n_0),
.B2(n_4),
.Y(n_13)
);

OA21x2_ASAP7_75t_L g14 ( 
.A1(n_1),
.A2(n_7),
.B(n_4),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_14),
.B(n_12),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.B1(n_13),
.B2(n_18),
.C(n_12),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_20),
.B1(n_18),
.B2(n_11),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_12),
.B(n_7),
.C(n_6),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_11),
.B1(n_12),
.B2(n_2),
.Y(n_25)
);

AOI22x1_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_3),
.B1(n_11),
.B2(n_24),
.Y(n_26)
);


endmodule