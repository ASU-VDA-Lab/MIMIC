module fake_netlist_684_2621_n_45 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_45);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_45;

wire n_24;
wire n_44;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_20),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_SL g24 ( 
.A(n_15),
.B(n_13),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_L g26 ( 
.A(n_7),
.B(n_16),
.C(n_0),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_9),
.B(n_6),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

AO22x1_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_19),
.B1(n_18),
.B2(n_1),
.Y(n_29)
);

BUFx12f_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_19),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_25),
.B(n_26),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

OAI33xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_33),
.A3(n_29),
.B1(n_30),
.B2(n_21),
.B3(n_27),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_32),
.Y(n_37)
);

XNOR2xp5_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_30),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_36),
.Y(n_39)
);

OAI221xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_21),
.B1(n_24),
.B2(n_2),
.C(n_3),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_21),
.B1(n_5),
.B2(n_4),
.Y(n_41)
);

OR3x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_10),
.C(n_8),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_42),
.B1(n_17),
.B2(n_12),
.Y(n_45)
);


endmodule