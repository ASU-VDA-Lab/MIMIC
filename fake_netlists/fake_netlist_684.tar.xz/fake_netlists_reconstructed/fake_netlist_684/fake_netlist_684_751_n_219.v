module fake_netlist_684_751_n_219 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_219);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_219;

wire n_61;
wire n_99;
wire n_210;
wire n_115;
wire n_110;
wire n_148;
wire n_27;
wire n_86;
wire n_147;
wire n_171;
wire n_102;
wire n_40;
wire n_66;
wire n_165;
wire n_88;
wire n_47;
wire n_119;
wire n_175;
wire n_35;
wire n_196;
wire n_52;
wire n_213;
wire n_71;
wire n_150;
wire n_162;
wire n_157;
wire n_179;
wire n_121;
wire n_182;
wire n_60;
wire n_189;
wire n_33;
wire n_89;
wire n_114;
wire n_181;
wire n_194;
wire n_211;
wire n_30;
wire n_212;
wire n_112;
wire n_197;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_113;
wire n_83;
wire n_131;
wire n_45;
wire n_204;
wire n_124;
wire n_158;
wire n_163;
wire n_130;
wire n_156;
wire n_64;
wire n_190;
wire n_146;
wire n_85;
wire n_136;
wire n_58;
wire n_218;
wire n_62;
wire n_200;
wire n_76;
wire n_63;
wire n_184;
wire n_70;
wire n_69;
wire n_101;
wire n_141;
wire n_123;
wire n_53;
wire n_109;
wire n_173;
wire n_168;
wire n_74;
wire n_188;
wire n_176;
wire n_160;
wire n_209;
wire n_144;
wire n_170;
wire n_187;
wire n_28;
wire n_208;
wire n_164;
wire n_94;
wire n_149;
wire n_81;
wire n_75;
wire n_161;
wire n_55;
wire n_192;
wire n_111;
wire n_54;
wire n_78;
wire n_207;
wire n_44;
wire n_38;
wire n_174;
wire n_203;
wire n_199;
wire n_91;
wire n_167;
wire n_42;
wire n_106;
wire n_116;
wire n_127;
wire n_34;
wire n_100;
wire n_26;
wire n_145;
wire n_43;
wire n_84;
wire n_177;
wire n_37;
wire n_51;
wire n_191;
wire n_68;
wire n_140;
wire n_92;
wire n_195;
wire n_129;
wire n_90;
wire n_143;
wire n_169;
wire n_32;
wire n_77;
wire n_82;
wire n_117;
wire n_152;
wire n_134;
wire n_180;
wire n_128;
wire n_202;
wire n_172;
wire n_93;
wire n_193;
wire n_97;
wire n_118;
wire n_186;
wire n_214;
wire n_216;
wire n_95;
wire n_98;
wire n_103;
wire n_135;
wire n_125;
wire n_122;
wire n_79;
wire n_178;
wire n_154;
wire n_104;
wire n_105;
wire n_215;
wire n_139;
wire n_133;
wire n_183;
wire n_155;
wire n_120;
wire n_217;
wire n_137;
wire n_46;
wire n_31;
wire n_87;
wire n_41;
wire n_73;
wire n_205;
wire n_29;
wire n_56;
wire n_159;
wire n_185;
wire n_72;
wire n_65;
wire n_80;
wire n_107;
wire n_132;
wire n_138;
wire n_151;
wire n_153;
wire n_201;
wire n_36;
wire n_142;
wire n_126;
wire n_206;
wire n_49;
wire n_57;
wire n_96;
wire n_166;
wire n_198;
wire n_108;

INVx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_2),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

INVxp33_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_1),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_15),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_16),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_7),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_8),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_5),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_R g38 ( 
.A(n_28),
.B(n_0),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_28),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_26),
.Y(n_40)
);

CKINVDCx20_ASAP7_75t_R g41 ( 
.A(n_36),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_33),
.Y(n_42)
);

CKINVDCx20_ASAP7_75t_R g43 ( 
.A(n_29),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_31),
.A2(n_14),
.B1(n_13),
.B2(n_7),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_27),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_40),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_40),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_26),
.Y(n_49)
);

BUFx6f_ASAP7_75t_L g50 ( 
.A(n_42),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_39),
.B(n_38),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_44),
.Y(n_52)
);

BUFx2_ASAP7_75t_L g53 ( 
.A(n_38),
.Y(n_53)
);

AND2x4_ASAP7_75t_L g54 ( 
.A(n_43),
.B(n_26),
.Y(n_54)
);

NAND2x1p5_ASAP7_75t_L g55 ( 
.A(n_41),
.B(n_32),
.Y(n_55)
);

A2O1A1Ixp33_ASAP7_75t_L g56 ( 
.A1(n_41),
.A2(n_37),
.B(n_32),
.C(n_29),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_40),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_40),
.Y(n_58)
);

INVx4_ASAP7_75t_L g59 ( 
.A(n_50),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_49),
.B(n_37),
.Y(n_60)
);

BUFx6f_ASAP7_75t_L g61 ( 
.A(n_57),
.Y(n_61)
);

BUFx6f_ASAP7_75t_L g62 ( 
.A(n_57),
.Y(n_62)
);

OAI22xp5_ASAP7_75t_L g63 ( 
.A1(n_52),
.A2(n_35),
.B1(n_34),
.B2(n_30),
.Y(n_63)
);

BUFx2_ASAP7_75t_L g64 ( 
.A(n_54),
.Y(n_64)
);

NOR2xp33_ASAP7_75t_L g65 ( 
.A(n_51),
.B(n_30),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_46),
.Y(n_66)
);

OAI22x1_ASAP7_75t_L g67 ( 
.A1(n_52),
.A2(n_35),
.B1(n_34),
.B2(n_13),
.Y(n_67)
);

INVxp67_ASAP7_75t_SL g68 ( 
.A(n_53),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_46),
.Y(n_69)
);

NAND2xp5_ASAP7_75t_L g70 ( 
.A(n_49),
.B(n_3),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_47),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_47),
.Y(n_72)
);

NAND2xp5_ASAP7_75t_L g73 ( 
.A(n_69),
.B(n_48),
.Y(n_73)
);

INVx2_ASAP7_75t_L g74 ( 
.A(n_66),
.Y(n_74)
);

OAI21xp5_ASAP7_75t_L g75 ( 
.A1(n_69),
.A2(n_48),
.B(n_56),
.Y(n_75)
);

INVx2_ASAP7_75t_L g76 ( 
.A(n_66),
.Y(n_76)
);

OAI21x1_ASAP7_75t_L g77 ( 
.A1(n_70),
.A2(n_58),
.B(n_55),
.Y(n_77)
);

NOR3xp33_ASAP7_75t_L g78 ( 
.A(n_64),
.B(n_53),
.C(n_54),
.Y(n_78)
);

OAI21x1_ASAP7_75t_L g79 ( 
.A1(n_70),
.A2(n_58),
.B(n_55),
.Y(n_79)
);

XNOR2xp5_ASAP7_75t_L g80 ( 
.A(n_64),
.B(n_55),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_66),
.Y(n_81)
);

HB1xp67_ASAP7_75t_L g82 ( 
.A(n_68),
.Y(n_82)
);

INVx2_ASAP7_75t_L g83 ( 
.A(n_61),
.Y(n_83)
);

INVxp67_ASAP7_75t_SL g84 ( 
.A(n_74),
.Y(n_84)
);

AND2x2_ASAP7_75t_L g85 ( 
.A(n_81),
.B(n_71),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_81),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_74),
.Y(n_87)
);

AOI22xp33_ASAP7_75t_L g88 ( 
.A1(n_78),
.A2(n_65),
.B1(n_72),
.B2(n_71),
.Y(n_88)
);

CKINVDCx16_ASAP7_75t_R g89 ( 
.A(n_80),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_74),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_87),
.Y(n_91)
);

BUFx3_ASAP7_75t_L g92 ( 
.A(n_87),
.Y(n_92)
);

AND2x2_ASAP7_75t_L g93 ( 
.A(n_85),
.B(n_76),
.Y(n_93)
);

INVxp67_ASAP7_75t_SL g94 ( 
.A(n_84),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_90),
.Y(n_95)
);

OA21x2_ASAP7_75t_L g96 ( 
.A1(n_84),
.A2(n_79),
.B(n_77),
.Y(n_96)
);

NAND2xp5_ASAP7_75t_L g97 ( 
.A(n_85),
.B(n_73),
.Y(n_97)
);

AOI221xp5_ASAP7_75t_L g98 ( 
.A1(n_88),
.A2(n_63),
.B1(n_75),
.B2(n_60),
.C(n_54),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_SL g99 ( 
.A(n_92),
.B(n_95),
.Y(n_99)
);

INVx1_ASAP7_75t_L g100 ( 
.A(n_95),
.Y(n_100)
);

AND2x2_ASAP7_75t_L g101 ( 
.A(n_93),
.B(n_86),
.Y(n_101)
);

AND2x2_ASAP7_75t_L g102 ( 
.A(n_93),
.B(n_86),
.Y(n_102)
);

AND2x2_ASAP7_75t_L g103 ( 
.A(n_93),
.B(n_85),
.Y(n_103)
);

OR2x2_ASAP7_75t_L g104 ( 
.A(n_94),
.B(n_90),
.Y(n_104)
);

AND2x2_ASAP7_75t_L g105 ( 
.A(n_93),
.B(n_79),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_95),
.Y(n_106)
);

AND2x2_ASAP7_75t_L g107 ( 
.A(n_95),
.B(n_79),
.Y(n_107)
);

INVx2_ASAP7_75t_L g108 ( 
.A(n_92),
.Y(n_108)
);

AND2x2_ASAP7_75t_L g109 ( 
.A(n_91),
.B(n_76),
.Y(n_109)
);

AND2x2_ASAP7_75t_L g110 ( 
.A(n_91),
.B(n_76),
.Y(n_110)
);

NOR4xp25_ASAP7_75t_SL g111 ( 
.A(n_94),
.B(n_67),
.C(n_89),
.D(n_77),
.Y(n_111)
);

AND2x2_ASAP7_75t_L g112 ( 
.A(n_91),
.B(n_75),
.Y(n_112)
);

CKINVDCx5p33_ASAP7_75t_R g113 ( 
.A(n_103),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_100),
.Y(n_114)
);

AND2x2_ASAP7_75t_L g115 ( 
.A(n_107),
.B(n_105),
.Y(n_115)
);

OR2x2_ASAP7_75t_L g116 ( 
.A(n_100),
.B(n_92),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_107),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_106),
.Y(n_118)
);

AND2x2_ASAP7_75t_L g119 ( 
.A(n_107),
.B(n_96),
.Y(n_119)
);

AND2x2_ASAP7_75t_L g120 ( 
.A(n_105),
.B(n_96),
.Y(n_120)
);

AND2x4_ASAP7_75t_L g121 ( 
.A(n_108),
.B(n_92),
.Y(n_121)
);

OR2x2_ASAP7_75t_L g122 ( 
.A(n_106),
.B(n_96),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_104),
.Y(n_123)
);

AND2x2_ASAP7_75t_L g124 ( 
.A(n_112),
.B(n_96),
.Y(n_124)
);

INVxp67_ASAP7_75t_SL g125 ( 
.A(n_104),
.Y(n_125)
);

INVx3_ASAP7_75t_L g126 ( 
.A(n_108),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_112),
.Y(n_127)
);

INVx3_ASAP7_75t_SL g128 ( 
.A(n_108),
.Y(n_128)
);

INVx2_ASAP7_75t_L g129 ( 
.A(n_112),
.Y(n_129)
);

INVx1_ASAP7_75t_SL g130 ( 
.A(n_110),
.Y(n_130)
);

NAND2xp5_ASAP7_75t_L g131 ( 
.A(n_102),
.B(n_97),
.Y(n_131)
);

AND2x2_ASAP7_75t_L g132 ( 
.A(n_101),
.B(n_96),
.Y(n_132)
);

NOR2x1_ASAP7_75t_L g133 ( 
.A(n_99),
.B(n_96),
.Y(n_133)
);

NAND2xp5_ASAP7_75t_L g134 ( 
.A(n_102),
.B(n_97),
.Y(n_134)
);

OAI221xp5_ASAP7_75t_L g135 ( 
.A1(n_113),
.A2(n_98),
.B1(n_80),
.B2(n_60),
.C(n_50),
.Y(n_135)
);

INVxp67_ASAP7_75t_L g136 ( 
.A(n_122),
.Y(n_136)
);

AOI21xp33_ASAP7_75t_SL g137 ( 
.A1(n_128),
.A2(n_89),
.B(n_67),
.Y(n_137)
);

INVxp33_ASAP7_75t_L g138 ( 
.A(n_122),
.Y(n_138)
);

NAND2xp5_ASAP7_75t_L g139 ( 
.A(n_115),
.B(n_127),
.Y(n_139)
);

INVx1_ASAP7_75t_L g140 ( 
.A(n_114),
.Y(n_140)
);

OAI21xp33_ASAP7_75t_L g141 ( 
.A1(n_125),
.A2(n_54),
.B(n_98),
.Y(n_141)
);

OAI21xp33_ASAP7_75t_L g142 ( 
.A1(n_120),
.A2(n_132),
.B(n_127),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_118),
.Y(n_143)
);

NAND2xp5_ASAP7_75t_L g144 ( 
.A(n_115),
.B(n_110),
.Y(n_144)
);

OAI321xp33_ASAP7_75t_L g145 ( 
.A1(n_123),
.A2(n_63),
.A3(n_50),
.B1(n_111),
.B2(n_109),
.C(n_73),
.Y(n_145)
);

NAND2xp5_ASAP7_75t_L g146 ( 
.A(n_115),
.B(n_109),
.Y(n_146)
);

NAND2xp33_ASAP7_75t_SL g147 ( 
.A(n_128),
.B(n_111),
.Y(n_147)
);

NOR2xp67_ASAP7_75t_L g148 ( 
.A(n_122),
.B(n_14),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_118),
.Y(n_149)
);

INVx3_ASAP7_75t_L g150 ( 
.A(n_116),
.Y(n_150)
);

AOI211xp5_ASAP7_75t_L g151 ( 
.A1(n_128),
.A2(n_50),
.B(n_82),
.C(n_72),
.Y(n_151)
);

NAND2xp5_ASAP7_75t_L g152 ( 
.A(n_123),
.B(n_96),
.Y(n_152)
);

NAND2xp33_ASAP7_75t_SL g153 ( 
.A(n_132),
.B(n_50),
.Y(n_153)
);

NOR2xp33_ASAP7_75t_L g154 ( 
.A(n_131),
.B(n_18),
.Y(n_154)
);

OAI21xp33_ASAP7_75t_L g155 ( 
.A1(n_120),
.A2(n_83),
.B(n_20),
.Y(n_155)
);

AOI31xp33_ASAP7_75t_L g156 ( 
.A1(n_130),
.A2(n_23),
.A3(n_22),
.B(n_21),
.Y(n_156)
);

NAND2xp33_ASAP7_75t_SL g157 ( 
.A(n_119),
.B(n_59),
.Y(n_157)
);

A2O1A1Ixp33_ASAP7_75t_L g158 ( 
.A1(n_130),
.A2(n_83),
.B(n_62),
.C(n_61),
.Y(n_158)
);

INVxp67_ASAP7_75t_L g159 ( 
.A(n_156),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_140),
.Y(n_160)
);

NAND2xp5_ASAP7_75t_L g161 ( 
.A(n_139),
.B(n_120),
.Y(n_161)
);

NOR2xp33_ASAP7_75t_L g162 ( 
.A(n_137),
.B(n_129),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_143),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_149),
.Y(n_164)
);

NOR2xp33_ASAP7_75t_L g165 ( 
.A(n_135),
.B(n_154),
.Y(n_165)
);

NOR2xp33_ASAP7_75t_L g166 ( 
.A(n_154),
.B(n_129),
.Y(n_166)
);

OAI21xp33_ASAP7_75t_L g167 ( 
.A1(n_142),
.A2(n_119),
.B(n_133),
.Y(n_167)
);

AND2x2_ASAP7_75t_L g168 ( 
.A(n_146),
.B(n_119),
.Y(n_168)
);

NAND2xp5_ASAP7_75t_SL g169 ( 
.A(n_151),
.B(n_133),
.Y(n_169)
);

INVx1_ASAP7_75t_SL g170 ( 
.A(n_144),
.Y(n_170)
);

AND2x2_ASAP7_75t_L g171 ( 
.A(n_150),
.B(n_129),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_136),
.Y(n_172)
);

OR2x2_ASAP7_75t_L g173 ( 
.A(n_150),
.B(n_117),
.Y(n_173)
);

INVxp67_ASAP7_75t_L g174 ( 
.A(n_148),
.Y(n_174)
);

NAND2xp33_ASAP7_75t_SL g175 ( 
.A(n_138),
.B(n_124),
.Y(n_175)
);

OR2x2_ASAP7_75t_L g176 ( 
.A(n_138),
.B(n_117),
.Y(n_176)
);

NAND2xp5_ASAP7_75t_L g177 ( 
.A(n_152),
.B(n_117),
.Y(n_177)
);

NAND2xp5_ASAP7_75t_L g178 ( 
.A(n_141),
.B(n_134),
.Y(n_178)
);

NAND2xp5_ASAP7_75t_SL g179 ( 
.A(n_153),
.B(n_121),
.Y(n_179)
);

NOR2xp33_ASAP7_75t_L g180 ( 
.A(n_155),
.B(n_145),
.Y(n_180)
);

NOR2xp33_ASAP7_75t_L g181 ( 
.A(n_147),
.B(n_126),
.Y(n_181)
);

NAND2xp5_ASAP7_75t_SL g182 ( 
.A(n_159),
.B(n_157),
.Y(n_182)
);

INVx2_ASAP7_75t_SL g183 ( 
.A(n_173),
.Y(n_183)
);

AOI221xp5_ASAP7_75t_L g184 ( 
.A1(n_165),
.A2(n_126),
.B1(n_158),
.B2(n_121),
.C(n_59),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_172),
.Y(n_185)
);

AOI22xp5_ASAP7_75t_L g186 ( 
.A1(n_165),
.A2(n_121),
.B1(n_158),
.B2(n_59),
.Y(n_186)
);

AOI21xp33_ASAP7_75t_SL g187 ( 
.A1(n_167),
.A2(n_22),
.B(n_21),
.Y(n_187)
);

NOR2xp67_ASAP7_75t_SL g188 ( 
.A(n_179),
.B(n_59),
.Y(n_188)
);

AOI21xp33_ASAP7_75t_SL g189 ( 
.A1(n_169),
.A2(n_179),
.B(n_162),
.Y(n_189)
);

HB1xp67_ASAP7_75t_L g190 ( 
.A(n_176),
.Y(n_190)
);

A2O1A1Ixp33_ASAP7_75t_L g191 ( 
.A1(n_175),
.A2(n_25),
.B(n_24),
.C(n_83),
.Y(n_191)
);

AOI21xp33_ASAP7_75t_SL g192 ( 
.A1(n_162),
.A2(n_25),
.B(n_24),
.Y(n_192)
);

AOI211xp5_ASAP7_75t_L g193 ( 
.A1(n_180),
.A2(n_62),
.B(n_61),
.C(n_4),
.Y(n_193)
);

OAI21xp33_ASAP7_75t_SL g194 ( 
.A1(n_181),
.A2(n_9),
.B(n_6),
.Y(n_194)
);

NAND3xp33_ASAP7_75t_SL g195 ( 
.A(n_174),
.B(n_11),
.C(n_10),
.Y(n_195)
);

AOI21xp5_ASAP7_75t_L g196 ( 
.A1(n_178),
.A2(n_166),
.B(n_177),
.Y(n_196)
);

BUFx6f_ASAP7_75t_L g197 ( 
.A(n_195),
.Y(n_197)
);

NAND2xp5_ASAP7_75t_L g198 ( 
.A(n_196),
.B(n_168),
.Y(n_198)
);

O2A1O1Ixp5_ASAP7_75t_L g199 ( 
.A1(n_182),
.A2(n_164),
.B(n_163),
.C(n_160),
.Y(n_199)
);

A2O1A1Ixp33_ASAP7_75t_L g200 ( 
.A1(n_189),
.A2(n_170),
.B(n_161),
.C(n_171),
.Y(n_200)
);

NOR3xp33_ASAP7_75t_L g201 ( 
.A(n_187),
.B(n_192),
.C(n_194),
.Y(n_201)
);

AOI221xp5_ASAP7_75t_L g202 ( 
.A1(n_185),
.A2(n_190),
.B1(n_183),
.B2(n_191),
.C(n_184),
.Y(n_202)
);

AND2x4_ASAP7_75t_L g203 ( 
.A(n_190),
.B(n_186),
.Y(n_203)
);

AOI211xp5_ASAP7_75t_L g204 ( 
.A1(n_193),
.A2(n_189),
.B(n_159),
.C(n_182),
.Y(n_204)
);

NAND2xp33_ASAP7_75t_SL g205 ( 
.A(n_188),
.B(n_182),
.Y(n_205)
);

BUFx6f_ASAP7_75t_L g206 ( 
.A(n_197),
.Y(n_206)
);

CKINVDCx5p33_ASAP7_75t_R g207 ( 
.A(n_205),
.Y(n_207)
);

INVx1_ASAP7_75t_L g208 ( 
.A(n_198),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_203),
.Y(n_209)
);

BUFx2_ASAP7_75t_L g210 ( 
.A(n_200),
.Y(n_210)
);

CKINVDCx5p33_ASAP7_75t_R g211 ( 
.A(n_197),
.Y(n_211)
);

INVx2_ASAP7_75t_SL g212 ( 
.A(n_211),
.Y(n_212)
);

INVx1_ASAP7_75t_L g213 ( 
.A(n_208),
.Y(n_213)
);

OAI21xp5_ASAP7_75t_SL g214 ( 
.A1(n_210),
.A2(n_201),
.B(n_202),
.Y(n_214)
);

INVxp67_ASAP7_75t_SL g215 ( 
.A(n_212),
.Y(n_215)
);

OAI22xp5_ASAP7_75t_L g216 ( 
.A1(n_214),
.A2(n_207),
.B1(n_210),
.B2(n_209),
.Y(n_216)
);

AOI22xp33_ASAP7_75t_L g217 ( 
.A1(n_216),
.A2(n_206),
.B1(n_208),
.B2(n_209),
.Y(n_217)
);

AOI22xp5_ASAP7_75t_L g218 ( 
.A1(n_217),
.A2(n_215),
.B1(n_206),
.B2(n_204),
.Y(n_218)
);

OAI21xp5_ASAP7_75t_L g219 ( 
.A1(n_218),
.A2(n_213),
.B(n_199),
.Y(n_219)
);


endmodule