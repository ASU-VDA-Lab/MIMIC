module fake_netlist_684_3929_n_41 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_41);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_41;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_22;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

INVx2_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

AND2x6_ASAP7_75t_L g24 ( 
.A(n_3),
.B(n_12),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_7),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_9),
.B(n_10),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_5),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_0),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

CKINVDCx8_ASAP7_75t_R g32 ( 
.A(n_29),
.Y(n_32)
);

CKINVDCx6p67_ASAP7_75t_R g33 ( 
.A(n_30),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_31),
.B1(n_25),
.B2(n_27),
.C(n_22),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_34),
.Y(n_36)
);

AND3x1_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_24),
.C(n_28),
.Y(n_37)
);

OAI22xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_8),
.B1(n_4),
.B2(n_2),
.Y(n_38)
);

NOR2xp67_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_11),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

AOI322xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_15),
.A3(n_14),
.B1(n_18),
.B2(n_20),
.C1(n_16),
.C2(n_17),
.Y(n_41)
);


endmodule