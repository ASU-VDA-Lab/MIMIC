module fake_netlist_765_2467_n_323 (n_20, n_23, n_14, n_22, n_36, n_16, n_18, n_34, n_13, n_39, n_11, n_1, n_28, n_27, n_37, n_42, n_24, n_10, n_5, n_26, n_6, n_33, n_40, n_31, n_30, n_38, n_2, n_3, n_9, n_35, n_4, n_25, n_7, n_17, n_21, n_43, n_12, n_15, n_19, n_41, n_29, n_32, n_0, n_8, n_323);

input n_20;
input n_23;
input n_14;
input n_22;
input n_36;
input n_16;
input n_18;
input n_34;
input n_13;
input n_39;
input n_11;
input n_1;
input n_28;
input n_27;
input n_37;
input n_42;
input n_24;
input n_10;
input n_5;
input n_26;
input n_6;
input n_33;
input n_40;
input n_31;
input n_30;
input n_38;
input n_2;
input n_3;
input n_9;
input n_35;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_43;
input n_12;
input n_15;
input n_19;
input n_41;
input n_29;
input n_32;
input n_0;
input n_8;

output n_323;

wire n_311;
wire n_200;
wire n_217;
wire n_104;
wire n_275;
wire n_73;
wire n_112;
wire n_127;
wire n_182;
wire n_189;
wire n_183;
wire n_155;
wire n_266;
wire n_269;
wire n_234;
wire n_288;
wire n_131;
wire n_289;
wire n_126;
wire n_210;
wire n_140;
wire n_235;
wire n_184;
wire n_260;
wire n_196;
wire n_72;
wire n_312;
wire n_95;
wire n_282;
wire n_69;
wire n_248;
wire n_295;
wire n_167;
wire n_204;
wire n_222;
wire n_172;
wire n_207;
wire n_320;
wire n_315;
wire n_253;
wire n_227;
wire n_87;
wire n_187;
wire n_117;
wire n_305;
wire n_79;
wire n_256;
wire n_249;
wire n_101;
wire n_91;
wire n_115;
wire n_243;
wire n_66;
wire n_159;
wire n_205;
wire n_181;
wire n_48;
wire n_293;
wire n_49;
wire n_170;
wire n_134;
wire n_247;
wire n_114;
wire n_161;
wire n_135;
wire n_162;
wire n_212;
wire n_164;
wire n_142;
wire n_93;
wire n_258;
wire n_146;
wire n_301;
wire n_250;
wire n_309;
wire n_62;
wire n_252;
wire n_231;
wire n_106;
wire n_223;
wire n_291;
wire n_105;
wire n_302;
wire n_60;
wire n_304;
wire n_264;
wire n_245;
wire n_86;
wire n_55;
wire n_201;
wire n_313;
wire n_236;
wire n_276;
wire n_322;
wire n_76;
wire n_193;
wire n_51;
wire n_102;
wire n_98;
wire n_251;
wire n_118;
wire n_75;
wire n_270;
wire n_197;
wire n_85;
wire n_198;
wire n_174;
wire n_63;
wire n_166;
wire n_125;
wire n_92;
wire n_246;
wire n_241;
wire n_136;
wire n_238;
wire n_279;
wire n_148;
wire n_226;
wire n_263;
wire n_96;
wire n_165;
wire n_188;
wire n_103;
wire n_163;
wire n_220;
wire n_199;
wire n_121;
wire n_116;
wire n_44;
wire n_268;
wire n_211;
wire n_107;
wire n_261;
wire n_321;
wire n_179;
wire n_221;
wire n_154;
wire n_177;
wire n_206;
wire n_88;
wire n_232;
wire n_213;
wire n_318;
wire n_71;
wire n_215;
wire n_186;
wire n_156;
wire n_175;
wire n_81;
wire n_94;
wire n_278;
wire n_287;
wire n_224;
wire n_218;
wire n_119;
wire n_271;
wire n_191;
wire n_255;
wire n_299;
wire n_46;
wire n_82;
wire n_145;
wire n_78;
wire n_308;
wire n_180;
wire n_149;
wire n_70;
wire n_281;
wire n_283;
wire n_144;
wire n_274;
wire n_319;
wire n_61;
wire n_45;
wire n_90;
wire n_169;
wire n_50;
wire n_298;
wire n_203;
wire n_216;
wire n_297;
wire n_58;
wire n_123;
wire n_262;
wire n_290;
wire n_99;
wire n_292;
wire n_254;
wire n_267;
wire n_59;
wire n_89;
wire n_316;
wire n_158;
wire n_124;
wire n_284;
wire n_306;
wire n_208;
wire n_314;
wire n_242;
wire n_178;
wire n_129;
wire n_171;
wire n_54;
wire n_83;
wire n_294;
wire n_219;
wire n_77;
wire n_80;
wire n_153;
wire n_68;
wire n_192;
wire n_176;
wire n_173;
wire n_139;
wire n_244;
wire n_285;
wire n_273;
wire n_53;
wire n_57;
wire n_157;
wire n_84;
wire n_195;
wire n_286;
wire n_151;
wire n_257;
wire n_64;
wire n_300;
wire n_194;
wire n_108;
wire n_259;
wire n_97;
wire n_132;
wire n_230;
wire n_160;
wire n_310;
wire n_147;
wire n_237;
wire n_100;
wire n_56;
wire n_272;
wire n_233;
wire n_111;
wire n_52;
wire n_307;
wire n_141;
wire n_214;
wire n_265;
wire n_110;
wire n_190;
wire n_137;
wire n_65;
wire n_150;
wire n_128;
wire n_133;
wire n_280;
wire n_240;
wire n_229;
wire n_138;
wire n_130;
wire n_225;
wire n_122;
wire n_239;
wire n_209;
wire n_74;
wire n_317;
wire n_303;
wire n_296;
wire n_109;
wire n_120;
wire n_168;
wire n_228;
wire n_277;
wire n_143;
wire n_67;
wire n_47;
wire n_152;
wire n_185;
wire n_202;
wire n_113;

INVx1_ASAP7_75t_L g44 ( 
.A(n_37),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_11),
.Y(n_45)
);

INVxp33_ASAP7_75t_L g46 ( 
.A(n_28),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_42),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_23),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_33),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_30),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_14),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_13),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_15),
.Y(n_53)
);

CKINVDCx5p33_ASAP7_75t_R g54 ( 
.A(n_19),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_39),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_24),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_31),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_16),
.Y(n_58)
);

BUFx2_ASAP7_75t_L g59 ( 
.A(n_34),
.Y(n_59)
);

BUFx3_ASAP7_75t_L g60 ( 
.A(n_26),
.Y(n_60)
);

HB1xp67_ASAP7_75t_L g61 ( 
.A(n_52),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_44),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_44),
.Y(n_63)
);

INVxp67_ASAP7_75t_L g64 ( 
.A(n_59),
.Y(n_64)
);

BUFx3_ASAP7_75t_L g65 ( 
.A(n_60),
.Y(n_65)
);

INVx5_ASAP7_75t_L g66 ( 
.A(n_60),
.Y(n_66)
);

BUFx6f_ASAP7_75t_L g67 ( 
.A(n_60),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_47),
.Y(n_68)
);

BUFx6f_ASAP7_75t_L g69 ( 
.A(n_47),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_69),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_63),
.B(n_64),
.Y(n_71)
);

CKINVDCx5p33_ASAP7_75t_R g72 ( 
.A(n_64),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_69),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_SL g74 ( 
.A(n_63),
.B(n_49),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_69),
.Y(n_75)
);

AOI22xp33_ASAP7_75t_L g76 ( 
.A1(n_63),
.A2(n_58),
.B1(n_53),
.B2(n_52),
.Y(n_76)
);

NOR2xp33_ASAP7_75t_L g77 ( 
.A(n_62),
.B(n_59),
.Y(n_77)
);

CKINVDCx20_ASAP7_75t_R g78 ( 
.A(n_61),
.Y(n_78)
);

INVx2_ASAP7_75t_L g79 ( 
.A(n_67),
.Y(n_79)
);

INVx3_ASAP7_75t_L g80 ( 
.A(n_69),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_67),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_69),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_69),
.Y(n_83)
);

AO22x1_ASAP7_75t_L g84 ( 
.A1(n_71),
.A2(n_46),
.B1(n_62),
.B2(n_68),
.Y(n_84)
);

INVx2_ASAP7_75t_L g85 ( 
.A(n_79),
.Y(n_85)
);

INVx3_ASAP7_75t_L g86 ( 
.A(n_80),
.Y(n_86)
);

BUFx3_ASAP7_75t_L g87 ( 
.A(n_71),
.Y(n_87)
);

INVx2_ASAP7_75t_L g88 ( 
.A(n_79),
.Y(n_88)
);

AND2x4_ASAP7_75t_L g89 ( 
.A(n_76),
.B(n_61),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_79),
.Y(n_90)
);

BUFx6f_ASAP7_75t_L g91 ( 
.A(n_81),
.Y(n_91)
);

INVx2_ASAP7_75t_L g92 ( 
.A(n_81),
.Y(n_92)
);

INVx2_ASAP7_75t_L g93 ( 
.A(n_81),
.Y(n_93)
);

INVx1_ASAP7_75t_L g94 ( 
.A(n_74),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_74),
.Y(n_95)
);

INVx1_ASAP7_75t_L g96 ( 
.A(n_70),
.Y(n_96)
);

BUFx6f_ASAP7_75t_L g97 ( 
.A(n_80),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_77),
.B(n_68),
.Y(n_98)
);

BUFx3_ASAP7_75t_L g99 ( 
.A(n_80),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_70),
.Y(n_100)
);

INVx3_ASAP7_75t_L g101 ( 
.A(n_87),
.Y(n_101)
);

BUFx2_ASAP7_75t_L g102 ( 
.A(n_87),
.Y(n_102)
);

AND2x4_ASAP7_75t_L g103 ( 
.A(n_87),
.B(n_78),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_94),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_89),
.B(n_72),
.Y(n_105)
);

CKINVDCx5p33_ASAP7_75t_R g106 ( 
.A(n_89),
.Y(n_106)
);

INVx1_ASAP7_75t_SL g107 ( 
.A(n_89),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_94),
.Y(n_108)
);

AOI22xp5_ASAP7_75t_L g109 ( 
.A1(n_89),
.A2(n_77),
.B1(n_76),
.B2(n_68),
.Y(n_109)
);

INVx3_ASAP7_75t_L g110 ( 
.A(n_99),
.Y(n_110)
);

OR2x2_ASAP7_75t_L g111 ( 
.A(n_89),
.B(n_45),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_95),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_95),
.Y(n_113)
);

INVx1_ASAP7_75t_SL g114 ( 
.A(n_84),
.Y(n_114)
);

OAI22xp5_ASAP7_75t_L g115 ( 
.A1(n_107),
.A2(n_109),
.B1(n_106),
.B2(n_102),
.Y(n_115)
);

OAI21x1_ASAP7_75t_L g116 ( 
.A1(n_104),
.A2(n_98),
.B(n_68),
.Y(n_116)
);

HB1xp67_ASAP7_75t_L g117 ( 
.A(n_103),
.Y(n_117)
);

CKINVDCx20_ASAP7_75t_R g118 ( 
.A(n_102),
.Y(n_118)
);

OR2x2_ASAP7_75t_L g119 ( 
.A(n_103),
.B(n_98),
.Y(n_119)
);

INVx1_ASAP7_75t_L g120 ( 
.A(n_104),
.Y(n_120)
);

INVx1_ASAP7_75t_L g121 ( 
.A(n_108),
.Y(n_121)
);

INVx2_ASAP7_75t_L g122 ( 
.A(n_101),
.Y(n_122)
);

AOI22xp33_ASAP7_75t_SL g123 ( 
.A1(n_103),
.A2(n_48),
.B1(n_51),
.B2(n_84),
.Y(n_123)
);

OR2x6_ASAP7_75t_L g124 ( 
.A(n_101),
.B(n_53),
.Y(n_124)
);

AND2x2_ASAP7_75t_L g125 ( 
.A(n_119),
.B(n_103),
.Y(n_125)
);

AOI21xp5_ASAP7_75t_L g126 ( 
.A1(n_116),
.A2(n_114),
.B(n_108),
.Y(n_126)
);

OAI22xp5_ASAP7_75t_L g127 ( 
.A1(n_115),
.A2(n_107),
.B1(n_105),
.B2(n_109),
.Y(n_127)
);

OAI211xp5_ASAP7_75t_SL g128 ( 
.A1(n_123),
.A2(n_105),
.B(n_111),
.C(n_119),
.Y(n_128)
);

NAND2xp5_ASAP7_75t_L g129 ( 
.A(n_117),
.B(n_103),
.Y(n_129)
);

OAI22xp5_ASAP7_75t_L g130 ( 
.A1(n_115),
.A2(n_111),
.B1(n_114),
.B2(n_101),
.Y(n_130)
);

AOI22xp33_ASAP7_75t_L g131 ( 
.A1(n_118),
.A2(n_111),
.B1(n_101),
.B2(n_112),
.Y(n_131)
);

OAI221xp5_ASAP7_75t_L g132 ( 
.A1(n_124),
.A2(n_112),
.B1(n_113),
.B2(n_58),
.C(n_49),
.Y(n_132)
);

AOI22xp33_ASAP7_75t_L g133 ( 
.A1(n_120),
.A2(n_113),
.B1(n_69),
.B2(n_65),
.Y(n_133)
);

AOI22xp33_ASAP7_75t_L g134 ( 
.A1(n_124),
.A2(n_110),
.B1(n_55),
.B2(n_50),
.Y(n_134)
);

AOI322xp5_ASAP7_75t_L g135 ( 
.A1(n_131),
.A2(n_121),
.A3(n_120),
.B1(n_56),
.B2(n_57),
.C1(n_50),
.C2(n_55),
.Y(n_135)
);

AOI22xp33_ASAP7_75t_L g136 ( 
.A1(n_128),
.A2(n_124),
.B1(n_121),
.B2(n_122),
.Y(n_136)
);

OR2x2_ASAP7_75t_L g137 ( 
.A(n_127),
.B(n_124),
.Y(n_137)
);

INVx3_ASAP7_75t_L g138 ( 
.A(n_125),
.Y(n_138)
);

AND2x2_ASAP7_75t_L g139 ( 
.A(n_129),
.B(n_116),
.Y(n_139)
);

OAI31xp33_ASAP7_75t_L g140 ( 
.A1(n_132),
.A2(n_57),
.A3(n_56),
.B(n_65),
.Y(n_140)
);

OR2x2_ASAP7_75t_L g141 ( 
.A(n_130),
.B(n_124),
.Y(n_141)
);

AOI22xp33_ASAP7_75t_L g142 ( 
.A1(n_134),
.A2(n_122),
.B1(n_116),
.B2(n_69),
.Y(n_142)
);

OAI22xp5_ASAP7_75t_L g143 ( 
.A1(n_133),
.A2(n_122),
.B1(n_110),
.B2(n_65),
.Y(n_143)
);

AOI221xp5_ASAP7_75t_SL g144 ( 
.A1(n_126),
.A2(n_67),
.B1(n_82),
.B2(n_73),
.C(n_75),
.Y(n_144)
);

INVx2_ASAP7_75t_L g145 ( 
.A(n_133),
.Y(n_145)
);

NAND4xp25_ASAP7_75t_L g146 ( 
.A(n_128),
.B(n_65),
.C(n_1),
.D(n_0),
.Y(n_146)
);

NOR2xp33_ASAP7_75t_L g147 ( 
.A(n_128),
.B(n_54),
.Y(n_147)
);

NAND2xp5_ASAP7_75t_L g148 ( 
.A(n_125),
.B(n_110),
.Y(n_148)
);

OAI21x1_ASAP7_75t_L g149 ( 
.A1(n_139),
.A2(n_110),
.B(n_73),
.Y(n_149)
);

INVxp67_ASAP7_75t_L g150 ( 
.A(n_139),
.Y(n_150)
);

AOI21xp5_ASAP7_75t_SL g151 ( 
.A1(n_137),
.A2(n_67),
.B(n_20),
.Y(n_151)
);

INVx2_ASAP7_75t_L g152 ( 
.A(n_137),
.Y(n_152)
);

AND2x2_ASAP7_75t_L g153 ( 
.A(n_138),
.B(n_0),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_141),
.Y(n_154)
);

INVx1_ASAP7_75t_L g155 ( 
.A(n_141),
.Y(n_155)
);

INVx2_ASAP7_75t_L g156 ( 
.A(n_138),
.Y(n_156)
);

AOI21xp5_ASAP7_75t_L g157 ( 
.A1(n_146),
.A2(n_67),
.B(n_66),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_138),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_138),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_148),
.Y(n_160)
);

OAI221xp5_ASAP7_75t_L g161 ( 
.A1(n_146),
.A2(n_67),
.B1(n_66),
.B2(n_75),
.C(n_82),
.Y(n_161)
);

AOI22xp5_ASAP7_75t_L g162 ( 
.A1(n_147),
.A2(n_66),
.B1(n_67),
.B2(n_85),
.Y(n_162)
);

NAND2xp5_ASAP7_75t_L g163 ( 
.A(n_135),
.B(n_1),
.Y(n_163)
);

NAND4xp25_ASAP7_75t_L g164 ( 
.A(n_135),
.B(n_136),
.C(n_140),
.D(n_142),
.Y(n_164)
);

OAI33xp33_ASAP7_75t_L g165 ( 
.A1(n_143),
.A2(n_3),
.A3(n_2),
.B1(n_4),
.B2(n_6),
.B3(n_5),
.Y(n_165)
);

AOI221xp5_ASAP7_75t_L g166 ( 
.A1(n_140),
.A2(n_67),
.B1(n_83),
.B2(n_66),
.C(n_80),
.Y(n_166)
);

OAI33xp33_ASAP7_75t_L g167 ( 
.A1(n_145),
.A2(n_3),
.A3(n_2),
.B1(n_4),
.B2(n_6),
.B3(n_5),
.Y(n_167)
);

NOR3xp33_ASAP7_75t_L g168 ( 
.A(n_144),
.B(n_83),
.C(n_80),
.Y(n_168)
);

BUFx2_ASAP7_75t_L g169 ( 
.A(n_145),
.Y(n_169)
);

AND2x4_ASAP7_75t_L g170 ( 
.A(n_139),
.B(n_21),
.Y(n_170)
);

AND2x2_ASAP7_75t_L g171 ( 
.A(n_139),
.B(n_7),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_139),
.Y(n_172)
);

NAND2xp5_ASAP7_75t_L g173 ( 
.A(n_135),
.B(n_7),
.Y(n_173)
);

OR2x2_ASAP7_75t_L g174 ( 
.A(n_172),
.B(n_8),
.Y(n_174)
);

INVxp67_ASAP7_75t_L g175 ( 
.A(n_171),
.Y(n_175)
);

OR2x6_ASAP7_75t_L g176 ( 
.A(n_151),
.B(n_8),
.Y(n_176)
);

OAI211xp5_ASAP7_75t_SL g177 ( 
.A1(n_163),
.A2(n_11),
.B(n_10),
.C(n_9),
.Y(n_177)
);

INVx2_ASAP7_75t_SL g178 ( 
.A(n_156),
.Y(n_178)
);

NAND2xp5_ASAP7_75t_L g179 ( 
.A(n_171),
.B(n_9),
.Y(n_179)
);

NAND2xp5_ASAP7_75t_L g180 ( 
.A(n_160),
.B(n_10),
.Y(n_180)
);

INVxp67_ASAP7_75t_L g181 ( 
.A(n_153),
.Y(n_181)
);

INVx1_ASAP7_75t_L g182 ( 
.A(n_172),
.Y(n_182)
);

AND2x2_ASAP7_75t_L g183 ( 
.A(n_150),
.B(n_12),
.Y(n_183)
);

INVx1_ASAP7_75t_L g184 ( 
.A(n_159),
.Y(n_184)
);

NAND2xp5_ASAP7_75t_L g185 ( 
.A(n_153),
.B(n_12),
.Y(n_185)
);

NAND4xp25_ASAP7_75t_L g186 ( 
.A(n_164),
.B(n_15),
.C(n_14),
.D(n_13),
.Y(n_186)
);

OR2x2_ASAP7_75t_L g187 ( 
.A(n_154),
.B(n_16),
.Y(n_187)
);

INVx1_ASAP7_75t_L g188 ( 
.A(n_159),
.Y(n_188)
);

BUFx2_ASAP7_75t_SL g189 ( 
.A(n_170),
.Y(n_189)
);

INVx1_ASAP7_75t_L g190 ( 
.A(n_158),
.Y(n_190)
);

AND2x2_ASAP7_75t_L g191 ( 
.A(n_152),
.B(n_17),
.Y(n_191)
);

INVx1_ASAP7_75t_SL g192 ( 
.A(n_170),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_152),
.B(n_17),
.Y(n_193)
);

OR2x2_ASAP7_75t_L g194 ( 
.A(n_154),
.B(n_18),
.Y(n_194)
);

AND2x2_ASAP7_75t_L g195 ( 
.A(n_155),
.B(n_18),
.Y(n_195)
);

NOR2xp33_ASAP7_75t_L g196 ( 
.A(n_173),
.B(n_22),
.Y(n_196)
);

INVx4_ASAP7_75t_L g197 ( 
.A(n_170),
.Y(n_197)
);

INVx1_ASAP7_75t_L g198 ( 
.A(n_156),
.Y(n_198)
);

AND2x2_ASAP7_75t_L g199 ( 
.A(n_155),
.B(n_66),
.Y(n_199)
);

AND2x2_ASAP7_75t_L g200 ( 
.A(n_169),
.B(n_66),
.Y(n_200)
);

BUFx2_ASAP7_75t_L g201 ( 
.A(n_169),
.Y(n_201)
);

INVx1_ASAP7_75t_L g202 ( 
.A(n_149),
.Y(n_202)
);

NOR2x1_ASAP7_75t_L g203 ( 
.A(n_151),
.B(n_25),
.Y(n_203)
);

INVx2_ASAP7_75t_L g204 ( 
.A(n_149),
.Y(n_204)
);

AOI22xp33_ASAP7_75t_L g205 ( 
.A1(n_165),
.A2(n_66),
.B1(n_91),
.B2(n_85),
.Y(n_205)
);

AOI22xp5_ASAP7_75t_L g206 ( 
.A1(n_167),
.A2(n_66),
.B1(n_88),
.B2(n_85),
.Y(n_206)
);

NOR2xp33_ASAP7_75t_L g207 ( 
.A(n_161),
.B(n_27),
.Y(n_207)
);

AND2x2_ASAP7_75t_L g208 ( 
.A(n_162),
.B(n_66),
.Y(n_208)
);

BUFx2_ASAP7_75t_L g209 ( 
.A(n_166),
.Y(n_209)
);

NAND2xp5_ASAP7_75t_L g210 ( 
.A(n_182),
.B(n_157),
.Y(n_210)
);

NOR2xp33_ASAP7_75t_L g211 ( 
.A(n_186),
.B(n_29),
.Y(n_211)
);

NOR2xp33_ASAP7_75t_L g212 ( 
.A(n_175),
.B(n_32),
.Y(n_212)
);

INVx1_ASAP7_75t_L g213 ( 
.A(n_182),
.Y(n_213)
);

AOI22xp33_ASAP7_75t_L g214 ( 
.A1(n_209),
.A2(n_168),
.B1(n_91),
.B2(n_88),
.Y(n_214)
);

OR2x2_ASAP7_75t_L g215 ( 
.A(n_201),
.B(n_35),
.Y(n_215)
);

NAND2xp33_ASAP7_75t_L g216 ( 
.A(n_192),
.B(n_36),
.Y(n_216)
);

NOR3xp33_ASAP7_75t_L g217 ( 
.A(n_177),
.B(n_90),
.C(n_88),
.Y(n_217)
);

OR2x2_ASAP7_75t_L g218 ( 
.A(n_201),
.B(n_38),
.Y(n_218)
);

INVx2_ASAP7_75t_L g219 ( 
.A(n_184),
.Y(n_219)
);

INVx1_ASAP7_75t_SL g220 ( 
.A(n_189),
.Y(n_220)
);

AOI22xp33_ASAP7_75t_L g221 ( 
.A1(n_209),
.A2(n_91),
.B1(n_92),
.B2(n_90),
.Y(n_221)
);

AOI21xp33_ASAP7_75t_SL g222 ( 
.A1(n_176),
.A2(n_41),
.B(n_40),
.Y(n_222)
);

XNOR2xp5_ASAP7_75t_L g223 ( 
.A(n_189),
.B(n_183),
.Y(n_223)
);

NOR2xp33_ASAP7_75t_L g224 ( 
.A(n_179),
.B(n_43),
.Y(n_224)
);

NOR2xp67_ASAP7_75t_L g225 ( 
.A(n_197),
.B(n_90),
.Y(n_225)
);

AND2x2_ASAP7_75t_L g226 ( 
.A(n_178),
.B(n_92),
.Y(n_226)
);

INVx1_ASAP7_75t_L g227 ( 
.A(n_184),
.Y(n_227)
);

OR2x2_ASAP7_75t_L g228 ( 
.A(n_198),
.B(n_188),
.Y(n_228)
);

AND2x2_ASAP7_75t_L g229 ( 
.A(n_178),
.B(n_92),
.Y(n_229)
);

INVx1_ASAP7_75t_L g230 ( 
.A(n_188),
.Y(n_230)
);

INVx1_ASAP7_75t_L g231 ( 
.A(n_190),
.Y(n_231)
);

OR2x2_ASAP7_75t_L g232 ( 
.A(n_181),
.B(n_93),
.Y(n_232)
);

INVx1_ASAP7_75t_L g233 ( 
.A(n_174),
.Y(n_233)
);

NAND2xp5_ASAP7_75t_L g234 ( 
.A(n_195),
.B(n_93),
.Y(n_234)
);

NAND4xp25_ASAP7_75t_L g235 ( 
.A(n_183),
.B(n_93),
.C(n_96),
.D(n_100),
.Y(n_235)
);

INVx1_ASAP7_75t_L g236 ( 
.A(n_174),
.Y(n_236)
);

NAND2xp5_ASAP7_75t_L g237 ( 
.A(n_195),
.B(n_91),
.Y(n_237)
);

AND2x2_ASAP7_75t_L g238 ( 
.A(n_202),
.B(n_91),
.Y(n_238)
);

OR2x2_ASAP7_75t_L g239 ( 
.A(n_197),
.B(n_91),
.Y(n_239)
);

OR2x2_ASAP7_75t_L g240 ( 
.A(n_197),
.B(n_91),
.Y(n_240)
);

INVx1_ASAP7_75t_L g241 ( 
.A(n_187),
.Y(n_241)
);

AND2x2_ASAP7_75t_L g242 ( 
.A(n_204),
.B(n_96),
.Y(n_242)
);

AND2x2_ASAP7_75t_L g243 ( 
.A(n_191),
.B(n_100),
.Y(n_243)
);

AND2x2_ASAP7_75t_L g244 ( 
.A(n_191),
.B(n_100),
.Y(n_244)
);

INVx1_ASAP7_75t_SL g245 ( 
.A(n_193),
.Y(n_245)
);

AOI22xp33_ASAP7_75t_L g246 ( 
.A1(n_176),
.A2(n_86),
.B1(n_99),
.B2(n_97),
.Y(n_246)
);

INVx1_ASAP7_75t_L g247 ( 
.A(n_187),
.Y(n_247)
);

NAND2xp5_ASAP7_75t_L g248 ( 
.A(n_193),
.B(n_86),
.Y(n_248)
);

NOR3xp33_ASAP7_75t_L g249 ( 
.A(n_180),
.B(n_86),
.C(n_99),
.Y(n_249)
);

NAND2xp5_ASAP7_75t_L g250 ( 
.A(n_241),
.B(n_194),
.Y(n_250)
);

NAND2xp5_ASAP7_75t_L g251 ( 
.A(n_247),
.B(n_194),
.Y(n_251)
);

INVx2_ASAP7_75t_SL g252 ( 
.A(n_220),
.Y(n_252)
);

INVx4_ASAP7_75t_L g253 ( 
.A(n_215),
.Y(n_253)
);

AOI211xp5_ASAP7_75t_SL g254 ( 
.A1(n_225),
.A2(n_185),
.B(n_196),
.C(n_207),
.Y(n_254)
);

AND2x2_ASAP7_75t_L g255 ( 
.A(n_219),
.B(n_200),
.Y(n_255)
);

NAND2xp5_ASAP7_75t_SL g256 ( 
.A(n_223),
.B(n_203),
.Y(n_256)
);

XOR2x2_ASAP7_75t_L g257 ( 
.A(n_223),
.B(n_176),
.Y(n_257)
);

INVx1_ASAP7_75t_L g258 ( 
.A(n_219),
.Y(n_258)
);

XNOR2x2_ASAP7_75t_L g259 ( 
.A(n_235),
.B(n_176),
.Y(n_259)
);

INVx1_ASAP7_75t_L g260 ( 
.A(n_228),
.Y(n_260)
);

INVx1_ASAP7_75t_L g261 ( 
.A(n_228),
.Y(n_261)
);

NAND2xp5_ASAP7_75t_L g262 ( 
.A(n_233),
.B(n_205),
.Y(n_262)
);

INVx2_ASAP7_75t_L g263 ( 
.A(n_227),
.Y(n_263)
);

NOR2xp33_ASAP7_75t_L g264 ( 
.A(n_236),
.B(n_200),
.Y(n_264)
);

XNOR2xp5_ASAP7_75t_L g265 ( 
.A(n_245),
.B(n_199),
.Y(n_265)
);

INVx1_ASAP7_75t_SL g266 ( 
.A(n_243),
.Y(n_266)
);

INVx1_ASAP7_75t_L g267 ( 
.A(n_213),
.Y(n_267)
);

NAND2xp5_ASAP7_75t_SL g268 ( 
.A(n_222),
.B(n_199),
.Y(n_268)
);

AND2x2_ASAP7_75t_L g269 ( 
.A(n_231),
.B(n_208),
.Y(n_269)
);

INVx1_ASAP7_75t_L g270 ( 
.A(n_230),
.Y(n_270)
);

NAND2xp5_ASAP7_75t_L g271 ( 
.A(n_210),
.B(n_206),
.Y(n_271)
);

AOI21xp33_ASAP7_75t_L g272 ( 
.A1(n_211),
.A2(n_212),
.B(n_224),
.Y(n_272)
);

INVx1_ASAP7_75t_L g273 ( 
.A(n_232),
.Y(n_273)
);

INVx1_ASAP7_75t_L g274 ( 
.A(n_232),
.Y(n_274)
);

NOR2x1_ASAP7_75t_L g275 ( 
.A(n_216),
.B(n_208),
.Y(n_275)
);

AOI21xp5_ASAP7_75t_L g276 ( 
.A1(n_216),
.A2(n_86),
.B(n_97),
.Y(n_276)
);

OAI22xp5_ASAP7_75t_L g277 ( 
.A1(n_246),
.A2(n_97),
.B1(n_215),
.B2(n_218),
.Y(n_277)
);

INVx1_ASAP7_75t_L g278 ( 
.A(n_218),
.Y(n_278)
);

INVx1_ASAP7_75t_L g279 ( 
.A(n_226),
.Y(n_279)
);

BUFx2_ASAP7_75t_L g280 ( 
.A(n_252),
.Y(n_280)
);

NAND2xp5_ASAP7_75t_L g281 ( 
.A(n_260),
.B(n_229),
.Y(n_281)
);

AOI21xp5_ASAP7_75t_L g282 ( 
.A1(n_275),
.A2(n_217),
.B(n_249),
.Y(n_282)
);

NAND2xp5_ASAP7_75t_L g283 ( 
.A(n_260),
.B(n_229),
.Y(n_283)
);

OR2x2_ASAP7_75t_L g284 ( 
.A(n_266),
.B(n_243),
.Y(n_284)
);

INVx1_ASAP7_75t_L g285 ( 
.A(n_261),
.Y(n_285)
);

INVx1_ASAP7_75t_SL g286 ( 
.A(n_252),
.Y(n_286)
);

INVx3_ASAP7_75t_L g287 ( 
.A(n_257),
.Y(n_287)
);

NAND2xp5_ASAP7_75t_L g288 ( 
.A(n_261),
.B(n_226),
.Y(n_288)
);

NAND2xp5_ASAP7_75t_L g289 ( 
.A(n_255),
.B(n_244),
.Y(n_289)
);

OAI22xp5_ASAP7_75t_L g290 ( 
.A1(n_256),
.A2(n_214),
.B1(n_240),
.B2(n_239),
.Y(n_290)
);

NOR2x1_ASAP7_75t_L g291 ( 
.A(n_253),
.B(n_239),
.Y(n_291)
);

NOR2xp33_ASAP7_75t_R g292 ( 
.A(n_265),
.B(n_253),
.Y(n_292)
);

NAND2xp5_ASAP7_75t_L g293 ( 
.A(n_255),
.B(n_244),
.Y(n_293)
);

AOI222xp33_ASAP7_75t_L g294 ( 
.A1(n_257),
.A2(n_248),
.B1(n_234),
.B2(n_237),
.C1(n_242),
.C2(n_238),
.Y(n_294)
);

NAND2xp5_ASAP7_75t_L g295 ( 
.A(n_269),
.B(n_242),
.Y(n_295)
);

AND2x2_ASAP7_75t_L g296 ( 
.A(n_269),
.B(n_240),
.Y(n_296)
);

NOR2x1_ASAP7_75t_L g297 ( 
.A(n_253),
.B(n_221),
.Y(n_297)
);

AOI21xp5_ASAP7_75t_L g298 ( 
.A1(n_268),
.A2(n_97),
.B(n_276),
.Y(n_298)
);

XNOR2x1_ASAP7_75t_L g299 ( 
.A(n_287),
.B(n_259),
.Y(n_299)
);

OA22x2_ASAP7_75t_SL g300 ( 
.A1(n_292),
.A2(n_259),
.B1(n_277),
.B2(n_278),
.Y(n_300)
);

O2A1O1Ixp33_ASAP7_75t_L g301 ( 
.A1(n_287),
.A2(n_272),
.B(n_262),
.C(n_271),
.Y(n_301)
);

INVx1_ASAP7_75t_L g302 ( 
.A(n_285),
.Y(n_302)
);

AOI211x1_ASAP7_75t_SL g303 ( 
.A1(n_282),
.A2(n_290),
.B(n_298),
.C(n_250),
.Y(n_303)
);

AOI211xp5_ASAP7_75t_L g304 ( 
.A1(n_282),
.A2(n_265),
.B(n_251),
.C(n_273),
.Y(n_304)
);

OAI21xp33_ASAP7_75t_SL g305 ( 
.A1(n_291),
.A2(n_270),
.B(n_267),
.Y(n_305)
);

OAI221xp5_ASAP7_75t_SL g306 ( 
.A1(n_294),
.A2(n_264),
.B1(n_274),
.B2(n_279),
.C(n_267),
.Y(n_306)
);

NAND2xp5_ASAP7_75t_L g307 ( 
.A(n_295),
.B(n_270),
.Y(n_307)
);

CKINVDCx5p33_ASAP7_75t_R g308 ( 
.A(n_286),
.Y(n_308)
);

OAI211xp5_ASAP7_75t_L g309 ( 
.A1(n_301),
.A2(n_297),
.B(n_280),
.C(n_254),
.Y(n_309)
);

OAI211xp5_ASAP7_75t_L g310 ( 
.A1(n_305),
.A2(n_298),
.B(n_281),
.C(n_283),
.Y(n_310)
);

NAND3xp33_ASAP7_75t_SL g311 ( 
.A(n_303),
.B(n_284),
.C(n_288),
.Y(n_311)
);

AO22x2_ASAP7_75t_L g312 ( 
.A1(n_299),
.A2(n_263),
.B1(n_258),
.B2(n_289),
.Y(n_312)
);

AND2x2_ASAP7_75t_L g313 ( 
.A(n_308),
.B(n_296),
.Y(n_313)
);

XNOR2xp5_ASAP7_75t_L g314 ( 
.A(n_313),
.B(n_304),
.Y(n_314)
);

HB1xp67_ASAP7_75t_L g315 ( 
.A(n_311),
.Y(n_315)
);

AOI22xp5_ASAP7_75t_L g316 ( 
.A1(n_309),
.A2(n_300),
.B1(n_307),
.B2(n_302),
.Y(n_316)
);

NAND3xp33_ASAP7_75t_L g317 ( 
.A(n_315),
.B(n_316),
.C(n_314),
.Y(n_317)
);

INVx1_ASAP7_75t_L g318 ( 
.A(n_315),
.Y(n_318)
);

OR2x2_ASAP7_75t_L g319 ( 
.A(n_318),
.B(n_310),
.Y(n_319)
);

INVx2_ASAP7_75t_L g320 ( 
.A(n_319),
.Y(n_320)
);

OAI22xp5_ASAP7_75t_L g321 ( 
.A1(n_320),
.A2(n_317),
.B1(n_312),
.B2(n_306),
.Y(n_321)
);

INVx1_ASAP7_75t_L g322 ( 
.A(n_321),
.Y(n_322)
);

AOI22xp5_ASAP7_75t_L g323 ( 
.A1(n_322),
.A2(n_312),
.B1(n_306),
.B2(n_293),
.Y(n_323)
);


endmodule