module fake_netlist_765_3406_n_84 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_26, n_6, n_2, n_3, n_9, n_4, n_25, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_84);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_26;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_84;

wire n_77;
wire n_71;
wire n_80;
wire n_62;
wire n_36;
wire n_81;
wire n_68;
wire n_73;
wire n_60;
wire n_53;
wire n_57;
wire n_41;
wire n_55;
wire n_46;
wire n_64;
wire n_82;
wire n_76;
wire n_72;
wire n_51;
wire n_78;
wire n_75;
wire n_42;
wire n_33;
wire n_70;
wire n_63;
wire n_69;
wire n_56;
wire n_52;
wire n_61;
wire n_45;
wire n_28;
wire n_65;
wire n_50;
wire n_79;
wire n_35;
wire n_43;
wire n_58;
wire n_74;
wire n_44;
wire n_66;
wire n_39;
wire n_34;
wire n_48;
wire n_49;
wire n_27;
wire n_59;
wire n_37;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_67;
wire n_29;
wire n_47;
wire n_54;
wire n_32;
wire n_83;

INVx2_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_0),
.B(n_7),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_4),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_19),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_14),
.B(n_5),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_SL g35 ( 
.A1(n_6),
.A2(n_15),
.B1(n_12),
.B2(n_26),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_15),
.B(n_10),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_17),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_22),
.B(n_18),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_24),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_13),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_9),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_10),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_29),
.B(n_14),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_16),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_27),
.A2(n_17),
.B1(n_16),
.B2(n_18),
.C(n_19),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_40),
.B(n_41),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

O2A1O1Ixp5_ASAP7_75t_L g48 ( 
.A1(n_28),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_48)
);

NOR2xp67_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_28),
.Y(n_49)
);

BUFx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

A2O1A1Ixp33_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_28),
.B(n_31),
.C(n_27),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_42),
.B(n_32),
.Y(n_52)
);

NOR2x1_ASAP7_75t_SL g53 ( 
.A(n_52),
.B(n_34),
.Y(n_53)
);

OR2x6_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_35),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_55),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_56),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_53),
.B(n_42),
.Y(n_59)
);

OR2x2_ASAP7_75t_L g60 ( 
.A(n_54),
.B(n_43),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_58),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_59),
.B(n_55),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_59),
.B(n_60),
.Y(n_64)
);

OR2x2_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_54),
.Y(n_65)
);

AOI22xp33_ASAP7_75t_L g66 ( 
.A1(n_63),
.A2(n_54),
.B1(n_57),
.B2(n_56),
.Y(n_66)
);

AOI22xp33_ASAP7_75t_L g67 ( 
.A1(n_63),
.A2(n_54),
.B1(n_57),
.B2(n_45),
.Y(n_67)
);

A2O1A1Ixp33_ASAP7_75t_L g68 ( 
.A1(n_64),
.A2(n_49),
.B(n_44),
.C(n_38),
.Y(n_68)
);

XNOR2x1_ASAP7_75t_L g69 ( 
.A(n_65),
.B(n_54),
.Y(n_69)
);

NAND2xp5_ASAP7_75t_SL g70 ( 
.A(n_65),
.B(n_62),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_61),
.Y(n_71)
);

NAND5xp2_ASAP7_75t_L g72 ( 
.A(n_66),
.B(n_36),
.C(n_61),
.D(n_30),
.E(n_53),
.Y(n_72)
);

NOR3xp33_ASAP7_75t_SL g73 ( 
.A(n_68),
.B(n_38),
.C(n_20),
.Y(n_73)
);

O2A1O1Ixp33_ASAP7_75t_L g74 ( 
.A1(n_67),
.A2(n_37),
.B(n_33),
.C(n_31),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_71),
.Y(n_75)
);

NAND4xp75_ASAP7_75t_L g76 ( 
.A(n_70),
.B(n_37),
.C(n_33),
.D(n_21),
.Y(n_76)
);

AND2x4_ASAP7_75t_SL g77 ( 
.A(n_75),
.B(n_69),
.Y(n_77)
);

NAND4xp75_ASAP7_75t_L g78 ( 
.A(n_73),
.B(n_69),
.C(n_23),
.D(n_21),
.Y(n_78)
);

AND2x4_ASAP7_75t_L g79 ( 
.A(n_72),
.B(n_25),
.Y(n_79)
);

NAND3xp33_ASAP7_75t_L g80 ( 
.A(n_74),
.B(n_11),
.C(n_8),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_77),
.B(n_76),
.Y(n_81)
);

OAI22xp5_ASAP7_75t_L g82 ( 
.A1(n_79),
.A2(n_78),
.B1(n_76),
.B2(n_80),
.Y(n_82)
);

AOI21x1_ASAP7_75t_L g83 ( 
.A1(n_82),
.A2(n_81),
.B(n_79),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_83),
.Y(n_84)
);


endmodule