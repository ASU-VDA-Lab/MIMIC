module fake_netlist_765_3145_n_12 (n_0, n_2, n_1, n_3, n_12);

input n_0;
input n_2;
input n_1;
input n_3;

output n_12;

wire n_9;
wire n_11;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

INVxp67_ASAP7_75t_SL g5 ( 
.A(n_2),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

AO32x2_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.A3(n_0),
.B1(n_2),
.B2(n_3),
.Y(n_7)
);

INVx4_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AOI211xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_4),
.B(n_7),
.C(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI222xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_3),
.B1(n_7),
.B2(n_8),
.C1(n_10),
.C2(n_0),
.Y(n_12)
);


endmodule