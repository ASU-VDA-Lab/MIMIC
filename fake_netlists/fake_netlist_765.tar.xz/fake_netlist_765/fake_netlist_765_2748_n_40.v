module fake_netlist_765_2748_n_40 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_40);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_40;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_4),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_9),
.B(n_2),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_0),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_0),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_17),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

OAI22xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_18),
.B1(n_15),
.B2(n_17),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_24),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_25),
.B1(n_26),
.B2(n_22),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_18),
.Y(n_30)
);

OAI21xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_20),
.B(n_14),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

O2A1O1Ixp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_30),
.B(n_20),
.C(n_19),
.Y(n_33)
);

NAND3xp33_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_23),
.C(n_15),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_1),
.Y(n_35)
);

NOR3xp33_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_19),
.C(n_1),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OAI22x1_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_6),
.B1(n_5),
.B2(n_3),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.B1(n_11),
.B2(n_10),
.Y(n_40)
);


endmodule