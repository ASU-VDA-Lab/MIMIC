module fake_netlist_765_2632_n_58 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_58);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_58;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_11),
.A2(n_16),
.B1(n_5),
.B2(n_3),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_4),
.B(n_10),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_2),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

INVx5_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

BUFx3_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_24),
.B(n_2),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_27),
.Y(n_35)
);

BUFx2_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

OAI22xp33_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_28),
.B1(n_29),
.B2(n_22),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_34),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_37),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_28),
.Y(n_42)
);

HB1xp67_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

INVx1_ASAP7_75t_SL g44 ( 
.A(n_42),
.Y(n_44)
);

AOI211xp5_ASAP7_75t_SL g45 ( 
.A1(n_41),
.A2(n_34),
.B(n_38),
.C(n_30),
.Y(n_45)
);

NAND3xp33_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_34),
.C(n_32),
.Y(n_46)
);

XNOR2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_34),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_26),
.A3(n_23),
.B1(n_21),
.B2(n_32),
.C1(n_33),
.C2(n_3),
.Y(n_48)
);

NAND2xp33_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_31),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_47),
.A2(n_25),
.B1(n_16),
.B2(n_15),
.Y(n_50)
);

INVx3_ASAP7_75t_SL g51 ( 
.A(n_48),
.Y(n_51)
);

AOI322xp5_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_25),
.A3(n_20),
.B1(n_17),
.B2(n_18),
.C1(n_31),
.C2(n_1),
.Y(n_52)
);

OAI211xp5_ASAP7_75t_SL g53 ( 
.A1(n_48),
.A2(n_20),
.B(n_18),
.C(n_17),
.Y(n_53)
);

AOI31xp33_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_8),
.A3(n_7),
.B(n_6),
.Y(n_54)
);

CKINVDCx20_ASAP7_75t_R g55 ( 
.A(n_51),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

OAI21xp33_ASAP7_75t_L g57 ( 
.A1(n_55),
.A2(n_52),
.B(n_31),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_56),
.B1(n_54),
.B2(n_31),
.Y(n_58)
);


endmodule