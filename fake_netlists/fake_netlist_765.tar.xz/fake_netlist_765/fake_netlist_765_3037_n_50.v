module fake_netlist_765_3037_n_50 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_50);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_50;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_13),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_10),
.B(n_15),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_0),
.B(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_2),
.B(n_5),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_9),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_16),
.B(n_0),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_1),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_18),
.B(n_2),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_20),
.Y(n_28)
);

NOR2x1_ASAP7_75t_SL g29 ( 
.A(n_27),
.B(n_17),
.Y(n_29)
);

AO21x2_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_23),
.B(n_21),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_27),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_28),
.B(n_23),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_29),
.Y(n_34)
);

NOR2x1p5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_18),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_30),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

NAND4xp25_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_25),
.C(n_24),
.D(n_21),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_31),
.B1(n_30),
.B2(n_18),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_35),
.B1(n_19),
.B2(n_22),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_19),
.B(n_29),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_30),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_30),
.Y(n_43)
);

INVx4_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_30),
.B1(n_22),
.B2(n_3),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_22),
.B1(n_8),
.B2(n_4),
.C(n_5),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_22),
.B1(n_9),
.B2(n_4),
.C(n_8),
.Y(n_47)
);

INVx2_ASAP7_75t_SL g48 ( 
.A(n_45),
.Y(n_48)
);

XNOR2xp5_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_46),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_49),
.A2(n_47),
.B1(n_14),
.B2(n_11),
.Y(n_50)
);


endmodule