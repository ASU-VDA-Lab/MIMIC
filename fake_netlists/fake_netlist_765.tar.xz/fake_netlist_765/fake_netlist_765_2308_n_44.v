module fake_netlist_765_2308_n_44 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_44);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_44;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_10),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_17),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_16),
.B(n_7),
.Y(n_22)
);

AND2x6_ASAP7_75t_L g23 ( 
.A(n_15),
.B(n_0),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_6),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_3),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_2),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_R g28 ( 
.A(n_12),
.B(n_8),
.Y(n_28)
);

O2A1O1Ixp5_ASAP7_75t_L g29 ( 
.A1(n_24),
.A2(n_11),
.B(n_9),
.C(n_5),
.Y(n_29)
);

A2O1A1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_20),
.B(n_26),
.C(n_21),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_R g33 ( 
.A(n_30),
.B(n_28),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_27),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_23),
.Y(n_35)
);

OAI32xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_20),
.A3(n_25),
.B1(n_23),
.B2(n_29),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_23),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_36),
.B1(n_35),
.B2(n_22),
.C(n_23),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_17),
.B1(n_16),
.B2(n_1),
.Y(n_39)
);

CKINVDCx20_ASAP7_75t_R g40 ( 
.A(n_39),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_38),
.Y(n_41)
);

BUFx3_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI21x1_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_14),
.B(n_13),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_40),
.B1(n_43),
.B2(n_18),
.Y(n_44)
);


endmodule