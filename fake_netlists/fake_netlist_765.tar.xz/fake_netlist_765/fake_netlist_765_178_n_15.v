module fake_netlist_765_178_n_15 (n_1, n_2, n_3, n_4, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_8;
wire n_9;
wire n_10;
wire n_13;
wire n_5;
wire n_7;
wire n_6;
wire n_11;

CKINVDCx20_ASAP7_75t_R g5 ( 
.A(n_1),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_2),
.B(n_0),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_2),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B(n_5),
.Y(n_12)
);

XNOR2x1_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_5),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_4),
.C(n_3),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_4),
.C(n_3),
.Y(n_15)
);


endmodule