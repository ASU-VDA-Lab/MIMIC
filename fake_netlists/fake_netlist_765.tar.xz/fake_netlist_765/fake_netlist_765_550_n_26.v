module fake_netlist_765_550_n_26 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_26);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_24;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_15;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_3),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_12),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_7),
.B(n_5),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_8),
.B(n_4),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_18),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_15),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_17),
.B1(n_13),
.B2(n_9),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_21),
.Y(n_23)
);

INVx2_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_11),
.Y(n_26)
);


endmodule