module fake_netlist_765_364_n_60 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_60);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_60;

wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_27;
wire n_42;
wire n_59;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx1_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_18),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_5),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_4),
.A2(n_8),
.B1(n_3),
.B2(n_10),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_0),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_14),
.B(n_24),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_17),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_20),
.B(n_7),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_SL g36 ( 
.A1(n_12),
.A2(n_19),
.B1(n_1),
.B2(n_15),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_20),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_24),
.B1(n_23),
.B2(n_22),
.Y(n_38)
);

NOR2x2_ASAP7_75t_L g39 ( 
.A(n_27),
.B(n_22),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_29),
.Y(n_40)
);

NAND2x1_ASAP7_75t_L g41 ( 
.A(n_25),
.B(n_23),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_30),
.Y(n_42)
);

AO31x2_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_32),
.A3(n_31),
.B(n_33),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_34),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

BUFx3_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_43),
.Y(n_49)
);

AOI221xp5_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_38),
.B1(n_36),
.B2(n_39),
.C(n_35),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_46),
.B1(n_38),
.B2(n_36),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_51),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

CKINVDCx5p33_ASAP7_75t_R g56 ( 
.A(n_54),
.Y(n_56)
);

A2O1A1Ixp33_ASAP7_75t_SL g57 ( 
.A1(n_55),
.A2(n_28),
.B(n_26),
.C(n_13),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_56),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_58),
.Y(n_59)
);

AOI22xp33_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_57),
.B1(n_21),
.B2(n_16),
.Y(n_60)
);


endmodule