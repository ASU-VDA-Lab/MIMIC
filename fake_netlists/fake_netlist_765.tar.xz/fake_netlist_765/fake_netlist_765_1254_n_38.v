module fake_netlist_765_1254_n_38 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_38);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_38;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_9),
.B(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_18),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_SL g23 ( 
.A(n_13),
.B(n_4),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_12),
.B(n_10),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_19),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_14),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_21),
.B(n_1),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_28),
.Y(n_31)
);

AO221x2_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_15),
.B1(n_14),
.B2(n_22),
.C(n_23),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_32),
.Y(n_33)
);

OAI21xp33_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_20),
.B(n_24),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

INVx5_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

AOI322xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_6),
.A3(n_5),
.B1(n_11),
.B2(n_17),
.C1(n_7),
.C2(n_8),
.Y(n_38)
);


endmodule