module fake_netlist_765_1221_n_53 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_53);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_53;

wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_52;
wire n_32;

INVx1_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_19),
.B(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

INVx6_ASAP7_75t_L g28 ( 
.A(n_11),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_20),
.B(n_12),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_8),
.Y(n_31)
);

CKINVDCx6p67_ASAP7_75t_R g32 ( 
.A(n_5),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_1),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_14),
.B(n_24),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_18),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_28),
.A2(n_24),
.B1(n_18),
.B2(n_0),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_25),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_32),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_SL g40 ( 
.A1(n_38),
.A2(n_29),
.B1(n_27),
.B2(n_34),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

OAI21x1_ASAP7_75t_SL g42 ( 
.A1(n_40),
.A2(n_37),
.B(n_26),
.Y(n_42)
);

OAI322xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_31),
.A3(n_30),
.B1(n_9),
.B2(n_13),
.C1(n_2),
.C2(n_7),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

BUFx3_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_39),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

OAI21x1_ASAP7_75t_SL g50 ( 
.A1(n_49),
.A2(n_46),
.B(n_15),
.Y(n_50)
);

NAND5xp2_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_31),
.C(n_21),
.D(n_16),
.E(n_17),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

AOI22xp33_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_51),
.B1(n_23),
.B2(n_22),
.Y(n_53)
);


endmodule