module fake_netlist_765_49_n_23 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_23);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_23;

wire n_20;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;

INVx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_2),
.B(n_10),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_4),
.Y(n_16)
);

AOI211x1_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_8),
.B(n_3),
.C(n_0),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_14),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND4xp25_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_17),
.C(n_16),
.D(n_4),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_15),
.C(n_5),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_13),
.B1(n_7),
.B2(n_9),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_7),
.C(n_13),
.D(n_12),
.Y(n_23)
);


endmodule