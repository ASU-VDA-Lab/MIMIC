module fake_netlist_857_570_n_25 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_25);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_25;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

O2A1O1Ixp33_ASAP7_75t_SL g18 ( 
.A1(n_14),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

AOI21xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B(n_13),
.Y(n_21)
);

NOR4xp25_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.C(n_20),
.D(n_4),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_6),
.Y(n_23)
);

OAI22x1_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_7),
.B1(n_1),
.B2(n_0),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_10),
.B1(n_3),
.B2(n_2),
.Y(n_25)
);


endmodule