module fake_netlist_857_535_n_25 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_25);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_25;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

INVxp67_ASAP7_75t_SL g7 ( 
.A(n_1),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_0),
.B(n_5),
.Y(n_8)
);

INVx5_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

BUFx10_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVx4_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_3),
.B(n_1),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_14),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_10),
.B1(n_7),
.B2(n_9),
.C(n_11),
.Y(n_19)
);

AOI21xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_9),
.B(n_16),
.Y(n_20)
);

NOR4xp75_ASAP7_75t_SL g21 ( 
.A(n_19),
.B(n_11),
.C(n_4),
.D(n_2),
.Y(n_21)
);

OR5x1_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_11),
.C(n_5),
.D(n_2),
.E(n_4),
.Y(n_22)
);

AO21x2_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_9),
.B(n_16),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_21),
.B(n_9),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_24),
.B(n_20),
.Y(n_25)
);


endmodule