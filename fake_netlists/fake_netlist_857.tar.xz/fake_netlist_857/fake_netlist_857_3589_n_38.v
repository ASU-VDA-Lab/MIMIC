module fake_netlist_857_3589_n_38 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_38);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_38;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_27;

AND2x4_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_5),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_3),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_1),
.B(n_2),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_4),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_12),
.Y(n_21)
);

OA21x2_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_12),
.B(n_17),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_19),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

AOI211xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_15),
.B(n_14),
.C(n_17),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVxp67_ASAP7_75t_SL g29 ( 
.A(n_28),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

OAI21xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_13),
.B(n_4),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_20),
.B1(n_17),
.B2(n_5),
.Y(n_32)
);

NAND4xp25_ASAP7_75t_SL g33 ( 
.A(n_31),
.B(n_7),
.C(n_6),
.D(n_8),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_11),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx2_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_6),
.B1(n_33),
.B2(n_36),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);


endmodule