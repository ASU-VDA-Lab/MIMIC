module fake_netlist_857_2366_n_32 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_32);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_9;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_1),
.Y(n_9)
);

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_0),
.A2(n_8),
.B1(n_5),
.B2(n_2),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_SL g15 ( 
.A(n_13),
.B(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_9),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_1),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_13),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_18),
.Y(n_23)
);

OAI21xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_19),
.B(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_25),
.B1(n_18),
.B2(n_21),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_SL g27 ( 
.A1(n_25),
.A2(n_15),
.B(n_11),
.Y(n_27)
);

CKINVDCx6p67_ASAP7_75t_R g28 ( 
.A(n_27),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_14),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_15),
.B1(n_6),
.B2(n_4),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_3),
.B1(n_6),
.B2(n_31),
.Y(n_32)
);


endmodule