module fake_netlist_857_2528_n_32 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_4),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

BUFx10_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_8),
.B(n_1),
.Y(n_19)
);

OR2x6_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_5),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

NOR2x1_ASAP7_75t_R g22 ( 
.A(n_21),
.B(n_18),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_20),
.B1(n_14),
.B2(n_19),
.Y(n_24)
);

NAND4xp25_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.C(n_18),
.D(n_5),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_17),
.Y(n_26)
);

NAND4xp25_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_7),
.C(n_6),
.D(n_17),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_26),
.B(n_3),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_17),
.C(n_9),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_17),
.B1(n_11),
.B2(n_10),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_29),
.B1(n_13),
.B2(n_12),
.Y(n_32)
);


endmodule