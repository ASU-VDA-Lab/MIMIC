module fake_netlist_857_1727_n_13 (n_2, n_0, n_1, n_13);

input n_2;
input n_0;
input n_1;

output n_13;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.B1(n_3),
.B2(n_0),
.C(n_1),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AND3x4_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_8),
.C(n_1),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_1),
.B1(n_2),
.B2(n_12),
.Y(n_13)
);


endmodule