module fake_netlist_857_577_n_18 (n_2, n_0, n_3, n_1, n_18);

input n_2;
input n_0;
input n_3;
input n_1;

output n_18;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_17;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

NAND3xp33_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.C(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx4_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

OAI22xp33_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_7),
.B1(n_8),
.B2(n_9),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_7),
.B(n_11),
.C(n_2),
.Y(n_14)
);

NAND4xp25_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_3),
.C(n_2),
.D(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_3),
.B1(n_9),
.B2(n_12),
.Y(n_17)
);

OAI22xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_9),
.B1(n_17),
.B2(n_15),
.Y(n_18)
);


endmodule