module fake_netlist_857_1540_n_33 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_33);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_33;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_9;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_4),
.B(n_1),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_11),
.A2(n_6),
.B(n_1),
.Y(n_18)
);

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_10),
.A2(n_7),
.B(n_6),
.Y(n_19)
);

OAI21x1_ASAP7_75t_L g20 ( 
.A1(n_10),
.A2(n_7),
.B(n_2),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_13),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

NOR2x1_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_10),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_14),
.C(n_9),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_SL g28 ( 
.A(n_26),
.B(n_15),
.C(n_13),
.Y(n_28)
);

AND3x4_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_24),
.C(n_22),
.Y(n_29)
);

AND3x4_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_22),
.C(n_15),
.Y(n_30)
);

OAI21xp33_ASAP7_75t_SL g31 ( 
.A1(n_29),
.A2(n_20),
.B(n_23),
.Y(n_31)
);

AOI21xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_25),
.B(n_12),
.Y(n_32)
);

OAI21xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_19),
.B(n_31),
.Y(n_33)
);


endmodule