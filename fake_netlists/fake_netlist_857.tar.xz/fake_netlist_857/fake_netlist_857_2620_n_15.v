module fake_netlist_857_2620_n_15 (n_2, n_0, n_1, n_15);

input n_2;
input n_0;
input n_1;

output n_15;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

BUFx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

CKINVDCx6p67_ASAP7_75t_R g7 ( 
.A(n_5),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_4),
.B1(n_3),
.B2(n_0),
.Y(n_8)
);

OAI32xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.A3(n_4),
.B1(n_6),
.B2(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_5),
.B1(n_4),
.B2(n_7),
.C(n_2),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_2),
.B1(n_4),
.B2(n_6),
.C(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

XNOR2x1_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_2),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_6),
.B1(n_14),
.B2(n_10),
.Y(n_15)
);


endmodule