module fake_netlist_857_696_n_13 (n_2, n_0, n_1, n_13);

input n_2;
input n_0;
input n_1;

output n_13;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

INVx3_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx1_ASAP7_75t_SL g7 ( 
.A(n_6),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_5),
.B1(n_3),
.B2(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_4),
.B(n_8),
.C(n_3),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_SL g12 ( 
.A(n_10),
.B(n_3),
.C(n_0),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_2),
.B(n_12),
.Y(n_13)
);


endmodule