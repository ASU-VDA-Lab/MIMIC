module fake_netlist_732_194_n_75 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_75);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_75;

wire n_46;
wire n_44;
wire n_61;
wire n_64;
wire n_62;
wire n_66;
wire n_71;
wire n_74;
wire n_72;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_68;
wire n_73;
wire n_49;
wire n_28;
wire n_65;
wire n_27;
wire n_37;
wire n_42;
wire n_59;
wire n_24;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_50;
wire n_31;
wire n_30;
wire n_38;
wire n_53;
wire n_57;
wire n_35;
wire n_63;
wire n_25;
wire n_70;
wire n_69;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_67;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_12),
.B(n_2),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

INVx6_ASAP7_75t_L g30 ( 
.A(n_15),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_6),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_0),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_9),
.A2(n_23),
.B1(n_4),
.B2(n_22),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_15),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_21),
.B(n_1),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_3),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_17),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_25),
.B(n_12),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_32),
.Y(n_39)
);

NOR2xp67_ASAP7_75t_L g40 ( 
.A(n_27),
.B(n_13),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_30),
.Y(n_41)
);

INVxp67_ASAP7_75t_L g42 ( 
.A(n_34),
.Y(n_42)
);

OR2x6_ASAP7_75t_L g43 ( 
.A(n_30),
.B(n_13),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_37),
.B(n_14),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_39),
.A2(n_29),
.B(n_36),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_39),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_29),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_41),
.B(n_44),
.Y(n_48)
);

AO21x2_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_38),
.B(n_26),
.Y(n_49)
);

OAI21xp5_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_38),
.B(n_40),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_46),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_47),
.Y(n_53)
);

BUFx2_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

NAND3xp33_ASAP7_75t_SL g56 ( 
.A(n_53),
.B(n_33),
.C(n_50),
.Y(n_56)
);

NOR2xp33_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_50),
.Y(n_57)
);

O2A1O1Ixp33_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_43),
.B(n_49),
.C(n_27),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

AOI22xp5_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_54),
.B1(n_43),
.B2(n_49),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_43),
.B1(n_49),
.B2(n_35),
.Y(n_61)
);

AOI21xp5_ASAP7_75t_L g62 ( 
.A1(n_58),
.A2(n_49),
.B(n_43),
.Y(n_62)
);

OAI21xp33_ASAP7_75t_SL g63 ( 
.A1(n_59),
.A2(n_35),
.B(n_18),
.Y(n_63)
);

OAI211xp5_ASAP7_75t_L g64 ( 
.A1(n_56),
.A2(n_28),
.B(n_24),
.C(n_31),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_63),
.Y(n_65)
);

NAND4xp25_ASAP7_75t_L g66 ( 
.A(n_61),
.B(n_19),
.C(n_28),
.D(n_24),
.Y(n_66)
);

NAND3xp33_ASAP7_75t_L g67 ( 
.A(n_64),
.B(n_28),
.C(n_24),
.Y(n_67)
);

NOR2x1_ASAP7_75t_L g68 ( 
.A(n_62),
.B(n_31),
.Y(n_68)
);

AND2x2_ASAP7_75t_L g69 ( 
.A(n_65),
.B(n_60),
.Y(n_69)
);

OR4x2_ASAP7_75t_L g70 ( 
.A(n_66),
.B(n_10),
.C(n_7),
.D(n_5),
.Y(n_70)
);

AND2x4_ASAP7_75t_L g71 ( 
.A(n_68),
.B(n_16),
.Y(n_71)
);

NAND2xp5_ASAP7_75t_L g72 ( 
.A(n_67),
.B(n_65),
.Y(n_72)
);

OA22x2_ASAP7_75t_L g73 ( 
.A1(n_71),
.A2(n_70),
.B1(n_69),
.B2(n_72),
.Y(n_73)
);

OAI21x1_ASAP7_75t_SL g74 ( 
.A1(n_73),
.A2(n_70),
.B(n_72),
.Y(n_74)
);

OR2x6_ASAP7_75t_L g75 ( 
.A(n_74),
.B(n_71),
.Y(n_75)
);


endmodule