module fake_netlist_732_642_n_27 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_27);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;

output n_27;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_24;
wire n_10;
wire n_26;
wire n_9;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;
wire n_8;

INVx1_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_3),
.A2(n_1),
.B1(n_4),
.B2(n_7),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

AND2x6_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

NAND2x1p5_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_2),
.Y(n_15)
);

O2A1O1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_10),
.A2(n_1),
.B(n_5),
.C(n_9),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_12),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

OAI21xp33_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_20),
.B(n_19),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_16),
.B1(n_15),
.B2(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_13),
.B1(n_15),
.B2(n_26),
.Y(n_27)
);


endmodule