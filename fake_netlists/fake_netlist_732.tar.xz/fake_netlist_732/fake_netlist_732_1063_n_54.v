module fake_netlist_732_1063_n_54 (n_20, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_54);

input n_20;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_54;

wire n_23;
wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_52;
wire n_32;

INVx2_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

AND2x2_ASAP7_75t_SL g28 ( 
.A(n_8),
.B(n_4),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_0),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_18),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_3),
.A2(n_18),
.B1(n_1),
.B2(n_21),
.Y(n_32)
);

BUFx3_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_19),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_27),
.B(n_19),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_23),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_30),
.B(n_25),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_36),
.C(n_37),
.Y(n_43)
);

NAND3xp33_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_28),
.C(n_29),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_35),
.B(n_32),
.Y(n_45)
);

AOI21xp33_ASAP7_75t_SL g46 ( 
.A1(n_45),
.A2(n_6),
.B(n_2),
.Y(n_46)
);

XNOR2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_7),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

AND3x1_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_10),
.C(n_9),
.Y(n_49)
);

NAND2x1p5_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_24),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

NAND3xp33_ASAP7_75t_SL g52 ( 
.A(n_50),
.B(n_24),
.C(n_12),
.Y(n_52)
);

AOI22xp33_ASAP7_75t_SL g53 ( 
.A1(n_51),
.A2(n_52),
.B1(n_49),
.B2(n_14),
.Y(n_53)
);

AOI21xp33_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_20),
.B(n_17),
.Y(n_54)
);


endmodule