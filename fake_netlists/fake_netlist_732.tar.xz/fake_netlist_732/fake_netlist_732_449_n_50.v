module fake_netlist_732_449_n_50 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_50);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_50;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_13),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_3),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_17),
.B(n_2),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_11),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_SL g33 ( 
.A(n_24),
.B(n_18),
.C(n_1),
.Y(n_33)
);

OR2x6_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_4),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_25),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_26),
.Y(n_38)
);

OAI33xp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_28),
.A3(n_27),
.B1(n_31),
.B2(n_23),
.B3(n_22),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_38),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_33),
.C(n_34),
.Y(n_43)
);

A2O1A1Ixp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_38),
.B(n_29),
.C(n_28),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_SL g45 ( 
.A1(n_44),
.A2(n_7),
.B(n_5),
.Y(n_45)
);

OAI21xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_12),
.B(n_10),
.Y(n_46)
);

AND2x4_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_14),
.Y(n_47)
);

OR3x1_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_16),
.C(n_15),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_47),
.B1(n_20),
.B2(n_19),
.Y(n_50)
);


endmodule