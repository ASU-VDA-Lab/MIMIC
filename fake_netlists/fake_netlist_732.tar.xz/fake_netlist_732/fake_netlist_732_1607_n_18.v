module fake_netlist_732_1607_n_18 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_18);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_18;

wire n_14;
wire n_16;
wire n_17;
wire n_13;
wire n_11;
wire n_12;
wire n_15;
wire n_10;

BUFx10_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

OR2x6_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_11),
.B(n_7),
.C(n_2),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_8),
.B1(n_5),
.B2(n_4),
.Y(n_18)
);


endmodule