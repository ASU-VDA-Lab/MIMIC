module fake_netlist_732_880_n_32 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_32);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_32;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_12),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_13),
.B(n_1),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_0),
.Y(n_19)
);

CKINVDCx14_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_16),
.Y(n_22)
);

AO31x2_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.A3(n_17),
.B(n_1),
.Y(n_23)
);

INVxp67_ASAP7_75t_SL g24 ( 
.A(n_22),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

OAI22xp33_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_24),
.B1(n_14),
.B2(n_23),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_15),
.B1(n_23),
.B2(n_21),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_15),
.B1(n_6),
.B2(n_4),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_4),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_6),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AOI322xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_30),
.A3(n_7),
.B1(n_8),
.B2(n_9),
.C1(n_2),
.C2(n_3),
.Y(n_32)
);


endmodule