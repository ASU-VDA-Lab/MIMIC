module fake_netlist_732_1637_n_35 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_35);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_35;

wire n_20;
wire n_23;
wire n_22;
wire n_34;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_25;
wire n_21;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_11),
.B(n_19),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_12),
.B(n_1),
.Y(n_26)
);

OR2x6_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_19),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_22),
.A2(n_24),
.B1(n_23),
.B2(n_20),
.Y(n_28)
);

OAI21x1_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_3),
.B(n_2),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_25),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

OAI32xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_28),
.A3(n_26),
.B1(n_4),
.B2(n_5),
.Y(n_32)
);

OAI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_30),
.B1(n_7),
.B2(n_6),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

OAI222xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_10),
.B1(n_8),
.B2(n_13),
.C1(n_16),
.C2(n_14),
.Y(n_35)
);


endmodule