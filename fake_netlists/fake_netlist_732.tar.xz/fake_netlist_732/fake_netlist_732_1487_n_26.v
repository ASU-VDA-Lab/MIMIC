module fake_netlist_732_1487_n_26 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_26);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_24;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

BUFx6f_ASAP7_75t_SL g14 ( 
.A(n_9),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_L g15 ( 
.A1(n_4),
.A2(n_2),
.B1(n_3),
.B2(n_13),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_4),
.B(n_6),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_1),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_19)
);

NAND2xp33_ASAP7_75t_SL g20 ( 
.A(n_18),
.B(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_17),
.B(n_19),
.Y(n_22)
);

AOI211xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_21),
.B(n_14),
.C(n_5),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_7),
.B1(n_10),
.B2(n_8),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_7),
.B1(n_12),
.B2(n_11),
.Y(n_26)
);


endmodule