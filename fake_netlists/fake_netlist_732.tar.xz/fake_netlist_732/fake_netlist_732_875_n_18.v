module fake_netlist_732_875_n_18 (n_1, n_2, n_3, n_4, n_5, n_0, n_18);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_18;

wire n_12;
wire n_15;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_7;
wire n_16;
wire n_17;
wire n_13;
wire n_6;
wire n_8;

NAND3x1_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_0),
.C(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_0),
.Y(n_7)
);

NAND2x1p5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_1),
.Y(n_8)
);

CKINVDCx6p67_ASAP7_75t_R g9 ( 
.A(n_6),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_1),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.C(n_2),
.Y(n_11)
);

OAI33xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_2),
.A3(n_4),
.B1(n_5),
.B2(n_8),
.B3(n_9),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_10),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.C(n_9),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_13),
.B1(n_14),
.B2(n_12),
.C1(n_16),
.C2(n_15),
.Y(n_18)
);


endmodule