module fake_netlist_732_961_n_42 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_42);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_42;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

NAND2x1p5_ASAP7_75t_L g20 ( 
.A(n_4),
.B(n_16),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_18),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx3_ASAP7_75t_SL g27 ( 
.A(n_23),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_20),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_20),
.Y(n_30)
);

OAI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_28),
.B1(n_22),
.B2(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

NOR2x1p5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_25),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_16),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_18),
.B1(n_1),
.B2(n_0),
.Y(n_35)
);

XNOR2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_2),
.Y(n_36)
);

BUFx12f_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

NOR2x1_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_3),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

OR3x2_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_7),
.C(n_5),
.Y(n_41)
);

AOI322xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_39),
.A3(n_11),
.B1(n_10),
.B2(n_9),
.C1(n_14),
.C2(n_12),
.Y(n_42)
);


endmodule