module fake_netlist_732_1582_n_33 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_33);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_33;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_11),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_7),
.B1(n_4),
.B2(n_1),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_15),
.B1(n_13),
.B2(n_12),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_19),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI211xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_24),
.B(n_19),
.C(n_12),
.Y(n_27)
);

OAI221xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_24),
.B1(n_7),
.B2(n_1),
.C(n_4),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_27),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_SL g33 ( 
.A1(n_31),
.A2(n_8),
.B1(n_9),
.B2(n_32),
.Y(n_33)
);


endmodule