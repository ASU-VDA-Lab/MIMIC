module fake_netlist_732_124_n_49 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_49);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_49;

wire n_20;
wire n_23;
wire n_46;
wire n_14;
wire n_44;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_39;
wire n_13;
wire n_34;
wire n_45;
wire n_48;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_12;
wire n_19;
wire n_15;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_8),
.B(n_6),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_5),
.B(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_1),
.B(n_7),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_0),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_1),
.Y(n_25)
);

CKINVDCx14_ASAP7_75t_R g26 ( 
.A(n_12),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_18),
.B(n_14),
.Y(n_27)
);

A2O1A1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_19),
.A2(n_7),
.B(n_5),
.C(n_4),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_18),
.A2(n_17),
.B1(n_21),
.B2(n_15),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_21),
.B1(n_15),
.B2(n_20),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_25),
.A2(n_21),
.B(n_13),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_21),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_26),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_30),
.B(n_29),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_30),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_32),
.B1(n_31),
.B2(n_28),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_36),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_35),
.Y(n_42)
);

AOI211xp5_ASAP7_75t_SL g43 ( 
.A1(n_40),
.A2(n_31),
.B(n_29),
.C(n_32),
.Y(n_43)
);

AOI211xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_22),
.B(n_34),
.C(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_41),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

XOR2xp5_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_45),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_22),
.B1(n_44),
.B2(n_47),
.Y(n_49)
);


endmodule