module fake_netlist_732_1622_n_47 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_47);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_47;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_9),
.B(n_7),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_6),
.B(n_0),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_10),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_6),
.Y(n_24)
);

NAND2x1p5_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_1),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_17),
.B(n_2),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_16),
.B(n_3),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_20),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_SL g31 ( 
.A1(n_29),
.A2(n_19),
.B1(n_23),
.B2(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_27),
.Y(n_33)
);

NAND3xp33_ASAP7_75t_SL g34 ( 
.A(n_31),
.B(n_25),
.C(n_28),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_27),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_28),
.Y(n_40)
);

INVx2_ASAP7_75t_SL g41 ( 
.A(n_38),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_22),
.B1(n_21),
.B2(n_5),
.C(n_11),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_12),
.B1(n_14),
.B2(n_39),
.C(n_37),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

AND4x1_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_41),
.C(n_42),
.D(n_16),
.Y(n_45)
);

INVx3_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

XNOR2xp5_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_44),
.Y(n_47)
);


endmodule