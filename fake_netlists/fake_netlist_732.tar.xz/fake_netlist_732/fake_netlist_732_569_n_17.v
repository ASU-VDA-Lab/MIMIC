module fake_netlist_732_569_n_17 (n_1, n_2, n_3, n_4, n_0, n_17);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_17;

wire n_12;
wire n_15;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_5;
wire n_7;
wire n_13;
wire n_16;
wire n_6;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

NAND2xp33_ASAP7_75t_SL g6 ( 
.A(n_3),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AO31x2_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_1),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_8),
.Y(n_12)
);

O2A1O1Ixp5_ASAP7_75t_SL g13 ( 
.A1(n_11),
.A2(n_10),
.B(n_8),
.C(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVxp33_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

OAI21x1_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_12),
.B(n_15),
.Y(n_17)
);


endmodule