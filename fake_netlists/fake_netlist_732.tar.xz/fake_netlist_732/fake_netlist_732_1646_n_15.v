module fake_netlist_732_1646_n_15 (n_1, n_2, n_3, n_4, n_5, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

INVx8_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_2),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_4),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.C(n_2),
.Y(n_12)
);

NOR3xp33_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_6),
.C(n_4),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_5),
.B(n_11),
.Y(n_15)
);


endmodule