module fake_netlist_732_34_n_15 (n_1, n_2, n_3, n_4, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_8;
wire n_9;
wire n_10;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_11;

INVx3_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_6),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVxp67_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

AOI321xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_6),
.A3(n_10),
.B1(n_9),
.B2(n_8),
.C(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);


endmodule