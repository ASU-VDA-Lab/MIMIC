module fake_netlist_732_1005_n_43 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_43);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_43;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_7),
.B(n_18),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_11),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_2),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_5),
.Y(n_27)
);

A2O1A1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_17),
.B(n_16),
.C(n_5),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_24),
.B1(n_19),
.B2(n_25),
.Y(n_30)
);

OAI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_24),
.B1(n_19),
.B2(n_28),
.Y(n_31)
);

NOR4xp25_ASAP7_75t_SL g32 ( 
.A(n_30),
.B(n_22),
.C(n_17),
.D(n_16),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_18),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_32),
.Y(n_37)
);

OAI21xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_25),
.B(n_0),
.Y(n_38)
);

NAND2xp33_ASAP7_75t_R g39 ( 
.A(n_37),
.B(n_3),
.Y(n_39)
);

XNOR2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_4),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_8),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_40),
.Y(n_42)
);

AOI322xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_9),
.A3(n_10),
.B1(n_14),
.B2(n_40),
.C1(n_37),
.C2(n_41),
.Y(n_43)
);


endmodule