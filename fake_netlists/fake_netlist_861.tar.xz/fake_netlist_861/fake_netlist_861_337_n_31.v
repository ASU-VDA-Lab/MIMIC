module fake_netlist_861_337_n_31 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_31);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_31;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;
wire n_27;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_6),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_6),
.B(n_2),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_0),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_1),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

NAND2x1p5_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_3),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_10),
.B1(n_13),
.B2(n_11),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_13),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_14),
.B(n_4),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_16),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_21),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_25),
.B1(n_15),
.B2(n_19),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_15),
.Y(n_27)
);

OR2x6_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B1(n_7),
.B2(n_5),
.Y(n_31)
);


endmodule