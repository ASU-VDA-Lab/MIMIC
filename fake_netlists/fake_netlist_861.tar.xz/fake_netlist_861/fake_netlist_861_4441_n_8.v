module fake_netlist_861_4441_n_8 (n_2, n_0, n_1, n_8);

input n_2;
input n_0;
input n_1;

output n_8;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;

BUFx3_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI211xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_4),
.B(n_3),
.C(n_2),
.Y(n_6)
);

NOR2x1p5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_2),
.Y(n_7)
);

AO22x2_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_0),
.B1(n_1),
.B2(n_6),
.Y(n_8)
);


endmodule