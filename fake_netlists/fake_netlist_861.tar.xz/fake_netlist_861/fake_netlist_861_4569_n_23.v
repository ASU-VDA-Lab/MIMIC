module fake_netlist_861_4569_n_23 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_23);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_2),
.B(n_0),
.Y(n_16)
);

OAI21x1_ASAP7_75t_SL g17 ( 
.A1(n_15),
.A2(n_7),
.B(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_16),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_14),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_12),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.B1(n_7),
.B2(n_19),
.C(n_9),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_11),
.Y(n_23)
);


endmodule