module fake_netlist_861_1598_n_35 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_35);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_35;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

INVx1_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

INVxp33_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

NOR2xp67_ASAP7_75t_L g16 ( 
.A(n_1),
.B(n_3),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_0),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_1),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_11),
.B(n_4),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_21),
.Y(n_22)
);

AO31x2_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_15),
.A3(n_10),
.B(n_16),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_19),
.A2(n_12),
.B1(n_18),
.B2(n_16),
.Y(n_24)
);

NAND4xp25_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_20),
.C(n_10),
.D(n_17),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_24),
.B(n_17),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_23),
.B(n_14),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_23),
.B(n_14),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_27),
.B(n_20),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_13),
.B1(n_25),
.B2(n_5),
.Y(n_30)
);

NOR4xp75_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_7),
.C(n_6),
.D(n_5),
.Y(n_31)
);

OAI31xp33_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_7),
.A3(n_6),
.B(n_5),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_30),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_32),
.B1(n_9),
.B2(n_8),
.Y(n_35)
);


endmodule