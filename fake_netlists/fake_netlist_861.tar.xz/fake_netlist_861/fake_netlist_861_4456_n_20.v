module fake_netlist_861_4456_n_20 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_20);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

INVx2_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_0),
.C(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

OA21x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_4),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

O2A1O1Ixp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B(n_10),
.C(n_13),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_13),
.B(n_10),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_19)
);

OAI22xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_6),
.B1(n_7),
.B2(n_16),
.Y(n_20)
);


endmodule