module fake_netlist_861_482_n_15 (n_2, n_0, n_1, n_15);

input n_2;
input n_0;
input n_1;

output n_15;

wire n_6;
wire n_10;
wire n_4;
wire n_13;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

AND2x2_ASAP7_75t_SL g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVx1_ASAP7_75t_SL g7 ( 
.A(n_5),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_3),
.B1(n_4),
.B2(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_10),
.B1(n_3),
.B2(n_2),
.C(n_0),
.Y(n_13)
);

OAI22x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_3),
.B1(n_12),
.B2(n_0),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_7),
.C2(n_5),
.Y(n_15)
);


endmodule