module fake_netlist_861_1060_n_14 (n_0, n_1, n_14);

input n_0;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_2;
wire n_13;
wire n_5;
wire n_3;
wire n_11;
wire n_9;
wire n_12;
wire n_8;

INVxp67_ASAP7_75t_SL g2 ( 
.A(n_1),
.Y(n_2)
);

INVx4_ASAP7_75t_SL g3 ( 
.A(n_1),
.Y(n_3)
);

A2O1A1Ixp33_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_0),
.B(n_1),
.C(n_3),
.Y(n_4)
);

BUFx10_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AOI221x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.C(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

A2O1A1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_0),
.B(n_1),
.C(n_4),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_0),
.Y(n_11)
);

OAI211xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_0),
.B(n_9),
.C(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

XNOR2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);


endmodule