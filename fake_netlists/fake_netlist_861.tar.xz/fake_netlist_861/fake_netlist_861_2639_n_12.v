module fake_netlist_861_2639_n_12 (n_2, n_0, n_1, n_12);

input n_2;
input n_0;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_0),
.Y(n_4)
);

OA21x2_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVxp67_ASAP7_75t_SL g7 ( 
.A(n_6),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_2),
.Y(n_8)
);

OAI32xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.A3(n_2),
.B1(n_0),
.B2(n_1),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B1(n_8),
.B2(n_2),
.C(n_0),
.Y(n_10)
);

NAND4xp75_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.C(n_7),
.D(n_1),
.Y(n_11)
);

AOI222xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_6),
.B2(n_3),
.C1(n_7),
.C2(n_0),
.Y(n_12)
);


endmodule