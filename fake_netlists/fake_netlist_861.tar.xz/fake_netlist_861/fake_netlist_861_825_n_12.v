module fake_netlist_861_825_n_12 (n_0, n_1, n_12);

input n_0;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_3;
wire n_11;
wire n_9;
wire n_8;

INVx1_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

INVx2_ASAP7_75t_SL g4 ( 
.A(n_2),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

BUFx2_ASAP7_75t_SL g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_5),
.B1(n_2),
.B2(n_1),
.Y(n_8)
);

OAI21xp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_5),
.B(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_6),
.Y(n_10)
);

INVxp33_ASAP7_75t_SL g11 ( 
.A(n_10),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B1(n_7),
.B2(n_5),
.Y(n_12)
);


endmodule