module fake_netlist_913_2417_n_53 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_53);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_53;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_22;
wire n_35;
wire n_25;
wire n_41;
wire n_21;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_13),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_12),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_14),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_4),
.B(n_19),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_11),
.Y(n_30)
);

AND3x1_ASAP7_75t_SL g31 ( 
.A(n_20),
.B(n_18),
.C(n_17),
.Y(n_31)
);

AO22x1_ASAP7_75t_L g32 ( 
.A1(n_24),
.A2(n_18),
.B1(n_17),
.B2(n_2),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_SL g33 ( 
.A(n_26),
.B(n_6),
.C(n_3),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_24),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_28),
.B1(n_24),
.B2(n_27),
.C(n_23),
.Y(n_37)
);

OAI31xp33_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_31),
.A3(n_29),
.B(n_22),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_25),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_37),
.Y(n_41)
);

INVxp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_38),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

A2O1A1Ixp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_44),
.B(n_42),
.C(n_28),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_21),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

XOR2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_31),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_47),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_45),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_SL g52 ( 
.A1(n_50),
.A2(n_48),
.B1(n_30),
.B2(n_7),
.Y(n_52)
);

OAI221xp5_ASAP7_75t_R g53 ( 
.A1(n_52),
.A2(n_51),
.B1(n_10),
.B2(n_8),
.C(n_9),
.Y(n_53)
);


endmodule