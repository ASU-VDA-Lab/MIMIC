module fake_netlist_913_1389_n_65 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_65);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_65;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_63;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_21;
wire n_22;
wire n_35;
wire n_25;
wire n_41;
wire n_42;
wire n_32;
wire n_57;
wire n_43;
wire n_62;
wire n_44;
wire n_36;
wire n_48;
wire n_45;
wire n_26;
wire n_29;
wire n_38;
wire n_56;

BUFx3_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_3),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

NAND2x1p5_ASAP7_75t_L g26 ( 
.A(n_5),
.B(n_12),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_15),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_10),
.B(n_1),
.Y(n_28)
);

INVx5_ASAP7_75t_L g29 ( 
.A(n_7),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_2),
.B(n_13),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_11),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_13),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_SL g34 ( 
.A(n_27),
.B(n_23),
.C(n_24),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_14),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_30),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_36)
);

BUFx3_ASAP7_75t_L g37 ( 
.A(n_20),
.Y(n_37)
);

AO21x2_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_24),
.B(n_21),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AOI21x1_ASAP7_75t_L g40 ( 
.A1(n_33),
.A2(n_28),
.B(n_30),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_35),
.A2(n_28),
.B1(n_25),
.B2(n_20),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_38),
.B(n_33),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_35),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_42),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_32),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_38),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_45),
.Y(n_51)
);

AOI211xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_36),
.B(n_45),
.C(n_43),
.Y(n_52)
);

OAI222xp33_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_26),
.B1(n_43),
.B2(n_23),
.C1(n_40),
.C2(n_28),
.Y(n_53)
);

NOR2xp33_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_40),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_47),
.B(n_39),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

INVx2_ASAP7_75t_SL g57 ( 
.A(n_53),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_52),
.A2(n_47),
.B1(n_26),
.B2(n_29),
.Y(n_58)
);

AND2x2_ASAP7_75t_SL g59 ( 
.A(n_58),
.B(n_26),
.Y(n_59)
);

AND2x4_ASAP7_75t_L g60 ( 
.A(n_57),
.B(n_55),
.Y(n_60)
);

NOR2x1_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_18),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_56),
.Y(n_62)
);

NAND3xp33_ASAP7_75t_SL g63 ( 
.A(n_62),
.B(n_29),
.C(n_8),
.Y(n_63)
);

AOI21xp5_ASAP7_75t_L g64 ( 
.A1(n_63),
.A2(n_59),
.B(n_60),
.Y(n_64)
);

OAI21xp5_ASAP7_75t_L g65 ( 
.A1(n_64),
.A2(n_61),
.B(n_29),
.Y(n_65)
);


endmodule