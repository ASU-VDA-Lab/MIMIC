module fake_netlist_913_431_n_9 (n_0, n_2, n_3, n_4, n_1, n_9);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_9;

wire n_5;
wire n_8;
wire n_6;
wire n_7;

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_1),
.Y(n_5)
);

AOI21xp5_ASAP7_75t_L g6 ( 
.A1(n_2),
.A2(n_3),
.B(n_0),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_1),
.Y(n_7)
);

OAI211xp5_ASAP7_75t_SL g8 ( 
.A1(n_7),
.A2(n_6),
.B(n_1),
.C(n_0),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_2),
.B1(n_4),
.B2(n_7),
.Y(n_9)
);


endmodule