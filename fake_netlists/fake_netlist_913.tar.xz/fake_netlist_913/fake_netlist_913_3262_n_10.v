module fake_netlist_913_3262_n_10 (n_0, n_1, n_2, n_10);

input n_0;
input n_1;
input n_2;

output n_10;

wire n_5;
wire n_3;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

NAND2x1p5_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

BUFx3_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

AOI222xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_5),
.B1(n_3),
.B2(n_2),
.C1(n_1),
.C2(n_0),
.Y(n_7)
);

NAND4xp25_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.C(n_3),
.D(n_0),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_10)
);


endmodule