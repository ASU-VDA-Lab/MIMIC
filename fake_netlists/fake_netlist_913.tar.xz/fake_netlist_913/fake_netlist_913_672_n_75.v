module fake_netlist_913_672_n_75 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_75);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_75;

wire n_74;
wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_68;
wire n_46;
wire n_63;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_66;
wire n_65;
wire n_71;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_70;
wire n_67;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_25;
wire n_22;
wire n_32;
wire n_35;
wire n_42;
wire n_57;
wire n_41;
wire n_43;
wire n_62;
wire n_44;
wire n_29;
wire n_36;
wire n_26;
wire n_48;
wire n_45;
wire n_69;
wire n_72;
wire n_38;
wire n_73;
wire n_56;

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_15),
.B(n_8),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_12),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_10),
.B(n_2),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_3),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_17),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_0),
.B(n_3),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_18),
.B(n_9),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_4),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_20),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_SL g38 ( 
.A1(n_16),
.A2(n_18),
.B1(n_1),
.B2(n_21),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_23),
.Y(n_39)
);

AOI21xp5_ASAP7_75t_L g40 ( 
.A1(n_25),
.A2(n_13),
.B(n_5),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_29),
.Y(n_41)
);

INVx2_ASAP7_75t_SL g42 ( 
.A(n_33),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_22),
.B(n_2),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_28),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_28),
.Y(n_45)
);

INVxp67_ASAP7_75t_L g46 ( 
.A(n_32),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_33),
.A2(n_20),
.B1(n_17),
.B2(n_16),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_35),
.Y(n_48)
);

BUFx3_ASAP7_75t_L g49 ( 
.A(n_42),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_44),
.Y(n_50)
);

O2A1O1Ixp33_ASAP7_75t_SL g51 ( 
.A1(n_42),
.A2(n_36),
.B(n_30),
.C(n_27),
.Y(n_51)
);

OA21x2_ASAP7_75t_L g52 ( 
.A1(n_39),
.A2(n_35),
.B(n_24),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_44),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_46),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

AOI22xp33_ASAP7_75t_SL g56 ( 
.A1(n_49),
.A2(n_37),
.B1(n_38),
.B2(n_26),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

O2A1O1Ixp33_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_51),
.B(n_43),
.C(n_53),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_54),
.B(n_37),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

O2A1O1Ixp33_ASAP7_75t_SL g61 ( 
.A1(n_58),
.A2(n_55),
.B(n_57),
.C(n_40),
.Y(n_61)
);

OR2x2_ASAP7_75t_L g62 ( 
.A(n_59),
.B(n_54),
.Y(n_62)
);

OAI322xp33_ASAP7_75t_L g63 ( 
.A1(n_58),
.A2(n_48),
.A3(n_45),
.B1(n_41),
.B2(n_39),
.C1(n_34),
.C2(n_31),
.Y(n_63)
);

OAI22xp5_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_49),
.B1(n_47),
.B2(n_52),
.Y(n_64)
);

O2A1O1Ixp33_ASAP7_75t_L g65 ( 
.A1(n_62),
.A2(n_51),
.B(n_41),
.C(n_45),
.Y(n_65)
);

OAI211xp5_ASAP7_75t_L g66 ( 
.A1(n_61),
.A2(n_56),
.B(n_48),
.C(n_34),
.Y(n_66)
);

OAI22xp5_ASAP7_75t_L g67 ( 
.A1(n_64),
.A2(n_52),
.B1(n_49),
.B2(n_63),
.Y(n_67)
);

AOI222xp33_ASAP7_75t_L g68 ( 
.A1(n_64),
.A2(n_33),
.B1(n_49),
.B2(n_52),
.C1(n_59),
.C2(n_38),
.Y(n_68)
);

AND2x2_ASAP7_75t_SL g69 ( 
.A(n_68),
.B(n_52),
.Y(n_69)
);

NOR2x1_ASAP7_75t_L g70 ( 
.A(n_66),
.B(n_52),
.Y(n_70)
);

AND3x4_ASAP7_75t_L g71 ( 
.A(n_65),
.B(n_56),
.C(n_38),
.Y(n_71)
);

INVx3_ASAP7_75t_L g72 ( 
.A(n_69),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_70),
.Y(n_73)
);

OAI22xp5_ASAP7_75t_L g74 ( 
.A1(n_72),
.A2(n_71),
.B1(n_73),
.B2(n_67),
.Y(n_74)
);

AOI21xp5_ASAP7_75t_L g75 ( 
.A1(n_74),
.A2(n_72),
.B(n_73),
.Y(n_75)
);


endmodule