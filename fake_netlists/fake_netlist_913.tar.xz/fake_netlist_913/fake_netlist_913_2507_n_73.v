module fake_netlist_913_2507_n_73 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_73);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_73;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_68;
wire n_46;
wire n_63;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_66;
wire n_19;
wire n_65;
wire n_71;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_70;
wire n_67;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_21;
wire n_32;
wire n_41;
wire n_25;
wire n_22;
wire n_35;
wire n_42;
wire n_57;
wire n_43;
wire n_62;
wire n_26;
wire n_29;
wire n_48;
wire n_36;
wire n_44;
wire n_45;
wire n_69;
wire n_72;
wire n_38;
wire n_56;

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

BUFx8_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

NOR2x1_ASAP7_75t_L g22 ( 
.A(n_0),
.B(n_8),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_1),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_16),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_5),
.B(n_17),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_6),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_12),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_2),
.A2(n_4),
.B1(n_9),
.B2(n_7),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_18),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_23),
.B(n_5),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_21),
.A2(n_3),
.B(n_17),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_19),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_24),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_30),
.Y(n_38)
);

BUFx3_ASAP7_75t_L g39 ( 
.A(n_19),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_29),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_29),
.B(n_27),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_26),
.B(n_18),
.Y(n_42)
);

HB1xp67_ASAP7_75t_L g43 ( 
.A(n_32),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_SL g44 ( 
.A1(n_41),
.A2(n_31),
.B1(n_20),
.B2(n_25),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_39),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_39),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_34),
.A2(n_28),
.B1(n_19),
.B2(n_20),
.C(n_22),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_34),
.Y(n_48)
);

AO31x2_ASAP7_75t_L g49 ( 
.A1(n_37),
.A2(n_19),
.A3(n_33),
.B(n_35),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_41),
.B(n_43),
.Y(n_50)
);

AOI211xp5_ASAP7_75t_SL g51 ( 
.A1(n_50),
.A2(n_42),
.B(n_37),
.C(n_40),
.Y(n_51)
);

BUFx2_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

AOI222xp33_ASAP7_75t_L g53 ( 
.A1(n_47),
.A2(n_36),
.B1(n_38),
.B2(n_40),
.C1(n_44),
.C2(n_45),
.Y(n_53)
);

OR2x6_ASAP7_75t_L g54 ( 
.A(n_46),
.B(n_38),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_38),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_51),
.B(n_49),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

NAND2xp33_ASAP7_75t_SL g59 ( 
.A(n_57),
.B(n_53),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_55),
.Y(n_60)
);

INVx2_ASAP7_75t_SL g61 ( 
.A(n_56),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_58),
.Y(n_62)
);

BUFx2_ASAP7_75t_L g63 ( 
.A(n_60),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_62),
.Y(n_64)
);

NOR2xp33_ASAP7_75t_L g65 ( 
.A(n_61),
.B(n_59),
.Y(n_65)
);

HB1xp67_ASAP7_75t_L g66 ( 
.A(n_59),
.Y(n_66)
);

AOI211x1_ASAP7_75t_L g67 ( 
.A1(n_64),
.A2(n_49),
.B(n_54),
.C(n_36),
.Y(n_67)
);

INVx1_ASAP7_75t_SL g68 ( 
.A(n_63),
.Y(n_68)
);

AND2x4_ASAP7_75t_L g69 ( 
.A(n_63),
.B(n_49),
.Y(n_69)
);

BUFx2_ASAP7_75t_L g70 ( 
.A(n_66),
.Y(n_70)
);

CKINVDCx20_ASAP7_75t_R g71 ( 
.A(n_68),
.Y(n_71)
);

OAI221xp5_ASAP7_75t_L g72 ( 
.A1(n_70),
.A2(n_36),
.B1(n_65),
.B2(n_67),
.C(n_69),
.Y(n_72)
);

NAND3xp33_ASAP7_75t_L g73 ( 
.A(n_72),
.B(n_69),
.C(n_71),
.Y(n_73)
);


endmodule