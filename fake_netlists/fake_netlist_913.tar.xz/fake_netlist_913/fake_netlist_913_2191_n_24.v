module fake_netlist_913_2191_n_24 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_24);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_24;

wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

INVx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_R g9 ( 
.A(n_4),
.B(n_7),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

O2A1O1Ixp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_10),
.B(n_2),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

NOR2x1_ASAP7_75t_SL g16 ( 
.A(n_14),
.B(n_8),
.Y(n_16)
);

AOI21x1_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_8),
.B(n_10),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_12),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_11),
.B1(n_17),
.B2(n_8),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_19),
.B(n_18),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_9),
.B1(n_13),
.B2(n_3),
.Y(n_23)
);

AOI222xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_9),
.B1(n_6),
.B2(n_4),
.C1(n_7),
.C2(n_5),
.Y(n_24)
);


endmodule