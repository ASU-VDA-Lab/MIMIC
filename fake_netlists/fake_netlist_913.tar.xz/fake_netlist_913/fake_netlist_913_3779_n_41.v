module fake_netlist_913_3779_n_41 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_41);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_41;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_40;
wire n_9;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_13;
wire n_21;
wire n_25;
wire n_14;
wire n_22;
wire n_32;
wire n_35;
wire n_26;
wire n_10;
wire n_29;
wire n_36;
wire n_8;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_6),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_0),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_3),
.B(n_7),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_7),
.B(n_0),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_L g17 ( 
.A(n_8),
.B(n_1),
.C(n_0),
.Y(n_17)
);

INVx5_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_12),
.B(n_9),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_12),
.A2(n_14),
.B(n_11),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_12),
.B(n_7),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_12),
.Y(n_24)
);

OR2x6_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_10),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_17),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_19),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_R g29 ( 
.A(n_24),
.B(n_13),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_22),
.B(n_21),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_13),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_26),
.B(n_23),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_7),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_30),
.B(n_18),
.Y(n_34)
);

AOI211xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_29),
.B(n_16),
.C(n_1),
.Y(n_35)
);

AOI222xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_29),
.B1(n_3),
.B2(n_1),
.C1(n_4),
.C2(n_2),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_35),
.A2(n_31),
.B1(n_5),
.B2(n_4),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_SL g39 ( 
.A(n_36),
.B(n_5),
.C(n_4),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_6),
.B1(n_16),
.B2(n_38),
.C1(n_39),
.C2(n_37),
.Y(n_41)
);


endmodule