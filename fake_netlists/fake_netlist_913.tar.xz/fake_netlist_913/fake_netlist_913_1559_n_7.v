module fake_netlist_913_1559_n_7 (n_0, n_2, n_3, n_4, n_1, n_7);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_7;

wire n_5;
wire n_6;

AND2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

OAI211xp5_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_5),
.B(n_1),
.C(n_0),
.Y(n_7)
);


endmodule