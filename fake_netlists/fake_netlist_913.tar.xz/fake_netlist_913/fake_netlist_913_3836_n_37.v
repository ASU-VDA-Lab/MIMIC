module fake_netlist_913_3836_n_37 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_37);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_37;

wire n_33;
wire n_34;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

INVx2_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_8),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_3),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_11),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_SL g25 ( 
.A(n_18),
.B(n_2),
.C(n_1),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_21),
.A2(n_12),
.B(n_7),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_SL g27 ( 
.A1(n_25),
.A2(n_22),
.B1(n_23),
.B2(n_19),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_17),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_27),
.Y(n_29)
);

OAI21xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_26),
.B(n_20),
.Y(n_30)
);

AOI31xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.A3(n_4),
.B(n_3),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_20),
.B1(n_6),
.B2(n_5),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_32),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_10),
.C(n_5),
.Y(n_34)
);

AOI22x1_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_20),
.B1(n_11),
.B2(n_10),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_SL g36 ( 
.A1(n_34),
.A2(n_20),
.B1(n_16),
.B2(n_13),
.Y(n_36)
);

AOI222xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_14),
.B1(n_15),
.B2(n_16),
.C1(n_20),
.C2(n_35),
.Y(n_37)
);


endmodule