module fake_netlist_913_1182_n_15 (n_0, n_1, n_3, n_2, n_15);

input n_0;
input n_1;
input n_3;
input n_2;

output n_15;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

INVx3_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

CKINVDCx11_ASAP7_75t_R g5 ( 
.A(n_2),
.Y(n_5)
);

O2A1O1Ixp33_ASAP7_75t_SL g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_6)
);

OAI22xp33_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.B1(n_5),
.B2(n_1),
.C(n_3),
.Y(n_11)
);

OA22x2_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_9),
.B1(n_4),
.B2(n_3),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_5),
.B(n_9),
.C(n_10),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);


endmodule