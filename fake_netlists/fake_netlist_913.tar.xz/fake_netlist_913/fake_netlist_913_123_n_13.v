module fake_netlist_913_123_n_13 (n_0, n_2, n_5, n_3, n_4, n_1, n_13);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_13;

wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

NOR2xp33_ASAP7_75t_SL g6 ( 
.A(n_2),
.B(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B(n_6),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_0),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_0),
.B1(n_1),
.B2(n_11),
.Y(n_13)
);


endmodule