module fake_netlist_913_1130_n_57 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_57);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_57;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_19;
wire n_27;
wire n_49;
wire n_20;
wire n_21;
wire n_40;
wire n_39;
wire n_18;
wire n_31;
wire n_32;
wire n_25;
wire n_22;
wire n_42;
wire n_41;
wire n_35;
wire n_43;
wire n_26;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_29;
wire n_38;
wire n_56;

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_10),
.B(n_4),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_4),
.B(n_1),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_16),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_7),
.Y(n_22)
);

INVx5_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

OA21x2_ASAP7_75t_L g24 ( 
.A1(n_2),
.A2(n_13),
.B(n_5),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_8),
.B(n_3),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_20),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

INVx2_ASAP7_75t_SL g31 ( 
.A(n_25),
.Y(n_31)
);

OR2x6_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_0),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_5),
.Y(n_33)
);

CKINVDCx11_ASAP7_75t_R g34 ( 
.A(n_32),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_SL g35 ( 
.A(n_32),
.B(n_25),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_30),
.A2(n_18),
.B(n_22),
.Y(n_36)
);

AO31x2_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_27),
.A3(n_20),
.B(n_19),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_32),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_34),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_37),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_35),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_40),
.B(n_35),
.Y(n_47)
);

OAI221xp5_ASAP7_75t_SL g48 ( 
.A1(n_46),
.A2(n_32),
.B1(n_41),
.B2(n_28),
.C(n_31),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_SL g49 ( 
.A1(n_44),
.A2(n_31),
.B(n_27),
.Y(n_49)
);

AOI21xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_45),
.B(n_30),
.Y(n_50)
);

AOI21xp33_ASAP7_75t_L g51 ( 
.A1(n_45),
.A2(n_24),
.B(n_21),
.Y(n_51)
);

OAI221xp5_ASAP7_75t_SL g52 ( 
.A1(n_49),
.A2(n_48),
.B1(n_50),
.B2(n_37),
.C(n_51),
.Y(n_52)
);

NOR2xp67_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_17),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);

NOR4xp25_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_37),
.C(n_24),
.D(n_23),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

AOI322xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_54),
.A3(n_55),
.B1(n_29),
.B2(n_9),
.C1(n_6),
.C2(n_12),
.Y(n_57)
);


endmodule