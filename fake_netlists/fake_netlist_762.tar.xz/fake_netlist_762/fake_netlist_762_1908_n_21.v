module fake_netlist_762_1908_n_21 (n_1, n_2, n_3, n_4, n_0, n_21);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_21;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_0),
.B(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_1),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_9),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

AOI21xp33_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_10),
.B(n_6),
.Y(n_14)
);

NAND4xp25_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.C(n_11),
.D(n_1),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_0),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_16),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_SL g18 ( 
.A(n_15),
.B(n_13),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AO22x1_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.Y(n_20)
);

NAND3xp33_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_2),
.C(n_20),
.Y(n_21)
);


endmodule