module fake_netlist_762_244_n_57 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_57);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_57;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_41;
wire n_19;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVxp67_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_13),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

INVx1_ASAP7_75t_SL g22 ( 
.A(n_11),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_18),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

XOR2xp5_ASAP7_75t_L g28 ( 
.A(n_10),
.B(n_8),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_12),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_8),
.Y(n_30)
);

BUFx4f_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_25),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_23),
.A2(n_18),
.B1(n_17),
.B2(n_9),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_23),
.B(n_17),
.Y(n_34)
);

NAND2xp33_ASAP7_75t_SL g35 ( 
.A(n_20),
.B(n_15),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_22),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_31),
.Y(n_38)
);

OR2x6_ASAP7_75t_L g39 ( 
.A(n_30),
.B(n_24),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

AO21x2_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_34),
.B(n_26),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_38),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_28),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_33),
.B(n_19),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

OAI322xp33_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_45),
.A3(n_22),
.B1(n_21),
.B2(n_27),
.C1(n_35),
.C2(n_42),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_R g50 ( 
.A(n_48),
.B(n_16),
.Y(n_50)
);

OAI21xp33_ASAP7_75t_SL g51 ( 
.A1(n_47),
.A2(n_27),
.B(n_6),
.Y(n_51)
);

XOR2xp5_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_5),
.Y(n_52)
);

XNOR2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_3),
.Y(n_53)
);

CKINVDCx5p33_ASAP7_75t_R g54 ( 
.A(n_51),
.Y(n_54)
);

CKINVDCx5p33_ASAP7_75t_R g55 ( 
.A(n_50),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_53),
.B1(n_55),
.B2(n_52),
.Y(n_57)
);


endmodule