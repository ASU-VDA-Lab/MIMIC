module fake_netlist_762_2434_n_17 (n_1, n_2, n_3, n_4, n_0, n_17);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_17;

wire n_12;
wire n_15;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_5;
wire n_7;
wire n_13;
wire n_16;
wire n_6;
wire n_8;

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

NOR2x1p5_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_3),
.Y(n_6)
);

INVxp67_ASAP7_75t_SL g7 ( 
.A(n_4),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_7),
.B(n_5),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_0),
.B(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_5),
.Y(n_11)
);

NAND5xp2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_7),
.C(n_0),
.D(n_4),
.E(n_2),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_9),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_5),
.B(n_11),
.C(n_0),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

NOR2xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_5),
.Y(n_17)
);


endmodule