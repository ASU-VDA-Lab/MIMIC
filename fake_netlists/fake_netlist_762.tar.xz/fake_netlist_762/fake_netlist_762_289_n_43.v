module fake_netlist_762_289_n_43 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_43);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_43;

wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_41;
wire n_29;
wire n_32;

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_6),
.B(n_5),
.Y(n_24)
);

NOR2xp67_ASAP7_75t_L g25 ( 
.A(n_8),
.B(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_14),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_21),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_15),
.B(n_16),
.C(n_17),
.Y(n_32)
);

O2A1O1Ixp33_ASAP7_75t_SL g33 ( 
.A1(n_26),
.A2(n_18),
.B(n_11),
.C(n_12),
.Y(n_33)
);

INVx3_ASAP7_75t_SL g34 ( 
.A(n_27),
.Y(n_34)
);

CKINVDCx11_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_SL g36 ( 
.A(n_32),
.B(n_24),
.C(n_28),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_31),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

OAI22xp33_ASAP7_75t_SL g39 ( 
.A1(n_37),
.A2(n_29),
.B1(n_38),
.B2(n_33),
.Y(n_39)
);

OAI211xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_25),
.B(n_23),
.C(n_10),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_40),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_1),
.B1(n_7),
.B2(n_0),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_3),
.B1(n_9),
.B2(n_19),
.Y(n_43)
);


endmodule