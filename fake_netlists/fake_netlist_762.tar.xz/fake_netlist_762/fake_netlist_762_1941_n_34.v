module fake_netlist_762_1941_n_34 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_34);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_34;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

INVx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_4),
.B(n_8),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_15),
.B(n_6),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

A2O1A1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_18),
.A2(n_7),
.B(n_10),
.C(n_11),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_22),
.B(n_24),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_28),
.Y(n_29)
);

OAI32xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_20),
.A3(n_21),
.B1(n_19),
.B2(n_23),
.Y(n_30)
);

AOI221xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_23),
.B1(n_7),
.B2(n_17),
.C(n_14),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_9),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_0),
.B1(n_3),
.B2(n_16),
.Y(n_34)
);


endmodule