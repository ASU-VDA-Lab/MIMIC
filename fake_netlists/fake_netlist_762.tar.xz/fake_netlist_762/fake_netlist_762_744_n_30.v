module fake_netlist_762_744_n_30 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_30);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_30;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_14),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_8),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_4),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

AOI21xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_8),
.B(n_16),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_SL g23 ( 
.A1(n_19),
.A2(n_9),
.B(n_7),
.C(n_2),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI322xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_18),
.A3(n_17),
.B1(n_3),
.B2(n_13),
.C1(n_12),
.C2(n_10),
.Y(n_26)
);

NAND3xp33_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_18),
.C(n_23),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_27),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_6),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_1),
.B1(n_5),
.B2(n_11),
.Y(n_30)
);


endmodule