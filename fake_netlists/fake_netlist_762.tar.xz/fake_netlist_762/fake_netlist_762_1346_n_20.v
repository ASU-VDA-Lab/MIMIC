module fake_netlist_762_1346_n_20 (n_1, n_2, n_3, n_4, n_0, n_20);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_20;

wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

OAI22xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_2),
.B(n_1),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_2),
.B1(n_4),
.B2(n_3),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_3),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_2),
.Y(n_11)
);

AO21x2_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_0),
.B(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_11),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_9),
.B1(n_11),
.B2(n_14),
.C(n_12),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.C(n_0),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_12),
.C(n_0),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_4),
.B1(n_12),
.B2(n_18),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);


endmodule