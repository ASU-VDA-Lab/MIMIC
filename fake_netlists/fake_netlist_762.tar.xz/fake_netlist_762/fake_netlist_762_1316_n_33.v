module fake_netlist_762_1316_n_33 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_33);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_33;

wire n_20;
wire n_23;
wire n_22;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_31;
wire n_30;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_4),
.Y(n_19)
);

AO22x2_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_18),
.B1(n_2),
.B2(n_11),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_13),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_7),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_8),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_24),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

XNOR2x1_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_21),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_19),
.B1(n_26),
.B2(n_12),
.C1(n_10),
.C2(n_16),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_1),
.B1(n_5),
.B2(n_0),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_3),
.B1(n_6),
.B2(n_17),
.Y(n_33)
);


endmodule