module fake_netlist_762_542_n_41 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_41);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_41;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_SL g13 ( 
.A(n_2),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_R g14 ( 
.A(n_7),
.B(n_4),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_0),
.A2(n_3),
.B(n_9),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_5),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_10),
.A2(n_3),
.B(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_1),
.Y(n_21)
);

INVx5_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_17),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_18),
.B(n_19),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_21),
.A2(n_13),
.B1(n_19),
.B2(n_14),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_13),
.B1(n_19),
.B2(n_23),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_29),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NAND4xp25_ASAP7_75t_SL g33 ( 
.A(n_31),
.B(n_25),
.C(n_1),
.D(n_0),
.Y(n_33)
);

CKINVDCx16_ASAP7_75t_R g34 ( 
.A(n_32),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_19),
.B1(n_15),
.B2(n_22),
.Y(n_35)
);

XNOR2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_15),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_33),
.A2(n_22),
.B1(n_4),
.B2(n_12),
.Y(n_37)
);

NAND2x1p5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_22),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_36),
.B1(n_40),
.B2(n_11),
.Y(n_41)
);


endmodule