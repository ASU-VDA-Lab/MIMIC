module fake_netlist_762_1928_n_28 (n_1, n_2, n_3, n_4, n_5, n_0, n_28);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_28;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_6;
wire n_9;
wire n_25;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

OAI22xp33_ASAP7_75t_L g8 ( 
.A1(n_0),
.A2(n_2),
.B1(n_3),
.B2(n_5),
.Y(n_8)
);

XNOR2xp5_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_1),
.Y(n_9)
);

AOI21x1_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_1),
.B(n_3),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_2),
.B(n_4),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_6),
.Y(n_12)
);

NAND2xp33_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_7),
.B1(n_6),
.B2(n_9),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_15),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_17),
.B1(n_19),
.B2(n_13),
.Y(n_20)
);

O2A1O1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_13),
.B(n_7),
.C(n_8),
.Y(n_21)
);

OAI21xp33_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_9),
.B(n_8),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_1),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_9),
.B1(n_3),
.B2(n_0),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_21),
.Y(n_25)
);

AOI211x1_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_2),
.B(n_24),
.C(n_23),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_23),
.Y(n_27)
);

OA21x2_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_27),
.B(n_16),
.Y(n_28)
);


endmodule