module fake_netlist_762_2121_n_32 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_32);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_32;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_12),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_3),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_10),
.B(n_11),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_19),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_26),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

AOI211xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_20),
.B(n_17),
.C(n_18),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_14),
.Y(n_30)
);

OAI22x1_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_16),
.B1(n_13),
.B2(n_15),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_7),
.B1(n_2),
.B2(n_5),
.C1(n_0),
.C2(n_1),
.Y(n_32)
);


endmodule