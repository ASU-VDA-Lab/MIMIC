module fake_netlist_762_291_n_61 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_61);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_61;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_47;
wire n_29;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_19),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_15),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_3),
.B(n_8),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_11),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_10),
.B1(n_17),
.B2(n_18),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_18),
.Y(n_33)
);

AOI211xp5_ASAP7_75t_L g34 ( 
.A1(n_25),
.A2(n_28),
.B(n_24),
.C(n_27),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_26),
.B(n_20),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_24),
.B(n_19),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_SL g38 ( 
.A1(n_33),
.A2(n_21),
.B1(n_24),
.B2(n_26),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_24),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_36),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_35),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

OA21x2_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_39),
.B(n_27),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_37),
.B1(n_26),
.B2(n_22),
.Y(n_44)
);

NOR4xp25_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_42),
.C(n_38),
.D(n_30),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_40),
.Y(n_46)
);

NAND2xp33_ASAP7_75t_SL g47 ( 
.A(n_43),
.B(n_23),
.Y(n_47)
);

INVx1_ASAP7_75t_SL g48 ( 
.A(n_47),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_46),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_SL g50 ( 
.A1(n_46),
.A2(n_23),
.B1(n_29),
.B2(n_32),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

BUFx2_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_48),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_L g55 ( 
.A1(n_50),
.A2(n_34),
.B1(n_17),
.B2(n_16),
.Y(n_55)
);

CKINVDCx20_ASAP7_75t_R g56 ( 
.A(n_54),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_53),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_52),
.B(n_1),
.Y(n_58)
);

AND2x4_ASAP7_75t_L g59 ( 
.A(n_58),
.B(n_2),
.Y(n_59)
);

OAI222xp33_ASAP7_75t_L g60 ( 
.A1(n_56),
.A2(n_55),
.B1(n_12),
.B2(n_0),
.C1(n_5),
.C2(n_4),
.Y(n_60)
);

AOI322xp5_ASAP7_75t_L g61 ( 
.A1(n_59),
.A2(n_13),
.A3(n_57),
.B1(n_58),
.B2(n_60),
.C1(n_55),
.C2(n_38),
.Y(n_61)
);


endmodule