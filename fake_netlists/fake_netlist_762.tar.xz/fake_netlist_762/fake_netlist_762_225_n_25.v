module fake_netlist_762_225_n_25 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_25);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_25;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_24;
wire n_10;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;

BUFx2_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_1),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_8),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

INVx4_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_6),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B1(n_11),
.B2(n_12),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_15),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_9),
.B(n_3),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2x1p5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_7),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

XNOR2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_24),
.Y(n_25)
);


endmodule