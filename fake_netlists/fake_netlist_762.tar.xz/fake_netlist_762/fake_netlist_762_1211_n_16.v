module fake_netlist_762_1211_n_16 (n_1, n_2, n_3, n_4, n_0, n_16);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_16;

wire n_12;
wire n_15;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

INVx4_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AO21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_3),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B1(n_3),
.B2(n_2),
.Y(n_8)
);

NAND4xp25_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.C(n_5),
.D(n_1),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVxp67_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AOI21xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_7),
.B(n_5),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_5),
.B1(n_2),
.B2(n_0),
.C(n_4),
.Y(n_13)
);

AOI322xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_0),
.A3(n_2),
.B1(n_5),
.B2(n_8),
.C1(n_10),
.C2(n_6),
.Y(n_14)
);

AO21x1_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_14),
.B(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);


endmodule