module fake_netlist_762_972_n_21 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_21);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_21;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_17;
wire n_15;
wire n_19;

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_0),
.A2(n_11),
.B1(n_12),
.B2(n_1),
.Y(n_13)
);

BUFx3_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_13),
.B1(n_15),
.B2(n_0),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_3),
.Y(n_18)
);

AOI211xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_10),
.B(n_8),
.C(n_7),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_2),
.B1(n_5),
.B2(n_6),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);


endmodule