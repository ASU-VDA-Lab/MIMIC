module fake_netlist_762_597_n_38 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_38);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_38;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

INVx2_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

AND3x1_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_6),
.C(n_5),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

INVxp67_ASAP7_75t_SL g18 ( 
.A(n_13),
.Y(n_18)
);

BUFx12f_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

OAI22xp33_ASAP7_75t_L g20 ( 
.A1(n_12),
.A2(n_17),
.B1(n_13),
.B2(n_16),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_SL g21 ( 
.A(n_12),
.B(n_4),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_15),
.B1(n_3),
.B2(n_0),
.C(n_2),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_7),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_19),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_19),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_1),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_26),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_28),
.Y(n_32)
);

NAND5xp2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_25),
.C(n_19),
.D(n_21),
.E(n_1),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_31),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_34),
.A2(n_25),
.B1(n_32),
.B2(n_3),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_33),
.B1(n_37),
.B2(n_35),
.Y(n_38)
);


endmodule