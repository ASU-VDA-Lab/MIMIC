module fake_netlist_762_650_n_35 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_35);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_35;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_16;
wire n_34;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_9),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_1),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_5),
.B(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_15),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_18),
.C(n_22),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_16),
.B(n_15),
.Y(n_24)
);

CKINVDCx11_ASAP7_75t_R g25 ( 
.A(n_16),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_20),
.B(n_17),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_19),
.B(n_16),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_11),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B1(n_25),
.B2(n_14),
.Y(n_29)
);

O2A1O1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_28),
.B(n_13),
.C(n_14),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_7),
.C(n_13),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

NOR4xp25_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_7),
.C(n_10),
.D(n_8),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_33),
.B1(n_0),
.B2(n_3),
.Y(n_35)
);


endmodule