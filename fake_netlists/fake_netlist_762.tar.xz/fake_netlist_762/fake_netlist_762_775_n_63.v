module fake_netlist_762_775_n_63 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_63);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_63;

wire n_20;
wire n_23;
wire n_46;
wire n_14;
wire n_44;
wire n_61;
wire n_22;
wire n_62;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_12;
wire n_15;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx2_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_3),
.B(n_2),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_16),
.A2(n_1),
.B1(n_0),
.B2(n_10),
.Y(n_23)
);

BUFx4f_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_12),
.B(n_1),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_20),
.B(n_0),
.Y(n_27)
);

NOR2x1p5_ASAP7_75t_L g28 ( 
.A(n_12),
.B(n_0),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_12),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_14),
.Y(n_31)
);

NOR2xp67_ASAP7_75t_SL g32 ( 
.A(n_22),
.B(n_26),
.Y(n_32)
);

INVx8_ASAP7_75t_L g33 ( 
.A(n_26),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_24),
.B1(n_27),
.B2(n_28),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

AOI21xp33_ASAP7_75t_L g36 ( 
.A1(n_24),
.A2(n_18),
.B(n_15),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_23),
.B(n_24),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

AOI31xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_23),
.A3(n_27),
.B(n_15),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_33),
.B(n_22),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_37),
.A2(n_19),
.B1(n_30),
.B2(n_21),
.C(n_17),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_34),
.Y(n_43)
);

AOI322xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_30),
.A3(n_17),
.B1(n_13),
.B2(n_31),
.C1(n_29),
.C2(n_25),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_28),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_33),
.Y(n_46)
);

OAI221xp5_ASAP7_75t_L g47 ( 
.A1(n_39),
.A2(n_13),
.B1(n_24),
.B2(n_22),
.C(n_31),
.Y(n_47)
);

NAND3xp33_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_32),
.C(n_40),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

OAI211xp5_ASAP7_75t_L g50 ( 
.A1(n_44),
.A2(n_31),
.B(n_25),
.C(n_22),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

OAI22xp33_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_47),
.B1(n_46),
.B2(n_9),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_6),
.B1(n_8),
.B2(n_5),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_L g54 ( 
.A1(n_48),
.A2(n_7),
.B1(n_10),
.B2(n_8),
.Y(n_54)
);

HB1xp67_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

AOI332xp33_ASAP7_75t_L g56 ( 
.A1(n_51),
.A2(n_6),
.A3(n_11),
.B1(n_23),
.B2(n_13),
.B3(n_17),
.C1(n_14),
.C2(n_19),
.Y(n_56)
);

AO22x2_ASAP7_75t_L g57 ( 
.A1(n_50),
.A2(n_37),
.B1(n_38),
.B2(n_43),
.Y(n_57)
);

INVx1_ASAP7_75t_SL g58 ( 
.A(n_55),
.Y(n_58)
);

HB1xp67_ASAP7_75t_L g59 ( 
.A(n_57),
.Y(n_59)
);

CKINVDCx20_ASAP7_75t_R g60 ( 
.A(n_53),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_54),
.Y(n_61)
);

HB1xp67_ASAP7_75t_L g62 ( 
.A(n_58),
.Y(n_62)
);

AOI222xp33_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_60),
.B1(n_56),
.B2(n_61),
.C1(n_59),
.C2(n_52),
.Y(n_63)
);


endmodule