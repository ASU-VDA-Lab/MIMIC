module fake_netlist_762_446_n_44 (n_20, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_44);

input n_20;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_44;

wire n_23;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_4),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_17),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_7),
.A2(n_19),
.B1(n_8),
.B2(n_14),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_10),
.B(n_6),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_18),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_15),
.Y(n_30)
);

A2O1A1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_21),
.B(n_11),
.C(n_22),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_13),
.B(n_12),
.Y(n_32)
);

NAND2x1p5_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_28),
.Y(n_33)
);

AOI222xp33_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_25),
.B1(n_29),
.B2(n_30),
.C1(n_24),
.C2(n_21),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_29),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_33),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_35),
.Y(n_37)
);

AOI21xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_25),
.B(n_16),
.Y(n_38)
);

AOI211xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_11),
.B(n_9),
.C(n_20),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_38),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_39),
.Y(n_41)
);

AOI22x1_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_3),
.B1(n_5),
.B2(n_1),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_2),
.B1(n_40),
.B2(n_42),
.Y(n_44)
);


endmodule