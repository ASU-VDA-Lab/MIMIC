module fake_netlist_853_566_n_26 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_26);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;
wire n_11;

BUFx3_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_5),
.B(n_8),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_0),
.B(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_17)
);

CKINVDCx11_ASAP7_75t_R g18 ( 
.A(n_16),
.Y(n_18)
);

AND2x4_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_15),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_12),
.B1(n_15),
.B2(n_14),
.C(n_13),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_20),
.B1(n_15),
.B2(n_14),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_11),
.B(n_13),
.C(n_4),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_11),
.B(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_22),
.B1(n_3),
.B2(n_1),
.Y(n_26)
);


endmodule