module fake_netlist_853_1443_n_16 (n_2, n_0, n_1, n_16);

input n_2;
input n_0;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

NOR2xp33_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

BUFx6f_ASAP7_75t_SL g4 ( 
.A(n_1),
.Y(n_4)
);

BUFx3_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx4_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

BUFx2_ASAP7_75t_SL g7 ( 
.A(n_4),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_5),
.Y(n_8)
);

OAI33xp33_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_4),
.A3(n_5),
.B1(n_3),
.B2(n_2),
.B3(n_0),
.Y(n_9)
);

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_6),
.B(n_2),
.Y(n_11)
);

AOI211x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.C(n_2),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_0),
.B(n_1),
.C(n_9),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_13),
.Y(n_15)
);

XNOR2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_15),
.Y(n_16)
);


endmodule