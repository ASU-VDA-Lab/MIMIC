module fake_netlist_853_2965_n_23 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_23);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;
wire n_11;

INVx2_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_8),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_5),
.B(n_1),
.C(n_4),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_2),
.B(n_0),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_14),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B1(n_17),
.B2(n_15),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_15),
.C(n_12),
.Y(n_20)
);

NOR2x1p5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_6),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_6),
.Y(n_22)
);

OAI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_7),
.B1(n_10),
.B2(n_19),
.Y(n_23)
);


endmodule