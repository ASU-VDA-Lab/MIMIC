module fake_netlist_853_28_n_18 (n_2, n_0, n_3, n_1, n_18);

input n_2;
input n_0;
input n_3;
input n_1;

output n_18;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_17;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

AOI22xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_4)
);

BUFx3_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVxp67_ASAP7_75t_SL g6 ( 
.A(n_1),
.Y(n_6)
);

OAI22xp33_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_3),
.B(n_2),
.Y(n_9)
);

OAI22xp33_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_3),
.B1(n_5),
.B2(n_9),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_8),
.B(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AOI21x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B(n_12),
.Y(n_15)
);

AO22x2_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_12),
.B1(n_10),
.B2(n_11),
.Y(n_16)
);

XOR2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_16),
.B1(n_11),
.B2(n_15),
.Y(n_18)
);


endmodule