module fake_netlist_853_4317_n_32 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_11),
.Y(n_15)
);

AND3x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_0),
.C(n_8),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

OA21x2_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_10),
.B(n_3),
.Y(n_20)
);

INVx2_ASAP7_75t_SL g21 ( 
.A(n_18),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_15),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_17),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B1(n_23),
.B2(n_19),
.C(n_4),
.Y(n_27)
);

INVx3_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI22x1_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_23),
.B1(n_16),
.B2(n_20),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_29),
.A2(n_20),
.B1(n_23),
.B2(n_5),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_1),
.B1(n_6),
.B2(n_7),
.C1(n_16),
.C2(n_30),
.Y(n_32)
);


endmodule