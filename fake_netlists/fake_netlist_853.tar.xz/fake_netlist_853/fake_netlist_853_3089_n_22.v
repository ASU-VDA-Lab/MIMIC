module fake_netlist_853_3089_n_22 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_22);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_2),
.A2(n_10),
.B1(n_8),
.B2(n_7),
.Y(n_14)
);

NOR2x1p5_ASAP7_75t_L g15 ( 
.A(n_1),
.B(n_4),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_3),
.B(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NOR2x1_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.B(n_13),
.C(n_14),
.Y(n_19)
);

NAND2x1p5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_6),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_6),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_7),
.B(n_11),
.Y(n_22)
);


endmodule