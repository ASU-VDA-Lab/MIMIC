module fake_netlist_853_372_n_26 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_26);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_12),
.Y(n_13)
);

BUFx10_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_11),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_3),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_14),
.B(n_4),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_SL g20 ( 
.A(n_18),
.B(n_15),
.C(n_13),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_14),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_17),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B1(n_6),
.B2(n_5),
.Y(n_23)
);

CKINVDCx11_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_7),
.B1(n_2),
.B2(n_1),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_26)
);


endmodule