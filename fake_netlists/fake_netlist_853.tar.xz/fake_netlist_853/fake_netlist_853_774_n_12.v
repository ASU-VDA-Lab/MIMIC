module fake_netlist_853_774_n_12 (n_2, n_0, n_1, n_12);

input n_2;
input n_0;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_8;

NOR2xp33_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_2),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

BUFx10_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_0),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NAND4xp25_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_7),
.C(n_6),
.D(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);

AOI222xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_2),
.B1(n_5),
.B2(n_6),
.C1(n_7),
.C2(n_3),
.Y(n_12)
);


endmodule