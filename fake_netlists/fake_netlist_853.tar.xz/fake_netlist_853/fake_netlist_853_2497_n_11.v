module fake_netlist_853_2497_n_11 (n_0, n_1, n_11);

input n_0;
input n_1;

output n_11;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_3;
wire n_9;
wire n_8;

INVx1_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

AND2x4_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

INVx3_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

BUFx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_SL g7 ( 
.A(n_5),
.B(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NOR4xp25_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_2),
.C(n_4),
.D(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OR2x6_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);


endmodule