module fake_netlist_872_892_n_17 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_17);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_17;

wire n_15;
wire n_11;
wire n_9;
wire n_13;
wire n_16;
wire n_14;
wire n_10;
wire n_12;

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_1),
.B(n_5),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

NOR2x1p5_ASAP7_75t_L g11 ( 
.A(n_4),
.B(n_2),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_9),
.B(n_7),
.C(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_10),
.B1(n_8),
.B2(n_0),
.Y(n_17)
);


endmodule