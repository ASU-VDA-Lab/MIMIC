module fake_netlist_872_797_n_234 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_30, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_17, n_18, n_31, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_26, n_10, n_29, n_8, n_234);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_30;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_17;
input n_18;
input n_31;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_26;
input n_10;
input n_29;
input n_8;

output n_234;

wire n_118;
wire n_100;
wire n_60;
wire n_104;
wire n_216;
wire n_127;
wire n_52;
wire n_99;
wire n_101;
wire n_152;
wire n_151;
wire n_111;
wire n_154;
wire n_185;
wire n_153;
wire n_193;
wire n_164;
wire n_116;
wire n_64;
wire n_102;
wire n_93;
wire n_157;
wire n_66;
wire n_65;
wire n_143;
wire n_88;
wire n_186;
wire n_195;
wire n_169;
wire n_192;
wire n_212;
wire n_197;
wire n_94;
wire n_198;
wire n_182;
wire n_206;
wire n_214;
wire n_91;
wire n_71;
wire n_135;
wire n_174;
wire n_224;
wire n_80;
wire n_229;
wire n_228;
wire n_149;
wire n_201;
wire n_196;
wire n_69;
wire n_83;
wire n_207;
wire n_210;
wire n_134;
wire n_96;
wire n_128;
wire n_117;
wire n_131;
wire n_165;
wire n_190;
wire n_51;
wire n_50;
wire n_217;
wire n_162;
wire n_223;
wire n_55;
wire n_123;
wire n_110;
wire n_46;
wire n_183;
wire n_144;
wire n_54;
wire n_211;
wire n_59;
wire n_227;
wire n_189;
wire n_177;
wire n_173;
wire n_166;
wire n_70;
wire n_40;
wire n_39;
wire n_132;
wire n_225;
wire n_220;
wire n_42;
wire n_32;
wire n_41;
wire n_222;
wire n_126;
wire n_62;
wire n_120;
wire n_141;
wire n_148;
wire n_150;
wire n_226;
wire n_188;
wire n_44;
wire n_79;
wire n_187;
wire n_87;
wire n_142;
wire n_159;
wire n_115;
wire n_155;
wire n_230;
wire n_33;
wire n_184;
wire n_113;
wire n_233;
wire n_200;
wire n_129;
wire n_191;
wire n_209;
wire n_208;
wire n_172;
wire n_77;
wire n_107;
wire n_199;
wire n_95;
wire n_204;
wire n_53;
wire n_161;
wire n_180;
wire n_106;
wire n_137;
wire n_90;
wire n_167;
wire n_146;
wire n_81;
wire n_221;
wire n_84;
wire n_171;
wire n_140;
wire n_61;
wire n_130;
wire n_122;
wire n_43;
wire n_138;
wire n_170;
wire n_136;
wire n_139;
wire n_48;
wire n_72;
wire n_176;
wire n_181;
wire n_133;
wire n_76;
wire n_38;
wire n_56;
wire n_218;
wire n_175;
wire n_213;
wire n_74;
wire n_125;
wire n_34;
wire n_179;
wire n_103;
wire n_37;
wire n_160;
wire n_108;
wire n_75;
wire n_47;
wire n_68;
wire n_158;
wire n_86;
wire n_63;
wire n_163;
wire n_105;
wire n_215;
wire n_114;
wire n_124;
wire n_145;
wire n_85;
wire n_112;
wire n_156;
wire n_205;
wire n_232;
wire n_49;
wire n_58;
wire n_109;
wire n_147;
wire n_168;
wire n_67;
wire n_219;
wire n_202;
wire n_35;
wire n_57;
wire n_121;
wire n_97;
wire n_98;
wire n_231;
wire n_119;
wire n_178;
wire n_203;
wire n_36;
wire n_194;
wire n_45;
wire n_73;
wire n_89;
wire n_92;
wire n_82;
wire n_78;

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_13),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_16),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_10),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_28),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_15),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_6),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_4),
.Y(n_40)
);

BUFx6f_ASAP7_75t_SL g41 ( 
.A(n_22),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_22),
.Y(n_42)
);

INVxp67_ASAP7_75t_SL g43 ( 
.A(n_10),
.Y(n_43)
);

AND2x4_ASAP7_75t_L g44 ( 
.A(n_33),
.B(n_0),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_37),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_SL g46 ( 
.A(n_33),
.B(n_0),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_SL g47 ( 
.A(n_34),
.B(n_1),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_41),
.Y(n_48)
);

CKINVDCx20_ASAP7_75t_R g49 ( 
.A(n_32),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_41),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_SL g51 ( 
.A(n_44),
.B(n_38),
.Y(n_51)
);

NOR2xp33_ASAP7_75t_L g52 ( 
.A(n_45),
.B(n_41),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_49),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_44),
.Y(n_54)
);

AO22x2_ASAP7_75t_L g55 ( 
.A1(n_44),
.A2(n_47),
.B1(n_46),
.B2(n_43),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_44),
.Y(n_56)
);

A2O1A1Ixp33_ASAP7_75t_L g57 ( 
.A1(n_44),
.A2(n_43),
.B(n_35),
.C(n_34),
.Y(n_57)
);

INVxp67_ASAP7_75t_L g58 ( 
.A(n_44),
.Y(n_58)
);

AND2x4_ASAP7_75t_L g59 ( 
.A(n_46),
.B(n_35),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_47),
.Y(n_60)
);

AOI22xp33_ASAP7_75t_L g61 ( 
.A1(n_48),
.A2(n_41),
.B1(n_39),
.B2(n_36),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_48),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_50),
.Y(n_63)
);

INVx2_ASAP7_75t_L g64 ( 
.A(n_50),
.Y(n_64)
);

NAND2xp33_ASAP7_75t_R g65 ( 
.A(n_53),
.B(n_60),
.Y(n_65)
);

OAI22xp5_ASAP7_75t_L g66 ( 
.A1(n_61),
.A2(n_32),
.B1(n_39),
.B2(n_36),
.Y(n_66)
);

CKINVDCx5p33_ASAP7_75t_R g67 ( 
.A(n_61),
.Y(n_67)
);

AOI22xp33_ASAP7_75t_L g68 ( 
.A1(n_59),
.A2(n_41),
.B1(n_40),
.B2(n_38),
.Y(n_68)
);

BUFx6f_ASAP7_75t_L g69 ( 
.A(n_56),
.Y(n_69)
);

AOI22xp5_ASAP7_75t_L g70 ( 
.A1(n_55),
.A2(n_42),
.B1(n_40),
.B2(n_49),
.Y(n_70)
);

OAI22xp5_ASAP7_75t_L g71 ( 
.A1(n_55),
.A2(n_60),
.B1(n_51),
.B2(n_58),
.Y(n_71)
);

OAI22xp5_ASAP7_75t_L g72 ( 
.A1(n_55),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_72)
);

O2A1O1Ixp33_ASAP7_75t_L g73 ( 
.A1(n_57),
.A2(n_4),
.B(n_3),
.C(n_2),
.Y(n_73)
);

OAI21xp33_ASAP7_75t_L g74 ( 
.A1(n_55),
.A2(n_6),
.B(n_5),
.Y(n_74)
);

AOI21xp5_ASAP7_75t_L g75 ( 
.A1(n_51),
.A2(n_7),
.B(n_5),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_64),
.B(n_7),
.Y(n_76)
);

NAND2xp5_ASAP7_75t_L g77 ( 
.A(n_64),
.B(n_8),
.Y(n_77)
);

NOR3xp33_ASAP7_75t_SL g78 ( 
.A(n_57),
.B(n_9),
.C(n_8),
.Y(n_78)
);

NAND2xp5_ASAP7_75t_L g79 ( 
.A(n_64),
.B(n_60),
.Y(n_79)
);

AOI21xp5_ASAP7_75t_L g80 ( 
.A1(n_58),
.A2(n_11),
.B(n_9),
.Y(n_80)
);

OAI21xp5_ASAP7_75t_L g81 ( 
.A1(n_71),
.A2(n_56),
.B(n_54),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_69),
.Y(n_82)
);

OAI21xp5_ASAP7_75t_L g83 ( 
.A1(n_79),
.A2(n_56),
.B(n_54),
.Y(n_83)
);

OAI21x1_ASAP7_75t_L g84 ( 
.A1(n_73),
.A2(n_64),
.B(n_62),
.Y(n_84)
);

AO21x2_ASAP7_75t_L g85 ( 
.A1(n_74),
.A2(n_59),
.B(n_52),
.Y(n_85)
);

OAI22xp33_ASAP7_75t_L g86 ( 
.A1(n_70),
.A2(n_59),
.B1(n_55),
.B2(n_62),
.Y(n_86)
);

NOR2xp33_ASAP7_75t_L g87 ( 
.A(n_67),
.B(n_69),
.Y(n_87)
);

OAI22xp5_ASAP7_75t_L g88 ( 
.A1(n_70),
.A2(n_55),
.B1(n_59),
.B2(n_63),
.Y(n_88)
);

OAI22xp5_ASAP7_75t_L g89 ( 
.A1(n_67),
.A2(n_55),
.B1(n_59),
.B2(n_63),
.Y(n_89)
);

AOI21xp5_ASAP7_75t_R g90 ( 
.A1(n_66),
.A2(n_59),
.B(n_12),
.Y(n_90)
);

OAI21x1_ASAP7_75t_L g91 ( 
.A1(n_80),
.A2(n_63),
.B(n_52),
.Y(n_91)
);

OA21x2_ASAP7_75t_L g92 ( 
.A1(n_75),
.A2(n_13),
.B(n_12),
.Y(n_92)
);

AOI22xp5_ASAP7_75t_L g93 ( 
.A1(n_74),
.A2(n_17),
.B1(n_16),
.B2(n_14),
.Y(n_93)
);

AND2x2_ASAP7_75t_L g94 ( 
.A(n_87),
.B(n_69),
.Y(n_94)
);

BUFx12f_ASAP7_75t_L g95 ( 
.A(n_90),
.Y(n_95)
);

INVx2_ASAP7_75t_L g96 ( 
.A(n_82),
.Y(n_96)
);

NOR3xp33_ASAP7_75t_SL g97 ( 
.A(n_86),
.B(n_72),
.C(n_66),
.Y(n_97)
);

NOR3xp33_ASAP7_75t_SL g98 ( 
.A(n_86),
.B(n_65),
.C(n_77),
.Y(n_98)
);

AND2x2_ASAP7_75t_L g99 ( 
.A(n_87),
.B(n_69),
.Y(n_99)
);

CKINVDCx16_ASAP7_75t_R g100 ( 
.A(n_88),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_82),
.Y(n_101)
);

NAND2xp5_ASAP7_75t_L g102 ( 
.A(n_99),
.B(n_88),
.Y(n_102)
);

AOI21xp5_ASAP7_75t_L g103 ( 
.A1(n_99),
.A2(n_81),
.B(n_83),
.Y(n_103)
);

OAI221xp5_ASAP7_75t_L g104 ( 
.A1(n_97),
.A2(n_93),
.B1(n_89),
.B2(n_81),
.C(n_68),
.Y(n_104)
);

INVx2_ASAP7_75t_L g105 ( 
.A(n_96),
.Y(n_105)
);

INVxp67_ASAP7_75t_L g106 ( 
.A(n_94),
.Y(n_106)
);

A2O1A1Ixp33_ASAP7_75t_L g107 ( 
.A1(n_98),
.A2(n_89),
.B(n_93),
.C(n_84),
.Y(n_107)
);

NAND3xp33_ASAP7_75t_L g108 ( 
.A(n_97),
.B(n_78),
.C(n_93),
.Y(n_108)
);

INVx2_ASAP7_75t_L g109 ( 
.A(n_96),
.Y(n_109)
);

OR2x2_ASAP7_75t_L g110 ( 
.A(n_100),
.B(n_85),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_106),
.B(n_94),
.Y(n_111)
);

OR2x2_ASAP7_75t_L g112 ( 
.A(n_110),
.B(n_100),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_105),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_105),
.Y(n_114)
);

INVx2_ASAP7_75t_L g115 ( 
.A(n_109),
.Y(n_115)
);

INVx2_ASAP7_75t_L g116 ( 
.A(n_109),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_107),
.Y(n_117)
);

NAND2xp5_ASAP7_75t_L g118 ( 
.A(n_103),
.B(n_94),
.Y(n_118)
);

INVx3_ASAP7_75t_L g119 ( 
.A(n_110),
.Y(n_119)
);

INVx1_ASAP7_75t_L g120 ( 
.A(n_102),
.Y(n_120)
);

AND2x4_ASAP7_75t_L g121 ( 
.A(n_108),
.B(n_94),
.Y(n_121)
);

AND2x2_ASAP7_75t_L g122 ( 
.A(n_108),
.B(n_100),
.Y(n_122)
);

NAND2xp33_ASAP7_75t_R g123 ( 
.A(n_104),
.B(n_97),
.Y(n_123)
);

AND2x2_ASAP7_75t_L g124 ( 
.A(n_107),
.B(n_100),
.Y(n_124)
);

INVx2_ASAP7_75t_L g125 ( 
.A(n_115),
.Y(n_125)
);

OR2x2_ASAP7_75t_L g126 ( 
.A(n_119),
.B(n_99),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_113),
.Y(n_127)
);

AOI22xp5_ASAP7_75t_L g128 ( 
.A1(n_123),
.A2(n_95),
.B1(n_98),
.B2(n_94),
.Y(n_128)
);

OR2x2_ASAP7_75t_L g129 ( 
.A(n_119),
.B(n_85),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_113),
.Y(n_130)
);

OR2x2_ASAP7_75t_L g131 ( 
.A(n_119),
.B(n_85),
.Y(n_131)
);

BUFx2_ASAP7_75t_L g132 ( 
.A(n_121),
.Y(n_132)
);

NOR2xp33_ASAP7_75t_L g133 ( 
.A(n_120),
.B(n_95),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_113),
.Y(n_134)
);

OR2x2_ASAP7_75t_L g135 ( 
.A(n_119),
.B(n_112),
.Y(n_135)
);

AND2x2_ASAP7_75t_L g136 ( 
.A(n_122),
.B(n_98),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_114),
.Y(n_137)
);

AND2x2_ASAP7_75t_L g138 ( 
.A(n_122),
.B(n_121),
.Y(n_138)
);

INVx2_ASAP7_75t_SL g139 ( 
.A(n_114),
.Y(n_139)
);

AOI22xp5_ASAP7_75t_L g140 ( 
.A1(n_123),
.A2(n_95),
.B1(n_85),
.B2(n_90),
.Y(n_140)
);

NAND2xp5_ASAP7_75t_L g141 ( 
.A(n_120),
.B(n_95),
.Y(n_141)
);

INVx2_ASAP7_75t_SL g142 ( 
.A(n_114),
.Y(n_142)
);

AO21x2_ASAP7_75t_L g143 ( 
.A1(n_118),
.A2(n_91),
.B(n_83),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_127),
.Y(n_144)
);

INVx1_ASAP7_75t_SL g145 ( 
.A(n_126),
.Y(n_145)
);

O2A1O1Ixp33_ASAP7_75t_L g146 ( 
.A1(n_133),
.A2(n_141),
.B(n_117),
.C(n_122),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_127),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_130),
.Y(n_148)
);

OAI322xp33_ASAP7_75t_L g149 ( 
.A1(n_140),
.A2(n_117),
.A3(n_118),
.B1(n_124),
.B2(n_111),
.C1(n_76),
.C2(n_101),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_130),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_134),
.Y(n_151)
);

OAI32xp33_ASAP7_75t_L g152 ( 
.A1(n_136),
.A2(n_124),
.A3(n_111),
.B1(n_101),
.B2(n_112),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_134),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_137),
.Y(n_154)
);

NAND2xp5_ASAP7_75t_L g155 ( 
.A(n_128),
.B(n_121),
.Y(n_155)
);

NAND2xp5_ASAP7_75t_SL g156 ( 
.A(n_128),
.B(n_121),
.Y(n_156)
);

OAI31xp33_ASAP7_75t_SL g157 ( 
.A1(n_138),
.A2(n_84),
.A3(n_91),
.B(n_101),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_137),
.Y(n_158)
);

OAI211xp5_ASAP7_75t_L g159 ( 
.A1(n_139),
.A2(n_92),
.B(n_91),
.C(n_84),
.Y(n_159)
);

AND2x2_ASAP7_75t_L g160 ( 
.A(n_138),
.B(n_115),
.Y(n_160)
);

OR2x2_ASAP7_75t_L g161 ( 
.A(n_135),
.B(n_115),
.Y(n_161)
);

NOR3xp33_ASAP7_75t_L g162 ( 
.A(n_139),
.B(n_91),
.C(n_84),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_142),
.Y(n_163)
);

NAND2x1_ASAP7_75t_L g164 ( 
.A(n_142),
.B(n_115),
.Y(n_164)
);

INVx1_ASAP7_75t_L g165 ( 
.A(n_135),
.Y(n_165)
);

OR2x2_ASAP7_75t_L g166 ( 
.A(n_132),
.B(n_116),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_SL g167 ( 
.A(n_129),
.B(n_131),
.Y(n_167)
);

OR2x2_ASAP7_75t_L g168 ( 
.A(n_165),
.B(n_132),
.Y(n_168)
);

INVx1_ASAP7_75t_L g169 ( 
.A(n_148),
.Y(n_169)
);

OR2x2_ASAP7_75t_L g170 ( 
.A(n_167),
.B(n_129),
.Y(n_170)
);

NAND2xp5_ASAP7_75t_L g171 ( 
.A(n_145),
.B(n_125),
.Y(n_171)
);

INVxp67_ASAP7_75t_L g172 ( 
.A(n_160),
.Y(n_172)
);

INVxp67_ASAP7_75t_SL g173 ( 
.A(n_164),
.Y(n_173)
);

INVx2_ASAP7_75t_SL g174 ( 
.A(n_148),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_158),
.Y(n_175)
);

NAND2xp5_ASAP7_75t_L g176 ( 
.A(n_160),
.B(n_146),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_158),
.Y(n_177)
);

AND2x2_ASAP7_75t_L g178 ( 
.A(n_144),
.B(n_143),
.Y(n_178)
);

NAND2xp5_ASAP7_75t_L g179 ( 
.A(n_161),
.B(n_147),
.Y(n_179)
);

NOR2xp33_ASAP7_75t_L g180 ( 
.A(n_149),
.B(n_18),
.Y(n_180)
);

NAND2x1_ASAP7_75t_SL g181 ( 
.A(n_163),
.B(n_125),
.Y(n_181)
);

NOR2xp33_ASAP7_75t_L g182 ( 
.A(n_161),
.B(n_18),
.Y(n_182)
);

AND2x2_ASAP7_75t_L g183 ( 
.A(n_150),
.B(n_143),
.Y(n_183)
);

NOR2xp33_ASAP7_75t_SL g184 ( 
.A(n_152),
.B(n_125),
.Y(n_184)
);

NOR2xp33_ASAP7_75t_L g185 ( 
.A(n_155),
.B(n_19),
.Y(n_185)
);

NOR2x1_ASAP7_75t_L g186 ( 
.A(n_164),
.B(n_143),
.Y(n_186)
);

NOR2xp33_ASAP7_75t_L g187 ( 
.A(n_156),
.B(n_19),
.Y(n_187)
);

BUFx2_ASAP7_75t_L g188 ( 
.A(n_151),
.Y(n_188)
);

NAND2xp5_ASAP7_75t_L g189 ( 
.A(n_153),
.B(n_116),
.Y(n_189)
);

INVx1_ASAP7_75t_L g190 ( 
.A(n_154),
.Y(n_190)
);

INVx2_ASAP7_75t_L g191 ( 
.A(n_166),
.Y(n_191)
);

INVx1_ASAP7_75t_L g192 ( 
.A(n_166),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_156),
.Y(n_193)
);

INVxp67_ASAP7_75t_SL g194 ( 
.A(n_162),
.Y(n_194)
);

AND2x2_ASAP7_75t_L g195 ( 
.A(n_157),
.B(n_116),
.Y(n_195)
);

NAND2xp5_ASAP7_75t_L g196 ( 
.A(n_176),
.B(n_152),
.Y(n_196)
);

AOI22xp5_ASAP7_75t_L g197 ( 
.A1(n_187),
.A2(n_92),
.B1(n_159),
.B2(n_96),
.Y(n_197)
);

OAI211xp5_ASAP7_75t_L g198 ( 
.A1(n_185),
.A2(n_92),
.B(n_96),
.C(n_20),
.Y(n_198)
);

NAND3xp33_ASAP7_75t_L g199 ( 
.A(n_182),
.B(n_92),
.C(n_69),
.Y(n_199)
);

OAI21xp5_ASAP7_75t_L g200 ( 
.A1(n_194),
.A2(n_24),
.B(n_23),
.Y(n_200)
);

NAND2xp5_ASAP7_75t_L g201 ( 
.A(n_192),
.B(n_190),
.Y(n_201)
);

NAND4xp75_ASAP7_75t_L g202 ( 
.A(n_193),
.B(n_195),
.C(n_186),
.D(n_178),
.Y(n_202)
);

AOI221xp5_ASAP7_75t_L g203 ( 
.A1(n_193),
.A2(n_26),
.B1(n_25),
.B2(n_27),
.C(n_28),
.Y(n_203)
);

OAI21xp5_ASAP7_75t_L g204 ( 
.A1(n_195),
.A2(n_26),
.B(n_25),
.Y(n_204)
);

OAI22xp33_ASAP7_75t_L g205 ( 
.A1(n_184),
.A2(n_31),
.B1(n_30),
.B2(n_29),
.Y(n_205)
);

AOI221xp5_ASAP7_75t_L g206 ( 
.A1(n_178),
.A2(n_29),
.B1(n_30),
.B2(n_31),
.C(n_183),
.Y(n_206)
);

AOI211x1_ASAP7_75t_SL g207 ( 
.A1(n_179),
.A2(n_189),
.B(n_171),
.C(n_191),
.Y(n_207)
);

AOI221xp5_ASAP7_75t_L g208 ( 
.A1(n_183),
.A2(n_188),
.B1(n_190),
.B2(n_169),
.C(n_175),
.Y(n_208)
);

NOR3xp33_ASAP7_75t_L g209 ( 
.A(n_186),
.B(n_173),
.C(n_188),
.Y(n_209)
);

OAI221xp5_ASAP7_75t_L g210 ( 
.A1(n_181),
.A2(n_170),
.B1(n_174),
.B2(n_189),
.C(n_169),
.Y(n_210)
);

OAI211xp5_ASAP7_75t_L g211 ( 
.A1(n_181),
.A2(n_177),
.B(n_175),
.C(n_174),
.Y(n_211)
);

OAI21xp5_ASAP7_75t_L g212 ( 
.A1(n_177),
.A2(n_168),
.B(n_172),
.Y(n_212)
);

NAND3x1_ASAP7_75t_L g213 ( 
.A(n_209),
.B(n_196),
.C(n_200),
.Y(n_213)
);

INVx1_ASAP7_75t_L g214 ( 
.A(n_201),
.Y(n_214)
);

INVx2_ASAP7_75t_L g215 ( 
.A(n_210),
.Y(n_215)
);

NAND2xp5_ASAP7_75t_L g216 ( 
.A(n_207),
.B(n_208),
.Y(n_216)
);

INVx1_ASAP7_75t_L g217 ( 
.A(n_211),
.Y(n_217)
);

NOR2x1p5_ASAP7_75t_L g218 ( 
.A(n_202),
.B(n_199),
.Y(n_218)
);

NOR3xp33_ASAP7_75t_L g219 ( 
.A(n_205),
.B(n_198),
.C(n_209),
.Y(n_219)
);

NAND2xp5_ASAP7_75t_L g220 ( 
.A(n_212),
.B(n_197),
.Y(n_220)
);

AOI222xp33_ASAP7_75t_L g221 ( 
.A1(n_205),
.A2(n_206),
.B1(n_180),
.B2(n_200),
.C1(n_204),
.C2(n_203),
.Y(n_221)
);

NAND2xp33_ASAP7_75t_R g222 ( 
.A(n_217),
.B(n_220),
.Y(n_222)
);

BUFx2_ASAP7_75t_L g223 ( 
.A(n_217),
.Y(n_223)
);

BUFx2_ASAP7_75t_L g224 ( 
.A(n_214),
.Y(n_224)
);

INVx1_ASAP7_75t_SL g225 ( 
.A(n_216),
.Y(n_225)
);

HB1xp67_ASAP7_75t_L g226 ( 
.A(n_224),
.Y(n_226)
);

INVx1_ASAP7_75t_L g227 ( 
.A(n_224),
.Y(n_227)
);

AND3x4_ASAP7_75t_L g228 ( 
.A(n_222),
.B(n_219),
.C(n_215),
.Y(n_228)
);

HB1xp67_ASAP7_75t_L g229 ( 
.A(n_223),
.Y(n_229)
);

CKINVDCx20_ASAP7_75t_R g230 ( 
.A(n_229),
.Y(n_230)
);

OAI22xp5_ASAP7_75t_L g231 ( 
.A1(n_228),
.A2(n_213),
.B1(n_225),
.B2(n_223),
.Y(n_231)
);

AOI22xp33_ASAP7_75t_L g232 ( 
.A1(n_231),
.A2(n_225),
.B1(n_218),
.B2(n_215),
.Y(n_232)
);

AOI22xp33_ASAP7_75t_L g233 ( 
.A1(n_232),
.A2(n_230),
.B1(n_221),
.B2(n_227),
.Y(n_233)
);

AOI21xp33_ASAP7_75t_SL g234 ( 
.A1(n_233),
.A2(n_222),
.B(n_226),
.Y(n_234)
);


endmodule