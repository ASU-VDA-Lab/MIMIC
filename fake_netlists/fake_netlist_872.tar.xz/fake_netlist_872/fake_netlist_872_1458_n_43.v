module fake_netlist_872_1458_n_43 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_43);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_43;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_41;
wire n_42;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

INVx1_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

INVxp33_ASAP7_75t_SL g23 ( 
.A(n_15),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_22),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_19),
.B(n_4),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_17),
.A2(n_7),
.B1(n_2),
.B2(n_1),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_24),
.B(n_18),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_26),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

AO21x2_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_27),
.B(n_21),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_30),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_35),
.B(n_32),
.Y(n_37)
);

OA211x2_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_17),
.B(n_33),
.C(n_23),
.Y(n_38)
);

AOI21xp33_ASAP7_75t_SL g39 ( 
.A1(n_37),
.A2(n_9),
.B(n_3),
.Y(n_39)
);

NOR5xp2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_19),
.C(n_36),
.D(n_10),
.E(n_11),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_36),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

AOI322xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_12),
.A3(n_13),
.B1(n_19),
.B2(n_40),
.C1(n_16),
.C2(n_18),
.Y(n_43)
);


endmodule