module fake_netlist_872_1390_n_34 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_34);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_34;

wire n_33;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_31;
wire n_21;
wire n_25;
wire n_22;
wire n_32;
wire n_26;
wire n_29;

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_6),
.B(n_4),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_13),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

A2O1A1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_16),
.B(n_15),
.C(n_1),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_17),
.B1(n_16),
.B2(n_1),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_26),
.B(n_21),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_25),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_22),
.C(n_20),
.Y(n_29)
);

AND4x1_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_19),
.C(n_18),
.D(n_17),
.Y(n_30)
);

XOR2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_18),
.Y(n_31)
);

OAI22x1_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_24),
.B1(n_20),
.B2(n_0),
.Y(n_32)
);

AO22x1_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_7),
.B1(n_5),
.B2(n_3),
.Y(n_33)
);

AOI222xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_33),
.B1(n_11),
.B2(n_9),
.C1(n_14),
.C2(n_10),
.Y(n_34)
);


endmodule