module fake_netlist_872_472_n_14 (n_0, n_1, n_2, n_14);

input n_0;
input n_1;
input n_2;

output n_14;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

INVx2_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_2),
.B(n_0),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_6),
.Y(n_9)
);

AOI211xp5_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_8),
.B(n_7),
.C(n_0),
.Y(n_10)
);

OAI311xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_1),
.A3(n_2),
.B1(n_5),
.C1(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

OAI22x1_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_1),
.B1(n_2),
.B2(n_10),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_1),
.B1(n_2),
.B2(n_11),
.C1(n_12),
.C2(n_8),
.Y(n_14)
);


endmodule