module fake_netlist_872_1168_n_9 (n_0, n_1, n_2, n_9);

input n_0;
input n_1;
input n_2;

output n_9;

wire n_5;
wire n_3;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

AOI21xp5_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

NOR4xp25_ASAP7_75t_SL g6 ( 
.A(n_3),
.B(n_0),
.C(n_4),
.D(n_5),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);


endmodule