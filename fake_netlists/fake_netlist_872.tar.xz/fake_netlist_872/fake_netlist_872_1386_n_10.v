module fake_netlist_872_1386_n_10 (n_0, n_1, n_10);

input n_0;
input n_1;

output n_10;

wire n_2;
wire n_5;
wire n_3;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

NOR2x1p5_ASAP7_75t_L g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

A2O1A1Ixp33_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_0),
.B(n_1),
.C(n_3),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

OAI211xp5_ASAP7_75t_SL g8 ( 
.A1(n_7),
.A2(n_0),
.B(n_1),
.C(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule