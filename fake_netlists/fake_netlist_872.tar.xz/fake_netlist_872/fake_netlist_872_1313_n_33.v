module fake_netlist_872_1313_n_33 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_33);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_33;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_32;
wire n_26;
wire n_29;

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_4),
.B(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_1),
.B(n_3),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_6),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_15),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AOI31xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.A3(n_13),
.B(n_11),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_22),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_11),
.B1(n_13),
.B2(n_14),
.C(n_7),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_7),
.Y(n_26)
);

NOR2x1_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_14),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_14),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_SL g30 ( 
.A(n_29),
.B(n_14),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

XOR2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_0),
.Y(n_32)
);

AOI22x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_30),
.B1(n_9),
.B2(n_2),
.Y(n_33)
);


endmodule