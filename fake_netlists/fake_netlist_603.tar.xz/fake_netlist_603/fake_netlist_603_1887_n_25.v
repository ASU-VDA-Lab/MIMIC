module fake_netlist_603_1887_n_25 (n_5, n_0, n_4, n_1, n_2, n_3, n_25);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_25;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_7;
wire n_9;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_6;
wire n_12;

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_0),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_0),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_6),
.Y(n_14)
);

OAI21xp33_ASAP7_75t_L g15 ( 
.A1(n_10),
.A2(n_8),
.B(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

A2O1A1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_15),
.B(n_12),
.C(n_14),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_13),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_14),
.Y(n_19)
);

AOI222xp33_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_11),
.B1(n_14),
.B2(n_15),
.C1(n_17),
.C2(n_1),
.Y(n_20)
);

AOI211xp5_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_14),
.B(n_4),
.C(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

OA22x2_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_5),
.B1(n_23),
.B2(n_22),
.Y(n_25)
);


endmodule