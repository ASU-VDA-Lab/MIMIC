module fake_netlist_603_348_n_18 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_18);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_18;

wire n_11;
wire n_15;
wire n_10;
wire n_16;
wire n_14;
wire n_17;
wire n_13;
wire n_12;

INVx1_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

NAND2x1p5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_5),
.Y(n_12)
);

OA21x2_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_12),
.B1(n_11),
.B2(n_4),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_7),
.B2(n_4),
.C(n_6),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_18)
);


endmodule