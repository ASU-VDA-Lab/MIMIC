module fake_netlist_603_49_n_21 (n_7, n_9, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_21);

input n_7;
input n_9;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_21;

wire n_11;
wire n_15;
wire n_18;
wire n_17;
wire n_19;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_13),
.C(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_SL g19 ( 
.A(n_18),
.Y(n_19)
);

OAI22x1_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_R g21 ( 
.A1(n_20),
.A2(n_7),
.B1(n_6),
.B2(n_8),
.C(n_10),
.Y(n_21)
);


endmodule