module fake_netlist_603_89_n_43 (n_11, n_8, n_15, n_3, n_21, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_43);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_43;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_38;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_11),
.B(n_10),
.Y(n_22)
);

INVx8_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

BUFx10_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

NOR2xp67_ASAP7_75t_L g25 ( 
.A(n_12),
.B(n_2),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_3),
.B(n_1),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_19),
.B1(n_18),
.B2(n_16),
.Y(n_31)
);

OAI22x1_ASAP7_75t_L g32 ( 
.A1(n_26),
.A2(n_19),
.B1(n_18),
.B2(n_4),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_28),
.C(n_27),
.Y(n_33)
);

INVxp33_ASAP7_75t_SL g34 ( 
.A(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVxp67_ASAP7_75t_SL g36 ( 
.A(n_35),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_34),
.B1(n_23),
.B2(n_30),
.C(n_22),
.Y(n_37)
);

O2A1O1Ixp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_25),
.B(n_24),
.C(n_7),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_38),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

OA22x2_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_24),
.B1(n_9),
.B2(n_8),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_SL g42 ( 
.A1(n_40),
.A2(n_14),
.B(n_13),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_15),
.B1(n_17),
.B2(n_42),
.Y(n_43)
);


endmodule