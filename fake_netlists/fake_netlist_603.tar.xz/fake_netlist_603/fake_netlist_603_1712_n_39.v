module fake_netlist_603_1712_n_39 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_39);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_39;

wire n_31;
wire n_37;
wire n_30;
wire n_36;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_38;
wire n_32;
wire n_23;
wire n_33;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

CKINVDCx6p67_ASAP7_75t_R g24 ( 
.A(n_5),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_SL g25 ( 
.A(n_15),
.B(n_11),
.Y(n_25)
);

AND3x2_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_18),
.C(n_13),
.Y(n_26)
);

INVx2_ASAP7_75t_SL g27 ( 
.A(n_19),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_8),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_18),
.B1(n_1),
.B2(n_0),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_25),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_R g33 ( 
.A(n_31),
.B(n_23),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_29),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_32),
.B1(n_27),
.B2(n_28),
.Y(n_35)
);

AOI322xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_26),
.A3(n_10),
.B1(n_9),
.B2(n_6),
.C1(n_16),
.C2(n_12),
.Y(n_36)
);

INVxp67_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

OAI31xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_22),
.A3(n_21),
.B(n_17),
.Y(n_39)
);


endmodule