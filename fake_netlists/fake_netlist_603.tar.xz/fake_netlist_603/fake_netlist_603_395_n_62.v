module fake_netlist_603_395_n_62 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_62);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_62;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_58;
wire n_52;
wire n_24;
wire n_51;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_60;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_18),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_16),
.B(n_4),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_2),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_16),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_7),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_17),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_3),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_25),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_25),
.B(n_17),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_29),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_SL g35 ( 
.A(n_27),
.B(n_19),
.C(n_18),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_24),
.B1(n_21),
.B2(n_22),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_30),
.Y(n_38)
);

AND2x6_ASAP7_75t_L g39 ( 
.A(n_33),
.B(n_28),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

XNOR2xp5_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_34),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

OAI322xp33_ASAP7_75t_L g44 ( 
.A1(n_38),
.A2(n_34),
.A3(n_30),
.B1(n_35),
.B2(n_23),
.C1(n_26),
.C2(n_28),
.Y(n_44)
);

NOR2x1_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_30),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_39),
.Y(n_47)
);

OAI211xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_30),
.B(n_42),
.C(n_19),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_0),
.Y(n_49)
);

INVxp67_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

NOR2xp33_ASAP7_75t_R g51 ( 
.A(n_46),
.B(n_1),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_51),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_9),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_49),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_53),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

CKINVDCx5p33_ASAP7_75t_R g59 ( 
.A(n_53),
.Y(n_59)
);

CKINVDCx20_ASAP7_75t_R g60 ( 
.A(n_59),
.Y(n_60)
);

AOI22xp33_ASAP7_75t_L g61 ( 
.A1(n_56),
.A2(n_55),
.B1(n_12),
.B2(n_10),
.Y(n_61)
);

AOI222xp33_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_58),
.B1(n_57),
.B2(n_60),
.C1(n_15),
.C2(n_13),
.Y(n_62)
);


endmodule