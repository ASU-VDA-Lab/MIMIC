module fake_netlist_603_751_n_50 (n_7, n_9, n_11, n_8, n_5, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_50);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_50;

wire n_31;
wire n_15;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_42;
wire n_33;
wire n_41;

XNOR2xp5_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_8),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_1),
.B(n_6),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_0),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

OR2x4_ASAP7_75t_L g24 ( 
.A(n_16),
.B(n_2),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_2),
.Y(n_25)
);

INVx4_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_18),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_20),
.B1(n_15),
.B2(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_23),
.B1(n_26),
.B2(n_25),
.C(n_15),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_28),
.B(n_26),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_24),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

INVxp67_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

XOR2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_32),
.Y(n_39)
);

NOR2xp67_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_34),
.Y(n_40)
);

OAI32xp33_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_35),
.A3(n_34),
.B1(n_19),
.B2(n_29),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_37),
.B1(n_35),
.B2(n_19),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

AOI322xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_4),
.A3(n_3),
.B1(n_5),
.B2(n_7),
.C1(n_6),
.C2(n_27),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_27),
.Y(n_45)
);

NAND4xp75_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_29),
.C(n_4),
.D(n_3),
.Y(n_46)
);

XNOR2xp5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_5),
.Y(n_47)
);

XOR2xp5_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_9),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

AOI322xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_10),
.A3(n_11),
.B1(n_44),
.B2(n_45),
.C1(n_49),
.C2(n_48),
.Y(n_50)
);


endmodule