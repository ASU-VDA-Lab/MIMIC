module fake_netlist_603_1970_n_31 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_31);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_31;

wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_3),
.B(n_7),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_9),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

INVxp33_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_8),
.B(n_11),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_4),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_SL g24 ( 
.A(n_18),
.B(n_6),
.C(n_4),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_21),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_25),
.B(n_18),
.Y(n_26)
);

AOI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B1(n_17),
.B2(n_19),
.C1(n_16),
.C2(n_6),
.Y(n_27)
);

OAI21xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_22),
.B(n_0),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_16),
.B1(n_2),
.B2(n_1),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_14),
.B1(n_10),
.B2(n_5),
.Y(n_31)
);


endmodule