module fake_netlist_603_1587_n_51 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_51);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_51;

wire n_31;
wire n_15;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_50;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_42;
wire n_33;
wire n_14;
wire n_41;
wire n_13;
wire n_12;

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_4),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_7),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_13),
.B(n_0),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_20),
.B(n_1),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

INVx4_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_SL g28 ( 
.A1(n_25),
.A2(n_20),
.B1(n_19),
.B2(n_12),
.Y(n_28)
);

AO21x2_ASAP7_75t_L g29 ( 
.A1(n_25),
.A2(n_15),
.B(n_14),
.Y(n_29)
);

AO21x2_ASAP7_75t_L g30 ( 
.A1(n_23),
.A2(n_18),
.B(n_2),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_18),
.B1(n_5),
.B2(n_4),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_27),
.B(n_6),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_L g33 ( 
.A(n_28),
.B(n_22),
.C(n_21),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_27),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_30),
.A2(n_29),
.B1(n_31),
.B2(n_32),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_29),
.B(n_27),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_30),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

BUFx3_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_33),
.B(n_30),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_21),
.B1(n_26),
.B2(n_24),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

AOI21xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_40),
.B(n_37),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_39),
.B(n_37),
.Y(n_46)
);

XOR2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_39),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_46),
.Y(n_48)
);

CKINVDCx20_ASAP7_75t_R g49 ( 
.A(n_44),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

AOI322xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_11),
.A3(n_47),
.B1(n_49),
.B2(n_40),
.C1(n_14),
.C2(n_12),
.Y(n_51)
);


endmodule