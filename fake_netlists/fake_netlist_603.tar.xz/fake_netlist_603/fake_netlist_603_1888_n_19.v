module fake_netlist_603_1888_n_19 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_19);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_19;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

AND2x4_ASAP7_75t_L g8 ( 
.A(n_4),
.B(n_2),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_3),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

AO31x2_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_3),
.A3(n_2),
.B(n_1),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_10),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_8),
.Y(n_15)
);

OAI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B(n_8),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI31xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_8),
.A3(n_15),
.B(n_10),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.B1(n_11),
.B2(n_6),
.Y(n_19)
);


endmodule