module fake_netlist_603_648_n_38 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_38);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_38;

wire n_31;
wire n_37;
wire n_21;
wire n_30;
wire n_36;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_32;
wire n_23;
wire n_33;
wire n_34;

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_10),
.B(n_19),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_1),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_7),
.B(n_17),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_11),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_5),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_13),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_13),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_22),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_27),
.B1(n_26),
.B2(n_21),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_23),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_23),
.Y(n_33)
);

NOR5xp2_ASAP7_75t_SL g34 ( 
.A(n_33),
.B(n_30),
.C(n_16),
.D(n_14),
.E(n_15),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_32),
.B1(n_31),
.B2(n_14),
.C(n_15),
.Y(n_35)
);

XNOR2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_18),
.Y(n_36)
);

AO221x2_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_3),
.B1(n_2),
.B2(n_4),
.C(n_6),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_12),
.B1(n_9),
.B2(n_8),
.Y(n_38)
);


endmodule