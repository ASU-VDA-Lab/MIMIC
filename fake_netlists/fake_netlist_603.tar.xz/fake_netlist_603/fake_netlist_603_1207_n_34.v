module fake_netlist_603_1207_n_34 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_34);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_34;

wire n_31;
wire n_21;
wire n_30;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

INVx2_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

AOI21x1_ASAP7_75t_L g21 ( 
.A1(n_5),
.A2(n_0),
.B(n_13),
.Y(n_21)
);

OA21x2_ASAP7_75t_L g22 ( 
.A1(n_8),
.A2(n_2),
.B(n_11),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_10),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_7),
.B(n_3),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_25),
.B1(n_23),
.B2(n_21),
.C(n_22),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_12),
.B1(n_9),
.B2(n_14),
.C1(n_16),
.C2(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_33),
.B1(n_18),
.B2(n_17),
.Y(n_34)
);


endmodule