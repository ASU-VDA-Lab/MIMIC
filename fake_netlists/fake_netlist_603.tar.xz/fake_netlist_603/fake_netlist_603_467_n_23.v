module fake_netlist_603_467_n_23 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_23);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_23;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_19;
wire n_20;
wire n_16;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_7),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_8),
.B(n_0),
.Y(n_15)
);

INVx8_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_6),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_13),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_14),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_15),
.C(n_6),
.Y(n_20)
);

OR3x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_2),
.C(n_1),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_9),
.B1(n_5),
.B2(n_3),
.Y(n_22)
);

OAI21xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_12),
.B(n_11),
.Y(n_23)
);


endmodule