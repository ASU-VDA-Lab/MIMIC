module fake_netlist_603_589_n_75 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_25, n_26, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_75);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_25;
input n_26;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_75;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_61;
wire n_29;
wire n_58;
wire n_27;
wire n_28;
wire n_62;
wire n_70;
wire n_67;
wire n_52;
wire n_51;
wire n_49;
wire n_65;
wire n_48;
wire n_35;
wire n_45;
wire n_69;
wire n_63;
wire n_60;
wire n_46;
wire n_38;
wire n_73;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_74;
wire n_71;
wire n_66;
wire n_32;
wire n_42;
wire n_33;
wire n_72;
wire n_41;
wire n_55;
wire n_64;
wire n_34;
wire n_68;

INVx2_ASAP7_75t_L g27 ( 
.A(n_8),
.Y(n_27)
);

AND2x6_ASAP7_75t_L g28 ( 
.A(n_14),
.B(n_13),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_10),
.B(n_9),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_23),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_19),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_12),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_21),
.Y(n_33)
);

INVx6_ASAP7_75t_L g34 ( 
.A(n_17),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_15),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_4),
.Y(n_37)
);

NAND2xp33_ASAP7_75t_L g38 ( 
.A(n_20),
.B(n_0),
.Y(n_38)
);

INVx3_ASAP7_75t_L g39 ( 
.A(n_22),
.Y(n_39)
);

INVx3_ASAP7_75t_L g40 ( 
.A(n_11),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_16),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_22),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_L g43 ( 
.A(n_34),
.B(n_23),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_L g45 ( 
.A(n_34),
.B(n_24),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_33),
.B(n_25),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_33),
.B(n_25),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_40),
.B(n_26),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_R g49 ( 
.A(n_42),
.B(n_31),
.Y(n_49)
);

OA21x2_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_35),
.B(n_27),
.Y(n_50)
);

OAI21x1_ASAP7_75t_L g51 ( 
.A1(n_44),
.A2(n_40),
.B(n_29),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_L g52 ( 
.A1(n_46),
.A2(n_30),
.B1(n_39),
.B2(n_36),
.Y(n_52)
);

O2A1O1Ixp33_ASAP7_75t_SL g53 ( 
.A1(n_47),
.A2(n_40),
.B(n_32),
.C(n_27),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

INVxp67_ASAP7_75t_SL g55 ( 
.A(n_50),
.Y(n_55)
);

OR2x2_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_30),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_50),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_56),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_57),
.Y(n_59)
);

NAND2x1_ASAP7_75t_SL g60 ( 
.A(n_54),
.B(n_30),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_55),
.B(n_52),
.Y(n_61)
);

AND2x4_ASAP7_75t_SL g62 ( 
.A(n_58),
.B(n_43),
.Y(n_62)
);

AND2x4_ASAP7_75t_L g63 ( 
.A(n_61),
.B(n_55),
.Y(n_63)
);

AOI22xp5_ASAP7_75t_L g64 ( 
.A1(n_61),
.A2(n_53),
.B1(n_43),
.B2(n_45),
.Y(n_64)
);

AOI22xp33_ASAP7_75t_L g65 ( 
.A1(n_59),
.A2(n_49),
.B1(n_38),
.B2(n_28),
.Y(n_65)
);

OAI22xp5_ASAP7_75t_L g66 ( 
.A1(n_63),
.A2(n_59),
.B1(n_64),
.B2(n_65),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_62),
.Y(n_67)
);

AOI221xp5_ASAP7_75t_L g68 ( 
.A1(n_62),
.A2(n_37),
.B1(n_35),
.B2(n_41),
.C(n_60),
.Y(n_68)
);

OAI22xp5_ASAP7_75t_L g69 ( 
.A1(n_66),
.A2(n_37),
.B1(n_26),
.B2(n_28),
.Y(n_69)
);

AOI21xp5_ASAP7_75t_L g70 ( 
.A1(n_68),
.A2(n_28),
.B(n_1),
.Y(n_70)
);

NAND2x1p5_ASAP7_75t_L g71 ( 
.A(n_67),
.B(n_2),
.Y(n_71)
);

HB1xp67_ASAP7_75t_L g72 ( 
.A(n_71),
.Y(n_72)
);

AOI221xp5_ASAP7_75t_L g73 ( 
.A1(n_69),
.A2(n_5),
.B1(n_3),
.B2(n_6),
.C(n_7),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_72),
.Y(n_74)
);

AOI22xp5_ASAP7_75t_SL g75 ( 
.A1(n_74),
.A2(n_70),
.B1(n_73),
.B2(n_18),
.Y(n_75)
);


endmodule