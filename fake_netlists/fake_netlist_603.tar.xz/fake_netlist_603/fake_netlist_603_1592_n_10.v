module fake_netlist_603_1592_n_10 (n_1, n_2, n_0, n_10);

input n_1;
input n_2;
input n_0;

output n_10;

wire n_7;
wire n_9;
wire n_8;
wire n_5;
wire n_6;
wire n_4;
wire n_3;

AO21x2_ASAP7_75t_L g3 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_3)
);

INVx4_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

OAI21xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_3),
.B(n_4),
.Y(n_7)
);

O2A1O1Ixp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_3),
.B(n_1),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_9),
.B(n_0),
.Y(n_10)
);


endmodule