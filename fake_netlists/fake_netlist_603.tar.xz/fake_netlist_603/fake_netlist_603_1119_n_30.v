module fake_netlist_603_1119_n_30 (n_7, n_9, n_11, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_30);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_30;

wire n_21;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;

INVx1_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_7),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_10),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_2),
.Y(n_19)
);

NOR2xp67_ASAP7_75t_L g20 ( 
.A(n_11),
.B(n_8),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_21),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_17),
.A2(n_1),
.B(n_0),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_19),
.B1(n_18),
.B2(n_20),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

OAI211xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AND2x4_ASAP7_75t_SL g29 ( 
.A(n_28),
.B(n_6),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_30)
);


endmodule