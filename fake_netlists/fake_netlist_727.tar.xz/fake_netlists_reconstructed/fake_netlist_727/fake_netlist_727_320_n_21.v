module fake_netlist_727_320_n_21 (n_1, n_2, n_6, n_0, n_3, n_4, n_5, n_21);

input n_1;
input n_2;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_21;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_7;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_8;
wire n_10;
wire n_15;
wire n_16;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_6),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_0),
.Y(n_10)
);

AO32x2_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_1),
.A3(n_3),
.B1(n_0),
.B2(n_2),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_1),
.Y(n_12)
);

AND2x4_ASAP7_75t_SL g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_2),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_7),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B1(n_8),
.B2(n_10),
.C(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_14),
.B1(n_10),
.B2(n_4),
.Y(n_19)
);

AOI22x1_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_14),
.B1(n_5),
.B2(n_4),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_5),
.B1(n_18),
.B2(n_20),
.Y(n_21)
);


endmodule