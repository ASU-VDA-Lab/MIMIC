module fake_netlist_727_3360_n_18 (n_1, n_2, n_0, n_3, n_4, n_18);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_18;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_15;
wire n_16;
wire n_6;
wire n_14;
wire n_17;
wire n_5;

NOR2xp33_ASAP7_75t_SL g5 ( 
.A(n_1),
.B(n_4),
.Y(n_5)
);

BUFx10_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

AOI21x1_ASAP7_75t_SL g11 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

O2A1O1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_7),
.B(n_12),
.C(n_11),
.Y(n_15)
);

NOR2xp67_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_6),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);


endmodule