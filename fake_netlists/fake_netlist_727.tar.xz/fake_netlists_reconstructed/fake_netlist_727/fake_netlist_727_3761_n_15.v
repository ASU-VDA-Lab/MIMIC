module fake_netlist_727_3761_n_15 (n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_15);

input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_15;

wire n_12;
wire n_8;
wire n_13;
wire n_10;
wire n_9;
wire n_14;
wire n_11;

INVx2_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_0),
.B1(n_3),
.B2(n_5),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_1),
.B(n_2),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_12),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

NAND5xp2_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_6),
.C(n_9),
.D(n_10),
.E(n_8),
.Y(n_15)
);


endmodule