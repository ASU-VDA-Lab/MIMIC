module fake_netlist_727_2795_n_25 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_25);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_25;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_2),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

OA33x2_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_12),
.A3(n_7),
.B1(n_6),
.B2(n_14),
.B3(n_15),
.Y(n_20)
);

NOR4xp75_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_12),
.C(n_6),
.D(n_15),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI322xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_13),
.A3(n_15),
.B1(n_18),
.B2(n_8),
.C1(n_4),
.C2(n_9),
.Y(n_25)
);


endmodule