module fake_netlist_727_1068_n_19 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_19);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_19;

wire n_14;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_10;
wire n_15;
wire n_16;

NAND3xp33_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_6),
.C(n_2),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

AOI21x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_9),
.B(n_0),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_4),
.C(n_1),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_5),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_8),
.Y(n_19)
);


endmodule