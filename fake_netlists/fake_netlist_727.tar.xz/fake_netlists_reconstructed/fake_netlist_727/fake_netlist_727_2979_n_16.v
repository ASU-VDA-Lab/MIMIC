module fake_netlist_727_2979_n_16 (n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_16);

input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_16;

wire n_12;
wire n_8;
wire n_10;
wire n_15;
wire n_14;
wire n_13;
wire n_9;
wire n_11;

NAND2x1p5_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_7),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_5),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_11)
);

OAI221xp5_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_10),
.B1(n_8),
.B2(n_9),
.C(n_0),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_9),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_8),
.C(n_1),
.Y(n_14)
);

OA22x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B(n_7),
.Y(n_16)
);


endmodule