module fake_netlist_727_3525_n_17 (n_1, n_2, n_6, n_0, n_3, n_4, n_5, n_17);

input n_1;
input n_2;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_17;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_15;
wire n_16;
wire n_14;

INVx2_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

OAI221xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_6),
.B1(n_1),
.B2(n_0),
.C(n_2),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B1(n_7),
.B2(n_1),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B(n_0),
.Y(n_14)
);

NOR4xp25_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.C(n_6),
.D(n_3),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_4),
.B(n_3),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_5),
.B2(n_14),
.Y(n_17)
);


endmodule