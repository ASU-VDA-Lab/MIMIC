module fake_netlist_727_2771_n_21 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_21);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_21;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_10;
wire n_15;
wire n_16;
wire n_19;

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

AND3x1_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_7),
.C(n_0),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_5),
.B(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_4),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_11),
.B1(n_13),
.B2(n_15),
.Y(n_18)
);

NAND3x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_7),
.C(n_1),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_3),
.Y(n_20)
);

NOR2xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_17),
.Y(n_21)
);


endmodule