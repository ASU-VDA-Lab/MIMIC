module fake_netlist_727_3546_n_20 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_20);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_20;

wire n_14;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_10;
wire n_15;
wire n_16;
wire n_19;

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_5),
.B(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_2),
.A2(n_6),
.B1(n_0),
.B2(n_4),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_4),
.B(n_1),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_11),
.Y(n_16)
);

A2O1A1O1Ixp25_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B(n_10),
.C(n_15),
.D(n_1),
.Y(n_17)
);

NOR2x1_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_9),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_17),
.B1(n_7),
.B2(n_6),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_7),
.Y(n_20)
);


endmodule