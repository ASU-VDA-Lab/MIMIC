module fake_netlist_752_3853_n_89 (n_20, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_89);

input n_20;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_89;

wire n_77;
wire n_71;
wire n_80;
wire n_62;
wire n_36;
wire n_81;
wire n_68;
wire n_73;
wire n_24;
wire n_60;
wire n_53;
wire n_57;
wire n_41;
wire n_84;
wire n_86;
wire n_55;
wire n_23;
wire n_46;
wire n_64;
wire n_82;
wire n_76;
wire n_72;
wire n_51;
wire n_78;
wire n_75;
wire n_42;
wire n_85;
wire n_33;
wire n_70;
wire n_63;
wire n_25;
wire n_69;
wire n_56;
wire n_52;
wire n_61;
wire n_45;
wire n_28;
wire n_65;
wire n_87;
wire n_50;
wire n_79;
wire n_35;
wire n_43;
wire n_58;
wire n_74;
wire n_44;
wire n_66;
wire n_34;
wire n_39;
wire n_48;
wire n_49;
wire n_37;
wire n_59;
wire n_27;
wire n_26;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_67;
wire n_29;
wire n_47;
wire n_88;
wire n_54;
wire n_32;
wire n_83;

INVx1_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_1),
.B(n_18),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

OA21x2_ASAP7_75t_L g27 ( 
.A1(n_4),
.A2(n_8),
.B(n_0),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_3),
.B(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

BUFx3_ASAP7_75t_L g30 ( 
.A(n_6),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_7),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_3),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_17),
.B(n_13),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_18),
.A2(n_16),
.B(n_19),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_15),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_16),
.B(n_19),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_32),
.B(n_26),
.Y(n_39)
);

A2O1A1Ixp33_ASAP7_75t_L g40 ( 
.A1(n_34),
.A2(n_11),
.B(n_10),
.C(n_9),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_30),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_32),
.B(n_12),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_L g43 ( 
.A(n_26),
.B(n_12),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_24),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_24),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_23),
.B(n_13),
.Y(n_46)
);

OAI21x1_ASAP7_75t_L g47 ( 
.A1(n_37),
.A2(n_31),
.B(n_23),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_L g48 ( 
.A(n_39),
.B(n_30),
.Y(n_48)
);

AO31x2_ASAP7_75t_L g49 ( 
.A1(n_40),
.A2(n_24),
.A3(n_29),
.B(n_33),
.Y(n_49)
);

A2O1A1Ixp33_ASAP7_75t_L g50 ( 
.A1(n_44),
.A2(n_34),
.B(n_30),
.C(n_24),
.Y(n_50)
);

OAI21x1_ASAP7_75t_SL g51 ( 
.A1(n_38),
.A2(n_25),
.B(n_36),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_L g52 ( 
.A1(n_39),
.A2(n_29),
.B1(n_36),
.B2(n_28),
.Y(n_52)
);

A2O1A1Ixp33_ASAP7_75t_L g53 ( 
.A1(n_44),
.A2(n_34),
.B(n_31),
.C(n_23),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_47),
.Y(n_54)
);

AO21x2_ASAP7_75t_L g55 ( 
.A1(n_50),
.A2(n_25),
.B(n_31),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_49),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_49),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_48),
.Y(n_58)
);

AO21x2_ASAP7_75t_L g59 ( 
.A1(n_53),
.A2(n_35),
.B(n_42),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_54),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_58),
.B(n_42),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_54),
.Y(n_62)
);

HB1xp67_ASAP7_75t_L g63 ( 
.A(n_56),
.Y(n_63)
);

OR2x2_ASAP7_75t_L g64 ( 
.A(n_56),
.B(n_52),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_63),
.Y(n_65)
);

AND2x2_ASAP7_75t_L g66 ( 
.A(n_61),
.B(n_57),
.Y(n_66)
);

NAND2xp5_ASAP7_75t_L g67 ( 
.A(n_61),
.B(n_48),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_63),
.B(n_57),
.Y(n_68)
);

AOI22xp5_ASAP7_75t_L g69 ( 
.A1(n_64),
.A2(n_43),
.B1(n_59),
.B2(n_55),
.Y(n_69)
);

OAI322xp33_ASAP7_75t_L g70 ( 
.A1(n_67),
.A2(n_33),
.A3(n_46),
.B1(n_64),
.B2(n_35),
.C1(n_28),
.C2(n_45),
.Y(n_70)
);

O2A1O1Ixp5_ASAP7_75t_L g71 ( 
.A1(n_65),
.A2(n_62),
.B(n_60),
.C(n_37),
.Y(n_71)
);

AOI221xp5_ASAP7_75t_L g72 ( 
.A1(n_66),
.A2(n_51),
.B1(n_28),
.B2(n_59),
.C(n_55),
.Y(n_72)
);

INVx2_ASAP7_75t_L g73 ( 
.A(n_65),
.Y(n_73)
);

OAI22xp5_ASAP7_75t_L g74 ( 
.A1(n_68),
.A2(n_62),
.B1(n_60),
.B2(n_35),
.Y(n_74)
);

OAI22xp33_ASAP7_75t_L g75 ( 
.A1(n_69),
.A2(n_27),
.B1(n_41),
.B2(n_49),
.Y(n_75)
);

NAND3xp33_ASAP7_75t_L g76 ( 
.A(n_72),
.B(n_73),
.C(n_27),
.Y(n_76)
);

AOI22xp5_ASAP7_75t_L g77 ( 
.A1(n_74),
.A2(n_66),
.B1(n_68),
.B2(n_59),
.Y(n_77)
);

A2O1A1Ixp33_ASAP7_75t_L g78 ( 
.A1(n_71),
.A2(n_41),
.B(n_49),
.C(n_27),
.Y(n_78)
);

NAND3xp33_ASAP7_75t_L g79 ( 
.A(n_75),
.B(n_27),
.C(n_14),
.Y(n_79)
);

AOI21xp5_ASAP7_75t_L g80 ( 
.A1(n_70),
.A2(n_27),
.B(n_14),
.Y(n_80)
);

NOR2xp33_ASAP7_75t_L g81 ( 
.A(n_70),
.B(n_17),
.Y(n_81)
);

NAND4xp75_ASAP7_75t_L g82 ( 
.A(n_81),
.B(n_27),
.C(n_21),
.D(n_20),
.Y(n_82)
);

AND2x4_ASAP7_75t_L g83 ( 
.A(n_77),
.B(n_22),
.Y(n_83)
);

AND2x4_ASAP7_75t_L g84 ( 
.A(n_79),
.B(n_22),
.Y(n_84)
);

NOR2xp33_ASAP7_75t_L g85 ( 
.A(n_80),
.B(n_76),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_83),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_83),
.Y(n_87)
);

AOI222xp33_ASAP7_75t_L g88 ( 
.A1(n_86),
.A2(n_78),
.B1(n_82),
.B2(n_84),
.C1(n_85),
.C2(n_87),
.Y(n_88)
);

OA21x2_ASAP7_75t_L g89 ( 
.A1(n_88),
.A2(n_87),
.B(n_84),
.Y(n_89)
);


endmodule