module fake_netlist_752_200_n_38 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_38);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_38;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_13;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

XNOR2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

INVx6_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_0),
.B(n_8),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_4),
.B(n_5),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_6),
.B(n_7),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVx2_ASAP7_75t_SL g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_16),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_SL g24 ( 
.A1(n_21),
.A2(n_12),
.B(n_20),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_25),
.B1(n_24),
.B2(n_15),
.C(n_19),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_25),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_19),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_18),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_18),
.Y(n_33)
);

AND2x2_ASAP7_75t_SL g34 ( 
.A(n_29),
.B(n_0),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_4),
.B1(n_3),
.B2(n_1),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_33),
.B1(n_32),
.B2(n_1),
.Y(n_37)
);

OAI221xp5_ASAP7_75t_R g38 ( 
.A1(n_37),
.A2(n_6),
.B1(n_5),
.B2(n_3),
.C(n_35),
.Y(n_38)
);


endmodule