module fake_netlist_752_1086_n_59 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_59);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_59;

wire n_46;
wire n_44;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_27;
wire n_42;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_4),
.B(n_13),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_9),
.B(n_23),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_L g29 ( 
.A(n_18),
.B(n_6),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_8),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_22),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_16),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_10),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_23),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_R g38 ( 
.A(n_32),
.B(n_0),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_26),
.Y(n_39)
);

O2A1O1Ixp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_37),
.B(n_36),
.C(n_28),
.Y(n_40)
);

A2O1A1Ixp33_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_30),
.B(n_27),
.C(n_29),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_34),
.Y(n_43)
);

INVx3_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_41),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

BUFx3_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

AOI21xp5_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_25),
.B(n_31),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_SL g53 ( 
.A(n_52),
.B(n_24),
.C(n_31),
.Y(n_53)
);

OAI211xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_50),
.B(n_2),
.C(n_1),
.Y(n_54)
);

AOI22xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_7),
.B1(n_5),
.B2(n_3),
.Y(n_55)
);

HB1xp67_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_11),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_56),
.Y(n_58)
);

AOI322xp5_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_57),
.A3(n_55),
.B1(n_19),
.B2(n_21),
.C1(n_12),
.C2(n_15),
.Y(n_59)
);


endmodule