module fake_netlist_752_635_n_56 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_25, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_56);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_56;

wire n_46;
wire n_44;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_42;
wire n_37;
wire n_27;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_43;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx2_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_0),
.B(n_24),
.Y(n_27)
);

INVx6_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_10),
.A2(n_13),
.B1(n_25),
.B2(n_18),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_7),
.A2(n_6),
.B1(n_14),
.B2(n_15),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_3),
.A2(n_12),
.B1(n_8),
.B2(n_17),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_18),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

NOR2xp67_ASAP7_75t_L g36 ( 
.A(n_11),
.B(n_19),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_31),
.B(n_19),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_30),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_26),
.B(n_22),
.Y(n_40)
);

OAI21x1_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_29),
.B(n_32),
.Y(n_41)
);

BUFx3_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_38),
.A2(n_32),
.B(n_36),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_39),
.C(n_37),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_41),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_41),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_43),
.B1(n_27),
.B2(n_33),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_43),
.B1(n_27),
.B2(n_34),
.Y(n_49)
);

O2A1O1Ixp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_36),
.B(n_28),
.C(n_35),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_35),
.B1(n_23),
.B2(n_22),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_51),
.B(n_23),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_9),
.B1(n_4),
.B2(n_2),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_53),
.Y(n_54)
);

AOI21xp33_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_21),
.B(n_16),
.Y(n_55)
);

INVxp67_ASAP7_75t_L g56 ( 
.A(n_55),
.Y(n_56)
);


endmodule