module fake_netlist_752_3890_n_38 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_38);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_38;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_1),
.B(n_16),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_2),
.B(n_16),
.Y(n_20)
);

NOR2xp67_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_4),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_5),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_15),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_15),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

OAI22xp33_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_21),
.B1(n_19),
.B2(n_17),
.Y(n_28)
);

NAND4xp25_ASAP7_75t_SL g29 ( 
.A(n_28),
.B(n_26),
.C(n_25),
.D(n_20),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_26),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_25),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_27),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_25),
.B(n_27),
.C(n_22),
.Y(n_34)
);

NAND2x1p5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_22),
.Y(n_35)
);

OAI322xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_6),
.A3(n_0),
.B1(n_9),
.B2(n_10),
.C1(n_7),
.C2(n_8),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_35),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_36),
.B1(n_12),
.B2(n_11),
.Y(n_38)
);


endmodule