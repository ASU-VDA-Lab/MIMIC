module fake_netlist_752_2313_n_39 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_39);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_39;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_29;
wire n_32;

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_4),
.B(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_15),
.B(n_0),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_5),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_7),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_17),
.B(n_3),
.Y(n_26)
);

AND2x6_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_1),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_21),
.A2(n_18),
.B1(n_6),
.B2(n_2),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_24),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_24),
.B1(n_26),
.B2(n_25),
.C(n_20),
.Y(n_30)
);

AO21x2_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_23),
.B(n_8),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_30),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_18),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_10),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

CKINVDCx12_ASAP7_75t_R g36 ( 
.A(n_35),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI322xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_37),
.A3(n_13),
.B1(n_12),
.B2(n_11),
.C1(n_16),
.C2(n_14),
.Y(n_39)
);


endmodule