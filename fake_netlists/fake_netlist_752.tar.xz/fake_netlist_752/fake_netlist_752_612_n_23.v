module fake_netlist_752_612_n_23 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_23);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_23;

wire n_20;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_17;
wire n_21;
wire n_19;
wire n_15;

INVx2_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_6),
.Y(n_15)
);

INVxp33_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

OAI21x1_ASAP7_75t_SL g18 ( 
.A1(n_14),
.A2(n_16),
.B(n_17),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

AOI221x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_15),
.B1(n_16),
.B2(n_0),
.C(n_1),
.Y(n_20)
);

OA22x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_21)
);

AO22x2_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_7),
.B1(n_8),
.B2(n_5),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_13),
.B1(n_11),
.B2(n_9),
.Y(n_23)
);


endmodule