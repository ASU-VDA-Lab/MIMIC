module fake_netlist_752_998_n_62 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_25, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_62);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_62;

wire n_46;
wire n_44;
wire n_61;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_57;
wire n_35;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_4),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_18),
.A2(n_24),
.B1(n_16),
.B2(n_2),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_10),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_11),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_20),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_17),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_13),
.Y(n_34)
);

INVx5_ASAP7_75t_L g35 ( 
.A(n_23),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_16),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_17),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_28),
.B(n_21),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_28),
.B(n_21),
.Y(n_39)
);

AOI21xp5_ASAP7_75t_SL g40 ( 
.A1(n_39),
.A2(n_31),
.B(n_26),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_28),
.Y(n_41)
);

OAI21xp5_ASAP7_75t_SL g42 ( 
.A1(n_38),
.A2(n_29),
.B(n_27),
.Y(n_42)
);

AND2x4_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_37),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_33),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_33),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_44),
.Y(n_49)
);

AOI211xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_45),
.B(n_30),
.C(n_31),
.Y(n_50)
);

AOI322xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_30),
.A3(n_25),
.B1(n_35),
.B2(n_26),
.C1(n_32),
.C2(n_0),
.Y(n_51)
);

OAI221xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_30),
.B1(n_32),
.B2(n_26),
.C(n_35),
.Y(n_52)
);

OAI211xp5_ASAP7_75t_SL g53 ( 
.A1(n_50),
.A2(n_48),
.B(n_25),
.C(n_35),
.Y(n_53)
);

AOI221xp5_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_32),
.B1(n_26),
.B2(n_35),
.C(n_1),
.Y(n_54)
);

NOR2x1_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_32),
.Y(n_55)
);

XOR2xp5_ASAP7_75t_L g56 ( 
.A(n_55),
.B(n_3),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

AOI31xp33_ASAP7_75t_L g58 ( 
.A1(n_54),
.A2(n_35),
.A3(n_6),
.B(n_5),
.Y(n_58)
);

AOI22xp33_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_59)
);

OAI22x1_ASAP7_75t_L g60 ( 
.A1(n_56),
.A2(n_19),
.B1(n_14),
.B2(n_12),
.Y(n_60)
);

OAI221xp5_ASAP7_75t_L g61 ( 
.A1(n_59),
.A2(n_22),
.B1(n_56),
.B2(n_58),
.C(n_60),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_61),
.Y(n_62)
);


endmodule