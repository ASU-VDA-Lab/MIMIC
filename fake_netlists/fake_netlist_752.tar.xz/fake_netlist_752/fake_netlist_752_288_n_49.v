module fake_netlist_752_288_n_49 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_49);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_49;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_1),
.B(n_7),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx4_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_12),
.B(n_15),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_11),
.B(n_4),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_23),
.B(n_1),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_5),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_SL g32 ( 
.A1(n_19),
.A2(n_17),
.B1(n_16),
.B2(n_5),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_24),
.B(n_21),
.Y(n_33)
);

OA21x2_ASAP7_75t_L g34 ( 
.A1(n_28),
.A2(n_26),
.B(n_20),
.Y(n_34)
);

OAI21x1_ASAP7_75t_L g35 ( 
.A1(n_29),
.A2(n_27),
.B(n_30),
.Y(n_35)
);

INVxp67_ASAP7_75t_SL g36 ( 
.A(n_35),
.Y(n_36)
);

NOR2x1_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_19),
.Y(n_37)
);

OAI221xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_32),
.B1(n_30),
.B2(n_23),
.C(n_27),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVxp67_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

NOR2x1_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_23),
.Y(n_42)
);

BUFx4f_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

OAI321xp33_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_22),
.A3(n_18),
.B1(n_17),
.B2(n_33),
.C(n_0),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_22),
.Y(n_45)
);

NAND4xp75_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_9),
.C(n_8),
.D(n_2),
.Y(n_46)
);

CKINVDCx20_ASAP7_75t_R g47 ( 
.A(n_46),
.Y(n_47)
);

XOR2xp5_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_45),
.Y(n_48)
);

AOI22x1_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_45),
.B1(n_47),
.B2(n_44),
.Y(n_49)
);


endmodule