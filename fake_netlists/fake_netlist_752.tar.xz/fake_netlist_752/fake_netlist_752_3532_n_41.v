module fake_netlist_752_3532_n_41 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_41);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_41;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_3),
.Y(n_19)
);

NAND2xp33_ASAP7_75t_SL g20 ( 
.A(n_5),
.B(n_4),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_8),
.B(n_6),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_18),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_16),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

AND3x1_ASAP7_75t_SL g28 ( 
.A(n_20),
.B(n_17),
.C(n_16),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_26),
.Y(n_29)
);

OAI22xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_23),
.B1(n_21),
.B2(n_25),
.Y(n_30)
);

INVx5_ASAP7_75t_SL g31 ( 
.A(n_30),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_26),
.B1(n_19),
.B2(n_25),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_32),
.B1(n_20),
.B2(n_22),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_17),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_18),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_28),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_35),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

OR3x1_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_1),
.C(n_0),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_2),
.Y(n_40)
);

AOI322xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_39),
.A3(n_12),
.B1(n_10),
.B2(n_7),
.C1(n_14),
.C2(n_13),
.Y(n_41)
);


endmodule