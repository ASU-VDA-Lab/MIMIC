module fake_netlist_752_231_n_60 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_60);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_60;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx2_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_11),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_15),
.A2(n_1),
.B1(n_4),
.B2(n_8),
.Y(n_25)
);

BUFx12f_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

BUFx12f_ASAP7_75t_L g27 ( 
.A(n_3),
.Y(n_27)
);

AOI22x1_ASAP7_75t_SL g28 ( 
.A1(n_20),
.A2(n_0),
.B1(n_17),
.B2(n_16),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_11),
.B(n_8),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_15),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_23),
.B(n_24),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_23),
.B(n_2),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_21),
.B(n_2),
.Y(n_33)
);

OR2x6_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_9),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_24),
.B(n_9),
.Y(n_35)
);

OA21x2_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_30),
.B(n_21),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_31),
.A2(n_30),
.B(n_22),
.Y(n_37)
);

AO31x2_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_29),
.A3(n_28),
.B(n_27),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

OR2x6_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_34),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_41),
.B1(n_36),
.B2(n_34),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_38),
.Y(n_46)
);

NAND2x1p5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_42),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_38),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_44),
.B1(n_28),
.B2(n_25),
.Y(n_49)
);

OAI22xp33_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_26),
.B1(n_38),
.B2(n_36),
.Y(n_50)
);

NOR2xp33_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_26),
.Y(n_51)
);

NAND4xp25_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_29),
.C(n_33),
.D(n_38),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_SL g53 ( 
.A(n_50),
.B(n_38),
.C(n_10),
.Y(n_53)
);

OR2x2_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_18),
.Y(n_54)
);

OR2x2_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_18),
.Y(n_55)
);

OAI22xp5_ASAP7_75t_SL g56 ( 
.A1(n_51),
.A2(n_20),
.B1(n_19),
.B2(n_7),
.Y(n_56)
);

AND2x4_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_12),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_14),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_SL g59 ( 
.A(n_57),
.B(n_56),
.Y(n_59)
);

AOI21xp33_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_58),
.B(n_57),
.Y(n_60)
);


endmodule