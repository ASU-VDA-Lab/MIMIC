module fake_netlist_752_2323_n_53 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_53);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_53;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_52;
wire n_32;

BUFx3_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_7),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_15),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_16),
.B(n_5),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_12),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_16),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_14),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_18),
.B(n_0),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_17),
.A2(n_13),
.B(n_1),
.C(n_0),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_24),
.A2(n_6),
.B(n_4),
.C(n_3),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

AND2x2_ASAP7_75t_SL g35 ( 
.A(n_30),
.B(n_21),
.Y(n_35)
);

OR2x6_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_26),
.Y(n_36)
);

INVx4_ASAP7_75t_L g37 ( 
.A(n_29),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_R g38 ( 
.A(n_32),
.B(n_28),
.Y(n_38)
);

NOR3xp33_ASAP7_75t_SL g39 ( 
.A(n_33),
.B(n_20),
.C(n_19),
.Y(n_39)
);

BUFx3_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx3_ASAP7_75t_L g43 ( 
.A(n_36),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_43),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

INVxp67_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_40),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_43),
.B1(n_42),
.B2(n_34),
.C(n_38),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_43),
.Y(n_49)
);

AOI21xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_46),
.B(n_47),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

OAI211xp5_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_38),
.B(n_39),
.C(n_25),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_50),
.B1(n_23),
.B2(n_8),
.Y(n_53)
);


endmodule