module fake_netlist_752_2371_n_64 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_27, n_24, n_10, n_5, n_26, n_6, n_2, n_3, n_9, n_4, n_25, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_64);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_27;
input n_24;
input n_10;
input n_5;
input n_26;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_64;

wire n_46;
wire n_44;
wire n_61;
wire n_62;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_42;
wire n_59;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_63;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx1_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_4),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_18),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_2),
.B(n_23),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_5),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_22),
.B(n_12),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_9),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_3),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_10),
.B(n_15),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_R g39 ( 
.A(n_30),
.B(n_0),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_29),
.B(n_24),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_28),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_36),
.B(n_24),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_38),
.B(n_36),
.Y(n_43)
);

INVx8_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_37),
.B1(n_31),
.B2(n_35),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_40),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_44),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_42),
.Y(n_50)
);

NAND4xp25_ASAP7_75t_SL g51 ( 
.A(n_49),
.B(n_46),
.C(n_34),
.D(n_25),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_37),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_37),
.Y(n_53)
);

AOI221xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_37),
.B1(n_32),
.B2(n_33),
.C(n_25),
.Y(n_54)
);

OAI21xp33_ASAP7_75t_SL g55 ( 
.A1(n_52),
.A2(n_32),
.B(n_26),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

AOI221xp5_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_6),
.B1(n_1),
.B2(n_7),
.C(n_8),
.Y(n_57)
);

AOI221xp5_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_56),
.B1(n_14),
.B2(n_11),
.C(n_13),
.Y(n_58)
);

NOR3xp33_ASAP7_75t_SL g59 ( 
.A(n_55),
.B(n_17),
.C(n_16),
.Y(n_59)
);

AND2x4_ASAP7_75t_L g60 ( 
.A(n_59),
.B(n_19),
.Y(n_60)
);

INVx3_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_60),
.Y(n_62)
);

AOI22xp33_ASAP7_75t_SL g63 ( 
.A1(n_61),
.A2(n_21),
.B1(n_57),
.B2(n_60),
.Y(n_63)
);

AOI22xp5_ASAP7_75t_SL g64 ( 
.A1(n_62),
.A2(n_60),
.B1(n_61),
.B2(n_63),
.Y(n_64)
);


endmodule