module fake_netlist_752_1979_n_36 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_36);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_36;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_34;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

CKINVDCx8_ASAP7_75t_R g15 ( 
.A(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_13),
.B(n_1),
.Y(n_17)
);

INVx5_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

BUFx4f_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.B(n_12),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_20),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_19),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_10),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_21),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_23),
.B1(n_18),
.B2(n_15),
.Y(n_27)
);

AOI211xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_17),
.B(n_14),
.C(n_12),
.Y(n_28)
);

AOI211xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_28),
.B(n_14),
.C(n_11),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_11),
.C(n_21),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_18),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_15),
.B1(n_5),
.B2(n_1),
.C(n_4),
.Y(n_32)
);

AOI22x1_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_7),
.B1(n_6),
.B2(n_9),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_6),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_7),
.B1(n_33),
.B2(n_32),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);


endmodule