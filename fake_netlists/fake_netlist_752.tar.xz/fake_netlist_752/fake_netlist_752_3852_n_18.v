module fake_netlist_752_3852_n_18 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_8, n_18);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_18;

wire n_14;
wire n_9;
wire n_16;
wire n_17;
wire n_13;
wire n_11;
wire n_12;
wire n_15;
wire n_10;

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

CKINVDCx16_ASAP7_75t_R g12 ( 
.A(n_2),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_4),
.B(n_1),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.C(n_9),
.Y(n_14)
);

A2O1A1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B(n_9),
.C(n_1),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_9),
.B1(n_6),
.B2(n_4),
.C1(n_7),
.C2(n_5),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_18)
);


endmodule