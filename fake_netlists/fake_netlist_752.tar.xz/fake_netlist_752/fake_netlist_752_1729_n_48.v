module fake_netlist_752_1729_n_48 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_48);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_48;

wire n_20;
wire n_23;
wire n_46;
wire n_14;
wire n_44;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_39;
wire n_11;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_10;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_15;
wire n_12;
wire n_41;
wire n_19;
wire n_29;
wire n_47;
wire n_32;

INVx3_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_SL g12 ( 
.A(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_SL g19 ( 
.A1(n_17),
.A2(n_7),
.B(n_0),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_7),
.B(n_2),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_10),
.B(n_3),
.Y(n_21)
);

NOR2xp67_ASAP7_75t_L g22 ( 
.A(n_10),
.B(n_3),
.Y(n_22)
);

O2A1O1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_14),
.A2(n_8),
.B(n_5),
.C(n_4),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_10),
.B(n_5),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_13),
.B(n_9),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_11),
.B(n_9),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_SL g27 ( 
.A1(n_14),
.A2(n_15),
.B(n_11),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_15),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_25),
.Y(n_32)
);

NOR2x1_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_16),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_32),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_27),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_28),
.B(n_24),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_31),
.B(n_12),
.Y(n_38)
);

NOR4xp25_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_23),
.C(n_18),
.D(n_16),
.Y(n_39)
);

NOR2x1_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_33),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_34),
.B(n_29),
.Y(n_41)
);

NOR4xp25_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_35),
.C(n_36),
.D(n_29),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_30),
.C(n_20),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_31),
.Y(n_45)
);

XOR2x1_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_19),
.Y(n_46)
);

NAND3xp33_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_43),
.C(n_42),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_45),
.B(n_46),
.Y(n_48)
);


endmodule