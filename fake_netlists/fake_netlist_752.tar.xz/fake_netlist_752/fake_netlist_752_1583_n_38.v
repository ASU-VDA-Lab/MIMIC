module fake_netlist_752_1583_n_38 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_38);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_38;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_1),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_6),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_0),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_14),
.B(n_0),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_15),
.B(n_5),
.Y(n_22)
);

OAI222xp33_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_17),
.B1(n_15),
.B2(n_11),
.C1(n_13),
.C2(n_14),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_17),
.B1(n_6),
.B2(n_5),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_25),
.B1(n_19),
.B2(n_18),
.C(n_22),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_24),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_19),
.Y(n_28)
);

AOI211xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_21),
.B(n_22),
.C(n_24),
.Y(n_29)
);

INVx5_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_28),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_19),
.Y(n_32)
);

NOR2x1_ASAP7_75t_SL g33 ( 
.A(n_31),
.B(n_30),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_18),
.B(n_19),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_18),
.B1(n_7),
.B2(n_8),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_10),
.B1(n_36),
.B2(n_35),
.Y(n_38)
);


endmodule