module fake_netlist_752_3319_n_84 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_84);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_84;

wire n_77;
wire n_71;
wire n_80;
wire n_62;
wire n_36;
wire n_81;
wire n_68;
wire n_73;
wire n_24;
wire n_60;
wire n_53;
wire n_57;
wire n_41;
wire n_55;
wire n_23;
wire n_46;
wire n_64;
wire n_22;
wire n_82;
wire n_76;
wire n_72;
wire n_51;
wire n_78;
wire n_75;
wire n_42;
wire n_33;
wire n_70;
wire n_63;
wire n_25;
wire n_69;
wire n_56;
wire n_52;
wire n_61;
wire n_45;
wire n_28;
wire n_65;
wire n_50;
wire n_79;
wire n_35;
wire n_43;
wire n_58;
wire n_74;
wire n_44;
wire n_66;
wire n_34;
wire n_39;
wire n_48;
wire n_49;
wire n_27;
wire n_37;
wire n_59;
wire n_26;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_67;
wire n_29;
wire n_47;
wire n_54;
wire n_32;
wire n_83;

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_6),
.B(n_14),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_13),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_10),
.Y(n_28)
);

AND2x6_ASAP7_75t_L g29 ( 
.A(n_0),
.B(n_11),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_5),
.A2(n_8),
.B1(n_12),
.B2(n_15),
.Y(n_30)
);

INVx4_ASAP7_75t_L g31 ( 
.A(n_3),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_17),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_9),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_21),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_25),
.B(n_2),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_22),
.B(n_2),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_22),
.B(n_11),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_L g40 ( 
.A(n_28),
.B(n_16),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_33),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_26),
.B(n_16),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_L g43 ( 
.A(n_31),
.B(n_17),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_23),
.Y(n_44)
);

INVx2_ASAP7_75t_SL g45 ( 
.A(n_31),
.Y(n_45)
);

O2A1O1Ixp33_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_36),
.B(n_45),
.C(n_42),
.Y(n_46)
);

AOI21xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_24),
.B(n_30),
.Y(n_47)
);

AO21x2_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_23),
.B(n_32),
.Y(n_48)
);

A2O1A1Ixp33_ASAP7_75t_L g49 ( 
.A1(n_37),
.A2(n_34),
.B(n_35),
.C(n_29),
.Y(n_49)
);

AO31x2_ASAP7_75t_L g50 ( 
.A1(n_40),
.A2(n_29),
.A3(n_35),
.B(n_18),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_38),
.B(n_19),
.Y(n_51)
);

AO32x2_ASAP7_75t_L g52 ( 
.A1(n_37),
.A2(n_29),
.A3(n_20),
.B1(n_4),
.B2(n_7),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_48),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_46),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_50),
.Y(n_56)
);

BUFx6f_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_47),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_57),
.B(n_52),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_54),
.Y(n_60)
);

AND2x4_ASAP7_75t_L g61 ( 
.A(n_56),
.B(n_49),
.Y(n_61)
);

HB1xp67_ASAP7_75t_L g62 ( 
.A(n_55),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_60),
.Y(n_63)
);

OR2x2_ASAP7_75t_L g64 ( 
.A(n_58),
.B(n_57),
.Y(n_64)
);

AND2x2_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_57),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_62),
.B(n_57),
.Y(n_66)
);

INVx2_ASAP7_75t_SL g67 ( 
.A(n_61),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_63),
.Y(n_68)
);

AND2x2_ASAP7_75t_L g69 ( 
.A(n_67),
.B(n_59),
.Y(n_69)
);

AOI31xp33_ASAP7_75t_L g70 ( 
.A1(n_67),
.A2(n_59),
.A3(n_43),
.B(n_37),
.Y(n_70)
);

OAI21xp33_ASAP7_75t_SL g71 ( 
.A1(n_65),
.A2(n_52),
.B(n_38),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_65),
.Y(n_72)
);

INVx1_ASAP7_75t_SL g73 ( 
.A(n_68),
.Y(n_73)
);

NOR4xp25_ASAP7_75t_L g74 ( 
.A(n_71),
.B(n_41),
.C(n_66),
.D(n_64),
.Y(n_74)
);

NAND3xp33_ASAP7_75t_SL g75 ( 
.A(n_68),
.B(n_41),
.C(n_64),
.Y(n_75)
);

A2O1A1Ixp33_ASAP7_75t_L g76 ( 
.A1(n_70),
.A2(n_37),
.B(n_39),
.C(n_61),
.Y(n_76)
);

NAND4xp25_ASAP7_75t_L g77 ( 
.A(n_72),
.B(n_39),
.C(n_61),
.D(n_20),
.Y(n_77)
);

NAND4xp25_ASAP7_75t_L g78 ( 
.A(n_77),
.B(n_39),
.C(n_72),
.D(n_69),
.Y(n_78)
);

NOR2x1_ASAP7_75t_L g79 ( 
.A(n_73),
.B(n_61),
.Y(n_79)
);

XNOR2x1_ASAP7_75t_SL g80 ( 
.A(n_76),
.B(n_69),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_SL g81 ( 
.A(n_79),
.B(n_74),
.Y(n_81)
);

NAND2xp5_ASAP7_75t_SL g82 ( 
.A(n_80),
.B(n_75),
.Y(n_82)
);

OAI22x1_ASAP7_75t_L g83 ( 
.A1(n_82),
.A2(n_50),
.B1(n_78),
.B2(n_81),
.Y(n_83)
);

OA21x2_ASAP7_75t_L g84 ( 
.A1(n_83),
.A2(n_50),
.B(n_81),
.Y(n_84)
);


endmodule