module fake_netlist_752_3187_n_33 (n_12, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_33);

input n_12;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_33;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_16;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_15;
wire n_29;
wire n_32;

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_12),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_10),
.B(n_9),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B1(n_18),
.B2(n_15),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_21),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

CKINVDCx16_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

AOI211xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_23),
.B(n_21),
.C(n_16),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

OAI221xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_19),
.B1(n_7),
.B2(n_4),
.C(n_0),
.Y(n_29)
);

NAND3xp33_ASAP7_75t_SL g30 ( 
.A(n_29),
.B(n_7),
.C(n_4),
.Y(n_30)
);

OAI221xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.C(n_5),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_31),
.C(n_11),
.Y(n_33)
);


endmodule