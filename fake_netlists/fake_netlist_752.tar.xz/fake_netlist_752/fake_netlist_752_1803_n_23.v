module fake_netlist_752_1803_n_23 (n_1, n_2, n_3, n_4, n_5, n_0, n_23);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_23;

wire n_20;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVxp33_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

INVxp67_ASAP7_75t_SL g12 ( 
.A(n_7),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.B1(n_8),
.B2(n_0),
.Y(n_13)
);

INVx3_ASAP7_75t_SL g14 ( 
.A(n_11),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_SL g15 ( 
.A1(n_13),
.A2(n_12),
.B(n_10),
.C(n_0),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

NAND3xp33_ASAP7_75t_SL g21 ( 
.A(n_19),
.B(n_14),
.C(n_1),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B1(n_8),
.B2(n_4),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_R g23 ( 
.A1(n_22),
.A2(n_20),
.B1(n_5),
.B2(n_4),
.C(n_8),
.Y(n_23)
);


endmodule