module fake_netlist_752_2969_n_8 (n_0, n_2, n_1, n_8);

input n_0;
input n_2;
input n_1;

output n_8;

wire n_3;
wire n_4;
wire n_5;
wire n_7;
wire n_6;

INVxp67_ASAP7_75t_SL g3 ( 
.A(n_0),
.Y(n_3)
);

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_0),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

OAI22xp33_ASAP7_75t_SL g6 ( 
.A1(n_5),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_R g7 ( 
.A(n_6),
.B(n_2),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B1(n_3),
.B2(n_6),
.Y(n_8)
);


endmodule