module fake_netlist_752_220_n_81 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_27, n_24, n_10, n_5, n_26, n_6, n_2, n_3, n_9, n_4, n_25, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_81);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_27;
input n_24;
input n_10;
input n_5;
input n_26;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_81;

wire n_77;
wire n_71;
wire n_80;
wire n_62;
wire n_36;
wire n_68;
wire n_73;
wire n_60;
wire n_53;
wire n_57;
wire n_41;
wire n_55;
wire n_46;
wire n_64;
wire n_76;
wire n_72;
wire n_51;
wire n_78;
wire n_75;
wire n_42;
wire n_33;
wire n_70;
wire n_63;
wire n_69;
wire n_56;
wire n_52;
wire n_61;
wire n_45;
wire n_28;
wire n_65;
wire n_50;
wire n_79;
wire n_35;
wire n_43;
wire n_58;
wire n_74;
wire n_44;
wire n_66;
wire n_39;
wire n_34;
wire n_48;
wire n_49;
wire n_37;
wire n_59;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_67;
wire n_29;
wire n_47;
wire n_54;
wire n_32;

INVx3_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_17),
.A2(n_16),
.B1(n_20),
.B2(n_8),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_4),
.B(n_5),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_7),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_0),
.B(n_22),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

CKINVDCx6p67_ASAP7_75t_R g36 ( 
.A(n_18),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_19),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_24),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_26),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_2),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_1),
.B(n_21),
.Y(n_41)
);

AO22x1_ASAP7_75t_L g42 ( 
.A1(n_37),
.A2(n_31),
.B1(n_39),
.B2(n_32),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_37),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_28),
.B(n_19),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_29),
.A2(n_26),
.B1(n_25),
.B2(n_23),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_36),
.Y(n_46)
);

AND2x4_ASAP7_75t_SL g47 ( 
.A(n_31),
.B(n_3),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_42),
.B(n_28),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_L g49 ( 
.A1(n_44),
.A2(n_40),
.B(n_30),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_43),
.Y(n_50)
);

AO21x1_ASAP7_75t_L g51 ( 
.A1(n_44),
.A2(n_41),
.B(n_34),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

AND2x4_ASAP7_75t_L g55 ( 
.A(n_54),
.B(n_47),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_49),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_46),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_49),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

BUFx2_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

AOI211xp5_ASAP7_75t_L g61 ( 
.A1(n_55),
.A2(n_45),
.B(n_29),
.C(n_35),
.Y(n_61)
);

OAI22xp33_ASAP7_75t_L g62 ( 
.A1(n_58),
.A2(n_38),
.B1(n_35),
.B2(n_41),
.Y(n_62)
);

O2A1O1Ixp5_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_58),
.B(n_56),
.C(n_55),
.Y(n_63)
);

NOR2xp33_ASAP7_75t_R g64 ( 
.A(n_60),
.B(n_23),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_60),
.Y(n_65)
);

AOI21xp5_ASAP7_75t_L g66 ( 
.A1(n_59),
.A2(n_55),
.B(n_33),
.Y(n_66)
);

A2O1A1Ixp33_ASAP7_75t_L g67 ( 
.A1(n_61),
.A2(n_38),
.B(n_35),
.C(n_33),
.Y(n_67)
);

NAND3xp33_ASAP7_75t_SL g68 ( 
.A(n_64),
.B(n_27),
.C(n_25),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_65),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_67),
.Y(n_70)
);

NOR3xp33_ASAP7_75t_L g71 ( 
.A(n_63),
.B(n_38),
.C(n_33),
.Y(n_71)
);

NOR2x1_ASAP7_75t_L g72 ( 
.A(n_66),
.B(n_6),
.Y(n_72)
);

NOR3xp33_ASAP7_75t_L g73 ( 
.A(n_68),
.B(n_69),
.C(n_71),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_70),
.Y(n_74)
);

INVx1_ASAP7_75t_SL g75 ( 
.A(n_72),
.Y(n_75)
);

NOR3xp33_ASAP7_75t_L g76 ( 
.A(n_68),
.B(n_11),
.C(n_10),
.Y(n_76)
);

AO22x2_ASAP7_75t_L g77 ( 
.A1(n_75),
.A2(n_74),
.B1(n_73),
.B2(n_76),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_74),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_74),
.Y(n_79)
);

OAI22xp5_ASAP7_75t_L g80 ( 
.A1(n_77),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_80)
);

AO21x2_ASAP7_75t_L g81 ( 
.A1(n_80),
.A2(n_79),
.B(n_78),
.Y(n_81)
);


endmodule