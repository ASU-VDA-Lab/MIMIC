module fake_netlist_752_2427_n_49 (n_20, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_49);

input n_20;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_49;

wire n_23;
wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_28;
wire n_37;
wire n_42;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVx1_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_1),
.B(n_20),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_2),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_8),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_22),
.B(n_16),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_18),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_6),
.B(n_13),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_26),
.A2(n_18),
.B(n_17),
.C(n_16),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_30),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_30),
.Y(n_36)
);

INVx3_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_34),
.B1(n_26),
.B2(n_24),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

CKINVDCx16_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_38),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

OAI21xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_39),
.B(n_33),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_31),
.B(n_29),
.Y(n_44)
);

NOR2x1_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_25),
.Y(n_45)
);

NOR4xp25_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_28),
.C(n_19),
.D(n_17),
.Y(n_46)
);

OAI222xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_27),
.B1(n_19),
.B2(n_5),
.C1(n_3),
.C2(n_0),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_7),
.Y(n_48)
);

AOI322xp5_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_47),
.A3(n_12),
.B1(n_11),
.B2(n_9),
.C1(n_15),
.C2(n_14),
.Y(n_49)
);


endmodule