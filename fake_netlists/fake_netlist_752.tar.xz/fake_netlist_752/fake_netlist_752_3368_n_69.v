module fake_netlist_752_3368_n_69 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_69);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_69;

wire n_46;
wire n_44;
wire n_66;
wire n_64;
wire n_62;
wire n_61;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_68;
wire n_49;
wire n_28;
wire n_65;
wire n_27;
wire n_42;
wire n_37;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_50;
wire n_31;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_63;
wire n_25;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_67;
wire n_55;
wire n_47;
wire n_29;
wire n_52;
wire n_54;
wire n_32;

OAI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_5),
.A2(n_11),
.B1(n_13),
.B2(n_15),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_17),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_16),
.A2(n_0),
.B1(n_22),
.B2(n_3),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_1),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_10),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_6),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_23),
.B(n_21),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_16),
.A2(n_4),
.B1(n_8),
.B2(n_24),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_23),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_27),
.B(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_30),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_28),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_26),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_30),
.B(n_10),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_35),
.B(n_17),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_38),
.A2(n_41),
.B1(n_42),
.B2(n_36),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_38),
.Y(n_44)
);

INVx3_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AND2x4_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_37),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_39),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_37),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_44),
.B1(n_45),
.B2(n_42),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_28),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_45),
.C(n_46),
.Y(n_53)
);

AND2x4_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_46),
.Y(n_54)
);

INVxp67_ASAP7_75t_SL g55 ( 
.A(n_49),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_34),
.B1(n_29),
.B2(n_45),
.Y(n_56)
);

AOI22xp33_ASAP7_75t_L g57 ( 
.A1(n_52),
.A2(n_45),
.B1(n_25),
.B2(n_40),
.Y(n_57)
);

INVx1_ASAP7_75t_SL g58 ( 
.A(n_54),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_L g59 ( 
.A1(n_52),
.A2(n_31),
.B1(n_33),
.B2(n_36),
.Y(n_59)
);

NOR2xp67_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_18),
.Y(n_60)
);

OR2x2_ASAP7_75t_L g61 ( 
.A(n_58),
.B(n_54),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_59),
.Y(n_62)
);

NOR5xp2_ASAP7_75t_L g63 ( 
.A(n_57),
.B(n_53),
.C(n_20),
.D(n_18),
.E(n_19),
.Y(n_63)
);

NOR4xp75_ASAP7_75t_SL g64 ( 
.A(n_58),
.B(n_22),
.C(n_20),
.D(n_19),
.Y(n_64)
);

AND3x4_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_54),
.C(n_26),
.Y(n_65)
);

NAND3xp33_ASAP7_75t_L g66 ( 
.A(n_63),
.B(n_32),
.C(n_24),
.Y(n_66)
);

OAI21xp33_ASAP7_75t_L g67 ( 
.A1(n_62),
.A2(n_32),
.B(n_2),
.Y(n_67)
);

OAI22xp5_ASAP7_75t_SL g68 ( 
.A1(n_65),
.A2(n_64),
.B1(n_66),
.B2(n_61),
.Y(n_68)
);

AOI22xp33_ASAP7_75t_L g69 ( 
.A1(n_68),
.A2(n_67),
.B1(n_12),
.B2(n_7),
.Y(n_69)
);


endmodule