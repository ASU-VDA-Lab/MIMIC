module fake_netlist_628_556_n_12 (n_1, n_2, n_3, n_0, n_12);

input n_1;
input n_2;
input n_3;
input n_0;

output n_12;

wire n_7;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_9;

NAND2xp33_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_6),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

OAI221xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B1(n_4),
.B2(n_5),
.C(n_1),
.Y(n_9)
);

NOR3xp33_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_1),
.C(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_2),
.B1(n_3),
.B2(n_10),
.Y(n_12)
);


endmodule