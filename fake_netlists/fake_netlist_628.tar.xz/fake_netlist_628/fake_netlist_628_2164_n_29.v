module fake_netlist_628_2164_n_29 (n_7, n_9, n_11, n_8, n_5, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_29);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_29;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;

INVx2_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

OR2x2_ASAP7_75t_SL g16 ( 
.A(n_0),
.B(n_12),
.Y(n_16)
);

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_10),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_5),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_11),
.B(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_15),
.A2(n_3),
.B(n_2),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_20),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_16),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_23),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_17),
.C(n_18),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.B1(n_12),
.B2(n_11),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_8),
.B1(n_7),
.B2(n_4),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_14),
.B1(n_13),
.B2(n_9),
.Y(n_29)
);


endmodule