module fake_netlist_628_4290_n_28 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_28);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_28;

wire n_11;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_27;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

INVx2_ASAP7_75t_SL g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_6),
.B(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

INVx5_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_1),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_3),
.B(n_0),
.Y(n_16)
);

NOR2xp67_ASAP7_75t_SL g17 ( 
.A(n_14),
.B(n_9),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_12),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_21),
.B1(n_19),
.B2(n_11),
.C(n_10),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_16),
.B(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND4xp75_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_11),
.C(n_21),
.D(n_14),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_16),
.B(n_1),
.Y(n_26)
);

XOR2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_4),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_27),
.B(n_4),
.Y(n_28)
);


endmodule