module fake_netlist_628_1686_n_31 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_31);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_31;

wire n_11;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_1),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_1),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_SL g14 ( 
.A(n_9),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_0),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_12),
.B(n_3),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_14),
.Y(n_18)
);

INVx2_ASAP7_75t_SL g19 ( 
.A(n_15),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_SL g20 ( 
.A(n_18),
.B(n_13),
.C(n_11),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.C(n_17),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_18),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

OAI211xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_19),
.B(n_18),
.C(n_0),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_18),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_SL g27 ( 
.A1(n_25),
.A2(n_23),
.B1(n_19),
.B2(n_2),
.C(n_4),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

XNOR2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_28),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_5),
.B1(n_6),
.B2(n_29),
.Y(n_31)
);


endmodule