module fake_netlist_628_1960_n_5 (n_1, n_0, n_5);

input n_1;
input n_0;

output n_5;

wire n_4;
wire n_2;
wire n_3;

NAND2xp5_ASAP7_75t_SL g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

INVx1_ASAP7_75t_SL g3 ( 
.A(n_2),
.Y(n_3)
);

OAI21xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

AOI22xp33_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.Y(n_5)
);


endmodule