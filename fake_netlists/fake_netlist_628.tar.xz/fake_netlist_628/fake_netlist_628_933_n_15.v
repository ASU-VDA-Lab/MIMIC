module fake_netlist_628_933_n_15 (n_0, n_4, n_1, n_2, n_3, n_15);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_15;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_12;

NOR2xp67_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_2),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_R g6 ( 
.A(n_2),
.B(n_1),
.Y(n_6)
);

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

AND2x6_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_1),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_R g9 ( 
.A(n_8),
.B(n_1),
.Y(n_9)
);

OR2x6_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

AOI21xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_5),
.B(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

NAND5xp2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_6),
.C(n_5),
.D(n_0),
.E(n_2),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_4),
.B1(n_3),
.B2(n_0),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_1),
.B1(n_4),
.B2(n_12),
.Y(n_15)
);


endmodule