module fake_netlist_628_3813_n_54 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_17, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_54);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_17;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_54;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_50;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_52;
wire n_24;
wire n_51;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;

INVx3_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_16),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_11),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_6),
.B(n_12),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_10),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_0),
.Y(n_26)
);

OAI22x1_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_9),
.B(n_5),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_22),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_18),
.B(n_3),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_18),
.B(n_11),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_23),
.B(n_14),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_33),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_32),
.B(n_21),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_30),
.B(n_24),
.Y(n_36)
);

BUFx3_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_31),
.A2(n_24),
.B1(n_25),
.B2(n_20),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_28),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_34),
.B(n_26),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_34),
.B(n_29),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

OAI221xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_38),
.B1(n_29),
.B2(n_37),
.C(n_36),
.Y(n_43)
);

AOI211xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_35),
.B(n_36),
.C(n_37),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

OAI21xp33_ASAP7_75t_SL g46 ( 
.A1(n_43),
.A2(n_42),
.B(n_39),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_R g47 ( 
.A(n_45),
.B(n_19),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_SL g48 ( 
.A(n_44),
.B(n_35),
.Y(n_48)
);

CKINVDCx20_ASAP7_75t_R g49 ( 
.A(n_47),
.Y(n_49)
);

XOR2xp5_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_27),
.Y(n_50)
);

NAND5xp2_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_38),
.C(n_41),
.D(n_36),
.E(n_39),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_51),
.B(n_15),
.Y(n_52)
);

AND2x2_ASAP7_75t_SL g53 ( 
.A(n_49),
.B(n_17),
.Y(n_53)
);

OAI221xp5_ASAP7_75t_R g54 ( 
.A1(n_52),
.A2(n_13),
.B1(n_50),
.B2(n_49),
.C(n_53),
.Y(n_54)
);


endmodule