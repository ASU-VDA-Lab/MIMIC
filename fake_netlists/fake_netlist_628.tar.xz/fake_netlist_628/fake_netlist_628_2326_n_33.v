module fake_netlist_628_2326_n_33 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_33);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_33;

wire n_31;
wire n_21;
wire n_30;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_5),
.B(n_1),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_7),
.B(n_6),
.Y(n_21)
);

AND2x6_ASAP7_75t_L g22 ( 
.A(n_15),
.B(n_12),
.Y(n_22)
);

INVx4_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

OR2x6_ASAP7_75t_L g24 ( 
.A(n_11),
.B(n_17),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_8),
.B(n_10),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_2),
.Y(n_26)
);

OAI22xp33_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_23),
.B1(n_21),
.B2(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_22),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_22),
.Y(n_29)
);

OAI21xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_19),
.B(n_3),
.Y(n_30)
);

AOI211x1_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_28),
.B(n_9),
.C(n_4),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_18),
.B1(n_16),
.B2(n_13),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);


endmodule