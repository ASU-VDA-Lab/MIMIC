module fake_netlist_628_17_n_48 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_17, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_48);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_17;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_48;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

INVx6_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_10),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_4),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_23),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_20),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_21),
.B1(n_25),
.B2(n_22),
.C(n_18),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_28),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_34),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

OAI222xp33_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_24),
.B1(n_32),
.B2(n_27),
.C1(n_25),
.C2(n_30),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_30),
.B(n_31),
.C(n_0),
.Y(n_39)
);

AOI222xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_37),
.B1(n_36),
.B2(n_31),
.C1(n_4),
.C2(n_0),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

O2A1O1Ixp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_31),
.B(n_3),
.C(n_2),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_5),
.Y(n_43)
);

OAI321xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_17),
.A3(n_16),
.B1(n_11),
.B2(n_8),
.C(n_6),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_13),
.A3(n_14),
.B1(n_15),
.B2(n_42),
.C1(n_44),
.C2(n_47),
.Y(n_48)
);


endmodule