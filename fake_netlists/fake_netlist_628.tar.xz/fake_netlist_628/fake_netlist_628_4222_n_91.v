module fake_netlist_628_4222_n_91 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_27, n_28, n_17, n_4, n_1, n_24, n_7, n_25, n_26, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_91);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_27;
input n_28;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_25;
input n_26;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_91;

wire n_75;
wire n_37;
wire n_54;
wire n_44;
wire n_36;
wire n_87;
wire n_65;
wire n_83;
wire n_63;
wire n_88;
wire n_47;
wire n_57;
wire n_82;
wire n_55;
wire n_76;
wire n_64;
wire n_68;
wire n_81;
wire n_39;
wire n_53;
wire n_77;
wire n_29;
wire n_35;
wire n_80;
wire n_69;
wire n_86;
wire n_78;
wire n_71;
wire n_42;
wire n_84;
wire n_59;
wire n_50;
wire n_58;
wire n_52;
wire n_49;
wire n_51;
wire n_45;
wire n_73;
wire n_56;
wire n_85;
wire n_66;
wire n_32;
wire n_33;
wire n_41;
wire n_34;
wire n_31;
wire n_79;
wire n_40;
wire n_30;
wire n_61;
wire n_62;
wire n_70;
wire n_90;
wire n_67;
wire n_89;
wire n_48;
wire n_60;
wire n_46;
wire n_38;
wire n_43;
wire n_74;
wire n_72;

INVx2_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_17),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_14),
.B(n_24),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_12),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_9),
.B(n_15),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_27),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

AOI22x1_ASAP7_75t_SL g38 ( 
.A1(n_26),
.A2(n_16),
.B1(n_6),
.B2(n_24),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_3),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_4),
.B(n_0),
.Y(n_40)
);

BUFx3_ASAP7_75t_L g41 ( 
.A(n_28),
.Y(n_41)
);

INVx3_ASAP7_75t_L g42 ( 
.A(n_5),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_10),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_13),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_31),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_25),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_SL g48 ( 
.A(n_32),
.B(n_26),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_41),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_R g50 ( 
.A(n_39),
.B(n_36),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_SL g51 ( 
.A(n_29),
.B(n_28),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_33),
.A2(n_7),
.B1(n_2),
.B2(n_1),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_45),
.B(n_46),
.Y(n_53)
);

OA21x2_ASAP7_75t_L g54 ( 
.A1(n_47),
.A2(n_34),
.B(n_29),
.Y(n_54)
);

CKINVDCx20_ASAP7_75t_R g55 ( 
.A(n_50),
.Y(n_55)
);

NOR2xp33_ASAP7_75t_L g56 ( 
.A(n_49),
.B(n_43),
.Y(n_56)
);

BUFx12f_ASAP7_75t_L g57 ( 
.A(n_50),
.Y(n_57)
);

INVx3_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_53),
.B(n_30),
.Y(n_59)
);

BUFx4f_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

NOR2xp33_ASAP7_75t_L g61 ( 
.A(n_53),
.B(n_48),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_59),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_60),
.B(n_55),
.Y(n_63)
);

OR2x2_ASAP7_75t_L g64 ( 
.A(n_61),
.B(n_56),
.Y(n_64)
);

NAND2xp5_ASAP7_75t_L g65 ( 
.A(n_61),
.B(n_54),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_62),
.Y(n_66)
);

INVx1_ASAP7_75t_SL g67 ( 
.A(n_63),
.Y(n_67)
);

BUFx4f_ASAP7_75t_SL g68 ( 
.A(n_64),
.Y(n_68)
);

AOI22xp5_ASAP7_75t_L g69 ( 
.A1(n_65),
.A2(n_60),
.B1(n_52),
.B2(n_38),
.Y(n_69)
);

OAI22xp5_ASAP7_75t_L g70 ( 
.A1(n_65),
.A2(n_58),
.B1(n_33),
.B2(n_51),
.Y(n_70)
);

AOI22xp5_ASAP7_75t_L g71 ( 
.A1(n_68),
.A2(n_58),
.B1(n_37),
.B2(n_34),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_66),
.Y(n_72)
);

AOI21xp5_ASAP7_75t_SL g73 ( 
.A1(n_70),
.A2(n_35),
.B(n_44),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_67),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_69),
.Y(n_75)
);

O2A1O1Ixp33_ASAP7_75t_L g76 ( 
.A1(n_66),
.A2(n_44),
.B(n_35),
.C(n_40),
.Y(n_76)
);

AND2x2_ASAP7_75t_L g77 ( 
.A(n_75),
.B(n_37),
.Y(n_77)
);

NOR2x1_ASAP7_75t_L g78 ( 
.A(n_73),
.B(n_37),
.Y(n_78)
);

NAND4xp75_ASAP7_75t_L g79 ( 
.A(n_71),
.B(n_37),
.C(n_11),
.D(n_8),
.Y(n_79)
);

AND2x2_ASAP7_75t_SL g80 ( 
.A(n_74),
.B(n_18),
.Y(n_80)
);

HB1xp67_ASAP7_75t_L g81 ( 
.A(n_72),
.Y(n_81)
);

NAND2xp5_ASAP7_75t_L g82 ( 
.A(n_76),
.B(n_19),
.Y(n_82)
);

NAND4xp25_ASAP7_75t_L g83 ( 
.A(n_75),
.B(n_20),
.C(n_21),
.D(n_69),
.Y(n_83)
);

INVx3_ASAP7_75t_L g84 ( 
.A(n_79),
.Y(n_84)
);

INVx2_ASAP7_75t_L g85 ( 
.A(n_81),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_77),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_80),
.Y(n_87)
);

XNOR2xp5_ASAP7_75t_L g88 ( 
.A(n_83),
.B(n_78),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_85),
.Y(n_89)
);

AOI22xp5_ASAP7_75t_SL g90 ( 
.A1(n_87),
.A2(n_82),
.B1(n_88),
.B2(n_84),
.Y(n_90)
);

AOI22x1_ASAP7_75t_L g91 ( 
.A1(n_90),
.A2(n_84),
.B1(n_86),
.B2(n_89),
.Y(n_91)
);


endmodule