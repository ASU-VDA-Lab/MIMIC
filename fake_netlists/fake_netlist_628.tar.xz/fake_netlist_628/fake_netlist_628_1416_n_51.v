module fake_netlist_628_1416_n_51 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_51);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_51;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

INVx3_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_3),
.B(n_22),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_10),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_6),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_13),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_15),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_23),
.B(n_18),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_23),
.B(n_18),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_30),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI21x1_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_24),
.B(n_29),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_30),
.B(n_27),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_31),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_37),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_25),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

OAI21xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_36),
.B(n_26),
.Y(n_43)
);

NAND5xp2_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_19),
.C(n_26),
.D(n_2),
.E(n_4),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NAND2xp33_ASAP7_75t_R g46 ( 
.A(n_45),
.B(n_5),
.Y(n_46)
);

NOR3xp33_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_26),
.C(n_7),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

OAI22xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_50)
);

AOI322xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_48),
.A3(n_17),
.B1(n_16),
.B2(n_14),
.C1(n_21),
.C2(n_20),
.Y(n_51)
);


endmodule