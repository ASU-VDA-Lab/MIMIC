module fake_netlist_628_3624_n_29 (n_7, n_9, n_11, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_29);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_29;

wire n_21;
wire n_18;
wire n_22;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_8),
.B(n_6),
.Y(n_17)
);

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_2),
.B(n_11),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_1),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_9),
.B(n_3),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_SL g21 ( 
.A(n_16),
.B(n_19),
.C(n_20),
.Y(n_21)
);

OAI221xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_7),
.B1(n_5),
.B2(n_4),
.C(n_0),
.Y(n_22)
);

OAI21x1_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_18),
.B(n_17),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_4),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_22),
.B1(n_23),
.B2(n_5),
.C(n_7),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_25),
.B1(n_12),
.B2(n_10),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_29)
);


endmodule