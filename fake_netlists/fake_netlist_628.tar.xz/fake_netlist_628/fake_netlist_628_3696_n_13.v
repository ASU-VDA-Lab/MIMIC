module fake_netlist_628_3696_n_13 (n_1, n_2, n_0, n_13);

input n_1;
input n_2;
input n_0;

output n_13;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_12;
wire n_3;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

BUFx10_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_2),
.Y(n_5)
);

CKINVDCx20_ASAP7_75t_R g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_0),
.B1(n_8),
.B2(n_11),
.Y(n_13)
);


endmodule