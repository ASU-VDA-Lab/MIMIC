module fake_netlist_628_1088_n_24 (n_1, n_2, n_3, n_0, n_24);

input n_1;
input n_2;
input n_3;
input n_0;

output n_24;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_4;
wire n_7;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_5;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_1),
.B(n_3),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_6),
.B(n_2),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_5),
.Y(n_14)
);

AOI33xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_9),
.A3(n_4),
.B1(n_10),
.B2(n_11),
.B3(n_12),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_11),
.B(n_4),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_13),
.B1(n_17),
.B2(n_16),
.C(n_12),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_10),
.B1(n_12),
.B2(n_2),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_14),
.B(n_16),
.C(n_12),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_17),
.B1(n_12),
.B2(n_15),
.C(n_2),
.Y(n_21)
);

AO22x2_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_17),
.B1(n_3),
.B2(n_12),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_12),
.B1(n_17),
.B2(n_14),
.C(n_9),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_22),
.Y(n_24)
);


endmodule