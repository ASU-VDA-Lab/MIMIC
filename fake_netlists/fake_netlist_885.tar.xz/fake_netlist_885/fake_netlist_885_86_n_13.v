module fake_netlist_885_86_n_13 (n_0, n_1, n_2, n_13);

input n_0;
input n_1;
input n_2;

output n_13;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

AND2x4_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

BUFx3_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVxp67_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI221x1_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B1(n_3),
.B2(n_4),
.C(n_5),
.Y(n_10)
);

AOI321xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_6),
.A3(n_2),
.B1(n_0),
.B2(n_1),
.C(n_5),
.Y(n_11)
);

AOI22x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_6),
.B1(n_2),
.B2(n_1),
.Y(n_12)
);

OAI222xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_2),
.B1(n_6),
.B2(n_10),
.C1(n_11),
.C2(n_9),
.Y(n_13)
);


endmodule