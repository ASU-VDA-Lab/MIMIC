module fake_netlist_885_4620_n_16 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_16);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_16;

wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_3),
.B(n_6),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_1),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B1(n_10),
.B2(n_8),
.C(n_7),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B(n_2),
.C(n_1),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_0),
.B(n_2),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_4),
.B1(n_5),
.B2(n_13),
.Y(n_16)
);


endmodule