module fake_netlist_885_1914_n_13 (n_0, n_1, n_2, n_13);

input n_0;
input n_1;
input n_2;

output n_13;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

INVx1_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AOI322xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_6),
.C1(n_4),
.C2(n_3),
.Y(n_9)
);

OAI211xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_8),
.C(n_1),
.Y(n_10)
);

INVxp67_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AO21x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_2),
.Y(n_13)
);


endmodule