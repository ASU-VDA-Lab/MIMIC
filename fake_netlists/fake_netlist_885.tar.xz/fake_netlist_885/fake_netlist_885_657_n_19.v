module fake_netlist_885_657_n_19 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_19);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_19;

wire n_15;
wire n_11;
wire n_16;
wire n_12;
wire n_17;
wire n_18;
wire n_13;
wire n_14;
wire n_10;

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_4),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_3),
.Y(n_12)
);

AND3x2_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_8),
.C(n_1),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_6),
.C(n_0),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_11),
.B1(n_10),
.B2(n_13),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_17),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_12),
.B1(n_6),
.B2(n_2),
.Y(n_19)
);


endmodule