module fake_netlist_885_2437_n_9 (n_0, n_1, n_9);

input n_0;
input n_1;

output n_9;

wire n_5;
wire n_2;
wire n_3;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

INVx4_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVx2_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

OAI311xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.A3(n_0),
.B1(n_2),
.C1(n_3),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);


endmodule