module fake_netlist_885_1073_n_11 (n_0, n_1, n_2, n_11);

input n_0;
input n_1;
input n_2;

output n_11;

wire n_5;
wire n_3;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

BUFx3_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AND2x4_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AOI31xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_4),
.A3(n_6),
.B(n_5),
.Y(n_8)
);

OAI221xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_6),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_2),
.B1(n_6),
.B2(n_9),
.Y(n_11)
);


endmodule