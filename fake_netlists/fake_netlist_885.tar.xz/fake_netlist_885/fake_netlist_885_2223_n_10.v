module fake_netlist_885_2223_n_10 (n_0, n_1, n_2, n_10);

input n_0;
input n_1;
input n_2;

output n_10;

wire n_5;
wire n_3;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

CKINVDCx5p33_ASAP7_75t_R g3 ( 
.A(n_2),
.Y(n_3)
);

INVx3_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_3),
.B1(n_4),
.B2(n_5),
.Y(n_7)
);

OAI221xp5_ASAP7_75t_SL g8 ( 
.A1(n_7),
.A2(n_4),
.B1(n_6),
.B2(n_3),
.C(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI222xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_4),
.C2(n_3),
.Y(n_10)
);


endmodule