module fake_netlist_885_923_n_12 (n_0, n_1, n_12);

input n_0;
input n_1;

output n_12;

wire n_5;
wire n_2;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

AND2x2_ASAP7_75t_SL g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

AND2x2_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_SL g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B1(n_4),
.B2(n_1),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_4),
.Y(n_8)
);

AOI211xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_6),
.B(n_2),
.C(n_4),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_0),
.B1(n_1),
.B2(n_10),
.Y(n_12)
);


endmodule