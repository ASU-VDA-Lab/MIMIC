module fake_netlist_879_229_n_60 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_60);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_60;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_19;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_31;
wire n_21;
wire n_22;
wire n_25;
wire n_32;
wire n_41;
wire n_42;
wire n_35;
wire n_57;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;
wire n_56;

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

NAND2xp33_ASAP7_75t_L g20 ( 
.A(n_7),
.B(n_14),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_9),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_6),
.B(n_4),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_15),
.B(n_5),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_13),
.B(n_8),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_16),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

NAND2x1p5_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_12),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_19),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_SL g31 ( 
.A1(n_27),
.A2(n_25),
.B(n_22),
.C(n_18),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_21),
.B(n_23),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_27),
.A2(n_29),
.B(n_30),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_28),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_34),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_29),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_29),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_28),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

OAI21xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_39),
.B(n_38),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_31),
.B1(n_20),
.B2(n_18),
.C(n_26),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_42),
.A2(n_24),
.B1(n_39),
.B2(n_33),
.C(n_35),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_42),
.B1(n_24),
.B2(n_39),
.C(n_33),
.Y(n_49)
);

AOI211xp5_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_24),
.B(n_35),
.C(n_10),
.Y(n_50)
);

NOR3x1_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_11),
.C(n_9),
.Y(n_51)
);

AOI21xp5_ASAP7_75t_L g52 ( 
.A1(n_47),
.A2(n_1),
.B(n_2),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_SL g53 ( 
.A(n_50),
.B(n_10),
.C(n_14),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_0),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_0),
.Y(n_55)
);

AOI21xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_52),
.B(n_7),
.Y(n_56)
);

AOI22x1_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_29),
.B1(n_34),
.B2(n_52),
.Y(n_57)
);

XOR2xp5_ASAP7_75t_L g58 ( 
.A(n_54),
.B(n_53),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_57),
.Y(n_59)
);

AOI21xp5_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_56),
.B(n_58),
.Y(n_60)
);


endmodule