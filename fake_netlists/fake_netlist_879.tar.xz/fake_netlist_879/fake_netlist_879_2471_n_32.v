module fake_netlist_879_2471_n_32 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_32);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_32;

wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_31;
wire n_21;
wire n_22;
wire n_25;
wire n_26;
wire n_29;

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_7),
.B(n_15),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_3),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

A2O1A1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_16),
.B(n_13),
.C(n_14),
.Y(n_24)
);

INVx5_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

NOR3xp33_ASAP7_75t_SL g26 ( 
.A(n_24),
.B(n_19),
.C(n_20),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI33xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_21),
.A3(n_18),
.B1(n_25),
.B2(n_22),
.B3(n_10),
.Y(n_28)
);

NOR2x1_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_2),
.Y(n_29)
);

CKINVDCx14_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_11),
.B1(n_9),
.B2(n_6),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_1),
.B1(n_5),
.B2(n_4),
.Y(n_32)
);


endmodule