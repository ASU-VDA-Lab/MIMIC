module fake_netlist_879_2579_n_50 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_50);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_50;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_32;
wire n_42;
wire n_41;
wire n_35;
wire n_21;
wire n_25;
wire n_22;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_13),
.Y(n_16)
);

INVxp33_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_9),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_5),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_10),
.B(n_12),
.Y(n_21)
);

AO21x2_ASAP7_75t_L g22 ( 
.A1(n_0),
.A2(n_13),
.B(n_7),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_14),
.B(n_1),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_15),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_17),
.A2(n_12),
.B1(n_8),
.B2(n_11),
.Y(n_29)
);

CKINVDCx6p67_ASAP7_75t_R g30 ( 
.A(n_24),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_24),
.A2(n_23),
.B(n_20),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_20),
.B(n_8),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_23),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_19),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_30),
.B(n_18),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_28),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_33),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_34),
.B1(n_29),
.B2(n_32),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI222xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_37),
.B1(n_23),
.B2(n_26),
.C1(n_28),
.C2(n_39),
.Y(n_43)
);

OAI21xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_35),
.B(n_38),
.Y(n_44)
);

OAI211xp5_ASAP7_75t_SL g45 ( 
.A1(n_40),
.A2(n_31),
.B(n_21),
.C(n_25),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_R g47 ( 
.A(n_43),
.B(n_40),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_45),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_46),
.B1(n_47),
.B2(n_11),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_22),
.B1(n_3),
.B2(n_6),
.Y(n_50)
);


endmodule