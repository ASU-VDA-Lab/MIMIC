module fake_netlist_879_1157_n_92 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_26, n_10, n_8, n_92);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_26;
input n_10;
input n_8;

output n_92;

wire n_60;
wire n_52;
wire n_30;
wire n_64;
wire n_66;
wire n_65;
wire n_88;
wire n_91;
wire n_71;
wire n_80;
wire n_29;
wire n_69;
wire n_83;
wire n_51;
wire n_50;
wire n_55;
wire n_46;
wire n_54;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_62;
wire n_44;
wire n_79;
wire n_87;
wire n_33;
wire n_77;
wire n_53;
wire n_90;
wire n_81;
wire n_84;
wire n_61;
wire n_43;
wire n_48;
wire n_72;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_34;
wire n_37;
wire n_75;
wire n_47;
wire n_68;
wire n_86;
wire n_63;
wire n_85;
wire n_49;
wire n_58;
wire n_67;
wire n_35;
wire n_57;
wire n_36;
wire n_45;
wire n_73;
wire n_89;
wire n_82;
wire n_78;

AND2x4_ASAP7_75t_L g29 ( 
.A(n_15),
.B(n_11),
.Y(n_29)
);

NOR2x1_ASAP7_75t_L g30 ( 
.A(n_20),
.B(n_10),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_13),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_20),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_12),
.B(n_18),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_19),
.B(n_7),
.Y(n_36)
);

AOI22x1_ASAP7_75t_SL g37 ( 
.A1(n_14),
.A2(n_23),
.B1(n_16),
.B2(n_2),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_24),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_3),
.B(n_9),
.Y(n_39)
);

INVx5_ASAP7_75t_L g40 ( 
.A(n_19),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_17),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_1),
.B(n_27),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_21),
.Y(n_43)
);

O2A1O1Ixp5_ASAP7_75t_L g44 ( 
.A1(n_34),
.A2(n_23),
.B(n_24),
.C(n_25),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_28),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_40),
.B(n_33),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_40),
.B(n_27),
.Y(n_47)
);

NOR3xp33_ASAP7_75t_L g48 ( 
.A(n_33),
.B(n_32),
.C(n_43),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_40),
.Y(n_49)
);

OR2x6_ASAP7_75t_L g50 ( 
.A(n_34),
.B(n_43),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_L g51 ( 
.A1(n_45),
.A2(n_39),
.B(n_31),
.Y(n_51)
);

AOI21xp33_ASAP7_75t_L g52 ( 
.A1(n_46),
.A2(n_47),
.B(n_44),
.Y(n_52)
);

INVx1_ASAP7_75t_SL g53 ( 
.A(n_46),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_48),
.B(n_49),
.Y(n_54)
);

OR2x2_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_54),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

INVxp67_ASAP7_75t_SL g57 ( 
.A(n_51),
.Y(n_57)
);

OR2x2_ASAP7_75t_L g58 ( 
.A(n_52),
.B(n_50),
.Y(n_58)
);

BUFx2_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_57),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_58),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_61),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_60),
.Y(n_64)
);

AND2x2_ASAP7_75t_L g65 ( 
.A(n_62),
.B(n_55),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_60),
.B(n_42),
.Y(n_66)
);

INVx2_ASAP7_75t_L g67 ( 
.A(n_59),
.Y(n_67)
);

OAI21xp5_ASAP7_75t_L g68 ( 
.A1(n_66),
.A2(n_59),
.B(n_36),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_63),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_63),
.Y(n_70)
);

CKINVDCx20_ASAP7_75t_R g71 ( 
.A(n_65),
.Y(n_71)
);

AOI22xp5_ASAP7_75t_L g72 ( 
.A1(n_65),
.A2(n_67),
.B1(n_64),
.B2(n_37),
.Y(n_72)
);

AOI21xp5_ASAP7_75t_L g73 ( 
.A1(n_64),
.A2(n_29),
.B(n_31),
.Y(n_73)
);

NOR2x1_ASAP7_75t_L g74 ( 
.A(n_71),
.B(n_67),
.Y(n_74)
);

AOI221xp5_ASAP7_75t_L g75 ( 
.A1(n_72),
.A2(n_38),
.B1(n_41),
.B2(n_42),
.C(n_35),
.Y(n_75)
);

NAND3xp33_ASAP7_75t_L g76 ( 
.A(n_68),
.B(n_37),
.C(n_73),
.Y(n_76)
);

OAI211xp5_ASAP7_75t_L g77 ( 
.A1(n_71),
.A2(n_30),
.B(n_38),
.C(n_41),
.Y(n_77)
);

AOI221xp5_ASAP7_75t_L g78 ( 
.A1(n_69),
.A2(n_42),
.B1(n_35),
.B2(n_40),
.C(n_29),
.Y(n_78)
);

NOR2xp33_ASAP7_75t_L g79 ( 
.A(n_70),
.B(n_50),
.Y(n_79)
);

NAND4xp75_ASAP7_75t_L g80 ( 
.A(n_72),
.B(n_50),
.C(n_22),
.D(n_21),
.Y(n_80)
);

NOR2xp67_ASAP7_75t_L g81 ( 
.A(n_77),
.B(n_79),
.Y(n_81)
);

AND2x2_ASAP7_75t_L g82 ( 
.A(n_74),
.B(n_35),
.Y(n_82)
);

AND2x4_ASAP7_75t_L g83 ( 
.A(n_76),
.B(n_29),
.Y(n_83)
);

NAND2xp5_ASAP7_75t_SL g84 ( 
.A(n_75),
.B(n_25),
.Y(n_84)
);

OR2x2_ASAP7_75t_L g85 ( 
.A(n_80),
.B(n_26),
.Y(n_85)
);

NAND3xp33_ASAP7_75t_SL g86 ( 
.A(n_78),
.B(n_18),
.C(n_14),
.Y(n_86)
);

AO22x2_ASAP7_75t_SL g87 ( 
.A1(n_82),
.A2(n_85),
.B1(n_81),
.B2(n_86),
.Y(n_87)
);

OAI22xp5_ASAP7_75t_L g88 ( 
.A1(n_83),
.A2(n_26),
.B1(n_17),
.B2(n_6),
.Y(n_88)
);

NAND2xp5_ASAP7_75t_L g89 ( 
.A(n_83),
.B(n_5),
.Y(n_89)
);

OAI21xp5_ASAP7_75t_SL g90 ( 
.A1(n_88),
.A2(n_86),
.B(n_84),
.Y(n_90)
);

AOI211xp5_ASAP7_75t_L g91 ( 
.A1(n_89),
.A2(n_0),
.B(n_4),
.C(n_8),
.Y(n_91)
);

AO21x2_ASAP7_75t_L g92 ( 
.A1(n_90),
.A2(n_87),
.B(n_91),
.Y(n_92)
);


endmodule