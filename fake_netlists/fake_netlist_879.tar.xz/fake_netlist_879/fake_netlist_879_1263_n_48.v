module fake_netlist_879_1263_n_48 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_48);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_48;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_1),
.Y(n_20)
);

OA21x2_ASAP7_75t_L g21 ( 
.A1(n_0),
.A2(n_14),
.B(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_15),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_25),
.B(n_8),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_26),
.B1(n_29),
.B2(n_28),
.C(n_23),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_SL g35 ( 
.A(n_30),
.B(n_27),
.C(n_8),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_31),
.B1(n_24),
.B2(n_33),
.C(n_21),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_33),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_21),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_18),
.C(n_16),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_17),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_40),
.B(n_41),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_13),
.Y(n_43)
);

INVx1_ASAP7_75t_SL g44 ( 
.A(n_41),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_SL g45 ( 
.A(n_44),
.B(n_42),
.C(n_43),
.Y(n_45)
);

NOR2x1_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_10),
.Y(n_46)
);

BUFx6f_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_46),
.B1(n_12),
.B2(n_19),
.Y(n_48)
);


endmodule