module fake_netlist_879_2266_n_55 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_55);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_55;

wire n_51;
wire n_33;
wire n_50;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_16;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_19;
wire n_12;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_32;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_10;
wire n_29;
wire n_36;
wire n_45;
wire n_44;
wire n_48;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

NAND2xp33_ASAP7_75t_R g11 ( 
.A(n_4),
.B(n_5),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_3),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_R g14 ( 
.A(n_3),
.B(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_1),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_9),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_8),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_0),
.B(n_8),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_0),
.B(n_7),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_SL g21 ( 
.A1(n_11),
.A2(n_2),
.B(n_7),
.C(n_6),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_12),
.A2(n_13),
.B(n_18),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

BUFx4f_ASAP7_75t_L g24 ( 
.A(n_12),
.Y(n_24)
);

O2A1O1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_17),
.A2(n_1),
.B(n_2),
.C(n_9),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_12),
.B(n_10),
.Y(n_26)
);

CKINVDCx16_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

CKINVDCx11_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

AO31x2_ASAP7_75t_L g29 ( 
.A1(n_19),
.A2(n_14),
.A3(n_12),
.B(n_10),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_22),
.B(n_16),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_20),
.B(n_24),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_21),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_24),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_25),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

AOI21xp5_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_37),
.B(n_35),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_32),
.B1(n_31),
.B2(n_27),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_35),
.A2(n_32),
.B1(n_30),
.B2(n_29),
.Y(n_40)
);

XNOR2xp5_ASAP7_75t_L g41 ( 
.A(n_34),
.B(n_36),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_35),
.Y(n_42)
);

AOI211xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_36),
.B(n_34),
.C(n_33),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_42),
.B1(n_40),
.B2(n_34),
.C(n_37),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_L g45 ( 
.A1(n_38),
.A2(n_33),
.B(n_35),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

OAI22x1_ASAP7_75t_SL g47 ( 
.A1(n_43),
.A2(n_28),
.B1(n_29),
.B2(n_33),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_46),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_35),
.Y(n_51)
);

INVx3_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

AO22x2_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_29),
.B1(n_47),
.B2(n_49),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_48),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_L g55 ( 
.A1(n_53),
.A2(n_50),
.B1(n_52),
.B2(n_54),
.Y(n_55)
);


endmodule