module fake_netlist_879_2406_n_23 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_23);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_23;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_18;
wire n_17;
wire n_13;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_4),
.Y(n_12)
);

CKINVDCx6p67_ASAP7_75t_R g13 ( 
.A(n_9),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_1),
.B(n_3),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_0),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_0),
.B(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NOR2x1_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_17),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_11),
.B1(n_14),
.B2(n_12),
.C(n_13),
.Y(n_20)
);

NAND2x1p5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

XNOR2x1_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_10),
.Y(n_23)
);


endmodule