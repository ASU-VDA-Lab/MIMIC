module fake_netlist_879_200_n_62 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_10, n_8, n_62);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_10;
input n_8;

output n_62;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_54;
wire n_28;
wire n_53;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_35;
wire n_32;
wire n_42;
wire n_41;
wire n_57;
wire n_43;
wire n_26;
wire n_44;
wire n_29;
wire n_45;
wire n_48;
wire n_36;
wire n_38;
wire n_56;

INVx1_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

OAI21x1_ASAP7_75t_L g28 ( 
.A1(n_6),
.A2(n_7),
.B(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_19),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_9),
.B(n_1),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_13),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_13),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_2),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_8),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_4),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_0),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_26),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_34),
.B(n_25),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_29),
.Y(n_40)
);

AND2x6_ASAP7_75t_SL g41 ( 
.A(n_33),
.B(n_21),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_35),
.B1(n_32),
.B2(n_31),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_31),
.B1(n_34),
.B2(n_35),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_38),
.A2(n_37),
.B(n_27),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_42),
.B1(n_40),
.B2(n_31),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_38),
.Y(n_47)
);

NAND2x1p5_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_28),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_38),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_30),
.Y(n_50)
);

OAI22xp5_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_32),
.B1(n_36),
.B2(n_41),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

AOI211x1_ASAP7_75t_SL g53 ( 
.A1(n_51),
.A2(n_25),
.B(n_24),
.C(n_21),
.Y(n_53)
);

NAND4xp25_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_23),
.C(n_22),
.D(n_20),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_17),
.Y(n_55)
);

INVx1_ASAP7_75t_SL g56 ( 
.A(n_55),
.Y(n_56)
);

NOR3xp33_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_16),
.C(n_15),
.Y(n_57)
);

NOR2x1p5_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_10),
.Y(n_58)
);

AND2x2_ASAP7_75t_SL g59 ( 
.A(n_55),
.B(n_14),
.Y(n_59)
);

NOR2xp67_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_18),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_59),
.Y(n_61)
);

AOI222xp33_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_3),
.B1(n_11),
.B2(n_57),
.C1(n_58),
.C2(n_60),
.Y(n_62)
);


endmodule