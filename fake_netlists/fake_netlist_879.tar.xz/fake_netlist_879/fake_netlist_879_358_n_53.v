module fake_netlist_879_358_n_53 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_53);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_53;

wire n_51;
wire n_33;
wire n_50;
wire n_15;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_16;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_32;
wire n_22;
wire n_14;
wire n_25;
wire n_35;
wire n_21;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

NAND2x1_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_10),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_4),
.A2(n_13),
.B1(n_11),
.B2(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx5_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_18),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_16),
.B(n_12),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_12),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

OR2x2_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_17),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_26),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_28),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_28),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_33),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_33),
.Y(n_40)
);

OAI21xp33_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_20),
.B(n_15),
.Y(n_41)
);

AOI332xp33_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_20),
.A3(n_10),
.B1(n_8),
.B2(n_5),
.B3(n_9),
.C1(n_11),
.C2(n_21),
.Y(n_42)
);

OAI311xp33_ASAP7_75t_L g43 ( 
.A1(n_37),
.A2(n_39),
.A3(n_40),
.B1(n_21),
.C1(n_30),
.Y(n_43)
);

INVxp67_ASAP7_75t_L g44 ( 
.A(n_38),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

INVx1_ASAP7_75t_SL g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_41),
.Y(n_48)
);

BUFx3_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

AOI22x1_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_42),
.B1(n_14),
.B2(n_2),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_51),
.B(n_46),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_L g53 ( 
.A(n_52),
.B(n_50),
.C(n_49),
.Y(n_53)
);


endmodule