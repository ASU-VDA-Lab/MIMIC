module fake_netlist_879_2161_n_52 (n_3, n_15, n_11, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_52);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_52;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_28;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_25;
wire n_35;
wire n_41;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_45;
wire n_44;
wire n_48;
wire n_38;

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_10),
.B(n_12),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_13),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_14),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_0),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_9),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_12),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_R g34 ( 
.A(n_32),
.B(n_23),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_24),
.B(n_23),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_25),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_30),
.Y(n_37)
);

INVxp67_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_29),
.B(n_28),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_35),
.B1(n_34),
.B2(n_26),
.C(n_27),
.Y(n_40)
);

OAI22xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_31),
.B1(n_15),
.B2(n_1),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_31),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

XOR2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_21),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_R g45 ( 
.A(n_43),
.B(n_18),
.Y(n_45)
);

NAND2xp33_ASAP7_75t_R g46 ( 
.A(n_45),
.B(n_17),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

XNOR2xp5_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_11),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

NOR3xp33_ASAP7_75t_SL g50 ( 
.A(n_49),
.B(n_3),
.C(n_5),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

AOI322xp5_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_2),
.A3(n_4),
.B1(n_6),
.B2(n_7),
.C1(n_16),
.C2(n_50),
.Y(n_52)
);


endmodule