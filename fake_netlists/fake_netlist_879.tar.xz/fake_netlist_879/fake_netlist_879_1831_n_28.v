module fake_netlist_879_1831_n_28 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_28);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_28;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_12),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_8),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_3),
.B(n_11),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_1),
.B1(n_5),
.B2(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

AOI21xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_18),
.B(n_17),
.Y(n_21)
);

OAI33xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_15),
.A3(n_19),
.B1(n_14),
.B2(n_16),
.B3(n_2),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OAI22xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_17),
.B1(n_15),
.B2(n_18),
.Y(n_24)
);

AND2x2_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

OAI221xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_2),
.B1(n_5),
.B2(n_4),
.C(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI321xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_25),
.A3(n_3),
.B1(n_0),
.B2(n_9),
.C(n_10),
.Y(n_28)
);


endmodule