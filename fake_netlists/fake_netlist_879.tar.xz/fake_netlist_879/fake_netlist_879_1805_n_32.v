module fake_netlist_879_1805_n_32 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_32);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_32;

wire n_15;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_29;

BUFx3_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

XOR2xp5_ASAP7_75t_L g16 ( 
.A(n_4),
.B(n_12),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_5),
.Y(n_19)
);

NAND3x1_ASAP7_75t_L g20 ( 
.A(n_6),
.B(n_8),
.C(n_11),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_15),
.A2(n_10),
.B(n_3),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_14),
.B(n_1),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_22),
.B(n_18),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_14),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_19),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_20),
.B1(n_24),
.B2(n_15),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_26),
.B(n_17),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

XNOR2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_16),
.Y(n_30)
);

OAI22x1_ASAP7_75t_SL g31 ( 
.A1(n_29),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_31),
.B(n_0),
.Y(n_32)
);


endmodule