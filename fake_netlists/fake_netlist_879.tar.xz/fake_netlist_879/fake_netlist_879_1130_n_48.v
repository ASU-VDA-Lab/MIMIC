module fake_netlist_879_1130_n_48 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_48);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_48;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_13),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_11),
.A2(n_3),
.B1(n_4),
.B2(n_10),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_5),
.B(n_18),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_8),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_SL g30 ( 
.A(n_23),
.B(n_29),
.C(n_21),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_10),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_19),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_24),
.B1(n_26),
.B2(n_25),
.C(n_17),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_37),
.B(n_30),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_32),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_25),
.C(n_15),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

INVxp67_ASAP7_75t_SL g47 ( 
.A(n_45),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_2),
.A3(n_6),
.B1(n_7),
.B2(n_14),
.C1(n_20),
.C2(n_47),
.Y(n_48)
);


endmodule