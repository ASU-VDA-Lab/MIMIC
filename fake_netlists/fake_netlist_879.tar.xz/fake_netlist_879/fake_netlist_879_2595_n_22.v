module fake_netlist_879_2595_n_22 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_22);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_22;

wire n_15;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_14;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_4),
.Y(n_12)
);

BUFx4f_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_7),
.B(n_8),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_2),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_11),
.B(n_6),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_5),
.B(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI32xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.A3(n_15),
.B1(n_16),
.B2(n_5),
.Y(n_19)
);

AOI21xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.B(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_0),
.B1(n_1),
.B2(n_3),
.C1(n_20),
.C2(n_4),
.Y(n_22)
);


endmodule