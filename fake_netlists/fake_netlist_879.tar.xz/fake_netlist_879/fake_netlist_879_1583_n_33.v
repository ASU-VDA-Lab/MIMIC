module fake_netlist_879_1583_n_33 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_33);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_33;

wire n_15;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_26;
wire n_29;

INVx3_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_8),
.B(n_0),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_3),
.B(n_13),
.Y(n_18)
);

INVx6_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx4_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_15),
.B(n_2),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_15),
.B(n_16),
.C(n_20),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_17),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_19),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_16),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AND3x4_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_1),
.C(n_0),
.Y(n_30)
);

OAI22x1_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_18),
.B1(n_2),
.B2(n_1),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI322xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_29),
.A3(n_11),
.B1(n_5),
.B2(n_6),
.C1(n_7),
.C2(n_12),
.Y(n_33)
);


endmodule