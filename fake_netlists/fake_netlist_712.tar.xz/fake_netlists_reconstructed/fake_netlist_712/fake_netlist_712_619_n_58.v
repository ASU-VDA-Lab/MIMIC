module fake_netlist_712_619_n_58 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_58);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_58;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_23;
wire n_41;
wire n_46;
wire n_29;
wire n_56;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_57;
wire n_19;
wire n_39;
wire n_55;

INVx1_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_0),
.B(n_17),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_18),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_4),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_2),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_10),
.Y(n_28)
);

NOR3xp33_ASAP7_75t_SL g29 ( 
.A(n_21),
.B(n_16),
.C(n_5),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_20),
.B(n_5),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_29),
.B1(n_32),
.B2(n_31),
.C(n_22),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AOI21xp33_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_23),
.B(n_26),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_27),
.B1(n_28),
.B2(n_24),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

OAI211xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_29),
.B(n_25),
.C(n_33),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

INVx3_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

OAI321xp33_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_43),
.A3(n_38),
.B1(n_28),
.B2(n_17),
.C(n_16),
.Y(n_47)
);

INVx3_ASAP7_75t_SL g48 ( 
.A(n_46),
.Y(n_48)
);

CKINVDCx16_ASAP7_75t_R g49 ( 
.A(n_45),
.Y(n_49)
);

OAI211xp5_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_33),
.B(n_28),
.C(n_36),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_46),
.Y(n_51)
);

OA22x2_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_18),
.B1(n_8),
.B2(n_1),
.Y(n_52)
);

NOR2x1_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_9),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_47),
.B(n_13),
.Y(n_54)
);

HB1xp67_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

OR2x2_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_14),
.Y(n_56)
);

OR3x2_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_47),
.C(n_15),
.Y(n_57)
);

AOI22xp33_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_55),
.B1(n_56),
.B2(n_53),
.Y(n_58)
);


endmodule