module fake_netlist_712_2000_n_7 (n_4, n_2, n_3, n_1, n_0, n_7);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_7;

wire n_5;
wire n_6;

OR2x6_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B1(n_4),
.B2(n_5),
.Y(n_7)
);


endmodule