module fake_netlist_712_616_n_26 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_26);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_26;

wire n_24;
wire n_21;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_7;
wire n_23;
wire n_12;
wire n_8;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_2),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_R g9 ( 
.A(n_0),
.B(n_3),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_6),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_1),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_8),
.B(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_12),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_13),
.B1(n_11),
.B2(n_5),
.C1(n_4),
.C2(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_13),
.Y(n_24)
);

AND2x4_ASAP7_75t_SL g25 ( 
.A(n_23),
.B(n_5),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_23),
.B1(n_24),
.B2(n_21),
.Y(n_26)
);


endmodule