module fake_netlist_712_1995_n_34 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_34);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_34;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_13;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;
wire n_12;

AND2x4_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_5),
.B(n_0),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_SL g20 ( 
.A(n_15),
.B(n_5),
.C(n_4),
.Y(n_20)
);

BUFx10_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx4_ASAP7_75t_SL g22 ( 
.A(n_19),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_18),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_13),
.C(n_17),
.D(n_12),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_22),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

OAI21xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_20),
.B(n_12),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_12),
.B1(n_16),
.B2(n_4),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

NAND2x1p5_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_16),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_16),
.A3(n_7),
.B1(n_32),
.B2(n_9),
.C1(n_1),
.C2(n_11),
.Y(n_34)
);


endmodule