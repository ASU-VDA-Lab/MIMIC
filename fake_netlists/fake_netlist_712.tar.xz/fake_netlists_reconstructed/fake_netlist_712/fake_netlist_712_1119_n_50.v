module fake_netlist_712_1119_n_50 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_50);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_50;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

OA21x2_ASAP7_75t_L g24 ( 
.A1(n_15),
.A2(n_10),
.B(n_22),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_7),
.B(n_9),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_19),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_3),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_SL g33 ( 
.A(n_26),
.B(n_18),
.C(n_16),
.Y(n_33)
);

OR2x6_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_18),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_0),
.Y(n_35)
);

OR2x6_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_29),
.Y(n_36)
);

OAI21x1_ASAP7_75t_SL g37 ( 
.A1(n_35),
.A2(n_32),
.B(n_24),
.Y(n_37)
);

OA21x2_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_32),
.B(n_23),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_31),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_31),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_38),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_33),
.Y(n_43)
);

AOI22x1_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_27),
.B1(n_30),
.B2(n_28),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_24),
.B1(n_25),
.B2(n_1),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_2),
.Y(n_46)
);

OAI21x1_ASAP7_75t_SL g47 ( 
.A1(n_44),
.A2(n_5),
.B(n_4),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_46),
.Y(n_48)
);

AOI21xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_8),
.B(n_6),
.Y(n_49)
);

OAI221xp5_ASAP7_75t_R g50 ( 
.A1(n_48),
.A2(n_11),
.B1(n_12),
.B2(n_20),
.C(n_49),
.Y(n_50)
);


endmodule