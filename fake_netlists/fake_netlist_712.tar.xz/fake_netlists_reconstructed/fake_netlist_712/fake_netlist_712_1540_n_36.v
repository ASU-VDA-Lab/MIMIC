module fake_netlist_712_1540_n_36 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_36);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_36;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_13;
wire n_33;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_19;
wire n_14;
wire n_12;

INVx2_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_10),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_17)
);

INVx4_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_0),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

NAND3xp33_ASAP7_75t_SL g21 ( 
.A(n_17),
.B(n_14),
.C(n_16),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_16),
.Y(n_22)
);

NOR4xp25_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_20),
.C(n_19),
.D(n_2),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_18),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_26),
.Y(n_29)
);

NAND4xp25_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_6),
.C(n_4),
.D(n_3),
.Y(n_30)
);

AO22x2_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_8),
.B1(n_7),
.B2(n_4),
.Y(n_31)
);

INVxp67_ASAP7_75t_SL g32 ( 
.A(n_29),
.Y(n_32)
);

NOR5xp2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_8),
.C(n_9),
.D(n_10),
.E(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_31),
.B1(n_33),
.B2(n_35),
.Y(n_36)
);


endmodule