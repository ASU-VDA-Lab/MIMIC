module fake_netlist_712_583_n_49 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_49);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_49;

wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_39;

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_11),
.B(n_0),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_5),
.Y(n_26)
);

CKINVDCx16_ASAP7_75t_R g27 ( 
.A(n_24),
.Y(n_27)
);

BUFx10_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

XOR2xp5_ASAP7_75t_L g29 ( 
.A(n_2),
.B(n_12),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_3),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_20),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_18),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_27),
.A2(n_33),
.B1(n_30),
.B2(n_29),
.Y(n_34)
);

A2O1A1Ixp33_ASAP7_75t_SL g35 ( 
.A1(n_25),
.A2(n_18),
.B(n_6),
.C(n_4),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_L g36 ( 
.A(n_28),
.B(n_7),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_28),
.B1(n_31),
.B2(n_26),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_32),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_8),
.Y(n_40)
);

OAI211xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_35),
.B(n_10),
.C(n_9),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI221x1_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_40),
.B1(n_15),
.B2(n_13),
.C(n_14),
.Y(n_43)
);

OAI21xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_17),
.B(n_16),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_44),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

OAI22x1_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_22),
.B1(n_21),
.B2(n_19),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_23),
.B1(n_46),
.B2(n_48),
.Y(n_49)
);


endmodule