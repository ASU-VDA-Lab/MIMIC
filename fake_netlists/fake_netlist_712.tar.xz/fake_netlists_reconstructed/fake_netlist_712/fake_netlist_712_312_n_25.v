module fake_netlist_712_312_n_25 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_25);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_25;

wire n_24;
wire n_21;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_12;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

CKINVDCx16_ASAP7_75t_R g11 ( 
.A(n_0),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

BUFx8_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_9),
.A2(n_3),
.B(n_1),
.Y(n_15)
);

AO31x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_9),
.A3(n_13),
.B(n_11),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_14),
.B(n_11),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND4xp25_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.C(n_13),
.D(n_17),
.Y(n_20)
);

O2A1O1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_16),
.B(n_10),
.C(n_12),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NOR2x1_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_1),
.Y(n_23)
);

AOI21xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_23),
.B(n_2),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_25)
);


endmodule