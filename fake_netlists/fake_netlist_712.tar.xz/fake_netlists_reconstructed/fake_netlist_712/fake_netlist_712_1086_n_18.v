module fake_netlist_712_1086_n_18 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_18);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_17;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

BUFx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_6),
.B1(n_3),
.B2(n_0),
.Y(n_11)
);

INVx4_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_13)
);

AO21x2_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_9),
.C(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);


endmodule