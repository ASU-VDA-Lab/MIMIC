module fake_netlist_712_2094_n_12 (n_0, n_2, n_1, n_12);

input n_0;
input n_2;
input n_1;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_3;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

INVx2_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_6),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_5),
.B(n_6),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B(n_0),
.C(n_2),
.Y(n_9)
);

AOI211xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_4),
.B(n_0),
.C(n_2),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_11),
.B(n_4),
.Y(n_12)
);


endmodule