module fake_netlist_712_95_n_32 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_32);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_32;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_28;
wire n_11;
wire n_19;
wire n_30;
wire n_25;
wire n_13;
wire n_14;
wire n_12;

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_7),
.B(n_10),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_12),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_14),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

NAND4xp25_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_17),
.C(n_15),
.D(n_13),
.Y(n_21)
);

AOI33xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_18),
.A3(n_12),
.B1(n_11),
.B2(n_5),
.B3(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx2_ASAP7_75t_SL g24 ( 
.A(n_21),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_19),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_19),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_24),
.B(n_19),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_27),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B1(n_19),
.B2(n_5),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_6),
.B1(n_9),
.B2(n_8),
.Y(n_32)
);


endmodule