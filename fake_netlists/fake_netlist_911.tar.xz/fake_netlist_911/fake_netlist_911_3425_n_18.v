module fake_netlist_911_3425_n_18 (n_0, n_2, n_3, n_4, n_1, n_18);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_18;

wire n_5;
wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_17;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_5),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OAI22xp33_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_5),
.B(n_8),
.C(n_0),
.Y(n_11)
);

XNOR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_0),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_11),
.B1(n_8),
.B2(n_9),
.C(n_1),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_2),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_5),
.B1(n_9),
.B2(n_4),
.C1(n_2),
.C2(n_3),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_3),
.B1(n_5),
.B2(n_13),
.Y(n_17)
);

OA21x2_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_5),
.B(n_16),
.Y(n_18)
);


endmodule