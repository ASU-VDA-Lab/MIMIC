module fake_netlist_911_446_n_65 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_65);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_65;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_63;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_19;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_40;
wire n_39;
wire n_17;
wire n_18;
wire n_61;
wire n_31;
wire n_21;
wire n_25;
wire n_22;
wire n_35;
wire n_32;
wire n_42;
wire n_41;
wire n_57;
wire n_43;
wire n_62;
wire n_26;
wire n_29;
wire n_44;
wire n_48;
wire n_45;
wire n_36;
wire n_38;
wire n_56;

INVx3_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_8),
.B(n_2),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_12),
.Y(n_26)
);

OA21x2_ASAP7_75t_L g27 ( 
.A1(n_15),
.A2(n_9),
.B(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_11),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_7),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_17),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_17),
.B(n_11),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_17),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_19),
.B(n_13),
.Y(n_34)
);

OR2x6_ASAP7_75t_L g35 ( 
.A(n_19),
.B(n_14),
.Y(n_35)
);

INVx4_ASAP7_75t_L g36 ( 
.A(n_25),
.Y(n_36)
);

OR2x2_ASAP7_75t_SL g37 ( 
.A(n_24),
.B(n_14),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_19),
.B(n_16),
.Y(n_38)
);

INVx3_ASAP7_75t_L g39 ( 
.A(n_19),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_18),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_22),
.B1(n_20),
.B2(n_30),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_SL g42 ( 
.A1(n_35),
.A2(n_26),
.B1(n_29),
.B2(n_20),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_L g43 ( 
.A1(n_37),
.A2(n_28),
.B1(n_21),
.B2(n_18),
.Y(n_43)
);

INVx4_ASAP7_75t_L g44 ( 
.A(n_32),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_39),
.B(n_21),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_35),
.A2(n_28),
.B1(n_23),
.B2(n_27),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_35),
.B1(n_38),
.B2(n_34),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

NAND2xp33_ASAP7_75t_R g49 ( 
.A(n_42),
.B(n_35),
.Y(n_49)
);

OAI22xp33_ASAP7_75t_L g50 ( 
.A1(n_41),
.A2(n_38),
.B1(n_34),
.B2(n_40),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_50),
.B(n_43),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

AO21x1_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_34),
.B(n_32),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_47),
.Y(n_54)
);

NOR2xp33_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_45),
.Y(n_55)
);

AND2x2_ASAP7_75t_SL g56 ( 
.A(n_52),
.B(n_34),
.Y(n_56)
);

NOR2xp33_ASAP7_75t_R g57 ( 
.A(n_56),
.B(n_16),
.Y(n_57)
);

AOI21xp5_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_27),
.B(n_40),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_L g59 ( 
.A1(n_54),
.A2(n_33),
.B1(n_31),
.B2(n_27),
.Y(n_59)
);

AOI22xp33_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_25),
.B1(n_36),
.B2(n_3),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_59),
.B(n_25),
.Y(n_61)
);

CKINVDCx16_ASAP7_75t_R g62 ( 
.A(n_58),
.Y(n_62)
);

HB1xp67_ASAP7_75t_L g63 ( 
.A(n_61),
.Y(n_63)
);

AND2x4_ASAP7_75t_L g64 ( 
.A(n_60),
.B(n_62),
.Y(n_64)
);

AOI22xp33_ASAP7_75t_L g65 ( 
.A1(n_64),
.A2(n_53),
.B1(n_63),
.B2(n_57),
.Y(n_65)
);


endmodule