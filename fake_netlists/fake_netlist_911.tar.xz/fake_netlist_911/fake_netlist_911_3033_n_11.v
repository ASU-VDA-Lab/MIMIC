module fake_netlist_911_3033_n_11 (n_0, n_2, n_3, n_4, n_1, n_11);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_11;

wire n_5;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_7;

O2A1O1Ixp5_ASAP7_75t_SL g5 ( 
.A1(n_1),
.A2(n_4),
.B(n_0),
.C(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_0),
.Y(n_7)
);

INVxp67_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

AND3x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_5),
.C(n_9),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);


endmodule