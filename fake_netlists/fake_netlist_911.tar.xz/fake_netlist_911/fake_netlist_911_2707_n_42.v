module fake_netlist_911_2707_n_42 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_42);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_42;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_41;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_9),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

CKINVDCx8_ASAP7_75t_R g24 ( 
.A(n_19),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_18),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_15),
.Y(n_27)
);

AO22x1_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_18),
.B1(n_1),
.B2(n_0),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

OR2x6_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_2),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_20),
.Y(n_31)
);

NAND4xp25_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_26),
.C(n_22),
.D(n_24),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_27),
.Y(n_33)
);

CKINVDCx16_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_32),
.Y(n_35)
);

NOR3xp33_ASAP7_75t_SL g36 ( 
.A(n_34),
.B(n_5),
.C(n_4),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_R g37 ( 
.A(n_36),
.B(n_6),
.Y(n_37)
);

NOR3x1_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_8),
.C(n_7),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_SL g40 ( 
.A(n_37),
.B(n_23),
.C(n_29),
.Y(n_40)
);

BUFx8_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AOI222xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_40),
.B1(n_13),
.B2(n_11),
.C1(n_14),
.C2(n_12),
.Y(n_42)
);


endmodule