module fake_netlist_911_571_n_22 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_22);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_22;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_14;
wire n_10;

INVx2_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_5),
.B(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

O2A1O1Ixp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_2),
.B(n_1),
.C(n_4),
.Y(n_14)
);

BUFx4f_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx8_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_4),
.Y(n_18)
);

AOI321xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.A3(n_7),
.B1(n_6),
.B2(n_14),
.C(n_15),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_11),
.B1(n_7),
.B2(n_6),
.Y(n_22)
);


endmodule