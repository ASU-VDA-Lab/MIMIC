module fake_netlist_911_2965_n_55 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_55);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_55;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_35;
wire n_41;
wire n_42;
wire n_32;
wire n_25;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

AND2x6_ASAP7_75t_L g23 ( 
.A(n_8),
.B(n_3),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_10),
.B(n_19),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_21),
.B(n_5),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_12),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_7),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_18),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_15),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_11),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_29),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_24),
.B(n_30),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_34),
.A2(n_21),
.B1(n_1),
.B2(n_0),
.Y(n_37)
);

INVx4_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_26),
.Y(n_39)
);

BUFx2_ASAP7_75t_SL g40 ( 
.A(n_39),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

BUFx4_ASAP7_75t_R g42 ( 
.A(n_35),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

OAI22xp33_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_36),
.B1(n_31),
.B2(n_27),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_43),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_37),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_R g47 ( 
.A(n_46),
.B(n_42),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_32),
.Y(n_48)
);

INVxp67_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

AND2x2_ASAP7_75t_SL g50 ( 
.A(n_48),
.B(n_47),
.Y(n_50)
);

O2A1O1Ixp33_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_33),
.B(n_25),
.C(n_23),
.Y(n_51)
);

OAI221xp5_ASAP7_75t_R g52 ( 
.A1(n_50),
.A2(n_23),
.B1(n_6),
.B2(n_2),
.C(n_4),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_SL g53 ( 
.A(n_51),
.B(n_14),
.Y(n_53)
);

INVx4_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_53),
.B1(n_17),
.B2(n_16),
.Y(n_55)
);


endmodule