module fake_netlist_911_2802_n_18 (n_0, n_1, n_3, n_2, n_18);

input n_0;
input n_1;
input n_3;
input n_2;

output n_18;

wire n_5;
wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_17;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

AND2x4_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_2),
.B(n_0),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_SL g9 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_4),
.B1(n_8),
.B2(n_9),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_9),
.C(n_4),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_10),
.B1(n_11),
.B2(n_4),
.Y(n_14)
);

OAI322xp33_ASAP7_75t_SL g15 ( 
.A1(n_13),
.A2(n_11),
.A3(n_2),
.B1(n_3),
.B2(n_1),
.C1(n_4),
.C2(n_7),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_7),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_14),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_3),
.B1(n_7),
.B2(n_17),
.C1(n_6),
.C2(n_12),
.Y(n_18)
);


endmodule