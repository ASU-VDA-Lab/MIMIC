module fake_netlist_911_1598_n_86 (n_3, n_15, n_11, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_86);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_86;

wire n_60;
wire n_52;
wire n_30;
wire n_64;
wire n_66;
wire n_65;
wire n_27;
wire n_71;
wire n_80;
wire n_29;
wire n_69;
wire n_83;
wire n_51;
wire n_50;
wire n_55;
wire n_46;
wire n_54;
wire n_28;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_62;
wire n_26;
wire n_44;
wire n_79;
wire n_33;
wire n_24;
wire n_77;
wire n_53;
wire n_81;
wire n_84;
wire n_61;
wire n_43;
wire n_48;
wire n_72;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_34;
wire n_37;
wire n_75;
wire n_47;
wire n_68;
wire n_63;
wire n_85;
wire n_58;
wire n_49;
wire n_67;
wire n_25;
wire n_35;
wire n_57;
wire n_36;
wire n_45;
wire n_73;
wire n_82;
wire n_78;

INVx1_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_15),
.B(n_8),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_12),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_L g31 ( 
.A(n_16),
.B(n_13),
.C(n_14),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_16),
.B(n_1),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_11),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_23),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_5),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_9),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_7),
.Y(n_38)
);

BUFx10_ASAP7_75t_L g39 ( 
.A(n_4),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_28),
.Y(n_41)
);

INVx2_ASAP7_75t_SL g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_36),
.Y(n_43)
);

INVx6_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

INVx3_ASAP7_75t_L g45 ( 
.A(n_26),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_24),
.B(n_17),
.Y(n_46)
);

NOR3xp33_ASAP7_75t_SL g47 ( 
.A(n_31),
.B(n_18),
.C(n_17),
.Y(n_47)
);

NOR2x1p5_ASAP7_75t_L g48 ( 
.A(n_25),
.B(n_18),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_R g49 ( 
.A(n_37),
.B(n_6),
.Y(n_49)
);

OR2x6_ASAP7_75t_L g50 ( 
.A(n_30),
.B(n_19),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_35),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_45),
.Y(n_52)
);

INVx8_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_45),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_38),
.Y(n_55)
);

OAI22xp33_ASAP7_75t_L g56 ( 
.A1(n_50),
.A2(n_27),
.B1(n_29),
.B2(n_28),
.Y(n_56)
);

BUFx2_ASAP7_75t_L g57 ( 
.A(n_44),
.Y(n_57)
);

AOI22xp33_ASAP7_75t_L g58 ( 
.A1(n_48),
.A2(n_32),
.B1(n_33),
.B2(n_29),
.Y(n_58)
);

INVx2_ASAP7_75t_SL g59 ( 
.A(n_44),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_54),
.Y(n_60)
);

BUFx3_ASAP7_75t_L g61 ( 
.A(n_53),
.Y(n_61)
);

HB1xp67_ASAP7_75t_L g62 ( 
.A(n_53),
.Y(n_62)
);

CKINVDCx20_ASAP7_75t_R g63 ( 
.A(n_53),
.Y(n_63)
);

OAI21x1_ASAP7_75t_L g64 ( 
.A1(n_55),
.A2(n_46),
.B(n_40),
.Y(n_64)
);

BUFx3_ASAP7_75t_L g65 ( 
.A(n_52),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_64),
.Y(n_66)
);

INVx1_ASAP7_75t_SL g67 ( 
.A(n_61),
.Y(n_67)
);

INVx1_ASAP7_75t_SL g68 ( 
.A(n_61),
.Y(n_68)
);

INVx3_ASAP7_75t_L g69 ( 
.A(n_65),
.Y(n_69)
);

NOR3xp33_ASAP7_75t_L g70 ( 
.A(n_62),
.B(n_56),
.C(n_57),
.Y(n_70)
);

NOR2xp33_ASAP7_75t_L g71 ( 
.A(n_67),
.B(n_62),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_66),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_68),
.Y(n_73)
);

OAI21xp5_ASAP7_75t_SL g74 ( 
.A1(n_70),
.A2(n_58),
.B(n_43),
.Y(n_74)
);

AOI22xp5_ASAP7_75t_L g75 ( 
.A1(n_69),
.A2(n_63),
.B1(n_42),
.B2(n_59),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_73),
.B(n_71),
.Y(n_76)
);

OAI221xp5_ASAP7_75t_L g77 ( 
.A1(n_75),
.A2(n_47),
.B1(n_65),
.B2(n_60),
.C(n_69),
.Y(n_77)
);

BUFx12f_ASAP7_75t_L g78 ( 
.A(n_72),
.Y(n_78)
);

OAI21xp5_ASAP7_75t_L g79 ( 
.A1(n_74),
.A2(n_49),
.B(n_19),
.Y(n_79)
);

INVx2_ASAP7_75t_SL g80 ( 
.A(n_78),
.Y(n_80)
);

CKINVDCx5p33_ASAP7_75t_R g81 ( 
.A(n_76),
.Y(n_81)
);

CKINVDCx5p33_ASAP7_75t_R g82 ( 
.A(n_79),
.Y(n_82)
);

AOI22xp33_ASAP7_75t_L g83 ( 
.A1(n_77),
.A2(n_34),
.B1(n_41),
.B2(n_20),
.Y(n_83)
);

CKINVDCx20_ASAP7_75t_R g84 ( 
.A(n_81),
.Y(n_84)
);

HB1xp67_ASAP7_75t_L g85 ( 
.A(n_82),
.Y(n_85)
);

AOI322xp5_ASAP7_75t_L g86 ( 
.A1(n_85),
.A2(n_41),
.A3(n_80),
.B1(n_83),
.B2(n_82),
.C1(n_84),
.C2(n_81),
.Y(n_86)
);


endmodule