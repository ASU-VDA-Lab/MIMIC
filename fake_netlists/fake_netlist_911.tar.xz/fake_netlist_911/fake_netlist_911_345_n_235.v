module fake_netlist_911_345_n_235 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_26, n_10, n_8, n_235);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_26;
input n_10;
input n_8;

output n_235;

wire n_118;
wire n_100;
wire n_60;
wire n_104;
wire n_216;
wire n_101;
wire n_52;
wire n_99;
wire n_127;
wire n_151;
wire n_152;
wire n_111;
wire n_185;
wire n_154;
wire n_153;
wire n_193;
wire n_30;
wire n_116;
wire n_164;
wire n_64;
wire n_102;
wire n_93;
wire n_157;
wire n_66;
wire n_65;
wire n_143;
wire n_88;
wire n_186;
wire n_195;
wire n_169;
wire n_192;
wire n_197;
wire n_212;
wire n_94;
wire n_198;
wire n_182;
wire n_206;
wire n_214;
wire n_91;
wire n_71;
wire n_135;
wire n_174;
wire n_224;
wire n_80;
wire n_229;
wire n_228;
wire n_149;
wire n_29;
wire n_201;
wire n_196;
wire n_69;
wire n_83;
wire n_207;
wire n_210;
wire n_134;
wire n_96;
wire n_128;
wire n_117;
wire n_131;
wire n_165;
wire n_190;
wire n_51;
wire n_50;
wire n_217;
wire n_162;
wire n_223;
wire n_55;
wire n_123;
wire n_234;
wire n_110;
wire n_46;
wire n_183;
wire n_144;
wire n_54;
wire n_211;
wire n_59;
wire n_227;
wire n_189;
wire n_177;
wire n_173;
wire n_166;
wire n_70;
wire n_40;
wire n_39;
wire n_132;
wire n_31;
wire n_225;
wire n_220;
wire n_42;
wire n_32;
wire n_41;
wire n_222;
wire n_126;
wire n_62;
wire n_120;
wire n_141;
wire n_148;
wire n_150;
wire n_226;
wire n_188;
wire n_44;
wire n_79;
wire n_187;
wire n_87;
wire n_142;
wire n_159;
wire n_115;
wire n_155;
wire n_230;
wire n_33;
wire n_184;
wire n_113;
wire n_233;
wire n_200;
wire n_129;
wire n_191;
wire n_209;
wire n_208;
wire n_172;
wire n_77;
wire n_107;
wire n_199;
wire n_95;
wire n_204;
wire n_53;
wire n_161;
wire n_180;
wire n_106;
wire n_137;
wire n_90;
wire n_167;
wire n_146;
wire n_81;
wire n_221;
wire n_84;
wire n_171;
wire n_140;
wire n_61;
wire n_130;
wire n_122;
wire n_43;
wire n_138;
wire n_170;
wire n_136;
wire n_139;
wire n_48;
wire n_72;
wire n_176;
wire n_181;
wire n_133;
wire n_76;
wire n_38;
wire n_56;
wire n_218;
wire n_175;
wire n_213;
wire n_74;
wire n_125;
wire n_34;
wire n_179;
wire n_103;
wire n_37;
wire n_160;
wire n_108;
wire n_75;
wire n_47;
wire n_68;
wire n_158;
wire n_86;
wire n_63;
wire n_163;
wire n_105;
wire n_215;
wire n_114;
wire n_124;
wire n_145;
wire n_85;
wire n_112;
wire n_156;
wire n_205;
wire n_232;
wire n_58;
wire n_49;
wire n_109;
wire n_147;
wire n_168;
wire n_67;
wire n_219;
wire n_202;
wire n_35;
wire n_57;
wire n_121;
wire n_97;
wire n_98;
wire n_231;
wire n_119;
wire n_178;
wire n_203;
wire n_36;
wire n_194;
wire n_45;
wire n_92;
wire n_89;
wire n_73;
wire n_82;
wire n_78;

CKINVDCx16_ASAP7_75t_R g29 ( 
.A(n_13),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_4),
.Y(n_32)
);

INVxp67_ASAP7_75t_SL g33 ( 
.A(n_26),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_19),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_5),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_14),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_6),
.Y(n_37)
);

CKINVDCx16_ASAP7_75t_R g38 ( 
.A(n_9),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_3),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_7),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_30),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_0),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_0),
.Y(n_43)
);

INVx6_ASAP7_75t_L g44 ( 
.A(n_29),
.Y(n_44)
);

INVx5_ASAP7_75t_L g45 ( 
.A(n_29),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_30),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_31),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_31),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_34),
.Y(n_49)
);

BUFx3_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

NOR2xp33_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_34),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_44),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_41),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_45),
.B(n_35),
.Y(n_54)
);

INVx3_ASAP7_75t_L g55 ( 
.A(n_42),
.Y(n_55)
);

AND2x4_ASAP7_75t_L g56 ( 
.A(n_42),
.B(n_37),
.Y(n_56)
);

OR2x6_ASAP7_75t_L g57 ( 
.A(n_44),
.B(n_39),
.Y(n_57)
);

BUFx8_ASAP7_75t_L g58 ( 
.A(n_42),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_SL g59 ( 
.A(n_45),
.B(n_36),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_41),
.Y(n_60)
);

O2A1O1Ixp33_ASAP7_75t_L g61 ( 
.A1(n_43),
.A2(n_39),
.B(n_32),
.C(n_36),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_45),
.B(n_40),
.Y(n_62)
);

AND2x4_ASAP7_75t_L g63 ( 
.A(n_57),
.B(n_45),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_55),
.Y(n_64)
);

NAND2xp5_ASAP7_75t_SL g65 ( 
.A(n_58),
.B(n_52),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_53),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_55),
.Y(n_67)
);

INVx4_ASAP7_75t_L g68 ( 
.A(n_57),
.Y(n_68)
);

NAND2xp5_ASAP7_75t_L g69 ( 
.A(n_49),
.B(n_47),
.Y(n_69)
);

CKINVDCx20_ASAP7_75t_R g70 ( 
.A(n_58),
.Y(n_70)
);

INVx4_ASAP7_75t_L g71 ( 
.A(n_57),
.Y(n_71)
);

AOI21xp5_ASAP7_75t_L g72 ( 
.A1(n_62),
.A2(n_48),
.B(n_46),
.Y(n_72)
);

INVx2_ASAP7_75t_L g73 ( 
.A(n_53),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_56),
.Y(n_74)
);

BUFx6f_ASAP7_75t_L g75 ( 
.A(n_50),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_56),
.Y(n_76)
);

BUFx3_ASAP7_75t_L g77 ( 
.A(n_58),
.Y(n_77)
);

AND2x4_ASAP7_75t_L g78 ( 
.A(n_68),
.B(n_56),
.Y(n_78)
);

INVx5_ASAP7_75t_L g79 ( 
.A(n_68),
.Y(n_79)
);

BUFx3_ASAP7_75t_L g80 ( 
.A(n_75),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_74),
.B(n_61),
.Y(n_81)
);

NAND2xp5_ASAP7_75t_L g82 ( 
.A(n_74),
.B(n_51),
.Y(n_82)
);

BUFx3_ASAP7_75t_L g83 ( 
.A(n_75),
.Y(n_83)
);

OAI21xp33_ASAP7_75t_L g84 ( 
.A1(n_69),
.A2(n_54),
.B(n_59),
.Y(n_84)
);

INVx2_ASAP7_75t_L g85 ( 
.A(n_64),
.Y(n_85)
);

INVx2_ASAP7_75t_L g86 ( 
.A(n_64),
.Y(n_86)
);

INVx2_ASAP7_75t_SL g87 ( 
.A(n_63),
.Y(n_87)
);

INVx2_ASAP7_75t_L g88 ( 
.A(n_67),
.Y(n_88)
);

AND2x2_ASAP7_75t_L g89 ( 
.A(n_63),
.B(n_32),
.Y(n_89)
);

AOI22xp33_ASAP7_75t_L g90 ( 
.A1(n_76),
.A2(n_41),
.B1(n_33),
.B2(n_60),
.Y(n_90)
);

OR2x6_ASAP7_75t_L g91 ( 
.A(n_78),
.B(n_77),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_85),
.Y(n_92)
);

INVx2_ASAP7_75t_L g93 ( 
.A(n_85),
.Y(n_93)
);

NOR2xp33_ASAP7_75t_R g94 ( 
.A(n_79),
.B(n_70),
.Y(n_94)
);

HB1xp67_ASAP7_75t_L g95 ( 
.A(n_79),
.Y(n_95)
);

INVx2_ASAP7_75t_L g96 ( 
.A(n_86),
.Y(n_96)
);

INVx2_ASAP7_75t_L g97 ( 
.A(n_86),
.Y(n_97)
);

INVx1_ASAP7_75t_L g98 ( 
.A(n_92),
.Y(n_98)
);

INVx2_ASAP7_75t_L g99 ( 
.A(n_92),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_93),
.Y(n_100)
);

INVx2_ASAP7_75t_L g101 ( 
.A(n_96),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_97),
.Y(n_102)
);

OR2x2_ASAP7_75t_L g103 ( 
.A(n_91),
.B(n_89),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_95),
.Y(n_104)
);

HB1xp67_ASAP7_75t_L g105 ( 
.A(n_99),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_99),
.Y(n_106)
);

INVx2_ASAP7_75t_L g107 ( 
.A(n_100),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_98),
.Y(n_108)
);

AND2x2_ASAP7_75t_L g109 ( 
.A(n_102),
.B(n_100),
.Y(n_109)
);

AOI22xp33_ASAP7_75t_L g110 ( 
.A1(n_103),
.A2(n_94),
.B1(n_65),
.B2(n_91),
.Y(n_110)
);

AOI22xp33_ASAP7_75t_L g111 ( 
.A1(n_104),
.A2(n_70),
.B1(n_71),
.B2(n_68),
.Y(n_111)
);

OA21x2_ASAP7_75t_L g112 ( 
.A1(n_101),
.A2(n_84),
.B(n_72),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_101),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_99),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_99),
.Y(n_115)
);

INVx2_ASAP7_75t_L g116 ( 
.A(n_99),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_99),
.Y(n_117)
);

AND2x4_ASAP7_75t_L g118 ( 
.A(n_114),
.B(n_80),
.Y(n_118)
);

AND2x2_ASAP7_75t_L g119 ( 
.A(n_114),
.B(n_41),
.Y(n_119)
);

INVx1_ASAP7_75t_SL g120 ( 
.A(n_105),
.Y(n_120)
);

INVxp67_ASAP7_75t_L g121 ( 
.A(n_109),
.Y(n_121)
);

INVx2_ASAP7_75t_L g122 ( 
.A(n_116),
.Y(n_122)
);

AND2x2_ASAP7_75t_SL g123 ( 
.A(n_115),
.B(n_71),
.Y(n_123)
);

AND2x2_ASAP7_75t_L g124 ( 
.A(n_117),
.B(n_41),
.Y(n_124)
);

NAND2xp5_ASAP7_75t_L g125 ( 
.A(n_108),
.B(n_109),
.Y(n_125)
);

INVx1_ASAP7_75t_L g126 ( 
.A(n_108),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_117),
.Y(n_127)
);

INVxp67_ASAP7_75t_L g128 ( 
.A(n_106),
.Y(n_128)
);

INVx2_ASAP7_75t_SL g129 ( 
.A(n_116),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_113),
.Y(n_130)
);

OAI221xp5_ASAP7_75t_L g131 ( 
.A1(n_110),
.A2(n_81),
.B1(n_90),
.B2(n_82),
.C(n_76),
.Y(n_131)
);

AND2x2_ASAP7_75t_L g132 ( 
.A(n_107),
.B(n_1),
.Y(n_132)
);

INVx2_ASAP7_75t_L g133 ( 
.A(n_107),
.Y(n_133)
);

NAND2xp5_ASAP7_75t_L g134 ( 
.A(n_111),
.B(n_86),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_112),
.Y(n_135)
);

OR2x2_ASAP7_75t_L g136 ( 
.A(n_112),
.B(n_1),
.Y(n_136)
);

AND2x4_ASAP7_75t_L g137 ( 
.A(n_112),
.B(n_80),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_114),
.Y(n_138)
);

NOR2xp33_ASAP7_75t_L g139 ( 
.A(n_121),
.B(n_120),
.Y(n_139)
);

INVx2_ASAP7_75t_SL g140 ( 
.A(n_129),
.Y(n_140)
);

INVx2_ASAP7_75t_L g141 ( 
.A(n_122),
.Y(n_141)
);

OR2x4_ASAP7_75t_L g142 ( 
.A(n_136),
.B(n_2),
.Y(n_142)
);

OR2x2_ASAP7_75t_L g143 ( 
.A(n_125),
.B(n_2),
.Y(n_143)
);

AND2x2_ASAP7_75t_L g144 ( 
.A(n_129),
.B(n_3),
.Y(n_144)
);

NOR3xp33_ASAP7_75t_L g145 ( 
.A(n_131),
.B(n_71),
.C(n_60),
.Y(n_145)
);

NAND2xp5_ASAP7_75t_L g146 ( 
.A(n_126),
.B(n_4),
.Y(n_146)
);

INVx1_ASAP7_75t_SL g147 ( 
.A(n_132),
.Y(n_147)
);

AND2x2_ASAP7_75t_L g148 ( 
.A(n_128),
.B(n_8),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_127),
.Y(n_149)
);

INVx2_ASAP7_75t_L g150 ( 
.A(n_122),
.Y(n_150)
);

AND2x2_ASAP7_75t_L g151 ( 
.A(n_132),
.B(n_127),
.Y(n_151)
);

NAND2xp5_ASAP7_75t_L g152 ( 
.A(n_130),
.B(n_8),
.Y(n_152)
);

NAND2x1_ASAP7_75t_L g153 ( 
.A(n_138),
.B(n_78),
.Y(n_153)
);

OR2x2_ASAP7_75t_L g154 ( 
.A(n_138),
.B(n_9),
.Y(n_154)
);

NAND2xp5_ASAP7_75t_L g155 ( 
.A(n_130),
.B(n_10),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_133),
.Y(n_156)
);

HB1xp67_ASAP7_75t_L g157 ( 
.A(n_133),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_119),
.Y(n_158)
);

OR2x2_ASAP7_75t_L g159 ( 
.A(n_136),
.B(n_10),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_119),
.Y(n_160)
);

INVx1_ASAP7_75t_L g161 ( 
.A(n_124),
.Y(n_161)
);

INVxp67_ASAP7_75t_L g162 ( 
.A(n_124),
.Y(n_162)
);

INVx2_ASAP7_75t_L g163 ( 
.A(n_135),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_135),
.Y(n_164)
);

INVx1_ASAP7_75t_L g165 ( 
.A(n_118),
.Y(n_165)
);

AND2x4_ASAP7_75t_L g166 ( 
.A(n_137),
.B(n_11),
.Y(n_166)
);

OR2x2_ASAP7_75t_L g167 ( 
.A(n_118),
.B(n_88),
.Y(n_167)
);

INVx2_ASAP7_75t_SL g168 ( 
.A(n_140),
.Y(n_168)
);

NAND2xp5_ASAP7_75t_L g169 ( 
.A(n_151),
.B(n_137),
.Y(n_169)
);

INVx1_ASAP7_75t_L g170 ( 
.A(n_149),
.Y(n_170)
);

OR2x2_ASAP7_75t_L g171 ( 
.A(n_147),
.B(n_134),
.Y(n_171)
);

OR2x2_ASAP7_75t_L g172 ( 
.A(n_140),
.B(n_12),
.Y(n_172)
);

INVxp67_ASAP7_75t_L g173 ( 
.A(n_139),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_157),
.Y(n_174)
);

NOR2xp33_ASAP7_75t_L g175 ( 
.A(n_142),
.B(n_123),
.Y(n_175)
);

NAND2xp5_ASAP7_75t_L g176 ( 
.A(n_158),
.B(n_82),
.Y(n_176)
);

AND2x2_ASAP7_75t_L g177 ( 
.A(n_163),
.B(n_15),
.Y(n_177)
);

INVx1_ASAP7_75t_SL g178 ( 
.A(n_167),
.Y(n_178)
);

AND2x2_ASAP7_75t_L g179 ( 
.A(n_164),
.B(n_16),
.Y(n_179)
);

AND2x2_ASAP7_75t_L g180 ( 
.A(n_164),
.B(n_17),
.Y(n_180)
);

INVx2_ASAP7_75t_L g181 ( 
.A(n_141),
.Y(n_181)
);

INVx2_ASAP7_75t_L g182 ( 
.A(n_141),
.Y(n_182)
);

NAND2xp5_ASAP7_75t_L g183 ( 
.A(n_160),
.B(n_18),
.Y(n_183)
);

NAND2xp5_ASAP7_75t_SL g184 ( 
.A(n_166),
.B(n_79),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_157),
.Y(n_185)
);

AND2x2_ASAP7_75t_L g186 ( 
.A(n_165),
.B(n_20),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_144),
.Y(n_187)
);

NAND2xp5_ASAP7_75t_L g188 ( 
.A(n_161),
.B(n_21),
.Y(n_188)
);

NOR2xp33_ASAP7_75t_L g189 ( 
.A(n_142),
.B(n_22),
.Y(n_189)
);

OAI22xp5_ASAP7_75t_L g190 ( 
.A1(n_153),
.A2(n_79),
.B1(n_78),
.B2(n_87),
.Y(n_190)
);

INVx1_ASAP7_75t_L g191 ( 
.A(n_156),
.Y(n_191)
);

INVx1_ASAP7_75t_L g192 ( 
.A(n_159),
.Y(n_192)
);

OR2x2_ASAP7_75t_L g193 ( 
.A(n_162),
.B(n_23),
.Y(n_193)
);

NAND2xp5_ASAP7_75t_L g194 ( 
.A(n_148),
.B(n_143),
.Y(n_194)
);

INVx1_ASAP7_75t_SL g195 ( 
.A(n_178),
.Y(n_195)
);

INVx1_ASAP7_75t_L g196 ( 
.A(n_170),
.Y(n_196)
);

INVx1_ASAP7_75t_L g197 ( 
.A(n_191),
.Y(n_197)
);

INVx1_ASAP7_75t_L g198 ( 
.A(n_174),
.Y(n_198)
);

INVx1_ASAP7_75t_L g199 ( 
.A(n_185),
.Y(n_199)
);

NOR3xp33_ASAP7_75t_L g200 ( 
.A(n_189),
.B(n_155),
.C(n_152),
.Y(n_200)
);

NOR2xp33_ASAP7_75t_L g201 ( 
.A(n_173),
.B(n_146),
.Y(n_201)
);

NAND2xp5_ASAP7_75t_L g202 ( 
.A(n_192),
.B(n_150),
.Y(n_202)
);

INVx1_ASAP7_75t_L g203 ( 
.A(n_171),
.Y(n_203)
);

NAND2xp5_ASAP7_75t_L g204 ( 
.A(n_187),
.B(n_154),
.Y(n_204)
);

NOR3xp33_ASAP7_75t_L g205 ( 
.A(n_189),
.B(n_145),
.C(n_166),
.Y(n_205)
);

AO21x1_ASAP7_75t_L g206 ( 
.A1(n_175),
.A2(n_166),
.B(n_27),
.Y(n_206)
);

INVx1_ASAP7_75t_L g207 ( 
.A(n_168),
.Y(n_207)
);

OAI21xp33_ASAP7_75t_SL g208 ( 
.A1(n_168),
.A2(n_79),
.B(n_28),
.Y(n_208)
);

NOR3x1_ASAP7_75t_L g209 ( 
.A(n_184),
.B(n_79),
.C(n_83),
.Y(n_209)
);

OAI22xp5_ASAP7_75t_SL g210 ( 
.A1(n_194),
.A2(n_193),
.B1(n_172),
.B2(n_190),
.Y(n_210)
);

AND2x2_ASAP7_75t_L g211 ( 
.A(n_169),
.B(n_83),
.Y(n_211)
);

NOR3xp33_ASAP7_75t_SL g212 ( 
.A(n_176),
.B(n_75),
.C(n_66),
.Y(n_212)
);

AOI22xp5_ASAP7_75t_L g213 ( 
.A1(n_205),
.A2(n_186),
.B1(n_183),
.B2(n_188),
.Y(n_213)
);

OAI21xp33_ASAP7_75t_L g214 ( 
.A1(n_207),
.A2(n_201),
.B(n_203),
.Y(n_214)
);

NOR2x1_ASAP7_75t_L g215 ( 
.A(n_195),
.B(n_179),
.Y(n_215)
);

AOI21xp5_ASAP7_75t_L g216 ( 
.A1(n_206),
.A2(n_180),
.B(n_177),
.Y(n_216)
);

AOI22xp33_ASAP7_75t_L g217 ( 
.A1(n_205),
.A2(n_177),
.B1(n_180),
.B2(n_181),
.Y(n_217)
);

INVx1_ASAP7_75t_L g218 ( 
.A(n_202),
.Y(n_218)
);

NOR2x1_ASAP7_75t_L g219 ( 
.A(n_209),
.B(n_181),
.Y(n_219)
);

NOR2x1_ASAP7_75t_L g220 ( 
.A(n_197),
.B(n_182),
.Y(n_220)
);

OAI31xp33_ASAP7_75t_SL g221 ( 
.A1(n_210),
.A2(n_73),
.A3(n_75),
.B(n_196),
.Y(n_221)
);

HB1xp67_ASAP7_75t_L g222 ( 
.A(n_220),
.Y(n_222)
);

NAND4xp75_ASAP7_75t_L g223 ( 
.A(n_215),
.B(n_208),
.C(n_212),
.D(n_204),
.Y(n_223)
);

OAI22xp5_ASAP7_75t_L g224 ( 
.A1(n_217),
.A2(n_199),
.B1(n_198),
.B2(n_200),
.Y(n_224)
);

INVx1_ASAP7_75t_L g225 ( 
.A(n_218),
.Y(n_225)
);

NOR3xp33_ASAP7_75t_SL g226 ( 
.A(n_214),
.B(n_200),
.C(n_211),
.Y(n_226)
);

INVx1_ASAP7_75t_L g227 ( 
.A(n_225),
.Y(n_227)
);

OAI211xp5_ASAP7_75t_SL g228 ( 
.A1(n_226),
.A2(n_221),
.B(n_224),
.C(n_213),
.Y(n_228)
);

NOR3xp33_ASAP7_75t_L g229 ( 
.A(n_223),
.B(n_219),
.C(n_216),
.Y(n_229)
);

INVx1_ASAP7_75t_L g230 ( 
.A(n_227),
.Y(n_230)
);

AND2x2_ASAP7_75t_SL g231 ( 
.A(n_229),
.B(n_222),
.Y(n_231)
);

BUFx2_ASAP7_75t_L g232 ( 
.A(n_231),
.Y(n_232)
);

XNOR2xp5_ASAP7_75t_L g233 ( 
.A(n_232),
.B(n_231),
.Y(n_233)
);

INVx1_ASAP7_75t_L g234 ( 
.A(n_233),
.Y(n_234)
);

OAI21xp5_ASAP7_75t_L g235 ( 
.A1(n_234),
.A2(n_228),
.B(n_230),
.Y(n_235)
);


endmodule