module fake_netlist_911_3081_n_224 (n_3, n_33, n_15, n_11, n_34, n_24, n_6, n_37, n_16, n_47, n_0, n_46, n_30, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_49, n_20, n_40, n_9, n_39, n_17, n_18, n_31, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_32, n_35, n_41, n_42, n_43, n_26, n_10, n_29, n_36, n_44, n_45, n_8, n_48, n_38, n_224);

input n_3;
input n_33;
input n_15;
input n_11;
input n_34;
input n_24;
input n_6;
input n_37;
input n_16;
input n_47;
input n_0;
input n_46;
input n_30;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_49;
input n_20;
input n_40;
input n_9;
input n_39;
input n_17;
input n_18;
input n_31;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_32;
input n_35;
input n_41;
input n_42;
input n_43;
input n_26;
input n_10;
input n_29;
input n_36;
input n_44;
input n_45;
input n_8;
input n_48;
input n_38;

output n_224;

wire n_118;
wire n_100;
wire n_104;
wire n_60;
wire n_216;
wire n_101;
wire n_99;
wire n_52;
wire n_127;
wire n_154;
wire n_152;
wire n_111;
wire n_151;
wire n_185;
wire n_153;
wire n_193;
wire n_116;
wire n_164;
wire n_64;
wire n_102;
wire n_93;
wire n_157;
wire n_66;
wire n_65;
wire n_143;
wire n_88;
wire n_186;
wire n_195;
wire n_169;
wire n_192;
wire n_197;
wire n_212;
wire n_94;
wire n_198;
wire n_182;
wire n_206;
wire n_214;
wire n_91;
wire n_71;
wire n_135;
wire n_174;
wire n_80;
wire n_149;
wire n_201;
wire n_196;
wire n_69;
wire n_83;
wire n_207;
wire n_210;
wire n_134;
wire n_96;
wire n_128;
wire n_117;
wire n_131;
wire n_165;
wire n_190;
wire n_51;
wire n_50;
wire n_217;
wire n_162;
wire n_223;
wire n_55;
wire n_123;
wire n_110;
wire n_183;
wire n_144;
wire n_54;
wire n_211;
wire n_59;
wire n_189;
wire n_177;
wire n_173;
wire n_166;
wire n_70;
wire n_132;
wire n_220;
wire n_222;
wire n_126;
wire n_62;
wire n_120;
wire n_148;
wire n_141;
wire n_150;
wire n_188;
wire n_79;
wire n_187;
wire n_87;
wire n_142;
wire n_159;
wire n_115;
wire n_155;
wire n_184;
wire n_113;
wire n_200;
wire n_129;
wire n_191;
wire n_208;
wire n_209;
wire n_172;
wire n_77;
wire n_107;
wire n_199;
wire n_95;
wire n_204;
wire n_53;
wire n_161;
wire n_180;
wire n_106;
wire n_137;
wire n_90;
wire n_167;
wire n_146;
wire n_81;
wire n_221;
wire n_84;
wire n_171;
wire n_140;
wire n_61;
wire n_130;
wire n_122;
wire n_138;
wire n_170;
wire n_139;
wire n_136;
wire n_72;
wire n_181;
wire n_176;
wire n_133;
wire n_76;
wire n_56;
wire n_218;
wire n_175;
wire n_213;
wire n_74;
wire n_125;
wire n_179;
wire n_103;
wire n_160;
wire n_108;
wire n_75;
wire n_68;
wire n_158;
wire n_86;
wire n_63;
wire n_163;
wire n_105;
wire n_215;
wire n_114;
wire n_124;
wire n_145;
wire n_85;
wire n_112;
wire n_156;
wire n_205;
wire n_58;
wire n_109;
wire n_147;
wire n_168;
wire n_67;
wire n_219;
wire n_202;
wire n_57;
wire n_121;
wire n_97;
wire n_98;
wire n_119;
wire n_178;
wire n_203;
wire n_194;
wire n_73;
wire n_92;
wire n_89;
wire n_82;
wire n_78;

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_13),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_16),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_21),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_6),
.Y(n_53)
);

INVxp33_ASAP7_75t_SL g54 ( 
.A(n_15),
.Y(n_54)
);

CKINVDCx20_ASAP7_75t_R g55 ( 
.A(n_47),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_25),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_41),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_2),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_46),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_48),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_7),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_19),
.Y(n_62)
);

BUFx3_ASAP7_75t_L g63 ( 
.A(n_6),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_5),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_27),
.Y(n_65)
);

INVxp67_ASAP7_75t_L g66 ( 
.A(n_11),
.Y(n_66)
);

INVxp33_ASAP7_75t_SL g67 ( 
.A(n_14),
.Y(n_67)
);

CKINVDCx20_ASAP7_75t_R g68 ( 
.A(n_45),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_18),
.Y(n_69)
);

INVxp67_ASAP7_75t_SL g70 ( 
.A(n_38),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_30),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_0),
.Y(n_72)
);

CKINVDCx16_ASAP7_75t_R g73 ( 
.A(n_42),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_34),
.Y(n_74)
);

CKINVDCx5p33_ASAP7_75t_R g75 ( 
.A(n_49),
.Y(n_75)
);

NOR2xp33_ASAP7_75t_L g76 ( 
.A(n_51),
.B(n_0),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_69),
.Y(n_77)
);

CKINVDCx5p33_ASAP7_75t_R g78 ( 
.A(n_55),
.Y(n_78)
);

INVx2_ASAP7_75t_L g79 ( 
.A(n_57),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_69),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_57),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_71),
.Y(n_82)
);

CKINVDCx5p33_ASAP7_75t_R g83 ( 
.A(n_68),
.Y(n_83)
);

INVx1_ASAP7_75t_SL g84 ( 
.A(n_78),
.Y(n_84)
);

BUFx6f_ASAP7_75t_L g85 ( 
.A(n_79),
.Y(n_85)
);

NAND2xp5_ASAP7_75t_L g86 ( 
.A(n_77),
.B(n_73),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_77),
.Y(n_87)
);

NAND2xp5_ASAP7_75t_L g88 ( 
.A(n_80),
.B(n_50),
.Y(n_88)
);

INVx2_ASAP7_75t_L g89 ( 
.A(n_79),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_81),
.Y(n_90)
);

INVx3_ASAP7_75t_L g91 ( 
.A(n_85),
.Y(n_91)
);

INVx2_ASAP7_75t_SL g92 ( 
.A(n_87),
.Y(n_92)
);

BUFx2_ASAP7_75t_L g93 ( 
.A(n_84),
.Y(n_93)
);

CKINVDCx5p33_ASAP7_75t_R g94 ( 
.A(n_86),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_85),
.Y(n_95)
);

NOR3xp33_ASAP7_75t_SL g96 ( 
.A(n_88),
.B(n_83),
.C(n_50),
.Y(n_96)
);

BUFx12f_ASAP7_75t_L g97 ( 
.A(n_93),
.Y(n_97)
);

INVx3_ASAP7_75t_L g98 ( 
.A(n_92),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_92),
.Y(n_99)
);

OR2x6_ASAP7_75t_L g100 ( 
.A(n_93),
.B(n_90),
.Y(n_100)
);

AND2x2_ASAP7_75t_L g101 ( 
.A(n_93),
.B(n_90),
.Y(n_101)
);

AOI22xp33_ASAP7_75t_SL g102 ( 
.A1(n_94),
.A2(n_67),
.B1(n_54),
.B2(n_63),
.Y(n_102)
);

BUFx2_ASAP7_75t_L g103 ( 
.A(n_92),
.Y(n_103)
);

AND2x2_ASAP7_75t_L g104 ( 
.A(n_101),
.B(n_89),
.Y(n_104)
);

AOI22xp5_ASAP7_75t_L g105 ( 
.A1(n_97),
.A2(n_96),
.B1(n_67),
.B2(n_54),
.Y(n_105)
);

INVx2_ASAP7_75t_SL g106 ( 
.A(n_100),
.Y(n_106)
);

BUFx2_ASAP7_75t_SL g107 ( 
.A(n_103),
.Y(n_107)
);

AOI22xp33_ASAP7_75t_L g108 ( 
.A1(n_97),
.A2(n_63),
.B1(n_82),
.B2(n_80),
.Y(n_108)
);

OAI22xp5_ASAP7_75t_L g109 ( 
.A1(n_103),
.A2(n_82),
.B1(n_96),
.B2(n_89),
.Y(n_109)
);

BUFx3_ASAP7_75t_L g110 ( 
.A(n_97),
.Y(n_110)
);

AND2x4_ASAP7_75t_L g111 ( 
.A(n_100),
.B(n_91),
.Y(n_111)
);

OAI22xp5_ASAP7_75t_L g112 ( 
.A1(n_103),
.A2(n_75),
.B1(n_66),
.B2(n_76),
.Y(n_112)
);

AOI22xp33_ASAP7_75t_L g113 ( 
.A1(n_106),
.A2(n_100),
.B1(n_102),
.B2(n_101),
.Y(n_113)
);

AOI22xp33_ASAP7_75t_SL g114 ( 
.A1(n_110),
.A2(n_100),
.B1(n_101),
.B2(n_98),
.Y(n_114)
);

OAI22xp5_ASAP7_75t_L g115 ( 
.A1(n_106),
.A2(n_100),
.B1(n_107),
.B2(n_102),
.Y(n_115)
);

AND2x2_ASAP7_75t_L g116 ( 
.A(n_104),
.B(n_100),
.Y(n_116)
);

OAI211xp5_ASAP7_75t_L g117 ( 
.A1(n_105),
.A2(n_72),
.B(n_61),
.C(n_53),
.Y(n_117)
);

BUFx2_ASAP7_75t_L g118 ( 
.A(n_111),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_104),
.Y(n_119)
);

AOI332xp33_ASAP7_75t_L g120 ( 
.A1(n_108),
.A2(n_61),
.A3(n_72),
.B1(n_64),
.B2(n_58),
.B3(n_81),
.C1(n_74),
.C2(n_71),
.Y(n_120)
);

INVx2_ASAP7_75t_L g121 ( 
.A(n_111),
.Y(n_121)
);

AND2x2_ASAP7_75t_L g122 ( 
.A(n_107),
.B(n_100),
.Y(n_122)
);

OAI22xp5_ASAP7_75t_L g123 ( 
.A1(n_111),
.A2(n_99),
.B1(n_98),
.B2(n_74),
.Y(n_123)
);

AND2x2_ASAP7_75t_L g124 ( 
.A(n_110),
.B(n_98),
.Y(n_124)
);

AOI22xp33_ASAP7_75t_L g125 ( 
.A1(n_109),
.A2(n_99),
.B1(n_98),
.B2(n_85),
.Y(n_125)
);

BUFx3_ASAP7_75t_L g126 ( 
.A(n_112),
.Y(n_126)
);

AOI21xp5_ASAP7_75t_L g127 ( 
.A1(n_106),
.A2(n_98),
.B(n_95),
.Y(n_127)
);

AOI211xp5_ASAP7_75t_L g128 ( 
.A1(n_112),
.A2(n_75),
.B(n_56),
.C(n_52),
.Y(n_128)
);

AND2x2_ASAP7_75t_L g129 ( 
.A(n_116),
.B(n_59),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_119),
.Y(n_130)
);

OR2x2_ASAP7_75t_L g131 ( 
.A(n_116),
.B(n_85),
.Y(n_131)
);

AND2x2_ASAP7_75t_L g132 ( 
.A(n_119),
.B(n_60),
.Y(n_132)
);

BUFx3_ASAP7_75t_L g133 ( 
.A(n_124),
.Y(n_133)
);

AND2x2_ASAP7_75t_L g134 ( 
.A(n_121),
.B(n_122),
.Y(n_134)
);

AND2x4_ASAP7_75t_L g135 ( 
.A(n_121),
.B(n_62),
.Y(n_135)
);

NAND2xp5_ASAP7_75t_SL g136 ( 
.A(n_115),
.B(n_85),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_122),
.Y(n_137)
);

OR2x2_ASAP7_75t_L g138 ( 
.A(n_118),
.B(n_1),
.Y(n_138)
);

OAI31xp33_ASAP7_75t_SL g139 ( 
.A1(n_114),
.A2(n_70),
.A3(n_65),
.B(n_1),
.Y(n_139)
);

NOR3xp33_ASAP7_75t_SL g140 ( 
.A(n_117),
.B(n_3),
.C(n_2),
.Y(n_140)
);

OAI21xp33_ASAP7_75t_L g141 ( 
.A1(n_126),
.A2(n_128),
.B(n_113),
.Y(n_141)
);

INVx1_ASAP7_75t_L g142 ( 
.A(n_124),
.Y(n_142)
);

NAND2xp5_ASAP7_75t_L g143 ( 
.A(n_128),
.B(n_126),
.Y(n_143)
);

INVxp67_ASAP7_75t_SL g144 ( 
.A(n_123),
.Y(n_144)
);

OAI22xp5_ASAP7_75t_L g145 ( 
.A1(n_126),
.A2(n_91),
.B1(n_95),
.B2(n_3),
.Y(n_145)
);

AOI22xp5_ASAP7_75t_L g146 ( 
.A1(n_123),
.A2(n_91),
.B1(n_95),
.B2(n_4),
.Y(n_146)
);

NAND2xp33_ASAP7_75t_SL g147 ( 
.A(n_118),
.B(n_91),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_121),
.Y(n_148)
);

INVx2_ASAP7_75t_L g149 ( 
.A(n_127),
.Y(n_149)
);

OAI222xp33_ASAP7_75t_SL g150 ( 
.A1(n_120),
.A2(n_5),
.B1(n_4),
.B2(n_7),
.C1(n_9),
.C2(n_8),
.Y(n_150)
);

INVx3_ASAP7_75t_L g151 ( 
.A(n_133),
.Y(n_151)
);

OR2x2_ASAP7_75t_L g152 ( 
.A(n_133),
.B(n_8),
.Y(n_152)
);

OR2x2_ASAP7_75t_L g153 ( 
.A(n_137),
.B(n_9),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_130),
.Y(n_154)
);

OR2x2_ASAP7_75t_L g155 ( 
.A(n_142),
.B(n_134),
.Y(n_155)
);

AND2x4_ASAP7_75t_L g156 ( 
.A(n_134),
.B(n_125),
.Y(n_156)
);

NAND2xp5_ASAP7_75t_L g157 ( 
.A(n_148),
.B(n_120),
.Y(n_157)
);

NAND3xp33_ASAP7_75t_L g158 ( 
.A(n_139),
.B(n_91),
.C(n_10),
.Y(n_158)
);

AND2x2_ASAP7_75t_L g159 ( 
.A(n_129),
.B(n_10),
.Y(n_159)
);

AND2x2_ASAP7_75t_L g160 ( 
.A(n_129),
.B(n_11),
.Y(n_160)
);

INVx2_ASAP7_75t_SL g161 ( 
.A(n_131),
.Y(n_161)
);

AOI22xp5_ASAP7_75t_L g162 ( 
.A1(n_141),
.A2(n_143),
.B1(n_144),
.B2(n_140),
.Y(n_162)
);

AND2x4_ASAP7_75t_SL g163 ( 
.A(n_135),
.B(n_12),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_131),
.Y(n_164)
);

INVx2_ASAP7_75t_L g165 ( 
.A(n_135),
.Y(n_165)
);

NOR3xp33_ASAP7_75t_L g166 ( 
.A(n_145),
.B(n_20),
.C(n_17),
.Y(n_166)
);

NOR3xp33_ASAP7_75t_L g167 ( 
.A(n_132),
.B(n_23),
.C(n_22),
.Y(n_167)
);

INVx1_ASAP7_75t_SL g168 ( 
.A(n_147),
.Y(n_168)
);

NAND2xp5_ASAP7_75t_L g169 ( 
.A(n_132),
.B(n_24),
.Y(n_169)
);

AND2x4_ASAP7_75t_L g170 ( 
.A(n_135),
.B(n_26),
.Y(n_170)
);

OAI22xp5_ASAP7_75t_L g171 ( 
.A1(n_138),
.A2(n_146),
.B1(n_136),
.B2(n_150),
.Y(n_171)
);

AOI221xp5_ASAP7_75t_L g172 ( 
.A1(n_150),
.A2(n_29),
.B1(n_28),
.B2(n_31),
.C(n_32),
.Y(n_172)
);

OAI33xp33_ASAP7_75t_L g173 ( 
.A1(n_138),
.A2(n_35),
.A3(n_33),
.B1(n_36),
.B2(n_39),
.B3(n_37),
.Y(n_173)
);

AND2x4_ASAP7_75t_L g174 ( 
.A(n_149),
.B(n_147),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_154),
.Y(n_175)
);

AND2x4_ASAP7_75t_L g176 ( 
.A(n_174),
.B(n_149),
.Y(n_176)
);

NAND2xp5_ASAP7_75t_L g177 ( 
.A(n_155),
.B(n_40),
.Y(n_177)
);

AND2x4_ASAP7_75t_L g178 ( 
.A(n_174),
.B(n_43),
.Y(n_178)
);

AOI22xp33_ASAP7_75t_L g179 ( 
.A1(n_172),
.A2(n_44),
.B1(n_171),
.B2(n_156),
.Y(n_179)
);

AND2x2_ASAP7_75t_L g180 ( 
.A(n_164),
.B(n_156),
.Y(n_180)
);

NOR2xp33_ASAP7_75t_L g181 ( 
.A(n_157),
.B(n_159),
.Y(n_181)
);

OAI21xp33_ASAP7_75t_L g182 ( 
.A1(n_162),
.A2(n_172),
.B(n_152),
.Y(n_182)
);

AND2x2_ASAP7_75t_L g183 ( 
.A(n_151),
.B(n_165),
.Y(n_183)
);

INVxp67_ASAP7_75t_L g184 ( 
.A(n_151),
.Y(n_184)
);

INVx2_ASAP7_75t_L g185 ( 
.A(n_161),
.Y(n_185)
);

INVx2_ASAP7_75t_L g186 ( 
.A(n_168),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_168),
.Y(n_187)
);

NAND2xp5_ASAP7_75t_L g188 ( 
.A(n_157),
.B(n_160),
.Y(n_188)
);

OR2x4_ASAP7_75t_L g189 ( 
.A(n_153),
.B(n_169),
.Y(n_189)
);

OR2x2_ASAP7_75t_L g190 ( 
.A(n_171),
.B(n_169),
.Y(n_190)
);

INVx1_ASAP7_75t_SL g191 ( 
.A(n_163),
.Y(n_191)
);

AND2x2_ASAP7_75t_L g192 ( 
.A(n_170),
.B(n_167),
.Y(n_192)
);

AOI221xp5_ASAP7_75t_L g193 ( 
.A1(n_181),
.A2(n_158),
.B1(n_173),
.B2(n_170),
.C(n_166),
.Y(n_193)
);

NAND3xp33_ASAP7_75t_L g194 ( 
.A(n_182),
.B(n_173),
.C(n_190),
.Y(n_194)
);

INVx1_ASAP7_75t_L g195 ( 
.A(n_175),
.Y(n_195)
);

INVx1_ASAP7_75t_SL g196 ( 
.A(n_191),
.Y(n_196)
);

NOR2xp33_ASAP7_75t_L g197 ( 
.A(n_188),
.B(n_189),
.Y(n_197)
);

NAND2x1p5_ASAP7_75t_L g198 ( 
.A(n_178),
.B(n_192),
.Y(n_198)
);

AND2x2_ASAP7_75t_L g199 ( 
.A(n_180),
.B(n_183),
.Y(n_199)
);

INVx1_ASAP7_75t_L g200 ( 
.A(n_175),
.Y(n_200)
);

INVx1_ASAP7_75t_L g201 ( 
.A(n_180),
.Y(n_201)
);

AOI22xp33_ASAP7_75t_L g202 ( 
.A1(n_182),
.A2(n_190),
.B1(n_179),
.B2(n_192),
.Y(n_202)
);

A2O1A1Ixp33_ASAP7_75t_L g203 ( 
.A1(n_184),
.A2(n_178),
.B(n_187),
.C(n_177),
.Y(n_203)
);

NAND2xp5_ASAP7_75t_L g204 ( 
.A(n_185),
.B(n_183),
.Y(n_204)
);

NOR2x1_ASAP7_75t_L g205 ( 
.A(n_194),
.B(n_178),
.Y(n_205)
);

BUFx3_ASAP7_75t_L g206 ( 
.A(n_196),
.Y(n_206)
);

NAND2xp5_ASAP7_75t_SL g207 ( 
.A(n_203),
.B(n_187),
.Y(n_207)
);

INVx1_ASAP7_75t_L g208 ( 
.A(n_195),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_200),
.Y(n_209)
);

AND2x2_ASAP7_75t_L g210 ( 
.A(n_199),
.B(n_176),
.Y(n_210)
);

CKINVDCx6p67_ASAP7_75t_R g211 ( 
.A(n_204),
.Y(n_211)
);

OAI21xp33_ASAP7_75t_L g212 ( 
.A1(n_205),
.A2(n_202),
.B(n_197),
.Y(n_212)
);

AND2x2_ASAP7_75t_L g213 ( 
.A(n_210),
.B(n_201),
.Y(n_213)
);

INVxp67_ASAP7_75t_L g214 ( 
.A(n_206),
.Y(n_214)
);

A2O1A1Ixp33_ASAP7_75t_L g215 ( 
.A1(n_206),
.A2(n_202),
.B(n_193),
.C(n_185),
.Y(n_215)
);

AOI22xp33_ASAP7_75t_L g216 ( 
.A1(n_212),
.A2(n_211),
.B1(n_198),
.B2(n_207),
.Y(n_216)
);

OAI21xp33_ASAP7_75t_SL g217 ( 
.A1(n_214),
.A2(n_210),
.B(n_211),
.Y(n_217)
);

NOR2xp33_ASAP7_75t_SL g218 ( 
.A(n_217),
.B(n_215),
.Y(n_218)
);

CKINVDCx5p33_ASAP7_75t_R g219 ( 
.A(n_218),
.Y(n_219)
);

INVx1_ASAP7_75t_L g220 ( 
.A(n_219),
.Y(n_220)
);

INVx1_ASAP7_75t_L g221 ( 
.A(n_220),
.Y(n_221)
);

INVx1_ASAP7_75t_L g222 ( 
.A(n_221),
.Y(n_222)
);

AOI322xp5_ASAP7_75t_L g223 ( 
.A1(n_222),
.A2(n_216),
.A3(n_213),
.B1(n_208),
.B2(n_189),
.C1(n_209),
.C2(n_186),
.Y(n_223)
);

AOI221xp5_ASAP7_75t_L g224 ( 
.A1(n_223),
.A2(n_209),
.B1(n_198),
.B2(n_186),
.C(n_176),
.Y(n_224)
);


endmodule