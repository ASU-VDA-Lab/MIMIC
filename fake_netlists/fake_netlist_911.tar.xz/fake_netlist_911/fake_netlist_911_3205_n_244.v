module fake_netlist_911_3205_n_244 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_30, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_26, n_10, n_29, n_8, n_244);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_30;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_26;
input n_10;
input n_29;
input n_8;

output n_244;

wire n_118;
wire n_100;
wire n_60;
wire n_104;
wire n_216;
wire n_235;
wire n_240;
wire n_101;
wire n_52;
wire n_99;
wire n_127;
wire n_152;
wire n_154;
wire n_151;
wire n_111;
wire n_185;
wire n_153;
wire n_193;
wire n_116;
wire n_164;
wire n_64;
wire n_102;
wire n_93;
wire n_157;
wire n_66;
wire n_65;
wire n_143;
wire n_88;
wire n_186;
wire n_195;
wire n_169;
wire n_192;
wire n_197;
wire n_212;
wire n_94;
wire n_198;
wire n_182;
wire n_206;
wire n_214;
wire n_91;
wire n_71;
wire n_135;
wire n_174;
wire n_224;
wire n_80;
wire n_229;
wire n_228;
wire n_149;
wire n_201;
wire n_196;
wire n_69;
wire n_83;
wire n_207;
wire n_210;
wire n_134;
wire n_96;
wire n_128;
wire n_165;
wire n_131;
wire n_190;
wire n_51;
wire n_50;
wire n_217;
wire n_162;
wire n_223;
wire n_242;
wire n_55;
wire n_123;
wire n_234;
wire n_110;
wire n_46;
wire n_183;
wire n_144;
wire n_54;
wire n_238;
wire n_211;
wire n_59;
wire n_227;
wire n_189;
wire n_177;
wire n_173;
wire n_237;
wire n_166;
wire n_70;
wire n_40;
wire n_39;
wire n_132;
wire n_243;
wire n_31;
wire n_225;
wire n_220;
wire n_42;
wire n_32;
wire n_41;
wire n_222;
wire n_126;
wire n_62;
wire n_120;
wire n_141;
wire n_150;
wire n_148;
wire n_226;
wire n_188;
wire n_44;
wire n_79;
wire n_187;
wire n_87;
wire n_142;
wire n_159;
wire n_115;
wire n_78;
wire n_155;
wire n_230;
wire n_33;
wire n_184;
wire n_113;
wire n_233;
wire n_200;
wire n_129;
wire n_191;
wire n_209;
wire n_208;
wire n_172;
wire n_77;
wire n_107;
wire n_199;
wire n_95;
wire n_204;
wire n_53;
wire n_161;
wire n_180;
wire n_106;
wire n_137;
wire n_90;
wire n_167;
wire n_146;
wire n_81;
wire n_221;
wire n_84;
wire n_171;
wire n_140;
wire n_61;
wire n_130;
wire n_122;
wire n_43;
wire n_138;
wire n_170;
wire n_136;
wire n_139;
wire n_72;
wire n_48;
wire n_181;
wire n_176;
wire n_133;
wire n_76;
wire n_38;
wire n_56;
wire n_218;
wire n_175;
wire n_213;
wire n_74;
wire n_125;
wire n_34;
wire n_179;
wire n_103;
wire n_37;
wire n_160;
wire n_108;
wire n_75;
wire n_47;
wire n_68;
wire n_158;
wire n_86;
wire n_236;
wire n_63;
wire n_241;
wire n_163;
wire n_105;
wire n_215;
wire n_114;
wire n_124;
wire n_145;
wire n_85;
wire n_112;
wire n_156;
wire n_205;
wire n_232;
wire n_49;
wire n_58;
wire n_109;
wire n_147;
wire n_168;
wire n_67;
wire n_219;
wire n_239;
wire n_202;
wire n_35;
wire n_57;
wire n_121;
wire n_98;
wire n_97;
wire n_231;
wire n_119;
wire n_178;
wire n_203;
wire n_36;
wire n_194;
wire n_45;
wire n_92;
wire n_89;
wire n_73;
wire n_82;
wire n_117;

INVx1_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_22),
.Y(n_32)
);

CKINVDCx14_ASAP7_75t_R g33 ( 
.A(n_1),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_1),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_8),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_6),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_13),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_6),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_29),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_30),
.Y(n_40)
);

INVxp67_ASAP7_75t_L g41 ( 
.A(n_0),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_10),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_33),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_33),
.Y(n_44)
);

NAND2xp33_ASAP7_75t_R g45 ( 
.A(n_40),
.B(n_0),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_35),
.Y(n_46)
);

CKINVDCx20_ASAP7_75t_R g47 ( 
.A(n_34),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_42),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_R g49 ( 
.A(n_42),
.B(n_9),
.Y(n_49)
);

OR2x6_ASAP7_75t_SL g50 ( 
.A(n_43),
.B(n_34),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_43),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_SL g52 ( 
.A(n_44),
.B(n_35),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_46),
.Y(n_53)
);

AO22x2_ASAP7_75t_L g54 ( 
.A1(n_46),
.A2(n_37),
.B1(n_36),
.B2(n_31),
.Y(n_54)
);

NOR2xp67_ASAP7_75t_L g55 ( 
.A(n_46),
.B(n_12),
.Y(n_55)
);

HB1xp67_ASAP7_75t_L g56 ( 
.A(n_48),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_48),
.Y(n_57)
);

BUFx8_ASAP7_75t_L g58 ( 
.A(n_48),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_44),
.Y(n_59)
);

A2O1A1Ixp33_ASAP7_75t_L g60 ( 
.A1(n_49),
.A2(n_37),
.B(n_36),
.C(n_31),
.Y(n_60)
);

BUFx2_ASAP7_75t_L g61 ( 
.A(n_49),
.Y(n_61)
);

HB1xp67_ASAP7_75t_L g62 ( 
.A(n_58),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_L g63 ( 
.A(n_53),
.B(n_41),
.Y(n_63)
);

AOI21xp5_ASAP7_75t_SL g64 ( 
.A1(n_53),
.A2(n_41),
.B(n_38),
.Y(n_64)
);

OAI21xp5_ASAP7_75t_L g65 ( 
.A1(n_60),
.A2(n_39),
.B(n_38),
.Y(n_65)
);

OAI21xp33_ASAP7_75t_SL g66 ( 
.A1(n_57),
.A2(n_39),
.B(n_32),
.Y(n_66)
);

INVx2_ASAP7_75t_L g67 ( 
.A(n_54),
.Y(n_67)
);

AOI21xp5_ASAP7_75t_L g68 ( 
.A1(n_57),
.A2(n_32),
.B(n_45),
.Y(n_68)
);

AOI21xp5_ASAP7_75t_L g69 ( 
.A1(n_57),
.A2(n_45),
.B(n_14),
.Y(n_69)
);

OAI321xp33_ASAP7_75t_L g70 ( 
.A1(n_59),
.A2(n_52),
.A3(n_61),
.B1(n_54),
.B2(n_56),
.C(n_55),
.Y(n_70)
);

NOR3xp33_ASAP7_75t_SL g71 ( 
.A(n_51),
.B(n_47),
.C(n_2),
.Y(n_71)
);

OAI21xp5_ASAP7_75t_L g72 ( 
.A1(n_55),
.A2(n_47),
.B(n_2),
.Y(n_72)
);

BUFx4f_ASAP7_75t_L g73 ( 
.A(n_59),
.Y(n_73)
);

BUFx2_ASAP7_75t_SL g74 ( 
.A(n_54),
.Y(n_74)
);

INVx3_ASAP7_75t_L g75 ( 
.A(n_54),
.Y(n_75)
);

INVx2_ASAP7_75t_L g76 ( 
.A(n_75),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_75),
.Y(n_77)
);

OA21x2_ASAP7_75t_L g78 ( 
.A1(n_69),
.A2(n_59),
.B(n_61),
.Y(n_78)
);

NOR2xp33_ASAP7_75t_L g79 ( 
.A(n_63),
.B(n_56),
.Y(n_79)
);

INVx2_ASAP7_75t_SL g80 ( 
.A(n_75),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_75),
.Y(n_81)
);

INVx2_ASAP7_75t_L g82 ( 
.A(n_75),
.Y(n_82)
);

O2A1O1Ixp5_ASAP7_75t_L g83 ( 
.A1(n_69),
.A2(n_54),
.B(n_4),
.C(n_3),
.Y(n_83)
);

OA21x2_ASAP7_75t_L g84 ( 
.A1(n_68),
.A2(n_58),
.B(n_3),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_74),
.Y(n_85)
);

OAI21x1_ASAP7_75t_L g86 ( 
.A1(n_67),
.A2(n_58),
.B(n_4),
.Y(n_86)
);

NOR2x1_ASAP7_75t_L g87 ( 
.A(n_85),
.B(n_67),
.Y(n_87)
);

INVx5_ASAP7_75t_L g88 ( 
.A(n_80),
.Y(n_88)
);

INVx2_ASAP7_75t_L g89 ( 
.A(n_76),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_76),
.Y(n_90)
);

OAI21xp5_ASAP7_75t_SL g91 ( 
.A1(n_79),
.A2(n_62),
.B(n_58),
.Y(n_91)
);

NAND2xp5_ASAP7_75t_L g92 ( 
.A(n_79),
.B(n_58),
.Y(n_92)
);

NAND2xp5_ASAP7_75t_L g93 ( 
.A(n_79),
.B(n_62),
.Y(n_93)
);

AO31x2_ASAP7_75t_L g94 ( 
.A1(n_89),
.A2(n_67),
.A3(n_85),
.B(n_76),
.Y(n_94)
);

NAND2xp5_ASAP7_75t_L g95 ( 
.A(n_93),
.B(n_67),
.Y(n_95)
);

INVx2_ASAP7_75t_L g96 ( 
.A(n_90),
.Y(n_96)
);

AND2x2_ASAP7_75t_L g97 ( 
.A(n_92),
.B(n_74),
.Y(n_97)
);

INVx2_ASAP7_75t_L g98 ( 
.A(n_88),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_91),
.B(n_74),
.Y(n_99)
);

OA21x2_ASAP7_75t_L g100 ( 
.A1(n_87),
.A2(n_83),
.B(n_86),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_87),
.Y(n_101)
);

NAND2x1p5_ASAP7_75t_L g102 ( 
.A(n_98),
.B(n_85),
.Y(n_102)
);

OR2x2_ASAP7_75t_L g103 ( 
.A(n_99),
.B(n_84),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_94),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_94),
.Y(n_105)
);

INVx2_ASAP7_75t_L g106 ( 
.A(n_94),
.Y(n_106)
);

AND2x2_ASAP7_75t_L g107 ( 
.A(n_96),
.B(n_84),
.Y(n_107)
);

AND2x4_ASAP7_75t_L g108 ( 
.A(n_94),
.B(n_88),
.Y(n_108)
);

OR2x2_ASAP7_75t_L g109 ( 
.A(n_99),
.B(n_84),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_94),
.Y(n_110)
);

HB1xp67_ASAP7_75t_SL g111 ( 
.A(n_98),
.Y(n_111)
);

AND2x2_ASAP7_75t_L g112 ( 
.A(n_96),
.B(n_94),
.Y(n_112)
);

AND2x2_ASAP7_75t_L g113 ( 
.A(n_96),
.B(n_84),
.Y(n_113)
);

AOI221xp5_ASAP7_75t_L g114 ( 
.A1(n_104),
.A2(n_72),
.B1(n_66),
.B2(n_71),
.C(n_64),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_112),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_112),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_112),
.Y(n_117)
);

INVx1_ASAP7_75t_SL g118 ( 
.A(n_111),
.Y(n_118)
);

INVx2_ASAP7_75t_L g119 ( 
.A(n_107),
.Y(n_119)
);

INVx2_ASAP7_75t_L g120 ( 
.A(n_107),
.Y(n_120)
);

OR2x2_ASAP7_75t_L g121 ( 
.A(n_106),
.B(n_101),
.Y(n_121)
);

INVx2_ASAP7_75t_L g122 ( 
.A(n_106),
.Y(n_122)
);

INVx2_ASAP7_75t_L g123 ( 
.A(n_107),
.Y(n_123)
);

INVx1_ASAP7_75t_L g124 ( 
.A(n_104),
.Y(n_124)
);

AND2x2_ASAP7_75t_L g125 ( 
.A(n_106),
.B(n_100),
.Y(n_125)
);

NAND2xp5_ASAP7_75t_SL g126 ( 
.A(n_108),
.B(n_98),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_105),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_105),
.Y(n_128)
);

INVx2_ASAP7_75t_SL g129 ( 
.A(n_108),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_110),
.Y(n_130)
);

INVx1_ASAP7_75t_L g131 ( 
.A(n_110),
.Y(n_131)
);

INVx1_ASAP7_75t_L g132 ( 
.A(n_106),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_113),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_113),
.Y(n_134)
);

NAND2xp5_ASAP7_75t_L g135 ( 
.A(n_115),
.B(n_108),
.Y(n_135)
);

INVx1_ASAP7_75t_L g136 ( 
.A(n_124),
.Y(n_136)
);

INVx3_ASAP7_75t_L g137 ( 
.A(n_118),
.Y(n_137)
);

AOI22xp5_ASAP7_75t_L g138 ( 
.A1(n_114),
.A2(n_111),
.B1(n_72),
.B2(n_108),
.Y(n_138)
);

AOI322xp5_ASAP7_75t_L g139 ( 
.A1(n_115),
.A2(n_66),
.A3(n_71),
.B1(n_108),
.B2(n_113),
.C1(n_97),
.C2(n_50),
.Y(n_139)
);

AOI22xp33_ASAP7_75t_L g140 ( 
.A1(n_116),
.A2(n_84),
.B1(n_97),
.B2(n_103),
.Y(n_140)
);

NAND2xp5_ASAP7_75t_L g141 ( 
.A(n_116),
.B(n_117),
.Y(n_141)
);

NAND3xp33_ASAP7_75t_L g142 ( 
.A(n_124),
.B(n_66),
.C(n_84),
.Y(n_142)
);

OAI22xp33_ASAP7_75t_L g143 ( 
.A1(n_129),
.A2(n_103),
.B1(n_109),
.B2(n_102),
.Y(n_143)
);

NAND2xp5_ASAP7_75t_L g144 ( 
.A(n_117),
.B(n_103),
.Y(n_144)
);

AOI21xp5_ASAP7_75t_L g145 ( 
.A1(n_126),
.A2(n_85),
.B(n_100),
.Y(n_145)
);

OR2x2_ASAP7_75t_L g146 ( 
.A(n_121),
.B(n_109),
.Y(n_146)
);

AOI221xp5_ASAP7_75t_L g147 ( 
.A1(n_127),
.A2(n_68),
.B1(n_65),
.B2(n_83),
.C(n_70),
.Y(n_147)
);

NAND2xp5_ASAP7_75t_L g148 ( 
.A(n_133),
.B(n_109),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_127),
.Y(n_149)
);

NAND2xp5_ASAP7_75t_L g150 ( 
.A(n_133),
.B(n_101),
.Y(n_150)
);

NAND2x1p5_ASAP7_75t_L g151 ( 
.A(n_129),
.B(n_86),
.Y(n_151)
);

NOR2xp33_ASAP7_75t_L g152 ( 
.A(n_134),
.B(n_50),
.Y(n_152)
);

AOI322xp5_ASAP7_75t_L g153 ( 
.A1(n_128),
.A2(n_97),
.A3(n_50),
.B1(n_95),
.B2(n_7),
.C1(n_5),
.C2(n_11),
.Y(n_153)
);

OR2x2_ASAP7_75t_L g154 ( 
.A(n_121),
.B(n_102),
.Y(n_154)
);

AOI22xp5_ASAP7_75t_L g155 ( 
.A1(n_128),
.A2(n_84),
.B1(n_86),
.B2(n_102),
.Y(n_155)
);

OAI21xp33_ASAP7_75t_L g156 ( 
.A1(n_130),
.A2(n_86),
.B(n_65),
.Y(n_156)
);

OR2x2_ASAP7_75t_L g157 ( 
.A(n_119),
.B(n_102),
.Y(n_157)
);

NAND2xp5_ASAP7_75t_L g158 ( 
.A(n_134),
.B(n_94),
.Y(n_158)
);

OR2x2_ASAP7_75t_L g159 ( 
.A(n_119),
.B(n_95),
.Y(n_159)
);

OAI22xp5_ASAP7_75t_L g160 ( 
.A1(n_120),
.A2(n_84),
.B1(n_100),
.B2(n_88),
.Y(n_160)
);

NAND2xp5_ASAP7_75t_L g161 ( 
.A(n_130),
.B(n_100),
.Y(n_161)
);

NAND2xp5_ASAP7_75t_L g162 ( 
.A(n_131),
.B(n_100),
.Y(n_162)
);

AOI22xp5_ASAP7_75t_L g163 ( 
.A1(n_131),
.A2(n_84),
.B1(n_86),
.B2(n_73),
.Y(n_163)
);

OR2x2_ASAP7_75t_L g164 ( 
.A(n_146),
.B(n_120),
.Y(n_164)
);

AND2x2_ASAP7_75t_L g165 ( 
.A(n_135),
.B(n_125),
.Y(n_165)
);

OR2x2_ASAP7_75t_L g166 ( 
.A(n_141),
.B(n_123),
.Y(n_166)
);

INVx1_ASAP7_75t_L g167 ( 
.A(n_136),
.Y(n_167)
);

OAI221xp5_ASAP7_75t_L g168 ( 
.A1(n_152),
.A2(n_132),
.B1(n_122),
.B2(n_83),
.C(n_63),
.Y(n_168)
);

AND2x2_ASAP7_75t_L g169 ( 
.A(n_144),
.B(n_125),
.Y(n_169)
);

INVx1_ASAP7_75t_L g170 ( 
.A(n_149),
.Y(n_170)
);

OAI22xp5_ASAP7_75t_L g171 ( 
.A1(n_138),
.A2(n_123),
.B1(n_132),
.B2(n_122),
.Y(n_171)
);

NAND2xp5_ASAP7_75t_L g172 ( 
.A(n_150),
.B(n_122),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_161),
.Y(n_173)
);

HB1xp67_ASAP7_75t_L g174 ( 
.A(n_154),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_162),
.Y(n_175)
);

NOR2xp67_ASAP7_75t_L g176 ( 
.A(n_137),
.B(n_142),
.Y(n_176)
);

INVxp67_ASAP7_75t_L g177 ( 
.A(n_137),
.Y(n_177)
);

OR2x2_ASAP7_75t_L g178 ( 
.A(n_148),
.B(n_5),
.Y(n_178)
);

NAND2xp33_ASAP7_75t_L g179 ( 
.A(n_151),
.B(n_86),
.Y(n_179)
);

NOR2x1_ASAP7_75t_L g180 ( 
.A(n_143),
.B(n_78),
.Y(n_180)
);

INVx1_ASAP7_75t_L g181 ( 
.A(n_158),
.Y(n_181)
);

NAND3xp33_ASAP7_75t_L g182 ( 
.A(n_139),
.B(n_78),
.C(n_77),
.Y(n_182)
);

AOI22xp33_ASAP7_75t_L g183 ( 
.A1(n_143),
.A2(n_78),
.B1(n_73),
.B2(n_77),
.Y(n_183)
);

INVxp67_ASAP7_75t_L g184 ( 
.A(n_157),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_159),
.Y(n_185)
);

OR2x2_ASAP7_75t_L g186 ( 
.A(n_145),
.B(n_160),
.Y(n_186)
);

INVxp67_ASAP7_75t_L g187 ( 
.A(n_151),
.Y(n_187)
);

OR2x2_ASAP7_75t_L g188 ( 
.A(n_145),
.B(n_7),
.Y(n_188)
);

INVx1_ASAP7_75t_SL g189 ( 
.A(n_155),
.Y(n_189)
);

NOR2x1_ASAP7_75t_L g190 ( 
.A(n_156),
.B(n_78),
.Y(n_190)
);

AND2x2_ASAP7_75t_L g191 ( 
.A(n_140),
.B(n_78),
.Y(n_191)
);

INVx1_ASAP7_75t_L g192 ( 
.A(n_163),
.Y(n_192)
);

NAND2xp5_ASAP7_75t_L g193 ( 
.A(n_153),
.B(n_11),
.Y(n_193)
);

NAND2xp5_ASAP7_75t_L g194 ( 
.A(n_181),
.B(n_147),
.Y(n_194)
);

OAI221xp5_ASAP7_75t_L g195 ( 
.A1(n_193),
.A2(n_147),
.B1(n_73),
.B2(n_78),
.C(n_15),
.Y(n_195)
);

INVx1_ASAP7_75t_L g196 ( 
.A(n_166),
.Y(n_196)
);

AOI22xp33_ASAP7_75t_L g197 ( 
.A1(n_180),
.A2(n_78),
.B1(n_73),
.B2(n_77),
.Y(n_197)
);

OAI211xp5_ASAP7_75t_SL g198 ( 
.A1(n_177),
.A2(n_17),
.B(n_16),
.C(n_15),
.Y(n_198)
);

AOI321xp33_ASAP7_75t_L g199 ( 
.A1(n_171),
.A2(n_70),
.A3(n_18),
.B1(n_16),
.B2(n_19),
.C(n_17),
.Y(n_199)
);

NOR4xp25_ASAP7_75t_L g200 ( 
.A(n_189),
.B(n_20),
.C(n_19),
.D(n_18),
.Y(n_200)
);

AOI222xp33_ASAP7_75t_L g201 ( 
.A1(n_192),
.A2(n_73),
.B1(n_22),
.B2(n_20),
.C1(n_23),
.C2(n_21),
.Y(n_201)
);

OAI21xp33_ASAP7_75t_SL g202 ( 
.A1(n_176),
.A2(n_188),
.B(n_190),
.Y(n_202)
);

A2O1A1Ixp33_ASAP7_75t_L g203 ( 
.A1(n_182),
.A2(n_80),
.B(n_23),
.C(n_21),
.Y(n_203)
);

OAI221xp5_ASAP7_75t_SL g204 ( 
.A1(n_186),
.A2(n_25),
.B1(n_24),
.B2(n_26),
.C(n_27),
.Y(n_204)
);

AOI22xp5_ASAP7_75t_L g205 ( 
.A1(n_185),
.A2(n_78),
.B1(n_77),
.B2(n_76),
.Y(n_205)
);

NAND4xp25_ASAP7_75t_L g206 ( 
.A(n_186),
.B(n_178),
.C(n_188),
.D(n_187),
.Y(n_206)
);

AOI22xp5_ASAP7_75t_L g207 ( 
.A1(n_184),
.A2(n_78),
.B1(n_81),
.B2(n_76),
.Y(n_207)
);

AOI222xp33_ASAP7_75t_L g208 ( 
.A1(n_173),
.A2(n_26),
.B1(n_25),
.B2(n_27),
.C1(n_29),
.C2(n_28),
.Y(n_208)
);

INVx2_ASAP7_75t_L g209 ( 
.A(n_167),
.Y(n_209)
);

AOI222xp33_ASAP7_75t_L g210 ( 
.A1(n_173),
.A2(n_30),
.B1(n_28),
.B2(n_82),
.C1(n_81),
.C2(n_76),
.Y(n_210)
);

AOI222xp33_ASAP7_75t_L g211 ( 
.A1(n_175),
.A2(n_80),
.B1(n_81),
.B2(n_82),
.C1(n_179),
.C2(n_174),
.Y(n_211)
);

OAI31xp33_ASAP7_75t_L g212 ( 
.A1(n_178),
.A2(n_80),
.A3(n_82),
.B(n_81),
.Y(n_212)
);

OAI221xp5_ASAP7_75t_L g213 ( 
.A1(n_175),
.A2(n_183),
.B1(n_168),
.B2(n_170),
.C(n_179),
.Y(n_213)
);

NAND3xp33_ASAP7_75t_L g214 ( 
.A(n_172),
.B(n_82),
.C(n_81),
.Y(n_214)
);

AOI321xp33_ASAP7_75t_L g215 ( 
.A1(n_191),
.A2(n_169),
.A3(n_165),
.B1(n_166),
.B2(n_164),
.C(n_81),
.Y(n_215)
);

AND2x2_ASAP7_75t_L g216 ( 
.A(n_196),
.B(n_165),
.Y(n_216)
);

AND2x2_ASAP7_75t_L g217 ( 
.A(n_209),
.B(n_169),
.Y(n_217)
);

NAND4xp75_ASAP7_75t_L g218 ( 
.A(n_202),
.B(n_191),
.C(n_164),
.D(n_80),
.Y(n_218)
);

INVx1_ASAP7_75t_SL g219 ( 
.A(n_209),
.Y(n_219)
);

NOR2xp33_ASAP7_75t_L g220 ( 
.A(n_206),
.B(n_82),
.Y(n_220)
);

NAND2xp5_ASAP7_75t_L g221 ( 
.A(n_194),
.B(n_82),
.Y(n_221)
);

OAI321xp33_ASAP7_75t_L g222 ( 
.A1(n_215),
.A2(n_213),
.A3(n_204),
.B1(n_199),
.B2(n_195),
.C(n_197),
.Y(n_222)
);

INVxp33_ASAP7_75t_SL g223 ( 
.A(n_200),
.Y(n_223)
);

O2A1O1Ixp5_ASAP7_75t_L g224 ( 
.A1(n_203),
.A2(n_214),
.B(n_211),
.C(n_208),
.Y(n_224)
);

INVx1_ASAP7_75t_L g225 ( 
.A(n_207),
.Y(n_225)
);

NAND3xp33_ASAP7_75t_L g226 ( 
.A(n_203),
.B(n_201),
.C(n_197),
.Y(n_226)
);

NAND2xp5_ASAP7_75t_L g227 ( 
.A(n_205),
.B(n_210),
.Y(n_227)
);

NAND3x1_ASAP7_75t_SL g228 ( 
.A(n_212),
.B(n_198),
.C(n_180),
.Y(n_228)
);

INVx1_ASAP7_75t_L g229 ( 
.A(n_216),
.Y(n_229)
);

BUFx6f_ASAP7_75t_L g230 ( 
.A(n_226),
.Y(n_230)
);

CKINVDCx5p33_ASAP7_75t_R g231 ( 
.A(n_223),
.Y(n_231)
);

OAI21xp5_ASAP7_75t_L g232 ( 
.A1(n_223),
.A2(n_224),
.B(n_218),
.Y(n_232)
);

CKINVDCx16_ASAP7_75t_R g233 ( 
.A(n_217),
.Y(n_233)
);

OAI221xp5_ASAP7_75t_L g234 ( 
.A1(n_227),
.A2(n_225),
.B1(n_220),
.B2(n_219),
.C(n_221),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_217),
.Y(n_235)
);

NAND2xp5_ASAP7_75t_SL g236 ( 
.A(n_233),
.B(n_222),
.Y(n_236)
);

XOR2xp5_ASAP7_75t_L g237 ( 
.A(n_231),
.B(n_218),
.Y(n_237)
);

OAI21x1_ASAP7_75t_L g238 ( 
.A1(n_232),
.A2(n_216),
.B(n_228),
.Y(n_238)
);

INVx1_ASAP7_75t_L g239 ( 
.A(n_229),
.Y(n_239)
);

OAI22x1_ASAP7_75t_L g240 ( 
.A1(n_236),
.A2(n_231),
.B1(n_237),
.B2(n_238),
.Y(n_240)
);

AOI22x1_ASAP7_75t_L g241 ( 
.A1(n_237),
.A2(n_230),
.B1(n_238),
.B2(n_239),
.Y(n_241)
);

OAI22xp5_ASAP7_75t_L g242 ( 
.A1(n_241),
.A2(n_230),
.B1(n_234),
.B2(n_235),
.Y(n_242)
);

AOI22xp33_ASAP7_75t_L g243 ( 
.A1(n_242),
.A2(n_230),
.B1(n_240),
.B2(n_235),
.Y(n_243)
);

AOI21xp33_ASAP7_75t_SL g244 ( 
.A1(n_243),
.A2(n_230),
.B(n_228),
.Y(n_244)
);


endmodule