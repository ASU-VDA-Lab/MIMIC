module fake_netlist_911_2563_n_45 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_45);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_45;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_38;

INVx1_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_17),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_11),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

OR2x6_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_19),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_25),
.Y(n_31)
);

AND2x2_ASAP7_75t_SL g32 ( 
.A(n_29),
.B(n_27),
.Y(n_32)
);

OAI21xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_22),
.B(n_28),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_23),
.B1(n_24),
.B2(n_31),
.Y(n_34)
);

AO21x2_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_1),
.B(n_0),
.Y(n_35)
);

INVx2_ASAP7_75t_SL g36 ( 
.A(n_35),
.Y(n_36)
);

CKINVDCx16_ASAP7_75t_R g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_19),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_2),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OAI211xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_7),
.B(n_6),
.C(n_3),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_40),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_10),
.B(n_9),
.C(n_8),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

OAI221xp5_ASAP7_75t_R g45 ( 
.A1(n_44),
.A2(n_43),
.B1(n_20),
.B2(n_12),
.C(n_14),
.Y(n_45)
);


endmodule