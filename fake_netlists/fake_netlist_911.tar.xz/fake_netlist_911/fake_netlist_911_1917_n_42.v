module fake_netlist_911_1917_n_42 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_42);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_42;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_40;
wire n_9;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_32;
wire n_35;
wire n_41;
wire n_26;
wire n_10;
wire n_29;
wire n_36;
wire n_8;
wire n_38;

NOR2xp67_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_1),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

OA21x2_ASAP7_75t_L g10 ( 
.A1(n_2),
.A2(n_0),
.B(n_5),
.Y(n_10)
);

BUFx10_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

AOI21x1_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_6),
.B(n_4),
.Y(n_15)
);

OAI22x1_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_16)
);

A2O1A1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_7),
.B(n_6),
.C(n_0),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_10),
.A2(n_7),
.B(n_12),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_9),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_14),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_20),
.B(n_11),
.Y(n_24)
);

BUFx8_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_17),
.C(n_8),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_23),
.B(n_21),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_25),
.B1(n_16),
.B2(n_21),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_28),
.B1(n_21),
.B2(n_23),
.C(n_30),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_23),
.B1(n_25),
.B2(n_11),
.C(n_8),
.Y(n_35)
);

NAND4xp25_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_11),
.C(n_10),
.D(n_15),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

OAI21xp5_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_15),
.B(n_10),
.Y(n_38)
);

INVx1_ASAP7_75t_SL g39 ( 
.A(n_35),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_11),
.B1(n_37),
.B2(n_38),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_SL g42 ( 
.A1(n_41),
.A2(n_38),
.B1(n_39),
.B2(n_40),
.Y(n_42)
);


endmodule