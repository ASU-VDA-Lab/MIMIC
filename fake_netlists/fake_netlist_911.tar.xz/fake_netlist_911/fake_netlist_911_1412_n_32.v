module fake_netlist_911_1412_n_32 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_32);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_32;

wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_22;
wire n_25;
wire n_26;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

XOR2xp5_ASAP7_75t_L g18 ( 
.A(n_8),
.B(n_2),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

OR2x6_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_17),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_16),
.B(n_6),
.C(n_4),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_20),
.B1(n_21),
.B2(n_19),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_18),
.B1(n_7),
.B2(n_6),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_0),
.Y(n_26)
);

NAND2x1_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_1),
.Y(n_28)
);

CKINVDCx16_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

XNOR2x1_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_3),
.Y(n_30)
);

OR3x1_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_12),
.C(n_10),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_32)
);


endmodule