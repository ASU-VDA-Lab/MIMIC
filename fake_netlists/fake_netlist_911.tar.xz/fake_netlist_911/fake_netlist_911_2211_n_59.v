module fake_netlist_911_2211_n_59 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_59);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_59;

wire n_51;
wire n_33;
wire n_50;
wire n_15;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_16;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_19;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_40;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_32;
wire n_22;
wire n_21;
wire n_35;
wire n_25;
wire n_41;
wire n_42;
wire n_57;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_45;
wire n_44;
wire n_48;
wire n_38;
wire n_56;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_14),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_6),
.B(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_12),
.B(n_3),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_1),
.B(n_4),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_4),
.B(n_5),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_7),
.Y(n_24)
);

O2A1O1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_15),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

CKINVDCx8_ASAP7_75t_R g28 ( 
.A(n_24),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_17),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_16),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_16),
.Y(n_32)
);

NAND2x1_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_19),
.Y(n_33)
);

NAND2x1p5_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_19),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_26),
.A2(n_20),
.B1(n_23),
.B2(n_18),
.Y(n_35)
);

OAI21x1_ASAP7_75t_SL g36 ( 
.A1(n_32),
.A2(n_18),
.B(n_21),
.Y(n_36)
);

AOI21xp33_ASAP7_75t_L g37 ( 
.A1(n_26),
.A2(n_11),
.B(n_10),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_31),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

NAND2xp33_ASAP7_75t_L g40 ( 
.A(n_34),
.B(n_30),
.Y(n_40)
);

OAI221xp5_ASAP7_75t_L g41 ( 
.A1(n_35),
.A2(n_28),
.B1(n_29),
.B2(n_25),
.C(n_31),
.Y(n_41)
);

OAI211xp5_ASAP7_75t_L g42 ( 
.A1(n_35),
.A2(n_28),
.B(n_29),
.C(n_32),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_34),
.B1(n_36),
.B2(n_33),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_37),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_0),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_SL g46 ( 
.A(n_45),
.B(n_39),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_40),
.Y(n_47)
);

INVxp67_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_43),
.B(n_2),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_3),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_49),
.Y(n_51)
);

OAI21xp33_ASAP7_75t_SL g52 ( 
.A1(n_49),
.A2(n_7),
.B(n_47),
.Y(n_52)
);

INVx2_ASAP7_75t_SL g53 ( 
.A(n_46),
.Y(n_53)
);

NOR2x1_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_51),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

INVx1_ASAP7_75t_SL g56 ( 
.A(n_51),
.Y(n_56)
);

BUFx2_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

AOI22xp33_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_52),
.B1(n_56),
.B2(n_58),
.Y(n_59)
);


endmodule