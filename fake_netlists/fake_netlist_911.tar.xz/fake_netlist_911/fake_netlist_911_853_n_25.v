module fake_netlist_911_853_n_25 (n_0, n_2, n_5, n_3, n_4, n_1, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_25;

wire n_15;
wire n_11;
wire n_24;
wire n_6;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_7),
.A2(n_2),
.B(n_1),
.Y(n_13)
);

AO21x1_ASAP7_75t_L g14 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_8),
.A2(n_10),
.B(n_9),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_8),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_13),
.B(n_12),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_14),
.B1(n_11),
.B2(n_3),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_5),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_22),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);


endmodule