module fake_netlist_911_3255_n_1 (n_0, n_1);

input n_0;

output n_1;


BUFx2_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);


endmodule