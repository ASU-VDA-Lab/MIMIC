module fake_netlist_911_3224_n_62 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_62);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_62;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_19;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_21;
wire n_42;
wire n_25;
wire n_22;
wire n_35;
wire n_41;
wire n_32;
wire n_57;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_45;
wire n_44;
wire n_48;
wire n_38;
wire n_56;

INVx1_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVxp67_ASAP7_75t_SL g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_1),
.B(n_6),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_5),
.B(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_14),
.B(n_9),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_22),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_0),
.Y(n_30)
);

INVx4_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

BUFx8_ASAP7_75t_L g32 ( 
.A(n_25),
.Y(n_32)
);

OR2x6_ASAP7_75t_L g33 ( 
.A(n_21),
.B(n_0),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_24),
.B(n_23),
.Y(n_34)
);

AO21x2_ASAP7_75t_L g35 ( 
.A1(n_30),
.A2(n_26),
.B(n_19),
.Y(n_35)
);

OA21x2_ASAP7_75t_L g36 ( 
.A1(n_29),
.A2(n_24),
.B(n_27),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AO31x2_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_31),
.A3(n_35),
.B(n_34),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_33),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_35),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_33),
.Y(n_43)
);

OAI32xp33_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_39),
.A3(n_40),
.B1(n_34),
.B2(n_35),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_41),
.A2(n_33),
.B1(n_36),
.B2(n_20),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_34),
.B(n_36),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_SL g48 ( 
.A1(n_46),
.A2(n_25),
.B1(n_28),
.B2(n_36),
.Y(n_48)
);

NAND2x1_ASAP7_75t_SL g49 ( 
.A(n_45),
.B(n_28),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_32),
.B1(n_35),
.B2(n_36),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_44),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_SL g52 ( 
.A1(n_51),
.A2(n_36),
.B1(n_28),
.B2(n_1),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_L g53 ( 
.A1(n_48),
.A2(n_36),
.B1(n_44),
.B2(n_32),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_49),
.Y(n_54)
);

OAI22xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_50),
.B1(n_34),
.B2(n_35),
.Y(n_55)
);

OAI22xp33_ASAP7_75t_L g56 ( 
.A1(n_51),
.A2(n_15),
.B1(n_3),
.B2(n_2),
.Y(n_56)
);

OAI21x1_ASAP7_75t_L g57 ( 
.A1(n_55),
.A2(n_8),
.B(n_7),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

AND2x4_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_10),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_52),
.Y(n_60)
);

OAI22xp5_ASAP7_75t_SL g61 ( 
.A1(n_60),
.A2(n_53),
.B1(n_15),
.B2(n_2),
.Y(n_61)
);

AOI322xp5_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_17),
.A3(n_57),
.B1(n_58),
.B2(n_59),
.C1(n_60),
.C2(n_56),
.Y(n_62)
);


endmodule