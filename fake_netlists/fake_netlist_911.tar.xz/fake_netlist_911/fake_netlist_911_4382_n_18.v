module fake_netlist_911_4382_n_18 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_18);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_18;

wire n_15;
wire n_11;
wire n_9;
wire n_17;
wire n_13;
wire n_16;
wire n_14;
wire n_10;
wire n_12;

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

NAND2xp33_ASAP7_75t_SL g11 ( 
.A(n_4),
.B(n_3),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_8),
.B(n_2),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

AOI221x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B1(n_11),
.B2(n_0),
.C(n_1),
.Y(n_15)
);

NAND2x1p5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_1),
.Y(n_16)
);

NAND2xp33_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_4),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_5),
.B1(n_6),
.B2(n_7),
.C1(n_11),
.C2(n_9),
.Y(n_18)
);


endmodule