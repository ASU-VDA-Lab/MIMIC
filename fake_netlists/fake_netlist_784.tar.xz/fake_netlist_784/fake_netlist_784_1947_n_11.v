module fake_netlist_784_1947_n_11 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_11);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_11;

wire n_7;
wire n_10;
wire n_8;
wire n_9;

NAND2x1p5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_2),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_3),
.A2(n_6),
.B(n_0),
.Y(n_8)
);

BUFx2_ASAP7_75t_SL g9 ( 
.A(n_5),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_1),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_7),
.B2(n_1),
.Y(n_11)
);


endmodule