module fake_netlist_784_1939_n_15 (n_1, n_0, n_3, n_2, n_4, n_15);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_15;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_14;
wire n_9;
wire n_12;
wire n_13;
wire n_8;

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_2),
.Y(n_7)
);

OA21x2_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

OR2x6_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_7),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B1(n_9),
.B2(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_3),
.B1(n_4),
.B2(n_8),
.C1(n_11),
.C2(n_7),
.Y(n_15)
);


endmodule