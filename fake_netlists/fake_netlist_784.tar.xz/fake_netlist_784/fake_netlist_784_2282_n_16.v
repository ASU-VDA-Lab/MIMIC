module fake_netlist_784_2282_n_16 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_16);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_16;

wire n_15;
wire n_11;
wire n_12;
wire n_8;
wire n_9;
wire n_10;
wire n_13;
wire n_14;

OR2x2_ASAP7_75t_L g8 ( 
.A(n_4),
.B(n_0),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

OA21x2_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_10),
.B2(n_1),
.Y(n_12)
);

INVxp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_8),
.B1(n_6),
.B2(n_5),
.Y(n_14)
);

NAND2x1p5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_3),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_16)
);


endmodule