module fake_netlist_784_2057_n_9 (n_1, n_2, n_0, n_9);

input n_1;
input n_2;
input n_0;

output n_9;

wire n_7;
wire n_5;
wire n_6;
wire n_3;
wire n_4;
wire n_8;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_2),
.Y(n_3)
);

OAI21x1_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

OAI22xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

AOI221xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.C(n_4),
.Y(n_7)
);

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);


endmodule