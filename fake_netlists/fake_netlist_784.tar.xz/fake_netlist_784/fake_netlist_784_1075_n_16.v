module fake_netlist_784_1075_n_16 (n_1, n_2, n_3, n_0, n_16);

input n_1;
input n_2;
input n_3;
input n_0;

output n_16;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_5;
wire n_6;
wire n_14;
wire n_8;
wire n_12;
wire n_13;
wire n_4;
wire n_9;

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_1),
.B(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

NAND2x1p5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

OAI22xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

NAND4xp25_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_6),
.C(n_7),
.D(n_0),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_6),
.B(n_10),
.C(n_0),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_3),
.B(n_2),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_3),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_3),
.B1(n_13),
.B2(n_14),
.Y(n_16)
);


endmodule