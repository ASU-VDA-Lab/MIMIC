module fake_netlist_784_1770_n_24 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_24);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_24;

wire n_20;
wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_9;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_4),
.Y(n_12)
);

OR2x6_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_0),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_1),
.Y(n_14)
);

AOI21x1_ASAP7_75t_L g15 ( 
.A1(n_9),
.A2(n_3),
.B(n_1),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B(n_12),
.Y(n_16)
);

NAND2xp33_ASAP7_75t_R g17 ( 
.A(n_13),
.B(n_14),
.Y(n_17)
);

OR2x6_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_11),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OAI211xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_19),
.B(n_17),
.C(n_18),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_5),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_22),
.B1(n_5),
.B2(n_6),
.Y(n_24)
);


endmodule