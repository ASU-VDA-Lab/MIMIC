module fake_netlist_784_2308_n_8 (n_1, n_2, n_3, n_0, n_8);

input n_1;
input n_2;
input n_3;
input n_0;

output n_8;

wire n_7;
wire n_5;
wire n_6;
wire n_4;

INVx2_ASAP7_75t_SL g4 ( 
.A(n_2),
.Y(n_4)
);

O2A1O1Ixp33_ASAP7_75t_L g5 ( 
.A1(n_1),
.A2(n_3),
.B(n_0),
.C(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

NAND4xp25_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.C(n_4),
.D(n_1),
.Y(n_7)
);

OAI22x1_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.Y(n_8)
);


endmodule