module fake_netlist_784_1629_n_26 (n_1, n_0, n_5, n_3, n_2, n_4, n_26);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_26;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_25;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_23;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_4),
.Y(n_6)
);

BUFx10_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_4),
.Y(n_8)
);

NAND2x1p5_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_3),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_3),
.B(n_1),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_SL g12 ( 
.A1(n_7),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_9),
.A2(n_4),
.B(n_0),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_10),
.C(n_7),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_9),
.B(n_2),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_2),
.B1(n_5),
.B2(n_14),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_12),
.C(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

AOI322xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_12),
.A3(n_13),
.B1(n_5),
.B2(n_2),
.C1(n_15),
.C2(n_11),
.Y(n_21)
);

INVx1_ASAP7_75t_SL g22 ( 
.A(n_20),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_15),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_SL g24 ( 
.A(n_22),
.B(n_19),
.C(n_21),
.D(n_15),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_11),
.B1(n_24),
.B2(n_22),
.Y(n_26)
);


endmodule