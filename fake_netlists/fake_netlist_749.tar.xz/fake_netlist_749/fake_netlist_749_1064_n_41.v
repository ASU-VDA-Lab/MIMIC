module fake_netlist_749_1064_n_41 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_41);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_41;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_13;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

INVx3_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_0),
.B(n_1),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_1),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_13),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

AOI22x1_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_15),
.B(n_18),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_23),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_26),
.Y(n_30)
);

AOI21xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_24),
.B(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_25),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_24),
.B1(n_16),
.B2(n_19),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_30),
.B1(n_14),
.B2(n_16),
.C(n_2),
.Y(n_36)
);

NOR2x1_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_14),
.Y(n_37)
);

INVxp67_ASAP7_75t_SL g38 ( 
.A(n_37),
.Y(n_38)
);

XNOR2x1_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_34),
.Y(n_39)
);

OAI22x1_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_39),
.B1(n_14),
.B2(n_9),
.Y(n_40)
);

AO221x2_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_39),
.B1(n_12),
.B2(n_10),
.C(n_11),
.Y(n_41)
);


endmodule