module fake_netlist_749_1933_n_22 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_22);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_22;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

INVx1_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

AO22x2_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_2),
.B1(n_8),
.B2(n_6),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

AO31x2_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_7),
.A3(n_6),
.B(n_1),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_15),
.B1(n_13),
.B2(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AO22x2_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_15),
.B1(n_7),
.B2(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_14),
.B1(n_10),
.B2(n_4),
.C1(n_12),
.C2(n_5),
.Y(n_22)
);


endmodule