module fake_netlist_749_1560_n_42 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_42);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_42;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_16;
wire n_13;
wire n_39;
wire n_11;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_10;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_12;
wire n_41;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_4),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

BUFx8_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_9),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_0),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_3),
.B(n_2),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_11),
.B(n_2),
.Y(n_22)
);

O2A1O1Ixp5_ASAP7_75t_L g23 ( 
.A1(n_15),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_19),
.Y(n_25)
);

OR2x6_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_17),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_20),
.A2(n_10),
.B1(n_12),
.B2(n_17),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_18),
.B(n_10),
.Y(n_28)
);

AND2x4_ASAP7_75t_SL g29 ( 
.A(n_22),
.B(n_14),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_18),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_19),
.Y(n_31)
);

INVxp67_ASAP7_75t_SL g32 ( 
.A(n_29),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_26),
.Y(n_34)
);

NOR2x1_ASAP7_75t_SL g35 ( 
.A(n_34),
.B(n_26),
.Y(n_35)
);

OAI22xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_32),
.B1(n_25),
.B2(n_23),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_R g37 ( 
.A(n_35),
.B(n_16),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_21),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_21),
.B(n_19),
.Y(n_39)
);

AOI22x1_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_24),
.B1(n_6),
.B2(n_5),
.Y(n_40)
);

CKINVDCx20_ASAP7_75t_R g41 ( 
.A(n_37),
.Y(n_41)
);

AOI222xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_14),
.B1(n_38),
.B2(n_40),
.C1(n_6),
.C2(n_24),
.Y(n_42)
);


endmodule