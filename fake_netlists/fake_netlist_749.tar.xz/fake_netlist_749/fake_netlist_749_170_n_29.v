module fake_netlist_749_170_n_29 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_29);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_29;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_15;

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_7),
.B(n_10),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_11),
.B(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_4),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_7),
.B(n_6),
.C(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_18),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_23),
.B1(n_19),
.B2(n_15),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_6),
.B(n_19),
.C(n_17),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_3),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_9),
.B1(n_8),
.B2(n_5),
.Y(n_29)
);


endmodule