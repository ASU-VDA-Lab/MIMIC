module fake_netlist_749_437_n_25 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_8, n_25);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_25;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_24;
wire n_10;
wire n_9;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_6),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_2),
.B(n_6),
.Y(n_12)
);

OR2x6_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_0),
.Y(n_13)
);

CKINVDCx6p67_ASAP7_75t_R g14 ( 
.A(n_12),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_SL g15 ( 
.A1(n_13),
.A2(n_10),
.B1(n_9),
.B2(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.B1(n_15),
.B2(n_13),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_20),
.B(n_3),
.Y(n_21)
);

AOI211xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_5),
.B(n_4),
.C(n_1),
.Y(n_22)
);

AO22x2_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_7),
.B1(n_5),
.B2(n_4),
.Y(n_23)
);

OR3x1_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.C(n_8),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_R g25 ( 
.A1(n_24),
.A2(n_23),
.B1(n_22),
.B2(n_21),
.Y(n_25)
);


endmodule