module fake_netlist_749_1001_n_25 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_25);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_25;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_24;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_1),
.B(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_4),
.Y(n_13)
);

INVx4_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_2),
.A2(n_9),
.B1(n_6),
.B2(n_4),
.Y(n_16)
);

OA22x2_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_7),
.B1(n_6),
.B2(n_3),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_12),
.B(n_15),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_17),
.B(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AO22x2_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_16),
.B1(n_13),
.B2(n_14),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_7),
.B(n_23),
.Y(n_25)
);


endmodule