module fake_netlist_749_1621_n_30 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_30);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_30;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_12;
wire n_29;

OR2x2_ASAP7_75t_L g11 ( 
.A(n_3),
.B(n_6),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_1),
.B(n_4),
.Y(n_12)
);

BUFx2_ASAP7_75t_SL g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_14),
.B1(n_11),
.B2(n_15),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_13),
.Y(n_19)
);

AOI21x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.B(n_8),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_22),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_22),
.B(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

NAND3xp33_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_22),
.C(n_25),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_21),
.B1(n_5),
.B2(n_2),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

AOI322xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_9),
.A3(n_10),
.B1(n_21),
.B2(n_27),
.C1(n_18),
.C2(n_12),
.Y(n_30)
);


endmodule