module fake_netlist_883_2957_n_37 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_37);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_37;

wire n_33;
wire n_34;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_31;
wire n_21;
wire n_25;
wire n_32;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

AND2x6_ASAP7_75t_L g22 ( 
.A(n_11),
.B(n_10),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_18),
.B(n_7),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_SL g24 ( 
.A(n_4),
.B(n_9),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_12),
.B(n_18),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_16),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_5),
.B1(n_3),
.B2(n_2),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_21),
.B(n_6),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_20),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B1(n_25),
.B2(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_24),
.B(n_26),
.C(n_22),
.Y(n_33)
);

NAND2xp33_ASAP7_75t_SL g34 ( 
.A(n_33),
.B(n_8),
.Y(n_34)
);

INVxp67_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_35),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_17),
.B1(n_15),
.B2(n_14),
.Y(n_37)
);


endmodule