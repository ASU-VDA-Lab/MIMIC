module fake_netlist_883_439_n_28 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_28);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_28;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_12),
.Y(n_14)
);

BUFx10_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_10),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_SL g20 ( 
.A1(n_17),
.A2(n_18),
.B(n_16),
.C(n_15),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_15),
.B1(n_17),
.B2(n_14),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_17),
.B1(n_15),
.B2(n_4),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

OAI211xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_22),
.B(n_7),
.C(n_6),
.Y(n_24)
);

NAND4xp25_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_7),
.C(n_1),
.D(n_0),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_11),
.B1(n_8),
.B2(n_2),
.Y(n_28)
);


endmodule