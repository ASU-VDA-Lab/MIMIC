module fake_netlist_883_2484_n_37 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_37);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_37;

wire n_33;
wire n_34;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_31;
wire n_21;
wire n_25;
wire n_22;
wire n_32;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_1),
.B(n_3),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_9),
.B(n_2),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_18),
.B(n_10),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_23),
.A2(n_25),
.B1(n_20),
.B2(n_19),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_25),
.B(n_24),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_21),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_22),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_29),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_14),
.B1(n_11),
.B2(n_8),
.Y(n_35)
);

XOR2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_15),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_17),
.B2(n_16),
.Y(n_37)
);


endmodule