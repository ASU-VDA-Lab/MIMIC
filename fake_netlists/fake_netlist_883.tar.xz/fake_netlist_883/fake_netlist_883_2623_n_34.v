module fake_netlist_883_2623_n_34 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_34);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_34;

wire n_33;
wire n_15;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_32;
wire n_26;
wire n_29;

AND2x2_ASAP7_75t_L g12 ( 
.A(n_5),
.B(n_3),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

OA21x2_ASAP7_75t_L g15 ( 
.A1(n_9),
.A2(n_11),
.B(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_10),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_12),
.B1(n_17),
.B2(n_15),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_15),
.B1(n_16),
.B2(n_1),
.Y(n_22)
);

OAI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B1(n_20),
.B2(n_16),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_4),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_27),
.B(n_6),
.Y(n_31)
);

NAND4xp25_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_2),
.C(n_8),
.D(n_31),
.Y(n_32)
);

NOR2xp67_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_29),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);


endmodule