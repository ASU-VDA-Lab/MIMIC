module fake_netlist_883_1889_n_13 (n_0, n_1, n_3, n_2, n_13);

input n_0;
input n_1;
input n_3;
input n_2;

output n_13;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

BUFx3_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AOI221xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.C(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_0),
.Y(n_7)
);

OAI221xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_4),
.B1(n_5),
.B2(n_0),
.C(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_3),
.B2(n_0),
.C(n_1),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_2),
.C(n_1),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_2),
.B1(n_11),
.B2(n_8),
.Y(n_13)
);


endmodule