module fake_netlist_883_1402_n_172 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_172);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_172;

wire n_118;
wire n_100;
wire n_60;
wire n_104;
wire n_101;
wire n_52;
wire n_99;
wire n_127;
wire n_152;
wire n_154;
wire n_151;
wire n_111;
wire n_153;
wire n_30;
wire n_116;
wire n_164;
wire n_64;
wire n_102;
wire n_93;
wire n_157;
wire n_66;
wire n_65;
wire n_143;
wire n_88;
wire n_169;
wire n_27;
wire n_94;
wire n_91;
wire n_71;
wire n_135;
wire n_80;
wire n_149;
wire n_29;
wire n_69;
wire n_83;
wire n_134;
wire n_96;
wire n_128;
wire n_117;
wire n_131;
wire n_165;
wire n_51;
wire n_50;
wire n_162;
wire n_55;
wire n_123;
wire n_110;
wire n_46;
wire n_144;
wire n_54;
wire n_28;
wire n_59;
wire n_166;
wire n_70;
wire n_40;
wire n_39;
wire n_132;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_126;
wire n_62;
wire n_120;
wire n_148;
wire n_150;
wire n_141;
wire n_26;
wire n_44;
wire n_79;
wire n_87;
wire n_142;
wire n_159;
wire n_115;
wire n_155;
wire n_33;
wire n_113;
wire n_129;
wire n_77;
wire n_107;
wire n_95;
wire n_53;
wire n_161;
wire n_106;
wire n_137;
wire n_90;
wire n_167;
wire n_146;
wire n_81;
wire n_84;
wire n_171;
wire n_140;
wire n_61;
wire n_130;
wire n_122;
wire n_43;
wire n_138;
wire n_170;
wire n_136;
wire n_139;
wire n_48;
wire n_72;
wire n_133;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_125;
wire n_34;
wire n_103;
wire n_37;
wire n_160;
wire n_108;
wire n_75;
wire n_47;
wire n_68;
wire n_158;
wire n_86;
wire n_63;
wire n_163;
wire n_105;
wire n_114;
wire n_124;
wire n_145;
wire n_85;
wire n_112;
wire n_156;
wire n_49;
wire n_58;
wire n_109;
wire n_147;
wire n_168;
wire n_67;
wire n_25;
wire n_57;
wire n_35;
wire n_121;
wire n_97;
wire n_98;
wire n_119;
wire n_36;
wire n_45;
wire n_73;
wire n_89;
wire n_92;
wire n_82;
wire n_78;

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_9),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

CKINVDCx14_ASAP7_75t_R g29 ( 
.A(n_24),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_17),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_7),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_20),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_13),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_18),
.Y(n_35)
);

INVxp67_ASAP7_75t_SL g36 ( 
.A(n_24),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_4),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_26),
.Y(n_38)
);

INVx6_ASAP7_75t_L g39 ( 
.A(n_29),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_26),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_26),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_25),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_25),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_25),
.Y(n_44)
);

OAI221xp5_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_36),
.B1(n_32),
.B2(n_28),
.C(n_30),
.Y(n_45)
);

NOR2xp67_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_32),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_42),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_42),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_43),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_43),
.Y(n_50)
);

NOR2xp67_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_27),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_44),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_47),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_SL g54 ( 
.A(n_51),
.B(n_31),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_46),
.B(n_38),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_47),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_48),
.B(n_39),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_45),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_48),
.A2(n_29),
.B1(n_36),
.B2(n_34),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_49),
.B(n_39),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_49),
.Y(n_61)
);

OAI22xp5_ASAP7_75t_SL g62 ( 
.A1(n_50),
.A2(n_34),
.B1(n_37),
.B2(n_28),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_56),
.Y(n_63)
);

OR2x6_ASAP7_75t_SL g64 ( 
.A(n_59),
.B(n_37),
.Y(n_64)
);

AOI22xp5_ASAP7_75t_L g65 ( 
.A1(n_58),
.A2(n_52),
.B1(n_50),
.B2(n_28),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_SL g66 ( 
.A(n_57),
.B(n_60),
.Y(n_66)
);

AOI221x1_ASAP7_75t_L g67 ( 
.A1(n_56),
.A2(n_52),
.B1(n_33),
.B2(n_30),
.C(n_39),
.Y(n_67)
);

A2O1A1Ixp33_ASAP7_75t_L g68 ( 
.A1(n_53),
.A2(n_33),
.B(n_30),
.C(n_35),
.Y(n_68)
);

NOR2xp67_ASAP7_75t_L g69 ( 
.A(n_60),
.B(n_33),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_53),
.Y(n_70)
);

OR2x2_ASAP7_75t_L g71 ( 
.A(n_59),
.B(n_0),
.Y(n_71)
);

NAND2xp5_ASAP7_75t_L g72 ( 
.A(n_57),
.B(n_55),
.Y(n_72)
);

AOI22xp33_ASAP7_75t_L g73 ( 
.A1(n_71),
.A2(n_62),
.B1(n_63),
.B2(n_65),
.Y(n_73)
);

AND2x2_ASAP7_75t_L g74 ( 
.A(n_72),
.B(n_55),
.Y(n_74)
);

OAI21xp5_ASAP7_75t_L g75 ( 
.A1(n_67),
.A2(n_61),
.B(n_53),
.Y(n_75)
);

AND2x2_ASAP7_75t_L g76 ( 
.A(n_65),
.B(n_61),
.Y(n_76)
);

BUFx2_ASAP7_75t_L g77 ( 
.A(n_64),
.Y(n_77)
);

INVx2_ASAP7_75t_L g78 ( 
.A(n_70),
.Y(n_78)
);

AND2x2_ASAP7_75t_L g79 ( 
.A(n_66),
.B(n_63),
.Y(n_79)
);

AND2x2_ASAP7_75t_L g80 ( 
.A(n_69),
.B(n_61),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_70),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_78),
.Y(n_82)
);

INVxp67_ASAP7_75t_L g83 ( 
.A(n_76),
.Y(n_83)
);

BUFx2_ASAP7_75t_L g84 ( 
.A(n_79),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_78),
.Y(n_85)
);

NAND2x1_ASAP7_75t_L g86 ( 
.A(n_78),
.B(n_69),
.Y(n_86)
);

BUFx3_ASAP7_75t_L g87 ( 
.A(n_79),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_81),
.Y(n_88)
);

HB1xp67_ASAP7_75t_L g89 ( 
.A(n_87),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_82),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_82),
.Y(n_91)
);

AND2x2_ASAP7_75t_L g92 ( 
.A(n_83),
.B(n_74),
.Y(n_92)
);

INVx2_ASAP7_75t_L g93 ( 
.A(n_85),
.Y(n_93)
);

OR2x2_ASAP7_75t_L g94 ( 
.A(n_83),
.B(n_76),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_85),
.Y(n_95)
);

INVx2_ASAP7_75t_L g96 ( 
.A(n_90),
.Y(n_96)
);

OR2x2_ASAP7_75t_L g97 ( 
.A(n_94),
.B(n_84),
.Y(n_97)
);

INVx1_ASAP7_75t_L g98 ( 
.A(n_91),
.Y(n_98)
);

AND2x4_ASAP7_75t_L g99 ( 
.A(n_90),
.B(n_87),
.Y(n_99)
);

HB1xp67_ASAP7_75t_L g100 ( 
.A(n_89),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_91),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_95),
.Y(n_102)
);

OAI22xp5_ASAP7_75t_L g103 ( 
.A1(n_94),
.A2(n_73),
.B1(n_64),
.B2(n_71),
.Y(n_103)
);

OAI22xp5_ASAP7_75t_L g104 ( 
.A1(n_92),
.A2(n_73),
.B1(n_77),
.B2(n_62),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_97),
.B(n_92),
.Y(n_105)
);

NOR2x1_ASAP7_75t_L g106 ( 
.A(n_98),
.B(n_95),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_98),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_101),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_101),
.Y(n_109)
);

NAND2xp5_ASAP7_75t_L g110 ( 
.A(n_97),
.B(n_84),
.Y(n_110)
);

OAI31xp33_ASAP7_75t_SL g111 ( 
.A1(n_104),
.A2(n_103),
.A3(n_102),
.B(n_99),
.Y(n_111)
);

NAND2xp5_ASAP7_75t_L g112 ( 
.A(n_100),
.B(n_84),
.Y(n_112)
);

AOI21xp5_ASAP7_75t_L g113 ( 
.A1(n_99),
.A2(n_86),
.B(n_75),
.Y(n_113)
);

INVx1_ASAP7_75t_SL g114 ( 
.A(n_99),
.Y(n_114)
);

NAND2xp5_ASAP7_75t_L g115 ( 
.A(n_99),
.B(n_87),
.Y(n_115)
);

AND2x4_ASAP7_75t_L g116 ( 
.A(n_96),
.B(n_90),
.Y(n_116)
);

HB1xp67_ASAP7_75t_L g117 ( 
.A(n_96),
.Y(n_117)
);

NAND2xp5_ASAP7_75t_L g118 ( 
.A(n_102),
.B(n_93),
.Y(n_118)
);

AND2x2_ASAP7_75t_L g119 ( 
.A(n_107),
.B(n_93),
.Y(n_119)
);

NAND2xp5_ASAP7_75t_SL g120 ( 
.A(n_111),
.B(n_93),
.Y(n_120)
);

BUFx6f_ASAP7_75t_L g121 ( 
.A(n_116),
.Y(n_121)
);

AND2x2_ASAP7_75t_L g122 ( 
.A(n_107),
.B(n_108),
.Y(n_122)
);

NOR3x1_ASAP7_75t_L g123 ( 
.A(n_105),
.B(n_77),
.C(n_54),
.Y(n_123)
);

NOR2x1_ASAP7_75t_R g124 ( 
.A(n_112),
.B(n_115),
.Y(n_124)
);

NAND2xp5_ASAP7_75t_L g125 ( 
.A(n_110),
.B(n_68),
.Y(n_125)
);

OR2x2_ASAP7_75t_L g126 ( 
.A(n_108),
.B(n_75),
.Y(n_126)
);

NAND2xp5_ASAP7_75t_SL g127 ( 
.A(n_116),
.B(n_88),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_109),
.Y(n_128)
);

NOR2xp33_ASAP7_75t_L g129 ( 
.A(n_114),
.B(n_0),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_109),
.Y(n_130)
);

INVx1_ASAP7_75t_L g131 ( 
.A(n_106),
.Y(n_131)
);

NAND3xp33_ASAP7_75t_L g132 ( 
.A(n_106),
.B(n_113),
.C(n_118),
.Y(n_132)
);

NOR3xp33_ASAP7_75t_L g133 ( 
.A(n_114),
.B(n_74),
.C(n_86),
.Y(n_133)
);

NOR3xp33_ASAP7_75t_SL g134 ( 
.A(n_116),
.B(n_88),
.C(n_67),
.Y(n_134)
);

NAND2xp5_ASAP7_75t_L g135 ( 
.A(n_116),
.B(n_1),
.Y(n_135)
);

INVx1_ASAP7_75t_L g136 ( 
.A(n_128),
.Y(n_136)
);

NAND2xp5_ASAP7_75t_L g137 ( 
.A(n_122),
.B(n_117),
.Y(n_137)
);

NAND2xp5_ASAP7_75t_L g138 ( 
.A(n_122),
.B(n_1),
.Y(n_138)
);

NOR3xp33_ASAP7_75t_L g139 ( 
.A(n_125),
.B(n_135),
.C(n_129),
.Y(n_139)
);

AOI221x1_ASAP7_75t_SL g140 ( 
.A1(n_128),
.A2(n_3),
.B1(n_2),
.B2(n_4),
.C(n_5),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_130),
.Y(n_141)
);

NAND4xp25_ASAP7_75t_L g142 ( 
.A(n_123),
.B(n_6),
.C(n_3),
.D(n_2),
.Y(n_142)
);

NAND2xp5_ASAP7_75t_SL g143 ( 
.A(n_132),
.B(n_80),
.Y(n_143)
);

NAND3xp33_ASAP7_75t_L g144 ( 
.A(n_131),
.B(n_134),
.C(n_120),
.Y(n_144)
);

NOR3xp33_ASAP7_75t_L g145 ( 
.A(n_131),
.B(n_133),
.C(n_124),
.Y(n_145)
);

NOR2xp33_ASAP7_75t_L g146 ( 
.A(n_130),
.B(n_6),
.Y(n_146)
);

NAND2xp5_ASAP7_75t_L g147 ( 
.A(n_119),
.B(n_7),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_119),
.Y(n_148)
);

INVx2_ASAP7_75t_L g149 ( 
.A(n_121),
.Y(n_149)
);

NOR2x1_ASAP7_75t_SL g150 ( 
.A(n_144),
.B(n_121),
.Y(n_150)
);

OR2x2_ASAP7_75t_L g151 ( 
.A(n_137),
.B(n_121),
.Y(n_151)
);

AOI221xp5_ASAP7_75t_L g152 ( 
.A1(n_140),
.A2(n_9),
.B1(n_8),
.B2(n_10),
.C(n_11),
.Y(n_152)
);

AOI22xp5_ASAP7_75t_L g153 ( 
.A1(n_145),
.A2(n_121),
.B1(n_127),
.B2(n_126),
.Y(n_153)
);

O2A1O1Ixp33_ASAP7_75t_L g154 ( 
.A1(n_142),
.A2(n_126),
.B(n_123),
.C(n_8),
.Y(n_154)
);

OR2x2_ASAP7_75t_L g155 ( 
.A(n_148),
.B(n_121),
.Y(n_155)
);

INVxp67_ASAP7_75t_L g156 ( 
.A(n_138),
.Y(n_156)
);

NOR2x1p5_ASAP7_75t_L g157 ( 
.A(n_147),
.B(n_81),
.Y(n_157)
);

AOI21xp5_ASAP7_75t_L g158 ( 
.A1(n_143),
.A2(n_80),
.B(n_81),
.Y(n_158)
);

AOI211x1_ASAP7_75t_L g159 ( 
.A1(n_143),
.A2(n_12),
.B(n_11),
.C(n_10),
.Y(n_159)
);

NAND2xp5_ASAP7_75t_L g160 ( 
.A(n_156),
.B(n_136),
.Y(n_160)
);

AOI222xp33_ASAP7_75t_L g161 ( 
.A1(n_152),
.A2(n_146),
.B1(n_150),
.B2(n_154),
.C1(n_157),
.C2(n_159),
.Y(n_161)
);

OAI211xp5_ASAP7_75t_L g162 ( 
.A1(n_152),
.A2(n_146),
.B(n_139),
.C(n_141),
.Y(n_162)
);

NOR3xp33_ASAP7_75t_L g163 ( 
.A(n_153),
.B(n_149),
.C(n_12),
.Y(n_163)
);

XOR2x2_ASAP7_75t_L g164 ( 
.A(n_151),
.B(n_13),
.Y(n_164)
);

AND4x1_ASAP7_75t_L g165 ( 
.A(n_158),
.B(n_16),
.C(n_15),
.D(n_14),
.Y(n_165)
);

AOI211xp5_ASAP7_75t_L g166 ( 
.A1(n_162),
.A2(n_149),
.B(n_155),
.C(n_14),
.Y(n_166)
);

AND3x4_ASAP7_75t_L g167 ( 
.A(n_163),
.B(n_16),
.C(n_15),
.Y(n_167)
);

OAI22xp5_ASAP7_75t_L g168 ( 
.A1(n_163),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_168)
);

XOR2xp5_ASAP7_75t_L g169 ( 
.A(n_168),
.B(n_164),
.Y(n_169)
);

OAI322xp33_ASAP7_75t_L g170 ( 
.A1(n_166),
.A2(n_160),
.A3(n_161),
.B1(n_165),
.B2(n_20),
.C1(n_19),
.C2(n_21),
.Y(n_170)
);

AOI21xp33_ASAP7_75t_L g171 ( 
.A1(n_169),
.A2(n_167),
.B(n_22),
.Y(n_171)
);

OAI22xp33_ASAP7_75t_L g172 ( 
.A1(n_171),
.A2(n_170),
.B1(n_23),
.B2(n_22),
.Y(n_172)
);


endmodule