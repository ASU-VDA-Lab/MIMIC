module fake_netlist_883_2079_n_38 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_38);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_38;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

BUFx8_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

BUFx8_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_SL g18 ( 
.A(n_6),
.B(n_5),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_4),
.B(n_2),
.Y(n_19)
);

INVxp67_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_1),
.B(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_19),
.B(n_4),
.C(n_1),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

AOI211xp5_ASAP7_75t_L g26 ( 
.A1(n_22),
.A2(n_18),
.B(n_21),
.C(n_16),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_23),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AOI322xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_18),
.A3(n_28),
.B1(n_24),
.B2(n_6),
.C1(n_5),
.C2(n_7),
.Y(n_32)
);

AOI211xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_28),
.B(n_7),
.C(n_17),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_SL g34 ( 
.A(n_32),
.B(n_17),
.C(n_3),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_37),
.B1(n_15),
.B2(n_11),
.C(n_13),
.Y(n_38)
);


endmodule