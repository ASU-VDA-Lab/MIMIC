module fake_netlist_883_696_n_27 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_27);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_27;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_20;
wire n_18;
wire n_17;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

INVx2_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_10),
.B1(n_9),
.B2(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_5),
.A2(n_2),
.B1(n_6),
.B2(n_12),
.Y(n_17)
);

OAI22xp33_ASAP7_75t_L g18 ( 
.A1(n_7),
.A2(n_11),
.B1(n_0),
.B2(n_8),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_3),
.B(n_1),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_1),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_18),
.B1(n_14),
.B2(n_16),
.C(n_17),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NAND4xp75_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_18),
.C(n_19),
.D(n_14),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_22),
.B1(n_20),
.B2(n_3),
.C(n_4),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

AOI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_25),
.B1(n_7),
.B2(n_5),
.C1(n_10),
.C2(n_6),
.Y(n_27)
);


endmodule