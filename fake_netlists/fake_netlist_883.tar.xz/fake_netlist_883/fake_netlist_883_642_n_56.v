module fake_netlist_883_642_n_56 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_56);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_56;

wire n_51;
wire n_33;
wire n_50;
wire n_15;
wire n_11;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_16;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_19;
wire n_12;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_13;
wire n_21;
wire n_25;
wire n_14;
wire n_22;
wire n_35;
wire n_42;
wire n_41;
wire n_32;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_5),
.B(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_3),
.B(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_1),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_1),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_11),
.B(n_7),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_11),
.B(n_7),
.Y(n_22)
);

CKINVDCx6p67_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

A2O1A1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_14),
.B(n_11),
.C(n_13),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_16),
.A2(n_7),
.B1(n_4),
.B2(n_3),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_17),
.B(n_4),
.Y(n_28)
);

NOR2xp67_ASAP7_75t_L g29 ( 
.A(n_16),
.B(n_6),
.Y(n_29)
);

AO32x2_ASAP7_75t_L g30 ( 
.A1(n_15),
.A2(n_18),
.A3(n_12),
.B1(n_19),
.B2(n_20),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_15),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_25),
.B(n_8),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_24),
.A2(n_8),
.B1(n_10),
.B2(n_28),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_25),
.B(n_10),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

NAND2x1_ASAP7_75t_L g36 ( 
.A(n_21),
.B(n_29),
.Y(n_36)
);

NAND3xp33_ASAP7_75t_SL g37 ( 
.A(n_24),
.B(n_27),
.C(n_21),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_23),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_30),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_31),
.B(n_30),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_36),
.B(n_30),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_37),
.B1(n_36),
.B2(n_33),
.Y(n_43)
);

INVxp67_ASAP7_75t_L g44 ( 
.A(n_38),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_39),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_39),
.B(n_31),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_39),
.Y(n_47)
);

AOI211xp5_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_41),
.B(n_38),
.C(n_40),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

OAI21xp5_ASAP7_75t_L g50 ( 
.A1(n_43),
.A2(n_42),
.B(n_40),
.Y(n_50)
);

AOI221xp5_ASAP7_75t_SL g51 ( 
.A1(n_46),
.A2(n_41),
.B1(n_47),
.B2(n_45),
.C(n_40),
.Y(n_51)
);

NAND3xp33_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_51),
.C(n_42),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_40),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_49),
.Y(n_54)
);

CKINVDCx20_ASAP7_75t_R g55 ( 
.A(n_53),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_SL g56 ( 
.A1(n_55),
.A2(n_54),
.B1(n_32),
.B2(n_52),
.Y(n_56)
);


endmodule