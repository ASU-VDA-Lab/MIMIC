module fake_netlist_883_468_n_14 (n_0, n_1, n_3, n_2, n_14);

input n_0;
input n_1;
input n_3;
input n_2;

output n_14;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

NAND2xp33_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_0),
.Y(n_5)
);

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_6)
);

OAI21xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AOI211x1_ASAP7_75t_SL g10 ( 
.A1(n_8),
.A2(n_6),
.B(n_1),
.C(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NOR2x1_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

AOI31xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_3),
.A3(n_2),
.B(n_1),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_3),
.B1(n_12),
.B2(n_7),
.C1(n_11),
.C2(n_8),
.Y(n_14)
);


endmodule