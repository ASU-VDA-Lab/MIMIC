module fake_netlist_883_1347_n_161 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_161);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_161;

wire n_118;
wire n_100;
wire n_60;
wire n_104;
wire n_101;
wire n_52;
wire n_99;
wire n_127;
wire n_151;
wire n_152;
wire n_111;
wire n_154;
wire n_153;
wire n_30;
wire n_116;
wire n_23;
wire n_64;
wire n_102;
wire n_93;
wire n_157;
wire n_66;
wire n_65;
wire n_143;
wire n_88;
wire n_27;
wire n_94;
wire n_91;
wire n_71;
wire n_135;
wire n_80;
wire n_149;
wire n_29;
wire n_69;
wire n_83;
wire n_134;
wire n_96;
wire n_128;
wire n_117;
wire n_131;
wire n_51;
wire n_50;
wire n_55;
wire n_123;
wire n_110;
wire n_46;
wire n_144;
wire n_54;
wire n_28;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_132;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_126;
wire n_62;
wire n_120;
wire n_141;
wire n_150;
wire n_148;
wire n_44;
wire n_26;
wire n_79;
wire n_87;
wire n_142;
wire n_159;
wire n_115;
wire n_155;
wire n_33;
wire n_113;
wire n_24;
wire n_129;
wire n_77;
wire n_107;
wire n_95;
wire n_53;
wire n_106;
wire n_137;
wire n_90;
wire n_146;
wire n_81;
wire n_84;
wire n_140;
wire n_61;
wire n_21;
wire n_22;
wire n_130;
wire n_122;
wire n_43;
wire n_138;
wire n_139;
wire n_136;
wire n_48;
wire n_72;
wire n_133;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_125;
wire n_34;
wire n_103;
wire n_37;
wire n_160;
wire n_108;
wire n_75;
wire n_47;
wire n_68;
wire n_158;
wire n_86;
wire n_63;
wire n_105;
wire n_114;
wire n_124;
wire n_145;
wire n_85;
wire n_112;
wire n_156;
wire n_49;
wire n_58;
wire n_109;
wire n_147;
wire n_67;
wire n_25;
wire n_35;
wire n_57;
wire n_121;
wire n_97;
wire n_98;
wire n_119;
wire n_36;
wire n_45;
wire n_73;
wire n_89;
wire n_92;
wire n_82;
wire n_78;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_16),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_13),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_4),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_19),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_1),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_0),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_10),
.Y(n_32)
);

INVxp67_ASAP7_75t_SL g33 ( 
.A(n_10),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_28),
.Y(n_36)
);

BUFx3_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_22),
.B(n_2),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_25),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_27),
.B(n_2),
.Y(n_41)
);

BUFx6f_ASAP7_75t_L g42 ( 
.A(n_35),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_38),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_38),
.B(n_27),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_37),
.B(n_24),
.Y(n_46)
);

INVx2_ASAP7_75t_SL g47 ( 
.A(n_37),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_37),
.B(n_22),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_35),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_35),
.Y(n_50)
);

A2O1A1Ixp33_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_39),
.B(n_36),
.C(n_35),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_45),
.B(n_46),
.Y(n_52)
);

O2A1O1Ixp33_ASAP7_75t_L g53 ( 
.A1(n_43),
.A2(n_41),
.B(n_39),
.C(n_23),
.Y(n_53)
);

AO31x2_ASAP7_75t_L g54 ( 
.A1(n_49),
.A2(n_39),
.A3(n_41),
.B(n_24),
.Y(n_54)
);

AOI22xp5_ASAP7_75t_L g55 ( 
.A1(n_46),
.A2(n_33),
.B1(n_23),
.B2(n_21),
.Y(n_55)
);

AND2x2_ASAP7_75t_SL g56 ( 
.A(n_46),
.B(n_31),
.Y(n_56)
);

OAI21x1_ASAP7_75t_L g57 ( 
.A1(n_50),
.A2(n_36),
.B(n_35),
.Y(n_57)
);

CKINVDCx11_ASAP7_75t_R g58 ( 
.A(n_46),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_SL g59 ( 
.A(n_48),
.B(n_34),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_47),
.B(n_35),
.Y(n_60)
);

INVx3_ASAP7_75t_L g61 ( 
.A(n_42),
.Y(n_61)
);

CKINVDCx5p33_ASAP7_75t_R g62 ( 
.A(n_58),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_57),
.Y(n_63)
);

AND2x2_ASAP7_75t_L g64 ( 
.A(n_52),
.B(n_45),
.Y(n_64)
);

OAI22xp5_ASAP7_75t_L g65 ( 
.A1(n_56),
.A2(n_41),
.B1(n_40),
.B2(n_34),
.Y(n_65)
);

O2A1O1Ixp33_ASAP7_75t_L g66 ( 
.A1(n_53),
.A2(n_43),
.B(n_44),
.C(n_45),
.Y(n_66)
);

CKINVDCx5p33_ASAP7_75t_R g67 ( 
.A(n_55),
.Y(n_67)
);

OA21x2_ASAP7_75t_L g68 ( 
.A1(n_51),
.A2(n_50),
.B(n_43),
.Y(n_68)
);

AND2x4_ASAP7_75t_L g69 ( 
.A(n_52),
.B(n_46),
.Y(n_69)
);

NAND2xp5_ASAP7_75t_L g70 ( 
.A(n_56),
.B(n_47),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_56),
.B(n_47),
.Y(n_71)
);

AND2x2_ASAP7_75t_L g72 ( 
.A(n_54),
.B(n_46),
.Y(n_72)
);

OR2x2_ASAP7_75t_L g73 ( 
.A(n_65),
.B(n_59),
.Y(n_73)
);

AO21x2_ASAP7_75t_L g74 ( 
.A1(n_70),
.A2(n_60),
.B(n_53),
.Y(n_74)
);

AND2x4_ASAP7_75t_L g75 ( 
.A(n_69),
.B(n_54),
.Y(n_75)
);

NOR2x1_ASAP7_75t_L g76 ( 
.A(n_70),
.B(n_61),
.Y(n_76)
);

AND2x2_ASAP7_75t_L g77 ( 
.A(n_64),
.B(n_54),
.Y(n_77)
);

NOR2xp33_ASAP7_75t_L g78 ( 
.A(n_65),
.B(n_55),
.Y(n_78)
);

AND2x2_ASAP7_75t_L g79 ( 
.A(n_64),
.B(n_54),
.Y(n_79)
);

INVx2_ASAP7_75t_L g80 ( 
.A(n_63),
.Y(n_80)
);

INVx4_ASAP7_75t_L g81 ( 
.A(n_69),
.Y(n_81)
);

OR2x2_ASAP7_75t_L g82 ( 
.A(n_67),
.B(n_65),
.Y(n_82)
);

OA21x2_ASAP7_75t_L g83 ( 
.A1(n_80),
.A2(n_63),
.B(n_57),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_80),
.Y(n_84)
);

INVx2_ASAP7_75t_SL g85 ( 
.A(n_81),
.Y(n_85)
);

BUFx2_ASAP7_75t_L g86 ( 
.A(n_81),
.Y(n_86)
);

INVx2_ASAP7_75t_L g87 ( 
.A(n_80),
.Y(n_87)
);

OAI21xp5_ASAP7_75t_L g88 ( 
.A1(n_77),
.A2(n_66),
.B(n_68),
.Y(n_88)
);

NAND2x1_ASAP7_75t_L g89 ( 
.A(n_81),
.B(n_63),
.Y(n_89)
);

AOI21xp33_ASAP7_75t_L g90 ( 
.A1(n_88),
.A2(n_78),
.B(n_73),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_84),
.Y(n_91)
);

AND2x2_ASAP7_75t_L g92 ( 
.A(n_88),
.B(n_79),
.Y(n_92)
);

OR2x2_ASAP7_75t_L g93 ( 
.A(n_87),
.B(n_82),
.Y(n_93)
);

NAND2xp5_ASAP7_75t_L g94 ( 
.A(n_85),
.B(n_79),
.Y(n_94)
);

AOI22xp33_ASAP7_75t_L g95 ( 
.A1(n_86),
.A2(n_73),
.B1(n_82),
.B2(n_67),
.Y(n_95)
);

INVx1_ASAP7_75t_L g96 ( 
.A(n_84),
.Y(n_96)
);

INVxp67_ASAP7_75t_SL g97 ( 
.A(n_87),
.Y(n_97)
);

AOI211x1_ASAP7_75t_L g98 ( 
.A1(n_90),
.A2(n_79),
.B(n_77),
.C(n_64),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_93),
.B(n_73),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_91),
.Y(n_100)
);

OAI211xp5_ASAP7_75t_L g101 ( 
.A1(n_90),
.A2(n_40),
.B(n_34),
.C(n_33),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_91),
.Y(n_102)
);

AOI22xp5_ASAP7_75t_L g103 ( 
.A1(n_95),
.A2(n_62),
.B1(n_40),
.B2(n_34),
.Y(n_103)
);

INVxp67_ASAP7_75t_SL g104 ( 
.A(n_97),
.Y(n_104)
);

AOI221xp5_ASAP7_75t_SL g105 ( 
.A1(n_96),
.A2(n_40),
.B1(n_66),
.B2(n_64),
.C(n_44),
.Y(n_105)
);

AO22x1_ASAP7_75t_L g106 ( 
.A1(n_96),
.A2(n_62),
.B1(n_77),
.B2(n_87),
.Y(n_106)
);

AOI221x1_ASAP7_75t_L g107 ( 
.A1(n_102),
.A2(n_31),
.B1(n_30),
.B2(n_26),
.C(n_35),
.Y(n_107)
);

OAI21xp33_ASAP7_75t_SL g108 ( 
.A1(n_102),
.A2(n_94),
.B(n_97),
.Y(n_108)
);

NOR3xp33_ASAP7_75t_L g109 ( 
.A(n_101),
.B(n_48),
.C(n_31),
.Y(n_109)
);

AND4x1_ASAP7_75t_L g110 ( 
.A(n_103),
.B(n_30),
.C(n_26),
.D(n_66),
.Y(n_110)
);

AOI21xp5_ASAP7_75t_L g111 ( 
.A1(n_104),
.A2(n_89),
.B(n_94),
.Y(n_111)
);

OAI222xp33_ASAP7_75t_L g112 ( 
.A1(n_99),
.A2(n_92),
.B1(n_32),
.B2(n_21),
.C1(n_29),
.C2(n_75),
.Y(n_112)
);

AOI21xp5_ASAP7_75t_L g113 ( 
.A1(n_106),
.A2(n_89),
.B(n_70),
.Y(n_113)
);

AOI21xp5_ASAP7_75t_L g114 ( 
.A1(n_106),
.A2(n_71),
.B(n_86),
.Y(n_114)
);

AND2x2_ASAP7_75t_L g115 ( 
.A(n_100),
.B(n_92),
.Y(n_115)
);

NAND4xp25_ASAP7_75t_L g116 ( 
.A(n_105),
.B(n_98),
.C(n_37),
.D(n_36),
.Y(n_116)
);

OAI221xp5_ASAP7_75t_L g117 ( 
.A1(n_100),
.A2(n_32),
.B1(n_29),
.B2(n_37),
.C(n_36),
.Y(n_117)
);

AOI221xp5_ASAP7_75t_L g118 ( 
.A1(n_101),
.A2(n_36),
.B1(n_69),
.B2(n_75),
.C(n_72),
.Y(n_118)
);

AOI211xp5_ASAP7_75t_L g119 ( 
.A1(n_101),
.A2(n_36),
.B(n_75),
.C(n_72),
.Y(n_119)
);

AOI32xp33_ASAP7_75t_L g120 ( 
.A1(n_101),
.A2(n_36),
.A3(n_69),
.B1(n_75),
.B2(n_3),
.Y(n_120)
);

OR2x2_ASAP7_75t_L g121 ( 
.A(n_115),
.B(n_54),
.Y(n_121)
);

HB1xp67_ASAP7_75t_L g122 ( 
.A(n_108),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_111),
.Y(n_123)
);

NOR3x1_ASAP7_75t_L g124 ( 
.A(n_116),
.B(n_8),
.C(n_7),
.Y(n_124)
);

NOR2x1_ASAP7_75t_L g125 ( 
.A(n_113),
.B(n_76),
.Y(n_125)
);

NOR2xp33_ASAP7_75t_L g126 ( 
.A(n_110),
.B(n_112),
.Y(n_126)
);

NAND3xp33_ASAP7_75t_L g127 ( 
.A(n_109),
.B(n_119),
.C(n_117),
.Y(n_127)
);

INVxp67_ASAP7_75t_L g128 ( 
.A(n_114),
.Y(n_128)
);

NOR2xp33_ASAP7_75t_L g129 ( 
.A(n_118),
.B(n_8),
.Y(n_129)
);

NAND2xp5_ASAP7_75t_L g130 ( 
.A(n_107),
.B(n_75),
.Y(n_130)
);

INVxp67_ASAP7_75t_L g131 ( 
.A(n_115),
.Y(n_131)
);

BUFx6f_ASAP7_75t_L g132 ( 
.A(n_115),
.Y(n_132)
);

OAI221xp5_ASAP7_75t_L g133 ( 
.A1(n_120),
.A2(n_85),
.B1(n_68),
.B2(n_72),
.C(n_50),
.Y(n_133)
);

OR2x2_ASAP7_75t_L g134 ( 
.A(n_115),
.B(n_68),
.Y(n_134)
);

AND2x2_ASAP7_75t_SL g135 ( 
.A(n_122),
.B(n_71),
.Y(n_135)
);

INVx1_ASAP7_75t_L g136 ( 
.A(n_131),
.Y(n_136)
);

NOR2x1_ASAP7_75t_L g137 ( 
.A(n_123),
.B(n_76),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_132),
.Y(n_138)
);

NAND3x1_ASAP7_75t_L g139 ( 
.A(n_126),
.B(n_72),
.C(n_11),
.Y(n_139)
);

AOI22xp5_ASAP7_75t_L g140 ( 
.A1(n_127),
.A2(n_85),
.B1(n_74),
.B2(n_68),
.Y(n_140)
);

OAI221xp5_ASAP7_75t_SL g141 ( 
.A1(n_129),
.A2(n_15),
.B1(n_14),
.B2(n_16),
.C(n_17),
.Y(n_141)
);

NOR2x1p5_ASAP7_75t_L g142 ( 
.A(n_132),
.B(n_14),
.Y(n_142)
);

NOR4xp75_ASAP7_75t_L g143 ( 
.A(n_133),
.B(n_18),
.C(n_17),
.D(n_15),
.Y(n_143)
);

AND2x2_ASAP7_75t_L g144 ( 
.A(n_128),
.B(n_134),
.Y(n_144)
);

NOR2x1_ASAP7_75t_L g145 ( 
.A(n_125),
.B(n_74),
.Y(n_145)
);

XNOR2xp5_ASAP7_75t_L g146 ( 
.A(n_142),
.B(n_121),
.Y(n_146)
);

AOI322xp5_ASAP7_75t_L g147 ( 
.A1(n_135),
.A2(n_130),
.A3(n_124),
.B1(n_20),
.B2(n_18),
.C1(n_69),
.C2(n_50),
.Y(n_147)
);

AOI22xp5_ASAP7_75t_L g148 ( 
.A1(n_139),
.A2(n_74),
.B1(n_68),
.B2(n_69),
.Y(n_148)
);

AND2x2_ASAP7_75t_L g149 ( 
.A(n_138),
.B(n_68),
.Y(n_149)
);

NOR3xp33_ASAP7_75t_L g150 ( 
.A(n_141),
.B(n_83),
.C(n_42),
.Y(n_150)
);

NOR3xp33_ASAP7_75t_L g151 ( 
.A(n_144),
.B(n_83),
.C(n_42),
.Y(n_151)
);

BUFx2_ASAP7_75t_L g152 ( 
.A(n_149),
.Y(n_152)
);

AOI22xp33_ASAP7_75t_L g153 ( 
.A1(n_150),
.A2(n_140),
.B1(n_143),
.B2(n_145),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_146),
.Y(n_154)
);

INVx1_ASAP7_75t_L g155 ( 
.A(n_151),
.Y(n_155)
);

XNOR2x1_ASAP7_75t_L g156 ( 
.A(n_148),
.B(n_147),
.Y(n_156)
);

INVx3_ASAP7_75t_L g157 ( 
.A(n_152),
.Y(n_157)
);

NAND2xp5_ASAP7_75t_L g158 ( 
.A(n_155),
.B(n_136),
.Y(n_158)
);

OR2x6_ASAP7_75t_L g159 ( 
.A(n_154),
.B(n_137),
.Y(n_159)
);

AND3x1_ASAP7_75t_L g160 ( 
.A(n_157),
.B(n_158),
.C(n_153),
.Y(n_160)
);

AOI22xp5_ASAP7_75t_L g161 ( 
.A1(n_160),
.A2(n_156),
.B1(n_159),
.B2(n_157),
.Y(n_161)
);


endmodule