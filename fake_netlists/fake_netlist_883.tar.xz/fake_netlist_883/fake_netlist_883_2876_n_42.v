module fake_netlist_883_2876_n_42 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_42);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_42;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_41;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

INVx4_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_14),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

OR2x6_ASAP7_75t_L g29 ( 
.A(n_24),
.B(n_17),
.Y(n_29)
);

AOI211x1_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_25),
.B(n_23),
.C(n_20),
.Y(n_30)
);

INVx2_ASAP7_75t_SL g31 ( 
.A(n_27),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_29),
.B1(n_26),
.B2(n_21),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_31),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_17),
.B1(n_6),
.B2(n_2),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_8),
.B2(n_7),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_9),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AOI211xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_12),
.B(n_11),
.C(n_10),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_41),
.A2(n_40),
.B1(n_16),
.B2(n_13),
.Y(n_42)
);


endmodule