module fake_netlist_883_2616_n_24 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_24);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_24;

wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_10;

INVx3_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

CKINVDCx16_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_11),
.B(n_2),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_11),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_15),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_13),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_17),
.Y(n_19)
);

OAI21xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_10),
.B(n_2),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_3),
.C(n_1),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_21),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_24)
);


endmodule