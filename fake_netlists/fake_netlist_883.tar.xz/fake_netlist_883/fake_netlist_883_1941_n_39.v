module fake_netlist_883_1941_n_39 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_39);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_39;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_3),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_14),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_7),
.B(n_1),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_17),
.B(n_4),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_23),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_22),
.Y(n_27)
);

CKINVDCx14_ASAP7_75t_R g28 ( 
.A(n_25),
.Y(n_28)
);

AOI33xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_19),
.A3(n_21),
.B1(n_18),
.B2(n_5),
.B3(n_4),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_21),
.B1(n_24),
.B2(n_5),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_29),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_SL g34 ( 
.A(n_33),
.B(n_15),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_34),
.Y(n_36)
);

NAND3xp33_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_16),
.C(n_8),
.Y(n_37)
);

NOR4xp25_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_37),
.C(n_10),
.D(n_9),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_13),
.C(n_12),
.Y(n_39)
);


endmodule