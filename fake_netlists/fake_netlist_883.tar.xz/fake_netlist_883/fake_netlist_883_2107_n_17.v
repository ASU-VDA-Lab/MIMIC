module fake_netlist_883_2107_n_17 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_17);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_17;

wire n_15;
wire n_11;
wire n_9;
wire n_13;
wire n_16;
wire n_14;
wire n_10;
wire n_8;
wire n_12;

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_1),
.A2(n_4),
.B1(n_2),
.B2(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

NOR2x1_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OA22x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_7),
.B(n_0),
.Y(n_17)
);


endmodule