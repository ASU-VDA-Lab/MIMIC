module fake_netlist_883_1350_n_16 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_16);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_16;

wire n_15;
wire n_11;
wire n_9;
wire n_13;
wire n_14;
wire n_10;
wire n_8;
wire n_12;

INVx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

OAI21xp33_ASAP7_75t_SL g9 ( 
.A1(n_6),
.A2(n_3),
.B(n_4),
.Y(n_9)
);

CKINVDCx11_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_9),
.B1(n_7),
.B2(n_10),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_1),
.B2(n_0),
.Y(n_16)
);


endmodule