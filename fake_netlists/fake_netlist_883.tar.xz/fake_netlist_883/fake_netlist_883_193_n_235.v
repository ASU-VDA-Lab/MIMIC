module fake_netlist_883_193_n_235 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_30, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_17, n_18, n_31, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_26, n_10, n_29, n_8, n_235);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_30;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_17;
input n_18;
input n_31;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_26;
input n_10;
input n_29;
input n_8;

output n_235;

wire n_118;
wire n_100;
wire n_60;
wire n_104;
wire n_216;
wire n_101;
wire n_52;
wire n_99;
wire n_127;
wire n_154;
wire n_152;
wire n_111;
wire n_151;
wire n_185;
wire n_153;
wire n_193;
wire n_164;
wire n_116;
wire n_64;
wire n_102;
wire n_93;
wire n_157;
wire n_66;
wire n_65;
wire n_143;
wire n_88;
wire n_186;
wire n_195;
wire n_169;
wire n_197;
wire n_192;
wire n_212;
wire n_94;
wire n_198;
wire n_182;
wire n_206;
wire n_214;
wire n_91;
wire n_71;
wire n_135;
wire n_174;
wire n_224;
wire n_80;
wire n_229;
wire n_228;
wire n_149;
wire n_201;
wire n_196;
wire n_69;
wire n_83;
wire n_207;
wire n_210;
wire n_134;
wire n_96;
wire n_128;
wire n_117;
wire n_131;
wire n_165;
wire n_190;
wire n_51;
wire n_50;
wire n_217;
wire n_162;
wire n_223;
wire n_55;
wire n_123;
wire n_234;
wire n_110;
wire n_46;
wire n_183;
wire n_144;
wire n_54;
wire n_211;
wire n_59;
wire n_227;
wire n_189;
wire n_177;
wire n_173;
wire n_166;
wire n_70;
wire n_40;
wire n_39;
wire n_132;
wire n_225;
wire n_220;
wire n_42;
wire n_32;
wire n_41;
wire n_222;
wire n_126;
wire n_62;
wire n_148;
wire n_150;
wire n_141;
wire n_120;
wire n_226;
wire n_188;
wire n_44;
wire n_79;
wire n_187;
wire n_87;
wire n_142;
wire n_159;
wire n_115;
wire n_155;
wire n_230;
wire n_33;
wire n_184;
wire n_113;
wire n_233;
wire n_200;
wire n_129;
wire n_191;
wire n_208;
wire n_209;
wire n_172;
wire n_77;
wire n_107;
wire n_199;
wire n_95;
wire n_204;
wire n_53;
wire n_161;
wire n_180;
wire n_106;
wire n_137;
wire n_90;
wire n_167;
wire n_146;
wire n_81;
wire n_221;
wire n_84;
wire n_171;
wire n_140;
wire n_61;
wire n_130;
wire n_122;
wire n_43;
wire n_138;
wire n_170;
wire n_139;
wire n_136;
wire n_48;
wire n_72;
wire n_176;
wire n_181;
wire n_133;
wire n_76;
wire n_38;
wire n_56;
wire n_218;
wire n_175;
wire n_213;
wire n_74;
wire n_125;
wire n_34;
wire n_179;
wire n_103;
wire n_37;
wire n_160;
wire n_108;
wire n_75;
wire n_47;
wire n_68;
wire n_158;
wire n_86;
wire n_63;
wire n_163;
wire n_105;
wire n_215;
wire n_114;
wire n_124;
wire n_145;
wire n_85;
wire n_112;
wire n_156;
wire n_205;
wire n_232;
wire n_49;
wire n_58;
wire n_109;
wire n_147;
wire n_168;
wire n_67;
wire n_219;
wire n_202;
wire n_35;
wire n_57;
wire n_121;
wire n_98;
wire n_97;
wire n_231;
wire n_119;
wire n_178;
wire n_203;
wire n_36;
wire n_194;
wire n_45;
wire n_92;
wire n_73;
wire n_89;
wire n_82;
wire n_78;

INVx1_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_19),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_17),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_14),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_0),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_23),
.Y(n_38)
);

INVx3_ASAP7_75t_L g39 ( 
.A(n_29),
.Y(n_39)
);

INVxp33_ASAP7_75t_SL g40 ( 
.A(n_3),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_6),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_28),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_16),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_18),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_R g45 ( 
.A(n_39),
.B(n_35),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_34),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_39),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_39),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_39),
.Y(n_49)
);

INVxp67_ASAP7_75t_L g50 ( 
.A(n_34),
.Y(n_50)
);

NOR2x1_ASAP7_75t_L g51 ( 
.A(n_45),
.B(n_35),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_46),
.Y(n_53)
);

AND2x4_ASAP7_75t_L g54 ( 
.A(n_47),
.B(n_37),
.Y(n_54)
);

INVx4_ASAP7_75t_L g55 ( 
.A(n_48),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_46),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_48),
.Y(n_57)
);

INVx3_ASAP7_75t_L g58 ( 
.A(n_49),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_49),
.Y(n_59)
);

A2O1A1Ixp33_ASAP7_75t_L g60 ( 
.A1(n_54),
.A2(n_50),
.B(n_38),
.C(n_37),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_51),
.Y(n_61)
);

HB1xp67_ASAP7_75t_L g62 ( 
.A(n_53),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_L g63 ( 
.A(n_52),
.B(n_45),
.Y(n_63)
);

BUFx12f_ASAP7_75t_L g64 ( 
.A(n_54),
.Y(n_64)
);

AOI21xp5_ASAP7_75t_L g65 ( 
.A1(n_52),
.A2(n_50),
.B(n_36),
.Y(n_65)
);

O2A1O1Ixp33_ASAP7_75t_L g66 ( 
.A1(n_53),
.A2(n_43),
.B(n_41),
.C(n_38),
.Y(n_66)
);

A2O1A1Ixp33_ASAP7_75t_L g67 ( 
.A1(n_54),
.A2(n_56),
.B(n_53),
.C(n_57),
.Y(n_67)
);

A2O1A1Ixp33_ASAP7_75t_L g68 ( 
.A1(n_54),
.A2(n_44),
.B(n_43),
.C(n_41),
.Y(n_68)
);

O2A1O1Ixp33_ASAP7_75t_L g69 ( 
.A1(n_56),
.A2(n_44),
.B(n_32),
.C(n_33),
.Y(n_69)
);

O2A1O1Ixp33_ASAP7_75t_L g70 ( 
.A1(n_56),
.A2(n_36),
.B(n_42),
.C(n_40),
.Y(n_70)
);

AOI22xp33_ASAP7_75t_L g71 ( 
.A1(n_54),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_71)
);

AOI21xp5_ASAP7_75t_L g72 ( 
.A1(n_52),
.A2(n_4),
.B(n_1),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_67),
.Y(n_73)
);

AND2x4_ASAP7_75t_L g74 ( 
.A(n_68),
.B(n_54),
.Y(n_74)
);

NOR2xp67_ASAP7_75t_SL g75 ( 
.A(n_64),
.B(n_72),
.Y(n_75)
);

OR2x2_ASAP7_75t_L g76 ( 
.A(n_62),
.B(n_57),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_72),
.Y(n_77)
);

AO31x2_ASAP7_75t_L g78 ( 
.A1(n_60),
.A2(n_52),
.A3(n_59),
.B(n_57),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_65),
.Y(n_79)
);

OAI21xp5_ASAP7_75t_L g80 ( 
.A1(n_65),
.A2(n_59),
.B(n_58),
.Y(n_80)
);

OAI21x1_ASAP7_75t_L g81 ( 
.A1(n_66),
.A2(n_51),
.B(n_58),
.Y(n_81)
);

OR2x2_ASAP7_75t_L g82 ( 
.A(n_63),
.B(n_59),
.Y(n_82)
);

OAI21x1_ASAP7_75t_L g83 ( 
.A1(n_69),
.A2(n_58),
.B(n_55),
.Y(n_83)
);

AND2x2_ASAP7_75t_L g84 ( 
.A(n_73),
.B(n_61),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_73),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_77),
.Y(n_86)
);

INVx3_ASAP7_75t_L g87 ( 
.A(n_78),
.Y(n_87)
);

INVx3_ASAP7_75t_L g88 ( 
.A(n_78),
.Y(n_88)
);

NOR2xp33_ASAP7_75t_R g89 ( 
.A(n_76),
.B(n_64),
.Y(n_89)
);

AO31x2_ASAP7_75t_L g90 ( 
.A1(n_77),
.A2(n_61),
.A3(n_63),
.B(n_55),
.Y(n_90)
);

NAND2xp5_ASAP7_75t_L g91 ( 
.A(n_82),
.B(n_58),
.Y(n_91)
);

INVx2_ASAP7_75t_L g92 ( 
.A(n_84),
.Y(n_92)
);

INVx2_ASAP7_75t_L g93 ( 
.A(n_87),
.Y(n_93)
);

OAI21xp5_ASAP7_75t_L g94 ( 
.A1(n_91),
.A2(n_81),
.B(n_83),
.Y(n_94)
);

AO22x1_ASAP7_75t_L g95 ( 
.A1(n_85),
.A2(n_74),
.B1(n_80),
.B2(n_79),
.Y(n_95)
);

INVxp67_ASAP7_75t_SL g96 ( 
.A(n_85),
.Y(n_96)
);

NOR2xp33_ASAP7_75t_L g97 ( 
.A(n_91),
.B(n_76),
.Y(n_97)
);

INVx1_ASAP7_75t_L g98 ( 
.A(n_86),
.Y(n_98)
);

AND2x2_ASAP7_75t_L g99 ( 
.A(n_92),
.B(n_76),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_92),
.Y(n_100)
);

HB1xp67_ASAP7_75t_L g101 ( 
.A(n_93),
.Y(n_101)
);

INVx2_ASAP7_75t_SL g102 ( 
.A(n_93),
.Y(n_102)
);

INVx2_ASAP7_75t_L g103 ( 
.A(n_93),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_98),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_97),
.B(n_84),
.Y(n_105)
);

AND2x2_ASAP7_75t_L g106 ( 
.A(n_96),
.B(n_84),
.Y(n_106)
);

INVx2_ASAP7_75t_L g107 ( 
.A(n_98),
.Y(n_107)
);

INVx2_ASAP7_75t_L g108 ( 
.A(n_95),
.Y(n_108)
);

INVx2_ASAP7_75t_L g109 ( 
.A(n_108),
.Y(n_109)
);

AOI33xp33_ASAP7_75t_L g110 ( 
.A1(n_104),
.A2(n_71),
.A3(n_70),
.B1(n_74),
.B2(n_85),
.B3(n_79),
.Y(n_110)
);

AND2x2_ASAP7_75t_L g111 ( 
.A(n_103),
.B(n_87),
.Y(n_111)
);

NOR2xp33_ASAP7_75t_L g112 ( 
.A(n_99),
.B(n_74),
.Y(n_112)
);

OR2x2_ASAP7_75t_L g113 ( 
.A(n_108),
.B(n_87),
.Y(n_113)
);

NAND2xp5_ASAP7_75t_L g114 ( 
.A(n_105),
.B(n_106),
.Y(n_114)
);

BUFx3_ASAP7_75t_L g115 ( 
.A(n_107),
.Y(n_115)
);

BUFx2_ASAP7_75t_L g116 ( 
.A(n_107),
.Y(n_116)
);

INVx1_ASAP7_75t_SL g117 ( 
.A(n_106),
.Y(n_117)
);

O2A1O1Ixp33_ASAP7_75t_L g118 ( 
.A1(n_102),
.A2(n_82),
.B(n_58),
.C(n_91),
.Y(n_118)
);

BUFx3_ASAP7_75t_L g119 ( 
.A(n_102),
.Y(n_119)
);

AND2x2_ASAP7_75t_L g120 ( 
.A(n_103),
.B(n_87),
.Y(n_120)
);

INVx2_ASAP7_75t_L g121 ( 
.A(n_101),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_100),
.Y(n_122)
);

AND2x2_ASAP7_75t_L g123 ( 
.A(n_100),
.B(n_87),
.Y(n_123)
);

CKINVDCx16_ASAP7_75t_R g124 ( 
.A(n_99),
.Y(n_124)
);

NAND2xp5_ASAP7_75t_L g125 ( 
.A(n_105),
.B(n_87),
.Y(n_125)
);

OAI332xp33_ASAP7_75t_L g126 ( 
.A1(n_114),
.A2(n_6),
.A3(n_19),
.B1(n_17),
.B2(n_18),
.B3(n_7),
.C1(n_5),
.C2(n_16),
.Y(n_126)
);

INVxp67_ASAP7_75t_SL g127 ( 
.A(n_121),
.Y(n_127)
);

AOI21xp33_ASAP7_75t_L g128 ( 
.A1(n_118),
.A2(n_75),
.B(n_84),
.Y(n_128)
);

AND2x2_ASAP7_75t_L g129 ( 
.A(n_116),
.B(n_87),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_109),
.Y(n_130)
);

INVx1_ASAP7_75t_L g131 ( 
.A(n_109),
.Y(n_131)
);

OAI22xp33_ASAP7_75t_L g132 ( 
.A1(n_124),
.A2(n_80),
.B1(n_88),
.B2(n_58),
.Y(n_132)
);

NOR2x1p5_ASAP7_75t_L g133 ( 
.A(n_114),
.B(n_88),
.Y(n_133)
);

INVx2_ASAP7_75t_SL g134 ( 
.A(n_119),
.Y(n_134)
);

INVx1_ASAP7_75t_SL g135 ( 
.A(n_116),
.Y(n_135)
);

XNOR2xp5_ASAP7_75t_L g136 ( 
.A(n_117),
.B(n_123),
.Y(n_136)
);

AOI21xp33_ASAP7_75t_L g137 ( 
.A1(n_118),
.A2(n_75),
.B(n_88),
.Y(n_137)
);

AND4x1_ASAP7_75t_L g138 ( 
.A(n_110),
.B(n_112),
.C(n_94),
.D(n_125),
.Y(n_138)
);

AND2x2_ASAP7_75t_L g139 ( 
.A(n_116),
.B(n_88),
.Y(n_139)
);

HB1xp67_ASAP7_75t_L g140 ( 
.A(n_115),
.Y(n_140)
);

NAND2xp5_ASAP7_75t_L g141 ( 
.A(n_124),
.B(n_88),
.Y(n_141)
);

INVx1_ASAP7_75t_L g142 ( 
.A(n_109),
.Y(n_142)
);

OAI22xp33_ASAP7_75t_SL g143 ( 
.A1(n_124),
.A2(n_88),
.B1(n_74),
.B2(n_86),
.Y(n_143)
);

OAI32xp33_ASAP7_75t_L g144 ( 
.A1(n_110),
.A2(n_55),
.A3(n_88),
.B1(n_86),
.B2(n_7),
.Y(n_144)
);

AOI22xp33_ASAP7_75t_SL g145 ( 
.A1(n_112),
.A2(n_89),
.B1(n_117),
.B2(n_109),
.Y(n_145)
);

OAI21xp5_ASAP7_75t_L g146 ( 
.A1(n_125),
.A2(n_81),
.B(n_83),
.Y(n_146)
);

INVxp67_ASAP7_75t_SL g147 ( 
.A(n_121),
.Y(n_147)
);

NAND2xp5_ASAP7_75t_SL g148 ( 
.A(n_121),
.B(n_89),
.Y(n_148)
);

AOI22xp33_ASAP7_75t_L g149 ( 
.A1(n_113),
.A2(n_74),
.B1(n_121),
.B2(n_123),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_115),
.Y(n_150)
);

AND2x2_ASAP7_75t_L g151 ( 
.A(n_150),
.B(n_115),
.Y(n_151)
);

NAND2xp5_ASAP7_75t_SL g152 ( 
.A(n_145),
.B(n_122),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_130),
.Y(n_153)
);

NAND2xp5_ASAP7_75t_L g154 ( 
.A(n_133),
.B(n_122),
.Y(n_154)
);

INVx1_ASAP7_75t_L g155 ( 
.A(n_130),
.Y(n_155)
);

OAI21xp33_ASAP7_75t_L g156 ( 
.A1(n_144),
.A2(n_126),
.B(n_143),
.Y(n_156)
);

BUFx10_ASAP7_75t_L g157 ( 
.A(n_134),
.Y(n_157)
);

AND2x2_ASAP7_75t_L g158 ( 
.A(n_150),
.B(n_115),
.Y(n_158)
);

NOR2xp33_ASAP7_75t_L g159 ( 
.A(n_126),
.B(n_20),
.Y(n_159)
);

NOR2xp33_ASAP7_75t_L g160 ( 
.A(n_148),
.B(n_20),
.Y(n_160)
);

INVx1_ASAP7_75t_L g161 ( 
.A(n_131),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_131),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_142),
.Y(n_163)
);

AND2x2_ASAP7_75t_L g164 ( 
.A(n_134),
.B(n_119),
.Y(n_164)
);

NAND2xp5_ASAP7_75t_SL g165 ( 
.A(n_138),
.B(n_122),
.Y(n_165)
);

OR2x2_ASAP7_75t_L g166 ( 
.A(n_135),
.B(n_127),
.Y(n_166)
);

INVx1_ASAP7_75t_L g167 ( 
.A(n_142),
.Y(n_167)
);

NAND2xp5_ASAP7_75t_SL g168 ( 
.A(n_138),
.B(n_119),
.Y(n_168)
);

INVx1_ASAP7_75t_L g169 ( 
.A(n_147),
.Y(n_169)
);

NAND2xp5_ASAP7_75t_L g170 ( 
.A(n_133),
.B(n_111),
.Y(n_170)
);

NAND2xp5_ASAP7_75t_L g171 ( 
.A(n_139),
.B(n_111),
.Y(n_171)
);

NAND2xp5_ASAP7_75t_SL g172 ( 
.A(n_143),
.B(n_119),
.Y(n_172)
);

NAND2xp5_ASAP7_75t_L g173 ( 
.A(n_139),
.B(n_129),
.Y(n_173)
);

NOR2xp33_ASAP7_75t_L g174 ( 
.A(n_141),
.B(n_21),
.Y(n_174)
);

NAND2xp5_ASAP7_75t_L g175 ( 
.A(n_129),
.B(n_111),
.Y(n_175)
);

OR2x2_ASAP7_75t_L g176 ( 
.A(n_135),
.B(n_113),
.Y(n_176)
);

INVx2_ASAP7_75t_L g177 ( 
.A(n_140),
.Y(n_177)
);

AND2x2_ASAP7_75t_L g178 ( 
.A(n_136),
.B(n_120),
.Y(n_178)
);

NAND2xp5_ASAP7_75t_SL g179 ( 
.A(n_132),
.B(n_136),
.Y(n_179)
);

AND2x2_ASAP7_75t_L g180 ( 
.A(n_178),
.B(n_149),
.Y(n_180)
);

AOI21xp5_ASAP7_75t_L g181 ( 
.A1(n_156),
.A2(n_144),
.B(n_159),
.Y(n_181)
);

NAND2xp5_ASAP7_75t_L g182 ( 
.A(n_154),
.B(n_146),
.Y(n_182)
);

AOI211xp5_ASAP7_75t_L g183 ( 
.A1(n_160),
.A2(n_128),
.B(n_137),
.C(n_95),
.Y(n_183)
);

AOI211xp5_ASAP7_75t_L g184 ( 
.A1(n_179),
.A2(n_81),
.B(n_113),
.C(n_83),
.Y(n_184)
);

OAI221xp5_ASAP7_75t_SL g185 ( 
.A1(n_174),
.A2(n_22),
.B1(n_21),
.B2(n_23),
.C(n_24),
.Y(n_185)
);

NAND4xp75_ASAP7_75t_L g186 ( 
.A(n_152),
.B(n_123),
.C(n_120),
.D(n_22),
.Y(n_186)
);

NOR2xp33_ASAP7_75t_R g187 ( 
.A(n_164),
.B(n_25),
.Y(n_187)
);

O2A1O1Ixp33_ASAP7_75t_L g188 ( 
.A1(n_168),
.A2(n_165),
.B(n_172),
.C(n_170),
.Y(n_188)
);

AOI22xp5_ASAP7_75t_L g189 ( 
.A1(n_178),
.A2(n_123),
.B1(n_120),
.B2(n_55),
.Y(n_189)
);

O2A1O1Ixp33_ASAP7_75t_L g190 ( 
.A1(n_153),
.A2(n_27),
.B(n_26),
.C(n_25),
.Y(n_190)
);

O2A1O1Ixp33_ASAP7_75t_L g191 ( 
.A1(n_153),
.A2(n_28),
.B(n_27),
.C(n_26),
.Y(n_191)
);

NOR2xp33_ASAP7_75t_R g192 ( 
.A(n_164),
.B(n_29),
.Y(n_192)
);

AOI211xp5_ASAP7_75t_L g193 ( 
.A1(n_158),
.A2(n_31),
.B(n_30),
.C(n_78),
.Y(n_193)
);

AOI21xp33_ASAP7_75t_L g194 ( 
.A1(n_162),
.A2(n_30),
.B(n_78),
.Y(n_194)
);

AND2x2_ASAP7_75t_L g195 ( 
.A(n_173),
.B(n_90),
.Y(n_195)
);

NOR2xp33_ASAP7_75t_L g196 ( 
.A(n_171),
.B(n_175),
.Y(n_196)
);

OAI222xp33_ASAP7_75t_L g197 ( 
.A1(n_176),
.A2(n_55),
.B1(n_78),
.B2(n_90),
.C1(n_8),
.C2(n_2),
.Y(n_197)
);

AO22x2_ASAP7_75t_L g198 ( 
.A1(n_162),
.A2(n_78),
.B1(n_90),
.B2(n_55),
.Y(n_198)
);

O2A1O1Ixp33_ASAP7_75t_L g199 ( 
.A1(n_163),
.A2(n_78),
.B(n_10),
.C(n_9),
.Y(n_199)
);

AOI21xp5_ASAP7_75t_L g200 ( 
.A1(n_169),
.A2(n_167),
.B(n_163),
.Y(n_200)
);

AOI222xp33_ASAP7_75t_L g201 ( 
.A1(n_169),
.A2(n_12),
.B1(n_11),
.B2(n_13),
.C1(n_15),
.C2(n_90),
.Y(n_201)
);

INVx1_ASAP7_75t_L g202 ( 
.A(n_155),
.Y(n_202)
);

OAI211xp5_ASAP7_75t_SL g203 ( 
.A1(n_167),
.A2(n_90),
.B(n_161),
.C(n_177),
.Y(n_203)
);

NAND2xp5_ASAP7_75t_L g204 ( 
.A(n_182),
.B(n_151),
.Y(n_204)
);

AOI211xp5_ASAP7_75t_L g205 ( 
.A1(n_181),
.A2(n_151),
.B(n_158),
.C(n_177),
.Y(n_205)
);

INVx1_ASAP7_75t_L g206 ( 
.A(n_202),
.Y(n_206)
);

NOR3xp33_ASAP7_75t_L g207 ( 
.A(n_185),
.B(n_190),
.C(n_191),
.Y(n_207)
);

OAI321xp33_ASAP7_75t_L g208 ( 
.A1(n_193),
.A2(n_90),
.A3(n_157),
.B1(n_166),
.B2(n_176),
.C(n_183),
.Y(n_208)
);

INVx1_ASAP7_75t_L g209 ( 
.A(n_200),
.Y(n_209)
);

AOI321xp33_ASAP7_75t_L g210 ( 
.A1(n_188),
.A2(n_90),
.A3(n_157),
.B1(n_166),
.B2(n_180),
.C(n_199),
.Y(n_210)
);

O2A1O1Ixp33_ASAP7_75t_L g211 ( 
.A1(n_197),
.A2(n_194),
.B(n_203),
.C(n_201),
.Y(n_211)
);

O2A1O1Ixp33_ASAP7_75t_L g212 ( 
.A1(n_194),
.A2(n_90),
.B(n_157),
.C(n_184),
.Y(n_212)
);

OR2x2_ASAP7_75t_L g213 ( 
.A(n_195),
.B(n_196),
.Y(n_213)
);

AOI21xp5_ASAP7_75t_L g214 ( 
.A1(n_198),
.A2(n_90),
.B(n_189),
.Y(n_214)
);

INVx2_ASAP7_75t_SL g215 ( 
.A(n_187),
.Y(n_215)
);

NAND2xp5_ASAP7_75t_L g216 ( 
.A(n_198),
.B(n_90),
.Y(n_216)
);

NAND3xp33_ASAP7_75t_SL g217 ( 
.A(n_192),
.B(n_90),
.C(n_186),
.Y(n_217)
);

O2A1O1Ixp33_ASAP7_75t_L g218 ( 
.A1(n_198),
.A2(n_181),
.B(n_159),
.C(n_185),
.Y(n_218)
);

NAND5xp2_ASAP7_75t_L g219 ( 
.A(n_218),
.B(n_210),
.C(n_211),
.D(n_208),
.E(n_207),
.Y(n_219)
);

INVxp67_ASAP7_75t_SL g220 ( 
.A(n_209),
.Y(n_220)
);

INVx1_ASAP7_75t_L g221 ( 
.A(n_206),
.Y(n_221)
);

CKINVDCx5p33_ASAP7_75t_R g222 ( 
.A(n_215),
.Y(n_222)
);

HB1xp67_ASAP7_75t_L g223 ( 
.A(n_204),
.Y(n_223)
);

NOR2x1_ASAP7_75t_L g224 ( 
.A(n_212),
.B(n_216),
.Y(n_224)
);

INVx2_ASAP7_75t_L g225 ( 
.A(n_213),
.Y(n_225)
);

NAND2xp5_ASAP7_75t_L g226 ( 
.A(n_205),
.B(n_214),
.Y(n_226)
);

AO21x2_ASAP7_75t_L g227 ( 
.A1(n_226),
.A2(n_208),
.B(n_217),
.Y(n_227)
);

INVx2_ASAP7_75t_L g228 ( 
.A(n_221),
.Y(n_228)
);

INVx1_ASAP7_75t_L g229 ( 
.A(n_221),
.Y(n_229)
);

AOI21x1_ASAP7_75t_L g230 ( 
.A1(n_224),
.A2(n_223),
.B(n_225),
.Y(n_230)
);

OAI22xp33_ASAP7_75t_L g231 ( 
.A1(n_230),
.A2(n_224),
.B1(n_220),
.B2(n_225),
.Y(n_231)
);

HB1xp67_ASAP7_75t_L g232 ( 
.A(n_228),
.Y(n_232)
);

O2A1O1Ixp33_ASAP7_75t_L g233 ( 
.A1(n_231),
.A2(n_219),
.B(n_227),
.C(n_229),
.Y(n_233)
);

AOI22xp5_ASAP7_75t_SL g234 ( 
.A1(n_233),
.A2(n_222),
.B1(n_232),
.B2(n_229),
.Y(n_234)
);

AOI22xp5_ASAP7_75t_L g235 ( 
.A1(n_234),
.A2(n_227),
.B1(n_222),
.B2(n_228),
.Y(n_235)
);


endmodule