module fake_netlist_844_894_n_72 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_72);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_72;

wire n_49;
wire n_48;
wire n_25;
wire n_51;
wire n_20;
wire n_36;
wire n_47;
wire n_70;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_34;
wire n_23;
wire n_40;
wire n_44;
wire n_60;
wire n_53;
wire n_28;
wire n_32;
wire n_31;
wire n_39;
wire n_58;
wire n_68;
wire n_26;
wire n_24;
wire n_71;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_69;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_67;
wire n_45;
wire n_46;
wire n_57;

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_7),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_0),
.B(n_4),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_2),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_2),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_17),
.A2(n_8),
.B1(n_12),
.B2(n_9),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_11),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_17),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_10),
.Y(n_32)
);

NAND2x1p5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_0),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_30),
.A2(n_18),
.B1(n_15),
.B2(n_3),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_21),
.B(n_3),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_21),
.B(n_15),
.Y(n_38)
);

NOR2x2_ASAP7_75t_L g39 ( 
.A(n_26),
.B(n_5),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_32),
.B(n_6),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_22),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_35),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_32),
.B(n_24),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_34),
.B(n_23),
.Y(n_44)
);

OA21x2_ASAP7_75t_L g45 ( 
.A1(n_38),
.A2(n_26),
.B(n_23),
.Y(n_45)
);

OAI211xp5_ASAP7_75t_L g46 ( 
.A1(n_36),
.A2(n_37),
.B(n_31),
.C(n_27),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_33),
.A2(n_27),
.B1(n_29),
.B2(n_31),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_42),
.Y(n_49)
);

BUFx3_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

BUFx3_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

AND2x2_ASAP7_75t_SL g53 ( 
.A(n_45),
.B(n_25),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_53),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_49),
.Y(n_55)
);

OR2x2_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_44),
.Y(n_56)
);

NAND4xp25_ASAP7_75t_L g57 ( 
.A(n_50),
.B(n_48),
.C(n_44),
.D(n_46),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_53),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

OAI21xp33_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_53),
.B(n_49),
.Y(n_60)
);

INVxp67_ASAP7_75t_L g61 ( 
.A(n_56),
.Y(n_61)
);

OAI221xp5_ASAP7_75t_L g62 ( 
.A1(n_60),
.A2(n_33),
.B1(n_54),
.B2(n_50),
.C(n_51),
.Y(n_62)
);

OAI22xp5_ASAP7_75t_L g63 ( 
.A1(n_61),
.A2(n_58),
.B1(n_51),
.B2(n_59),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_59),
.Y(n_64)
);

AOI211xp5_ASAP7_75t_L g65 ( 
.A1(n_64),
.A2(n_28),
.B(n_43),
.C(n_22),
.Y(n_65)
);

NAND4xp75_ASAP7_75t_L g66 ( 
.A(n_62),
.B(n_45),
.C(n_39),
.D(n_47),
.Y(n_66)
);

OAI22xp5_ASAP7_75t_L g67 ( 
.A1(n_63),
.A2(n_52),
.B1(n_39),
.B2(n_28),
.Y(n_67)
);

OAI22x1_ASAP7_75t_L g68 ( 
.A1(n_66),
.A2(n_28),
.B1(n_20),
.B2(n_14),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_65),
.Y(n_69)
);

OAI21xp5_ASAP7_75t_L g70 ( 
.A1(n_67),
.A2(n_28),
.B(n_20),
.Y(n_70)
);

HB1xp67_ASAP7_75t_L g71 ( 
.A(n_69),
.Y(n_71)
);

AOI22x1_ASAP7_75t_L g72 ( 
.A1(n_71),
.A2(n_68),
.B1(n_70),
.B2(n_20),
.Y(n_72)
);


endmodule