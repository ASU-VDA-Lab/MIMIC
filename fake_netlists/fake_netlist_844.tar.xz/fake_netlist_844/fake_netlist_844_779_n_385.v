module fake_netlist_844_779_n_385 (n_25, n_20, n_15, n_13, n_2, n_36, n_17, n_14, n_22, n_41, n_4, n_7, n_23, n_34, n_40, n_28, n_39, n_44, n_9, n_31, n_32, n_26, n_24, n_43, n_37, n_19, n_42, n_3, n_33, n_12, n_0, n_29, n_6, n_30, n_18, n_10, n_16, n_21, n_5, n_35, n_38, n_11, n_27, n_1, n_8, n_385);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_36;
input n_17;
input n_14;
input n_22;
input n_41;
input n_4;
input n_7;
input n_23;
input n_34;
input n_40;
input n_28;
input n_39;
input n_44;
input n_9;
input n_31;
input n_32;
input n_26;
input n_24;
input n_43;
input n_37;
input n_19;
input n_42;
input n_3;
input n_33;
input n_12;
input n_0;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_35;
input n_38;
input n_11;
input n_27;
input n_1;
input n_8;

output n_385;

wire n_298;
wire n_364;
wire n_114;
wire n_261;
wire n_316;
wire n_166;
wire n_240;
wire n_326;
wire n_154;
wire n_340;
wire n_153;
wire n_195;
wire n_210;
wire n_87;
wire n_95;
wire n_325;
wire n_232;
wire n_63;
wire n_110;
wire n_265;
wire n_61;
wire n_108;
wire n_48;
wire n_163;
wire n_209;
wire n_196;
wire n_353;
wire n_47;
wire n_294;
wire n_202;
wire n_90;
wire n_76;
wire n_299;
wire n_272;
wire n_160;
wire n_338;
wire n_329;
wire n_99;
wire n_366;
wire n_349;
wire n_155;
wire n_361;
wire n_314;
wire n_357;
wire n_52;
wire n_379;
wire n_229;
wire n_51;
wire n_382;
wire n_119;
wire n_312;
wire n_152;
wire n_131;
wire n_133;
wire n_274;
wire n_323;
wire n_223;
wire n_279;
wire n_84;
wire n_303;
wire n_270;
wire n_188;
wire n_343;
wire n_205;
wire n_65;
wire n_247;
wire n_300;
wire n_309;
wire n_378;
wire n_281;
wire n_359;
wire n_365;
wire n_129;
wire n_201;
wire n_198;
wire n_169;
wire n_180;
wire n_220;
wire n_267;
wire n_370;
wire n_208;
wire n_82;
wire n_234;
wire n_165;
wire n_374;
wire n_141;
wire n_305;
wire n_280;
wire n_331;
wire n_221;
wire n_311;
wire n_293;
wire n_156;
wire n_347;
wire n_126;
wire n_296;
wire n_78;
wire n_187;
wire n_96;
wire n_94;
wire n_162;
wire n_135;
wire n_324;
wire n_275;
wire n_362;
wire n_369;
wire n_107;
wire n_301;
wire n_288;
wire n_384;
wire n_178;
wire n_121;
wire n_73;
wire n_211;
wire n_235;
wire n_371;
wire n_246;
wire n_344;
wire n_175;
wire n_185;
wire n_161;
wire n_224;
wire n_179;
wire n_137;
wire n_57;
wire n_226;
wire n_284;
wire n_116;
wire n_128;
wire n_139;
wire n_115;
wire n_339;
wire n_144;
wire n_328;
wire n_283;
wire n_183;
wire n_367;
wire n_345;
wire n_106;
wire n_149;
wire n_237;
wire n_373;
wire n_159;
wire n_91;
wire n_233;
wire n_333;
wire n_204;
wire n_191;
wire n_317;
wire n_181;
wire n_60;
wire n_356;
wire n_260;
wire n_372;
wire n_291;
wire n_186;
wire n_218;
wire n_69;
wire n_212;
wire n_241;
wire n_256;
wire n_134;
wire n_254;
wire n_148;
wire n_245;
wire n_376;
wire n_193;
wire n_49;
wire n_132;
wire n_219;
wire n_194;
wire n_250;
wire n_81;
wire n_273;
wire n_80;
wire n_123;
wire n_290;
wire n_319;
wire n_167;
wire n_122;
wire n_289;
wire n_56;
wire n_59;
wire n_74;
wire n_341;
wire n_79;
wire n_177;
wire n_244;
wire n_158;
wire n_171;
wire n_259;
wire n_214;
wire n_127;
wire n_295;
wire n_213;
wire n_257;
wire n_72;
wire n_266;
wire n_320;
wire n_249;
wire n_120;
wire n_327;
wire n_145;
wire n_307;
wire n_200;
wire n_377;
wire n_170;
wire n_77;
wire n_383;
wire n_138;
wire n_217;
wire n_253;
wire n_238;
wire n_381;
wire n_322;
wire n_332;
wire n_62;
wire n_117;
wire n_351;
wire n_104;
wire n_354;
wire n_168;
wire n_360;
wire n_350;
wire n_285;
wire n_310;
wire n_176;
wire n_271;
wire n_330;
wire n_101;
wire n_336;
wire n_242;
wire n_313;
wire n_157;
wire n_83;
wire n_375;
wire n_348;
wire n_334;
wire n_346;
wire n_216;
wire n_150;
wire n_71;
wire n_92;
wire n_100;
wire n_124;
wire n_236;
wire n_206;
wire n_147;
wire n_363;
wire n_268;
wire n_380;
wire n_97;
wire n_182;
wire n_335;
wire n_130;
wire n_239;
wire n_173;
wire n_287;
wire n_318;
wire n_222;
wire n_277;
wire n_263;
wire n_269;
wire n_54;
wire n_304;
wire n_64;
wire n_278;
wire n_264;
wire n_292;
wire n_297;
wire n_184;
wire n_86;
wire n_45;
wire n_192;
wire n_230;
wire n_118;
wire n_189;
wire n_125;
wire n_255;
wire n_151;
wire n_302;
wire n_258;
wire n_207;
wire n_103;
wire n_227;
wire n_215;
wire n_199;
wire n_143;
wire n_190;
wire n_251;
wire n_352;
wire n_136;
wire n_102;
wire n_89;
wire n_262;
wire n_70;
wire n_172;
wire n_142;
wire n_337;
wire n_109;
wire n_53;
wire n_315;
wire n_58;
wire n_68;
wire n_146;
wire n_248;
wire n_105;
wire n_306;
wire n_321;
wire n_355;
wire n_225;
wire n_358;
wire n_85;
wire n_55;
wire n_164;
wire n_252;
wire n_75;
wire n_140;
wire n_342;
wire n_67;
wire n_66;
wire n_98;
wire n_286;
wire n_203;
wire n_50;
wire n_112;
wire n_228;
wire n_111;
wire n_93;
wire n_174;
wire n_197;
wire n_88;
wire n_243;
wire n_276;
wire n_113;
wire n_282;
wire n_231;
wire n_368;
wire n_308;
wire n_46;

BUFx6f_ASAP7_75t_L g45 ( 
.A(n_7),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_8),
.Y(n_46)
);

CKINVDCx20_ASAP7_75t_R g47 ( 
.A(n_7),
.Y(n_47)
);

INVxp67_ASAP7_75t_SL g48 ( 
.A(n_40),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_3),
.Y(n_49)
);

BUFx2_ASAP7_75t_L g50 ( 
.A(n_28),
.Y(n_50)
);

BUFx3_ASAP7_75t_L g51 ( 
.A(n_12),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_14),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_21),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_19),
.Y(n_54)
);

CKINVDCx14_ASAP7_75t_R g55 ( 
.A(n_37),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_3),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_44),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_5),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_26),
.Y(n_59)
);

INVx2_ASAP7_75t_L g60 ( 
.A(n_33),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_39),
.Y(n_61)
);

AND2x2_ASAP7_75t_R g62 ( 
.A(n_52),
.B(n_0),
.Y(n_62)
);

CKINVDCx5p33_ASAP7_75t_R g63 ( 
.A(n_50),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_51),
.Y(n_64)
);

INVx3_ASAP7_75t_L g65 ( 
.A(n_51),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_51),
.Y(n_66)
);

CKINVDCx20_ASAP7_75t_R g67 ( 
.A(n_47),
.Y(n_67)
);

BUFx2_ASAP7_75t_L g68 ( 
.A(n_50),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_53),
.Y(n_69)
);

CKINVDCx20_ASAP7_75t_R g70 ( 
.A(n_46),
.Y(n_70)
);

CKINVDCx5p33_ASAP7_75t_R g71 ( 
.A(n_49),
.Y(n_71)
);

NAND2xp5_ASAP7_75t_SL g72 ( 
.A(n_53),
.B(n_0),
.Y(n_72)
);

BUFx6f_ASAP7_75t_L g73 ( 
.A(n_65),
.Y(n_73)
);

INVx1_ASAP7_75t_SL g74 ( 
.A(n_71),
.Y(n_74)
);

INVx2_ASAP7_75t_SL g75 ( 
.A(n_68),
.Y(n_75)
);

AND2x6_ASAP7_75t_L g76 ( 
.A(n_65),
.B(n_54),
.Y(n_76)
);

INVx2_ASAP7_75t_L g77 ( 
.A(n_65),
.Y(n_77)
);

A2O1A1Ixp33_ASAP7_75t_L g78 ( 
.A1(n_69),
.A2(n_60),
.B(n_57),
.C(n_54),
.Y(n_78)
);

OAI221xp5_ASAP7_75t_L g79 ( 
.A1(n_68),
.A2(n_46),
.B1(n_58),
.B2(n_52),
.C(n_56),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_64),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_65),
.Y(n_81)
);

AND2x4_ASAP7_75t_L g82 ( 
.A(n_68),
.B(n_56),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_64),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_66),
.Y(n_84)
);

INVx2_ASAP7_75t_L g85 ( 
.A(n_65),
.Y(n_85)
);

INVx2_ASAP7_75t_L g86 ( 
.A(n_66),
.Y(n_86)
);

AND2x4_ASAP7_75t_L g87 ( 
.A(n_69),
.B(n_58),
.Y(n_87)
);

BUFx3_ASAP7_75t_L g88 ( 
.A(n_63),
.Y(n_88)
);

INVx2_ASAP7_75t_L g89 ( 
.A(n_72),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_72),
.Y(n_90)
);

NAND3xp33_ASAP7_75t_L g91 ( 
.A(n_62),
.B(n_61),
.C(n_59),
.Y(n_91)
);

INVx2_ASAP7_75t_L g92 ( 
.A(n_62),
.Y(n_92)
);

INVx2_ASAP7_75t_L g93 ( 
.A(n_70),
.Y(n_93)
);

INVx1_ASAP7_75t_L g94 ( 
.A(n_70),
.Y(n_94)
);

NAND2xp5_ASAP7_75t_L g95 ( 
.A(n_87),
.B(n_48),
.Y(n_95)
);

NOR2xp33_ASAP7_75t_L g96 ( 
.A(n_82),
.B(n_48),
.Y(n_96)
);

BUFx12f_ASAP7_75t_L g97 ( 
.A(n_82),
.Y(n_97)
);

OR2x2_ASAP7_75t_L g98 ( 
.A(n_75),
.B(n_1),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_87),
.B(n_55),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_73),
.Y(n_100)
);

NAND2xp5_ASAP7_75t_SL g101 ( 
.A(n_89),
.B(n_57),
.Y(n_101)
);

BUFx2_ASAP7_75t_L g102 ( 
.A(n_88),
.Y(n_102)
);

NAND2xp5_ASAP7_75t_L g103 ( 
.A(n_87),
.B(n_59),
.Y(n_103)
);

NAND2xp5_ASAP7_75t_SL g104 ( 
.A(n_89),
.B(n_57),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_87),
.B(n_61),
.Y(n_105)
);

CKINVDCx5p33_ASAP7_75t_R g106 ( 
.A(n_74),
.Y(n_106)
);

BUFx2_ASAP7_75t_L g107 ( 
.A(n_88),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_80),
.Y(n_108)
);

BUFx4_ASAP7_75t_L g109 ( 
.A(n_94),
.Y(n_109)
);

INVx2_ASAP7_75t_SL g110 ( 
.A(n_76),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_80),
.Y(n_111)
);

AND2x4_ASAP7_75t_L g112 ( 
.A(n_82),
.B(n_45),
.Y(n_112)
);

HB1xp67_ASAP7_75t_L g113 ( 
.A(n_75),
.Y(n_113)
);

AND2x2_ASAP7_75t_L g114 ( 
.A(n_82),
.B(n_45),
.Y(n_114)
);

BUFx6f_ASAP7_75t_L g115 ( 
.A(n_73),
.Y(n_115)
);

CKINVDCx5p33_ASAP7_75t_R g116 ( 
.A(n_93),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_83),
.Y(n_117)
);

BUFx2_ASAP7_75t_L g118 ( 
.A(n_76),
.Y(n_118)
);

BUFx12f_ASAP7_75t_L g119 ( 
.A(n_97),
.Y(n_119)
);

BUFx3_ASAP7_75t_L g120 ( 
.A(n_118),
.Y(n_120)
);

CKINVDCx8_ASAP7_75t_R g121 ( 
.A(n_106),
.Y(n_121)
);

OR2x6_ASAP7_75t_SL g122 ( 
.A(n_98),
.B(n_92),
.Y(n_122)
);

AND2x4_ASAP7_75t_L g123 ( 
.A(n_102),
.B(n_92),
.Y(n_123)
);

INVx1_ASAP7_75t_L g124 ( 
.A(n_108),
.Y(n_124)
);

NAND2xp5_ASAP7_75t_L g125 ( 
.A(n_96),
.B(n_90),
.Y(n_125)
);

NAND2xp5_ASAP7_75t_L g126 ( 
.A(n_96),
.B(n_90),
.Y(n_126)
);

BUFx6f_ASAP7_75t_L g127 ( 
.A(n_115),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_108),
.Y(n_128)
);

AOI21xp5_ASAP7_75t_L g129 ( 
.A1(n_111),
.A2(n_84),
.B(n_83),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_111),
.Y(n_130)
);

AOI221xp5_ASAP7_75t_L g131 ( 
.A1(n_116),
.A2(n_79),
.B1(n_93),
.B2(n_94),
.C(n_91),
.Y(n_131)
);

AND2x2_ASAP7_75t_L g132 ( 
.A(n_97),
.B(n_91),
.Y(n_132)
);

AND2x4_ASAP7_75t_L g133 ( 
.A(n_102),
.B(n_78),
.Y(n_133)
);

OAI22xp5_ASAP7_75t_L g134 ( 
.A1(n_105),
.A2(n_84),
.B1(n_86),
.B2(n_77),
.Y(n_134)
);

NAND2xp5_ASAP7_75t_L g135 ( 
.A(n_113),
.B(n_76),
.Y(n_135)
);

BUFx2_ASAP7_75t_L g136 ( 
.A(n_97),
.Y(n_136)
);

INVx3_ASAP7_75t_L g137 ( 
.A(n_120),
.Y(n_137)
);

NAND2xp33_ASAP7_75t_SL g138 ( 
.A(n_136),
.B(n_118),
.Y(n_138)
);

OR2x2_ASAP7_75t_L g139 ( 
.A(n_136),
.B(n_102),
.Y(n_139)
);

AND2x4_ASAP7_75t_L g140 ( 
.A(n_120),
.B(n_107),
.Y(n_140)
);

INVx1_ASAP7_75t_L g141 ( 
.A(n_124),
.Y(n_141)
);

NAND2xp5_ASAP7_75t_L g142 ( 
.A(n_124),
.B(n_117),
.Y(n_142)
);

AOI221xp5_ASAP7_75t_L g143 ( 
.A1(n_131),
.A2(n_114),
.B1(n_95),
.B2(n_113),
.C(n_105),
.Y(n_143)
);

OR2x2_ASAP7_75t_L g144 ( 
.A(n_123),
.B(n_107),
.Y(n_144)
);

AND2x2_ASAP7_75t_L g145 ( 
.A(n_128),
.B(n_117),
.Y(n_145)
);

AND2x2_ASAP7_75t_L g146 ( 
.A(n_128),
.B(n_95),
.Y(n_146)
);

OAI21xp5_ASAP7_75t_L g147 ( 
.A1(n_130),
.A2(n_103),
.B(n_101),
.Y(n_147)
);

AND2x2_ASAP7_75t_L g148 ( 
.A(n_130),
.B(n_114),
.Y(n_148)
);

AOI22xp33_ASAP7_75t_L g149 ( 
.A1(n_143),
.A2(n_133),
.B1(n_132),
.B2(n_140),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_141),
.Y(n_150)
);

OAI22xp5_ASAP7_75t_L g151 ( 
.A1(n_142),
.A2(n_122),
.B1(n_98),
.B2(n_134),
.Y(n_151)
);

OAI22xp5_ASAP7_75t_L g152 ( 
.A1(n_142),
.A2(n_122),
.B1(n_98),
.B2(n_134),
.Y(n_152)
);

HB1xp67_ASAP7_75t_L g153 ( 
.A(n_139),
.Y(n_153)
);

AOI22xp33_ASAP7_75t_L g154 ( 
.A1(n_143),
.A2(n_133),
.B1(n_132),
.B2(n_123),
.Y(n_154)
);

INVx2_ASAP7_75t_SL g155 ( 
.A(n_140),
.Y(n_155)
);

AOI22xp33_ASAP7_75t_L g156 ( 
.A1(n_140),
.A2(n_133),
.B1(n_123),
.B2(n_112),
.Y(n_156)
);

AOI22xp33_ASAP7_75t_L g157 ( 
.A1(n_140),
.A2(n_133),
.B1(n_123),
.B2(n_112),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_141),
.Y(n_158)
);

AO21x2_ASAP7_75t_L g159 ( 
.A1(n_147),
.A2(n_129),
.B(n_103),
.Y(n_159)
);

OA21x2_ASAP7_75t_L g160 ( 
.A1(n_147),
.A2(n_60),
.B(n_101),
.Y(n_160)
);

AOI22xp33_ASAP7_75t_SL g161 ( 
.A1(n_140),
.A2(n_67),
.B1(n_119),
.B2(n_109),
.Y(n_161)
);

INVxp67_ASAP7_75t_SL g162 ( 
.A(n_151),
.Y(n_162)
);

INVx2_ASAP7_75t_L g163 ( 
.A(n_150),
.Y(n_163)
);

AND2x2_ASAP7_75t_L g164 ( 
.A(n_150),
.B(n_158),
.Y(n_164)
);

INVx2_ASAP7_75t_L g165 ( 
.A(n_158),
.Y(n_165)
);

INVx1_ASAP7_75t_L g166 ( 
.A(n_160),
.Y(n_166)
);

INVx1_ASAP7_75t_L g167 ( 
.A(n_160),
.Y(n_167)
);

AOI21xp5_ASAP7_75t_L g168 ( 
.A1(n_151),
.A2(n_145),
.B(n_127),
.Y(n_168)
);

AND2x2_ASAP7_75t_L g169 ( 
.A(n_155),
.B(n_149),
.Y(n_169)
);

AND2x2_ASAP7_75t_L g170 ( 
.A(n_155),
.B(n_145),
.Y(n_170)
);

AOI22xp33_ASAP7_75t_L g171 ( 
.A1(n_152),
.A2(n_148),
.B1(n_145),
.B2(n_144),
.Y(n_171)
);

BUFx3_ASAP7_75t_L g172 ( 
.A(n_153),
.Y(n_172)
);

NOR2x2_ASAP7_75t_L g173 ( 
.A(n_161),
.B(n_109),
.Y(n_173)
);

AND2x2_ASAP7_75t_L g174 ( 
.A(n_152),
.B(n_148),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_160),
.Y(n_175)
);

OAI211xp5_ASAP7_75t_SL g176 ( 
.A1(n_161),
.A2(n_121),
.B(n_139),
.C(n_125),
.Y(n_176)
);

INVx2_ASAP7_75t_L g177 ( 
.A(n_160),
.Y(n_177)
);

INVx1_ASAP7_75t_L g178 ( 
.A(n_159),
.Y(n_178)
);

AND2x4_ASAP7_75t_L g179 ( 
.A(n_159),
.B(n_137),
.Y(n_179)
);

BUFx2_ASAP7_75t_L g180 ( 
.A(n_159),
.Y(n_180)
);

OAI211xp5_ASAP7_75t_L g181 ( 
.A1(n_154),
.A2(n_121),
.B(n_67),
.C(n_157),
.Y(n_181)
);

OAI22xp5_ASAP7_75t_L g182 ( 
.A1(n_156),
.A2(n_144),
.B1(n_146),
.B2(n_148),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_159),
.Y(n_183)
);

OAI31xp33_ASAP7_75t_L g184 ( 
.A1(n_181),
.A2(n_138),
.A3(n_99),
.B(n_146),
.Y(n_184)
);

OAI33xp33_ASAP7_75t_L g185 ( 
.A1(n_176),
.A2(n_60),
.A3(n_104),
.B1(n_99),
.B2(n_109),
.B3(n_1),
.Y(n_185)
);

AOI211xp5_ASAP7_75t_SL g186 ( 
.A1(n_181),
.A2(n_137),
.B(n_146),
.C(n_114),
.Y(n_186)
);

AOI221xp5_ASAP7_75t_L g187 ( 
.A1(n_162),
.A2(n_112),
.B1(n_45),
.B2(n_126),
.C(n_104),
.Y(n_187)
);

OAI221xp5_ASAP7_75t_L g188 ( 
.A1(n_176),
.A2(n_45),
.B1(n_137),
.B2(n_135),
.C(n_120),
.Y(n_188)
);

AOI22xp33_ASAP7_75t_L g189 ( 
.A1(n_174),
.A2(n_137),
.B1(n_112),
.B2(n_45),
.Y(n_189)
);

AND2x2_ASAP7_75t_L g190 ( 
.A(n_164),
.B(n_45),
.Y(n_190)
);

OR2x6_ASAP7_75t_L g191 ( 
.A(n_168),
.B(n_119),
.Y(n_191)
);

OR2x2_ASAP7_75t_L g192 ( 
.A(n_172),
.B(n_112),
.Y(n_192)
);

INVx2_ASAP7_75t_L g193 ( 
.A(n_177),
.Y(n_193)
);

INVx2_ASAP7_75t_L g194 ( 
.A(n_177),
.Y(n_194)
);

AND2x2_ASAP7_75t_L g195 ( 
.A(n_164),
.B(n_2),
.Y(n_195)
);

INVxp67_ASAP7_75t_L g196 ( 
.A(n_172),
.Y(n_196)
);

AND2x2_ASAP7_75t_L g197 ( 
.A(n_164),
.B(n_2),
.Y(n_197)
);

INVx2_ASAP7_75t_L g198 ( 
.A(n_177),
.Y(n_198)
);

INVx1_ASAP7_75t_L g199 ( 
.A(n_163),
.Y(n_199)
);

INVx1_ASAP7_75t_L g200 ( 
.A(n_163),
.Y(n_200)
);

AND2x4_ASAP7_75t_L g201 ( 
.A(n_179),
.B(n_18),
.Y(n_201)
);

INVx2_ASAP7_75t_L g202 ( 
.A(n_166),
.Y(n_202)
);

HB1xp67_ASAP7_75t_L g203 ( 
.A(n_179),
.Y(n_203)
);

AND2x2_ASAP7_75t_L g204 ( 
.A(n_174),
.B(n_4),
.Y(n_204)
);

NOR3xp33_ASAP7_75t_L g205 ( 
.A(n_182),
.B(n_86),
.C(n_77),
.Y(n_205)
);

INVx3_ASAP7_75t_L g206 ( 
.A(n_179),
.Y(n_206)
);

NOR2xp33_ASAP7_75t_L g207 ( 
.A(n_172),
.B(n_119),
.Y(n_207)
);

BUFx2_ASAP7_75t_L g208 ( 
.A(n_179),
.Y(n_208)
);

HB1xp67_ASAP7_75t_L g209 ( 
.A(n_179),
.Y(n_209)
);

AND2x2_ASAP7_75t_L g210 ( 
.A(n_174),
.B(n_4),
.Y(n_210)
);

INVx1_ASAP7_75t_L g211 ( 
.A(n_163),
.Y(n_211)
);

AND2x2_ASAP7_75t_L g212 ( 
.A(n_165),
.B(n_5),
.Y(n_212)
);

BUFx3_ASAP7_75t_L g213 ( 
.A(n_170),
.Y(n_213)
);

AOI22xp5_ASAP7_75t_L g214 ( 
.A1(n_182),
.A2(n_76),
.B1(n_127),
.B2(n_81),
.Y(n_214)
);

OR2x2_ASAP7_75t_L g215 ( 
.A(n_162),
.B(n_6),
.Y(n_215)
);

AND2x2_ASAP7_75t_L g216 ( 
.A(n_165),
.B(n_6),
.Y(n_216)
);

INVx1_ASAP7_75t_L g217 ( 
.A(n_165),
.Y(n_217)
);

NOR3xp33_ASAP7_75t_L g218 ( 
.A(n_178),
.B(n_183),
.C(n_180),
.Y(n_218)
);

OAI211xp5_ASAP7_75t_L g219 ( 
.A1(n_171),
.A2(n_173),
.B(n_168),
.C(n_180),
.Y(n_219)
);

HB1xp67_ASAP7_75t_L g220 ( 
.A(n_170),
.Y(n_220)
);

AND2x2_ASAP7_75t_L g221 ( 
.A(n_203),
.B(n_180),
.Y(n_221)
);

AND2x2_ASAP7_75t_L g222 ( 
.A(n_203),
.B(n_178),
.Y(n_222)
);

INVx1_ASAP7_75t_L g223 ( 
.A(n_199),
.Y(n_223)
);

NOR2xp33_ASAP7_75t_L g224 ( 
.A(n_207),
.B(n_8),
.Y(n_224)
);

INVxp67_ASAP7_75t_L g225 ( 
.A(n_190),
.Y(n_225)
);

INVx1_ASAP7_75t_SL g226 ( 
.A(n_197),
.Y(n_226)
);

OAI221xp5_ASAP7_75t_L g227 ( 
.A1(n_184),
.A2(n_171),
.B1(n_183),
.B2(n_173),
.C(n_169),
.Y(n_227)
);

HB1xp67_ASAP7_75t_L g228 ( 
.A(n_196),
.Y(n_228)
);

NAND4xp25_ASAP7_75t_L g229 ( 
.A(n_186),
.B(n_184),
.C(n_219),
.D(n_204),
.Y(n_229)
);

INVx1_ASAP7_75t_L g230 ( 
.A(n_199),
.Y(n_230)
);

NAND2xp5_ASAP7_75t_L g231 ( 
.A(n_197),
.B(n_169),
.Y(n_231)
);

NAND2xp33_ASAP7_75t_L g232 ( 
.A(n_205),
.B(n_170),
.Y(n_232)
);

NAND2xp5_ASAP7_75t_L g233 ( 
.A(n_195),
.B(n_169),
.Y(n_233)
);

INVx1_ASAP7_75t_L g234 ( 
.A(n_200),
.Y(n_234)
);

AND2x2_ASAP7_75t_L g235 ( 
.A(n_209),
.B(n_166),
.Y(n_235)
);

AND2x2_ASAP7_75t_L g236 ( 
.A(n_209),
.B(n_167),
.Y(n_236)
);

INVx1_ASAP7_75t_L g237 ( 
.A(n_200),
.Y(n_237)
);

INVx1_ASAP7_75t_L g238 ( 
.A(n_211),
.Y(n_238)
);

AOI221x1_ASAP7_75t_L g239 ( 
.A1(n_218),
.A2(n_175),
.B1(n_167),
.B2(n_9),
.C(n_10),
.Y(n_239)
);

INVx1_ASAP7_75t_L g240 ( 
.A(n_211),
.Y(n_240)
);

AND2x2_ASAP7_75t_L g241 ( 
.A(n_208),
.B(n_175),
.Y(n_241)
);

OR2x2_ASAP7_75t_L g242 ( 
.A(n_196),
.B(n_9),
.Y(n_242)
);

AND2x2_ASAP7_75t_L g243 ( 
.A(n_208),
.B(n_10),
.Y(n_243)
);

NAND2xp5_ASAP7_75t_L g244 ( 
.A(n_195),
.B(n_11),
.Y(n_244)
);

INVx1_ASAP7_75t_L g245 ( 
.A(n_217),
.Y(n_245)
);

NAND2xp5_ASAP7_75t_L g246 ( 
.A(n_204),
.B(n_11),
.Y(n_246)
);

AND2x2_ASAP7_75t_L g247 ( 
.A(n_206),
.B(n_12),
.Y(n_247)
);

INVx2_ASAP7_75t_L g248 ( 
.A(n_193),
.Y(n_248)
);

AND2x4_ASAP7_75t_SL g249 ( 
.A(n_220),
.B(n_127),
.Y(n_249)
);

AND2x2_ASAP7_75t_L g250 ( 
.A(n_206),
.B(n_13),
.Y(n_250)
);

NAND2xp33_ASAP7_75t_SL g251 ( 
.A(n_210),
.B(n_13),
.Y(n_251)
);

OAI21xp33_ASAP7_75t_L g252 ( 
.A1(n_219),
.A2(n_85),
.B(n_81),
.Y(n_252)
);

NAND2xp5_ASAP7_75t_L g253 ( 
.A(n_210),
.B(n_14),
.Y(n_253)
);

INVxp67_ASAP7_75t_L g254 ( 
.A(n_190),
.Y(n_254)
);

INVx1_ASAP7_75t_L g255 ( 
.A(n_217),
.Y(n_255)
);

AND2x2_ASAP7_75t_L g256 ( 
.A(n_206),
.B(n_15),
.Y(n_256)
);

NOR3xp33_ASAP7_75t_L g257 ( 
.A(n_185),
.B(n_85),
.C(n_100),
.Y(n_257)
);

NAND2xp5_ASAP7_75t_L g258 ( 
.A(n_216),
.B(n_212),
.Y(n_258)
);

CKINVDCx5p33_ASAP7_75t_R g259 ( 
.A(n_213),
.Y(n_259)
);

NAND2xp5_ASAP7_75t_L g260 ( 
.A(n_216),
.B(n_15),
.Y(n_260)
);

INVx1_ASAP7_75t_L g261 ( 
.A(n_212),
.Y(n_261)
);

NAND2xp33_ASAP7_75t_R g262 ( 
.A(n_201),
.B(n_16),
.Y(n_262)
);

AND2x2_ASAP7_75t_L g263 ( 
.A(n_206),
.B(n_16),
.Y(n_263)
);

NAND2xp5_ASAP7_75t_L g264 ( 
.A(n_215),
.B(n_213),
.Y(n_264)
);

INVx2_ASAP7_75t_L g265 ( 
.A(n_193),
.Y(n_265)
);

NOR2xp33_ASAP7_75t_L g266 ( 
.A(n_213),
.B(n_17),
.Y(n_266)
);

AND2x2_ASAP7_75t_L g267 ( 
.A(n_202),
.B(n_17),
.Y(n_267)
);

NAND2xp5_ASAP7_75t_L g268 ( 
.A(n_215),
.B(n_76),
.Y(n_268)
);

INVxp67_ASAP7_75t_L g269 ( 
.A(n_192),
.Y(n_269)
);

NAND2xp5_ASAP7_75t_L g270 ( 
.A(n_226),
.B(n_218),
.Y(n_270)
);

OAI22xp33_ASAP7_75t_SL g271 ( 
.A1(n_259),
.A2(n_191),
.B1(n_188),
.B2(n_201),
.Y(n_271)
);

CKINVDCx16_ASAP7_75t_R g272 ( 
.A(n_262),
.Y(n_272)
);

INVx1_ASAP7_75t_L g273 ( 
.A(n_223),
.Y(n_273)
);

OR2x6_ASAP7_75t_L g274 ( 
.A(n_247),
.B(n_191),
.Y(n_274)
);

AND2x2_ASAP7_75t_L g275 ( 
.A(n_221),
.B(n_191),
.Y(n_275)
);

INVx1_ASAP7_75t_L g276 ( 
.A(n_223),
.Y(n_276)
);

AOI22xp5_ASAP7_75t_L g277 ( 
.A1(n_251),
.A2(n_229),
.B1(n_232),
.B2(n_227),
.Y(n_277)
);

NAND3xp33_ASAP7_75t_SL g278 ( 
.A(n_224),
.B(n_186),
.C(n_188),
.Y(n_278)
);

OAI22xp5_ASAP7_75t_L g279 ( 
.A1(n_259),
.A2(n_191),
.B1(n_214),
.B2(n_201),
.Y(n_279)
);

INVx2_ASAP7_75t_L g280 ( 
.A(n_248),
.Y(n_280)
);

INVx1_ASAP7_75t_L g281 ( 
.A(n_230),
.Y(n_281)
);

INVx1_ASAP7_75t_L g282 ( 
.A(n_230),
.Y(n_282)
);

INVx1_ASAP7_75t_L g283 ( 
.A(n_234),
.Y(n_283)
);

INVx1_ASAP7_75t_L g284 ( 
.A(n_234),
.Y(n_284)
);

OAI22xp5_ASAP7_75t_L g285 ( 
.A1(n_266),
.A2(n_191),
.B1(n_214),
.B2(n_201),
.Y(n_285)
);

NAND2xp5_ASAP7_75t_L g286 ( 
.A(n_231),
.B(n_202),
.Y(n_286)
);

OAI21xp5_ASAP7_75t_L g287 ( 
.A1(n_239),
.A2(n_205),
.B(n_187),
.Y(n_287)
);

INVx1_ASAP7_75t_L g288 ( 
.A(n_237),
.Y(n_288)
);

AND2x2_ASAP7_75t_L g289 ( 
.A(n_228),
.B(n_202),
.Y(n_289)
);

INVx1_ASAP7_75t_L g290 ( 
.A(n_237),
.Y(n_290)
);

INVx1_ASAP7_75t_L g291 ( 
.A(n_238),
.Y(n_291)
);

INVx1_ASAP7_75t_L g292 ( 
.A(n_238),
.Y(n_292)
);

AND2x2_ASAP7_75t_L g293 ( 
.A(n_225),
.B(n_193),
.Y(n_293)
);

OR2x2_ASAP7_75t_L g294 ( 
.A(n_233),
.B(n_194),
.Y(n_294)
);

NAND2xp5_ASAP7_75t_L g295 ( 
.A(n_269),
.B(n_194),
.Y(n_295)
);

NAND2xp5_ASAP7_75t_L g296 ( 
.A(n_243),
.B(n_194),
.Y(n_296)
);

A2O1A1Ixp33_ASAP7_75t_L g297 ( 
.A1(n_232),
.A2(n_187),
.B(n_192),
.C(n_189),
.Y(n_297)
);

INVx2_ASAP7_75t_L g298 ( 
.A(n_248),
.Y(n_298)
);

XNOR2x2_ASAP7_75t_SL g299 ( 
.A(n_243),
.B(n_185),
.Y(n_299)
);

AND2x2_ASAP7_75t_L g300 ( 
.A(n_254),
.B(n_198),
.Y(n_300)
);

OAI22xp33_ASAP7_75t_L g301 ( 
.A1(n_239),
.A2(n_198),
.B1(n_127),
.B2(n_73),
.Y(n_301)
);

OAI22xp5_ASAP7_75t_L g302 ( 
.A1(n_242),
.A2(n_198),
.B1(n_127),
.B2(n_73),
.Y(n_302)
);

INVx1_ASAP7_75t_SL g303 ( 
.A(n_249),
.Y(n_303)
);

NOR2xp33_ASAP7_75t_L g304 ( 
.A(n_244),
.B(n_20),
.Y(n_304)
);

AND2x2_ASAP7_75t_L g305 ( 
.A(n_221),
.B(n_22),
.Y(n_305)
);

OAI21xp33_ASAP7_75t_L g306 ( 
.A1(n_252),
.A2(n_73),
.B(n_100),
.Y(n_306)
);

AND2x2_ASAP7_75t_L g307 ( 
.A(n_264),
.B(n_23),
.Y(n_307)
);

AOI32xp33_ASAP7_75t_L g308 ( 
.A1(n_247),
.A2(n_25),
.A3(n_24),
.B1(n_27),
.B2(n_29),
.Y(n_308)
);

AOI31xp33_ASAP7_75t_L g309 ( 
.A1(n_242),
.A2(n_32),
.A3(n_31),
.B(n_30),
.Y(n_309)
);

NAND2xp5_ASAP7_75t_L g310 ( 
.A(n_261),
.B(n_34),
.Y(n_310)
);

AOI22xp33_ASAP7_75t_L g311 ( 
.A1(n_246),
.A2(n_76),
.B1(n_115),
.B2(n_127),
.Y(n_311)
);

INVx1_ASAP7_75t_L g312 ( 
.A(n_240),
.Y(n_312)
);

NAND2xp5_ASAP7_75t_L g313 ( 
.A(n_267),
.B(n_35),
.Y(n_313)
);

NOR2xp33_ASAP7_75t_L g314 ( 
.A(n_253),
.B(n_36),
.Y(n_314)
);

INVx1_ASAP7_75t_L g315 ( 
.A(n_240),
.Y(n_315)
);

NOR2xp33_ASAP7_75t_R g316 ( 
.A(n_272),
.B(n_250),
.Y(n_316)
);

AND2x2_ASAP7_75t_L g317 ( 
.A(n_275),
.B(n_222),
.Y(n_317)
);

NAND2xp33_ASAP7_75t_SL g318 ( 
.A(n_279),
.B(n_250),
.Y(n_318)
);

NAND2xp5_ASAP7_75t_L g319 ( 
.A(n_270),
.B(n_222),
.Y(n_319)
);

NOR3xp33_ASAP7_75t_SL g320 ( 
.A(n_278),
.B(n_260),
.C(n_268),
.Y(n_320)
);

OAI322xp33_ASAP7_75t_L g321 ( 
.A1(n_277),
.A2(n_294),
.A3(n_286),
.B1(n_295),
.B2(n_296),
.C1(n_273),
.C2(n_276),
.Y(n_321)
);

CKINVDCx20_ASAP7_75t_R g322 ( 
.A(n_303),
.Y(n_322)
);

INVx1_ASAP7_75t_L g323 ( 
.A(n_281),
.Y(n_323)
);

INVx1_ASAP7_75t_SL g324 ( 
.A(n_289),
.Y(n_324)
);

OR2x2_ASAP7_75t_L g325 ( 
.A(n_293),
.B(n_258),
.Y(n_325)
);

NAND4xp25_ASAP7_75t_L g326 ( 
.A(n_285),
.B(n_263),
.C(n_256),
.D(n_267),
.Y(n_326)
);

NAND2xp5_ASAP7_75t_L g327 ( 
.A(n_300),
.B(n_235),
.Y(n_327)
);

INVx1_ASAP7_75t_L g328 ( 
.A(n_282),
.Y(n_328)
);

INVxp67_ASAP7_75t_L g329 ( 
.A(n_283),
.Y(n_329)
);

XNOR2xp5_ASAP7_75t_L g330 ( 
.A(n_299),
.B(n_263),
.Y(n_330)
);

AND2x4_ASAP7_75t_L g331 ( 
.A(n_275),
.B(n_235),
.Y(n_331)
);

INVxp33_ASAP7_75t_SL g332 ( 
.A(n_271),
.Y(n_332)
);

INVx1_ASAP7_75t_L g333 ( 
.A(n_284),
.Y(n_333)
);

INVx1_ASAP7_75t_L g334 ( 
.A(n_288),
.Y(n_334)
);

NOR2x1_ASAP7_75t_L g335 ( 
.A(n_309),
.B(n_256),
.Y(n_335)
);

BUFx6f_ASAP7_75t_L g336 ( 
.A(n_310),
.Y(n_336)
);

INVx1_ASAP7_75t_L g337 ( 
.A(n_290),
.Y(n_337)
);

NAND2xp5_ASAP7_75t_L g338 ( 
.A(n_291),
.B(n_236),
.Y(n_338)
);

INVx2_ASAP7_75t_L g339 ( 
.A(n_280),
.Y(n_339)
);

INVx2_ASAP7_75t_L g340 ( 
.A(n_280),
.Y(n_340)
);

INVx1_ASAP7_75t_SL g341 ( 
.A(n_274),
.Y(n_341)
);

INVx1_ASAP7_75t_L g342 ( 
.A(n_292),
.Y(n_342)
);

BUFx4f_ASAP7_75t_SL g343 ( 
.A(n_305),
.Y(n_343)
);

NOR2xp33_ASAP7_75t_R g344 ( 
.A(n_311),
.B(n_236),
.Y(n_344)
);

INVx1_ASAP7_75t_L g345 ( 
.A(n_312),
.Y(n_345)
);

AOI221xp5_ASAP7_75t_L g346 ( 
.A1(n_321),
.A2(n_287),
.B1(n_315),
.B2(n_301),
.C(n_297),
.Y(n_346)
);

INVx1_ASAP7_75t_L g347 ( 
.A(n_329),
.Y(n_347)
);

AOI22xp5_ASAP7_75t_L g348 ( 
.A1(n_335),
.A2(n_274),
.B1(n_297),
.B2(n_301),
.Y(n_348)
);

XOR2x2_ASAP7_75t_L g349 ( 
.A(n_332),
.B(n_314),
.Y(n_349)
);

AND2x2_ASAP7_75t_L g350 ( 
.A(n_324),
.B(n_274),
.Y(n_350)
);

AOI211xp5_ASAP7_75t_L g351 ( 
.A1(n_330),
.A2(n_314),
.B(n_304),
.C(n_302),
.Y(n_351)
);

AOI211xp5_ASAP7_75t_L g352 ( 
.A1(n_318),
.A2(n_304),
.B(n_307),
.C(n_306),
.Y(n_352)
);

AOI21xp33_ASAP7_75t_L g353 ( 
.A1(n_336),
.A2(n_308),
.B(n_313),
.Y(n_353)
);

OAI21xp33_ASAP7_75t_L g354 ( 
.A1(n_316),
.A2(n_241),
.B(n_249),
.Y(n_354)
);

AOI22xp5_ASAP7_75t_L g355 ( 
.A1(n_326),
.A2(n_320),
.B1(n_341),
.B2(n_319),
.Y(n_355)
);

INVx1_ASAP7_75t_L g356 ( 
.A(n_329),
.Y(n_356)
);

INVx2_ASAP7_75t_SL g357 ( 
.A(n_322),
.Y(n_357)
);

AO22x1_ASAP7_75t_L g358 ( 
.A1(n_331),
.A2(n_343),
.B1(n_317),
.B2(n_299),
.Y(n_358)
);

OAI22xp5_ASAP7_75t_SL g359 ( 
.A1(n_343),
.A2(n_331),
.B1(n_344),
.B2(n_327),
.Y(n_359)
);

OAI221xp5_ASAP7_75t_L g360 ( 
.A1(n_320),
.A2(n_311),
.B1(n_245),
.B2(n_255),
.C(n_298),
.Y(n_360)
);

INVx1_ASAP7_75t_L g361 ( 
.A(n_323),
.Y(n_361)
);

XNOR2x1_ASAP7_75t_L g362 ( 
.A(n_325),
.B(n_241),
.Y(n_362)
);

INVx3_ASAP7_75t_SL g363 ( 
.A(n_357),
.Y(n_363)
);

AOI222xp33_ASAP7_75t_L g364 ( 
.A1(n_358),
.A2(n_333),
.B1(n_328),
.B2(n_334),
.C1(n_342),
.C2(n_337),
.Y(n_364)
);

NAND2xp5_ASAP7_75t_L g365 ( 
.A(n_346),
.B(n_338),
.Y(n_365)
);

BUFx12f_ASAP7_75t_L g366 ( 
.A(n_350),
.Y(n_366)
);

NOR2xp33_ASAP7_75t_L g367 ( 
.A(n_362),
.B(n_336),
.Y(n_367)
);

XNOR2xp5_ASAP7_75t_L g368 ( 
.A(n_349),
.B(n_359),
.Y(n_368)
);

AOI22xp33_ASAP7_75t_SL g369 ( 
.A1(n_360),
.A2(n_344),
.B1(n_336),
.B2(n_345),
.Y(n_369)
);

O2A1O1Ixp33_ASAP7_75t_L g370 ( 
.A1(n_353),
.A2(n_340),
.B(n_339),
.C(n_257),
.Y(n_370)
);

AOI221xp5_ASAP7_75t_L g371 ( 
.A1(n_355),
.A2(n_336),
.B1(n_245),
.B2(n_298),
.C(n_265),
.Y(n_371)
);

INVx2_ASAP7_75t_SL g372 ( 
.A(n_363),
.Y(n_372)
);

AOI22xp5_ASAP7_75t_L g373 ( 
.A1(n_368),
.A2(n_348),
.B1(n_354),
.B2(n_351),
.Y(n_373)
);

AOI22xp5_ASAP7_75t_L g374 ( 
.A1(n_365),
.A2(n_348),
.B1(n_356),
.B2(n_347),
.Y(n_374)
);

OAI22xp5_ASAP7_75t_L g375 ( 
.A1(n_369),
.A2(n_352),
.B1(n_361),
.B2(n_265),
.Y(n_375)
);

AOI22xp5_ASAP7_75t_L g376 ( 
.A1(n_364),
.A2(n_76),
.B1(n_115),
.B2(n_100),
.Y(n_376)
);

OAI221xp5_ASAP7_75t_L g377 ( 
.A1(n_373),
.A2(n_364),
.B1(n_371),
.B2(n_367),
.C(n_370),
.Y(n_377)
);

HB1xp67_ASAP7_75t_L g378 ( 
.A(n_372),
.Y(n_378)
);

NAND3xp33_ASAP7_75t_L g379 ( 
.A(n_374),
.B(n_366),
.C(n_115),
.Y(n_379)
);

NOR4xp25_ASAP7_75t_L g380 ( 
.A(n_377),
.B(n_375),
.C(n_376),
.D(n_38),
.Y(n_380)
);

XOR2xp5_ASAP7_75t_L g381 ( 
.A(n_378),
.B(n_41),
.Y(n_381)
);

OAI21xp5_ASAP7_75t_L g382 ( 
.A1(n_380),
.A2(n_379),
.B(n_110),
.Y(n_382)
);

XOR2xp5_ASAP7_75t_L g383 ( 
.A(n_382),
.B(n_381),
.Y(n_383)
);

AOI22xp5_ASAP7_75t_SL g384 ( 
.A1(n_383),
.A2(n_110),
.B1(n_43),
.B2(n_42),
.Y(n_384)
);

AOI221xp5_ASAP7_75t_L g385 ( 
.A1(n_384),
.A2(n_110),
.B1(n_115),
.B2(n_378),
.C(n_383),
.Y(n_385)
);


endmodule