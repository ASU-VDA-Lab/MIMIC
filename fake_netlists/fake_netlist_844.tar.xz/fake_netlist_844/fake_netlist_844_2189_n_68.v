module fake_netlist_844_2189_n_68 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_68);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_68;

wire n_48;
wire n_49;
wire n_25;
wire n_34;
wire n_20;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_44;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_60;
wire n_31;
wire n_32;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_18;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_67;
wire n_45;
wire n_46;
wire n_51;

BUFx2_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_5),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_0),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_2),
.B(n_11),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_16),
.B(n_10),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_29),
.B(n_4),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_18),
.B(n_4),
.Y(n_35)
);

XNOR2xp5_ASAP7_75t_L g36 ( 
.A(n_22),
.B(n_16),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_26),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_20),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AO21x1_ASAP7_75t_L g40 ( 
.A1(n_31),
.A2(n_28),
.B(n_35),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_33),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_33),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_32),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_32),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_39),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

OR2x2_ASAP7_75t_SL g47 ( 
.A(n_43),
.B(n_21),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_35),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_40),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_40),
.Y(n_50)
);

NAND3xp33_ASAP7_75t_SL g51 ( 
.A(n_45),
.B(n_23),
.C(n_31),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_46),
.A2(n_36),
.B1(n_42),
.B2(n_37),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

NAND2xp33_ASAP7_75t_SL g55 ( 
.A(n_51),
.B(n_47),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_28),
.B1(n_37),
.B2(n_24),
.Y(n_57)
);

INVxp67_ASAP7_75t_SL g58 ( 
.A(n_54),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_53),
.A2(n_24),
.B1(n_30),
.B2(n_27),
.Y(n_59)
);

XNOR2xp5_ASAP7_75t_L g60 ( 
.A(n_55),
.B(n_17),
.Y(n_60)
);

NAND4xp75_ASAP7_75t_L g61 ( 
.A(n_60),
.B(n_17),
.C(n_30),
.D(n_3),
.Y(n_61)
);

CKINVDCx5p33_ASAP7_75t_R g62 ( 
.A(n_58),
.Y(n_62)
);

CKINVDCx5p33_ASAP7_75t_R g63 ( 
.A(n_59),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_57),
.B(n_27),
.Y(n_64)
);

AOI221xp5_ASAP7_75t_L g65 ( 
.A1(n_63),
.A2(n_34),
.B1(n_15),
.B2(n_12),
.C(n_13),
.Y(n_65)
);

AOI22xp33_ASAP7_75t_SL g66 ( 
.A1(n_62),
.A2(n_34),
.B1(n_64),
.B2(n_61),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_62),
.Y(n_67)
);

OAI22xp5_ASAP7_75t_L g68 ( 
.A1(n_66),
.A2(n_67),
.B1(n_65),
.B2(n_34),
.Y(n_68)
);


endmodule