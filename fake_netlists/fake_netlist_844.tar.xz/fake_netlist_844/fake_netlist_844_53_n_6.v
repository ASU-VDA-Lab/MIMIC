module fake_netlist_844_53_n_6 (n_0, n_6);

input n_0;

output n_6;

wire n_4;
wire n_2;
wire n_5;
wire n_3;
wire n_1;

INVx2_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

INVx1_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

OR2x2_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

HB1xp67_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AOI211xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B(n_3),
.C(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);


endmodule