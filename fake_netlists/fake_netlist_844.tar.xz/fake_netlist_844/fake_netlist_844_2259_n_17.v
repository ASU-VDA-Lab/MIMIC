module fake_netlist_844_2259_n_17 (n_4, n_2, n_3, n_0, n_1, n_17);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

AND2x2_ASAP7_75t_SL g5 ( 
.A(n_0),
.B(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_0),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_1),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AOI31xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_6),
.A3(n_5),
.B(n_1),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_5),
.B1(n_6),
.B2(n_2),
.Y(n_11)
);

NAND2x1_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

OAI21xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_8),
.B(n_2),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AOI211xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_10),
.B(n_3),
.C(n_2),
.Y(n_15)
);

OAI31xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_3),
.A3(n_4),
.B(n_14),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_12),
.B(n_14),
.Y(n_17)
);


endmodule