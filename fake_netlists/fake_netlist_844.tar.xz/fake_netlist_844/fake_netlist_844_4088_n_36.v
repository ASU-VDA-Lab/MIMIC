module fake_netlist_844_4088_n_36 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_36);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_36;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_27;

INVx3_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_6),
.B(n_8),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_20),
.B1(n_23),
.B2(n_22),
.Y(n_27)
);

NAND4xp25_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_17),
.C(n_16),
.D(n_18),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_24),
.B1(n_26),
.B2(n_18),
.C(n_16),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_26),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_28),
.C(n_18),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_4),
.B(n_1),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_9),
.B(n_5),
.Y(n_35)
);

AOI222xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_33),
.B1(n_12),
.B2(n_10),
.C1(n_15),
.C2(n_11),
.Y(n_36)
);


endmodule