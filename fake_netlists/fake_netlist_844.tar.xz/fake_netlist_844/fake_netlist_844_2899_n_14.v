module fake_netlist_844_2899_n_14 (n_2, n_0, n_1, n_14);

input n_2;
input n_0;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

AND3x4_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.C(n_0),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

AO21x2_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AOI211xp5_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_6),
.B1(n_5),
.B2(n_0),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_8),
.Y(n_10)
);

OAI211xp5_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_2),
.B(n_6),
.C(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

XNOR2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_6),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_2),
.B1(n_6),
.B2(n_13),
.C1(n_11),
.C2(n_10),
.Y(n_14)
);


endmodule