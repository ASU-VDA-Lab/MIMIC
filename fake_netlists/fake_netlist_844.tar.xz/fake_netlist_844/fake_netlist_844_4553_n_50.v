module fake_netlist_844_4553_n_50 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_50);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_50;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_43;
wire n_45;
wire n_46;

AND2x4_ASAP7_75t_SL g22 ( 
.A(n_8),
.B(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_9),
.A2(n_10),
.B1(n_21),
.B2(n_2),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_3),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_16),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_25),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_31),
.B1(n_28),
.B2(n_26),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_29),
.B(n_23),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_32),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_36),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_37),
.Y(n_42)
);

AOI32xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_33),
.A3(n_22),
.B1(n_27),
.B2(n_34),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_24),
.B1(n_38),
.B2(n_22),
.C(n_19),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_SL g45 ( 
.A(n_43),
.B(n_20),
.Y(n_45)
);

NAND4xp75_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_21),
.C(n_20),
.D(n_1),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_47)
);

XNOR2xp5_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_7),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_11),
.B1(n_13),
.B2(n_47),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);


endmodule