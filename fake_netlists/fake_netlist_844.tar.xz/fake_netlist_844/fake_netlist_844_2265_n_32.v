module fake_netlist_844_2265_n_32 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_4),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_1),
.B(n_0),
.Y(n_23)
);

AO21x1_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_7),
.B(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx6_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

NAND4xp25_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_19),
.C(n_21),
.D(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

NOR4xp75_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_22),
.C(n_17),
.D(n_16),
.Y(n_30)
);

OAI22x1_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_R g32 ( 
.A1(n_31),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_32)
);


endmodule