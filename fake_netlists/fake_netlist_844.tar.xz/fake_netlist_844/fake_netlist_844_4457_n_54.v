module fake_netlist_844_4457_n_54 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_54);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_54;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVxp67_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_1),
.B(n_2),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_17),
.B(n_7),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_4),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_18),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_0),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

AND2x6_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_3),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_22),
.B(n_16),
.Y(n_35)
);

INVx4_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_30),
.B1(n_22),
.B2(n_24),
.C(n_27),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_25),
.B(n_31),
.Y(n_38)
);

OA21x2_ASAP7_75t_L g39 ( 
.A1(n_33),
.A2(n_28),
.B(n_23),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

BUFx3_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_37),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_37),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_36),
.B1(n_41),
.B2(n_23),
.C(n_32),
.Y(n_44)
);

OAI22xp33_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_29),
.B1(n_41),
.B2(n_39),
.Y(n_45)
);

O2A1O1Ixp33_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_41),
.B(n_34),
.C(n_23),
.Y(n_46)
);

OAI221xp5_ASAP7_75t_SL g47 ( 
.A1(n_44),
.A2(n_32),
.B1(n_34),
.B2(n_16),
.C(n_17),
.Y(n_47)
);

AND3x4_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_21),
.C(n_20),
.Y(n_48)
);

NAND4xp25_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_21),
.C(n_20),
.D(n_32),
.Y(n_49)
);

NAND4xp75_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_32),
.C(n_34),
.D(n_5),
.Y(n_50)
);

XOR2x2_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_8),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_52)
);

BUFx2_ASAP7_75t_SL g53 ( 
.A(n_51),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_52),
.B1(n_50),
.B2(n_15),
.Y(n_54)
);


endmodule