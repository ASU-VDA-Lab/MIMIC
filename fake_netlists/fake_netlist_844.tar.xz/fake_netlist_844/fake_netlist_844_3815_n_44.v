module fake_netlist_844_3815_n_44 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_44);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_44;

wire n_25;
wire n_20;
wire n_36;
wire n_17;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;

INVxp67_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_15),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_19),
.B(n_0),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_0),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_22),
.B(n_2),
.C(n_1),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

OA21x2_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_21),
.B(n_20),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_29),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI222xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_26),
.B1(n_23),
.B2(n_16),
.C1(n_24),
.C2(n_29),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_33),
.A2(n_16),
.B1(n_31),
.B2(n_27),
.Y(n_37)
);

NAND4xp25_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_26),
.C(n_28),
.D(n_31),
.Y(n_38)
);

NOR3xp33_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_17),
.C(n_3),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_L g40 ( 
.A1(n_35),
.A2(n_28),
.B1(n_30),
.B2(n_3),
.C(n_4),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_40),
.B1(n_35),
.B2(n_30),
.C(n_4),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_30),
.B1(n_7),
.B2(n_5),
.C(n_6),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

AOI322xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_41),
.A3(n_10),
.B1(n_9),
.B2(n_8),
.C1(n_14),
.C2(n_13),
.Y(n_44)
);


endmodule