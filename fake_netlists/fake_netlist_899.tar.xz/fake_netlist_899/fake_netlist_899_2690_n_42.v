module fake_netlist_899_2690_n_42 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_42);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_42;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_40;
wire n_9;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_13;
wire n_21;
wire n_25;
wire n_14;
wire n_22;
wire n_32;
wire n_35;
wire n_41;
wire n_26;
wire n_10;
wire n_29;
wire n_36;
wire n_8;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_0),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_6),
.Y(n_13)
);

AO21x2_ASAP7_75t_L g14 ( 
.A1(n_6),
.A2(n_2),
.B(n_3),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_0),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_4),
.B1(n_3),
.B2(n_1),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_13),
.B1(n_10),
.B2(n_8),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_13),
.Y(n_19)
);

INVx3_ASAP7_75t_SL g20 ( 
.A(n_12),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

INVx4_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

AND2x2_ASAP7_75t_SL g25 ( 
.A(n_17),
.B(n_14),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_18),
.B1(n_14),
.B2(n_16),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_14),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_25),
.B1(n_21),
.B2(n_23),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_24),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_9),
.B1(n_24),
.B2(n_27),
.C(n_22),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_32),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

BUFx4f_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

NOR4xp75_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_9),
.C(n_14),
.D(n_1),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_35),
.A2(n_4),
.B1(n_27),
.B2(n_37),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_27),
.B1(n_36),
.B2(n_38),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_27),
.B1(n_39),
.B2(n_41),
.Y(n_42)
);


endmodule