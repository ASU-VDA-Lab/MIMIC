module fake_netlist_899_1670_n_21 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_21;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_14;
wire n_10;

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_2),
.B(n_4),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_3),
.A2(n_7),
.B1(n_6),
.B2(n_1),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

AOI221x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_1),
.B1(n_0),
.B2(n_4),
.C(n_5),
.Y(n_14)
);

A2O1A1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_7),
.B(n_5),
.C(n_0),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

NOR2x1_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_10),
.Y(n_17)
);

OAI211xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B(n_11),
.C(n_8),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_14),
.Y(n_21)
);


endmodule