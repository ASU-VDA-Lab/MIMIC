module fake_netlist_899_1676_n_16 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_16);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_16;

wire n_15;
wire n_11;
wire n_9;
wire n_13;
wire n_14;
wire n_10;
wire n_8;
wire n_12;

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_1),
.A2(n_2),
.B1(n_4),
.B2(n_0),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_3),
.A2(n_1),
.B1(n_6),
.B2(n_4),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_7),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B(n_5),
.Y(n_11)
);

CKINVDCx16_ASAP7_75t_R g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_13),
.Y(n_14)
);

AOI22x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_5),
.B1(n_14),
.B2(n_13),
.Y(n_16)
);


endmodule