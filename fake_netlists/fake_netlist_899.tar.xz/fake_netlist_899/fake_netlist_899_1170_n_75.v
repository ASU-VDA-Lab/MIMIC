module fake_netlist_899_1170_n_75 (n_3, n_15, n_11, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_75);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_75;

wire n_74;
wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_68;
wire n_46;
wire n_63;
wire n_30;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_66;
wire n_65;
wire n_71;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_70;
wire n_67;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_32;
wire n_41;
wire n_42;
wire n_57;
wire n_35;
wire n_25;
wire n_43;
wire n_62;
wire n_26;
wire n_36;
wire n_44;
wire n_29;
wire n_45;
wire n_48;
wire n_69;
wire n_72;
wire n_38;
wire n_73;
wire n_56;

INVx3_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_9),
.B(n_1),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_11),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_14),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_0),
.Y(n_30)
);

OA21x2_ASAP7_75t_L g31 ( 
.A1(n_16),
.A2(n_12),
.B(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_20),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_13),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_7),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_19),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_33),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_33),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_26),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_26),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_38),
.B(n_24),
.Y(n_44)
);

OAI21x1_ASAP7_75t_L g45 ( 
.A1(n_39),
.A2(n_24),
.B(n_31),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_39),
.B(n_27),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_L g47 ( 
.A(n_41),
.B(n_27),
.Y(n_47)
);

AND2x4_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_46),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_29),
.Y(n_49)
);

INVx3_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_49),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_54),
.B(n_47),
.Y(n_55)
);

INVx1_ASAP7_75t_SL g56 ( 
.A(n_51),
.Y(n_56)
);

AOI211xp5_ASAP7_75t_L g57 ( 
.A1(n_52),
.A2(n_40),
.B(n_43),
.C(n_42),
.Y(n_57)
);

INVxp67_ASAP7_75t_SL g58 ( 
.A(n_53),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_37),
.Y(n_59)
);

INVx1_ASAP7_75t_SL g60 ( 
.A(n_56),
.Y(n_60)
);

NAND4xp25_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_37),
.C(n_34),
.D(n_28),
.Y(n_61)
);

AOI22xp33_ASAP7_75t_L g62 ( 
.A1(n_58),
.A2(n_24),
.B1(n_31),
.B2(n_35),
.Y(n_62)
);

HB1xp67_ASAP7_75t_L g63 ( 
.A(n_57),
.Y(n_63)
);

NOR4xp25_ASAP7_75t_L g64 ( 
.A(n_61),
.B(n_35),
.C(n_25),
.D(n_20),
.Y(n_64)
);

NAND3xp33_ASAP7_75t_L g65 ( 
.A(n_63),
.B(n_30),
.C(n_29),
.Y(n_65)
);

AND2x2_ASAP7_75t_L g66 ( 
.A(n_60),
.B(n_30),
.Y(n_66)
);

AND2x2_ASAP7_75t_L g67 ( 
.A(n_59),
.B(n_31),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_62),
.B(n_31),
.Y(n_68)
);

NOR4xp25_ASAP7_75t_SL g69 ( 
.A(n_64),
.B(n_45),
.C(n_25),
.D(n_2),
.Y(n_69)
);

AO22x2_ASAP7_75t_L g70 ( 
.A1(n_65),
.A2(n_50),
.B1(n_5),
.B2(n_3),
.Y(n_70)
);

AOI22xp5_ASAP7_75t_L g71 ( 
.A1(n_65),
.A2(n_50),
.B1(n_8),
.B2(n_6),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_67),
.Y(n_72)
);

AOI22xp33_ASAP7_75t_SL g73 ( 
.A1(n_70),
.A2(n_68),
.B1(n_66),
.B2(n_50),
.Y(n_73)
);

AOI21xp5_ASAP7_75t_L g74 ( 
.A1(n_69),
.A2(n_23),
.B(n_22),
.Y(n_74)
);

AOI22x1_ASAP7_75t_L g75 ( 
.A1(n_74),
.A2(n_72),
.B1(n_73),
.B2(n_71),
.Y(n_75)
);


endmodule