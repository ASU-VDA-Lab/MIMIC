module fake_netlist_899_2069_n_40 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_40);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_40;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_13;
wire n_25;
wire n_22;
wire n_14;
wire n_32;
wire n_35;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_11),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_6),
.A2(n_10),
.B(n_7),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

BUFx4f_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_5),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_17),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_21),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_20),
.C(n_24),
.Y(n_30)
);

AOI31xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_27),
.A3(n_15),
.B(n_13),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_27),
.C(n_23),
.Y(n_33)
);

OAI211xp5_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_34)
);

OAI221xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_17),
.B1(n_19),
.B2(n_23),
.C(n_18),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_31),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_17),
.B1(n_23),
.B2(n_18),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

OAI21xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_34),
.B(n_18),
.Y(n_39)
);

AOI322xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.A3(n_37),
.B1(n_8),
.B2(n_9),
.C1(n_1),
.C2(n_2),
.Y(n_40)
);


endmodule