module fake_netlist_899_1556_n_14 (n_0, n_1, n_3, n_2, n_14);

input n_0;
input n_1;
input n_3;
input n_2;

output n_14;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_7),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_5),
.B1(n_6),
.B2(n_1),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B(n_6),
.C(n_1),
.Y(n_12)
);

OAI22x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B1(n_2),
.B2(n_0),
.Y(n_13)
);

OAI222xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_3),
.B1(n_5),
.B2(n_6),
.C1(n_11),
.C2(n_12),
.Y(n_14)
);


endmodule