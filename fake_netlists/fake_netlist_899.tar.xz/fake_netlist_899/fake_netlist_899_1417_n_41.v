module fake_netlist_899_1417_n_41 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_41);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_41;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

INVx1_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_12),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_0),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_3),
.B(n_4),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_16),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_21),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_19),
.B1(n_18),
.B2(n_22),
.Y(n_27)
);

O2A1O1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_18),
.A2(n_16),
.B(n_5),
.C(n_1),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_19),
.Y(n_29)
);

OR2x6_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_24),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_26),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_30),
.B1(n_23),
.B2(n_20),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_5),
.Y(n_34)
);

OAI21xp5_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_17),
.B(n_6),
.Y(n_35)
);

NOR3xp33_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_17),
.C(n_8),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_9),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_13),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_SL g41 ( 
.A1(n_40),
.A2(n_14),
.B1(n_15),
.B2(n_39),
.Y(n_41)
);


endmodule