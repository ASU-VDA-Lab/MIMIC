module fake_netlist_899_1343_n_21 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_21;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_14;
wire n_10;

INVx2_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_2),
.B(n_1),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_3),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

O2A1O1Ixp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_14),
.B(n_6),
.C(n_5),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

NOR2xp67_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_4),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_12),
.B(n_5),
.Y(n_20)
);

AO21x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_9),
.B(n_8),
.Y(n_21)
);


endmodule