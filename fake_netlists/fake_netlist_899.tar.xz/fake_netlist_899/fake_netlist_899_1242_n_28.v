module fake_netlist_899_1242_n_28 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_28);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_28;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

INVx3_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_4),
.B(n_9),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

INVxp67_ASAP7_75t_SL g18 ( 
.A(n_13),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_15),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_16),
.Y(n_21)
);

OAI31xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_17),
.A3(n_3),
.B(n_1),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_7),
.B2(n_6),
.Y(n_23)
);

INVxp67_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_10),
.Y(n_25)
);

NOR3xp33_ASAP7_75t_SL g26 ( 
.A(n_25),
.B(n_12),
.C(n_11),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);


endmodule