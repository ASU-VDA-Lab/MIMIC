module fake_netlist_899_2665_n_37 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_37);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_37;

wire n_33;
wire n_34;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_31;
wire n_21;
wire n_25;
wire n_22;
wire n_32;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_19),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_14),
.B(n_15),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_13),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_22),
.B(n_19),
.Y(n_28)
);

AO32x1_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_1),
.A3(n_0),
.B1(n_2),
.B2(n_3),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

OAI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_21),
.B1(n_25),
.B2(n_23),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OAI21xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B(n_24),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_21),
.B1(n_26),
.B2(n_4),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

OAI22x1_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_8),
.B1(n_6),
.B2(n_5),
.Y(n_36)
);

AOI222xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_12),
.B1(n_11),
.B2(n_16),
.C1(n_20),
.C2(n_18),
.Y(n_37)
);


endmodule