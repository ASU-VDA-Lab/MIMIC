module fake_netlist_899_178_n_17 (n_0, n_2, n_5, n_3, n_4, n_1, n_17);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_17;

wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

BUFx3_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

CKINVDCx20_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_8),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AND2x4_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_6),
.B1(n_7),
.B2(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_R g15 ( 
.A(n_14),
.B(n_2),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_17)
);


endmodule