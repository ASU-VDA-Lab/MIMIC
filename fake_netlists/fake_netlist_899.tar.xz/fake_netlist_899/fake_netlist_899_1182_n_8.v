module fake_netlist_899_1182_n_8 (n_0, n_1, n_2, n_8);

input n_0;
input n_1;
input n_2;

output n_8;

wire n_5;
wire n_3;
wire n_4;
wire n_6;
wire n_7;

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVxp67_ASAP7_75t_SL g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NOR2x1_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);


endmodule