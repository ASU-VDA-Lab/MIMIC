module fake_netlist_899_1003_n_35 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_35);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_35;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_13;
wire n_21;
wire n_25;
wire n_22;
wire n_14;
wire n_32;
wire n_26;
wire n_29;

NOR2xp67_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_0),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_17),
.B1(n_16),
.B2(n_18),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_SL g23 ( 
.A1(n_19),
.A2(n_14),
.B(n_13),
.Y(n_23)
);

NAND4xp25_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_16),
.C(n_18),
.D(n_13),
.Y(n_24)
);

NAND4xp25_ASAP7_75t_SL g25 ( 
.A(n_22),
.B(n_14),
.C(n_18),
.D(n_1),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_20),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_22),
.Y(n_27)
);

INVx2_ASAP7_75t_SL g28 ( 
.A(n_26),
.Y(n_28)
);

NOR2x1_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_26),
.Y(n_29)
);

OAI211xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_20),
.B(n_15),
.C(n_3),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_15),
.B1(n_5),
.B2(n_4),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_30),
.B(n_6),
.C(n_4),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_7),
.Y(n_33)
);

AND2x6_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_11),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_32),
.B1(n_11),
.B2(n_10),
.Y(n_35)
);


endmodule