module fake_netlist_899_842_n_24 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_24);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_24;

wire n_15;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;

NAND2xp33_ASAP7_75t_R g12 ( 
.A(n_9),
.B(n_4),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_2),
.A2(n_6),
.B1(n_10),
.B2(n_5),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_0),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_7),
.B(n_1),
.Y(n_15)
);

INVx5_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

INVx5_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND3x1_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_8),
.C(n_3),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND3x1_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.C(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_R g24 ( 
.A1(n_23),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_24)
);


endmodule