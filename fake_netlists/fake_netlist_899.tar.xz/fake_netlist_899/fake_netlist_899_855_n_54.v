module fake_netlist_899_855_n_54 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_54);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_54;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_28;
wire n_53;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_10),
.A2(n_20),
.B(n_19),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

AOI22x1_ASAP7_75t_SL g29 ( 
.A1(n_8),
.A2(n_6),
.B1(n_16),
.B2(n_17),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_15),
.B(n_4),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_7),
.B(n_23),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_1),
.B(n_2),
.Y(n_32)
);

OR2x6_ASAP7_75t_L g33 ( 
.A(n_20),
.B(n_16),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_22),
.B1(n_21),
.B2(n_18),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_25),
.B(n_33),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_26),
.B(n_28),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_27),
.B(n_31),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_33),
.B1(n_25),
.B2(n_32),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_SL g40 ( 
.A1(n_34),
.A2(n_33),
.B1(n_29),
.B2(n_26),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_36),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_39),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_SL g46 ( 
.A(n_44),
.B(n_40),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_28),
.B1(n_30),
.B2(n_42),
.C(n_29),
.Y(n_47)
);

OAI21xp33_ASAP7_75t_SL g48 ( 
.A1(n_45),
.A2(n_27),
.B(n_30),
.Y(n_48)
);

OAI211xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_24),
.B(n_23),
.C(n_21),
.Y(n_49)
);

OAI311xp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_24),
.A3(n_5),
.B1(n_0),
.C1(n_3),
.Y(n_50)
);

INVxp67_ASAP7_75t_SL g51 ( 
.A(n_49),
.Y(n_51)
);

CKINVDCx20_ASAP7_75t_R g52 ( 
.A(n_50),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_53)
);

OAI21xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_51),
.B(n_52),
.Y(n_54)
);


endmodule