module fake_netlist_899_2595_n_38 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_38);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_38;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

INVx1_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_10),
.A2(n_1),
.B1(n_5),
.B2(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_4),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_7),
.Y(n_22)
);

BUFx10_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_15),
.B(n_16),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_17),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_21),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_23),
.B(n_15),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_24),
.B1(n_19),
.B2(n_23),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI211x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_26),
.B(n_30),
.C(n_16),
.Y(n_33)
);

OA21x2_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_22),
.B(n_20),
.Y(n_34)
);

NOR2xp67_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_0),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_34),
.B1(n_35),
.B2(n_17),
.Y(n_37)
);

AOI222xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_8),
.B1(n_6),
.B2(n_9),
.C1(n_14),
.C2(n_13),
.Y(n_38)
);


endmodule