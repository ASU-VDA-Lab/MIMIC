module fake_netlist_899_2369_n_36 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_36);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_36;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_25;
wire n_32;
wire n_22;
wire n_35;
wire n_26;
wire n_29;

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_5),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_14),
.B(n_7),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_9),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_16),
.B(n_4),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_19),
.A2(n_3),
.B(n_1),
.Y(n_24)
);

O2A1O1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_15),
.A2(n_14),
.B(n_13),
.C(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_27),
.Y(n_30)
);

AOI221xp5_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_28),
.B2(n_24),
.C(n_18),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_17),
.B(n_21),
.C(n_20),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_31),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_17),
.B1(n_22),
.B2(n_13),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_33),
.B1(n_12),
.B2(n_10),
.Y(n_36)
);


endmodule