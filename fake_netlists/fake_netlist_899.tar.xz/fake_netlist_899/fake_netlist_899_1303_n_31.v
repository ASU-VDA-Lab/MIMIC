module fake_netlist_899_1303_n_31 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_31);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_31;

wire n_15;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_25;
wire n_22;
wire n_14;
wire n_26;
wire n_29;

AND2x4_ASAP7_75t_L g13 ( 
.A(n_1),
.B(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_SL g14 ( 
.A(n_6),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B1(n_17),
.B2(n_13),
.C(n_18),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_21),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI322xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_6),
.A3(n_4),
.B1(n_8),
.B2(n_9),
.C1(n_0),
.C2(n_3),
.Y(n_30)
);

AOI322xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.A3(n_21),
.B1(n_4),
.B2(n_19),
.C1(n_11),
.C2(n_12),
.Y(n_31)
);


endmodule