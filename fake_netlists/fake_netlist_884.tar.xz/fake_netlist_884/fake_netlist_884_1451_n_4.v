module fake_netlist_884_1451_n_4 (n_0, n_1, n_2, n_4);

input n_0;
input n_1;
input n_2;

output n_4;

wire n_3;

HB1xp67_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

AOI211xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_2),
.C(n_0),
.Y(n_4)
);


endmodule