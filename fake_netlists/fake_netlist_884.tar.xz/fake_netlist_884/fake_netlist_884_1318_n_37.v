module fake_netlist_884_1318_n_37 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_37);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_37;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_32;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

INVx3_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

BUFx10_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_5),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_6),
.B(n_7),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_1),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_4),
.B(n_2),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_11),
.B(n_0),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_1),
.Y(n_19)
);

INVxp67_ASAP7_75t_SL g20 ( 
.A(n_14),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_14),
.A2(n_10),
.B(n_8),
.C(n_3),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_21),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_12),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_13),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_13),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

AOI211xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_22),
.B(n_16),
.C(n_24),
.Y(n_29)
);

NAND4xp25_ASAP7_75t_SL g30 ( 
.A(n_29),
.B(n_27),
.C(n_26),
.D(n_22),
.Y(n_30)
);

NOR2x1_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_22),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_22),
.B1(n_25),
.B2(n_15),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_32),
.Y(n_34)
);

BUFx4f_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_34),
.B1(n_36),
.B2(n_30),
.Y(n_37)
);


endmodule