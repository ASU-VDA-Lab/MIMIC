module fake_netlist_884_494_n_22 (n_0, n_2, n_3, n_4, n_1, n_22);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_22;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_19;
wire n_12;
wire n_5;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_21;
wire n_14;
wire n_10;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

CKINVDCx14_ASAP7_75t_R g6 ( 
.A(n_1),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_R g7 ( 
.A(n_1),
.B(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_7),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_11),
.B(n_13),
.C(n_12),
.Y(n_16)
);

AOI211xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_13),
.B(n_11),
.C(n_0),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_2),
.B1(n_0),
.B2(n_3),
.Y(n_20)
);

AOI22x1_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_2),
.B1(n_4),
.B2(n_15),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_SL g22 ( 
.A1(n_20),
.A2(n_18),
.B1(n_21),
.B2(n_4),
.Y(n_22)
);


endmodule