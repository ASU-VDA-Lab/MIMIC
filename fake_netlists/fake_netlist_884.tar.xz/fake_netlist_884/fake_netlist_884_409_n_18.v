module fake_netlist_884_409_n_18 (n_0, n_1, n_3, n_2, n_18);

input n_0;
input n_1;
input n_3;
input n_2;

output n_18;

wire n_5;
wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_17;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

INVx3_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx4_ASAP7_75t_SL g5 ( 
.A(n_0),
.Y(n_5)
);

AND2x6_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_1),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_9),
.Y(n_10)
);

INVxp67_ASAP7_75t_SL g11 ( 
.A(n_7),
.Y(n_11)
);

O2A1O1Ixp5_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_5),
.B(n_6),
.C(n_8),
.Y(n_12)
);

OAI311xp33_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_8),
.A3(n_6),
.B1(n_0),
.C1(n_1),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B1(n_6),
.B2(n_11),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_SL g15 ( 
.A1(n_12),
.A2(n_7),
.B(n_2),
.C(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI21xp33_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_7),
.B(n_2),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_5),
.B1(n_12),
.B2(n_16),
.Y(n_18)
);


endmodule