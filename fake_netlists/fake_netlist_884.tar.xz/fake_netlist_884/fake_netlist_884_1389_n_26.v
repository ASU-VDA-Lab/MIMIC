module fake_netlist_884_1389_n_26 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_26);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_26;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_22;
wire n_14;
wire n_25;

AO22x2_ASAP7_75t_L g14 ( 
.A1(n_7),
.A2(n_10),
.B1(n_1),
.B2(n_5),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_13),
.B(n_1),
.Y(n_15)
);

OAI22xp33_ASAP7_75t_L g16 ( 
.A1(n_8),
.A2(n_9),
.B1(n_3),
.B2(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_7),
.Y(n_18)
);

O2A1O1Ixp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_18),
.B(n_16),
.C(n_17),
.Y(n_19)
);

INVxp67_ASAP7_75t_SL g20 ( 
.A(n_14),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_20),
.Y(n_22)
);

O2A1O1Ixp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B(n_14),
.C(n_4),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_14),
.C(n_4),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_11),
.B(n_2),
.Y(n_25)
);

AND3x1_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_6),
.C(n_22),
.Y(n_26)
);


endmodule