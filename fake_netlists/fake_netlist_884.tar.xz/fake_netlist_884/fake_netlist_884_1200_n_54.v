module fake_netlist_884_1200_n_54 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_54);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_54;

wire n_51;
wire n_33;
wire n_50;
wire n_15;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_16;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_53;
wire n_19;
wire n_12;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_14;
wire n_35;
wire n_13;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_48;
wire n_45;
wire n_38;

INVx3_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_8),
.A2(n_6),
.B(n_11),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_2),
.B(n_6),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_12),
.B(n_1),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_17),
.B(n_5),
.C(n_0),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_12),
.B(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_16),
.B(n_5),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_10),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

BUFx8_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_14),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_21),
.B1(n_26),
.B2(n_19),
.Y(n_34)
);

NAND2xp33_ASAP7_75t_SL g35 ( 
.A(n_29),
.B(n_23),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_L g36 ( 
.A(n_30),
.B(n_26),
.C(n_28),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_28),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_34),
.B(n_28),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_30),
.Y(n_41)
);

CKINVDCx16_ASAP7_75t_R g42 ( 
.A(n_39),
.Y(n_42)
);

AOI221x1_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_19),
.B1(n_20),
.B2(n_13),
.C(n_15),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_37),
.Y(n_44)
);

OAI21xp33_ASAP7_75t_SL g45 ( 
.A1(n_41),
.A2(n_13),
.B(n_19),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_42),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_R g47 ( 
.A(n_44),
.B(n_15),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_46),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_46),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

AOI322xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_43),
.A3(n_45),
.B1(n_47),
.B2(n_49),
.C1(n_50),
.C2(n_52),
.Y(n_54)
);


endmodule