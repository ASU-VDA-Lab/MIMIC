module fake_netlist_884_1060_n_348 (n_3, n_33, n_15, n_11, n_34, n_24, n_6, n_37, n_16, n_0, n_30, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_39, n_17, n_18, n_31, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_32, n_35, n_26, n_10, n_29, n_36, n_8, n_38, n_348);

input n_3;
input n_33;
input n_15;
input n_11;
input n_34;
input n_24;
input n_6;
input n_37;
input n_16;
input n_0;
input n_30;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_39;
input n_17;
input n_18;
input n_31;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_32;
input n_35;
input n_26;
input n_10;
input n_29;
input n_36;
input n_8;
input n_38;

output n_348;

wire n_104;
wire n_337;
wire n_240;
wire n_341;
wire n_154;
wire n_193;
wire n_294;
wire n_164;
wire n_345;
wire n_143;
wire n_195;
wire n_169;
wire n_292;
wire n_192;
wire n_289;
wire n_94;
wire n_182;
wire n_308;
wire n_224;
wire n_80;
wire n_229;
wire n_288;
wire n_83;
wire n_207;
wire n_210;
wire n_190;
wire n_51;
wire n_217;
wire n_242;
wire n_270;
wire n_296;
wire n_183;
wire n_144;
wire n_54;
wire n_238;
wire n_189;
wire n_245;
wire n_40;
wire n_325;
wire n_141;
wire n_150;
wire n_226;
wire n_335;
wire n_142;
wire n_256;
wire n_159;
wire n_297;
wire n_184;
wire n_293;
wire n_303;
wire n_113;
wire n_208;
wire n_266;
wire n_172;
wire n_77;
wire n_204;
wire n_274;
wire n_106;
wire n_81;
wire n_84;
wire n_300;
wire n_346;
wire n_283;
wire n_130;
wire n_43;
wire n_72;
wire n_76;
wire n_278;
wire n_179;
wire n_310;
wire n_103;
wire n_160;
wire n_108;
wire n_47;
wire n_163;
wire n_105;
wire n_215;
wire n_232;
wire n_58;
wire n_328;
wire n_231;
wire n_98;
wire n_267;
wire n_89;
wire n_82;
wire n_117;
wire n_146;
wire n_78;
wire n_333;
wire n_118;
wire n_100;
wire n_60;
wire n_216;
wire n_101;
wire n_127;
wire n_111;
wire n_314;
wire n_153;
wire n_244;
wire n_102;
wire n_306;
wire n_197;
wire n_212;
wire n_316;
wire n_264;
wire n_214;
wire n_91;
wire n_273;
wire n_149;
wire n_284;
wire n_196;
wire n_69;
wire n_165;
wire n_131;
wire n_50;
wire n_55;
wire n_247;
wire n_285;
wire n_46;
wire n_286;
wire n_344;
wire n_237;
wire n_312;
wire n_132;
wire n_225;
wire n_120;
wire n_188;
wire n_252;
wire n_230;
wire n_200;
wire n_280;
wire n_53;
wire n_161;
wire n_90;
wire n_277;
wire n_221;
wire n_140;
wire n_324;
wire n_301;
wire n_122;
wire n_138;
wire n_263;
wire n_139;
wire n_269;
wire n_181;
wire n_74;
wire n_331;
wire n_158;
wire n_86;
wire n_63;
wire n_241;
wire n_114;
wire n_156;
wire n_205;
wire n_49;
wire n_109;
wire n_168;
wire n_315;
wire n_97;
wire n_178;
wire n_249;
wire n_194;
wire n_287;
wire n_92;
wire n_262;
wire n_235;
wire n_52;
wire n_151;
wire n_152;
wire n_185;
wire n_116;
wire n_334;
wire n_64;
wire n_65;
wire n_88;
wire n_253;
wire n_268;
wire n_305;
wire n_71;
wire n_135;
wire n_302;
wire n_311;
wire n_134;
wire n_276;
wire n_162;
wire n_223;
wire n_248;
wire n_320;
wire n_211;
wire n_59;
wire n_227;
wire n_347;
wire n_220;
wire n_42;
wire n_222;
wire n_255;
wire n_271;
wire n_148;
wire n_44;
wire n_257;
wire n_342;
wire n_115;
wire n_155;
wire n_233;
wire n_129;
wire n_272;
wire n_95;
wire n_258;
wire n_327;
wire n_279;
wire n_251;
wire n_48;
wire n_322;
wire n_56;
wire n_175;
wire n_213;
wire n_125;
wire n_275;
wire n_336;
wire n_75;
wire n_236;
wire n_124;
wire n_265;
wire n_147;
wire n_239;
wire n_254;
wire n_219;
wire n_57;
wire n_121;
wire n_261;
wire n_45;
wire n_73;
wire n_202;
wire n_250;
wire n_298;
wire n_99;
wire n_93;
wire n_157;
wire n_66;
wire n_338;
wire n_186;
wire n_198;
wire n_206;
wire n_174;
wire n_339;
wire n_228;
wire n_321;
wire n_299;
wire n_318;
wire n_96;
wire n_128;
wire n_323;
wire n_123;
wire n_234;
wire n_329;
wire n_110;
wire n_295;
wire n_177;
wire n_173;
wire n_166;
wire n_313;
wire n_70;
wire n_243;
wire n_282;
wire n_317;
wire n_41;
wire n_126;
wire n_62;
wire n_79;
wire n_187;
wire n_87;
wire n_307;
wire n_191;
wire n_209;
wire n_340;
wire n_107;
wire n_199;
wire n_309;
wire n_180;
wire n_137;
wire n_167;
wire n_291;
wire n_343;
wire n_171;
wire n_61;
wire n_330;
wire n_170;
wire n_136;
wire n_246;
wire n_304;
wire n_176;
wire n_133;
wire n_326;
wire n_218;
wire n_290;
wire n_281;
wire n_68;
wire n_145;
wire n_85;
wire n_112;
wire n_67;
wire n_259;
wire n_119;
wire n_260;
wire n_319;
wire n_203;
wire n_332;
wire n_201;

INVx1_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

INVxp67_ASAP7_75t_SL g41 ( 
.A(n_38),
.Y(n_41)
);

INVxp67_ASAP7_75t_SL g42 ( 
.A(n_4),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_19),
.Y(n_43)
);

INVx3_ASAP7_75t_L g44 ( 
.A(n_24),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_2),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_21),
.Y(n_46)
);

CKINVDCx14_ASAP7_75t_R g47 ( 
.A(n_32),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_11),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_28),
.Y(n_49)
);

CKINVDCx20_ASAP7_75t_R g50 ( 
.A(n_17),
.Y(n_50)
);

CKINVDCx16_ASAP7_75t_R g51 ( 
.A(n_11),
.Y(n_51)
);

INVxp67_ASAP7_75t_SL g52 ( 
.A(n_26),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_27),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_5),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_3),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_16),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_37),
.Y(n_57)
);

INVxp33_ASAP7_75t_SL g58 ( 
.A(n_23),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_5),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_15),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_2),
.Y(n_61)
);

INVxp33_ASAP7_75t_L g62 ( 
.A(n_33),
.Y(n_62)
);

CKINVDCx5p33_ASAP7_75t_R g63 ( 
.A(n_51),
.Y(n_63)
);

CKINVDCx20_ASAP7_75t_R g64 ( 
.A(n_50),
.Y(n_64)
);

XNOR2xp5_ASAP7_75t_L g65 ( 
.A(n_42),
.B(n_0),
.Y(n_65)
);

INVx1_ASAP7_75t_SL g66 ( 
.A(n_51),
.Y(n_66)
);

CKINVDCx5p33_ASAP7_75t_R g67 ( 
.A(n_45),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_48),
.Y(n_68)
);

CKINVDCx5p33_ASAP7_75t_R g69 ( 
.A(n_58),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_48),
.Y(n_70)
);

CKINVDCx5p33_ASAP7_75t_R g71 ( 
.A(n_47),
.Y(n_71)
);

NOR2xp33_ASAP7_75t_R g72 ( 
.A(n_47),
.B(n_0),
.Y(n_72)
);

CKINVDCx5p33_ASAP7_75t_R g73 ( 
.A(n_42),
.Y(n_73)
);

CKINVDCx5p33_ASAP7_75t_R g74 ( 
.A(n_40),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_54),
.Y(n_75)
);

INVx2_ASAP7_75t_L g76 ( 
.A(n_46),
.Y(n_76)
);

NOR2xp33_ASAP7_75t_L g77 ( 
.A(n_62),
.B(n_1),
.Y(n_77)
);

HB1xp67_ASAP7_75t_L g78 ( 
.A(n_54),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_55),
.Y(n_79)
);

AND2x2_ASAP7_75t_L g80 ( 
.A(n_55),
.B(n_1),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_59),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_59),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_60),
.Y(n_83)
);

NAND2x1p5_ASAP7_75t_L g84 ( 
.A(n_80),
.B(n_44),
.Y(n_84)
);

BUFx6f_ASAP7_75t_L g85 ( 
.A(n_76),
.Y(n_85)
);

AND2x4_ASAP7_75t_L g86 ( 
.A(n_80),
.B(n_60),
.Y(n_86)
);

NAND2xp33_ASAP7_75t_L g87 ( 
.A(n_80),
.B(n_44),
.Y(n_87)
);

NAND2xp5_ASAP7_75t_L g88 ( 
.A(n_71),
.B(n_74),
.Y(n_88)
);

AO22x2_ASAP7_75t_L g89 ( 
.A1(n_66),
.A2(n_61),
.B1(n_43),
.B2(n_40),
.Y(n_89)
);

AND2x4_ASAP7_75t_L g90 ( 
.A(n_68),
.B(n_61),
.Y(n_90)
);

INVx2_ASAP7_75t_L g91 ( 
.A(n_76),
.Y(n_91)
);

CKINVDCx5p33_ASAP7_75t_R g92 ( 
.A(n_69),
.Y(n_92)
);

AND2x2_ASAP7_75t_L g93 ( 
.A(n_78),
.B(n_62),
.Y(n_93)
);

NOR2xp67_ASAP7_75t_L g94 ( 
.A(n_67),
.B(n_44),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_76),
.Y(n_95)
);

INVx2_ASAP7_75t_SL g96 ( 
.A(n_72),
.Y(n_96)
);

AOI22xp5_ASAP7_75t_L g97 ( 
.A1(n_77),
.A2(n_52),
.B1(n_41),
.B2(n_43),
.Y(n_97)
);

INVx2_ASAP7_75t_L g98 ( 
.A(n_68),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_70),
.Y(n_99)
);

AND2x4_ASAP7_75t_L g100 ( 
.A(n_70),
.B(n_53),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_75),
.Y(n_101)
);

NOR2xp33_ASAP7_75t_L g102 ( 
.A(n_77),
.B(n_73),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_75),
.Y(n_103)
);

NAND2xp5_ASAP7_75t_L g104 ( 
.A(n_79),
.B(n_53),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_79),
.Y(n_105)
);

INVxp67_ASAP7_75t_L g106 ( 
.A(n_66),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_81),
.Y(n_107)
);

NOR2x1p5_ASAP7_75t_L g108 ( 
.A(n_63),
.B(n_41),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_81),
.Y(n_109)
);

NOR2xp33_ASAP7_75t_L g110 ( 
.A(n_102),
.B(n_78),
.Y(n_110)
);

INVxp67_ASAP7_75t_L g111 ( 
.A(n_106),
.Y(n_111)
);

NOR2xp33_ASAP7_75t_L g112 ( 
.A(n_88),
.B(n_82),
.Y(n_112)
);

INVx1_ASAP7_75t_SL g113 ( 
.A(n_93),
.Y(n_113)
);

BUFx8_ASAP7_75t_L g114 ( 
.A(n_93),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_99),
.Y(n_115)
);

NOR2xp33_ASAP7_75t_L g116 ( 
.A(n_96),
.B(n_82),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_85),
.Y(n_117)
);

NOR2xp33_ASAP7_75t_L g118 ( 
.A(n_96),
.B(n_83),
.Y(n_118)
);

AOI21xp5_ASAP7_75t_L g119 ( 
.A1(n_87),
.A2(n_52),
.B(n_56),
.Y(n_119)
);

NAND3xp33_ASAP7_75t_SL g120 ( 
.A(n_97),
.B(n_56),
.C(n_83),
.Y(n_120)
);

BUFx12f_ASAP7_75t_L g121 ( 
.A(n_108),
.Y(n_121)
);

NAND2xp5_ASAP7_75t_L g122 ( 
.A(n_94),
.B(n_46),
.Y(n_122)
);

AOI21xp5_ASAP7_75t_L g123 ( 
.A1(n_87),
.A2(n_49),
.B(n_46),
.Y(n_123)
);

NAND2x1_ASAP7_75t_L g124 ( 
.A(n_100),
.B(n_44),
.Y(n_124)
);

NAND2xp5_ASAP7_75t_SL g125 ( 
.A(n_84),
.B(n_65),
.Y(n_125)
);

NAND2xp5_ASAP7_75t_L g126 ( 
.A(n_86),
.B(n_49),
.Y(n_126)
);

OAI22xp5_ASAP7_75t_L g127 ( 
.A1(n_84),
.A2(n_65),
.B1(n_57),
.B2(n_49),
.Y(n_127)
);

NAND2xp5_ASAP7_75t_L g128 ( 
.A(n_86),
.B(n_57),
.Y(n_128)
);

NOR2xp33_ASAP7_75t_L g129 ( 
.A(n_92),
.B(n_64),
.Y(n_129)
);

NOR2x1_ASAP7_75t_L g130 ( 
.A(n_95),
.B(n_57),
.Y(n_130)
);

NAND2xp5_ASAP7_75t_L g131 ( 
.A(n_86),
.B(n_3),
.Y(n_131)
);

OR2x6_ASAP7_75t_L g132 ( 
.A(n_89),
.B(n_4),
.Y(n_132)
);

NAND2xp5_ASAP7_75t_L g133 ( 
.A(n_84),
.B(n_6),
.Y(n_133)
);

AND2x4_ASAP7_75t_L g134 ( 
.A(n_100),
.B(n_6),
.Y(n_134)
);

INVx4_ASAP7_75t_L g135 ( 
.A(n_100),
.Y(n_135)
);

NOR2xp33_ASAP7_75t_L g136 ( 
.A(n_103),
.B(n_7),
.Y(n_136)
);

OR2x6_ASAP7_75t_SL g137 ( 
.A(n_92),
.B(n_7),
.Y(n_137)
);

NOR2xp33_ASAP7_75t_L g138 ( 
.A(n_105),
.B(n_8),
.Y(n_138)
);

A2O1A1Ixp33_ASAP7_75t_SL g139 ( 
.A1(n_107),
.A2(n_10),
.B(n_9),
.C(n_8),
.Y(n_139)
);

NAND2xp5_ASAP7_75t_SL g140 ( 
.A(n_90),
.B(n_104),
.Y(n_140)
);

BUFx3_ASAP7_75t_L g141 ( 
.A(n_134),
.Y(n_141)
);

OR2x2_ASAP7_75t_L g142 ( 
.A(n_113),
.B(n_90),
.Y(n_142)
);

AO21x2_ASAP7_75t_L g143 ( 
.A1(n_133),
.A2(n_101),
.B(n_99),
.Y(n_143)
);

AOI22xp33_ASAP7_75t_L g144 ( 
.A1(n_132),
.A2(n_89),
.B1(n_90),
.B2(n_98),
.Y(n_144)
);

INVx1_ASAP7_75t_L g145 ( 
.A(n_115),
.Y(n_145)
);

AOI21xp5_ASAP7_75t_L g146 ( 
.A1(n_140),
.A2(n_128),
.B(n_126),
.Y(n_146)
);

CKINVDCx20_ASAP7_75t_R g147 ( 
.A(n_114),
.Y(n_147)
);

OA21x2_ASAP7_75t_L g148 ( 
.A1(n_123),
.A2(n_109),
.B(n_101),
.Y(n_148)
);

AO21x2_ASAP7_75t_L g149 ( 
.A1(n_131),
.A2(n_109),
.B(n_91),
.Y(n_149)
);

BUFx2_ASAP7_75t_L g150 ( 
.A(n_132),
.Y(n_150)
);

O2A1O1Ixp33_ASAP7_75t_SL g151 ( 
.A1(n_139),
.A2(n_98),
.B(n_89),
.C(n_91),
.Y(n_151)
);

OAI21x1_ASAP7_75t_L g152 ( 
.A1(n_124),
.A2(n_89),
.B(n_85),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_117),
.Y(n_153)
);

NAND2xp5_ASAP7_75t_L g154 ( 
.A(n_112),
.B(n_85),
.Y(n_154)
);

OAI21x1_ASAP7_75t_L g155 ( 
.A1(n_119),
.A2(n_85),
.B(n_9),
.Y(n_155)
);

NOR2x1_ASAP7_75t_SL g156 ( 
.A(n_132),
.B(n_85),
.Y(n_156)
);

OAI21x1_ASAP7_75t_L g157 ( 
.A1(n_130),
.A2(n_12),
.B(n_10),
.Y(n_157)
);

INVx2_ASAP7_75t_SL g158 ( 
.A(n_135),
.Y(n_158)
);

OAI21x1_ASAP7_75t_L g159 ( 
.A1(n_122),
.A2(n_13),
.B(n_12),
.Y(n_159)
);

HB1xp67_ASAP7_75t_L g160 ( 
.A(n_134),
.Y(n_160)
);

NOR2xp33_ASAP7_75t_L g161 ( 
.A(n_110),
.B(n_13),
.Y(n_161)
);

AND2x2_ASAP7_75t_L g162 ( 
.A(n_118),
.B(n_116),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_135),
.Y(n_163)
);

AOI221xp5_ASAP7_75t_L g164 ( 
.A1(n_120),
.A2(n_15),
.B1(n_14),
.B2(n_18),
.C(n_20),
.Y(n_164)
);

BUFx6f_ASAP7_75t_L g165 ( 
.A(n_121),
.Y(n_165)
);

INVx1_ASAP7_75t_L g166 ( 
.A(n_136),
.Y(n_166)
);

INVx4_ASAP7_75t_L g167 ( 
.A(n_136),
.Y(n_167)
);

OAI22xp33_ASAP7_75t_L g168 ( 
.A1(n_166),
.A2(n_127),
.B1(n_120),
.B2(n_125),
.Y(n_168)
);

NOR3xp33_ASAP7_75t_SL g169 ( 
.A(n_161),
.B(n_138),
.C(n_129),
.Y(n_169)
);

INVx1_ASAP7_75t_L g170 ( 
.A(n_145),
.Y(n_170)
);

INVx1_ASAP7_75t_L g171 ( 
.A(n_145),
.Y(n_171)
);

BUFx10_ASAP7_75t_L g172 ( 
.A(n_161),
.Y(n_172)
);

AND2x2_ASAP7_75t_L g173 ( 
.A(n_166),
.B(n_111),
.Y(n_173)
);

NAND2xp5_ASAP7_75t_L g174 ( 
.A(n_162),
.B(n_111),
.Y(n_174)
);

BUFx3_ASAP7_75t_L g175 ( 
.A(n_141),
.Y(n_175)
);

AND2x2_ASAP7_75t_L g176 ( 
.A(n_162),
.B(n_138),
.Y(n_176)
);

INVx2_ASAP7_75t_L g177 ( 
.A(n_153),
.Y(n_177)
);

OR2x6_ASAP7_75t_L g178 ( 
.A(n_150),
.B(n_114),
.Y(n_178)
);

AND2x4_ASAP7_75t_L g179 ( 
.A(n_141),
.B(n_22),
.Y(n_179)
);

BUFx3_ASAP7_75t_L g180 ( 
.A(n_141),
.Y(n_180)
);

INVx1_ASAP7_75t_L g181 ( 
.A(n_153),
.Y(n_181)
);

AND2x2_ASAP7_75t_L g182 ( 
.A(n_162),
.B(n_160),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_148),
.Y(n_183)
);

NAND2xp33_ASAP7_75t_R g184 ( 
.A(n_150),
.B(n_142),
.Y(n_184)
);

OR2x2_ASAP7_75t_L g185 ( 
.A(n_142),
.B(n_14),
.Y(n_185)
);

INVx1_ASAP7_75t_L g186 ( 
.A(n_170),
.Y(n_186)
);

INVx2_ASAP7_75t_L g187 ( 
.A(n_177),
.Y(n_187)
);

AND2x4_ASAP7_75t_L g188 ( 
.A(n_175),
.B(n_156),
.Y(n_188)
);

NAND3xp33_ASAP7_75t_L g189 ( 
.A(n_169),
.B(n_167),
.C(n_164),
.Y(n_189)
);

CKINVDCx5p33_ASAP7_75t_R g190 ( 
.A(n_178),
.Y(n_190)
);

AOI21xp5_ASAP7_75t_L g191 ( 
.A1(n_183),
.A2(n_154),
.B(n_146),
.Y(n_191)
);

OAI21xp33_ASAP7_75t_L g192 ( 
.A1(n_169),
.A2(n_144),
.B(n_142),
.Y(n_192)
);

AND2x2_ASAP7_75t_L g193 ( 
.A(n_176),
.B(n_144),
.Y(n_193)
);

HB1xp67_ASAP7_75t_L g194 ( 
.A(n_185),
.Y(n_194)
);

NAND3xp33_ASAP7_75t_SL g195 ( 
.A(n_176),
.B(n_164),
.C(n_167),
.Y(n_195)
);

INVx1_ASAP7_75t_L g196 ( 
.A(n_170),
.Y(n_196)
);

INVx2_ASAP7_75t_SL g197 ( 
.A(n_179),
.Y(n_197)
);

AOI22xp33_ASAP7_75t_L g198 ( 
.A1(n_168),
.A2(n_167),
.B1(n_160),
.B2(n_163),
.Y(n_198)
);

INVx2_ASAP7_75t_L g199 ( 
.A(n_177),
.Y(n_199)
);

INVx2_ASAP7_75t_L g200 ( 
.A(n_187),
.Y(n_200)
);

AND2x2_ASAP7_75t_L g201 ( 
.A(n_193),
.B(n_176),
.Y(n_201)
);

AND2x2_ASAP7_75t_L g202 ( 
.A(n_193),
.B(n_182),
.Y(n_202)
);

AND2x2_ASAP7_75t_L g203 ( 
.A(n_192),
.B(n_182),
.Y(n_203)
);

AND2x2_ASAP7_75t_L g204 ( 
.A(n_192),
.B(n_182),
.Y(n_204)
);

INVx1_ASAP7_75t_L g205 ( 
.A(n_186),
.Y(n_205)
);

AND2x4_ASAP7_75t_L g206 ( 
.A(n_197),
.B(n_175),
.Y(n_206)
);

INVx2_ASAP7_75t_SL g207 ( 
.A(n_188),
.Y(n_207)
);

BUFx2_ASAP7_75t_L g208 ( 
.A(n_194),
.Y(n_208)
);

INVx2_ASAP7_75t_L g209 ( 
.A(n_187),
.Y(n_209)
);

AND2x2_ASAP7_75t_L g210 ( 
.A(n_187),
.B(n_171),
.Y(n_210)
);

INVx1_ASAP7_75t_L g211 ( 
.A(n_186),
.Y(n_211)
);

INVx1_ASAP7_75t_L g212 ( 
.A(n_196),
.Y(n_212)
);

INVx2_ASAP7_75t_L g213 ( 
.A(n_199),
.Y(n_213)
);

AND2x2_ASAP7_75t_L g214 ( 
.A(n_199),
.B(n_174),
.Y(n_214)
);

AND2x2_ASAP7_75t_L g215 ( 
.A(n_199),
.B(n_171),
.Y(n_215)
);

INVx2_ASAP7_75t_SL g216 ( 
.A(n_208),
.Y(n_216)
);

INVx1_ASAP7_75t_SL g217 ( 
.A(n_208),
.Y(n_217)
);

AND2x2_ASAP7_75t_L g218 ( 
.A(n_202),
.B(n_196),
.Y(n_218)
);

INVxp67_ASAP7_75t_L g219 ( 
.A(n_214),
.Y(n_219)
);

AND2x2_ASAP7_75t_L g220 ( 
.A(n_202),
.B(n_143),
.Y(n_220)
);

INVx2_ASAP7_75t_L g221 ( 
.A(n_200),
.Y(n_221)
);

AND2x4_ASAP7_75t_L g222 ( 
.A(n_207),
.B(n_197),
.Y(n_222)
);

AOI22xp5_ASAP7_75t_L g223 ( 
.A1(n_201),
.A2(n_168),
.B1(n_184),
.B2(n_189),
.Y(n_223)
);

INVx1_ASAP7_75t_L g224 ( 
.A(n_205),
.Y(n_224)
);

INVx1_ASAP7_75t_L g225 ( 
.A(n_205),
.Y(n_225)
);

NAND2xp5_ASAP7_75t_L g226 ( 
.A(n_201),
.B(n_174),
.Y(n_226)
);

NOR2x1_ASAP7_75t_L g227 ( 
.A(n_203),
.B(n_189),
.Y(n_227)
);

OR2x6_ASAP7_75t_L g228 ( 
.A(n_207),
.B(n_197),
.Y(n_228)
);

NAND2xp5_ASAP7_75t_L g229 ( 
.A(n_201),
.B(n_173),
.Y(n_229)
);

INVx4_ASAP7_75t_L g230 ( 
.A(n_206),
.Y(n_230)
);

OR2x2_ASAP7_75t_L g231 ( 
.A(n_202),
.B(n_185),
.Y(n_231)
);

OR2x6_ASAP7_75t_L g232 ( 
.A(n_207),
.B(n_188),
.Y(n_232)
);

OAI211xp5_ASAP7_75t_SL g233 ( 
.A1(n_211),
.A2(n_198),
.B(n_151),
.C(n_137),
.Y(n_233)
);

INVx1_ASAP7_75t_L g234 ( 
.A(n_211),
.Y(n_234)
);

AND2x2_ASAP7_75t_L g235 ( 
.A(n_203),
.B(n_143),
.Y(n_235)
);

NOR4xp75_ASAP7_75t_L g236 ( 
.A(n_204),
.B(n_195),
.C(n_173),
.D(n_154),
.Y(n_236)
);

INVx2_ASAP7_75t_L g237 ( 
.A(n_200),
.Y(n_237)
);

HB1xp67_ASAP7_75t_L g238 ( 
.A(n_214),
.Y(n_238)
);

AOI221x1_ASAP7_75t_L g239 ( 
.A1(n_233),
.A2(n_195),
.B1(n_191),
.B2(n_204),
.C(n_212),
.Y(n_239)
);

HB1xp67_ASAP7_75t_L g240 ( 
.A(n_216),
.Y(n_240)
);

NAND2xp5_ASAP7_75t_SL g241 ( 
.A(n_223),
.B(n_172),
.Y(n_241)
);

INVx1_ASAP7_75t_L g242 ( 
.A(n_224),
.Y(n_242)
);

OAI31xp33_ASAP7_75t_L g243 ( 
.A1(n_217),
.A2(n_173),
.A3(n_180),
.B(n_175),
.Y(n_243)
);

OAI32xp33_ASAP7_75t_L g244 ( 
.A1(n_231),
.A2(n_167),
.A3(n_212),
.B1(n_172),
.B2(n_190),
.Y(n_244)
);

INVx2_ASAP7_75t_L g245 ( 
.A(n_224),
.Y(n_245)
);

INVx2_ASAP7_75t_SL g246 ( 
.A(n_216),
.Y(n_246)
);

INVx1_ASAP7_75t_L g247 ( 
.A(n_225),
.Y(n_247)
);

OAI22xp5_ASAP7_75t_L g248 ( 
.A1(n_229),
.A2(n_167),
.B1(n_178),
.B2(n_180),
.Y(n_248)
);

INVxp67_ASAP7_75t_L g249 ( 
.A(n_238),
.Y(n_249)
);

AOI221xp5_ASAP7_75t_L g250 ( 
.A1(n_226),
.A2(n_151),
.B1(n_165),
.B2(n_181),
.C(n_146),
.Y(n_250)
);

AOI21xp5_ASAP7_75t_L g251 ( 
.A1(n_228),
.A2(n_191),
.B(n_156),
.Y(n_251)
);

NOR2xp33_ASAP7_75t_L g252 ( 
.A(n_231),
.B(n_147),
.Y(n_252)
);

INVx1_ASAP7_75t_L g253 ( 
.A(n_225),
.Y(n_253)
);

O2A1O1Ixp33_ASAP7_75t_L g254 ( 
.A1(n_227),
.A2(n_178),
.B(n_180),
.C(n_179),
.Y(n_254)
);

INVx1_ASAP7_75t_L g255 ( 
.A(n_234),
.Y(n_255)
);

INVx1_ASAP7_75t_L g256 ( 
.A(n_234),
.Y(n_256)
);

NAND2xp5_ASAP7_75t_L g257 ( 
.A(n_218),
.B(n_215),
.Y(n_257)
);

INVx2_ASAP7_75t_L g258 ( 
.A(n_221),
.Y(n_258)
);

AOI22xp5_ASAP7_75t_L g259 ( 
.A1(n_227),
.A2(n_172),
.B1(n_178),
.B2(n_147),
.Y(n_259)
);

NOR2x1_ASAP7_75t_SL g260 ( 
.A(n_228),
.B(n_143),
.Y(n_260)
);

INVx1_ASAP7_75t_L g261 ( 
.A(n_221),
.Y(n_261)
);

INVx1_ASAP7_75t_L g262 ( 
.A(n_237),
.Y(n_262)
);

OAI21xp5_ASAP7_75t_L g263 ( 
.A1(n_222),
.A2(n_152),
.B(n_155),
.Y(n_263)
);

O2A1O1Ixp33_ASAP7_75t_L g264 ( 
.A1(n_228),
.A2(n_178),
.B(n_179),
.C(n_163),
.Y(n_264)
);

INVx1_ASAP7_75t_L g265 ( 
.A(n_237),
.Y(n_265)
);

INVx2_ASAP7_75t_L g266 ( 
.A(n_235),
.Y(n_266)
);

INVx1_ASAP7_75t_L g267 ( 
.A(n_245),
.Y(n_267)
);

OAI21xp5_ASAP7_75t_L g268 ( 
.A1(n_241),
.A2(n_239),
.B(n_254),
.Y(n_268)
);

NAND2xp5_ASAP7_75t_L g269 ( 
.A(n_249),
.B(n_218),
.Y(n_269)
);

INVx1_ASAP7_75t_L g270 ( 
.A(n_242),
.Y(n_270)
);

NAND2xp5_ASAP7_75t_L g271 ( 
.A(n_240),
.B(n_219),
.Y(n_271)
);

NOR2xp33_ASAP7_75t_L g272 ( 
.A(n_252),
.B(n_165),
.Y(n_272)
);

INVx1_ASAP7_75t_L g273 ( 
.A(n_247),
.Y(n_273)
);

NAND2xp5_ASAP7_75t_L g274 ( 
.A(n_246),
.B(n_220),
.Y(n_274)
);

NAND3xp33_ASAP7_75t_L g275 ( 
.A(n_239),
.B(n_235),
.C(n_220),
.Y(n_275)
);

AND2x2_ASAP7_75t_L g276 ( 
.A(n_266),
.B(n_230),
.Y(n_276)
);

NAND2xp5_ASAP7_75t_L g277 ( 
.A(n_246),
.B(n_230),
.Y(n_277)
);

AND2x2_ASAP7_75t_L g278 ( 
.A(n_266),
.B(n_230),
.Y(n_278)
);

AND2x2_ASAP7_75t_L g279 ( 
.A(n_245),
.B(n_159),
.Y(n_279)
);

OR2x2_ASAP7_75t_L g280 ( 
.A(n_253),
.B(n_159),
.Y(n_280)
);

NAND2xp5_ASAP7_75t_L g281 ( 
.A(n_257),
.B(n_222),
.Y(n_281)
);

AND2x2_ASAP7_75t_L g282 ( 
.A(n_255),
.B(n_159),
.Y(n_282)
);

NAND2xp5_ASAP7_75t_SL g283 ( 
.A(n_259),
.B(n_172),
.Y(n_283)
);

NAND2xp5_ASAP7_75t_L g284 ( 
.A(n_256),
.B(n_222),
.Y(n_284)
);

INVx1_ASAP7_75t_L g285 ( 
.A(n_262),
.Y(n_285)
);

BUFx12f_ASAP7_75t_L g286 ( 
.A(n_264),
.Y(n_286)
);

INVx1_ASAP7_75t_L g287 ( 
.A(n_262),
.Y(n_287)
);

INVx1_ASAP7_75t_L g288 ( 
.A(n_265),
.Y(n_288)
);

OR2x2_ASAP7_75t_L g289 ( 
.A(n_265),
.B(n_228),
.Y(n_289)
);

HB1xp67_ASAP7_75t_L g290 ( 
.A(n_261),
.Y(n_290)
);

NOR3x1_ASAP7_75t_L g291 ( 
.A(n_241),
.B(n_157),
.C(n_152),
.Y(n_291)
);

NAND2xp5_ASAP7_75t_L g292 ( 
.A(n_258),
.B(n_210),
.Y(n_292)
);

NAND2xp5_ASAP7_75t_L g293 ( 
.A(n_258),
.B(n_210),
.Y(n_293)
);

INVxp67_ASAP7_75t_L g294 ( 
.A(n_260),
.Y(n_294)
);

AOI311xp33_ASAP7_75t_L g295 ( 
.A1(n_268),
.A2(n_248),
.A3(n_250),
.B(n_263),
.C(n_251),
.Y(n_295)
);

INVx1_ASAP7_75t_L g296 ( 
.A(n_270),
.Y(n_296)
);

NAND3xp33_ASAP7_75t_SL g297 ( 
.A(n_272),
.B(n_236),
.C(n_243),
.Y(n_297)
);

OAI321xp33_ASAP7_75t_L g298 ( 
.A1(n_294),
.A2(n_178),
.A3(n_236),
.B1(n_232),
.B2(n_165),
.C(n_260),
.Y(n_298)
);

AOI21xp33_ASAP7_75t_L g299 ( 
.A1(n_286),
.A2(n_244),
.B(n_157),
.Y(n_299)
);

A2O1A1Ixp33_ASAP7_75t_L g300 ( 
.A1(n_283),
.A2(n_244),
.B(n_157),
.C(n_155),
.Y(n_300)
);

NAND3xp33_ASAP7_75t_L g301 ( 
.A(n_275),
.B(n_232),
.C(n_165),
.Y(n_301)
);

AOI22xp5_ASAP7_75t_L g302 ( 
.A1(n_286),
.A2(n_271),
.B1(n_269),
.B2(n_232),
.Y(n_302)
);

NOR2xp33_ASAP7_75t_R g303 ( 
.A(n_277),
.B(n_165),
.Y(n_303)
);

NAND4xp25_ASAP7_75t_L g304 ( 
.A(n_284),
.B(n_179),
.C(n_210),
.D(n_215),
.Y(n_304)
);

OAI211xp5_ASAP7_75t_L g305 ( 
.A1(n_270),
.A2(n_165),
.B(n_155),
.C(n_152),
.Y(n_305)
);

AOI321xp33_ASAP7_75t_L g306 ( 
.A1(n_274),
.A2(n_181),
.A3(n_206),
.B1(n_177),
.B2(n_215),
.C(n_188),
.Y(n_306)
);

AOI211xp5_ASAP7_75t_L g307 ( 
.A1(n_273),
.A2(n_165),
.B(n_206),
.C(n_188),
.Y(n_307)
);

OAI211xp5_ASAP7_75t_L g308 ( 
.A1(n_273),
.A2(n_213),
.B(n_209),
.C(n_200),
.Y(n_308)
);

O2A1O1Ixp5_ASAP7_75t_L g309 ( 
.A1(n_285),
.A2(n_206),
.B(n_213),
.C(n_209),
.Y(n_309)
);

NAND2xp5_ASAP7_75t_L g310 ( 
.A(n_281),
.B(n_232),
.Y(n_310)
);

AOI221xp5_ASAP7_75t_L g311 ( 
.A1(n_285),
.A2(n_288),
.B1(n_287),
.B2(n_267),
.C(n_282),
.Y(n_311)
);

NAND4xp25_ASAP7_75t_SL g312 ( 
.A(n_276),
.B(n_213),
.C(n_209),
.D(n_183),
.Y(n_312)
);

AOI211xp5_ASAP7_75t_SL g313 ( 
.A1(n_289),
.A2(n_143),
.B(n_149),
.C(n_148),
.Y(n_313)
);

O2A1O1Ixp5_ASAP7_75t_SL g314 ( 
.A1(n_288),
.A2(n_290),
.B(n_293),
.C(n_292),
.Y(n_314)
);

AOI221xp5_ASAP7_75t_L g315 ( 
.A1(n_282),
.A2(n_149),
.B1(n_158),
.B2(n_25),
.C(n_29),
.Y(n_315)
);

NAND4xp75_ASAP7_75t_L g316 ( 
.A(n_302),
.B(n_291),
.C(n_278),
.D(n_276),
.Y(n_316)
);

INVx1_ASAP7_75t_L g317 ( 
.A(n_296),
.Y(n_317)
);

BUFx2_ASAP7_75t_L g318 ( 
.A(n_303),
.Y(n_318)
);

AOI221xp5_ASAP7_75t_L g319 ( 
.A1(n_311),
.A2(n_278),
.B1(n_279),
.B2(n_289),
.C(n_280),
.Y(n_319)
);

OR2x2_ASAP7_75t_L g320 ( 
.A(n_310),
.B(n_280),
.Y(n_320)
);

INVx1_ASAP7_75t_L g321 ( 
.A(n_309),
.Y(n_321)
);

NAND2xp5_ASAP7_75t_L g322 ( 
.A(n_314),
.B(n_313),
.Y(n_322)
);

AOI222xp33_ASAP7_75t_L g323 ( 
.A1(n_297),
.A2(n_279),
.B1(n_35),
.B2(n_30),
.C1(n_36),
.C2(n_31),
.Y(n_323)
);

AOI22xp5_ASAP7_75t_L g324 ( 
.A1(n_297),
.A2(n_304),
.B1(n_301),
.B2(n_315),
.Y(n_324)
);

OAI21xp5_ASAP7_75t_L g325 ( 
.A1(n_298),
.A2(n_148),
.B(n_158),
.Y(n_325)
);

OR2x2_ASAP7_75t_L g326 ( 
.A(n_312),
.B(n_308),
.Y(n_326)
);

NAND2xp5_ASAP7_75t_L g327 ( 
.A(n_300),
.B(n_149),
.Y(n_327)
);

INVx2_ASAP7_75t_L g328 ( 
.A(n_295),
.Y(n_328)
);

NOR2x1_ASAP7_75t_L g329 ( 
.A(n_316),
.B(n_305),
.Y(n_329)
);

CKINVDCx5p33_ASAP7_75t_R g330 ( 
.A(n_328),
.Y(n_330)
);

HB1xp67_ASAP7_75t_L g331 ( 
.A(n_321),
.Y(n_331)
);

XNOR2xp5_ASAP7_75t_L g332 ( 
.A(n_324),
.B(n_307),
.Y(n_332)
);

CKINVDCx5p33_ASAP7_75t_R g333 ( 
.A(n_318),
.Y(n_333)
);

NOR2xp67_ASAP7_75t_L g334 ( 
.A(n_317),
.B(n_320),
.Y(n_334)
);

NOR2xp33_ASAP7_75t_R g335 ( 
.A(n_326),
.B(n_322),
.Y(n_335)
);

BUFx2_ASAP7_75t_L g336 ( 
.A(n_319),
.Y(n_336)
);

INVx1_ASAP7_75t_L g337 ( 
.A(n_331),
.Y(n_337)
);

INVx2_ASAP7_75t_L g338 ( 
.A(n_333),
.Y(n_338)
);

NOR2x1_ASAP7_75t_L g339 ( 
.A(n_329),
.B(n_327),
.Y(n_339)
);

AOI22xp33_ASAP7_75t_L g340 ( 
.A1(n_336),
.A2(n_323),
.B1(n_299),
.B2(n_325),
.Y(n_340)
);

INVx1_ASAP7_75t_L g341 ( 
.A(n_330),
.Y(n_341)
);

INVx1_ASAP7_75t_L g342 ( 
.A(n_337),
.Y(n_342)
);

NAND2xp5_ASAP7_75t_L g343 ( 
.A(n_339),
.B(n_335),
.Y(n_343)
);

OA22x2_ASAP7_75t_L g344 ( 
.A1(n_341),
.A2(n_332),
.B1(n_335),
.B2(n_334),
.Y(n_344)
);

NAND2xp5_ASAP7_75t_SL g345 ( 
.A(n_343),
.B(n_338),
.Y(n_345)
);

OAI322xp33_ASAP7_75t_L g346 ( 
.A1(n_344),
.A2(n_340),
.A3(n_323),
.B1(n_306),
.B2(n_325),
.C1(n_158),
.C2(n_39),
.Y(n_346)
);

AOI22xp5_ASAP7_75t_SL g347 ( 
.A1(n_346),
.A2(n_342),
.B1(n_340),
.B2(n_148),
.Y(n_347)
);

AOI22xp33_ASAP7_75t_L g348 ( 
.A1(n_347),
.A2(n_345),
.B1(n_149),
.B2(n_148),
.Y(n_348)
);


endmodule