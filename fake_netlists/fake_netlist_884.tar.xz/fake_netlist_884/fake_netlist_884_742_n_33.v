module fake_netlist_884_742_n_33 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_33);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_33;

wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_31;
wire n_21;
wire n_25;
wire n_22;
wire n_32;
wire n_26;
wire n_29;

INVx1_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_6),
.B(n_4),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_9),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_18),
.A2(n_21),
.B(n_22),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_19),
.B(n_20),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_1),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_2),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_3),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_27),
.B1(n_7),
.B2(n_5),
.Y(n_29)
);

OAI211xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_11),
.B(n_10),
.C(n_8),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_33)
);


endmodule