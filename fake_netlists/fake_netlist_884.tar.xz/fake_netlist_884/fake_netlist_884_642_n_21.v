module fake_netlist_884_642_n_21 (n_0, n_2, n_5, n_3, n_4, n_1, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_21;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_SL g7 ( 
.A(n_3),
.B(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

OR2x6_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_1),
.Y(n_9)
);

INVxp33_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_6),
.Y(n_11)
);

AO21x2_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B1(n_9),
.B2(n_6),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI321xp33_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_7),
.A3(n_12),
.B1(n_5),
.B2(n_4),
.C(n_0),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_13),
.C(n_9),
.Y(n_18)
);

AOI322xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_6),
.A3(n_9),
.B1(n_5),
.B2(n_4),
.C1(n_12),
.C2(n_2),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_14),
.B(n_12),
.C(n_9),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_6),
.B1(n_14),
.B2(n_18),
.Y(n_21)
);


endmodule