module fake_netlist_884_321_n_25 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_25;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_22;
wire n_14;

BUFx8_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_6),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_17),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_15),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_14),
.Y(n_22)
);

OAI22x1_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_11),
.B1(n_9),
.B2(n_14),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_24)
);

AOI222xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_7),
.B1(n_5),
.B2(n_8),
.C1(n_13),
.C2(n_12),
.Y(n_25)
);


endmodule