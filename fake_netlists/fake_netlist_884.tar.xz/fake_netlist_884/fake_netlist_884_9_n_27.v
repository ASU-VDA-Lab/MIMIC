module fake_netlist_884_9_n_27 (n_0, n_2, n_5, n_3, n_4, n_1, n_27);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_27;

wire n_15;
wire n_11;
wire n_24;
wire n_6;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;
wire n_8;

INVx1_ASAP7_75t_SL g6 ( 
.A(n_4),
.Y(n_6)
);

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_3),
.A2(n_0),
.B1(n_5),
.B2(n_1),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_2),
.B(n_1),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_9),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_14),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_15),
.B(n_14),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

AOI311xp33_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_13),
.A3(n_17),
.B(n_10),
.C(n_15),
.Y(n_22)
);

AOI322xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_10),
.A3(n_6),
.B1(n_15),
.B2(n_11),
.C1(n_16),
.C2(n_17),
.Y(n_23)
);

NAND5xp2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_6),
.C(n_15),
.D(n_9),
.E(n_2),
.Y(n_24)
);

OAI211xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_8),
.B(n_5),
.C(n_4),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_21),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);


endmodule