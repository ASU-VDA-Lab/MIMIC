module fake_netlist_884_1553_n_20 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_20);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_20;

wire n_15;
wire n_16;
wire n_19;
wire n_12;
wire n_17;
wire n_18;
wire n_13;
wire n_14;

AND2x2_ASAP7_75t_L g12 ( 
.A(n_1),
.B(n_7),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_SL g13 ( 
.A1(n_0),
.A2(n_9),
.B1(n_8),
.B2(n_6),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

AO21x2_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_5),
.B(n_4),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B1(n_14),
.B2(n_4),
.Y(n_16)
);

AOI221x1_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_14),
.B1(n_15),
.B2(n_13),
.C(n_2),
.Y(n_17)
);

OAI211xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B(n_6),
.C(n_5),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_11),
.B2(n_3),
.Y(n_20)
);


endmodule