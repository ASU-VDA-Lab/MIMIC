module fake_netlist_884_289_n_41 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_41);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_41;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_22;
wire n_25;
wire n_21;
wire n_35;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

INVx1_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_3),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_1),
.Y(n_26)
);

AND3x2_ASAP7_75t_L g27 ( 
.A(n_0),
.B(n_16),
.C(n_1),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_22),
.B(n_16),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_17),
.Y(n_29)
);

A2O1A1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_23),
.A2(n_19),
.B(n_18),
.C(n_17),
.Y(n_30)
);

A2O1A1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_23),
.B(n_24),
.C(n_20),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_27),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_31),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_26),
.B2(n_30),
.C(n_23),
.Y(n_34)
);

AOI32xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_24),
.A3(n_25),
.B1(n_21),
.B2(n_18),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_19),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_35),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_R g39 ( 
.A1(n_38),
.A2(n_8),
.B1(n_5),
.B2(n_2),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_12),
.B1(n_14),
.B2(n_15),
.C1(n_37),
.C2(n_39),
.Y(n_41)
);


endmodule