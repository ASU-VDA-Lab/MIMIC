module fake_netlist_884_1548_n_11 (n_0, n_1, n_11);

input n_0;
input n_1;

output n_11;

wire n_5;
wire n_2;
wire n_3;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

OR2x6_ASAP7_75t_L g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

A2O1A1Ixp33_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_0),
.B(n_1),
.C(n_2),
.Y(n_4)
);

NOR2x1_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_0),
.Y(n_7)
);

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_0),
.B1(n_1),
.B2(n_7),
.Y(n_8)
);

NAND4xp25_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_7),
.C(n_0),
.D(n_1),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_0),
.B1(n_1),
.B2(n_8),
.Y(n_10)
);

AOI222xp33_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_0),
.B1(n_1),
.B2(n_6),
.C1(n_9),
.C2(n_8),
.Y(n_11)
);


endmodule