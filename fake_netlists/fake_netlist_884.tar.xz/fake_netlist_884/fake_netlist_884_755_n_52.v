module fake_netlist_884_755_n_52 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_52);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_52;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_35;
wire n_41;
wire n_22;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

INVx2_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_4),
.B(n_8),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_17),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_15),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_16),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_19),
.B(n_16),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

BUFx3_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_26),
.Y(n_31)
);

INVx3_ASAP7_75t_SL g32 ( 
.A(n_29),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

INVxp67_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_24),
.Y(n_39)
);

INVxp33_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_23),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_22),
.B(n_18),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_40),
.B1(n_20),
.B2(n_18),
.C(n_28),
.Y(n_46)
);

NOR4xp25_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_28),
.C(n_17),
.D(n_0),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

NOR3xp33_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_2),
.C(n_1),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_10),
.B1(n_7),
.B2(n_5),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_14),
.B1(n_49),
.B2(n_50),
.Y(n_52)
);


endmodule