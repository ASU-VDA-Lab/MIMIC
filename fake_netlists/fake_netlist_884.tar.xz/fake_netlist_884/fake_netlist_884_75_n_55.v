module fake_netlist_884_75_n_55 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_55);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_55;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_19;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_42;
wire n_41;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_45;
wire n_44;
wire n_48;
wire n_38;

INVx1_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_4),
.B(n_12),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_1),
.B(n_12),
.Y(n_24)
);

NAND2x1p5_ASAP7_75t_L g25 ( 
.A(n_13),
.B(n_14),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_13),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_24),
.B(n_1),
.Y(n_29)
);

OR2x2_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_14),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_24),
.A2(n_17),
.B1(n_15),
.B2(n_0),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_17),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

BUFx4f_ASAP7_75t_SL g35 ( 
.A(n_28),
.Y(n_35)
);

NAND2xp33_ASAP7_75t_R g36 ( 
.A(n_30),
.B(n_23),
.Y(n_36)
);

CKINVDCx16_ASAP7_75t_R g37 ( 
.A(n_33),
.Y(n_37)
);

OAI211xp5_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_32),
.B(n_29),
.C(n_20),
.Y(n_38)
);

AOI222xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_32),
.B1(n_20),
.B2(n_27),
.C1(n_31),
.C2(n_22),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_18),
.C(n_19),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_34),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_25),
.Y(n_42)
);

NAND2xp33_ASAP7_75t_SL g43 ( 
.A(n_38),
.B(n_35),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_2),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

BUFx6f_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_44),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_SL g50 ( 
.A(n_47),
.B(n_9),
.Y(n_50)
);

AND2x4_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_11),
.Y(n_51)
);

INVxp67_ASAP7_75t_SL g52 ( 
.A(n_50),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

AOI22xp5_ASAP7_75t_SL g55 ( 
.A1(n_53),
.A2(n_54),
.B1(n_52),
.B2(n_44),
.Y(n_55)
);


endmodule