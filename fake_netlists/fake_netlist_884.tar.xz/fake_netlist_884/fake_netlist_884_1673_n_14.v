module fake_netlist_884_1673_n_14 (n_0, n_2, n_3, n_4, n_1, n_14);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_14;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

AND2x6_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_3),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

AO32x2_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_2),
.A3(n_1),
.B1(n_0),
.B2(n_4),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_SL g8 ( 
.A1(n_6),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_5),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.Y(n_11)
);

NOR2x1_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_5),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_5),
.B(n_2),
.Y(n_13)
);

AO21x2_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B(n_10),
.Y(n_14)
);


endmodule