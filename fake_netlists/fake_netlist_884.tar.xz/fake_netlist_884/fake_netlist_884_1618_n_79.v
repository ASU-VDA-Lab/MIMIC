module fake_netlist_884_1618_n_79 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_79);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_79;

wire n_60;
wire n_52;
wire n_30;
wire n_23;
wire n_64;
wire n_66;
wire n_65;
wire n_27;
wire n_20;
wire n_71;
wire n_29;
wire n_69;
wire n_51;
wire n_50;
wire n_55;
wire n_46;
wire n_54;
wire n_28;
wire n_19;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_62;
wire n_26;
wire n_44;
wire n_33;
wire n_24;
wire n_77;
wire n_53;
wire n_61;
wire n_21;
wire n_22;
wire n_43;
wire n_48;
wire n_72;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_34;
wire n_37;
wire n_75;
wire n_47;
wire n_68;
wire n_63;
wire n_49;
wire n_58;
wire n_67;
wire n_25;
wire n_35;
wire n_57;
wire n_36;
wire n_45;
wire n_73;
wire n_78;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_5),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_11),
.B(n_4),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_3),
.B(n_5),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_14),
.B(n_18),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_9),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_2),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_17),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_SL g33 ( 
.A(n_19),
.B(n_1),
.C(n_0),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_24),
.B(n_0),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_1),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_30),
.A2(n_10),
.B(n_7),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_24),
.B(n_2),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_28),
.B(n_17),
.Y(n_39)
);

BUFx12f_ASAP7_75t_L g40 ( 
.A(n_19),
.Y(n_40)
);

CKINVDCx8_ASAP7_75t_R g41 ( 
.A(n_25),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_21),
.B(n_18),
.Y(n_42)
);

NAND2xp33_ASAP7_75t_R g43 ( 
.A(n_27),
.B(n_25),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_31),
.B1(n_28),
.B2(n_20),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_26),
.B1(n_31),
.B2(n_21),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_39),
.A2(n_20),
.B1(n_29),
.B2(n_23),
.Y(n_46)
);

BUFx12f_ASAP7_75t_L g47 ( 
.A(n_40),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_35),
.B(n_23),
.Y(n_48)
);

OAI21x1_ASAP7_75t_L g49 ( 
.A1(n_38),
.A2(n_22),
.B(n_23),
.Y(n_49)
);

BUFx2_ASAP7_75t_L g50 ( 
.A(n_40),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_SL g51 ( 
.A1(n_39),
.A2(n_23),
.B1(n_29),
.B2(n_36),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_41),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_44),
.B(n_34),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_49),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_34),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_45),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

INVx1_ASAP7_75t_SL g59 ( 
.A(n_56),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_54),
.B(n_51),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_54),
.B(n_46),
.Y(n_61)
);

NOR2xp33_ASAP7_75t_L g62 ( 
.A(n_59),
.B(n_53),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_SL g63 ( 
.A(n_59),
.B(n_47),
.Y(n_63)
);

NOR2xp33_ASAP7_75t_R g64 ( 
.A(n_57),
.B(n_47),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_58),
.Y(n_65)
);

AND2x2_ASAP7_75t_L g66 ( 
.A(n_60),
.B(n_33),
.Y(n_66)
);

AND2x2_ASAP7_75t_L g67 ( 
.A(n_66),
.B(n_61),
.Y(n_67)
);

AOI22x1_ASAP7_75t_L g68 ( 
.A1(n_65),
.A2(n_55),
.B1(n_37),
.B2(n_49),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_62),
.Y(n_69)
);

AOI22xp33_ASAP7_75t_L g70 ( 
.A1(n_64),
.A2(n_42),
.B1(n_29),
.B2(n_43),
.Y(n_70)
);

NOR3xp33_ASAP7_75t_L g71 ( 
.A(n_63),
.B(n_64),
.C(n_29),
.Y(n_71)
);

INVx3_ASAP7_75t_SL g72 ( 
.A(n_67),
.Y(n_72)
);

AND2x4_ASAP7_75t_L g73 ( 
.A(n_67),
.B(n_71),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_69),
.Y(n_74)
);

AOI21xp33_ASAP7_75t_L g75 ( 
.A1(n_70),
.A2(n_69),
.B(n_66),
.Y(n_75)
);

CKINVDCx5p33_ASAP7_75t_R g76 ( 
.A(n_68),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_74),
.Y(n_77)
);

NOR2x1_ASAP7_75t_L g78 ( 
.A(n_73),
.B(n_72),
.Y(n_78)
);

AOI22xp5_ASAP7_75t_SL g79 ( 
.A1(n_77),
.A2(n_75),
.B1(n_76),
.B2(n_78),
.Y(n_79)
);


endmodule