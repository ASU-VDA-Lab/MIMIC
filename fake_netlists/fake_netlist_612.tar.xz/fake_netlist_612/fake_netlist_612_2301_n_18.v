module fake_netlist_612_2301_n_18 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_18);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_18;

wire n_11;
wire n_15;
wire n_10;
wire n_16;
wire n_14;
wire n_17;
wire n_13;
wire n_12;

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_0),
.B(n_6),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_4),
.Y(n_13)
);

O2A1O1Ixp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_11),
.C(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B1(n_7),
.B2(n_2),
.C(n_5),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_10),
.B1(n_7),
.B2(n_5),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_10),
.B1(n_9),
.B2(n_3),
.C(n_8),
.Y(n_18)
);


endmodule