module fake_netlist_612_1997_n_46 (n_11, n_8, n_15, n_3, n_21, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_46);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_46;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_43;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;

XOR2xp5_ASAP7_75t_L g22 ( 
.A(n_5),
.B(n_3),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_0),
.Y(n_24)
);

BUFx10_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_14),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_17),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_9),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_7),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_15),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_21),
.B1(n_19),
.B2(n_18),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_23),
.A2(n_2),
.B(n_1),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_33),
.B(n_24),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_25),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_25),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_31),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_35),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_29),
.B1(n_22),
.B2(n_26),
.C(n_28),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_19),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_30),
.B1(n_6),
.B2(n_4),
.Y(n_44)
);

OAI22x1_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_11),
.B1(n_10),
.B2(n_8),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_13),
.B1(n_20),
.B2(n_45),
.Y(n_46)
);


endmodule