module fake_netlist_612_1505_n_25 (n_5, n_0, n_4, n_1, n_2, n_3, n_25);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_25;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_7;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

OR2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_5),
.Y(n_7)
);

NAND2xp33_ASAP7_75t_SL g8 ( 
.A(n_1),
.B(n_0),
.Y(n_8)
);

AND2x6_ASAP7_75t_SL g9 ( 
.A(n_4),
.B(n_5),
.Y(n_9)
);

AOI21x1_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_6),
.B(n_8),
.Y(n_10)
);

AO31x2_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_SL g12 ( 
.A1(n_7),
.A2(n_9),
.B(n_1),
.C(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_SL g13 ( 
.A(n_11),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_7),
.B1(n_12),
.B2(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

OAI22xp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_7),
.B1(n_11),
.B2(n_2),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_13),
.B(n_15),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_13),
.B(n_15),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_13),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_3),
.B1(n_4),
.B2(n_19),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_3),
.Y(n_24)
);

AOI21xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_22),
.B(n_23),
.Y(n_25)
);


endmodule