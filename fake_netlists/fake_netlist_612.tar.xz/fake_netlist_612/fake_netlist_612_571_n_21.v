module fake_netlist_612_571_n_21 (n_5, n_0, n_4, n_1, n_2, n_3, n_21);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_21;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_7;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_5),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_4),
.B(n_5),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_8),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_11),
.B1(n_3),
.B2(n_2),
.Y(n_16)
);

XNOR2x1_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_2),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_4),
.B1(n_11),
.B2(n_16),
.C(n_13),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_11),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

OAI21x1_ASAP7_75t_SL g21 ( 
.A1(n_19),
.A2(n_11),
.B(n_20),
.Y(n_21)
);


endmodule