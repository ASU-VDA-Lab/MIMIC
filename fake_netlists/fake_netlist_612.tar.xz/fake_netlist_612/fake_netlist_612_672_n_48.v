module fake_netlist_612_672_n_48 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_48);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_48;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_36;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_42;
wire n_33;
wire n_41;

INVx1_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_20),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_5),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_4),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_7),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_13),
.B(n_21),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_22),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_24),
.B1(n_1),
.B2(n_0),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_25),
.B(n_2),
.Y(n_34)
);

AO32x2_ASAP7_75t_L g35 ( 
.A1(n_28),
.A2(n_6),
.A3(n_3),
.B1(n_8),
.B2(n_9),
.Y(n_35)
);

CKINVDCx16_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

XNOR2x1_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_26),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

A2O1A1Ixp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_35),
.B(n_30),
.C(n_27),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_SL g43 ( 
.A1(n_40),
.A2(n_31),
.B(n_32),
.C(n_10),
.Y(n_43)
);

INVx1_ASAP7_75t_SL g44 ( 
.A(n_43),
.Y(n_44)
);

BUFx6f_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_SL g46 ( 
.A1(n_45),
.A2(n_14),
.B1(n_12),
.B2(n_11),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_18),
.B1(n_16),
.B2(n_15),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_R g48 ( 
.A1(n_47),
.A2(n_19),
.B1(n_23),
.B2(n_46),
.Y(n_48)
);


endmodule