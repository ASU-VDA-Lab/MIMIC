module fake_netlist_612_476_n_11 (n_1, n_2, n_0, n_11);

input n_1;
input n_2;
input n_0;

output n_11;

wire n_7;
wire n_9;
wire n_8;
wire n_5;
wire n_10;
wire n_6;
wire n_4;
wire n_3;

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

INVx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_2),
.B(n_0),
.Y(n_5)
);

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_3),
.B1(n_4),
.B2(n_2),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_5),
.B(n_2),
.Y(n_8)
);

NOR4xp75_ASAP7_75t_SL g9 ( 
.A(n_8),
.B(n_2),
.C(n_1),
.D(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);


endmodule