module fake_netlist_612_314_n_36 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_36);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_36;

wire n_31;
wire n_21;
wire n_30;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_0),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_3),
.A2(n_14),
.B1(n_19),
.B2(n_1),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_16),
.B(n_4),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_10),
.Y(n_25)
);

AND2x6_ASAP7_75t_L g26 ( 
.A(n_7),
.B(n_8),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

AOI21xp33_ASAP7_75t_L g30 ( 
.A1(n_23),
.A2(n_17),
.B(n_2),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_26),
.B1(n_24),
.B2(n_20),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_26),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_31),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_25),
.B(n_21),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_29),
.B1(n_17),
.B2(n_5),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_13),
.B(n_12),
.Y(n_36)
);


endmodule