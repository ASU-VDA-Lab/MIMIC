module fake_netlist_612_1930_n_33 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_17, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_33);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_17;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_33;

wire n_31;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;

INVx1_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_11),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_SL g24 ( 
.A(n_18),
.B(n_15),
.C(n_0),
.Y(n_24)
);

O2A1O1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_15),
.B(n_3),
.C(n_1),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_19),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_20),
.Y(n_28)
);

OAI222xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B1(n_22),
.B2(n_21),
.C1(n_5),
.C2(n_4),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_13),
.B1(n_12),
.B2(n_10),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_17),
.B1(n_16),
.B2(n_14),
.Y(n_33)
);


endmodule