module fake_netlist_612_1874_n_47 (n_11, n_8, n_15, n_3, n_21, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_47);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_47;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_30;
wire n_44;
wire n_36;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_43;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_15),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_3),
.Y(n_27)
);

INVx2_ASAP7_75t_SL g28 ( 
.A(n_18),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_9),
.Y(n_29)
);

NOR2xp67_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_8),
.Y(n_30)
);

OR2x6_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_16),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_24),
.B(n_16),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_27),
.Y(n_34)
);

OAI21x1_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_26),
.B(n_22),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_23),
.B1(n_29),
.B2(n_25),
.C(n_31),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_31),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_23),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_29),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

XNOR2xp5_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_30),
.Y(n_42)
);

AOI211xp5_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_19),
.B(n_18),
.C(n_17),
.Y(n_43)
);

NOR3xp33_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_19),
.C(n_17),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_0),
.Y(n_45)
);

OAI332xp33_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_45),
.A3(n_5),
.B1(n_7),
.B2(n_4),
.B3(n_11),
.C1(n_1),
.C2(n_12),
.Y(n_46)
);

NAND3xp33_ASAP7_75t_R g47 ( 
.A(n_46),
.B(n_14),
.C(n_13),
.Y(n_47)
);


endmodule