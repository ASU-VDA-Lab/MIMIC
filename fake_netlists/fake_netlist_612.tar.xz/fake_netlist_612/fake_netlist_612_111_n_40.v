module fake_netlist_612_111_n_40 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_17, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_40);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_17;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_40;

wire n_31;
wire n_37;
wire n_39;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_14),
.B(n_15),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_18),
.A2(n_20),
.B(n_21),
.Y(n_26)
);

O2A1O1Ixp5_ASAP7_75t_SL g27 ( 
.A1(n_25),
.A2(n_17),
.B(n_2),
.C(n_1),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_3),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_23),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_22),
.B2(n_19),
.C(n_27),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_22),
.B1(n_5),
.B2(n_4),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_34),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AOI222xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.B1(n_12),
.B2(n_7),
.C1(n_13),
.C2(n_10),
.Y(n_40)
);


endmodule