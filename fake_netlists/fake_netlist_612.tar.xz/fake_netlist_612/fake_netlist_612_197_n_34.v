module fake_netlist_612_197_n_34 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_17, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_34);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_17;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_34;

wire n_31;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_14),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_19),
.B(n_16),
.Y(n_24)
);

INVx6_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

AO21x2_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_20),
.B(n_18),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_21),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_23),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B1(n_22),
.B2(n_17),
.Y(n_29)
);

AOI21xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_17),
.B(n_1),
.Y(n_30)
);

NAND4xp25_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_4),
.C(n_3),
.D(n_2),
.Y(n_31)
);

NOR2xp67_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_5),
.Y(n_32)
);

OAI22x1_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_10),
.B1(n_7),
.B2(n_6),
.Y(n_33)
);

AOI32xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.A3(n_15),
.B1(n_12),
.B2(n_13),
.Y(n_34)
);


endmodule