module fake_netlist_612_991_n_63 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_63);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_63;

wire n_31;
wire n_15;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_18;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_58;
wire n_62;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_60;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_42;
wire n_33;
wire n_14;
wire n_41;
wire n_55;
wire n_13;
wire n_12;

INVx1_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_0),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_7),
.Y(n_15)
);

CKINVDCx11_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

NAND2xp33_ASAP7_75t_L g17 ( 
.A(n_2),
.B(n_6),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_9),
.B(n_2),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_13),
.B(n_7),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_12),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_16),
.Y(n_25)
);

AO21x2_ASAP7_75t_L g26 ( 
.A1(n_18),
.A2(n_7),
.B(n_1),
.Y(n_26)
);

NOR2x1p5_ASAP7_75t_L g27 ( 
.A(n_12),
.B(n_4),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_13),
.B(n_20),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_17),
.B(n_4),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_19),
.B(n_6),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_20),
.B(n_18),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_19),
.B(n_8),
.Y(n_32)
);

INVxp67_ASAP7_75t_SL g33 ( 
.A(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_28),
.A2(n_15),
.B1(n_22),
.B2(n_21),
.C(n_18),
.Y(n_35)
);

INVx4_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_31),
.A2(n_21),
.B(n_14),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_24),
.B(n_22),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_27),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_26),
.A2(n_14),
.B1(n_10),
.B2(n_8),
.Y(n_40)
);

OAI211xp5_ASAP7_75t_L g41 ( 
.A1(n_35),
.A2(n_23),
.B(n_33),
.C(n_32),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_34),
.Y(n_42)
);

OAI221xp5_ASAP7_75t_L g43 ( 
.A1(n_35),
.A2(n_23),
.B1(n_28),
.B2(n_32),
.C(n_30),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_33),
.B(n_26),
.Y(n_45)
);

NAND2xp33_ASAP7_75t_R g46 ( 
.A(n_38),
.B(n_25),
.Y(n_46)
);

NOR3xp33_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_39),
.C(n_37),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_42),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_38),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_L g50 ( 
.A(n_43),
.B(n_36),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_42),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_41),
.B1(n_45),
.B2(n_46),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

NOR2xp67_ASAP7_75t_SL g54 ( 
.A(n_48),
.B(n_36),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_47),
.Y(n_55)
);

A2O1A1O1Ixp25_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_51),
.B(n_34),
.C(n_27),
.D(n_29),
.Y(n_56)
);

NAND4xp75_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_38),
.C(n_51),
.D(n_40),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

OA22x2_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_36),
.B1(n_26),
.B2(n_54),
.Y(n_59)
);

NAND3xp33_ASAP7_75t_SL g60 ( 
.A(n_56),
.B(n_54),
.C(n_10),
.Y(n_60)
);

NOR4xp25_ASAP7_75t_L g61 ( 
.A(n_56),
.B(n_43),
.C(n_41),
.D(n_35),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_59),
.Y(n_62)
);

AOI22xp33_ASAP7_75t_R g63 ( 
.A1(n_62),
.A2(n_61),
.B1(n_60),
.B2(n_57),
.Y(n_63)
);


endmodule