module fake_netlist_612_2496_n_38 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_38);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_38;

wire n_11;
wire n_31;
wire n_15;
wire n_37;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;
wire n_14;
wire n_13;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_8),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_6),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

AOI21x1_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_1),
.B(n_0),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_4),
.B(n_3),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_5),
.B(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

O2A1O1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_16),
.A2(n_8),
.B(n_6),
.C(n_5),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_12),
.B1(n_16),
.B2(n_10),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_R g24 ( 
.A(n_21),
.B(n_12),
.Y(n_24)
);

CKINVDCx8_ASAP7_75t_R g25 ( 
.A(n_22),
.Y(n_25)
);

OAI21xp33_ASAP7_75t_L g26 ( 
.A1(n_18),
.A2(n_15),
.B(n_11),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_15),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_17),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NAND2xp33_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_19),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_24),
.C(n_29),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_R g33 ( 
.A(n_30),
.B(n_28),
.Y(n_33)
);

AND2x2_ASAP7_75t_SL g34 ( 
.A(n_33),
.B(n_31),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_20),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_9),
.B(n_24),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_SL g38 ( 
.A1(n_36),
.A2(n_37),
.B1(n_35),
.B2(n_9),
.Y(n_38)
);


endmodule