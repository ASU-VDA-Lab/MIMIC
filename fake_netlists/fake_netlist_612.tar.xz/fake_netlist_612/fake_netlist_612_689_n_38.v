module fake_netlist_612_689_n_38 (n_11, n_8, n_15, n_3, n_21, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_38);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_38;

wire n_31;
wire n_37;
wire n_30;
wire n_36;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_32;
wire n_23;
wire n_33;
wire n_34;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_7),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_6),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_8),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_21),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_24),
.B(n_21),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_28),
.C(n_27),
.Y(n_31)
);

OA21x2_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_23),
.B(n_22),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_26),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.B1(n_24),
.B2(n_0),
.Y(n_34)
);

OAI22xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_9),
.B1(n_5),
.B2(n_10),
.C(n_11),
.Y(n_36)
);

OAI22x1_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_17),
.B1(n_13),
.B2(n_12),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_SL g38 ( 
.A1(n_37),
.A2(n_20),
.B1(n_19),
.B2(n_18),
.Y(n_38)
);


endmodule