module fake_netlist_612_1863_n_14 (n_1, n_2, n_3, n_0, n_14);

input n_1;
input n_2;
input n_3;
input n_0;

output n_14;

wire n_7;
wire n_11;
wire n_9;
wire n_8;
wire n_5;
wire n_10;
wire n_13;
wire n_6;
wire n_4;
wire n_12;

AND2x2_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_3),
.Y(n_4)
);

NAND3xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_1),
.C(n_2),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_2),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

OAI32xp33_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_5),
.A3(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B1(n_10),
.B2(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B(n_2),
.Y(n_14)
);


endmodule