module fake_netlist_757_636_n_54 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_54);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_54;

wire n_46;
wire n_44;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_27;
wire n_42;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_52;
wire n_32;

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_5),
.B(n_8),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_17),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_13),
.B(n_12),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_14),
.B(n_4),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_9),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_2),
.Y(n_33)
);

OA21x2_ASAP7_75t_L g34 ( 
.A1(n_0),
.A2(n_23),
.B(n_19),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_29),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_30),
.B(n_1),
.Y(n_37)
);

INVx4_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_3),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_25),
.B(n_26),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_37),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_27),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_31),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_42),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

OAI221xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_31),
.B1(n_34),
.B2(n_32),
.C(n_7),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

NOR3xp33_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_50),
.C(n_32),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_10),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);

AOI322xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_51),
.A3(n_16),
.B1(n_15),
.B2(n_11),
.C1(n_21),
.C2(n_20),
.Y(n_54)
);


endmodule