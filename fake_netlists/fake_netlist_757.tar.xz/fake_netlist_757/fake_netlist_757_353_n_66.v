module fake_netlist_757_353_n_66 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_66);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_66;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_64;
wire n_22;
wire n_62;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_65;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_63;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx1_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_6),
.B(n_7),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_29),
.B(n_0),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_27),
.B(n_2),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_2),
.Y(n_34)
);

INVx4_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_31),
.Y(n_37)
);

INVxp67_ASAP7_75t_SL g38 ( 
.A(n_35),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_33),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_21),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_40),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_30),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_38),
.Y(n_47)
);

AOI221x1_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_32),
.B1(n_34),
.B2(n_25),
.C(n_24),
.Y(n_48)
);

OAI211xp5_ASAP7_75t_L g49 ( 
.A1(n_44),
.A2(n_21),
.B(n_26),
.C(n_22),
.Y(n_49)
);

AOI321xp33_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_22),
.A3(n_28),
.B1(n_23),
.B2(n_15),
.C(n_11),
.Y(n_50)
);

OAI211xp5_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_28),
.B(n_29),
.C(n_33),
.Y(n_51)
);

NOR2x1_ASAP7_75t_L g52 ( 
.A(n_46),
.B(n_35),
.Y(n_52)
);

OAI221xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_49),
.B1(n_47),
.B2(n_48),
.C(n_51),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

OAI21xp33_ASAP7_75t_L g55 ( 
.A1(n_48),
.A2(n_36),
.B(n_11),
.Y(n_55)
);

AOI211xp5_ASAP7_75t_L g56 ( 
.A1(n_49),
.A2(n_17),
.B(n_16),
.C(n_15),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_18),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_53),
.B(n_18),
.Y(n_59)
);

NAND4xp25_ASAP7_75t_SL g60 ( 
.A(n_53),
.B(n_19),
.C(n_4),
.D(n_1),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_L g61 ( 
.A1(n_55),
.A2(n_35),
.B1(n_13),
.B2(n_10),
.Y(n_61)
);

AOI22xp33_ASAP7_75t_L g62 ( 
.A1(n_60),
.A2(n_54),
.B1(n_57),
.B2(n_35),
.Y(n_62)
);

XOR2x1_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_14),
.Y(n_63)
);

BUFx2_ASAP7_75t_L g64 ( 
.A(n_59),
.Y(n_64)
);

OR2x2_ASAP7_75t_L g65 ( 
.A(n_64),
.B(n_61),
.Y(n_65)
);

AO21x2_ASAP7_75t_L g66 ( 
.A1(n_65),
.A2(n_63),
.B(n_62),
.Y(n_66)
);


endmodule