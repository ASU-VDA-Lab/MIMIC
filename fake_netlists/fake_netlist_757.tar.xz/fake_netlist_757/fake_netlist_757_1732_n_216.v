module fake_netlist_757_1732_n_216 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_26, n_6, n_2, n_3, n_9, n_4, n_25, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_216);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_26;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_216;

wire n_77;
wire n_71;
wire n_80;
wire n_62;
wire n_215;
wire n_186;
wire n_156;
wire n_36;
wire n_175;
wire n_153;
wire n_81;
wire n_106;
wire n_200;
wire n_104;
wire n_68;
wire n_73;
wire n_192;
wire n_176;
wire n_173;
wire n_112;
wire n_127;
wire n_139;
wire n_182;
wire n_189;
wire n_155;
wire n_94;
wire n_183;
wire n_105;
wire n_60;
wire n_53;
wire n_57;
wire n_41;
wire n_157;
wire n_119;
wire n_84;
wire n_86;
wire n_195;
wire n_55;
wire n_131;
wire n_201;
wire n_191;
wire n_126;
wire n_151;
wire n_210;
wire n_140;
wire n_184;
wire n_46;
wire n_64;
wire n_82;
wire n_196;
wire n_76;
wire n_194;
wire n_193;
wire n_72;
wire n_108;
wire n_145;
wire n_51;
wire n_78;
wire n_98;
wire n_102;
wire n_97;
wire n_118;
wire n_75;
wire n_197;
wire n_42;
wire n_132;
wire n_85;
wire n_160;
wire n_33;
wire n_147;
wire n_198;
wire n_95;
wire n_180;
wire n_149;
wire n_174;
wire n_70;
wire n_63;
wire n_69;
wire n_166;
wire n_144;
wire n_100;
wire n_56;
wire n_167;
wire n_204;
wire n_111;
wire n_125;
wire n_92;
wire n_52;
wire n_141;
wire n_214;
wire n_136;
wire n_61;
wire n_110;
wire n_172;
wire n_207;
wire n_45;
wire n_190;
wire n_137;
wire n_90;
wire n_28;
wire n_65;
wire n_148;
wire n_169;
wire n_150;
wire n_87;
wire n_187;
wire n_128;
wire n_117;
wire n_133;
wire n_50;
wire n_96;
wire n_138;
wire n_203;
wire n_79;
wire n_130;
wire n_35;
wire n_101;
wire n_122;
wire n_43;
wire n_165;
wire n_209;
wire n_58;
wire n_91;
wire n_188;
wire n_103;
wire n_123;
wire n_163;
wire n_115;
wire n_74;
wire n_199;
wire n_121;
wire n_116;
wire n_44;
wire n_66;
wire n_159;
wire n_34;
wire n_39;
wire n_99;
wire n_181;
wire n_205;
wire n_48;
wire n_211;
wire n_49;
wire n_170;
wire n_134;
wire n_114;
wire n_37;
wire n_59;
wire n_27;
wire n_89;
wire n_161;
wire n_135;
wire n_162;
wire n_40;
wire n_109;
wire n_120;
wire n_158;
wire n_31;
wire n_30;
wire n_38;
wire n_124;
wire n_168;
wire n_107;
wire n_208;
wire n_179;
wire n_212;
wire n_164;
wire n_154;
wire n_143;
wire n_178;
wire n_129;
wire n_67;
wire n_171;
wire n_177;
wire n_206;
wire n_142;
wire n_29;
wire n_47;
wire n_88;
wire n_152;
wire n_93;
wire n_146;
wire n_54;
wire n_32;
wire n_185;
wire n_213;
wire n_83;
wire n_202;
wire n_113;

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVxp33_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_9),
.Y(n_31)
);

INVxp67_ASAP7_75t_SL g32 ( 
.A(n_13),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_2),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_13),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_1),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_15),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_4),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_14),
.Y(n_38)
);

INVxp33_ASAP7_75t_L g39 ( 
.A(n_0),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_29),
.Y(n_40)
);

CKINVDCx5p33_ASAP7_75t_R g41 ( 
.A(n_29),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_29),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_33),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_33),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_29),
.Y(n_45)
);

NAND2x1p5_ASAP7_75t_L g46 ( 
.A(n_40),
.B(n_35),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_40),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_41),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_41),
.Y(n_50)
);

NOR2xp33_ASAP7_75t_L g51 ( 
.A(n_42),
.B(n_39),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_42),
.Y(n_52)
);

OR2x2_ASAP7_75t_SL g53 ( 
.A(n_44),
.B(n_34),
.Y(n_53)
);

CKINVDCx5p33_ASAP7_75t_R g54 ( 
.A(n_43),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_SL g55 ( 
.A(n_51),
.B(n_39),
.Y(n_55)
);

OA21x2_ASAP7_75t_L g56 ( 
.A1(n_47),
.A2(n_35),
.B(n_34),
.Y(n_56)
);

INVxp67_ASAP7_75t_SL g57 ( 
.A(n_46),
.Y(n_57)
);

OAI22xp5_ASAP7_75t_L g58 ( 
.A1(n_46),
.A2(n_44),
.B1(n_28),
.B2(n_32),
.Y(n_58)
);

AOI21xp5_ASAP7_75t_L g59 ( 
.A1(n_49),
.A2(n_35),
.B(n_31),
.Y(n_59)
);

NOR2xp33_ASAP7_75t_L g60 ( 
.A(n_47),
.B(n_28),
.Y(n_60)
);

INVx1_ASAP7_75t_SL g61 ( 
.A(n_54),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_48),
.B(n_31),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_SL g63 ( 
.A(n_48),
.B(n_37),
.Y(n_63)
);

AND2x4_ASAP7_75t_L g64 ( 
.A(n_50),
.B(n_34),
.Y(n_64)
);

OAI22xp5_ASAP7_75t_L g65 ( 
.A1(n_46),
.A2(n_52),
.B1(n_50),
.B2(n_32),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_SL g66 ( 
.A(n_52),
.B(n_37),
.Y(n_66)
);

AOI21xp5_ASAP7_75t_L g67 ( 
.A1(n_53),
.A2(n_38),
.B(n_36),
.Y(n_67)
);

OR2x6_ASAP7_75t_L g68 ( 
.A(n_67),
.B(n_36),
.Y(n_68)
);

OR2x6_ASAP7_75t_L g69 ( 
.A(n_65),
.B(n_36),
.Y(n_69)
);

OA21x2_ASAP7_75t_L g70 ( 
.A1(n_59),
.A2(n_62),
.B(n_64),
.Y(n_70)
);

AND2x2_ASAP7_75t_L g71 ( 
.A(n_64),
.B(n_38),
.Y(n_71)
);

OA21x2_ASAP7_75t_L g72 ( 
.A1(n_64),
.A2(n_38),
.B(n_27),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_56),
.Y(n_73)
);

INVx3_ASAP7_75t_L g74 ( 
.A(n_56),
.Y(n_74)
);

CKINVDCx8_ASAP7_75t_R g75 ( 
.A(n_64),
.Y(n_75)
);

OAI22xp5_ASAP7_75t_L g76 ( 
.A1(n_58),
.A2(n_53),
.B1(n_30),
.B2(n_27),
.Y(n_76)
);

NAND3xp33_ASAP7_75t_L g77 ( 
.A(n_56),
.B(n_30),
.C(n_3),
.Y(n_77)
);

BUFx4_ASAP7_75t_SL g78 ( 
.A(n_61),
.Y(n_78)
);

INVx2_ASAP7_75t_L g79 ( 
.A(n_74),
.Y(n_79)
);

AND2x4_ASAP7_75t_L g80 ( 
.A(n_71),
.B(n_57),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_71),
.B(n_60),
.Y(n_81)
);

NAND2x1_ASAP7_75t_L g82 ( 
.A(n_74),
.B(n_56),
.Y(n_82)
);

INVx2_ASAP7_75t_L g83 ( 
.A(n_74),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_70),
.Y(n_84)
);

NAND2xp5_ASAP7_75t_L g85 ( 
.A(n_71),
.B(n_55),
.Y(n_85)
);

NOR3xp33_ASAP7_75t_SL g86 ( 
.A(n_76),
.B(n_66),
.C(n_63),
.Y(n_86)
);

AOI22xp5_ASAP7_75t_L g87 ( 
.A1(n_80),
.A2(n_76),
.B1(n_61),
.B2(n_69),
.Y(n_87)
);

OR2x6_ASAP7_75t_L g88 ( 
.A(n_85),
.B(n_69),
.Y(n_88)
);

AOI22xp33_ASAP7_75t_L g89 ( 
.A1(n_80),
.A2(n_69),
.B1(n_68),
.B2(n_71),
.Y(n_89)
);

O2A1O1Ixp33_ASAP7_75t_L g90 ( 
.A1(n_81),
.A2(n_69),
.B(n_68),
.C(n_77),
.Y(n_90)
);

AOI22xp33_ASAP7_75t_L g91 ( 
.A1(n_84),
.A2(n_69),
.B1(n_68),
.B2(n_70),
.Y(n_91)
);

INVx2_ASAP7_75t_L g92 ( 
.A(n_79),
.Y(n_92)
);

AOI22xp5_ASAP7_75t_L g93 ( 
.A1(n_86),
.A2(n_69),
.B1(n_68),
.B2(n_70),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_92),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_93),
.Y(n_95)
);

NAND2xp5_ASAP7_75t_L g96 ( 
.A(n_89),
.B(n_86),
.Y(n_96)
);

AND2x4_ASAP7_75t_L g97 ( 
.A(n_88),
.B(n_87),
.Y(n_97)
);

AND2x2_ASAP7_75t_L g98 ( 
.A(n_88),
.B(n_68),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_90),
.Y(n_99)
);

OAI211xp5_ASAP7_75t_L g100 ( 
.A1(n_91),
.A2(n_75),
.B(n_77),
.C(n_70),
.Y(n_100)
);

HB1xp67_ASAP7_75t_L g101 ( 
.A(n_88),
.Y(n_101)
);

INVx2_ASAP7_75t_L g102 ( 
.A(n_92),
.Y(n_102)
);

OR2x2_ASAP7_75t_L g103 ( 
.A(n_88),
.B(n_69),
.Y(n_103)
);

NAND2xp5_ASAP7_75t_L g104 ( 
.A(n_99),
.B(n_79),
.Y(n_104)
);

INVx2_ASAP7_75t_L g105 ( 
.A(n_99),
.Y(n_105)
);

INVx2_ASAP7_75t_SL g106 ( 
.A(n_101),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_95),
.Y(n_107)
);

INVx3_ASAP7_75t_L g108 ( 
.A(n_103),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_95),
.Y(n_109)
);

OR2x2_ASAP7_75t_L g110 ( 
.A(n_96),
.B(n_77),
.Y(n_110)
);

NOR2xp33_ASAP7_75t_L g111 ( 
.A(n_96),
.B(n_69),
.Y(n_111)
);

AND2x2_ASAP7_75t_L g112 ( 
.A(n_97),
.B(n_72),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_94),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_94),
.Y(n_114)
);

INVx1_ASAP7_75t_SL g115 ( 
.A(n_103),
.Y(n_115)
);

INVx2_ASAP7_75t_L g116 ( 
.A(n_94),
.Y(n_116)
);

NAND2xp5_ASAP7_75t_L g117 ( 
.A(n_97),
.B(n_83),
.Y(n_117)
);

AND2x2_ASAP7_75t_L g118 ( 
.A(n_97),
.B(n_72),
.Y(n_118)
);

NOR2xp33_ASAP7_75t_R g119 ( 
.A(n_98),
.B(n_75),
.Y(n_119)
);

AND2x2_ASAP7_75t_L g120 ( 
.A(n_108),
.B(n_97),
.Y(n_120)
);

OAI221xp5_ASAP7_75t_SL g121 ( 
.A1(n_111),
.A2(n_68),
.B1(n_100),
.B2(n_98),
.C(n_78),
.Y(n_121)
);

AOI221xp5_ASAP7_75t_L g122 ( 
.A1(n_107),
.A2(n_100),
.B1(n_73),
.B2(n_68),
.C(n_74),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_105),
.Y(n_123)
);

INVx1_ASAP7_75t_L g124 ( 
.A(n_105),
.Y(n_124)
);

AND2x2_ASAP7_75t_SL g125 ( 
.A(n_110),
.B(n_70),
.Y(n_125)
);

NAND2xp5_ASAP7_75t_L g126 ( 
.A(n_107),
.B(n_102),
.Y(n_126)
);

OAI22xp5_ASAP7_75t_L g127 ( 
.A1(n_110),
.A2(n_75),
.B1(n_68),
.B2(n_70),
.Y(n_127)
);

AND2x4_ASAP7_75t_L g128 ( 
.A(n_108),
.B(n_102),
.Y(n_128)
);

INVx1_ASAP7_75t_L g129 ( 
.A(n_105),
.Y(n_129)
);

INVx2_ASAP7_75t_L g130 ( 
.A(n_113),
.Y(n_130)
);

AOI21xp33_ASAP7_75t_L g131 ( 
.A1(n_110),
.A2(n_102),
.B(n_70),
.Y(n_131)
);

AND2x4_ASAP7_75t_L g132 ( 
.A(n_108),
.B(n_83),
.Y(n_132)
);

NAND2xp5_ASAP7_75t_L g133 ( 
.A(n_109),
.B(n_72),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_109),
.Y(n_134)
);

NOR2xp33_ASAP7_75t_L g135 ( 
.A(n_106),
.B(n_3),
.Y(n_135)
);

INVx4_ASAP7_75t_L g136 ( 
.A(n_108),
.Y(n_136)
);

INVx2_ASAP7_75t_L g137 ( 
.A(n_113),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_114),
.Y(n_138)
);

INVx2_ASAP7_75t_L g139 ( 
.A(n_114),
.Y(n_139)
);

NAND3xp33_ASAP7_75t_L g140 ( 
.A(n_106),
.B(n_75),
.C(n_72),
.Y(n_140)
);

INVx2_ASAP7_75t_L g141 ( 
.A(n_116),
.Y(n_141)
);

OAI22xp5_ASAP7_75t_SL g142 ( 
.A1(n_106),
.A2(n_72),
.B1(n_78),
.B2(n_73),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_116),
.Y(n_143)
);

AND2x2_ASAP7_75t_L g144 ( 
.A(n_120),
.B(n_112),
.Y(n_144)
);

INVx1_ASAP7_75t_L g145 ( 
.A(n_134),
.Y(n_145)
);

NAND2xp5_ASAP7_75t_L g146 ( 
.A(n_134),
.B(n_123),
.Y(n_146)
);

AND2x2_ASAP7_75t_L g147 ( 
.A(n_120),
.B(n_112),
.Y(n_147)
);

NAND2xp33_ASAP7_75t_L g148 ( 
.A(n_142),
.B(n_119),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_123),
.Y(n_149)
);

INVx2_ASAP7_75t_SL g150 ( 
.A(n_124),
.Y(n_150)
);

NOR2xp33_ASAP7_75t_L g151 ( 
.A(n_135),
.B(n_115),
.Y(n_151)
);

OR2x2_ASAP7_75t_L g152 ( 
.A(n_124),
.B(n_129),
.Y(n_152)
);

NAND2xp5_ASAP7_75t_L g153 ( 
.A(n_132),
.B(n_115),
.Y(n_153)
);

INVx1_ASAP7_75t_SL g154 ( 
.A(n_136),
.Y(n_154)
);

INVx1_ASAP7_75t_L g155 ( 
.A(n_129),
.Y(n_155)
);

AND2x2_ASAP7_75t_L g156 ( 
.A(n_136),
.B(n_112),
.Y(n_156)
);

INVx2_ASAP7_75t_L g157 ( 
.A(n_143),
.Y(n_157)
);

NOR2xp33_ASAP7_75t_L g158 ( 
.A(n_121),
.B(n_4),
.Y(n_158)
);

NAND2xp33_ASAP7_75t_L g159 ( 
.A(n_142),
.B(n_104),
.Y(n_159)
);

NOR2xp33_ASAP7_75t_L g160 ( 
.A(n_136),
.B(n_5),
.Y(n_160)
);

OR3x1_ASAP7_75t_L g161 ( 
.A(n_131),
.B(n_73),
.C(n_118),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_138),
.Y(n_162)
);

NAND2xp5_ASAP7_75t_SL g163 ( 
.A(n_128),
.B(n_117),
.Y(n_163)
);

OAI31xp33_ASAP7_75t_SL g164 ( 
.A1(n_122),
.A2(n_118),
.A3(n_116),
.B(n_5),
.Y(n_164)
);

NOR2xp33_ASAP7_75t_L g165 ( 
.A(n_136),
.B(n_6),
.Y(n_165)
);

INVx1_ASAP7_75t_SL g166 ( 
.A(n_128),
.Y(n_166)
);

INVx1_ASAP7_75t_L g167 ( 
.A(n_130),
.Y(n_167)
);

NOR2xp33_ASAP7_75t_L g168 ( 
.A(n_132),
.B(n_6),
.Y(n_168)
);

AND2x2_ASAP7_75t_L g169 ( 
.A(n_125),
.B(n_118),
.Y(n_169)
);

OAI211xp5_ASAP7_75t_SL g170 ( 
.A1(n_164),
.A2(n_133),
.B(n_126),
.C(n_140),
.Y(n_170)
);

OAI21xp5_ASAP7_75t_L g171 ( 
.A1(n_158),
.A2(n_165),
.B(n_160),
.Y(n_171)
);

AOI221xp5_ASAP7_75t_L g172 ( 
.A1(n_159),
.A2(n_127),
.B1(n_128),
.B2(n_143),
.C(n_130),
.Y(n_172)
);

NAND3xp33_ASAP7_75t_L g173 ( 
.A(n_164),
.B(n_139),
.C(n_137),
.Y(n_173)
);

NAND2xp5_ASAP7_75t_SL g174 ( 
.A(n_151),
.B(n_153),
.Y(n_174)
);

AND4x1_ASAP7_75t_L g175 ( 
.A(n_168),
.B(n_145),
.C(n_162),
.D(n_149),
.Y(n_175)
);

AOI221xp5_ASAP7_75t_L g176 ( 
.A1(n_145),
.A2(n_137),
.B1(n_139),
.B2(n_132),
.C(n_141),
.Y(n_176)
);

AOI211xp5_ASAP7_75t_L g177 ( 
.A1(n_148),
.A2(n_132),
.B(n_117),
.C(n_141),
.Y(n_177)
);

INVx1_ASAP7_75t_L g178 ( 
.A(n_162),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_146),
.Y(n_179)
);

AOI211xp5_ASAP7_75t_L g180 ( 
.A1(n_155),
.A2(n_14),
.B(n_12),
.C(n_11),
.Y(n_180)
);

OAI211xp5_ASAP7_75t_SL g181 ( 
.A1(n_154),
.A2(n_16),
.B(n_15),
.C(n_12),
.Y(n_181)
);

AOI222xp33_ASAP7_75t_L g182 ( 
.A1(n_169),
.A2(n_125),
.B1(n_163),
.B2(n_147),
.C1(n_144),
.C2(n_156),
.Y(n_182)
);

OAI211xp5_ASAP7_75t_SL g183 ( 
.A1(n_154),
.A2(n_18),
.B(n_17),
.C(n_16),
.Y(n_183)
);

NAND2xp5_ASAP7_75t_L g184 ( 
.A(n_147),
.B(n_17),
.Y(n_184)
);

OAI211xp5_ASAP7_75t_SL g185 ( 
.A1(n_150),
.A2(n_152),
.B(n_167),
.C(n_157),
.Y(n_185)
);

AOI211xp5_ASAP7_75t_SL g186 ( 
.A1(n_156),
.A2(n_74),
.B(n_19),
.C(n_18),
.Y(n_186)
);

AOI221xp5_ASAP7_75t_SL g187 ( 
.A1(n_167),
.A2(n_20),
.B1(n_19),
.B2(n_21),
.C(n_22),
.Y(n_187)
);

AOI211xp5_ASAP7_75t_L g188 ( 
.A1(n_152),
.A2(n_169),
.B(n_144),
.C(n_166),
.Y(n_188)
);

AOI221xp5_ASAP7_75t_L g189 ( 
.A1(n_161),
.A2(n_21),
.B1(n_20),
.B2(n_22),
.C(n_23),
.Y(n_189)
);

NAND3xp33_ASAP7_75t_L g190 ( 
.A(n_157),
.B(n_72),
.C(n_82),
.Y(n_190)
);

NAND2xp5_ASAP7_75t_L g191 ( 
.A(n_179),
.B(n_161),
.Y(n_191)
);

HB1xp67_ASAP7_75t_L g192 ( 
.A(n_178),
.Y(n_192)
);

NAND4xp25_ASAP7_75t_L g193 ( 
.A(n_171),
.B(n_26),
.C(n_25),
.D(n_74),
.Y(n_193)
);

NAND2x1p5_ASAP7_75t_L g194 ( 
.A(n_175),
.B(n_7),
.Y(n_194)
);

AND4x1_ASAP7_75t_L g195 ( 
.A(n_186),
.B(n_180),
.C(n_189),
.D(n_188),
.Y(n_195)
);

OAI21xp33_ASAP7_75t_L g196 ( 
.A1(n_182),
.A2(n_10),
.B(n_181),
.Y(n_196)
);

INVx2_ASAP7_75t_L g197 ( 
.A(n_184),
.Y(n_197)
);

AND2x2_ASAP7_75t_L g198 ( 
.A(n_174),
.B(n_176),
.Y(n_198)
);

OAI22xp5_ASAP7_75t_L g199 ( 
.A1(n_177),
.A2(n_173),
.B1(n_172),
.B2(n_187),
.Y(n_199)
);

AOI221xp5_ASAP7_75t_L g200 ( 
.A1(n_185),
.A2(n_171),
.B1(n_187),
.B2(n_189),
.C(n_183),
.Y(n_200)
);

INVx1_ASAP7_75t_L g201 ( 
.A(n_185),
.Y(n_201)
);

AOI22xp33_ASAP7_75t_L g202 ( 
.A1(n_170),
.A2(n_158),
.B1(n_183),
.B2(n_181),
.Y(n_202)
);

BUFx2_ASAP7_75t_L g203 ( 
.A(n_201),
.Y(n_203)
);

NAND2xp5_ASAP7_75t_L g204 ( 
.A(n_191),
.B(n_190),
.Y(n_204)
);

BUFx2_ASAP7_75t_L g205 ( 
.A(n_192),
.Y(n_205)
);

CKINVDCx5p33_ASAP7_75t_R g206 ( 
.A(n_197),
.Y(n_206)
);

INVxp67_ASAP7_75t_L g207 ( 
.A(n_198),
.Y(n_207)
);

BUFx2_ASAP7_75t_L g208 ( 
.A(n_194),
.Y(n_208)
);

INVx4_ASAP7_75t_L g209 ( 
.A(n_203),
.Y(n_209)
);

OR3x2_ASAP7_75t_L g210 ( 
.A(n_207),
.B(n_193),
.C(n_195),
.Y(n_210)
);

BUFx2_ASAP7_75t_L g211 ( 
.A(n_205),
.Y(n_211)
);

OAI22x1_ASAP7_75t_L g212 ( 
.A1(n_209),
.A2(n_206),
.B1(n_208),
.B2(n_194),
.Y(n_212)
);

OR2x2_ASAP7_75t_L g213 ( 
.A(n_211),
.B(n_204),
.Y(n_213)
);

XOR2xp5_ASAP7_75t_L g214 ( 
.A(n_213),
.B(n_210),
.Y(n_214)
);

AOI22xp33_ASAP7_75t_L g215 ( 
.A1(n_214),
.A2(n_209),
.B1(n_196),
.B2(n_200),
.Y(n_215)
);

AOI22xp5_ASAP7_75t_L g216 ( 
.A1(n_215),
.A2(n_212),
.B1(n_199),
.B2(n_202),
.Y(n_216)
);


endmodule