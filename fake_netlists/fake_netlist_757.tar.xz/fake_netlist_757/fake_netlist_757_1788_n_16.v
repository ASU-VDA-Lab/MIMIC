module fake_netlist_757_1788_n_16 (n_1, n_2, n_3, n_4, n_5, n_0, n_16);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_16;

wire n_12;
wire n_15;
wire n_14;
wire n_8;
wire n_9;
wire n_10;
wire n_13;
wire n_7;
wire n_6;
wire n_11;

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_5),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

CKINVDCx14_ASAP7_75t_R g9 ( 
.A(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_11),
.B(n_8),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_13),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_16)
);


endmodule