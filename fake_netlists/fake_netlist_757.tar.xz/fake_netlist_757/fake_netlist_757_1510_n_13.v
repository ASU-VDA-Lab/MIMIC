module fake_netlist_757_1510_n_13 (n_1, n_2, n_3, n_4, n_0, n_13);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_13;

wire n_12;
wire n_9;
wire n_11;
wire n_10;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

INVx2_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVxp67_ASAP7_75t_SL g6 ( 
.A(n_0),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_7),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.Y(n_10)
);

OAI221xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.C(n_1),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B(n_10),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_12),
.Y(n_13)
);


endmodule