module fake_netlist_757_885_n_39 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_39);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_39;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

BUFx3_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

BUFx10_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_7),
.B(n_10),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_8),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_R g25 ( 
.A(n_9),
.B(n_0),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_19),
.B(n_24),
.C(n_20),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_18),
.A2(n_3),
.B(n_1),
.Y(n_27)
);

BUFx4f_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NAND3x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_25),
.C(n_15),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_22),
.Y(n_34)
);

OAI21xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_32),
.B(n_27),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.C(n_25),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_17),
.B2(n_16),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_14),
.B1(n_12),
.B2(n_11),
.Y(n_39)
);


endmodule