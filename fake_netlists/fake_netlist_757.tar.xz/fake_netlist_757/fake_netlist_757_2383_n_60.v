module fake_netlist_757_2383_n_60 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_60);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_60;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_SL g24 ( 
.A(n_11),
.B(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_15),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_15),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_6),
.B(n_17),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

BUFx4f_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

OR2x6_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_16),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_16),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_27),
.B(n_18),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_31),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_SL g39 ( 
.A1(n_34),
.A2(n_28),
.B1(n_29),
.B2(n_20),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_33),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_36),
.Y(n_41)
);

OAI222xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_34),
.B1(n_30),
.B2(n_37),
.C1(n_35),
.C2(n_32),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx3_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

INVx4_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

NAND4xp25_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_44),
.C(n_24),
.D(n_32),
.Y(n_51)
);

OAI21xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_48),
.B(n_42),
.Y(n_52)
);

AOI221xp5_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_45),
.B1(n_31),
.B2(n_23),
.C(n_18),
.Y(n_53)
);

AOI322xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_31),
.A3(n_7),
.B1(n_4),
.B2(n_2),
.C1(n_12),
.C2(n_9),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

HB1xp67_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

NOR2x1_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_14),
.Y(n_57)
);

CKINVDCx20_ASAP7_75t_R g58 ( 
.A(n_55),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_57),
.Y(n_59)
);

AOI22xp5_ASAP7_75t_L g60 ( 
.A1(n_58),
.A2(n_19),
.B1(n_56),
.B2(n_59),
.Y(n_60)
);


endmodule