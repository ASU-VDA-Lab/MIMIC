module fake_netlist_757_1389_n_27 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_27);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_27;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_24;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;

INVx1_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_2),
.B(n_3),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_7),
.B(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_17),
.B1(n_14),
.B2(n_15),
.C(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.C(n_14),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B(n_5),
.C(n_4),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_19),
.B(n_6),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_19),
.C(n_7),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_0),
.Y(n_26)
);

OAI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_1),
.B1(n_10),
.B2(n_11),
.C1(n_12),
.C2(n_21),
.Y(n_27)
);


endmodule