module fake_netlist_757_2795_n_12 (n_1, n_2, n_3, n_4, n_0, n_12);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_12;

wire n_9;
wire n_11;
wire n_10;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

AND2x2_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_SL g7 ( 
.A(n_5),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

OAI211xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_1),
.C(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI222xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C1(n_4),
.C2(n_7),
.Y(n_12)
);


endmodule