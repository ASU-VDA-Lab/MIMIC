module fake_netlist_757_258_n_49 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_49);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_49;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

AND2x4_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_13),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_0),
.B(n_7),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_5),
.A2(n_15),
.B1(n_9),
.B2(n_1),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_4),
.B(n_3),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_10),
.B(n_17),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_21),
.B1(n_26),
.B2(n_28),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_22),
.A2(n_16),
.B(n_15),
.C(n_14),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_16),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_31),
.Y(n_34)
);

OAI21x1_ASAP7_75t_SL g35 ( 
.A1(n_32),
.A2(n_33),
.B(n_29),
.Y(n_35)
);

NOR2x1_ASAP7_75t_R g36 ( 
.A(n_30),
.B(n_21),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

OAI221xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_30),
.B1(n_25),
.B2(n_22),
.C(n_27),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_21),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_38),
.Y(n_40)
);

OAI221xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_34),
.B1(n_25),
.B2(n_27),
.C(n_35),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI21xp33_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_39),
.B(n_17),
.Y(n_43)
);

OAI22xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_23),
.B1(n_19),
.B2(n_18),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_44),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_45),
.B1(n_23),
.B2(n_19),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_SL g48 ( 
.A1(n_47),
.A2(n_12),
.B1(n_8),
.B2(n_6),
.Y(n_48)
);

INVxp67_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);


endmodule