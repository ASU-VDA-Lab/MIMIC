module fake_netlist_757_2220_n_34 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_34);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_34;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_7),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_12),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_8),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_5),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_SL g24 ( 
.A(n_21),
.B(n_13),
.C(n_0),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_17),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

NAND2x1_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_18),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_23),
.B1(n_19),
.B2(n_13),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_28),
.Y(n_30)
);

AOI211xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_26),
.B(n_2),
.C(n_1),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.Y(n_34)
);


endmodule