module fake_netlist_757_767_n_181 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_28, n_27, n_24, n_10, n_5, n_26, n_6, n_31, n_30, n_2, n_3, n_9, n_4, n_25, n_7, n_17, n_21, n_12, n_15, n_19, n_29, n_32, n_0, n_8, n_181);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_28;
input n_27;
input n_24;
input n_10;
input n_5;
input n_26;
input n_6;
input n_31;
input n_30;
input n_2;
input n_3;
input n_9;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_29;
input n_32;
input n_0;
input n_8;

output n_181;

wire n_77;
wire n_71;
wire n_80;
wire n_62;
wire n_156;
wire n_36;
wire n_175;
wire n_153;
wire n_81;
wire n_106;
wire n_104;
wire n_68;
wire n_73;
wire n_176;
wire n_173;
wire n_112;
wire n_127;
wire n_139;
wire n_155;
wire n_94;
wire n_105;
wire n_60;
wire n_53;
wire n_57;
wire n_41;
wire n_157;
wire n_119;
wire n_84;
wire n_86;
wire n_55;
wire n_131;
wire n_126;
wire n_151;
wire n_140;
wire n_46;
wire n_64;
wire n_82;
wire n_76;
wire n_108;
wire n_72;
wire n_145;
wire n_51;
wire n_102;
wire n_98;
wire n_78;
wire n_97;
wire n_118;
wire n_75;
wire n_42;
wire n_132;
wire n_85;
wire n_160;
wire n_33;
wire n_147;
wire n_95;
wire n_180;
wire n_149;
wire n_174;
wire n_70;
wire n_63;
wire n_69;
wire n_166;
wire n_144;
wire n_100;
wire n_56;
wire n_167;
wire n_111;
wire n_125;
wire n_92;
wire n_52;
wire n_141;
wire n_136;
wire n_61;
wire n_110;
wire n_172;
wire n_45;
wire n_137;
wire n_90;
wire n_65;
wire n_148;
wire n_169;
wire n_150;
wire n_87;
wire n_117;
wire n_128;
wire n_133;
wire n_50;
wire n_96;
wire n_138;
wire n_79;
wire n_130;
wire n_35;
wire n_101;
wire n_122;
wire n_43;
wire n_165;
wire n_58;
wire n_91;
wire n_103;
wire n_123;
wire n_163;
wire n_115;
wire n_74;
wire n_121;
wire n_116;
wire n_44;
wire n_66;
wire n_159;
wire n_34;
wire n_99;
wire n_39;
wire n_48;
wire n_49;
wire n_170;
wire n_134;
wire n_114;
wire n_37;
wire n_59;
wire n_89;
wire n_161;
wire n_135;
wire n_162;
wire n_40;
wire n_109;
wire n_120;
wire n_158;
wire n_38;
wire n_124;
wire n_168;
wire n_107;
wire n_179;
wire n_154;
wire n_164;
wire n_143;
wire n_178;
wire n_129;
wire n_67;
wire n_177;
wire n_171;
wire n_142;
wire n_47;
wire n_88;
wire n_152;
wire n_93;
wire n_146;
wire n_54;
wire n_83;
wire n_113;

INVx1_ASAP7_75t_L g33 ( 
.A(n_3),
.Y(n_33)
);

INVxp33_ASAP7_75t_L g34 ( 
.A(n_0),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_6),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

CKINVDCx14_ASAP7_75t_R g37 ( 
.A(n_28),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_5),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_12),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_17),
.Y(n_40)
);

INVxp67_ASAP7_75t_SL g41 ( 
.A(n_26),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_19),
.Y(n_42)
);

INVxp67_ASAP7_75t_SL g43 ( 
.A(n_19),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_4),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_7),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_11),
.Y(n_46)
);

NOR2xp67_ASAP7_75t_L g47 ( 
.A(n_38),
.B(n_0),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_37),
.Y(n_48)
);

CKINVDCx5p33_ASAP7_75t_R g49 ( 
.A(n_37),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_38),
.B(n_1),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_44),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_44),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

AO22x2_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_46),
.B1(n_45),
.B2(n_42),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_38),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_48),
.B(n_36),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_51),
.A2(n_43),
.B1(n_34),
.B2(n_35),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_50),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_50),
.Y(n_59)
);

AOI22xp5_ASAP7_75t_L g60 ( 
.A1(n_52),
.A2(n_43),
.B1(n_34),
.B2(n_35),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_SL g61 ( 
.A(n_49),
.B(n_38),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_50),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_55),
.B(n_58),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_SL g64 ( 
.A(n_56),
.B(n_57),
.Y(n_64)
);

NOR2xp33_ASAP7_75t_L g65 ( 
.A(n_61),
.B(n_52),
.Y(n_65)
);

BUFx6f_ASAP7_75t_L g66 ( 
.A(n_59),
.Y(n_66)
);

AOI22xp33_ASAP7_75t_L g67 ( 
.A1(n_54),
.A2(n_47),
.B1(n_45),
.B2(n_42),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_55),
.Y(n_68)
);

INVx3_ASAP7_75t_SL g69 ( 
.A(n_54),
.Y(n_69)
);

O2A1O1Ixp33_ASAP7_75t_L g70 ( 
.A1(n_59),
.A2(n_46),
.B(n_45),
.C(n_42),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_SL g71 ( 
.A(n_57),
.B(n_60),
.Y(n_71)
);

NAND3xp33_ASAP7_75t_SL g72 ( 
.A(n_53),
.B(n_46),
.C(n_33),
.Y(n_72)
);

OAI21x1_ASAP7_75t_L g73 ( 
.A1(n_62),
.A2(n_70),
.B(n_67),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_SL g74 ( 
.A(n_69),
.B(n_36),
.Y(n_74)
);

INVx2_ASAP7_75t_L g75 ( 
.A(n_66),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_66),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_66),
.Y(n_77)
);

INVx3_ASAP7_75t_L g78 ( 
.A(n_66),
.Y(n_78)
);

AND2x2_ASAP7_75t_L g79 ( 
.A(n_69),
.B(n_54),
.Y(n_79)
);

CKINVDCx6p67_ASAP7_75t_R g80 ( 
.A(n_69),
.Y(n_80)
);

AOI22xp33_ASAP7_75t_L g81 ( 
.A1(n_71),
.A2(n_54),
.B1(n_47),
.B2(n_33),
.Y(n_81)
);

CKINVDCx20_ASAP7_75t_R g82 ( 
.A(n_64),
.Y(n_82)
);

AND2x2_ASAP7_75t_L g83 ( 
.A(n_79),
.B(n_68),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_76),
.Y(n_84)
);

AND2x4_ASAP7_75t_L g85 ( 
.A(n_79),
.B(n_68),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_76),
.Y(n_86)
);

INVxp67_ASAP7_75t_L g87 ( 
.A(n_74),
.Y(n_87)
);

NAND2xp33_ASAP7_75t_R g88 ( 
.A(n_79),
.B(n_65),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_76),
.Y(n_89)
);

NAND3xp33_ASAP7_75t_L g90 ( 
.A(n_81),
.B(n_66),
.C(n_70),
.Y(n_90)
);

OAI22xp5_ASAP7_75t_L g91 ( 
.A1(n_90),
.A2(n_81),
.B1(n_82),
.B2(n_62),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_84),
.Y(n_92)
);

INVx2_ASAP7_75t_L g93 ( 
.A(n_85),
.Y(n_93)
);

INVx1_ASAP7_75t_L g94 ( 
.A(n_84),
.Y(n_94)
);

NAND2xp5_ASAP7_75t_L g95 ( 
.A(n_83),
.B(n_68),
.Y(n_95)
);

OA21x2_ASAP7_75t_L g96 ( 
.A1(n_86),
.A2(n_77),
.B(n_76),
.Y(n_96)
);

AOI22xp5_ASAP7_75t_L g97 ( 
.A1(n_88),
.A2(n_82),
.B1(n_74),
.B2(n_81),
.Y(n_97)
);

AND2x2_ASAP7_75t_L g98 ( 
.A(n_93),
.B(n_83),
.Y(n_98)
);

AND2x4_ASAP7_75t_L g99 ( 
.A(n_93),
.B(n_85),
.Y(n_99)
);

INVx1_ASAP7_75t_L g100 ( 
.A(n_96),
.Y(n_100)
);

NAND2xp5_ASAP7_75t_L g101 ( 
.A(n_95),
.B(n_85),
.Y(n_101)
);

OR2x2_ASAP7_75t_L g102 ( 
.A(n_91),
.B(n_87),
.Y(n_102)
);

AND2x2_ASAP7_75t_L g103 ( 
.A(n_93),
.B(n_85),
.Y(n_103)
);

INVx2_ASAP7_75t_L g104 ( 
.A(n_96),
.Y(n_104)
);

AND2x2_ASAP7_75t_L g105 ( 
.A(n_97),
.B(n_87),
.Y(n_105)
);

HB1xp67_ASAP7_75t_L g106 ( 
.A(n_103),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_100),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_100),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_100),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_104),
.Y(n_110)
);

INVx4_ASAP7_75t_L g111 ( 
.A(n_99),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_104),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_104),
.Y(n_113)
);

HB1xp67_ASAP7_75t_L g114 ( 
.A(n_103),
.Y(n_114)
);

AND2x2_ASAP7_75t_L g115 ( 
.A(n_105),
.B(n_103),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_104),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_102),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_98),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_107),
.Y(n_119)
);

OAI22xp5_ASAP7_75t_L g120 ( 
.A1(n_117),
.A2(n_102),
.B1(n_91),
.B2(n_90),
.Y(n_120)
);

O2A1O1Ixp33_ASAP7_75t_L g121 ( 
.A1(n_108),
.A2(n_72),
.B(n_40),
.C(n_39),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_108),
.Y(n_122)
);

OAI221xp5_ASAP7_75t_L g123 ( 
.A1(n_118),
.A2(n_72),
.B1(n_40),
.B2(n_39),
.C(n_41),
.Y(n_123)
);

OAI21xp33_ASAP7_75t_L g124 ( 
.A1(n_109),
.A2(n_41),
.B(n_74),
.Y(n_124)
);

INVx1_ASAP7_75t_SL g125 ( 
.A(n_106),
.Y(n_125)
);

OAI22xp5_ASAP7_75t_L g126 ( 
.A1(n_111),
.A2(n_101),
.B1(n_94),
.B2(n_92),
.Y(n_126)
);

NOR2xp33_ASAP7_75t_L g127 ( 
.A(n_115),
.B(n_92),
.Y(n_127)
);

OAI22xp33_ASAP7_75t_SL g128 ( 
.A1(n_114),
.A2(n_94),
.B1(n_89),
.B2(n_86),
.Y(n_128)
);

OR2x2_ASAP7_75t_L g129 ( 
.A(n_110),
.B(n_96),
.Y(n_129)
);

AOI332xp33_ASAP7_75t_L g130 ( 
.A1(n_110),
.A2(n_2),
.A3(n_7),
.B1(n_5),
.B2(n_6),
.B3(n_3),
.C1(n_1),
.C2(n_4),
.Y(n_130)
);

AND2x2_ASAP7_75t_L g131 ( 
.A(n_112),
.B(n_96),
.Y(n_131)
);

NAND2xp5_ASAP7_75t_L g132 ( 
.A(n_125),
.B(n_113),
.Y(n_132)
);

NAND2xp5_ASAP7_75t_L g133 ( 
.A(n_127),
.B(n_113),
.Y(n_133)
);

NAND3xp33_ASAP7_75t_L g134 ( 
.A(n_121),
.B(n_116),
.C(n_89),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_119),
.Y(n_135)
);

AND2x2_ASAP7_75t_L g136 ( 
.A(n_131),
.B(n_122),
.Y(n_136)
);

NAND2xp5_ASAP7_75t_SL g137 ( 
.A(n_128),
.B(n_99),
.Y(n_137)
);

HB1xp67_ASAP7_75t_L g138 ( 
.A(n_126),
.Y(n_138)
);

NAND3xp33_ASAP7_75t_L g139 ( 
.A(n_123),
.B(n_130),
.C(n_124),
.Y(n_139)
);

INVx1_ASAP7_75t_L g140 ( 
.A(n_129),
.Y(n_140)
);

OR2x2_ASAP7_75t_L g141 ( 
.A(n_129),
.B(n_8),
.Y(n_141)
);

NAND2xp5_ASAP7_75t_L g142 ( 
.A(n_125),
.B(n_9),
.Y(n_142)
);

OR2x6_ASAP7_75t_L g143 ( 
.A(n_120),
.B(n_75),
.Y(n_143)
);

INVx2_ASAP7_75t_SL g144 ( 
.A(n_119),
.Y(n_144)
);

INVxp67_ASAP7_75t_L g145 ( 
.A(n_125),
.Y(n_145)
);

NAND2xp5_ASAP7_75t_SL g146 ( 
.A(n_125),
.B(n_75),
.Y(n_146)
);

INVxp67_ASAP7_75t_L g147 ( 
.A(n_125),
.Y(n_147)
);

A2O1A1Ixp33_ASAP7_75t_L g148 ( 
.A1(n_139),
.A2(n_73),
.B(n_79),
.C(n_9),
.Y(n_148)
);

OAI22xp5_ASAP7_75t_L g149 ( 
.A1(n_139),
.A2(n_80),
.B1(n_75),
.B2(n_77),
.Y(n_149)
);

AOI221xp5_ASAP7_75t_L g150 ( 
.A1(n_138),
.A2(n_13),
.B1(n_10),
.B2(n_14),
.C(n_15),
.Y(n_150)
);

O2A1O1Ixp33_ASAP7_75t_L g151 ( 
.A1(n_142),
.A2(n_78),
.B(n_63),
.C(n_15),
.Y(n_151)
);

OAI222xp33_ASAP7_75t_L g152 ( 
.A1(n_143),
.A2(n_17),
.B1(n_16),
.B2(n_18),
.C1(n_21),
.C2(n_20),
.Y(n_152)
);

NOR4xp25_ASAP7_75t_L g153 ( 
.A(n_141),
.B(n_147),
.C(n_145),
.D(n_140),
.Y(n_153)
);

NAND3xp33_ASAP7_75t_SL g154 ( 
.A(n_134),
.B(n_137),
.C(n_146),
.Y(n_154)
);

AOI221xp5_ASAP7_75t_L g155 ( 
.A1(n_140),
.A2(n_18),
.B1(n_16),
.B2(n_20),
.C(n_21),
.Y(n_155)
);

OAI211xp5_ASAP7_75t_L g156 ( 
.A1(n_133),
.A2(n_24),
.B(n_23),
.C(n_22),
.Y(n_156)
);

OAI22xp5_ASAP7_75t_L g157 ( 
.A1(n_143),
.A2(n_80),
.B1(n_78),
.B2(n_22),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_135),
.Y(n_158)
);

AOI22xp5_ASAP7_75t_L g159 ( 
.A1(n_143),
.A2(n_78),
.B1(n_73),
.B2(n_80),
.Y(n_159)
);

AOI221xp5_ASAP7_75t_L g160 ( 
.A1(n_144),
.A2(n_78),
.B1(n_30),
.B2(n_25),
.C(n_29),
.Y(n_160)
);

NOR2x1p5_ASAP7_75t_L g161 ( 
.A(n_154),
.B(n_132),
.Y(n_161)
);

AOI221xp5_ASAP7_75t_L g162 ( 
.A1(n_153),
.A2(n_136),
.B1(n_32),
.B2(n_31),
.C(n_80),
.Y(n_162)
);

OAI31xp33_ASAP7_75t_L g163 ( 
.A1(n_156),
.A2(n_148),
.A3(n_152),
.B(n_151),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_158),
.Y(n_164)
);

AOI22xp5_ASAP7_75t_L g165 ( 
.A1(n_154),
.A2(n_150),
.B1(n_155),
.B2(n_157),
.Y(n_165)
);

AOI22xp5_ASAP7_75t_L g166 ( 
.A1(n_160),
.A2(n_149),
.B1(n_139),
.B2(n_154),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_L g167 ( 
.A(n_159),
.B(n_153),
.Y(n_167)
);

NAND2xp5_ASAP7_75t_SL g168 ( 
.A(n_153),
.B(n_145),
.Y(n_168)
);

NAND3xp33_ASAP7_75t_SL g169 ( 
.A(n_151),
.B(n_130),
.C(n_150),
.Y(n_169)
);

BUFx2_ASAP7_75t_L g170 ( 
.A(n_164),
.Y(n_170)
);

AOI22xp33_ASAP7_75t_L g171 ( 
.A1(n_169),
.A2(n_162),
.B1(n_163),
.B2(n_166),
.Y(n_171)
);

CKINVDCx5p33_ASAP7_75t_R g172 ( 
.A(n_168),
.Y(n_172)
);

HB1xp67_ASAP7_75t_L g173 ( 
.A(n_161),
.Y(n_173)
);

CKINVDCx5p33_ASAP7_75t_R g174 ( 
.A(n_165),
.Y(n_174)
);

CKINVDCx20_ASAP7_75t_R g175 ( 
.A(n_167),
.Y(n_175)
);

BUFx6f_ASAP7_75t_L g176 ( 
.A(n_169),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_170),
.Y(n_177)
);

AND2x4_ASAP7_75t_L g178 ( 
.A(n_177),
.B(n_173),
.Y(n_178)
);

AOI22xp5_ASAP7_75t_L g179 ( 
.A1(n_178),
.A2(n_176),
.B1(n_171),
.B2(n_175),
.Y(n_179)
);

AOI22xp5_ASAP7_75t_L g180 ( 
.A1(n_179),
.A2(n_176),
.B1(n_172),
.B2(n_174),
.Y(n_180)
);

AOI21xp5_ASAP7_75t_L g181 ( 
.A1(n_180),
.A2(n_176),
.B(n_174),
.Y(n_181)
);


endmodule