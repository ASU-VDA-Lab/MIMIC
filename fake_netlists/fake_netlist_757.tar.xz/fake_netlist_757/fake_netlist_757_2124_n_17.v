module fake_netlist_757_2124_n_17 (n_1, n_2, n_3, n_4, n_5, n_0, n_17);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_17;

wire n_12;
wire n_15;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_13;
wire n_7;
wire n_16;
wire n_6;
wire n_8;

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

BUFx10_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVxp67_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_SL g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_0),
.Y(n_10)
);

CKINVDCx16_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_6),
.B1(n_7),
.B2(n_11),
.C1(n_1),
.C2(n_0),
.Y(n_13)
);

OAI21xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_6),
.B(n_7),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_1),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_17)
);


endmodule