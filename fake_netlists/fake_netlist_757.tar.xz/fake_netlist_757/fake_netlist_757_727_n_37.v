module fake_netlist_757_727_n_37 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_37);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_37;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_16),
.A2(n_1),
.B1(n_15),
.B2(n_0),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_17),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_9),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_17),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_23),
.B(n_21),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_22),
.B1(n_26),
.B2(n_19),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_28),
.B2(n_24),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_24),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_SL g33 ( 
.A(n_32),
.B(n_3),
.C(n_2),
.Y(n_33)
);

NAND4xp75_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_24),
.C(n_6),
.D(n_4),
.Y(n_34)
);

NOR2x1_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_8),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_37)
);


endmodule