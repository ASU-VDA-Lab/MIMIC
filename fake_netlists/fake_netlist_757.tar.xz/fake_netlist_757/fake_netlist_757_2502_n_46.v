module fake_netlist_757_2502_n_46 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_46);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_46;

wire n_20;
wire n_23;
wire n_14;
wire n_44;
wire n_22;
wire n_36;
wire n_16;
wire n_34;
wire n_18;
wire n_13;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_15;
wire n_19;
wire n_12;
wire n_41;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_11),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_3),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_7),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_19),
.B1(n_17),
.B2(n_15),
.Y(n_23)
);

A2O1A1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_24)
);

BUFx12f_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

INVx3_ASAP7_75t_SL g26 ( 
.A(n_21),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_12),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_19),
.A2(n_10),
.B1(n_9),
.B2(n_1),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_23),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_24),
.B(n_15),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_32),
.Y(n_33)
);

NAND2x1p5_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_14),
.Y(n_34)
);

AND2x4_ASAP7_75t_SL g35 ( 
.A(n_31),
.B(n_29),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_SL g36 ( 
.A(n_33),
.B(n_28),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_32),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

AOI211xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_28),
.B(n_16),
.C(n_22),
.Y(n_39)
);

AOI221xp5_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_34),
.B1(n_22),
.B2(n_13),
.C(n_18),
.Y(n_40)
);

NOR3xp33_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_25),
.C(n_10),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_41),
.Y(n_42)
);

BUFx6f_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_SL g45 ( 
.A1(n_43),
.A2(n_37),
.B1(n_38),
.B2(n_18),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_44),
.B(n_42),
.Y(n_46)
);


endmodule