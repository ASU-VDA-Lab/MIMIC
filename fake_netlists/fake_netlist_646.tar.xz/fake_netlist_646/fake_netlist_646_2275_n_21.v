module fake_netlist_646_2275_n_21 (n_4, n_1, n_2, n_0, n_5, n_3, n_21);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_10;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

NAND2xp33_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_3),
.Y(n_6)
);

NAND2xp33_ASAP7_75t_SL g7 ( 
.A(n_4),
.B(n_3),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_1),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_SL g9 ( 
.A1(n_4),
.A2(n_2),
.B1(n_5),
.B2(n_1),
.Y(n_9)
);

OAI21xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_8),
.B(n_0),
.Y(n_11)
);

OAI21xp33_ASAP7_75t_SL g12 ( 
.A1(n_9),
.A2(n_4),
.B(n_0),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_2),
.Y(n_16)
);

NOR2x1_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_16),
.B(n_9),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B(n_19),
.Y(n_21)
);


endmodule