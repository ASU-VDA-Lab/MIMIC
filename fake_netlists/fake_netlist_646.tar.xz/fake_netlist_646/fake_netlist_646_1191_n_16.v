module fake_netlist_646_1191_n_16 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_16);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_16;

wire n_14;
wire n_10;
wire n_11;
wire n_9;
wire n_15;
wire n_13;
wire n_8;
wire n_12;

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_2),
.B1(n_5),
.B2(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B(n_10),
.C(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

OAI33xp33_ASAP7_75t_R g16 ( 
.A1(n_15),
.A2(n_8),
.A3(n_0),
.B1(n_6),
.B2(n_5),
.B3(n_1),
.Y(n_16)
);


endmodule