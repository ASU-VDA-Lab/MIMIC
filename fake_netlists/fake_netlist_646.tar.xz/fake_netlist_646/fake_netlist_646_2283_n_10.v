module fake_netlist_646_2283_n_10 (n_1, n_0, n_10);

input n_1;
input n_0;

output n_10;

wire n_9;
wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_8;
wire n_6;
wire n_3;

INVx1_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_SL g4 ( 
.A(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI22xp33_ASAP7_75t_SL g6 ( 
.A1(n_5),
.A2(n_2),
.B1(n_0),
.B2(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_1),
.Y(n_7)
);

NOR4xp25_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_4),
.C(n_5),
.D(n_0),
.Y(n_8)
);

NAND3xp33_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_4),
.C(n_0),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_R g10 ( 
.A1(n_9),
.A2(n_8),
.B1(n_0),
.B2(n_1),
.Y(n_10)
);


endmodule