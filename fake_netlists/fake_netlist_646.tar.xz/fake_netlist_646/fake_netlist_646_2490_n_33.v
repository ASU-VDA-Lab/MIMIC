module fake_netlist_646_2490_n_33 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_33);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_33;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_11;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_32;
wire n_13;

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_0),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_8),
.B(n_3),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_SL g18 ( 
.A1(n_11),
.A2(n_6),
.B(n_1),
.C(n_0),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_7),
.B(n_1),
.C(n_9),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_15),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_R g21 ( 
.A(n_18),
.B(n_13),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_15),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI211x1_ASAP7_75t_SL g27 ( 
.A1(n_25),
.A2(n_11),
.B(n_21),
.C(n_17),
.Y(n_27)
);

OAI21xp5_ASAP7_75t_SL g28 ( 
.A1(n_25),
.A2(n_24),
.B(n_23),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_24),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_26),
.B1(n_13),
.B2(n_21),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_26),
.B2(n_7),
.Y(n_33)
);


endmodule