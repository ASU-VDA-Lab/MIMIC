module fake_netlist_646_3877_n_19 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_19);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_19;

wire n_18;
wire n_10;
wire n_11;
wire n_15;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_1),
.B(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

A2O1A1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_7),
.B(n_6),
.C(n_0),
.Y(n_13)
);

BUFx8_ASAP7_75t_SL g14 ( 
.A(n_13),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

NAND4xp75_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.C(n_10),
.D(n_9),
.Y(n_16)
);

NOR2x1_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_15),
.Y(n_17)
);

AOI21xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_9),
.B(n_2),
.Y(n_18)
);

AO21x2_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_4),
.B(n_3),
.Y(n_19)
);


endmodule