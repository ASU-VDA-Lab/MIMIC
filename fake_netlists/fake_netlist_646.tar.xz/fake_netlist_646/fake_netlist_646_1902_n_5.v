module fake_netlist_646_1902_n_5 (n_1, n_2, n_0, n_5);

input n_1;
input n_2;
input n_0;

output n_5;

wire n_4;
wire n_3;

NAND2x1p5_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);


endmodule