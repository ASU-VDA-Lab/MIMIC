module fake_netlist_646_3063_n_9 (n_4, n_1, n_2, n_0, n_3, n_9);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_9;

wire n_7;
wire n_5;
wire n_8;
wire n_6;

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_4),
.Y(n_5)
);

OAI22xp5_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

AOI22x1_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B1(n_7),
.B2(n_6),
.Y(n_9)
);


endmodule