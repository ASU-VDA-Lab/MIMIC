module fake_netlist_646_4289_n_9 (n_1, n_2, n_0, n_9);

input n_1;
input n_2;
input n_0;

output n_9;

wire n_4;
wire n_7;
wire n_5;
wire n_8;
wire n_6;
wire n_3;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

AOI21xp5_ASAP7_75t_L g4 ( 
.A1(n_0),
.A2(n_2),
.B(n_1),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_1),
.Y(n_5)
);

AND2x4_ASAP7_75t_SL g6 ( 
.A(n_4),
.B(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_SL g7 ( 
.A(n_5),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_2),
.B1(n_6),
.B2(n_7),
.Y(n_9)
);


endmodule