module fake_netlist_646_967_n_17 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_17);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_17;

wire n_14;
wire n_10;
wire n_15;
wire n_11;
wire n_9;
wire n_13;
wire n_16;
wire n_12;

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_3),
.B(n_2),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_2),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B1(n_11),
.B2(n_0),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B1(n_11),
.B2(n_1),
.C(n_3),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B(n_4),
.C(n_1),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_5),
.B2(n_6),
.C1(n_14),
.C2(n_9),
.Y(n_17)
);


endmodule