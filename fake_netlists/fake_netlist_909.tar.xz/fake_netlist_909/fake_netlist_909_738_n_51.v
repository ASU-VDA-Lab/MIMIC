module fake_netlist_909_738_n_51 (n_3, n_15, n_11, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_51);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_51;

wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_28;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

INVx5_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_9),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_0),
.Y(n_27)
);

OA21x2_ASAP7_75t_L g28 ( 
.A1(n_11),
.A2(n_18),
.B(n_13),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_4),
.B(n_20),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_25),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_19),
.Y(n_34)
);

INVx4_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

OAI21xp5_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_31),
.B(n_27),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_24),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_34),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_33),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_26),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

OAI221xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_28),
.B1(n_26),
.B2(n_1),
.C(n_3),
.Y(n_44)
);

AOI21xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_6),
.B(n_5),
.Y(n_45)
);

NOR3xp33_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_8),
.C(n_7),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_45),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_14),
.B1(n_12),
.B2(n_10),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_15),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_49),
.Y(n_50)
);

AOI22x1_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_48),
.B1(n_23),
.B2(n_16),
.Y(n_51)
);


endmodule