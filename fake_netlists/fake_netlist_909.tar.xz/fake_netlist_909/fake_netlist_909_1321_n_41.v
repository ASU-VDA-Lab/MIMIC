module fake_netlist_909_1321_n_41 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_41);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_41;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_19),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_11),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_5),
.B(n_7),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_12),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

OAI21x1_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_2),
.B(n_1),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_21),
.B(n_0),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_22),
.A2(n_4),
.B(n_3),
.Y(n_30)
);

BUFx10_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_27),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_24),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_22),
.B1(n_23),
.B2(n_26),
.Y(n_34)
);

OAI221xp5_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_25),
.B1(n_31),
.B2(n_0),
.C(n_16),
.Y(n_35)
);

OAI211xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_28),
.B(n_31),
.C(n_17),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_SL g37 ( 
.A1(n_35),
.A2(n_31),
.B1(n_28),
.B2(n_17),
.C(n_18),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_19),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_8),
.B(n_6),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_SL g40 ( 
.A1(n_38),
.A2(n_20),
.B1(n_10),
.B2(n_9),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_13),
.B1(n_14),
.B2(n_15),
.C1(n_38),
.C2(n_39),
.Y(n_41)
);


endmodule