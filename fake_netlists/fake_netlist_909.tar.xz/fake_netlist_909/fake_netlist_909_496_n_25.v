module fake_netlist_909_496_n_25 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_25;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

OAI22xp33_ASAP7_75t_L g12 ( 
.A1(n_4),
.A2(n_1),
.B1(n_3),
.B2(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_4),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_2),
.B(n_8),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_13),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

BUFx2_ASAP7_75t_SL g19 ( 
.A(n_16),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_12),
.B1(n_11),
.B2(n_15),
.C(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_12),
.C(n_18),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_11),
.B1(n_19),
.B2(n_18),
.C(n_6),
.Y(n_23)
);

INVxp67_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

AOI21xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_7),
.B(n_10),
.Y(n_25)
);


endmodule