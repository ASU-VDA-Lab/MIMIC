module fake_netlist_909_1019_n_40 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_40);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_40;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_20;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

BUFx10_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_18),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_6),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_3),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_5),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_10),
.Y(n_27)
);

OAI21xp33_ASAP7_75t_L g28 ( 
.A1(n_21),
.A2(n_1),
.B(n_0),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_23),
.A2(n_25),
.B(n_24),
.Y(n_29)
);

AOI33xp33_ASAP7_75t_L g30 ( 
.A1(n_20),
.A2(n_17),
.A3(n_16),
.B1(n_14),
.B2(n_7),
.B3(n_2),
.Y(n_30)
);

INVx4_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_SL g32 ( 
.A(n_30),
.B(n_22),
.C(n_26),
.Y(n_32)
);

NOR2x1p5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_27),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_31),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_28),
.B1(n_20),
.B2(n_16),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_9),
.B(n_8),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_35),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_36),
.Y(n_38)
);

CKINVDCx20_ASAP7_75t_R g39 ( 
.A(n_37),
.Y(n_39)
);

AOI222xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.B1(n_15),
.B2(n_12),
.C1(n_19),
.C2(n_13),
.Y(n_40)
);


endmodule