module fake_netlist_909_1370_n_14 (n_0, n_2, n_3, n_4, n_1, n_14);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_14;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_0),
.Y(n_5)
);

AND3x2_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_3),
.C(n_4),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_1),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI21xp33_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_5),
.B(n_7),
.Y(n_10)
);

NOR2x1_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_6),
.Y(n_11)
);

NOR3x1_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_6),
.C(n_0),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_2),
.B1(n_3),
.B2(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);


endmodule