module fake_netlist_909_1408_n_31 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_31);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_31;

wire n_15;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_22;
wire n_25;
wire n_26;
wire n_29;

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_4),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_3),
.B(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_19),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_15),
.B1(n_17),
.B2(n_20),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_15),
.B1(n_22),
.B2(n_6),
.Y(n_26)
);

OAI211xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_7),
.B(n_6),
.C(n_10),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI22x1_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_7),
.B1(n_12),
.B2(n_11),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_29),
.A2(n_13),
.B1(n_14),
.B2(n_30),
.Y(n_31)
);


endmodule