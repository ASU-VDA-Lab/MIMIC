module fake_netlist_909_622_n_17 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_17);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_17;

wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

AND3x2_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_4),
.C(n_1),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_1),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_3),
.B(n_4),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_9),
.B2(n_11),
.C(n_8),
.Y(n_14)
);

CKINVDCx14_ASAP7_75t_R g15 ( 
.A(n_14),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B(n_12),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_5),
.B1(n_6),
.B2(n_8),
.C1(n_14),
.C2(n_15),
.Y(n_17)
);


endmodule