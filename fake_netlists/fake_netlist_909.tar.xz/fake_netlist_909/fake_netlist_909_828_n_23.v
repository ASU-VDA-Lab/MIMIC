module fake_netlist_909_828_n_23 (n_0, n_2, n_3, n_4, n_1, n_23);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_23;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_19;
wire n_12;
wire n_5;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

NAND3xp33_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.C(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NAND3x1_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_1),
.C(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_1),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_5),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_10),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_14),
.B1(n_12),
.B2(n_1),
.Y(n_17)
);

AOI211xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_3),
.B(n_13),
.C(n_16),
.Y(n_18)
);

INVxp33_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

O2A1O1Ixp33_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_20),
.B(n_21),
.C(n_19),
.Y(n_23)
);


endmodule