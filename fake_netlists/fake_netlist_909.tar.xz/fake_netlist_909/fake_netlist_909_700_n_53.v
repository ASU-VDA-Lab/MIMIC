module fake_netlist_909_700_n_53 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_53);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_53;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_41;
wire n_43;
wire n_26;
wire n_36;
wire n_44;
wire n_29;
wire n_45;
wire n_48;
wire n_38;

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_10),
.B(n_21),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_1),
.B(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_14),
.A2(n_18),
.B(n_11),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_2),
.B(n_21),
.Y(n_30)
);

AND2x6_ASAP7_75t_L g31 ( 
.A(n_0),
.B(n_19),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_28),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_24),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_22),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_31),
.B1(n_24),
.B2(n_25),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_32),
.A2(n_27),
.B(n_23),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_30),
.B(n_31),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_35),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_36),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_36),
.Y(n_42)
);

INVxp33_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

O2A1O1Ixp33_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_17),
.B(n_33),
.C(n_29),
.Y(n_45)
);

XOR2x2_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_17),
.Y(n_46)
);

OAI322xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_29),
.A3(n_7),
.B1(n_6),
.B2(n_4),
.C1(n_12),
.C2(n_8),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

CKINVDCx6p67_ASAP7_75t_R g49 ( 
.A(n_46),
.Y(n_49)
);

NAND3xp33_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_33),
.C(n_13),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

OA21x2_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_51),
.B(n_49),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);


endmodule