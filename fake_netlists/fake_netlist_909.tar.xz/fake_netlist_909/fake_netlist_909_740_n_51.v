module fake_netlist_909_740_n_51 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_51);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_51;

wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_21;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

INVx2_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

INVx5_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_1),
.B(n_10),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_5),
.B(n_7),
.Y(n_20)
);

AND2x6_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_6),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_0),
.B(n_9),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_2),
.B(n_3),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_3),
.A2(n_13),
.B1(n_14),
.B2(n_8),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_16),
.B(n_0),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_1),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

NAND3xp33_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_22),
.C(n_23),
.Y(n_30)
);

AOI221xp5_ASAP7_75t_L g31 ( 
.A1(n_26),
.A2(n_24),
.B1(n_23),
.B2(n_22),
.C(n_19),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_26),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx4_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_25),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_34),
.B1(n_21),
.B2(n_20),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_21),
.B1(n_20),
.B2(n_18),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_35),
.B(n_20),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_39),
.Y(n_42)
);

XNOR2x1_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_37),
.Y(n_43)
);

NOR2x1p5_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_35),
.Y(n_44)
);

NOR3xp33_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_35),
.C(n_43),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_15),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_17),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_21),
.B1(n_17),
.B2(n_27),
.Y(n_49)
);

OAI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_47),
.A2(n_17),
.B1(n_21),
.B2(n_4),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_48),
.B1(n_49),
.B2(n_21),
.Y(n_51)
);


endmodule