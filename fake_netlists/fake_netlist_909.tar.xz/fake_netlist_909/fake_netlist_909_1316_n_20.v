module fake_netlist_909_1316_n_20 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_20);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_20;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_17;
wire n_18;
wire n_13;
wire n_14;

CKINVDCx16_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_7),
.B(n_10),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_3),
.Y(n_13)
);

AND2x6_ASAP7_75t_L g14 ( 
.A(n_4),
.B(n_9),
.Y(n_14)
);

OR2x6_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_1),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_11),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_12),
.B(n_14),
.Y(n_17)
);

XNOR2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_2),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_14),
.Y(n_19)
);

AOI21xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_6),
.B(n_5),
.Y(n_20)
);


endmodule