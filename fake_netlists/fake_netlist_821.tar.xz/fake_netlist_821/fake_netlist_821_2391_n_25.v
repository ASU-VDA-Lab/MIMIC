module fake_netlist_821_2391_n_25 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_25);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_25;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_9;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_1),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_2),
.B(n_1),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_2),
.Y(n_14)
);

O2A1O1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_9),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx2_ASAP7_75t_SL g19 ( 
.A(n_18),
.Y(n_19)
);

INVxp67_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

O2A1O1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_15),
.B(n_10),
.C(n_13),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_20),
.Y(n_22)
);

BUFx8_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

OAI22x1_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_21),
.B1(n_17),
.B2(n_5),
.Y(n_24)
);

AO22x2_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_22),
.B1(n_23),
.B2(n_19),
.Y(n_25)
);


endmodule