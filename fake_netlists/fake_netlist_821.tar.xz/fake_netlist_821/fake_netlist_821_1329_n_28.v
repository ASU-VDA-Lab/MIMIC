module fake_netlist_821_1329_n_28 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_28);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_13),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_7),
.B(n_4),
.C(n_0),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_R g21 ( 
.A(n_20),
.B(n_15),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NOR2x1_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_18),
.Y(n_23)
);

AOI211xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_19),
.B(n_17),
.C(n_16),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_R g25 ( 
.A1(n_24),
.A2(n_18),
.B1(n_14),
.B2(n_2),
.C(n_3),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_25),
.B1(n_10),
.B2(n_8),
.Y(n_28)
);


endmodule