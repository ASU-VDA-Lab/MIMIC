module fake_netlist_821_1268_n_43 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_43);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_43;

wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;

INVx1_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_9),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_SL g16 ( 
.A1(n_6),
.A2(n_5),
.B1(n_1),
.B2(n_10),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_6),
.B(n_8),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_0),
.Y(n_19)
);

BUFx12f_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_17),
.B(n_0),
.Y(n_22)
);

O2A1O1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_14),
.B(n_21),
.C(n_19),
.Y(n_23)
);

INVx4_ASAP7_75t_SL g24 ( 
.A(n_20),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_24),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_26),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

OAI21xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_14),
.B(n_18),
.Y(n_32)
);

AO22x2_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_16),
.B1(n_21),
.B2(n_20),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_29),
.A2(n_21),
.B1(n_15),
.B2(n_2),
.C(n_4),
.Y(n_34)
);

NOR2x1p5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_30),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_2),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_4),
.Y(n_37)
);

XNOR2xp5_ASAP7_75t_SL g38 ( 
.A(n_35),
.B(n_5),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_3),
.B1(n_7),
.B2(n_39),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_7),
.B(n_38),
.Y(n_42)
);

XNOR2xp5_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_41),
.Y(n_43)
);


endmodule