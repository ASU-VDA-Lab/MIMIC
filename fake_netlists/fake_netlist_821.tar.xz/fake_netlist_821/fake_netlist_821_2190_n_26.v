module fake_netlist_821_2190_n_26 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_26);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_5),
.B(n_9),
.Y(n_13)
);

AOI21x1_ASAP7_75t_L g14 ( 
.A1(n_3),
.A2(n_12),
.B(n_6),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_5),
.B(n_6),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_16),
.B(n_4),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.B1(n_15),
.B2(n_13),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_18),
.Y(n_21)
);

O2A1O1Ixp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_17),
.B(n_7),
.C(n_4),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_7),
.C(n_0),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_24),
.B(n_1),
.Y(n_25)
);

OAI31xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_8),
.A3(n_11),
.B(n_19),
.Y(n_26)
);


endmodule