module fake_netlist_821_1829_n_12 (n_2, n_0, n_1, n_12);

input n_2;
input n_0;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_8;

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_0),
.B(n_2),
.Y(n_3)
);

AND2x6_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_1),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

AOI21xp5_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_2),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_9)
);

AOI32xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.A3(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI222xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_2),
.B2(n_4),
.C1(n_10),
.C2(n_0),
.Y(n_12)
);


endmodule