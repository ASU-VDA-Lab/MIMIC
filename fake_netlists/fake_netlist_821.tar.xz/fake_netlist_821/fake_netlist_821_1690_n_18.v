module fake_netlist_821_1690_n_18 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_18);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_18;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;
wire n_9;

AND2x6_ASAP7_75t_L g9 ( 
.A(n_1),
.B(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

AND2x2_ASAP7_75t_SL g12 ( 
.A(n_7),
.B(n_8),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_7),
.B(n_6),
.Y(n_13)
);

INVx4_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B(n_9),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B(n_9),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_9),
.B1(n_6),
.B2(n_5),
.C1(n_3),
.C2(n_2),
.Y(n_18)
);


endmodule