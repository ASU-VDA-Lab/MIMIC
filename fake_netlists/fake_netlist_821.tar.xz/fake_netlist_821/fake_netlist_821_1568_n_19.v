module fake_netlist_821_1568_n_19 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_19);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_2),
.B(n_1),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_3),
.B(n_8),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_5),
.A2(n_8),
.B(n_9),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_2),
.A2(n_6),
.B1(n_0),
.B2(n_1),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_3),
.B(n_6),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_0),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_4),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_14),
.B(n_10),
.C(n_13),
.Y(n_17)
);

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.C(n_12),
.Y(n_18)
);

OAI321xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_4),
.A3(n_5),
.B1(n_7),
.B2(n_15),
.C(n_17),
.Y(n_19)
);


endmodule