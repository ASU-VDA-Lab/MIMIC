module fake_netlist_821_2317_n_14 (n_2, n_0, n_1, n_14);

input n_2;
input n_0;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

AND2x6_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_5),
.B1(n_4),
.B2(n_6),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

OAI221xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_6),
.B2(n_1),
.C(n_2),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_9),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_2),
.B1(n_6),
.B2(n_11),
.C1(n_4),
.C2(n_12),
.Y(n_14)
);


endmodule