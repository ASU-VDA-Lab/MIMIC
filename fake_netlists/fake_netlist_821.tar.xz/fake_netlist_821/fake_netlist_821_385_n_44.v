module fake_netlist_821_385_n_44 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_44);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_44;

wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_8),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_0),
.Y(n_24)
);

AND2x6_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_6),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_22),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_15),
.B(n_19),
.C(n_14),
.Y(n_27)
);

INVx4_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

OAI221xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_23),
.B1(n_21),
.B2(n_14),
.C(n_18),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_20),
.B(n_18),
.Y(n_30)
);

AND2x6_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_21),
.Y(n_31)
);

NOR4xp25_ASAP7_75t_SL g32 ( 
.A(n_29),
.B(n_23),
.C(n_25),
.D(n_22),
.Y(n_32)
);

NAND2x1p5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_17),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.B1(n_25),
.B2(n_17),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_31),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_33),
.B(n_28),
.Y(n_36)
);

NOR3xp33_ASAP7_75t_SL g37 ( 
.A(n_34),
.B(n_16),
.C(n_1),
.Y(n_37)
);

AND2x2_ASAP7_75t_SL g38 ( 
.A(n_34),
.B(n_17),
.Y(n_38)
);

OAI311xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_8),
.A3(n_2),
.B1(n_9),
.C1(n_10),
.Y(n_39)
);

OAI22xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_28),
.B1(n_12),
.B2(n_11),
.Y(n_40)
);

OAI211xp5_ASAP7_75t_SL g41 ( 
.A1(n_40),
.A2(n_36),
.B(n_13),
.C(n_11),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_39),
.Y(n_42)
);

INVx4_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_42),
.B1(n_41),
.B2(n_40),
.Y(n_44)
);


endmodule