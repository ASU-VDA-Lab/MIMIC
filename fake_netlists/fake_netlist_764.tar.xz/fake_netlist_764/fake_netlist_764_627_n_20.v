module fake_netlist_764_627_n_20 (n_0, n_2, n_1, n_3, n_20);

input n_0;
input n_2;
input n_1;
input n_3;

output n_20;

wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_4;
wire n_7;
wire n_17;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

HB1xp67_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx4_ASAP7_75t_SL g5 ( 
.A(n_0),
.Y(n_5)
);

INVx4_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_SL g8 ( 
.A(n_4),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_6),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_6),
.B(n_5),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_8),
.B1(n_6),
.B2(n_5),
.C(n_2),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_9),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_SL g16 ( 
.A(n_14),
.B(n_13),
.C(n_12),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_5),
.B1(n_3),
.B2(n_2),
.C(n_9),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

AOI222xp33_ASAP7_75t_SL g20 ( 
.A1(n_18),
.A2(n_3),
.B1(n_5),
.B2(n_15),
.C1(n_19),
.C2(n_8),
.Y(n_20)
);


endmodule