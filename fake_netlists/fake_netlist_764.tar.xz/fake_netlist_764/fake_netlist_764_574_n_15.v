module fake_netlist_764_574_n_15 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_11;
wire n_9;
wire n_10;
wire n_7;
wire n_13;
wire n_8;

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

BUFx3_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_8),
.Y(n_11)
);

AOI21xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_4),
.B(n_1),
.Y(n_12)
);

AOI211x1_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_7),
.B(n_4),
.C(n_1),
.Y(n_13)
);

OAI31xp67_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_7),
.A3(n_6),
.B(n_9),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_3),
.B(n_2),
.Y(n_15)
);


endmodule