module fake_netlist_764_1039_n_18 (n_1, n_2, n_3, n_4, n_5, n_0, n_18);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_18;

wire n_12;
wire n_15;
wire n_14;
wire n_9;
wire n_11;
wire n_13;
wire n_7;
wire n_16;
wire n_10;
wire n_17;
wire n_6;
wire n_8;

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx5_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_0),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_7),
.B(n_6),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_2),
.B(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_8),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

OAI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B(n_13),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B1(n_8),
.B2(n_10),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_R g18 ( 
.A1(n_17),
.A2(n_5),
.B1(n_2),
.B2(n_15),
.Y(n_18)
);


endmodule