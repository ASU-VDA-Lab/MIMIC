module fake_netlist_764_2015_n_36 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_36);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_36;

wire n_23;
wire n_22;
wire n_34;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_35;
wire n_25;
wire n_21;
wire n_29;
wire n_32;

AND2x4_ASAP7_75t_L g21 ( 
.A(n_4),
.B(n_1),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_0),
.B(n_10),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_9),
.B(n_13),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_15),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_25),
.B1(n_26),
.B2(n_24),
.C(n_27),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_23),
.Y(n_31)
);

NOR2x1_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_22),
.Y(n_32)
);

AOI332xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_6),
.A3(n_14),
.B1(n_11),
.B2(n_12),
.B3(n_7),
.C1(n_2),
.C2(n_8),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_36)
);


endmodule