module fake_netlist_764_3389_n_48 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_48);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_48;

wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVx1_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_2),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_6),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_L g29 ( 
.A(n_0),
.B(n_19),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_1),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_14),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_16),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_18),
.Y(n_34)
);

AO221x1_ASAP7_75t_L g35 ( 
.A1(n_25),
.A2(n_19),
.B1(n_18),
.B2(n_5),
.C(n_7),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_32),
.Y(n_37)
);

OR2x6_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_34),
.Y(n_38)
);

AOI222xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_35),
.B1(n_29),
.B2(n_31),
.C1(n_24),
.C2(n_26),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_37),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_31),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_35),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_30),
.B(n_23),
.Y(n_43)
);

NAND2x1p5_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_8),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_28),
.Y(n_45)
);

XOR2xp5_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_10),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_44),
.A3(n_15),
.B1(n_13),
.B2(n_11),
.C1(n_20),
.C2(n_17),
.Y(n_48)
);


endmodule