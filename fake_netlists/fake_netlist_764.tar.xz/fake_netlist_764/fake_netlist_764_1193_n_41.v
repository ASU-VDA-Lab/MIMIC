module fake_netlist_764_1193_n_41 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_41);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_41;

wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_SL g21 ( 
.A(n_6),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_17),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_4),
.B(n_18),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_2),
.B(n_11),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_8),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_20),
.Y(n_27)
);

CKINVDCx8_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_23),
.A2(n_19),
.B1(n_18),
.B2(n_0),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_22),
.B1(n_24),
.B2(n_27),
.Y(n_31)
);

INVx6_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_30),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_35),
.Y(n_36)
);

NOR4xp25_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_21),
.C(n_25),
.D(n_19),
.Y(n_37)
);

OAI322xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_3),
.A3(n_1),
.B1(n_9),
.B2(n_10),
.C1(n_5),
.C2(n_7),
.Y(n_38)
);

CKINVDCx20_ASAP7_75t_R g39 ( 
.A(n_37),
.Y(n_39)
);

NOR2x1_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_32),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_38),
.B1(n_15),
.B2(n_13),
.C1(n_16),
.C2(n_14),
.Y(n_41)
);


endmodule