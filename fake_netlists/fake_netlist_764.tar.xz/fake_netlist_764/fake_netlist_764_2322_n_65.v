module fake_netlist_764_2322_n_65 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_65);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_65;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_64;
wire n_22;
wire n_62;
wire n_36;
wire n_18;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_42;
wire n_27;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_63;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_14),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_8),
.B(n_0),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_5),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_2),
.B(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_14),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx4_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_SL g35 ( 
.A(n_22),
.B(n_28),
.C(n_18),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_29),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_28),
.B(n_3),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_26),
.B1(n_24),
.B2(n_20),
.Y(n_39)
);

AOI21xp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_20),
.B(n_25),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_22),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_L g42 ( 
.A1(n_37),
.A2(n_26),
.B1(n_19),
.B2(n_17),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_36),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_33),
.B1(n_20),
.B2(n_36),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_39),
.A2(n_31),
.B1(n_30),
.B2(n_33),
.Y(n_46)
);

AO21x2_ASAP7_75t_L g47 ( 
.A1(n_40),
.A2(n_31),
.B(n_30),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_33),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

NAND4xp25_ASAP7_75t_L g50 ( 
.A(n_44),
.B(n_42),
.C(n_34),
.D(n_32),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

OR2x2_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_46),
.Y(n_54)
);

XOR2x2_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_47),
.Y(n_55)
);

AOI221xp5_ASAP7_75t_SL g56 ( 
.A1(n_53),
.A2(n_27),
.B1(n_23),
.B2(n_32),
.C(n_34),
.Y(n_56)
);

O2A1O1Ixp33_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_38),
.B(n_43),
.C(n_47),
.Y(n_57)
);

XNOR2xp5_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_3),
.Y(n_58)
);

AND2x4_ASAP7_75t_L g59 ( 
.A(n_52),
.B(n_48),
.Y(n_59)
);

OR3x2_ASAP7_75t_L g60 ( 
.A(n_58),
.B(n_56),
.C(n_7),
.Y(n_60)
);

HB1xp67_ASAP7_75t_SL g61 ( 
.A(n_59),
.Y(n_61)
);

AOI311xp33_ASAP7_75t_L g62 ( 
.A1(n_57),
.A2(n_13),
.A3(n_10),
.B(n_15),
.C(n_16),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_62),
.B(n_13),
.Y(n_63)
);

AND2x2_ASAP7_75t_SL g64 ( 
.A(n_61),
.B(n_60),
.Y(n_64)
);

AOI322xp5_ASAP7_75t_L g65 ( 
.A1(n_64),
.A2(n_11),
.A3(n_12),
.B1(n_63),
.B2(n_27),
.C1(n_17),
.C2(n_23),
.Y(n_65)
);


endmodule