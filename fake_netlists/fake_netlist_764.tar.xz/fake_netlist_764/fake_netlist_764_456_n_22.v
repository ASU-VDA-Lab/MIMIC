module fake_netlist_764_456_n_22 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_22);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_22;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_5),
.A2(n_9),
.B1(n_7),
.B2(n_6),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_4),
.B(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

AND2x2_ASAP7_75t_SL g14 ( 
.A(n_6),
.B(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_SL g15 ( 
.A(n_13),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_11),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_14),
.B1(n_5),
.B2(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI31xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.A3(n_14),
.B(n_0),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_1),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AO22x2_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B1(n_3),
.B2(n_2),
.Y(n_22)
);


endmodule