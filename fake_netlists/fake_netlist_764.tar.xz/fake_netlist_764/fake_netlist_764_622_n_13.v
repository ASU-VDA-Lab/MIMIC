module fake_netlist_764_622_n_13 (n_1, n_2, n_3, n_4, n_5, n_0, n_13);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_13;

wire n_12;
wire n_9;
wire n_11;
wire n_10;
wire n_7;
wire n_6;
wire n_8;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_1),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

AO21x2_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_2),
.B(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NAND4xp25_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_7),
.C(n_4),
.D(n_2),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.C(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

OAI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_3),
.B1(n_4),
.B2(n_5),
.C(n_11),
.Y(n_13)
);


endmodule