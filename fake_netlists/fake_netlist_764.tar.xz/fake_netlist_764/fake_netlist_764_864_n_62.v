module fake_netlist_764_864_n_62 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_62);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_62;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_22;
wire n_36;
wire n_18;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_50;
wire n_31;
wire n_30;
wire n_38;
wire n_53;
wire n_57;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_19;
wire n_41;
wire n_55;
wire n_47;
wire n_29;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx16_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_2),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_8),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_16),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_15),
.B(n_5),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_13),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_14),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_L g27 ( 
.A(n_10),
.B(n_7),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_12),
.B(n_3),
.Y(n_28)
);

NOR2xp67_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_0),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_18),
.B(n_1),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_SL g31 ( 
.A(n_21),
.B(n_6),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_18),
.B(n_1),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_20),
.B(n_2),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_27),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_19),
.B(n_4),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_20),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_32),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_25),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_32),
.B(n_19),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_33),
.A2(n_22),
.B1(n_23),
.B2(n_24),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_33),
.A2(n_26),
.B(n_22),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_37),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_30),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_38),
.Y(n_48)
);

XOR2x2_ASAP7_75t_L g49 ( 
.A(n_42),
.B(n_40),
.Y(n_49)
);

OAI211xp5_ASAP7_75t_SL g50 ( 
.A1(n_48),
.A2(n_34),
.B(n_43),
.C(n_45),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

AOI221xp5_ASAP7_75t_L g52 ( 
.A1(n_46),
.A2(n_22),
.B1(n_28),
.B2(n_24),
.C(n_36),
.Y(n_52)
);

OAI211xp5_ASAP7_75t_L g53 ( 
.A1(n_46),
.A2(n_29),
.B(n_28),
.C(n_36),
.Y(n_53)
);

XNOR2xp5_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_49),
.Y(n_54)
);

BUFx2_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_50),
.A2(n_49),
.B1(n_47),
.B2(n_31),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_51),
.Y(n_57)
);

OAI22xp5_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_53),
.B1(n_36),
.B2(n_10),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_36),
.B1(n_17),
.B2(n_11),
.Y(n_59)
);

AOI22x1_ASAP7_75t_L g60 ( 
.A1(n_54),
.A2(n_9),
.B1(n_17),
.B2(n_55),
.Y(n_60)
);

INVx1_ASAP7_75t_SL g61 ( 
.A(n_56),
.Y(n_61)
);

AOI22xp33_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_60),
.B1(n_59),
.B2(n_58),
.Y(n_62)
);


endmodule