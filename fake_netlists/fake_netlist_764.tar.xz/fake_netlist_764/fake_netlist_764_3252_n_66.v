module fake_netlist_764_3252_n_66 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_66);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_66;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_64;
wire n_22;
wire n_62;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_65;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_63;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

NOR2xp33_ASAP7_75t_SL g20 ( 
.A(n_3),
.B(n_0),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_13),
.B(n_7),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_8),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_18),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_6),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_15),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_5),
.B(n_19),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_29),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

INVx4_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_1),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_26),
.B(n_4),
.Y(n_36)
);

INVxp67_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

NOR3xp33_ASAP7_75t_SL g40 ( 
.A(n_31),
.B(n_27),
.C(n_26),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_33),
.B(n_27),
.Y(n_41)
);

INVx3_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_32),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

A2O1A1Ixp33_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_37),
.B(n_30),
.C(n_20),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

AND2x2_ASAP7_75t_SL g47 ( 
.A(n_44),
.B(n_33),
.Y(n_47)
);

NAND5xp2_ASAP7_75t_SL g48 ( 
.A(n_45),
.B(n_40),
.C(n_18),
.D(n_16),
.E(n_17),
.Y(n_48)
);

AND4x1_ASAP7_75t_L g49 ( 
.A(n_43),
.B(n_19),
.C(n_17),
.D(n_16),
.Y(n_49)
);

NOR4xp25_ASAP7_75t_SL g50 ( 
.A(n_49),
.B(n_44),
.C(n_21),
.D(n_36),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_47),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

NOR2x1_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_43),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

INVx1_ASAP7_75t_SL g57 ( 
.A(n_50),
.Y(n_57)
);

AND3x1_ASAP7_75t_L g58 ( 
.A(n_50),
.B(n_48),
.C(n_42),
.Y(n_58)
);

HB1xp67_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

INVx1_ASAP7_75t_SL g60 ( 
.A(n_56),
.Y(n_60)
);

AOI22xp33_ASAP7_75t_R g61 ( 
.A1(n_57),
.A2(n_48),
.B1(n_36),
.B2(n_10),
.Y(n_61)
);

AOI22xp33_ASAP7_75t_L g62 ( 
.A1(n_54),
.A2(n_42),
.B1(n_33),
.B2(n_12),
.Y(n_62)
);

NOR3xp33_ASAP7_75t_SL g63 ( 
.A(n_58),
.B(n_14),
.C(n_56),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_59),
.Y(n_64)
);

AND2x4_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_63),
.Y(n_65)
);

AOI22xp33_ASAP7_75t_SL g66 ( 
.A1(n_65),
.A2(n_61),
.B1(n_62),
.B2(n_64),
.Y(n_66)
);


endmodule