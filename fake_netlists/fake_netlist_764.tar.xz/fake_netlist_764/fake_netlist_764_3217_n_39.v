module fake_netlist_764_3217_n_39 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_39);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_39;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_3),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_17),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_6),
.B(n_9),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_15),
.B(n_0),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_10),
.B(n_16),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_SL g26 ( 
.A(n_21),
.B(n_17),
.C(n_16),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_19),
.B(n_1),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_18),
.Y(n_28)
);

OAI211xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B(n_23),
.C(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_30),
.B1(n_20),
.B2(n_19),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_SL g33 ( 
.A(n_32),
.B(n_30),
.Y(n_33)
);

NOR2x1_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_20),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_25),
.B1(n_24),
.B2(n_22),
.Y(n_36)
);

AOI211x1_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_18),
.B(n_4),
.C(n_2),
.Y(n_37)
);

OR3x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_8),
.C(n_5),
.Y(n_38)
);

AOI222xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_36),
.B1(n_25),
.B2(n_14),
.C1(n_13),
.C2(n_11),
.Y(n_39)
);


endmodule