module fake_netlist_764_200_n_50 (n_20, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_50);

input n_20;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_50;

wire n_23;
wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_27;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

OR2x2_ASAP7_75t_L g23 ( 
.A(n_10),
.B(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_8),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_3),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_4),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_5),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_18),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_0),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

OAI21xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_30),
.B(n_28),
.Y(n_36)
);

NAND2xp33_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_23),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_SL g38 ( 
.A1(n_37),
.A2(n_32),
.B1(n_33),
.B2(n_27),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_31),
.B1(n_6),
.B2(n_1),
.Y(n_39)
);

INVx5_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AOI31xp33_ASAP7_75t_SL g41 ( 
.A1(n_39),
.A2(n_11),
.A3(n_9),
.B(n_7),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_12),
.Y(n_43)
);

XNOR2x1_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_13),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_44),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_45),
.Y(n_47)
);

CKINVDCx20_ASAP7_75t_R g48 ( 
.A(n_46),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_20),
.B1(n_17),
.B2(n_14),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_48),
.B1(n_22),
.B2(n_21),
.Y(n_50)
);


endmodule