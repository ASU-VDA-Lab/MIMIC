module fake_netlist_764_194_n_75 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_75);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_75;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_64;
wire n_22;
wire n_62;
wire n_71;
wire n_66;
wire n_74;
wire n_72;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_68;
wire n_73;
wire n_49;
wire n_28;
wire n_65;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_63;
wire n_25;
wire n_69;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_67;
wire n_55;
wire n_29;
wire n_47;
wire n_70;
wire n_52;
wire n_54;
wire n_32;

INVx1_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_12),
.Y(n_21)
);

BUFx12f_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

INVx5_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_17),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_13),
.B(n_14),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_SL g30 ( 
.A(n_7),
.B(n_18),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_5),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_15),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_21),
.A2(n_17),
.B1(n_16),
.B2(n_0),
.Y(n_33)
);

NAND2x1_ASAP7_75t_L g34 ( 
.A(n_21),
.B(n_1),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_20),
.B(n_2),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_24),
.B(n_4),
.Y(n_36)
);

INVxp67_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_26),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_31),
.B(n_32),
.Y(n_39)
);

CKINVDCx16_ASAP7_75t_R g40 ( 
.A(n_22),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_29),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_34),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_34),
.Y(n_44)
);

OA21x2_ASAP7_75t_L g45 ( 
.A1(n_36),
.A2(n_25),
.B(n_28),
.Y(n_45)
);

OAI21x1_ASAP7_75t_L g46 ( 
.A1(n_35),
.A2(n_28),
.B(n_10),
.Y(n_46)
);

A2O1A1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_37),
.A2(n_30),
.B(n_23),
.C(n_11),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_40),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_42),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_44),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_46),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_38),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_45),
.Y(n_54)
);

HB1xp67_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

OR2x2_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_39),
.Y(n_56)
);

OAI211xp5_ASAP7_75t_SL g57 ( 
.A1(n_53),
.A2(n_33),
.B(n_47),
.C(n_35),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_51),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

INVx1_ASAP7_75t_SL g60 ( 
.A(n_55),
.Y(n_60)
);

OAI211xp5_ASAP7_75t_SL g61 ( 
.A1(n_60),
.A2(n_52),
.B(n_30),
.C(n_23),
.Y(n_61)
);

INVxp67_ASAP7_75t_L g62 ( 
.A(n_58),
.Y(n_62)
);

NOR2x1_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_23),
.Y(n_63)
);

INVx2_ASAP7_75t_SL g64 ( 
.A(n_59),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_57),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_SL g66 ( 
.A(n_61),
.B(n_23),
.Y(n_66)
);

INVx3_ASAP7_75t_L g67 ( 
.A(n_64),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_62),
.B(n_63),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_65),
.Y(n_69)
);

AND2x2_ASAP7_75t_L g70 ( 
.A(n_67),
.B(n_68),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_69),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_67),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_71),
.Y(n_73)
);

AOI22xp5_ASAP7_75t_L g74 ( 
.A1(n_70),
.A2(n_66),
.B1(n_72),
.B2(n_71),
.Y(n_74)
);

OAI21xp5_ASAP7_75t_SL g75 ( 
.A1(n_74),
.A2(n_66),
.B(n_73),
.Y(n_75)
);


endmodule