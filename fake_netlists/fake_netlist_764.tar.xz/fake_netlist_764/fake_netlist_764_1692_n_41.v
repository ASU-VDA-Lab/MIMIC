module fake_netlist_764_1692_n_41 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_41);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_41;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_13;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_9),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_7),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_0),
.Y(n_21)
);

INVx4_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_18),
.B(n_0),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_18),
.B(n_1),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_18),
.A2(n_16),
.B(n_15),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_14),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_22),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_R g29 ( 
.A(n_25),
.B(n_14),
.Y(n_29)
);

NOR2x1p5_ASAP7_75t_L g30 ( 
.A(n_22),
.B(n_20),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_26),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_20),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_29),
.B1(n_30),
.B2(n_31),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_SL g34 ( 
.A1(n_32),
.A2(n_23),
.B(n_24),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_23),
.B(n_17),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_SL g36 ( 
.A1(n_34),
.A2(n_30),
.B1(n_19),
.B2(n_1),
.C(n_2),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_35),
.Y(n_37)
);

OAI21xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_5),
.B(n_4),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_8),
.B1(n_12),
.B2(n_39),
.Y(n_41)
);


endmodule