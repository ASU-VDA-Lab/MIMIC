module fake_netlist_764_3151_n_11 (n_1, n_2, n_3, n_4, n_5, n_0, n_11);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_11;

wire n_9;
wire n_10;
wire n_7;
wire n_6;
wire n_8;

AND2x2_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

INVxp67_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AND4x1_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.C(n_5),
.D(n_3),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);


endmodule