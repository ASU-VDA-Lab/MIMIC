module fake_netlist_764_964_n_43 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_43);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_43;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_15;
wire n_41;
wire n_29;
wire n_32;

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_0),
.B(n_1),
.Y(n_14)
);

OR2x6_ASAP7_75t_L g15 ( 
.A(n_0),
.B(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

INVx4_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_9),
.B(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_11),
.B(n_10),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_19),
.A2(n_3),
.B(n_2),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_19),
.A2(n_7),
.B(n_6),
.C(n_8),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

OAI21x1_ASAP7_75t_L g28 ( 
.A1(n_20),
.A2(n_22),
.B(n_24),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

OAI21x1_ASAP7_75t_L g31 ( 
.A1(n_22),
.A2(n_17),
.B(n_16),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_27),
.B(n_15),
.Y(n_32)
);

AO21x2_ASAP7_75t_L g33 ( 
.A1(n_25),
.A2(n_23),
.B(n_21),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_29),
.B(n_15),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_26),
.B1(n_15),
.B2(n_30),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_33),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_30),
.Y(n_38)
);

INVxp67_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AOI222xp33_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_14),
.B1(n_34),
.B2(n_31),
.C1(n_28),
.C2(n_25),
.Y(n_40)
);

XOR2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_14),
.Y(n_41)
);

XNOR2x1_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_38),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_34),
.B(n_41),
.Y(n_43)
);


endmodule