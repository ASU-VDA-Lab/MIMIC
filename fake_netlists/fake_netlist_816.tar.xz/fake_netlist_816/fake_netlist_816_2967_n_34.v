module fake_netlist_816_2967_n_34 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_34);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

BUFx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_9),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_11),
.B(n_3),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_SL g19 ( 
.A(n_15),
.B(n_4),
.C(n_3),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_13),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_12),
.B(n_14),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

OR2x2_ASAP7_75t_SL g24 ( 
.A(n_18),
.B(n_15),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_20),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_22),
.A2(n_19),
.B1(n_21),
.B2(n_16),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_24),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_4),
.Y(n_30)
);

OAI22x1_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_27),
.B1(n_29),
.B2(n_28),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_34)
);


endmodule