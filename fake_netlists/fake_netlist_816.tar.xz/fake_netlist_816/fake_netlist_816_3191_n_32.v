module fake_netlist_816_3191_n_32 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_27;

INVx1_ASAP7_75t_SL g17 ( 
.A(n_9),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_3),
.B(n_5),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

BUFx4f_ASAP7_75t_SL g24 ( 
.A(n_19),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_18),
.Y(n_25)
);

OAI31xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.A3(n_22),
.B(n_17),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_24),
.B1(n_16),
.B2(n_20),
.C(n_0),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_1),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_4),
.Y(n_29)
);

OAI211xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_8),
.B(n_7),
.C(n_6),
.Y(n_30)
);

OR2x6_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_11),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_32)
);


endmodule