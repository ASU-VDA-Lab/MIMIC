module fake_netlist_816_244_n_23 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_23);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_19;
wire n_12;
wire n_18;
wire n_21;
wire n_16;

AO21x2_ASAP7_75t_L g12 ( 
.A1(n_1),
.A2(n_11),
.B(n_3),
.Y(n_12)
);

AND3x4_ASAP7_75t_L g13 ( 
.A(n_5),
.B(n_4),
.C(n_9),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

INVx8_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

INVx3_ASAP7_75t_SL g16 ( 
.A(n_15),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_SL g17 ( 
.A(n_13),
.B(n_0),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND4xp25_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.C(n_14),
.D(n_7),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_12),
.B(n_14),
.Y(n_21)
);

OAI21x1_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_8),
.B(n_6),
.Y(n_22)
);

OR2x6_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_10),
.Y(n_23)
);


endmodule