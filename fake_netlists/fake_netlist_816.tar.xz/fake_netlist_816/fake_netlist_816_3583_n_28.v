module fake_netlist_816_3583_n_28 (n_4, n_2, n_3, n_0, n_1, n_28);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_27;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx4_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

AND2x6_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_1),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_2),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_7),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_6),
.B(n_7),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_5),
.B(n_9),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_5),
.B1(n_6),
.B2(n_8),
.C(n_13),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_15),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_17),
.B(n_18),
.C(n_11),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_SL g23 ( 
.A1(n_20),
.A2(n_8),
.B1(n_15),
.B2(n_12),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_12),
.C(n_8),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_19),
.B1(n_20),
.B2(n_8),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_20),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_SL g28 ( 
.A1(n_26),
.A2(n_8),
.B1(n_27),
.B2(n_25),
.Y(n_28)
);


endmodule