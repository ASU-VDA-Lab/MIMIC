module fake_netlist_792_2949_n_47 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_47);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_47;

wire n_37;
wire n_45;
wire n_44;
wire n_36;
wire n_29;
wire n_35;
wire n_25;
wire n_40;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_43;
wire n_38;
wire n_28;
wire n_30;
wire n_41;
wire n_32;

BUFx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_5),
.B(n_2),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_18),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_12),
.B(n_19),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_22),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_21),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_0),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_27),
.A2(n_3),
.B(n_1),
.Y(n_34)
);

INVx4_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

CKINVDCx16_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_29),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_30),
.B1(n_31),
.B2(n_28),
.C1(n_26),
.C2(n_34),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_SL g42 ( 
.A1(n_39),
.A2(n_7),
.B1(n_6),
.B2(n_8),
.C(n_9),
.Y(n_42)
);

OAI22x1_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_13),
.B1(n_11),
.B2(n_10),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

INVx2_ASAP7_75t_SL g45 ( 
.A(n_44),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_17),
.B1(n_20),
.B2(n_46),
.Y(n_47)
);


endmodule