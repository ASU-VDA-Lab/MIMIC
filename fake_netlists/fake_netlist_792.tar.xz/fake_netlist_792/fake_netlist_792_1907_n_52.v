module fake_netlist_792_1907_n_52 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_52);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_52;

wire n_37;
wire n_45;
wire n_44;
wire n_20;
wire n_47;
wire n_29;
wire n_36;
wire n_17;
wire n_50;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_18;
wire n_49;
wire n_43;
wire n_48;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_41;
wire n_51;
wire n_32;
wire n_22;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_2),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_17),
.B(n_0),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_23),
.B(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_R g29 ( 
.A(n_25),
.B(n_19),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_18),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_30),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_L g34 ( 
.A1(n_29),
.A2(n_27),
.B1(n_28),
.B2(n_18),
.C(n_20),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_SL g38 ( 
.A(n_37),
.B(n_30),
.Y(n_38)
);

XNOR2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_4),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_4),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_35),
.B1(n_20),
.B2(n_5),
.C(n_6),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_16),
.B1(n_6),
.B2(n_5),
.C(n_3),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

AOI31xp33_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_16),
.A3(n_14),
.B(n_7),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_44),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_43),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_42),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

INVx2_ASAP7_75t_SL g50 ( 
.A(n_46),
.Y(n_50)
);

INVxp33_ASAP7_75t_SL g51 ( 
.A(n_45),
.Y(n_51)
);

AOI321xp33_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_15),
.A3(n_47),
.B1(n_48),
.B2(n_51),
.C(n_50),
.Y(n_52)
);


endmodule