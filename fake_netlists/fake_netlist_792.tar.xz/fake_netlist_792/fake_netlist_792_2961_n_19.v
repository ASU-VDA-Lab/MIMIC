module fake_netlist_792_2961_n_19 (n_1, n_0, n_5, n_6, n_3, n_2, n_4, n_19);

input n_1;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;

output n_19;

wire n_17;
wire n_12;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_14;

INVx1_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

BUFx10_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_3),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_6),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_1),
.B(n_3),
.C(n_2),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_8),
.B1(n_10),
.B2(n_9),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_8),
.B2(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AND5x1_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_8),
.C(n_1),
.D(n_2),
.E(n_4),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_15),
.B1(n_16),
.B2(n_5),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_8),
.B1(n_6),
.B2(n_5),
.Y(n_19)
);


endmodule