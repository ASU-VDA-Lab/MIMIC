module fake_netlist_792_2978_n_49 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_24, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_49);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_24;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_49;

wire n_37;
wire n_45;
wire n_44;
wire n_47;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_40;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_26;
wire n_42;
wire n_48;
wire n_43;
wire n_38;
wire n_28;
wire n_30;
wire n_41;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_3),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_R g27 ( 
.A(n_11),
.B(n_21),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_12),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_21),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_6),
.B(n_20),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_18),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_0),
.A2(n_4),
.B1(n_5),
.B2(n_15),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_19),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_2),
.B(n_1),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_SL g35 ( 
.A(n_29),
.B(n_23),
.C(n_22),
.Y(n_35)
);

OAI21xp33_ASAP7_75t_L g36 ( 
.A1(n_26),
.A2(n_8),
.B(n_7),
.Y(n_36)
);

BUFx3_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_29),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_28),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_33),
.Y(n_40)
);

O2A1O1Ixp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_30),
.B(n_37),
.C(n_27),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_37),
.B(n_35),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_32),
.B(n_24),
.C(n_23),
.Y(n_43)
);

OAI21xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_31),
.B(n_25),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_24),
.B1(n_13),
.B2(n_9),
.C(n_10),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_44),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_14),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_SL g49 ( 
.A1(n_48),
.A2(n_16),
.B1(n_17),
.B2(n_47),
.Y(n_49)
);


endmodule