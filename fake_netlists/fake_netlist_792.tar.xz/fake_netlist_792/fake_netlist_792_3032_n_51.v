module fake_netlist_792_3032_n_51 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_25, n_5, n_24, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_51);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_25;
input n_5;
input n_24;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_51;

wire n_37;
wire n_45;
wire n_44;
wire n_47;
wire n_29;
wire n_36;
wire n_50;
wire n_35;
wire n_40;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_42;
wire n_26;
wire n_48;
wire n_43;
wire n_49;
wire n_38;
wire n_28;
wire n_30;
wire n_41;
wire n_32;

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_22),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_3),
.B(n_15),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_16),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_25),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_14),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_2),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

OAI21xp33_ASAP7_75t_L g37 ( 
.A1(n_29),
.A2(n_4),
.B(n_1),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_28),
.B(n_22),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_35),
.B1(n_33),
.B2(n_32),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_32),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_39),
.Y(n_42)
);

AOI21xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_37),
.B(n_31),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_34),
.Y(n_44)
);

AOI322xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_26),
.A3(n_25),
.B1(n_23),
.B2(n_24),
.C1(n_30),
.C2(n_5),
.Y(n_45)
);

OAI22xp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_24),
.B1(n_30),
.B2(n_6),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_7),
.Y(n_47)
);

AO221x1_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_10),
.B1(n_9),
.B2(n_11),
.C(n_12),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_18),
.B1(n_17),
.B2(n_13),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_49),
.B1(n_20),
.B2(n_19),
.Y(n_51)
);


endmodule