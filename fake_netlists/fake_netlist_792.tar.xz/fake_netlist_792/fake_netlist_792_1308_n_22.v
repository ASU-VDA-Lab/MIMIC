module fake_netlist_792_1308_n_22 (n_1, n_0, n_5, n_3, n_2, n_4, n_22);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_22;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_14;

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_1),
.C(n_0),
.Y(n_11)
);

AO21x2_ASAP7_75t_L g12 ( 
.A1(n_6),
.A2(n_1),
.B(n_10),
.Y(n_12)
);

OAI22xp33_ASAP7_75t_L g13 ( 
.A1(n_7),
.A2(n_8),
.B1(n_10),
.B2(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

INVx4_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

AOI211xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B(n_11),
.C(n_9),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_16),
.B(n_15),
.C(n_7),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

XNOR2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_20),
.Y(n_22)
);


endmodule