module fake_netlist_792_2276_n_31 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_31);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_31;

wire n_20;
wire n_29;
wire n_17;
wire n_12;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_8),
.Y(n_10)
);

BUFx3_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_11),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_12),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_12),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_20),
.B1(n_16),
.B2(n_13),
.C(n_15),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_20),
.Y(n_24)
);

AOI21xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_22),
.B(n_14),
.Y(n_25)
);

OAI221xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_13),
.B1(n_15),
.B2(n_10),
.C(n_4),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

XOR2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_5),
.Y(n_28)
);

AO22x2_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_7),
.B1(n_6),
.B2(n_9),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_7),
.B1(n_27),
.B2(n_30),
.Y(n_31)
);


endmodule