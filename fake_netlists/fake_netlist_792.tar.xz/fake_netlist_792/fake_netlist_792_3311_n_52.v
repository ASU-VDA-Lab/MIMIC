module fake_netlist_792_3311_n_52 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_25, n_5, n_27, n_24, n_26, n_18, n_13, n_15, n_11, n_16, n_23, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_52);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_25;
input n_5;
input n_27;
input n_24;
input n_26;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_23;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_52;

wire n_37;
wire n_45;
wire n_44;
wire n_29;
wire n_36;
wire n_50;
wire n_35;
wire n_31;
wire n_40;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_42;
wire n_49;
wire n_48;
wire n_43;
wire n_38;
wire n_28;
wire n_30;
wire n_41;
wire n_51;
wire n_32;
wire n_47;

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_15),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_17),
.Y(n_32)
);

NOR2xp67_ASAP7_75t_L g33 ( 
.A(n_3),
.B(n_21),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_25),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_16),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_20),
.Y(n_36)
);

O2A1O1Ixp5_ASAP7_75t_L g37 ( 
.A1(n_31),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

AOI21x1_ASAP7_75t_L g39 ( 
.A1(n_31),
.A2(n_29),
.B(n_33),
.Y(n_39)
);

NAND2xp33_ASAP7_75t_R g40 ( 
.A(n_38),
.B(n_30),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

OAI21xp5_ASAP7_75t_SL g42 ( 
.A1(n_41),
.A2(n_39),
.B(n_34),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_37),
.C(n_32),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_41),
.B1(n_34),
.B2(n_35),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_36),
.B1(n_25),
.B2(n_24),
.Y(n_45)
);

AOI211xp5_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_26),
.B(n_24),
.C(n_4),
.Y(n_46)
);

AO221x1_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_26),
.B1(n_7),
.B2(n_5),
.C(n_6),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

XNOR2x1_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_8),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_50)
);

OAI22x1_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_18),
.B1(n_19),
.B2(n_50),
.Y(n_52)
);


endmodule