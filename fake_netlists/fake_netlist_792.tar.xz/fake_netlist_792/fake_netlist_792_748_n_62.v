module fake_netlist_792_748_n_62 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_62);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_62;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_20;
wire n_52;
wire n_36;
wire n_29;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_49;
wire n_43;
wire n_48;
wire n_56;
wire n_38;
wire n_54;
wire n_61;
wire n_60;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_59;
wire n_53;
wire n_41;
wire n_21;
wire n_51;
wire n_32;
wire n_22;
wire n_47;

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_2),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_8),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_9),
.Y(n_29)
);

NAND3xp33_ASAP7_75t_SL g30 ( 
.A(n_26),
.B(n_1),
.C(n_0),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_27),
.B(n_1),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_2),
.Y(n_34)
);

OAI21x1_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_27),
.B(n_24),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_25),
.B(n_24),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_26),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_36),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_30),
.Y(n_40)
);

NAND4xp25_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_23),
.C(n_32),
.D(n_22),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_22),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_38),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_32),
.B1(n_23),
.B2(n_39),
.C(n_21),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_28),
.B(n_25),
.Y(n_45)
);

O2A1O1Ixp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_37),
.B(n_21),
.C(n_3),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_21),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_21),
.B1(n_20),
.B2(n_29),
.C(n_31),
.Y(n_48)
);

AOI211xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_20),
.B(n_31),
.C(n_3),
.Y(n_49)
);

BUFx3_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_20),
.B1(n_31),
.B2(n_11),
.Y(n_51)
);

OAI221xp5_ASAP7_75t_L g52 ( 
.A1(n_44),
.A2(n_16),
.B1(n_11),
.B2(n_17),
.C(n_19),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

AOI21xp33_ASAP7_75t_SL g54 ( 
.A1(n_52),
.A2(n_17),
.B(n_16),
.Y(n_54)
);

OA21x2_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_7),
.B(n_4),
.Y(n_55)
);

CKINVDCx5p33_ASAP7_75t_R g56 ( 
.A(n_50),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_48),
.Y(n_57)
);

OA22x2_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_14),
.B1(n_12),
.B2(n_10),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_L g59 ( 
.A1(n_53),
.A2(n_57),
.B1(n_55),
.B2(n_54),
.Y(n_59)
);

BUFx2_ASAP7_75t_L g60 ( 
.A(n_55),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_59),
.Y(n_61)
);

AOI22xp33_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_58),
.B1(n_60),
.B2(n_54),
.Y(n_62)
);


endmodule