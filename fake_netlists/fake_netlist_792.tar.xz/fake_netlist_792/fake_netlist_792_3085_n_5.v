module fake_netlist_792_3085_n_5 (n_1, n_2, n_3, n_0, n_5);

input n_1;
input n_2;
input n_3;
input n_0;

output n_5;

wire n_4;

AND2x2_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

NAND4xp75_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_1),
.C(n_3),
.D(n_0),
.Y(n_5)
);


endmodule