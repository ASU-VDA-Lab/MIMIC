module fake_netlist_792_2444_n_32 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_17, n_9, n_2, n_12, n_13, n_4, n_8, n_32);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_17;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_32;

wire n_20;
wire n_29;
wire n_25;
wire n_31;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_22;

INVx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_14),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_7),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_1),
.B(n_5),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

A2O1A1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_18),
.A2(n_12),
.B(n_11),
.C(n_10),
.Y(n_24)
);

A2O1A1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_18),
.A2(n_11),
.B(n_10),
.C(n_0),
.Y(n_25)
);

AO21x2_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_22),
.B(n_21),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_24),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_26),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_20),
.B1(n_21),
.B2(n_19),
.C(n_23),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AO211x2_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_6),
.B(n_4),
.C(n_3),
.Y(n_31)
);

OAI321xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_30),
.A3(n_16),
.B1(n_9),
.B2(n_17),
.C(n_15),
.Y(n_32)
);


endmodule