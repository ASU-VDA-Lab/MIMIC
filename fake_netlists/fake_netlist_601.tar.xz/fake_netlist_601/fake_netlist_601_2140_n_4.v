module fake_netlist_601_2140_n_4 (n_0, n_4);

input n_0;

output n_4;

wire n_1;
wire n_2;
wire n_3;

INVx2_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

INVx1_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

AND2x2_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

OAI22x1_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_4)
);


endmodule