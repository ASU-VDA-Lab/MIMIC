module fake_netlist_601_876_n_26 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_26);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_26;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_25;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_0),
.B(n_5),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_7),
.A2(n_12),
.B1(n_11),
.B2(n_1),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_8),
.A2(n_3),
.B1(n_6),
.B2(n_2),
.Y(n_16)
);

AOI21x1_ASAP7_75t_L g17 ( 
.A1(n_1),
.A2(n_3),
.B(n_4),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_14),
.B(n_0),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_10),
.B(n_2),
.Y(n_20)
);

INVxp33_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_16),
.B2(n_20),
.C(n_15),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

NOR2x1_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_18),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_6),
.B1(n_7),
.B2(n_17),
.C1(n_18),
.C2(n_24),
.Y(n_26)
);


endmodule