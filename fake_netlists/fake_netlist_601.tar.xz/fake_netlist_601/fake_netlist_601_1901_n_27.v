module fake_netlist_601_1901_n_27 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_27);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_27;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

BUFx10_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_2),
.B(n_6),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

OAI21xp33_ASAP7_75t_SL g13 ( 
.A1(n_10),
.A2(n_7),
.B(n_0),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_7),
.B1(n_1),
.B2(n_0),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_7),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_10),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B(n_17),
.C(n_9),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_16),
.B1(n_12),
.B2(n_11),
.C(n_10),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_16),
.B(n_22),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI22x1_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_16),
.B1(n_2),
.B2(n_1),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_3),
.B1(n_5),
.B2(n_26),
.Y(n_27)
);


endmodule