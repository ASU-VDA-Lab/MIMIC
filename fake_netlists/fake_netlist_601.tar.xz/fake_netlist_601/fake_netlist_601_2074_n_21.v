module fake_netlist_601_2074_n_21 (n_0, n_4, n_1, n_2, n_3, n_21);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_21;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_7;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_5;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

NAND2xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_3),
.B(n_4),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

OAI222xp33_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B1(n_3),
.B2(n_0),
.C1(n_4),
.C2(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_7),
.Y(n_12)
);

NAND2x1_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_10),
.B(n_11),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_7),
.B(n_8),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_13),
.B1(n_5),
.B2(n_14),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_9),
.B1(n_4),
.B2(n_0),
.C(n_1),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_9),
.B1(n_4),
.B2(n_1),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_1),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_9),
.B1(n_19),
.B2(n_18),
.Y(n_21)
);


endmodule