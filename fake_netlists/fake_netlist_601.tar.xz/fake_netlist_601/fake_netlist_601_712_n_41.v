module fake_netlist_601_712_n_41 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_17, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_41);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_17;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_41;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_10),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_2),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_4),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_16),
.B(n_5),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_14),
.B(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

AND2x6_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_0),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

BUFx10_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_27),
.A2(n_22),
.B1(n_21),
.B2(n_19),
.Y(n_30)
);

NAND2x1_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_26),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_24),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

OAI321xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_23),
.A3(n_8),
.B1(n_1),
.B2(n_9),
.C(n_3),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_33),
.B(n_13),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_36),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_15),
.B1(n_17),
.B2(n_40),
.Y(n_41)
);


endmodule