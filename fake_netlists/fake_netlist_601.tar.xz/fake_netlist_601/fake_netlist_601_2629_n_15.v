module fake_netlist_601_2629_n_15 (n_5, n_0, n_4, n_1, n_2, n_3, n_15);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_15;

wire n_7;
wire n_11;
wire n_9;
wire n_8;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_12;

INVx5_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

AO22x1_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_3),
.B1(n_0),
.B2(n_1),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

NOR3xp33_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.C(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_10),
.Y(n_13)
);

NOR2xp67_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_6),
.Y(n_14)
);

NAND5xp2_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_1),
.C(n_6),
.D(n_13),
.E(n_12),
.Y(n_15)
);


endmodule