module fake_netlist_601_3692_n_21 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_21);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_21;

wire n_11;
wire n_15;
wire n_18;
wire n_17;
wire n_19;
wire n_10;
wire n_20;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_0),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_7),
.B(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_12),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_17),
.B(n_6),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AO22x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_9),
.B1(n_8),
.B2(n_4),
.Y(n_21)
);


endmodule