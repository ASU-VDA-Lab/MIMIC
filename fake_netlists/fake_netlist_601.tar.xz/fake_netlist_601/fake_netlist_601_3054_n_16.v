module fake_netlist_601_3054_n_16 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_16);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_16;

wire n_11;
wire n_8;
wire n_15;
wire n_10;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_6),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_8),
.B1(n_9),
.B2(n_1),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_7),
.B2(n_5),
.C(n_2),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_7),
.C(n_3),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);


endmodule