module fake_netlist_601_1810_n_45 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_45);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_45;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_36;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_38;
wire n_43;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_34;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_18),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_17),
.B(n_16),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_8),
.A2(n_0),
.B1(n_12),
.B2(n_13),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_7),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_10),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_22),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_15),
.Y(n_31)
);

BUFx12f_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

OAI221xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_28),
.B1(n_26),
.B2(n_21),
.C(n_23),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_31),
.B1(n_29),
.B2(n_25),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_31),
.B1(n_29),
.B2(n_25),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_24),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_24),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_36),
.Y(n_38)
);

INVxp33_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_33),
.B(n_29),
.Y(n_41)
);

OAI221xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_38),
.B1(n_17),
.B2(n_15),
.C(n_16),
.Y(n_42)
);

HB1xp67_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_18),
.B1(n_3),
.B2(n_2),
.Y(n_44)
);

AOI322xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_43),
.A3(n_6),
.B1(n_5),
.B2(n_4),
.C1(n_11),
.C2(n_9),
.Y(n_45)
);


endmodule