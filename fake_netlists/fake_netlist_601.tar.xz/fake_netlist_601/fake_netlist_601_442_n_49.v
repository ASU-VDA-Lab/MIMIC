module fake_netlist_601_442_n_49 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_17, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_49);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_17;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_49;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_2),
.B(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_16),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_10),
.B(n_12),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

AND2x6_ASAP7_75t_L g27 ( 
.A(n_5),
.B(n_14),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_17),
.B1(n_15),
.B2(n_1),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_28),
.B1(n_32),
.B2(n_31),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_19),
.B1(n_18),
.B2(n_22),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

NAND3xp33_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_23),
.C(n_27),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_27),
.B(n_25),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_37),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND2xp33_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_27),
.Y(n_43)
);

INVxp67_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

NAND4xp25_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_17),
.C(n_15),
.D(n_3),
.Y(n_45)
);

OR3x1_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_9),
.C(n_8),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_11),
.B1(n_47),
.B2(n_45),
.Y(n_49)
);


endmodule