module fake_netlist_601_515_n_36 (n_7, n_9, n_11, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_36);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_36;

wire n_31;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

AND2x6_ASAP7_75t_L g18 ( 
.A(n_6),
.B(n_12),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_15),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_9),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_18),
.B(n_1),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_21),
.B1(n_23),
.B2(n_20),
.Y(n_27)
);

OAI221xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_16),
.B1(n_22),
.B2(n_18),
.C(n_15),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_24),
.B1(n_25),
.B2(n_5),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_7),
.Y(n_31)
);

NAND4xp25_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_11),
.C(n_10),
.D(n_8),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_32),
.B(n_13),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_30),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);


endmodule