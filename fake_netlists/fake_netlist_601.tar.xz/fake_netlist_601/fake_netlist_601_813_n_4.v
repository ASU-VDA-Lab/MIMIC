module fake_netlist_601_813_n_4 (n_0, n_4);

input n_0;

output n_4;

wire n_1;
wire n_2;
wire n_3;

INVx5_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

NOR2x1_ASAP7_75t_SL g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

NOR3xp33_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.C(n_0),
.Y(n_3)
);

HB1xp67_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);


endmodule