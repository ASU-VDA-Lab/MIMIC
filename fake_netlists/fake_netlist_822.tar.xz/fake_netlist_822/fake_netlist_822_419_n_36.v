module fake_netlist_822_419_n_36 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_36);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_36;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_11;
wire n_27;

INVx2_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_4),
.Y(n_12)
);

OAI22x1_ASAP7_75t_SL g13 ( 
.A1(n_2),
.A2(n_9),
.B1(n_3),
.B2(n_4),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_5),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_1),
.B(n_6),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

OAI22xp33_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_6),
.B1(n_8),
.B2(n_11),
.Y(n_20)
);

BUFx8_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_12),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_20),
.B1(n_16),
.B2(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_20),
.B1(n_14),
.B2(n_21),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_17),
.Y(n_33)
);

OAI21x1_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_17),
.B(n_14),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI22x1_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_14),
.B1(n_34),
.B2(n_33),
.Y(n_36)
);


endmodule