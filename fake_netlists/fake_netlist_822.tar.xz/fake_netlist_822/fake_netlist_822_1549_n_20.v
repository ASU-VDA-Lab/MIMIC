module fake_netlist_822_1549_n_20 (n_2, n_0, n_3, n_1, n_20);

input n_2;
input n_0;
input n_3;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_4;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_5;
wire n_11;
wire n_8;

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_3),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_6),
.B(n_4),
.Y(n_7)
);

BUFx12f_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

O2A1O1Ixp5_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.C(n_7),
.Y(n_14)
);

AOI211xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_7),
.B(n_9),
.C(n_8),
.Y(n_15)
);

OAI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_8),
.B2(n_0),
.Y(n_16)
);

XNOR2x1_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_1),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

OAI222xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_1),
.B1(n_2),
.B2(n_18),
.C1(n_17),
.C2(n_4),
.Y(n_20)
);


endmodule