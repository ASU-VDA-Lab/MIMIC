module fake_netlist_822_930_n_22 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_22);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_5),
.A2(n_9),
.B1(n_6),
.B2(n_7),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_4),
.B(n_1),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_2),
.B(n_6),
.Y(n_15)
);

NAND3x1_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_7),
.C(n_5),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_1),
.B(n_0),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.B1(n_13),
.B2(n_0),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_4),
.B(n_2),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_8),
.C(n_3),
.Y(n_21)
);

AO22x2_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_10),
.B1(n_12),
.B2(n_20),
.Y(n_22)
);


endmodule