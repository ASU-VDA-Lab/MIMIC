module fake_netlist_822_1751_n_17 (n_2, n_0, n_3, n_1, n_17);

input n_2;
input n_0;
input n_3;
input n_1;

output n_17;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_16;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx4_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

BUFx4f_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

NAND3xp33_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_1),
.C(n_0),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

OAI321xp33_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_4),
.A3(n_5),
.B1(n_6),
.B2(n_1),
.C(n_0),
.Y(n_9)
);

AO21x2_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_4),
.B(n_6),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_5),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_6),
.B1(n_5),
.B2(n_0),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B1(n_6),
.B2(n_9),
.Y(n_13)
);

AOI322xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_1),
.A3(n_2),
.B1(n_3),
.B2(n_9),
.C1(n_4),
.C2(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_16),
.B(n_2),
.Y(n_17)
);


endmodule