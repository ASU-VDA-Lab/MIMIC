module fake_netlist_822_1316_n_32 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_32);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_28;
wire n_9;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;
wire n_8;

AND2x2_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_6),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_2),
.B(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_4),
.B(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_4),
.B(n_5),
.Y(n_11)
);

BUFx6f_ASAP7_75t_SL g12 ( 
.A(n_3),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_1),
.Y(n_13)
);

AO21x1_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_14)
);

AOI21x1_ASAP7_75t_L g15 ( 
.A1(n_9),
.A2(n_3),
.B(n_0),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_5),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_11),
.B(n_12),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_13),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_14),
.Y(n_24)
);

OAI211xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_21),
.B(n_19),
.C(n_20),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_18),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_18),
.B1(n_20),
.B2(n_14),
.Y(n_27)
);

AND4x1_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_18),
.C(n_22),
.D(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

INVxp33_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

NAND3x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_30),
.C(n_28),
.Y(n_32)
);


endmodule