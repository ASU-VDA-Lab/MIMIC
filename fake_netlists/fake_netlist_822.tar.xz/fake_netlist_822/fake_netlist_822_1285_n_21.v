module fake_netlist_822_1285_n_21 (n_2, n_0, n_3, n_1, n_21);

input n_2;
input n_0;
input n_3;
input n_1;

output n_21;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_4;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_5;
wire n_11;
wire n_8;

AO22x2_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_1),
.B1(n_0),
.B2(n_3),
.Y(n_4)
);

INVxp67_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

AO21x1_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

NAND3xp33_ASAP7_75t_SL g8 ( 
.A(n_5),
.B(n_1),
.C(n_0),
.Y(n_8)
);

INVx6_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_4),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_4),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

NAND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_4),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_11),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_SL g16 ( 
.A1(n_13),
.A2(n_7),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_16)
);

NAND2x1p5_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_13),
.Y(n_17)
);

XOR2x1_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_2),
.Y(n_18)
);

XNOR2x1_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_3),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_3),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_17),
.B(n_19),
.Y(n_21)
);


endmodule