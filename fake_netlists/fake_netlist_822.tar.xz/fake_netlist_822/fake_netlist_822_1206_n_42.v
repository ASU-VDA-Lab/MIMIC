module fake_netlist_822_1206_n_42 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_42);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_42;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;

AND2x6_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_1),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_5),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_8),
.B(n_1),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_0),
.Y(n_22)
);

BUFx4_ASAP7_75t_SL g23 ( 
.A(n_19),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_2),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_16),
.B(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_23),
.Y(n_26)
);

INVx4_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_22),
.C(n_24),
.Y(n_29)
);

NAND2x1p5_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_22),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_29),
.B(n_26),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_27),
.B(n_24),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

INVxp67_ASAP7_75t_SL g34 ( 
.A(n_32),
.Y(n_34)
);

AOI322xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_24),
.A3(n_25),
.B1(n_21),
.B2(n_18),
.C1(n_20),
.C2(n_15),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_35),
.B(n_31),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_20),
.B1(n_13),
.B2(n_28),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_36),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_3),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

AND3x1_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_13),
.C(n_4),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_40),
.A2(n_7),
.B1(n_10),
.B2(n_41),
.Y(n_42)
);


endmodule