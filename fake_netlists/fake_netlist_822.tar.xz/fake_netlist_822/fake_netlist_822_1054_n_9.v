module fake_netlist_822_1054_n_9 (n_0, n_1, n_9);

input n_0;
input n_1;

output n_9;

wire n_6;
wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_3;
wire n_8;

INVx2_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

AND2x2_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

OA21x2_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_3),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_SL g6 ( 
.A1(n_5),
.A2(n_2),
.B(n_4),
.Y(n_6)
);

NAND4xp25_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.C(n_0),
.D(n_5),
.Y(n_7)
);

OAI211xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.C(n_5),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B(n_0),
.Y(n_9)
);


endmodule