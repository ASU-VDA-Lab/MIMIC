module fake_netlist_822_1331_n_19 (n_2, n_0, n_3, n_1, n_19);

input n_2;
input n_0;
input n_3;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_4;
wire n_7;
wire n_9;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_5;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_3),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_1),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_4),
.B(n_1),
.Y(n_8)
);

A2O1A1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_2),
.C(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_4),
.Y(n_10)
);

NAND2xp33_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_1),
.Y(n_11)
);

NOR3xp33_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.C(n_0),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_0),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_3),
.C(n_2),
.Y(n_14)
);

NAND2x1_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_10),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_1),
.Y(n_16)
);

AND4x1_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_2),
.C(n_3),
.D(n_9),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B(n_17),
.Y(n_19)
);


endmodule