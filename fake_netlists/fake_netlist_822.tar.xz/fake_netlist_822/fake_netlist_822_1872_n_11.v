module fake_netlist_822_1872_n_11 (n_2, n_0, n_1, n_11);

input n_2;
input n_0;
input n_1;

output n_11;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_8;

CKINVDCx16_ASAP7_75t_R g3 ( 
.A(n_0),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

NOR2x1_ASAP7_75t_R g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

BUFx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_3),
.Y(n_7)
);

NAND4xp25_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_2),
.C(n_1),
.D(n_0),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_1),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_2),
.Y(n_10)
);

AO21x2_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_2),
.B(n_4),
.Y(n_11)
);


endmodule