module fake_netlist_822_1101_n_34 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_34);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_3),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_9),
.B(n_14),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_16),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_20),
.B(n_16),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_18),
.A2(n_1),
.B(n_0),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_2),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_SL g28 ( 
.A(n_24),
.B(n_23),
.C(n_19),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI321xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_28),
.A3(n_21),
.B1(n_25),
.B2(n_22),
.C(n_17),
.Y(n_30)
);

OAI221xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_6),
.B1(n_4),
.B2(n_7),
.C(n_8),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_13),
.B1(n_12),
.B2(n_10),
.Y(n_34)
);


endmodule