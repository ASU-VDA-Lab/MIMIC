module fake_netlist_822_543_n_25 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_25);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_25;

wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_2),
.B(n_7),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

AOI21x1_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_3),
.B(n_1),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_14),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.C(n_18),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI31xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_8),
.A3(n_6),
.B(n_5),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.C(n_12),
.Y(n_25)
);


endmodule