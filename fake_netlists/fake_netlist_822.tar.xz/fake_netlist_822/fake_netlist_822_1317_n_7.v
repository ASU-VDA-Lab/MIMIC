module fake_netlist_822_1317_n_7 (n_2, n_0, n_1, n_7);

input n_2;
input n_0;
input n_1;

output n_7;

wire n_6;
wire n_4;
wire n_5;
wire n_3;

CKINVDCx5p33_ASAP7_75t_R g3 ( 
.A(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_2),
.Y(n_5)
);

AOI221xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.C(n_4),
.Y(n_6)
);

BUFx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);


endmodule