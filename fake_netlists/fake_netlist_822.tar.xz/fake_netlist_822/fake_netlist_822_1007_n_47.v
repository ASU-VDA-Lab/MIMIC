module fake_netlist_822_1007_n_47 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_47);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_47;

wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_17;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

NOR2xp67_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_2),
.B(n_10),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_5),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx6_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_1),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_19),
.B1(n_21),
.B2(n_17),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_26),
.Y(n_29)
);

NAND2x1_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_15),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_24),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_24),
.B(n_25),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_33),
.Y(n_34)
);

INVxp67_ASAP7_75t_SL g35 ( 
.A(n_32),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_31),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_25),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_25),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_26),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_23),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_21),
.B1(n_6),
.B2(n_1),
.C(n_5),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

OA21x2_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_7),
.B(n_6),
.Y(n_43)
);

NOR3xp33_ASAP7_75t_SL g44 ( 
.A(n_41),
.B(n_7),
.C(n_3),
.Y(n_44)
);

XNOR2xp5_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_8),
.Y(n_45)
);

AND3x1_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_40),
.C(n_12),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_45),
.B1(n_44),
.B2(n_43),
.Y(n_47)
);


endmodule