module fake_netlist_822_1467_n_25 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_25);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_25;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_9;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx5_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

AO21x2_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_9),
.B(n_12),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

OAI21xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_10),
.B(n_14),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_10),
.B(n_6),
.C(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

OAI221xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_7),
.B1(n_6),
.B2(n_3),
.C(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_21),
.B1(n_7),
.B2(n_8),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);


endmodule