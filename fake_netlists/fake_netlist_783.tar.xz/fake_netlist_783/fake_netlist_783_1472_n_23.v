module fake_netlist_783_1472_n_23 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_23);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_23;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_6),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_4),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_10),
.A2(n_2),
.B(n_1),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.B1(n_13),
.B2(n_17),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_15),
.Y(n_20)
);

OAI22x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_15),
.B1(n_11),
.B2(n_10),
.Y(n_21)
);

AO22x1_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_12),
.B1(n_6),
.B2(n_4),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_7),
.B(n_22),
.Y(n_23)
);


endmodule