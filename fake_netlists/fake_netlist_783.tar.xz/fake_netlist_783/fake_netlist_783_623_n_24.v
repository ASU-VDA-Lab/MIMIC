module fake_netlist_783_623_n_24 (n_1, n_7, n_0, n_5, n_6, n_3, n_2, n_4, n_8, n_24);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_2;
input n_4;
input n_8;

output n_24;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_9;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

NOR2xp33_ASAP7_75t_R g9 ( 
.A(n_1),
.B(n_2),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

A2O1A1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_13)
);

NAND2x1_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_4),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_13),
.B(n_12),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_9),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_0),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B1(n_9),
.B2(n_7),
.C1(n_6),
.C2(n_5),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_7),
.B1(n_6),
.B2(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_7),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_8),
.B1(n_3),
.B2(n_2),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_22),
.B1(n_21),
.B2(n_18),
.Y(n_24)
);


endmodule