module fake_netlist_783_209_n_12 (n_1, n_0, n_5, n_3, n_2, n_4, n_12);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_12;

wire n_7;
wire n_10;
wire n_11;
wire n_6;
wire n_9;
wire n_8;

AOI21xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_5),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_1),
.A2(n_0),
.B(n_2),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_8),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.B1(n_6),
.B2(n_7),
.C(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule