module fake_netlist_783_978_n_43 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_43);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_43;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_18;
wire n_15;
wire n_16;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_41;
wire n_32;
wire n_22;

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_14),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx6p67_ASAP7_75t_R g18 ( 
.A(n_7),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_9),
.B(n_12),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_1),
.B(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_18),
.B1(n_19),
.B2(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

AO21x2_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_4),
.B(n_1),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_SL g25 ( 
.A(n_22),
.B(n_15),
.C(n_21),
.Y(n_25)
);

O2A1O1Ixp33_ASAP7_75t_SL g26 ( 
.A1(n_23),
.A2(n_21),
.B(n_18),
.C(n_4),
.Y(n_26)
);

AOI31xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_19),
.A3(n_16),
.B(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_27),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_29),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_24),
.B(n_6),
.C(n_5),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

NAND2x1p5_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_0),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_33),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_24),
.B1(n_36),
.B2(n_6),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_39),
.Y(n_42)
);

AOI322xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_3),
.A3(n_7),
.B1(n_11),
.B2(n_13),
.C1(n_40),
.C2(n_42),
.Y(n_43)
);


endmodule