module fake_netlist_783_22_n_16 (n_1, n_0, n_5, n_3, n_2, n_4, n_16);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_16;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_6;
wire n_14;
wire n_8;
wire n_12;
wire n_13;
wire n_9;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_3),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_0),
.A2(n_4),
.B1(n_2),
.B2(n_5),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_6),
.B(n_8),
.C(n_13),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);


endmodule