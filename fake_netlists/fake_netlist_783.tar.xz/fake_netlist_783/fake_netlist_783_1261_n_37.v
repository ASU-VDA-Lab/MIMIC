module fake_netlist_783_1261_n_37 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_6, n_14, n_3, n_9, n_2, n_12, n_13, n_4, n_8, n_37);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_6;
input n_14;
input n_3;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_37;

wire n_20;
wire n_29;
wire n_36;
wire n_17;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_24;
wire n_26;
wire n_18;
wire n_16;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

BUFx2_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

AOI21x1_ASAP7_75t_L g19 ( 
.A1(n_7),
.A2(n_0),
.B(n_9),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_7),
.B(n_13),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_3),
.B(n_2),
.Y(n_23)
);

INVx5_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_11),
.B(n_8),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_22),
.Y(n_26)
);

OR2x6_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_20),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_17),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_26),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_27),
.B1(n_25),
.B2(n_20),
.Y(n_31)
);

AOI211xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_18),
.B(n_1),
.C(n_0),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_4),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

OAI221xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_19),
.B1(n_6),
.B2(n_5),
.C(n_14),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_5),
.B1(n_15),
.B2(n_36),
.Y(n_37)
);


endmodule