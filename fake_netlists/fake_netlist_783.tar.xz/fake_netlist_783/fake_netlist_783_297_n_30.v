module fake_netlist_783_297_n_30 (n_1, n_7, n_10, n_0, n_11, n_5, n_6, n_3, n_9, n_2, n_12, n_4, n_8, n_30);

input n_1;
input n_7;
input n_10;
input n_0;
input n_11;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_12;
input n_4;
input n_8;

output n_30;

wire n_20;
wire n_29;
wire n_17;
wire n_25;
wire n_27;
wire n_24;
wire n_26;
wire n_18;
wire n_13;
wire n_15;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_5),
.A2(n_3),
.B1(n_8),
.B2(n_12),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_7),
.Y(n_18)
);

BUFx12f_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_R g22 ( 
.A(n_20),
.B(n_7),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OAI21xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_14),
.B(n_15),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_16),
.B1(n_21),
.B2(n_0),
.Y(n_25)
);

NOR2x1_ASAP7_75t_SL g26 ( 
.A(n_24),
.B(n_16),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_10),
.B1(n_4),
.B2(n_2),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

XOR2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_28),
.Y(n_30)
);


endmodule