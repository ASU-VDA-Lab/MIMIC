module fake_netlist_907_965_n_42 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_42);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_42;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_13;
wire n_32;
wire n_25;
wire n_14;
wire n_22;
wire n_21;
wire n_35;
wire n_41;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

BUFx8_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_9),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_10),
.Y(n_16)
);

XOR2xp5_ASAP7_75t_L g17 ( 
.A(n_5),
.B(n_6),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_1),
.A2(n_4),
.B(n_2),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_3),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_15),
.A2(n_7),
.B(n_5),
.C(n_0),
.Y(n_21)
);

O2A1O1Ixp5_ASAP7_75t_L g22 ( 
.A1(n_15),
.A2(n_11),
.B(n_8),
.C(n_0),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_7),
.B(n_16),
.Y(n_23)
);

INVx4_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_14),
.B(n_13),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_19),
.Y(n_26)
);

OR2x6_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_18),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_24),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_SL g29 ( 
.A1(n_23),
.A2(n_12),
.B1(n_19),
.B2(n_17),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_24),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

NAND2xp33_ASAP7_75t_R g34 ( 
.A(n_30),
.B(n_31),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_30),
.Y(n_35)
);

AOI32xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_12),
.A3(n_20),
.B1(n_34),
.B2(n_28),
.Y(n_36)
);

A2O1A1Ixp33_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_22),
.B(n_32),
.C(n_21),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_36),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_12),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_38),
.B1(n_40),
.B2(n_27),
.Y(n_42)
);


endmodule