module fake_netlist_907_2122_n_39 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_39);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_39;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_13;
wire n_21;
wire n_25;
wire n_14;
wire n_22;
wire n_32;
wire n_35;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_7),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_0),
.B(n_5),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_11),
.B(n_0),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_1),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_12),
.B(n_1),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_13),
.A2(n_9),
.B(n_4),
.Y(n_21)
);

AO32x1_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_4),
.A3(n_5),
.B1(n_6),
.B2(n_14),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_19),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_17),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_14),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_24),
.B(n_15),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_25),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

NAND4xp25_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_29),
.C(n_22),
.D(n_28),
.Y(n_32)
);

NAND4xp25_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_22),
.C(n_6),
.D(n_26),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_32),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_33),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_33),
.B(n_16),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_37),
.A2(n_34),
.B1(n_36),
.B2(n_38),
.Y(n_39)
);


endmodule