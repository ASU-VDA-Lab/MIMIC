module fake_netlist_907_883_n_16 (n_0, n_1, n_3, n_2, n_16);

input n_0;
input n_1;
input n_3;
input n_2;

output n_16;

wire n_5;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

INVx2_ASAP7_75t_SL g5 ( 
.A(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_0),
.Y(n_6)
);

NOR3xp33_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_0),
.C(n_3),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_8),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_2),
.B1(n_7),
.B2(n_12),
.C1(n_14),
.C2(n_11),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B(n_12),
.Y(n_16)
);


endmodule