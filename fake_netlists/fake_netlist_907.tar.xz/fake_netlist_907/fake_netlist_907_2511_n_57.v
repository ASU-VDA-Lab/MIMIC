module fake_netlist_907_2511_n_57 (n_3, n_15, n_11, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_57);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_57;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_54;
wire n_28;
wire n_53;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_25;
wire n_35;
wire n_42;
wire n_41;
wire n_43;
wire n_44;
wire n_36;
wire n_26;
wire n_45;
wire n_29;
wire n_48;
wire n_38;
wire n_56;

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_18),
.B(n_22),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_7),
.Y(n_29)
);

INVx6_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_8),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_15),
.B(n_19),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_SL g33 ( 
.A(n_9),
.B(n_2),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

NAND2x1p5_ASAP7_75t_L g36 ( 
.A(n_27),
.B(n_16),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_24),
.A2(n_19),
.B1(n_17),
.B2(n_0),
.Y(n_37)
);

A2O1A1Ixp33_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_31),
.B(n_28),
.C(n_32),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_32),
.B(n_25),
.Y(n_39)
);

INVxp67_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_36),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_38),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_38),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_37),
.Y(n_47)
);

AOI222xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_33),
.B1(n_26),
.B2(n_25),
.C1(n_29),
.C2(n_17),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

OAI22x1_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_33),
.B1(n_26),
.B2(n_25),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_26),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_R g52 ( 
.A1(n_48),
.A2(n_4),
.B1(n_3),
.B2(n_1),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_11),
.B1(n_10),
.B2(n_5),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_SL g55 ( 
.A1(n_54),
.A2(n_52),
.B1(n_13),
.B2(n_12),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

AOI22x1_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_14),
.B1(n_21),
.B2(n_55),
.Y(n_57)
);


endmodule