module fake_netlist_907_1590_n_38 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_38);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_38;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_13;
wire n_22;
wire n_25;
wire n_32;
wire n_35;
wire n_14;
wire n_26;
wire n_36;
wire n_29;

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

NOR2xp67_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_2),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

BUFx6f_ASAP7_75t_SL g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_1),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_15),
.A2(n_6),
.B1(n_4),
.B2(n_3),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_19),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_SL g27 ( 
.A(n_19),
.B(n_12),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_21),
.Y(n_28)
);

OR2x2_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_23),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_SL g30 ( 
.A(n_29),
.B(n_27),
.C(n_24),
.Y(n_30)
);

AND2x4_ASAP7_75t_SL g31 ( 
.A(n_28),
.B(n_16),
.Y(n_31)
);

AO22x2_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_24),
.B1(n_25),
.B2(n_4),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_25),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_32),
.Y(n_36)
);

OAI22x1_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_34),
.B2(n_30),
.Y(n_37)
);

AOI222xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_14),
.B1(n_6),
.B2(n_11),
.C1(n_10),
.C2(n_9),
.Y(n_38)
);


endmodule