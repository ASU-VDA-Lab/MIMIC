module fake_netlist_907_3801_n_47 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_47);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_47;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_41;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_38;

INVx1_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_1),
.B(n_9),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_10),
.B(n_11),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_17),
.B(n_21),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_3),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_20),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_12),
.B(n_4),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_16),
.Y(n_31)
);

BUFx3_ASAP7_75t_L g32 ( 
.A(n_25),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_28),
.B(n_16),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

BUFx12f_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_31),
.C(n_32),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_31),
.B1(n_29),
.B2(n_27),
.C(n_23),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_35),
.B1(n_37),
.B2(n_27),
.Y(n_38)
);

INVx1_ASAP7_75t_SL g39 ( 
.A(n_36),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_29),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_26),
.B1(n_30),
.B2(n_24),
.C(n_18),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_7),
.B(n_0),
.Y(n_44)
);

AO22x2_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_19),
.B1(n_18),
.B2(n_8),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_14),
.B(n_13),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_SL g47 ( 
.A1(n_46),
.A2(n_45),
.B1(n_19),
.B2(n_15),
.Y(n_47)
);


endmodule