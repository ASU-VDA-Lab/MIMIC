module fake_netlist_907_2988_n_40 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_40);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_40;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_39;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_2),
.B(n_10),
.Y(n_19)
);

INVxp67_ASAP7_75t_SL g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_8),
.Y(n_21)
);

NOR2xp67_ASAP7_75t_L g22 ( 
.A(n_12),
.B(n_17),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_16),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_13),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_20),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_13),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_28),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_25),
.B1(n_19),
.B2(n_21),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_31),
.Y(n_34)
);

AOI211xp5_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_22),
.B(n_19),
.C(n_15),
.Y(n_35)
);

OAI211xp5_ASAP7_75t_SL g36 ( 
.A1(n_34),
.A2(n_15),
.B(n_23),
.C(n_1),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_R g37 ( 
.A(n_35),
.B(n_3),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_37),
.B1(n_7),
.B2(n_4),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_14),
.B1(n_11),
.B2(n_9),
.Y(n_40)
);


endmodule