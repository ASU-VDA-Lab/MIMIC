module fake_netlist_907_1360_n_36 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_36);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_36;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_32;
wire n_35;
wire n_26;
wire n_29;

INVx3_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_8),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_1),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

BUFx4f_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

AOI22x1_ASAP7_75t_L g19 ( 
.A1(n_11),
.A2(n_10),
.B1(n_9),
.B2(n_6),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_12),
.A2(n_3),
.B(n_2),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_15),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_SL g25 ( 
.A(n_20),
.B(n_14),
.C(n_13),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_24),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_22),
.B(n_16),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

OAI21xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_27),
.B(n_26),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_28),
.B1(n_25),
.B2(n_23),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

CKINVDCx16_ASAP7_75t_R g34 ( 
.A(n_31),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_34),
.B1(n_19),
.B2(n_4),
.Y(n_36)
);


endmodule