module fake_netlist_907_79_n_37 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_37);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_37;

wire n_33;
wire n_34;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

BUFx3_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

AND2x2_ASAP7_75t_SL g20 ( 
.A(n_11),
.B(n_12),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_7),
.B(n_15),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_4),
.B(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

NOR3xp33_ASAP7_75t_SL g26 ( 
.A(n_21),
.B(n_1),
.C(n_0),
.Y(n_26)
);

BUFx4f_ASAP7_75t_SL g27 ( 
.A(n_20),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_25),
.B1(n_23),
.B2(n_19),
.Y(n_29)
);

OAI21x1_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_24),
.B(n_22),
.Y(n_30)
);

AOI21xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B(n_2),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI31xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_8),
.A3(n_6),
.B(n_3),
.Y(n_33)
);

CKINVDCx16_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

INVxp67_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_10),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_18),
.B2(n_13),
.Y(n_37)
);


endmodule