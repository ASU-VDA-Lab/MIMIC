module fake_netlist_907_3330_n_48 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_48);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_48;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_13;
wire n_21;
wire n_32;
wire n_22;
wire n_14;
wire n_25;
wire n_35;
wire n_42;
wire n_41;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_45;
wire n_44;
wire n_38;

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_2),
.Y(n_12)
);

AND2x6_ASAP7_75t_L g13 ( 
.A(n_5),
.B(n_1),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_11),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

OR2x2_ASAP7_75t_SL g23 ( 
.A(n_14),
.B(n_18),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_SL g25 ( 
.A(n_14),
.B(n_4),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_14),
.Y(n_26)
);

OR2x6_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_18),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_24),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

OAI31xp33_ASAP7_75t_L g33 ( 
.A1(n_29),
.A2(n_25),
.A3(n_26),
.B(n_12),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

AND2x2_ASAP7_75t_SL g35 ( 
.A(n_32),
.B(n_30),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_SL g36 ( 
.A(n_33),
.B(n_25),
.C(n_15),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_30),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

NOR4xp25_ASAP7_75t_SL g39 ( 
.A(n_36),
.B(n_19),
.C(n_13),
.D(n_5),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_27),
.Y(n_40)
);

NAND2xp33_ASAP7_75t_R g41 ( 
.A(n_39),
.B(n_6),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_SL g43 ( 
.A(n_42),
.B(n_39),
.C(n_37),
.Y(n_43)
);

AOI22x1_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_18),
.B1(n_13),
.B2(n_28),
.Y(n_44)
);

AND3x1_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_7),
.C(n_8),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_SL g47 ( 
.A(n_45),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_28),
.A3(n_44),
.B1(n_47),
.B2(n_43),
.C1(n_25),
.C2(n_17),
.Y(n_48)
);


endmodule