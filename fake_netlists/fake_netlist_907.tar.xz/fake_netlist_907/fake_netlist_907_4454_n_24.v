module fake_netlist_907_4454_n_24 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_24);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_24;

wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_7),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_1),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_2),
.A2(n_0),
.B1(n_3),
.B2(n_5),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_9),
.B(n_10),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_11),
.Y(n_16)
);

NOR2xp67_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_15),
.Y(n_17)
);

O2A1O1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_16),
.B(n_14),
.C(n_10),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_7),
.B(n_6),
.Y(n_19)
);

NOR2x1_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_6),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_6),
.Y(n_21)
);

AO22x2_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_23)
);

OAI31xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_4),
.A3(n_23),
.B(n_10),
.Y(n_24)
);


endmodule