module fake_netlist_907_1365_n_36 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_36);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_36;

wire n_33;
wire n_34;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_31;
wire n_21;
wire n_22;
wire n_25;
wire n_32;
wire n_35;
wire n_26;
wire n_29;

INVx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_8),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_25),
.B(n_22),
.C(n_21),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_24),
.B1(n_23),
.B2(n_20),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_19),
.B1(n_1),
.B2(n_0),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_28),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_2),
.Y(n_31)
);

AOI32xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_4),
.A3(n_3),
.B1(n_6),
.B2(n_9),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

OR3x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_12),
.C(n_11),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_34),
.B1(n_16),
.B2(n_14),
.Y(n_36)
);


endmodule