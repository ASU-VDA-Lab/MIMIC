module fake_netlist_907_803_n_18 (n_0, n_2, n_5, n_3, n_4, n_1, n_18);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_18;

wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_17;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

INVx1_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

OAI22xp33_ASAP7_75t_SL g7 ( 
.A1(n_0),
.A2(n_2),
.B1(n_1),
.B2(n_5),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_2),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_3),
.B(n_4),
.Y(n_10)
);

OA21x2_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.B(n_8),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx4_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_8),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_11),
.B(n_10),
.Y(n_15)
);

OAI321xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.A3(n_14),
.B1(n_7),
.B2(n_11),
.C(n_12),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_7),
.B1(n_13),
.B2(n_12),
.Y(n_18)
);


endmodule