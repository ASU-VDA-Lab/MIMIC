module fake_netlist_907_2621_n_34 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_34);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_34;

wire n_33;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_25;
wire n_22;
wire n_32;
wire n_26;
wire n_29;

INVx2_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_11),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_8),
.B(n_0),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_1),
.B(n_9),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_16),
.B1(n_6),
.B2(n_4),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_18),
.C(n_17),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_23),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_22),
.B1(n_19),
.B2(n_21),
.C(n_6),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_26),
.Y(n_28)
);

NAND2x1_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_19),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_29),
.B(n_16),
.Y(n_30)
);

OAI222xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_7),
.B1(n_3),
.B2(n_10),
.C1(n_13),
.C2(n_12),
.Y(n_31)
);

INVxp67_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_31),
.B1(n_15),
.B2(n_14),
.Y(n_34)
);


endmodule