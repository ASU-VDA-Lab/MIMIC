module fake_netlist_907_2531_n_6 (n_0, n_1, n_2, n_6);

input n_0;
input n_1;
input n_2;

output n_6;

wire n_5;
wire n_3;
wire n_4;

AND2x4_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.Y(n_3)
);

OAI21x1_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_4),
.Y(n_5)
);

OR3x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_3),
.C(n_4),
.Y(n_6)
);


endmodule