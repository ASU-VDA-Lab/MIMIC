module fake_netlist_907_2182_n_56 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_56);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_56;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_19;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_41;
wire n_35;
wire n_42;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

INVx1_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_12),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

BUFx10_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_0),
.Y(n_26)
);

O2A1O1Ixp33_ASAP7_75t_SL g27 ( 
.A1(n_17),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_22),
.B(n_1),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_20),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_20),
.A2(n_11),
.B1(n_5),
.B2(n_3),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_25),
.B1(n_21),
.B2(n_19),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_33),
.B(n_21),
.Y(n_35)
);

INVx2_ASAP7_75t_SL g36 ( 
.A(n_31),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_29),
.B(n_25),
.Y(n_37)
);

OR2x2_ASAP7_75t_SL g38 ( 
.A(n_32),
.B(n_23),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_L g39 ( 
.A(n_28),
.B(n_24),
.C(n_11),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_29),
.Y(n_40)
);

INVx2_ASAP7_75t_SL g41 ( 
.A(n_36),
.Y(n_41)
);

INVxp67_ASAP7_75t_SL g42 ( 
.A(n_37),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_37),
.B(n_28),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_35),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_34),
.Y(n_45)
);

INVx1_ASAP7_75t_SL g46 ( 
.A(n_40),
.Y(n_46)
);

NOR3xp33_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_39),
.C(n_41),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_42),
.B(n_43),
.Y(n_48)
);

AOI211x1_ASAP7_75t_SL g49 ( 
.A1(n_45),
.A2(n_38),
.B(n_27),
.C(n_16),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

BUFx2_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

XNOR2x1_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_43),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_15),
.B1(n_14),
.B2(n_7),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_50),
.B1(n_54),
.B2(n_55),
.Y(n_56)
);


endmodule