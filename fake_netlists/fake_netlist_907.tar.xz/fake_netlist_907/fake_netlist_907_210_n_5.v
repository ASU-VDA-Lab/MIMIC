module fake_netlist_907_210_n_5 (n_0, n_5);

input n_0;

output n_5;

wire n_2;
wire n_3;
wire n_4;
wire n_1;

BUFx3_ASAP7_75t_L g1 ( 
.A(n_0),
.Y(n_1)
);

INVx1_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_SL g5 ( 
.A(n_4),
.Y(n_5)
);


endmodule