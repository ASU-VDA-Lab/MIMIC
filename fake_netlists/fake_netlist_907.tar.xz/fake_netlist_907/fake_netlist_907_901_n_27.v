module fake_netlist_907_901_n_27 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_27);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_27;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;

INVx1_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_0),
.B1(n_4),
.B2(n_2),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_1),
.Y(n_13)
);

INVxp67_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_12),
.C(n_13),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

AOI21xp33_ASAP7_75t_SL g21 ( 
.A1(n_19),
.A2(n_10),
.B(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_13),
.C(n_11),
.Y(n_23)
);

OAI211xp5_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_18),
.B(n_16),
.C(n_3),
.Y(n_24)
);

OA22x2_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_22),
.B1(n_18),
.B2(n_16),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_23),
.A2(n_6),
.B1(n_5),
.B2(n_3),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_6),
.B1(n_7),
.B2(n_25),
.Y(n_27)
);


endmodule