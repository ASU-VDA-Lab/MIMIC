module fake_netlist_907_3631_n_25 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_25;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_10;

INVx1_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_4),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_2),
.B1(n_0),
.B2(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

A2O1A1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B(n_11),
.C(n_10),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

OAI22x1_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_14),
.B(n_6),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_6),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI322xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_18),
.A3(n_17),
.B1(n_15),
.B2(n_7),
.C1(n_1),
.C2(n_2),
.Y(n_20)
);

AOI21xp33_ASAP7_75t_SL g21 ( 
.A1(n_19),
.A2(n_3),
.B(n_1),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_3),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_23),
.B1(n_22),
.B2(n_16),
.Y(n_25)
);


endmodule