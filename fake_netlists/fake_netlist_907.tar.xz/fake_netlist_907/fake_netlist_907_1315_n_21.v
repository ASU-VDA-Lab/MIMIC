module fake_netlist_907_1315_n_21 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_21;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_1),
.Y(n_8)
);

INVx4_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_SL g10 ( 
.A1(n_5),
.A2(n_4),
.B1(n_6),
.B2(n_2),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_4),
.B(n_1),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_2),
.Y(n_12)
);

INVx2_ASAP7_75t_SL g13 ( 
.A(n_9),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_12),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B1(n_8),
.B2(n_10),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_7),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_10),
.Y(n_19)
);

OAI22xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.B1(n_16),
.B2(n_14),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_15),
.B1(n_18),
.B2(n_19),
.C(n_17),
.Y(n_21)
);


endmodule