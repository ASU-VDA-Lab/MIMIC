module fake_netlist_907_4260_n_16 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_16);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_16;

wire n_15;
wire n_11;
wire n_9;
wire n_13;
wire n_14;
wire n_10;
wire n_8;
wire n_12;

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_1),
.A2(n_0),
.B1(n_6),
.B2(n_4),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

CKINVDCx16_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND4xp25_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_8),
.C(n_7),
.D(n_6),
.Y(n_14)
);

XNOR2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_7),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_15),
.B(n_5),
.Y(n_16)
);


endmodule