module fake_netlist_907_2341_n_42 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_42);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_42;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_35;
wire n_22;
wire n_41;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_1),
.B(n_7),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_SL g22 ( 
.A(n_10),
.B(n_19),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_0),
.B(n_14),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

OA21x2_ASAP7_75t_L g25 ( 
.A1(n_3),
.A2(n_16),
.B(n_11),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_12),
.B(n_2),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_15),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_27),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_30),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_23),
.B1(n_20),
.B2(n_26),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_28),
.B1(n_25),
.B2(n_26),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_31),
.B(n_25),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_28),
.Y(n_37)
);

OA22x2_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_18),
.B1(n_17),
.B2(n_22),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_17),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_25),
.B1(n_18),
.B2(n_5),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_40),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_13),
.B1(n_9),
.B2(n_8),
.Y(n_42)
);


endmodule