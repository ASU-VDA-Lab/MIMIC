module fake_netlist_737_336_n_25 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_25);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_25;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_24;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_6),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_13),
.B(n_6),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_11),
.B(n_1),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_12),
.B(n_3),
.Y(n_18)
);

AO21x2_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_17),
.B(n_4),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_14),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_15),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVxp33_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_7),
.B1(n_9),
.B2(n_8),
.Y(n_25)
);


endmodule