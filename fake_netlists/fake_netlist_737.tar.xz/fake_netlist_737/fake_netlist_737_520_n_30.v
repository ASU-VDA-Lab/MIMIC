module fake_netlist_737_520_n_30 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_30);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_30;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_29;

INVxp67_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_0),
.Y(n_11)
);

OA21x2_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_4),
.B(n_9),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_4),
.B(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_2),
.B(n_5),
.Y(n_14)
);

INVx5_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_10),
.B(n_11),
.C(n_13),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_10),
.B1(n_14),
.B2(n_0),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_15),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_16),
.C(n_1),
.Y(n_21)
);

NOR4xp25_ASAP7_75t_SL g22 ( 
.A(n_19),
.B(n_15),
.C(n_3),
.D(n_2),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_20),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_15),
.Y(n_24)
);

OAI211xp5_ASAP7_75t_SL g25 ( 
.A1(n_23),
.A2(n_16),
.B(n_6),
.C(n_5),
.Y(n_25)
);

OAI22xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_15),
.B1(n_16),
.B2(n_6),
.Y(n_26)
);

XNOR2x1_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_7),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_8),
.C(n_7),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_15),
.B1(n_28),
.B2(n_27),
.Y(n_30)
);


endmodule