module fake_netlist_737_513_n_17 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_17);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;

output n_17;

wire n_14;
wire n_9;
wire n_16;
wire n_13;
wire n_11;
wire n_12;
wire n_15;
wire n_10;
wire n_8;

INVx4_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_2),
.Y(n_9)
);

OAI22xp33_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_4),
.B1(n_7),
.B2(n_1),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_1),
.Y(n_11)
);

AO32x2_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_2),
.A3(n_0),
.B1(n_4),
.B2(n_5),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_9),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B(n_9),
.Y(n_14)
);

OAI21xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B(n_11),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI322xp5_ASAP7_75t_R g17 ( 
.A1(n_16),
.A2(n_0),
.A3(n_7),
.B1(n_10),
.B2(n_13),
.C1(n_12),
.C2(n_15),
.Y(n_17)
);


endmodule