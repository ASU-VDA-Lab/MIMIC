module fake_netlist_737_1189_n_45 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_45);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_45;

wire n_20;
wire n_23;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

AND2x2_ASAP7_75t_L g19 ( 
.A(n_4),
.B(n_11),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_17),
.Y(n_20)
);

BUFx12f_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_12),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_8),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_16),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_7),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_22),
.B(n_17),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_20),
.B(n_0),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_25),
.B(n_24),
.Y(n_33)
);

OAI22x1_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_28),
.B1(n_26),
.B2(n_23),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_32),
.Y(n_35)
);

AO21x2_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_29),
.B(n_19),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_27),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_35),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_2),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_9),
.B1(n_6),
.B2(n_3),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_42),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_18),
.B1(n_14),
.B2(n_13),
.Y(n_45)
);


endmodule