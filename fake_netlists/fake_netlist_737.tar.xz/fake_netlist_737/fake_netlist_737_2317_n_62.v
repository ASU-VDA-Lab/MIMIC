module fake_netlist_737_2317_n_62 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_62);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_62;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_22;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_42;
wire n_37;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_7),
.B(n_18),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_6),
.B(n_4),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_11),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

CKINVDCx8_ASAP7_75t_R g28 ( 
.A(n_3),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_0),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_26),
.B(n_2),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_0),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_23),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_24),
.Y(n_36)
);

OAI21x1_ASAP7_75t_SL g37 ( 
.A1(n_31),
.A2(n_28),
.B(n_20),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_20),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

INVx4_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

INVxp67_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

NAND4xp25_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_33),
.C(n_19),
.D(n_27),
.Y(n_43)
);

INVx1_ASAP7_75t_SL g44 ( 
.A(n_40),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_37),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_35),
.B1(n_23),
.B2(n_34),
.Y(n_47)
);

NOR4xp25_ASAP7_75t_SL g48 ( 
.A(n_47),
.B(n_34),
.C(n_28),
.D(n_30),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_40),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

NOR2x1_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_51),
.Y(n_52)
);

INVx1_ASAP7_75t_SL g53 ( 
.A(n_50),
.Y(n_53)
);

NAND4xp75_ASAP7_75t_L g54 ( 
.A(n_48),
.B(n_25),
.C(n_39),
.D(n_14),
.Y(n_54)
);

CKINVDCx20_ASAP7_75t_R g55 ( 
.A(n_49),
.Y(n_55)
);

NAND5xp2_ASAP7_75t_L g56 ( 
.A(n_55),
.B(n_15),
.C(n_14),
.D(n_16),
.E(n_17),
.Y(n_56)
);

INVx1_ASAP7_75t_SL g57 ( 
.A(n_53),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_52),
.Y(n_58)
);

OR2x2_ASAP7_75t_L g59 ( 
.A(n_54),
.B(n_44),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_59),
.Y(n_61)
);

AOI322xp5_ASAP7_75t_L g62 ( 
.A1(n_60),
.A2(n_9),
.A3(n_13),
.B1(n_35),
.B2(n_61),
.C1(n_57),
.C2(n_56),
.Y(n_62)
);


endmodule