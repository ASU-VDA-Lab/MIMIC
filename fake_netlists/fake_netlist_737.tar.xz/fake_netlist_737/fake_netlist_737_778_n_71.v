module fake_netlist_737_778_n_71 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_71);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_71;

wire n_23;
wire n_46;
wire n_44;
wire n_66;
wire n_61;
wire n_64;
wire n_22;
wire n_62;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_68;
wire n_49;
wire n_28;
wire n_65;
wire n_37;
wire n_27;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_57;
wire n_35;
wire n_63;
wire n_25;
wire n_70;
wire n_69;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_67;
wire n_55;
wire n_47;
wire n_29;
wire n_52;
wire n_54;
wire n_32;

AND2x6_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_13),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx5_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_4),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_7),
.B(n_15),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_11),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_2),
.B(n_20),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_20),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_26),
.B(n_3),
.Y(n_33)
);

INVx5_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_16),
.B1(n_11),
.B2(n_3),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

AO31x2_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_30),
.A3(n_37),
.B(n_28),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_23),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_33),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_34),
.A2(n_27),
.B(n_25),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_24),
.Y(n_42)
);

OR2x6_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_31),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_34),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_24),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_38),
.Y(n_46)
);

INVxp67_ASAP7_75t_SL g47 ( 
.A(n_44),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_38),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_46),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_43),
.Y(n_51)
);

INVx2_ASAP7_75t_SL g52 ( 
.A(n_47),
.Y(n_52)
);

AOI21xp5_ASAP7_75t_SL g53 ( 
.A1(n_52),
.A2(n_29),
.B(n_22),
.Y(n_53)
);

OAI221xp5_ASAP7_75t_L g54 ( 
.A1(n_49),
.A2(n_35),
.B1(n_26),
.B2(n_41),
.C(n_29),
.Y(n_54)
);

AOI321xp33_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_26),
.A3(n_19),
.B1(n_17),
.B2(n_21),
.C(n_18),
.Y(n_55)
);

NOR2xp33_ASAP7_75t_L g56 ( 
.A(n_51),
.B(n_34),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_50),
.B(n_38),
.Y(n_57)
);

NAND3xp33_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_26),
.C(n_52),
.Y(n_58)
);

NAND4xp75_ASAP7_75t_L g59 ( 
.A(n_57),
.B(n_56),
.C(n_53),
.D(n_54),
.Y(n_59)
);

NOR2xp33_ASAP7_75t_L g60 ( 
.A(n_54),
.B(n_17),
.Y(n_60)
);

NOR5xp2_ASAP7_75t_L g61 ( 
.A(n_54),
.B(n_21),
.C(n_18),
.D(n_22),
.E(n_0),
.Y(n_61)
);

NAND3xp33_ASAP7_75t_L g62 ( 
.A(n_55),
.B(n_34),
.C(n_22),
.Y(n_62)
);

AND3x4_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_22),
.C(n_1),
.Y(n_63)
);

AND2x4_ASAP7_75t_L g64 ( 
.A(n_60),
.B(n_8),
.Y(n_64)
);

HB1xp67_ASAP7_75t_L g65 ( 
.A(n_59),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_62),
.B(n_9),
.Y(n_66)
);

INVx2_ASAP7_75t_L g67 ( 
.A(n_64),
.Y(n_67)
);

XOR2x2_ASAP7_75t_L g68 ( 
.A(n_63),
.B(n_12),
.Y(n_68)
);

BUFx2_ASAP7_75t_L g69 ( 
.A(n_64),
.Y(n_69)
);

OAI21x1_ASAP7_75t_L g70 ( 
.A1(n_67),
.A2(n_66),
.B(n_65),
.Y(n_70)
);

AO221x2_ASAP7_75t_L g71 ( 
.A1(n_70),
.A2(n_69),
.B1(n_68),
.B2(n_61),
.C(n_14),
.Y(n_71)
);


endmodule