module fake_netlist_737_889_n_16 (n_1, n_2, n_3, n_4, n_0, n_16);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_16;

wire n_12;
wire n_15;
wire n_14;
wire n_8;
wire n_9;
wire n_10;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_11;

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_2),
.B(n_4),
.Y(n_5)
);

AND2x4_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_3),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_0),
.Y(n_7)
);

BUFx3_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_5),
.Y(n_10)
);

XNOR2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

OAI221xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.C(n_0),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_8),
.B1(n_4),
.B2(n_1),
.C(n_2),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_8),
.B(n_1),
.Y(n_14)
);

AOI211x1_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_8),
.B(n_2),
.C(n_1),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_3),
.B1(n_4),
.B2(n_15),
.Y(n_16)
);


endmodule