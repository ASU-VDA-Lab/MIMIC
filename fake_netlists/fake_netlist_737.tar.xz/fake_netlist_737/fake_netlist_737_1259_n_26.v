module fake_netlist_737_1259_n_26 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_26);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_26;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_24;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;

INVx1_ASAP7_75t_SL g12 ( 
.A(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx16_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

AND2x6_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_6),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

INVx4_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_2),
.B(n_1),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_7),
.B1(n_4),
.B2(n_3),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_20),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_14),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_21),
.B(n_17),
.Y(n_24)
);

OAI22xp33_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_12),
.B1(n_13),
.B2(n_15),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_15),
.B1(n_7),
.B2(n_4),
.C1(n_10),
.C2(n_8),
.Y(n_26)
);


endmodule