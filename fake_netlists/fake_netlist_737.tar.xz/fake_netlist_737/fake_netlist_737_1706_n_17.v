module fake_netlist_737_1706_n_17 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_17);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;

output n_17;

wire n_14;
wire n_9;
wire n_16;
wire n_13;
wire n_11;
wire n_12;
wire n_15;
wire n_10;
wire n_8;

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_8),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_8),
.B1(n_6),
.B2(n_11),
.C(n_2),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B(n_3),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_6),
.B(n_4),
.Y(n_17)
);


endmodule