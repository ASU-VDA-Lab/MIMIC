module fake_netlist_737_203_n_58 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_58);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_58;

wire n_20;
wire n_23;
wire n_46;
wire n_14;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_13;
wire n_39;
wire n_11;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_56;
wire n_12;
wire n_19;
wire n_15;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

NAND2xp33_ASAP7_75t_R g17 ( 
.A(n_2),
.B(n_0),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_3),
.B(n_4),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_4),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_1),
.B(n_0),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_0),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_13),
.B(n_1),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_18),
.A2(n_4),
.B(n_2),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_12),
.A2(n_6),
.B(n_5),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_SL g26 ( 
.A(n_12),
.B(n_5),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_SL g28 ( 
.A(n_16),
.B(n_5),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_19),
.B(n_6),
.Y(n_29)
);

NOR2xp67_ASAP7_75t_SL g30 ( 
.A(n_23),
.B(n_19),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

OR2x6_ASAP7_75t_L g32 ( 
.A(n_23),
.B(n_17),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_14),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

NOR3xp33_ASAP7_75t_SL g36 ( 
.A(n_29),
.B(n_17),
.C(n_15),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_27),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_33),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_32),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_32),
.B1(n_35),
.B2(n_31),
.Y(n_42)
);

OAI322xp33_ASAP7_75t_L g43 ( 
.A1(n_37),
.A2(n_20),
.A3(n_28),
.B1(n_26),
.B2(n_22),
.C1(n_31),
.C2(n_34),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

NAND4xp25_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_28),
.C(n_26),
.D(n_20),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_SL g47 ( 
.A1(n_43),
.A2(n_39),
.B1(n_38),
.B2(n_41),
.C(n_32),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_SL g48 ( 
.A1(n_44),
.A2(n_38),
.B1(n_39),
.B2(n_32),
.C(n_36),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_32),
.B1(n_30),
.B2(n_6),
.Y(n_50)
);

AND2x4_ASAP7_75t_SL g51 ( 
.A(n_49),
.B(n_45),
.Y(n_51)
);

AOI21xp5_ASAP7_75t_L g52 ( 
.A1(n_49),
.A2(n_30),
.B(n_7),
.Y(n_52)
);

AND2x4_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_7),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_46),
.Y(n_54)
);

OAI22xp5_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_47),
.B1(n_48),
.B2(n_3),
.Y(n_55)
);

HB1xp67_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

OAI22x1_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_8),
.B1(n_54),
.B2(n_52),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_SL g58 ( 
.A1(n_56),
.A2(n_57),
.B1(n_53),
.B2(n_55),
.Y(n_58)
);


endmodule