module fake_netlist_737_2541_n_21 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_21);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_21;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_17;
wire n_12;
wire n_15;
wire n_19;

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

AOI21x1_ASAP7_75t_L g12 ( 
.A1(n_4),
.A2(n_1),
.B(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

NAND3x1_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_5),
.C(n_4),
.Y(n_14)
);

OAI21xp33_ASAP7_75t_SL g15 ( 
.A1(n_10),
.A2(n_6),
.B(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_15),
.B(n_13),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_7),
.Y(n_19)
);

OA21x2_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_2),
.B(n_0),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_8),
.B(n_19),
.Y(n_21)
);


endmodule