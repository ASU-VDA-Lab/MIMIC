module fake_netlist_737_763_n_23 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_23);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_23;

wire n_20;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_1),
.B(n_3),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_9),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_1),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_SL g16 ( 
.A1(n_13),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_11),
.B1(n_13),
.B2(n_16),
.Y(n_19)
);

AOI21xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_6),
.B(n_4),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

AOI22x1_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_7),
.B1(n_8),
.B2(n_2),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_7),
.B1(n_10),
.B2(n_21),
.Y(n_23)
);


endmodule