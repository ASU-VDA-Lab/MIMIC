module fake_netlist_737_2593_n_47 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_47);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_47;

wire n_20;
wire n_23;
wire n_46;
wire n_14;
wire n_44;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_15;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_0),
.B(n_10),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_10),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_13),
.B(n_11),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_5),
.B(n_8),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_15),
.B(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_17),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_14),
.Y(n_27)
);

OAI221xp5_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_15),
.B1(n_16),
.B2(n_20),
.C(n_21),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_23),
.B1(n_25),
.B2(n_22),
.Y(n_29)
);

NAND4xp25_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_22),
.C(n_15),
.D(n_23),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_27),
.C(n_26),
.Y(n_31)
);

NAND4xp25_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_23),
.C(n_25),
.D(n_21),
.Y(n_32)
);

NOR2x1_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_18),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_25),
.B1(n_20),
.B2(n_19),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_31),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_20),
.B1(n_4),
.B2(n_2),
.Y(n_38)
);

OAI221xp5_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_20),
.B1(n_6),
.B2(n_4),
.C(n_5),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_39),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_37),
.Y(n_43)
);

NOR2xp67_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_6),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AOI322xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_7),
.A3(n_20),
.B1(n_41),
.B2(n_42),
.C1(n_45),
.C2(n_44),
.Y(n_47)
);


endmodule