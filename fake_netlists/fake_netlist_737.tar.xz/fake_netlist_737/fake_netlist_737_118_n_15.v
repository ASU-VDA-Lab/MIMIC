module fake_netlist_737_118_n_15 (n_1, n_2, n_3, n_4, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_5;
wire n_7;
wire n_13;
wire n_6;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_2),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_8),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_9),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B(n_5),
.C(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_5),
.B1(n_7),
.B2(n_0),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_1),
.B1(n_4),
.B2(n_10),
.Y(n_15)
);


endmodule