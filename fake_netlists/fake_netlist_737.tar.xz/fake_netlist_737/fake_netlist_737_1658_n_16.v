module fake_netlist_737_1658_n_16 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_16);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;

output n_16;

wire n_14;
wire n_9;
wire n_13;
wire n_11;
wire n_12;
wire n_15;
wire n_10;
wire n_8;

NOR2x1p5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);

BUFx3_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B(n_3),
.C(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_6),
.B(n_4),
.Y(n_16)
);


endmodule