module fake_netlist_737_186_n_75 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_75);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_75;

wire n_61;
wire n_46;
wire n_44;
wire n_66;
wire n_64;
wire n_62;
wire n_71;
wire n_74;
wire n_72;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_68;
wire n_73;
wire n_49;
wire n_28;
wire n_65;
wire n_42;
wire n_37;
wire n_59;
wire n_24;
wire n_27;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_57;
wire n_35;
wire n_70;
wire n_63;
wire n_25;
wire n_69;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_67;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

INVx2_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_10),
.B(n_6),
.Y(n_26)
);

INVx6_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

OA21x2_ASAP7_75t_L g28 ( 
.A1(n_8),
.A2(n_18),
.B(n_13),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_2),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_11),
.Y(n_30)
);

NOR2x1_ASAP7_75t_L g31 ( 
.A(n_1),
.B(n_21),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_0),
.B(n_11),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_4),
.B(n_17),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_9),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_17),
.Y(n_35)
);

NAND2xp33_ASAP7_75t_L g36 ( 
.A(n_14),
.B(n_15),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_7),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_25),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_25),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_30),
.B(n_7),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_SL g41 ( 
.A(n_24),
.B(n_13),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_24),
.B(n_14),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_26),
.B(n_29),
.Y(n_43)
);

NAND2xp33_ASAP7_75t_L g44 ( 
.A(n_37),
.B(n_29),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_34),
.B(n_32),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_L g46 ( 
.A1(n_40),
.A2(n_34),
.B(n_32),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_40),
.B1(n_33),
.B2(n_32),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

OR2x6_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_40),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_40),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_38),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_48),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);

INVxp33_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

AOI21xp5_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_46),
.B(n_45),
.Y(n_57)
);

AOI211xp5_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_36),
.B(n_39),
.C(n_38),
.Y(n_58)
);

OAI211xp5_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_39),
.B(n_31),
.C(n_30),
.Y(n_59)
);

AOI22xp5_ASAP7_75t_L g60 ( 
.A1(n_56),
.A2(n_50),
.B1(n_36),
.B2(n_33),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_L g61 ( 
.A1(n_54),
.A2(n_50),
.B1(n_33),
.B2(n_28),
.Y(n_61)
);

NOR2x1_ASAP7_75t_L g62 ( 
.A(n_54),
.B(n_50),
.Y(n_62)
);

NOR2xp33_ASAP7_75t_L g63 ( 
.A(n_59),
.B(n_15),
.Y(n_63)
);

AOI22xp5_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_62),
.B1(n_58),
.B2(n_61),
.Y(n_64)
);

OAI221xp5_ASAP7_75t_L g65 ( 
.A1(n_58),
.A2(n_57),
.B1(n_27),
.B2(n_28),
.C(n_16),
.Y(n_65)
);

NOR3xp33_ASAP7_75t_SL g66 ( 
.A(n_59),
.B(n_27),
.C(n_28),
.Y(n_66)
);

AOI211xp5_ASAP7_75t_L g67 ( 
.A1(n_59),
.A2(n_27),
.B(n_18),
.C(n_16),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_63),
.Y(n_68)
);

NAND4xp25_ASAP7_75t_L g69 ( 
.A(n_67),
.B(n_21),
.C(n_20),
.D(n_19),
.Y(n_69)
);

NAND2xp5_ASAP7_75t_L g70 ( 
.A(n_64),
.B(n_19),
.Y(n_70)
);

NAND2x1p5_ASAP7_75t_L g71 ( 
.A(n_66),
.B(n_20),
.Y(n_71)
);

OAI22xp5_ASAP7_75t_L g72 ( 
.A1(n_71),
.A2(n_65),
.B1(n_23),
.B2(n_22),
.Y(n_72)
);

INVxp67_ASAP7_75t_L g73 ( 
.A(n_70),
.Y(n_73)
);

OAI22xp5_ASAP7_75t_L g74 ( 
.A1(n_73),
.A2(n_71),
.B1(n_68),
.B2(n_69),
.Y(n_74)
);

OAI22xp5_ASAP7_75t_L g75 ( 
.A1(n_74),
.A2(n_72),
.B1(n_23),
.B2(n_3),
.Y(n_75)
);


endmodule