module fake_netlist_737_2294_n_47 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_47);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_47;

wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_37;
wire n_27;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g24 ( 
.A(n_3),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_13),
.B(n_22),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_16),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_9),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_0),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_18),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_19),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_SL g33 ( 
.A(n_24),
.B(n_19),
.C(n_1),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_28),
.B(n_2),
.Y(n_34)
);

CKINVDCx16_ASAP7_75t_R g35 ( 
.A(n_32),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

INVx4_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_34),
.B(n_29),
.Y(n_39)
);

AOI21xp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_27),
.B(n_26),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_30),
.Y(n_41)
);

AOI322xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_25),
.A3(n_7),
.B1(n_5),
.B2(n_4),
.C1(n_10),
.C2(n_8),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_41),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

AOI22x1_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_15),
.B1(n_14),
.B2(n_11),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AOI222xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_17),
.B1(n_20),
.B2(n_21),
.C1(n_23),
.C2(n_45),
.Y(n_47)
);


endmodule