module fake_netlist_863_3217_n_23 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_23);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_2),
.A2(n_1),
.B1(n_4),
.B2(n_7),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_0),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_5),
.Y(n_12)
);

NAND3x1_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_7),
.C(n_0),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_7),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_11),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_10),
.B1(n_13),
.B2(n_12),
.C(n_1),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_17),
.C(n_13),
.Y(n_19)
);

NOR3x1_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_3),
.C(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_6),
.B1(n_4),
.B2(n_3),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_6),
.B1(n_8),
.B2(n_22),
.Y(n_23)
);


endmodule