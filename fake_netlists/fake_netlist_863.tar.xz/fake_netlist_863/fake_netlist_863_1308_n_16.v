module fake_netlist_863_1308_n_16 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_16);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_15;
wire n_13;
wire n_14;
wire n_12;
wire n_10;
wire n_11;
wire n_9;
wire n_8;

AND2x2_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_7),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_7),
.Y(n_9)
);

AND2x6_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_6),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_0),
.Y(n_14)
);

NOR4xp25_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.C(n_5),
.D(n_1),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B1(n_6),
.B2(n_1),
.C1(n_5),
.C2(n_3),
.Y(n_16)
);


endmodule