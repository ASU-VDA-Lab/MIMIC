module fake_netlist_863_920_n_24 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_24);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_24;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;
wire n_11;

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_2),
.B(n_4),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_5),
.B(n_6),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_10),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_17),
.B(n_14),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_15),
.B1(n_12),
.B2(n_11),
.C(n_14),
.Y(n_20)
);

AOI211x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B(n_4),
.C(n_1),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_21),
.B(n_0),
.Y(n_22)
);

AOI22x1_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_8),
.B1(n_3),
.B2(n_1),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_5),
.B1(n_7),
.B2(n_22),
.Y(n_24)
);


endmodule