module fake_netlist_863_2557_n_3 (n_0, n_1, n_3);

input n_0;
input n_1;

output n_3;

wire n_2;

INVxp67_ASAP7_75t_SL g2 ( 
.A(n_1),
.Y(n_2)
);

NAND3xp33_ASAP7_75t_SL g3 ( 
.A(n_2),
.B(n_1),
.C(n_0),
.Y(n_3)
);


endmodule