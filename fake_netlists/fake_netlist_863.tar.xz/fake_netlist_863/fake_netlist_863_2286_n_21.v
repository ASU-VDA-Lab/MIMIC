module fake_netlist_863_2286_n_21 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_21);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_21;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

INVx1_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_4),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_6),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_10),
.A2(n_7),
.B(n_6),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.C(n_15),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_7),
.B1(n_15),
.B2(n_0),
.C(n_2),
.Y(n_19)
);

INVxp67_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

AO21x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_9),
.B(n_8),
.Y(n_21)
);


endmodule