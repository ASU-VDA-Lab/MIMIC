module fake_netlist_863_2101_n_18 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_18);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_18;

wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_16;
wire n_17;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

OR2x6_ASAP7_75t_SL g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B(n_12),
.Y(n_14)
);

NAND4xp25_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_6),
.C(n_5),
.D(n_2),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_6),
.B1(n_5),
.B2(n_3),
.Y(n_18)
);


endmodule