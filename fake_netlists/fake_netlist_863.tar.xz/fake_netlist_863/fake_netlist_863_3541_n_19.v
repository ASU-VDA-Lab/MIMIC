module fake_netlist_863_3541_n_19 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_19);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVxp67_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_1),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_6),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_7),
.B2(n_11),
.C(n_1),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

AOI211xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B(n_6),
.C(n_2),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_6),
.B1(n_4),
.B2(n_3),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_4),
.B1(n_5),
.B2(n_17),
.Y(n_19)
);


endmodule