module fake_netlist_863_3566_n_10 (n_4, n_2, n_3, n_0, n_1, n_10);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_10;

wire n_6;
wire n_7;
wire n_5;
wire n_9;
wire n_8;

AOI21xp5_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_4),
.B(n_1),
.Y(n_5)
);

AND2x4_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_1),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_0),
.Y(n_8)
);

OAI211xp5_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_7),
.B(n_5),
.C(n_6),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.Y(n_10)
);


endmodule