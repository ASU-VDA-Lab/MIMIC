module fake_netlist_863_2846_n_9 (n_4, n_2, n_3, n_0, n_1, n_9);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_9;

wire n_6;
wire n_7;
wire n_5;
wire n_8;

CKINVDCx6p67_ASAP7_75t_R g5 ( 
.A(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B(n_2),
.Y(n_6)
);

AOI21xp33_ASAP7_75t_L g7 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_4),
.B(n_0),
.Y(n_8)
);

OR4x1_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.C(n_7),
.D(n_5),
.Y(n_9)
);


endmodule