module fake_netlist_863_2718_n_25 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_25);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_25;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_9;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_1),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_3),
.B(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_0),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_9),
.B1(n_12),
.B2(n_2),
.C(n_3),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_14),
.B(n_9),
.C(n_12),
.Y(n_20)
);

XOR2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_4),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_5),
.C(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI322xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_5),
.A3(n_6),
.B1(n_7),
.B2(n_19),
.C1(n_20),
.C2(n_23),
.Y(n_25)
);


endmodule