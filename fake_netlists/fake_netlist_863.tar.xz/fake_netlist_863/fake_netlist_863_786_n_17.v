module fake_netlist_863_786_n_17 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_17);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_17;

wire n_15;
wire n_13;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;
wire n_9;

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_2),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_3),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B(n_11),
.C(n_6),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_0),
.B1(n_1),
.B2(n_5),
.C1(n_7),
.C2(n_12),
.Y(n_17)
);


endmodule