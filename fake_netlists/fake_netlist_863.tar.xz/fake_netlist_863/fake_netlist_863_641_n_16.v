module fake_netlist_863_641_n_16 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_16);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_15;
wire n_13;
wire n_14;
wire n_12;
wire n_10;
wire n_11;
wire n_9;
wire n_8;

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AO21x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_5),
.B(n_4),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_10),
.B2(n_9),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B1(n_5),
.B2(n_4),
.Y(n_13)
);

AOI322xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_5),
.A3(n_4),
.B1(n_6),
.B2(n_7),
.C1(n_0),
.C2(n_1),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_2),
.B1(n_3),
.B2(n_6),
.C1(n_8),
.C2(n_10),
.Y(n_16)
);


endmodule