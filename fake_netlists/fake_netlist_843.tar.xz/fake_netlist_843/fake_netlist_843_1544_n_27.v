module fake_netlist_843_1544_n_27 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_27);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

INVx1_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_0),
.B(n_3),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_7),
.B(n_13),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_5),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_16),
.Y(n_23)
);

OAI21xp33_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_21),
.B(n_18),
.Y(n_24)
);

AOI222xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_19),
.B1(n_17),
.B2(n_6),
.C1(n_2),
.C2(n_1),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_9),
.B(n_8),
.Y(n_26)
);

OAI21x1_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_12),
.B(n_10),
.Y(n_27)
);


endmodule