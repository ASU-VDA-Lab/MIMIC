module fake_netlist_843_1930_n_15 (n_2, n_0, n_3, n_1, n_15);

input n_2;
input n_0;
input n_3;
input n_1;

output n_15;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_2),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_2),
.Y(n_7)
);

AO22x2_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B1(n_2),
.B2(n_4),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI211xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B(n_10),
.C(n_8),
.Y(n_12)
);

OR2x6_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_8),
.B1(n_9),
.B2(n_10),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_1),
.B1(n_10),
.B2(n_14),
.Y(n_15)
);


endmodule