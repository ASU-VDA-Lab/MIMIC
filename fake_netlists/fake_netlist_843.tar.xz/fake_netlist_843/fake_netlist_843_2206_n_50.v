module fake_netlist_843_2206_n_50 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_50);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_50;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_47;
wire n_17;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_4),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_9),
.B(n_6),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_8),
.B(n_7),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_5),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_0),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_13),
.B(n_11),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_SL g28 ( 
.A(n_18),
.B(n_11),
.C(n_1),
.Y(n_28)
);

INVx3_ASAP7_75t_SL g29 ( 
.A(n_15),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_SL g30 ( 
.A(n_25),
.B(n_1),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_12),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_30),
.B(n_23),
.C(n_21),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_16),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_19),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_32),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_31),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_31),
.B1(n_24),
.B2(n_28),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_24),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_SL g43 ( 
.A(n_40),
.B(n_33),
.C(n_20),
.Y(n_43)
);

NOR3xp33_ASAP7_75t_SL g44 ( 
.A(n_41),
.B(n_14),
.C(n_13),
.Y(n_44)
);

NAND4xp25_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_34),
.C(n_17),
.D(n_16),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx3_ASAP7_75t_SL g47 ( 
.A(n_44),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_47),
.B1(n_46),
.B2(n_48),
.Y(n_50)
);


endmodule