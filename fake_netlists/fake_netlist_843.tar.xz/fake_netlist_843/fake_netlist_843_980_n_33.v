module fake_netlist_843_980_n_33 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_33);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_33;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_6),
.B(n_13),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_5),
.B(n_4),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_11),
.B(n_3),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_17),
.A2(n_2),
.B(n_0),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_SL g26 ( 
.A1(n_23),
.A2(n_22),
.B1(n_20),
.B2(n_18),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

NOR3xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_26),
.C(n_24),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_19),
.B1(n_15),
.B2(n_14),
.C1(n_20),
.C2(n_25),
.Y(n_30)
);

NAND2x1p5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_15),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_12),
.B1(n_8),
.B2(n_7),
.Y(n_33)
);


endmodule