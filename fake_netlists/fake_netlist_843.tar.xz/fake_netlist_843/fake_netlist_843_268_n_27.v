module fake_netlist_843_268_n_27 (n_4, n_2, n_5, n_3, n_0, n_1, n_27);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_1),
.B1(n_0),
.B2(n_5),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_5),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_1),
.C(n_0),
.Y(n_10)
);

AOI21xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_6),
.B(n_7),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_L g13 ( 
.A1(n_6),
.A2(n_4),
.B(n_3),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_6),
.Y(n_14)
);

AO21x2_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_7),
.B(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

AOI322xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_3),
.A3(n_6),
.B1(n_11),
.B2(n_15),
.C1(n_16),
.C2(n_17),
.Y(n_20)
);

AOI322xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_15),
.A3(n_16),
.B1(n_17),
.B2(n_19),
.C1(n_11),
.C2(n_14),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_16),
.B(n_15),
.Y(n_22)
);

AND3x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_19),
.C(n_17),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_15),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_15),
.B1(n_24),
.B2(n_23),
.Y(n_26)
);

OAI21xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_25),
.B(n_23),
.Y(n_27)
);


endmodule