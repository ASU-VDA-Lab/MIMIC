module fake_netlist_843_2007_n_23 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_23);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_7),
.Y(n_9)
);

BUFx10_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_6),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_10),
.B1(n_9),
.B2(n_3),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_15),
.B(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_19),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_2),
.B2(n_1),
.Y(n_23)
);


endmodule