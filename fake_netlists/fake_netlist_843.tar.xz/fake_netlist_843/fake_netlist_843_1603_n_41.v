module fake_netlist_843_1603_n_41 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_41);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_41;

wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;

INVx2_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_3),
.B(n_11),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_1),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

OAI21xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_20),
.B(n_19),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

O2A1O1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_25),
.B(n_24),
.C(n_21),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_28),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_24),
.Y(n_31)
);

NOR2xp67_ASAP7_75t_SL g32 ( 
.A(n_31),
.B(n_21),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_4),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_35),
.A2(n_22),
.B1(n_7),
.B2(n_6),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_22),
.B1(n_2),
.B2(n_0),
.Y(n_39)
);

CKINVDCx20_ASAP7_75t_R g40 ( 
.A(n_38),
.Y(n_40)
);

AOI322xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_39),
.A3(n_22),
.B1(n_12),
.B2(n_13),
.C1(n_8),
.C2(n_10),
.Y(n_41)
);


endmodule