module fake_netlist_843_1390_n_8 (n_2, n_0, n_1, n_8);

input n_2;
input n_0;
input n_1;

output n_8;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;

BUFx6f_ASAP7_75t_SL g3 ( 
.A(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

OAI211xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_SL g7 ( 
.A(n_6),
.Y(n_7)
);

OAI322xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_5),
.C1(n_4),
.C2(n_3),
.Y(n_8)
);


endmodule