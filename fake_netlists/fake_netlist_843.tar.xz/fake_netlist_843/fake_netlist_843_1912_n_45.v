module fake_netlist_843_1912_n_45 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_45);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_45;

wire n_25;
wire n_36;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_19),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_13),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_16),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_1),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_4),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_6),
.B(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_22),
.B(n_19),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_3),
.B(n_2),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_7),
.B(n_5),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_23),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_SL g34 ( 
.A1(n_31),
.A2(n_24),
.B(n_28),
.C(n_25),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_26),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_8),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_32),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

NAND4xp75_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_11),
.C(n_10),
.D(n_9),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_12),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

OAI21xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_17),
.B(n_14),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_43),
.B1(n_21),
.B2(n_18),
.Y(n_45)
);


endmodule