module fake_netlist_843_402_n_29 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_29);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_29;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

BUFx10_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_2),
.B(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_15),
.B(n_16),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_4),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_13),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_17),
.B(n_18),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_14),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_19),
.C(n_23),
.Y(n_25)
);

OAI221xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_15),
.B1(n_6),
.B2(n_4),
.C(n_5),
.Y(n_26)
);

NAND3xp33_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_5),
.C(n_1),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_29)
);


endmodule