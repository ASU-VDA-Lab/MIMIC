module fake_netlist_843_1694_n_70 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_70);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_70;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_23;
wire n_31;
wire n_32;
wire n_58;
wire n_68;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_69;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_21;
wire n_52;
wire n_38;
wire n_35;
wire n_61;
wire n_27;
wire n_67;
wire n_45;
wire n_46;
wire n_51;

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_8),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_5),
.B(n_15),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_2),
.B(n_3),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_6),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_7),
.A2(n_17),
.B(n_9),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_20),
.B(n_13),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_20),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_21),
.B(n_16),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_24),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_21),
.Y(n_35)
);

BUFx3_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_21),
.B(n_19),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

OAI211xp5_ASAP7_75t_SL g39 ( 
.A1(n_34),
.A2(n_30),
.B(n_31),
.C(n_22),
.Y(n_39)
);

CKINVDCx11_ASAP7_75t_R g40 ( 
.A(n_33),
.Y(n_40)
);

OAI21x1_ASAP7_75t_L g41 ( 
.A1(n_32),
.A2(n_27),
.B(n_30),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_36),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_34),
.B1(n_37),
.B2(n_25),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_38),
.Y(n_44)
);

OR2x6_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_25),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_42),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_43),
.Y(n_51)
);

AND2x4_ASAP7_75t_SL g52 ( 
.A(n_46),
.B(n_31),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_38),
.Y(n_53)
);

AOI21xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_49),
.B(n_41),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

XNOR2xp5_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_50),
.Y(n_56)
);

AOI211xp5_ASAP7_75t_L g57 ( 
.A1(n_51),
.A2(n_29),
.B(n_26),
.C(n_23),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_50),
.B(n_22),
.Y(n_58)
);

XNOR2xp5_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_58),
.Y(n_59)
);

INVxp33_ASAP7_75t_L g60 ( 
.A(n_55),
.Y(n_60)
);

NOR3xp33_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_35),
.C(n_19),
.Y(n_61)
);

AOI22xp5_ASAP7_75t_L g62 ( 
.A1(n_54),
.A2(n_29),
.B1(n_26),
.B2(n_23),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_55),
.Y(n_63)
);

OR4x1_ASAP7_75t_L g64 ( 
.A(n_63),
.B(n_12),
.C(n_10),
.D(n_0),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_60),
.Y(n_65)
);

NOR3x2_ASAP7_75t_L g66 ( 
.A(n_59),
.B(n_26),
.C(n_23),
.Y(n_66)
);

INVx2_ASAP7_75t_L g67 ( 
.A(n_62),
.Y(n_67)
);

OAI22xp5_ASAP7_75t_L g68 ( 
.A1(n_66),
.A2(n_61),
.B1(n_29),
.B2(n_14),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_65),
.Y(n_69)
);

OAI22xp33_ASAP7_75t_L g70 ( 
.A1(n_68),
.A2(n_64),
.B1(n_67),
.B2(n_69),
.Y(n_70)
);


endmodule