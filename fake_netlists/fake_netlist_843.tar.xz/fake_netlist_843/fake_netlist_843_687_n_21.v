module fake_netlist_843_687_n_21 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_21);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_21;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

AND2x2_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_4),
.Y(n_12)
);

A2O1A1Ixp33_ASAP7_75t_SL g13 ( 
.A1(n_10),
.A2(n_9),
.B(n_12),
.C(n_11),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_SL g14 ( 
.A(n_12),
.B(n_1),
.C(n_0),
.Y(n_14)
);

INVx1_ASAP7_75t_SL g15 ( 
.A(n_13),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_9),
.B(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_10),
.B2(n_9),
.C(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

OAI22x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_20)
);

OAI321xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_6),
.A3(n_7),
.B1(n_8),
.B2(n_19),
.C(n_18),
.Y(n_21)
);


endmodule