module fake_netlist_843_1630_n_48 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_48);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_48;

wire n_25;
wire n_36;
wire n_47;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

AND2x2_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_24),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_8),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_24),
.B(n_2),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_1),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_10),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_14),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_16),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_28),
.A2(n_3),
.B(n_0),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

OR2x6_ASAP7_75t_L g35 ( 
.A(n_25),
.B(n_27),
.Y(n_35)
);

CKINVDCx16_ASAP7_75t_R g36 ( 
.A(n_35),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_26),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_29),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_31),
.Y(n_39)
);

OAI332xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_30),
.A3(n_33),
.B1(n_6),
.B2(n_4),
.B3(n_11),
.C1(n_7),
.C2(n_5),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_32),
.Y(n_41)
);

OAI21xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_13),
.B(n_12),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_18),
.B1(n_17),
.B2(n_15),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_19),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_21),
.Y(n_45)
);

AND2x2_ASAP7_75t_SL g46 ( 
.A(n_44),
.B(n_22),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_SL g48 ( 
.A1(n_47),
.A2(n_45),
.B1(n_46),
.B2(n_23),
.Y(n_48)
);


endmodule