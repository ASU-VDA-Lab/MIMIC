module fake_netlist_843_458_n_12 (n_4, n_2, n_5, n_3, n_0, n_1, n_12);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_7;
wire n_9;
wire n_11;
wire n_8;

NOR3xp33_ASAP7_75t_SL g6 ( 
.A(n_5),
.B(n_2),
.C(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVxp67_ASAP7_75t_SL g9 ( 
.A(n_8),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_0),
.Y(n_10)
);

OAI221xp5_ASAP7_75t_SL g11 ( 
.A1(n_9),
.A2(n_4),
.B1(n_7),
.B2(n_10),
.C(n_8),
.Y(n_11)
);

CKINVDCx11_ASAP7_75t_R g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule