module fake_netlist_843_2246_n_54 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_54);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_54;

wire n_49;
wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_44;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_31;
wire n_32;
wire n_26;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx1_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_6),
.B(n_12),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_7),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_5),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_14),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_3),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_20),
.A2(n_1),
.B1(n_18),
.B2(n_10),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_21),
.B(n_13),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_16),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_25),
.B(n_16),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_30),
.B(n_24),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_4),
.B1(n_2),
.B2(n_0),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_29),
.B(n_8),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_31),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_39),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_38),
.B1(n_36),
.B2(n_33),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_40),
.Y(n_47)
);

OR2x6_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_27),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_28),
.Y(n_49)
);

AOI211xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_28),
.B(n_27),
.C(n_26),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_38),
.B1(n_28),
.B2(n_32),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_34),
.Y(n_53)
);

AOI322xp5_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_9),
.A3(n_11),
.B1(n_17),
.B2(n_19),
.C1(n_23),
.C2(n_53),
.Y(n_54)
);


endmodule