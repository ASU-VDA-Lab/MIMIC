module fake_netlist_817_354_n_46 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_46);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_46;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;

INVx1_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_6),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_5),
.B(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_4),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_16),
.B(n_0),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_13),
.B(n_0),
.Y(n_25)
);

OAI221xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_13),
.B1(n_18),
.B2(n_15),
.C(n_14),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_L g27 ( 
.A1(n_21),
.A2(n_18),
.B1(n_14),
.B2(n_19),
.C(n_16),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_16),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_22),
.B(n_23),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

NAND2xp33_ASAP7_75t_SL g32 ( 
.A(n_31),
.B(n_20),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_30),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_24),
.Y(n_34)
);

INVxp67_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_24),
.Y(n_37)
);

NAND2xp33_ASAP7_75t_R g38 ( 
.A(n_37),
.B(n_17),
.Y(n_38)
);

NAND5xp2_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_19),
.C(n_17),
.D(n_1),
.E(n_3),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_3),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_5),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_38),
.Y(n_43)
);

OAI21xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_38),
.B(n_6),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

AOI322xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_7),
.A3(n_8),
.B1(n_11),
.B2(n_12),
.C1(n_43),
.C2(n_44),
.Y(n_46)
);


endmodule