module fake_netlist_817_564_n_19 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_19);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

NAND2xp33_ASAP7_75t_R g8 ( 
.A(n_1),
.B(n_4),
.Y(n_8)
);

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_1),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_2),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_0),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_19)
);


endmodule