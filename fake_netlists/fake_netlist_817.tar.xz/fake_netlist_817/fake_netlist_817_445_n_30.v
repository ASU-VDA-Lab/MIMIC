module fake_netlist_817_445_n_30 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_30);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_13),
.B(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_11),
.Y(n_16)
);

AO21x1_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AND4x1_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_14),
.C(n_10),
.D(n_12),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_19),
.Y(n_23)
);

A2O1A1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_20),
.B(n_21),
.C(n_14),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_21),
.B1(n_17),
.B2(n_0),
.C(n_2),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_24),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_26),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_8),
.B1(n_25),
.B2(n_29),
.C1(n_26),
.C2(n_20),
.Y(n_30)
);


endmodule