module fake_netlist_817_2882_n_8 (n_2, n_0, n_1, n_8);

input n_2;
input n_0;
input n_1;

output n_8;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;

NOR3xp33_ASAP7_75t_SL g3 ( 
.A(n_2),
.B(n_0),
.C(n_1),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

O2A1O1Ixp33_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_6)
);

OAI22x1_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B1(n_5),
.B2(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);


endmodule