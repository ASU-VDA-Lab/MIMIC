module fake_netlist_817_3670_n_26 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_26);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_18;
wire n_21;
wire n_16;

AOI22xp33_ASAP7_75t_SL g13 ( 
.A1(n_4),
.A2(n_8),
.B1(n_6),
.B2(n_2),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_10),
.B1(n_5),
.B2(n_6),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_5),
.B(n_12),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_4),
.A2(n_0),
.B1(n_7),
.B2(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_11),
.B(n_1),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_18),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_17),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

AOI211xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_14),
.B(n_16),
.C(n_17),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AO21x2_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_13),
.B(n_22),
.Y(n_26)
);


endmodule