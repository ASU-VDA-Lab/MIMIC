module fake_netlist_817_4586_n_45 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_45);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_45;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_3),
.B(n_9),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_1),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_4),
.B(n_11),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_5),
.B(n_6),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_1),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_17),
.A2(n_2),
.B(n_0),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_22),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_15),
.A2(n_4),
.B(n_0),
.Y(n_28)
);

AOI22x1_ASAP7_75t_L g29 ( 
.A1(n_20),
.A2(n_7),
.B1(n_13),
.B2(n_18),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

CKINVDCx11_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_R g34 ( 
.A(n_25),
.B(n_26),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_SL g35 ( 
.A(n_34),
.B(n_28),
.C(n_23),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_27),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_36),
.Y(n_37)
);

AOI32xp33_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_16),
.A3(n_25),
.B1(n_31),
.B2(n_33),
.Y(n_38)
);

OAI21xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_35),
.B(n_30),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_30),
.B1(n_25),
.B2(n_31),
.Y(n_40)
);

BUFx8_ASAP7_75t_SL g41 ( 
.A(n_40),
.Y(n_41)
);

XNOR2x1_ASAP7_75t_SL g42 ( 
.A(n_39),
.B(n_29),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_41),
.B1(n_39),
.B2(n_43),
.Y(n_45)
);


endmodule