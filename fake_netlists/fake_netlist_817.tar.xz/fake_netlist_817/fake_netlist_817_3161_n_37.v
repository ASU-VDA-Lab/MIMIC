module fake_netlist_817_3161_n_37 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_37);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_37;

wire n_25;
wire n_20;
wire n_36;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_27;

INVx1_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_2),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_14),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_0),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_1),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_8),
.B(n_3),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_19),
.Y(n_28)
);

OAI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.B1(n_26),
.B2(n_20),
.C(n_19),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_21),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_22),
.B1(n_18),
.B2(n_6),
.C1(n_5),
.C2(n_4),
.Y(n_31)
);

AOI221xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_24),
.B1(n_7),
.B2(n_9),
.C(n_10),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_31),
.Y(n_33)
);

BUFx10_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_33),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_7),
.B1(n_13),
.B2(n_11),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_SL g37 ( 
.A1(n_35),
.A2(n_15),
.B1(n_34),
.B2(n_36),
.Y(n_37)
);


endmodule