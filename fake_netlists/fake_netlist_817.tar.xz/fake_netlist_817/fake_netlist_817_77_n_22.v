module fake_netlist_817_77_n_22 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_22);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

AND2x2_ASAP7_75t_SL g13 ( 
.A(n_0),
.B(n_4),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_3),
.B(n_2),
.Y(n_14)
);

AO31x2_ASAP7_75t_L g15 ( 
.A1(n_10),
.A2(n_6),
.A3(n_5),
.B(n_1),
.Y(n_15)
);

NOR2x1_ASAP7_75t_SL g16 ( 
.A(n_10),
.B(n_1),
.Y(n_16)
);

AND2x4_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_10),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_12),
.B(n_9),
.C(n_14),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_13),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_13),
.B(n_15),
.Y(n_22)
);


endmodule