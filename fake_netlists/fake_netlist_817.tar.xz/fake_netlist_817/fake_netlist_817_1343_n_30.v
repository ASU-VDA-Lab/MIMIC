module fake_netlist_817_1343_n_30 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_30);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_16)
);

OAI22xp33_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_17)
);

CKINVDCx8_ASAP7_75t_R g18 ( 
.A(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_17),
.Y(n_21)
);

AND2x4_ASAP7_75t_SL g22 ( 
.A(n_19),
.B(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI21xp33_ASAP7_75t_SL g24 ( 
.A1(n_21),
.A2(n_20),
.B(n_15),
.Y(n_24)
);

NAND4xp25_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_23),
.C(n_20),
.D(n_0),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_25),
.B(n_5),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_24),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_28),
.B1(n_9),
.B2(n_8),
.Y(n_30)
);


endmodule