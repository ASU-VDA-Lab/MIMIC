module fake_netlist_659_3092_n_17 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_17);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_17;

wire n_14;
wire n_10;
wire n_11;
wire n_9;
wire n_15;
wire n_13;
wire n_8;
wire n_16;
wire n_12;

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_6),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_SL g12 ( 
.A(n_10),
.Y(n_12)
);

OAI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B1(n_10),
.B2(n_8),
.C(n_11),
.Y(n_13)
);

OAI32xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_1),
.A3(n_0),
.B1(n_4),
.B2(n_5),
.Y(n_14)
);

NAND5xp2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_4),
.C(n_1),
.D(n_5),
.E(n_6),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_3),
.B(n_7),
.Y(n_17)
);


endmodule