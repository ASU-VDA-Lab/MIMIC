module fake_netlist_659_1866_n_17 (n_3, n_1, n_2, n_0, n_17);

input n_3;
input n_1;
input n_2;
input n_0;

output n_17;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_16;
wire n_8;
wire n_15;
wire n_6;

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx4_ASAP7_75t_SL g5 ( 
.A(n_3),
.Y(n_5)
);

NAND2x1p5_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AOI222xp33_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_3),
.C2(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AND2x4_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AND4x1_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_3),
.C(n_2),
.D(n_1),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_SL g14 ( 
.A1(n_11),
.A2(n_10),
.B(n_1),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.C(n_1),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_13),
.B(n_16),
.Y(n_17)
);


endmodule