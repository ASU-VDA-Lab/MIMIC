module fake_netlist_659_3657_n_42 (n_9, n_4, n_7, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_42);

input n_9;
input n_4;
input n_7;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_42;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_39;
wire n_17;
wire n_14;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

INVx3_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_6),
.A2(n_13),
.B(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_4),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_SL g20 ( 
.A(n_7),
.B(n_4),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_14),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_7),
.B1(n_5),
.B2(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

OR2x6_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_2),
.Y(n_25)
);

AOI21xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_22),
.B(n_24),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_14),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_25),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_27),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_28),
.B(n_26),
.Y(n_30)
);

OAI31xp33_ASAP7_75t_SL g31 ( 
.A1(n_28),
.A2(n_18),
.A3(n_15),
.B(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OAI22xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_29),
.B1(n_28),
.B2(n_20),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_29),
.B1(n_23),
.B2(n_16),
.C(n_19),
.Y(n_34)
);

AND2x6_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_21),
.Y(n_35)
);

NAND2xp33_ASAP7_75t_R g36 ( 
.A(n_32),
.B(n_3),
.Y(n_36)
);

INVxp67_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

AOI211x1_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_23),
.B(n_14),
.C(n_21),
.Y(n_38)
);

CKINVDCx20_ASAP7_75t_R g39 ( 
.A(n_35),
.Y(n_39)
);

OR3x1_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_35),
.C(n_8),
.Y(n_40)
);

OAI221xp5_ASAP7_75t_SL g41 ( 
.A1(n_37),
.A2(n_17),
.B1(n_12),
.B2(n_10),
.C(n_11),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_17),
.B1(n_38),
.B2(n_41),
.Y(n_42)
);


endmodule