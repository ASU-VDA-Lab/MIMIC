module fake_netlist_659_1050_n_39 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_39);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_39;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_17),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_1),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_19),
.B(n_5),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_5),
.Y(n_27)
);

OAI222xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_24),
.B1(n_22),
.B2(n_18),
.C1(n_20),
.C2(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_18),
.Y(n_29)
);

NAND3xp33_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_26),
.C(n_21),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B1(n_16),
.B2(n_15),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_15),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_31),
.B(n_16),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

NAND4xp75_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_17),
.C(n_4),
.D(n_0),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_6),
.Y(n_36)
);

NOR3xp33_ASAP7_75t_SL g37 ( 
.A(n_35),
.B(n_8),
.C(n_7),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_36),
.Y(n_38)
);

AOI222xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_37),
.B1(n_35),
.B2(n_13),
.C1(n_12),
.C2(n_10),
.Y(n_39)
);


endmodule