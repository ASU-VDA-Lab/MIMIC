module fake_netlist_659_3152_n_40 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_40);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_40;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

BUFx10_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_3),
.B(n_17),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_15),
.B(n_9),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_4),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_7),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_1),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_20),
.B(n_1),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_21),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

AND2x2_ASAP7_75t_SL g31 ( 
.A(n_29),
.B(n_24),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_28),
.Y(n_33)
);

OAI21xp33_ASAP7_75t_SL g34 ( 
.A1(n_32),
.A2(n_31),
.B(n_21),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_31),
.B1(n_25),
.B2(n_19),
.Y(n_35)
);

NOR2x1_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_20),
.Y(n_36)
);

AOI221x1_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_23),
.B1(n_31),
.B2(n_20),
.C(n_16),
.Y(n_37)
);

OAI311xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_36),
.A3(n_18),
.B1(n_26),
.C1(n_2),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_11),
.B1(n_10),
.B2(n_5),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_40)
);


endmodule