module fake_netlist_659_2385_n_13 (n_3, n_1, n_2, n_0, n_13);

input n_3;
input n_1;
input n_2;
input n_0;

output n_13;

wire n_9;
wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;

NOR2xp33_ASAP7_75t_R g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVxp67_ASAP7_75t_SL g6 ( 
.A(n_5),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_SL g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_SL g10 ( 
.A(n_9),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_10),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_4),
.Y(n_12)
);

OAI31xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_0),
.A3(n_1),
.B(n_10),
.Y(n_13)
);


endmodule