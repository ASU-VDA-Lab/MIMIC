module fake_netlist_659_2650_n_37 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_37);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_37;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_4),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_SL g16 ( 
.A1(n_7),
.A2(n_11),
.B1(n_4),
.B2(n_12),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

INVxp67_ASAP7_75t_SL g21 ( 
.A(n_2),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_19),
.B(n_3),
.C(n_0),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_17),
.A2(n_22),
.B(n_21),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_18),
.B(n_20),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_19),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_18),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_23),
.B1(n_16),
.B2(n_15),
.Y(n_31)
);

NAND4xp25_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_22),
.C(n_3),
.D(n_0),
.Y(n_32)
);

NOR2xp67_ASAP7_75t_SL g33 ( 
.A(n_30),
.B(n_13),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_6),
.B2(n_5),
.Y(n_37)
);


endmodule