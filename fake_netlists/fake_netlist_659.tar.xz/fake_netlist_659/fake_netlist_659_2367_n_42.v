module fake_netlist_659_2367_n_42 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_42);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_42;

wire n_36;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

INVx4_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_9),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_R g23 ( 
.A(n_3),
.B(n_8),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_11),
.B(n_12),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_22),
.A2(n_1),
.B(n_0),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_31),
.B(n_23),
.C(n_24),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_SL g33 ( 
.A(n_30),
.B(n_19),
.C(n_21),
.Y(n_33)
);

AOI221x1_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_29),
.B1(n_26),
.B2(n_28),
.C(n_2),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_26),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_34),
.B1(n_6),
.B2(n_4),
.C(n_5),
.Y(n_37)
);

AOI211xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_15),
.B(n_10),
.C(n_7),
.Y(n_38)
);

INVx5_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_37),
.Y(n_40)
);

CKINVDCx20_ASAP7_75t_R g41 ( 
.A(n_39),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_41),
.A2(n_40),
.B1(n_20),
.B2(n_18),
.Y(n_42)
);


endmodule