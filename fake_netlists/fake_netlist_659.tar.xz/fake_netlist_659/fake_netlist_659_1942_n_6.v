module fake_netlist_659_1942_n_6 (n_1, n_0, n_6);

input n_1;
input n_0;

output n_6;

wire n_4;
wire n_2;
wire n_5;
wire n_3;

NAND2xp5_ASAP7_75t_SL g2 ( 
.A(n_0),
.B(n_1),
.Y(n_2)
);

BUFx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

O2A1O1Ixp33_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_0),
.B(n_1),
.C(n_2),
.Y(n_4)
);

NAND3xp33_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_1),
.C(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);


endmodule