module fake_netlist_659_1872_n_54 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_54);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_54;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_24),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_SL g27 ( 
.A(n_15),
.B(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_17),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_2),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_9),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_4),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_11),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_17),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_25),
.B1(n_24),
.B2(n_16),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

BUFx4f_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_25),
.B(n_16),
.C(n_0),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_36),
.B1(n_26),
.B2(n_30),
.C(n_27),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_27),
.B1(n_39),
.B2(n_38),
.C(n_28),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_41),
.Y(n_45)
);

INVx2_ASAP7_75t_SL g46 ( 
.A(n_45),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_31),
.Y(n_47)
);

OAI322xp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_45),
.A3(n_33),
.B1(n_29),
.B2(n_32),
.C1(n_1),
.C2(n_3),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_5),
.Y(n_50)
);

AOI221xp5_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_10),
.B1(n_7),
.B2(n_12),
.C(n_13),
.Y(n_51)
);

AOI221xp5_ASAP7_75t_SL g52 ( 
.A1(n_50),
.A2(n_18),
.B1(n_14),
.B2(n_19),
.C(n_20),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_SL g54 ( 
.A1(n_53),
.A2(n_22),
.B1(n_23),
.B2(n_52),
.Y(n_54)
);


endmodule