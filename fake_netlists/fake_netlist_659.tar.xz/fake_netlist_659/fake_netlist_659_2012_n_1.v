module fake_netlist_659_2012_n_1 (n_0, n_1);

input n_0;

output n_1;


CKINVDCx5p33_ASAP7_75t_R g1 ( 
.A(n_0),
.Y(n_1)
);


endmodule