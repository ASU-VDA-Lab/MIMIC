module fake_netlist_659_2142_n_62 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_27, n_2, n_26, n_9, n_13, n_8, n_6, n_62);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_27;
input n_2;
input n_26;
input n_9;
input n_13;
input n_8;
input n_6;

output n_62;

wire n_36;
wire n_59;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_40;
wire n_54;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_48;
wire n_60;
wire n_39;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;
wire n_61;

INVx1_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_12),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_17),
.B(n_27),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_10),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_1),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_14),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_19),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_21),
.B(n_24),
.Y(n_39)
);

AO22x1_ASAP7_75t_L g40 ( 
.A1(n_34),
.A2(n_26),
.B1(n_25),
.B2(n_0),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_R g41 ( 
.A(n_38),
.B(n_2),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_34),
.Y(n_42)
);

BUFx6f_ASAP7_75t_L g43 ( 
.A(n_33),
.Y(n_43)
);

BUFx6f_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_30),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

OA21x2_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_29),
.B(n_28),
.Y(n_47)
);

OAI211xp5_ASAP7_75t_SL g48 ( 
.A1(n_45),
.A2(n_36),
.B(n_37),
.C(n_31),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_32),
.B1(n_43),
.B2(n_41),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_32),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_50),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_40),
.Y(n_52)
);

AOI221x1_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_44),
.B1(n_39),
.B2(n_35),
.C(n_3),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

NOR3xp33_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_44),
.C(n_5),
.Y(n_55)
);

AOI221xp5_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_44),
.B1(n_9),
.B2(n_7),
.C(n_8),
.Y(n_56)
);

HB1xp67_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

AOI22xp33_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_44),
.B1(n_53),
.B2(n_11),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

OAI22xp33_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_16),
.B1(n_15),
.B2(n_13),
.Y(n_60)
);

INVx1_ASAP7_75t_SL g61 ( 
.A(n_59),
.Y(n_61)
);

AOI322xp5_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_18),
.A3(n_20),
.B1(n_22),
.B2(n_23),
.C1(n_58),
.C2(n_60),
.Y(n_62)
);


endmodule