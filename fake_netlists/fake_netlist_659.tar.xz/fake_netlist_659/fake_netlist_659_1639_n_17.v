module fake_netlist_659_1639_n_17 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_17);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_17;

wire n_14;
wire n_10;
wire n_11;
wire n_9;
wire n_15;
wire n_13;
wire n_8;
wire n_16;
wire n_12;

AND2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_2),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

OAI21x1_ASAP7_75t_SL g12 ( 
.A1(n_10),
.A2(n_5),
.B(n_4),
.Y(n_12)
);

BUFx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI321xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.A3(n_10),
.B1(n_11),
.B2(n_8),
.C(n_5),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.C(n_1),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

CKINVDCx14_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);


endmodule