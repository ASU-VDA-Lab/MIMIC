module fake_netlist_659_3900_n_15 (n_4, n_1, n_2, n_0, n_3, n_15);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_15;

wire n_9;
wire n_7;
wire n_14;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;

AND2x4_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

AOI21xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_5),
.B1(n_6),
.B2(n_0),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_2),
.B1(n_4),
.B2(n_12),
.C(n_7),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);


endmodule