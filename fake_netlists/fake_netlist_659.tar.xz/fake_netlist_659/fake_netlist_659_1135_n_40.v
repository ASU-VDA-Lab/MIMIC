module fake_netlist_659_1135_n_40 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_40);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_40;

wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_15),
.B(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_4),
.B(n_8),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_14),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_19),
.B(n_17),
.C(n_16),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_SL g29 ( 
.A(n_27),
.B(n_22),
.Y(n_29)
);

CKINVDCx8_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_28),
.B1(n_26),
.B2(n_25),
.C1(n_23),
.C2(n_21),
.Y(n_31)
);

BUFx3_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_30),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_22),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI322xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_18),
.A3(n_24),
.B1(n_3),
.B2(n_5),
.C1(n_0),
.C2(n_2),
.Y(n_36)
);

NAND5xp2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_18),
.C(n_9),
.D(n_6),
.E(n_7),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_35),
.Y(n_38)
);

NOR2x1_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_10),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.B1(n_37),
.B2(n_11),
.Y(n_40)
);


endmodule