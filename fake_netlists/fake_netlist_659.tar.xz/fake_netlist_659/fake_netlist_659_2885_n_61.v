module fake_netlist_659_2885_n_61 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_61);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_61;

wire n_36;
wire n_59;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_40;
wire n_54;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_48;
wire n_60;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_6),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_23),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_10),
.B(n_14),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_0),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_19),
.A2(n_17),
.B1(n_2),
.B2(n_25),
.Y(n_35)
);

INVxp67_ASAP7_75t_SL g36 ( 
.A(n_32),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_28),
.B(n_17),
.Y(n_37)
);

INVxp67_ASAP7_75t_SL g38 ( 
.A(n_28),
.Y(n_38)
);

AND2x2_ASAP7_75t_SL g39 ( 
.A(n_33),
.B(n_1),
.Y(n_39)
);

AO31x2_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_29),
.A3(n_30),
.B(n_27),
.Y(n_40)
);

O2A1O1Ixp33_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_29),
.B(n_34),
.C(n_33),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_39),
.Y(n_42)
);

OAI21xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_38),
.B(n_39),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_40),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_40),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_44),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_35),
.Y(n_49)
);

O2A1O1Ixp33_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_24),
.B(n_23),
.C(n_21),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

NAND3xp33_ASAP7_75t_SL g52 ( 
.A(n_49),
.B(n_24),
.C(n_21),
.Y(n_52)
);

AOI221xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_26),
.B1(n_31),
.B2(n_25),
.C(n_3),
.Y(n_53)
);

A2O1A1Ixp33_ASAP7_75t_SL g54 ( 
.A1(n_50),
.A2(n_31),
.B(n_26),
.C(n_4),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_26),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_55),
.Y(n_56)
);

NOR2x1_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_31),
.Y(n_57)
);

OAI22xp5_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_53),
.B1(n_7),
.B2(n_5),
.Y(n_58)
);

XNOR2xp5_ASAP7_75t_L g59 ( 
.A(n_57),
.B(n_8),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_L g60 ( 
.A1(n_59),
.A2(n_18),
.B1(n_15),
.B2(n_13),
.Y(n_60)
);

OA21x2_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_58),
.B(n_20),
.Y(n_61)
);


endmodule