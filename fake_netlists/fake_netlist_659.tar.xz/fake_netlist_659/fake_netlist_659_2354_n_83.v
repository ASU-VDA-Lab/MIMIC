module fake_netlist_659_2354_n_83 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_83);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_83;

wire n_62;
wire n_70;
wire n_58;
wire n_38;
wire n_57;
wire n_35;
wire n_45;
wire n_78;
wire n_66;
wire n_60;
wire n_39;
wire n_63;
wire n_31;
wire n_81;
wire n_37;
wire n_71;
wire n_40;
wire n_28;
wire n_49;
wire n_53;
wire n_77;
wire n_75;
wire n_48;
wire n_41;
wire n_65;
wire n_33;
wire n_43;
wire n_82;
wire n_61;
wire n_72;
wire n_51;
wire n_25;
wire n_54;
wire n_68;
wire n_27;
wire n_67;
wire n_29;
wire n_52;
wire n_50;
wire n_26;
wire n_76;
wire n_36;
wire n_59;
wire n_34;
wire n_64;
wire n_44;
wire n_79;
wire n_30;
wire n_73;
wire n_56;
wire n_69;
wire n_46;
wire n_42;
wire n_55;
wire n_74;
wire n_32;
wire n_47;
wire n_80;

AND2x2_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_6),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

INVx6_ASAP7_75t_L g29 ( 
.A(n_10),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_15),
.Y(n_31)
);

AOI22x1_ASAP7_75t_SL g32 ( 
.A1(n_17),
.A2(n_23),
.B1(n_2),
.B2(n_8),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_13),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_7),
.A2(n_20),
.B1(n_12),
.B2(n_11),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_4),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_3),
.B(n_18),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_21),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_9),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_SL g39 ( 
.A(n_37),
.B(n_18),
.C(n_16),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_26),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_29),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_28),
.B(n_37),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_29),
.Y(n_43)
);

INVx2_ASAP7_75t_SL g44 ( 
.A(n_29),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_26),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_30),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_27),
.Y(n_47)
);

AO21x2_ASAP7_75t_L g48 ( 
.A1(n_39),
.A2(n_25),
.B(n_35),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_30),
.B1(n_25),
.B2(n_36),
.Y(n_49)
);

OAI21x1_ASAP7_75t_L g50 ( 
.A1(n_41),
.A2(n_43),
.B(n_40),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

BUFx6f_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_48),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_47),
.Y(n_57)
);

NOR3xp33_ASAP7_75t_SL g58 ( 
.A(n_56),
.B(n_39),
.C(n_33),
.Y(n_58)
);

NAND2x1p5_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_34),
.Y(n_59)
);

OR2x2_ASAP7_75t_L g60 ( 
.A(n_54),
.B(n_49),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_60),
.Y(n_61)
);

AO21x1_ASAP7_75t_L g62 ( 
.A1(n_59),
.A2(n_54),
.B(n_41),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_57),
.Y(n_63)
);

OAI32xp33_ASAP7_75t_L g64 ( 
.A1(n_58),
.A2(n_43),
.A3(n_44),
.B1(n_38),
.B2(n_33),
.Y(n_64)
);

INVx5_ASAP7_75t_L g65 ( 
.A(n_58),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_63),
.B(n_48),
.Y(n_66)
);

HB1xp67_ASAP7_75t_L g67 ( 
.A(n_61),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_62),
.Y(n_68)
);

OA22x2_ASAP7_75t_L g69 ( 
.A1(n_65),
.A2(n_32),
.B1(n_48),
.B2(n_53),
.Y(n_69)
);

AOI322xp5_ASAP7_75t_L g70 ( 
.A1(n_65),
.A2(n_24),
.A3(n_21),
.B1(n_38),
.B2(n_31),
.C1(n_1),
.C2(n_5),
.Y(n_70)
);

OAI21xp5_ASAP7_75t_L g71 ( 
.A1(n_64),
.A2(n_53),
.B(n_31),
.Y(n_71)
);

NOR2x1p5_ASAP7_75t_L g72 ( 
.A(n_66),
.B(n_65),
.Y(n_72)
);

BUFx6f_ASAP7_75t_L g73 ( 
.A(n_68),
.Y(n_73)
);

INVx1_ASAP7_75t_SL g74 ( 
.A(n_67),
.Y(n_74)
);

NOR2x1_ASAP7_75t_L g75 ( 
.A(n_71),
.B(n_31),
.Y(n_75)
);

AOI221xp5_ASAP7_75t_L g76 ( 
.A1(n_69),
.A2(n_65),
.B1(n_31),
.B2(n_70),
.C(n_53),
.Y(n_76)
);

NAND4xp75_ASAP7_75t_L g77 ( 
.A(n_69),
.B(n_22),
.C(n_19),
.D(n_14),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_74),
.Y(n_78)
);

XNOR2x1_ASAP7_75t_L g79 ( 
.A(n_77),
.B(n_72),
.Y(n_79)
);

INVx2_ASAP7_75t_L g80 ( 
.A(n_73),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_76),
.Y(n_81)
);

OAI22xp5_ASAP7_75t_SL g82 ( 
.A1(n_78),
.A2(n_75),
.B1(n_79),
.B2(n_81),
.Y(n_82)
);

XNOR2xp5_ASAP7_75t_L g83 ( 
.A(n_82),
.B(n_80),
.Y(n_83)
);


endmodule