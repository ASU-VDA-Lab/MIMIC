module fake_netlist_659_446_n_76 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_76);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_76;

wire n_72;
wire n_36;
wire n_59;
wire n_62;
wire n_70;
wire n_34;
wire n_58;
wire n_38;
wire n_51;
wire n_44;
wire n_64;
wire n_25;
wire n_40;
wire n_57;
wire n_24;
wire n_35;
wire n_54;
wire n_28;
wire n_68;
wire n_30;
wire n_45;
wire n_49;
wire n_73;
wire n_53;
wire n_56;
wire n_66;
wire n_75;
wire n_23;
wire n_69;
wire n_48;
wire n_60;
wire n_39;
wire n_22;
wire n_27;
wire n_67;
wire n_46;
wire n_42;
wire n_63;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_65;
wire n_33;
wire n_32;
wire n_74;
wire n_37;
wire n_71;
wire n_43;
wire n_47;
wire n_61;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_20),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_11),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_1),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

OAI22x1_ASAP7_75t_L g27 ( 
.A1(n_2),
.A2(n_21),
.B1(n_12),
.B2(n_0),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_10),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_3),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_16),
.B(n_4),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_14),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_23),
.B(n_16),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_17),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_28),
.B(n_17),
.Y(n_37)
);

INVx5_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

INVx3_ASAP7_75t_L g39 ( 
.A(n_24),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_31),
.B(n_18),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_35),
.Y(n_41)
);

BUFx2_ASAP7_75t_R g42 ( 
.A(n_34),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_32),
.B(n_31),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_34),
.A2(n_25),
.B(n_22),
.Y(n_44)
);

OA21x2_ASAP7_75t_L g45 ( 
.A1(n_36),
.A2(n_30),
.B(n_22),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_40),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_41),
.B(n_39),
.Y(n_47)
);

BUFx3_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_41),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_46),
.Y(n_51)
);

INVx2_ASAP7_75t_SL g52 ( 
.A(n_48),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

OAI21xp33_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_46),
.B(n_42),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_SL g55 ( 
.A1(n_52),
.A2(n_45),
.B(n_27),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_45),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_45),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_52),
.B1(n_42),
.B2(n_35),
.Y(n_59)
);

INVx1_ASAP7_75t_SL g60 ( 
.A(n_56),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_54),
.Y(n_61)
);

INVx1_ASAP7_75t_SL g62 ( 
.A(n_58),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_55),
.Y(n_63)
);

AND2x4_ASAP7_75t_L g64 ( 
.A(n_63),
.B(n_28),
.Y(n_64)
);

NAND3xp33_ASAP7_75t_L g65 ( 
.A(n_61),
.B(n_38),
.C(n_37),
.Y(n_65)
);

NOR3xp33_ASAP7_75t_SL g66 ( 
.A(n_59),
.B(n_30),
.C(n_44),
.Y(n_66)
);

BUFx12f_ASAP7_75t_L g67 ( 
.A(n_63),
.Y(n_67)
);

AOI211xp5_ASAP7_75t_L g68 ( 
.A1(n_60),
.A2(n_29),
.B(n_19),
.C(n_38),
.Y(n_68)
);

OAI31xp33_ASAP7_75t_L g69 ( 
.A1(n_62),
.A2(n_19),
.A3(n_29),
.B(n_38),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_64),
.Y(n_70)
);

AOI21xp5_ASAP7_75t_L g71 ( 
.A1(n_64),
.A2(n_29),
.B(n_6),
.Y(n_71)
);

OAI22x1_ASAP7_75t_L g72 ( 
.A1(n_68),
.A2(n_13),
.B1(n_9),
.B2(n_7),
.Y(n_72)
);

OAI22xp5_ASAP7_75t_L g73 ( 
.A1(n_67),
.A2(n_15),
.B1(n_66),
.B2(n_65),
.Y(n_73)
);

XOR2xp5_ASAP7_75t_L g74 ( 
.A(n_73),
.B(n_69),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_70),
.Y(n_75)
);

AOI22xp33_ASAP7_75t_SL g76 ( 
.A1(n_75),
.A2(n_71),
.B1(n_72),
.B2(n_74),
.Y(n_76)
);


endmodule