module fake_netlist_659_538_n_55 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_55);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_55;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_40;
wire n_54;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_48;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_8),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_23),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_15),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_22),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_10),
.B(n_20),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_12),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_11),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_13),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_18),
.Y(n_35)
);

BUFx6f_ASAP7_75t_SL g36 ( 
.A(n_28),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_26),
.B(n_25),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

OAI21xp33_ASAP7_75t_L g39 ( 
.A1(n_32),
.A2(n_2),
.B(n_1),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_36),
.B1(n_38),
.B2(n_33),
.Y(n_40)
);

AO31x2_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_34),
.A3(n_31),
.B(n_28),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_35),
.B1(n_30),
.B2(n_29),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_25),
.Y(n_43)
);

AOI21xp33_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_4),
.B(n_3),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

XOR2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_5),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_41),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_R g49 ( 
.A(n_47),
.B(n_6),
.Y(n_49)
);

NAND4xp75_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_14),
.C(n_9),
.D(n_7),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

INVxp67_ASAP7_75t_SL g53 ( 
.A(n_52),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

AOI222xp33_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_16),
.B1(n_17),
.B2(n_21),
.C1(n_24),
.C2(n_53),
.Y(n_55)
);


endmodule