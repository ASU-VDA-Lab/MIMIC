module fake_netlist_659_4000_n_67 (n_18, n_19, n_1, n_0, n_5, n_10, n_25, n_24, n_28, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_27, n_2, n_26, n_9, n_13, n_8, n_6, n_67);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_25;
input n_24;
input n_28;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_27;
input n_2;
input n_26;
input n_9;
input n_13;
input n_8;
input n_6;

output n_67;

wire n_36;
wire n_59;
wire n_62;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_64;
wire n_40;
wire n_54;
wire n_35;
wire n_57;
wire n_30;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_66;
wire n_48;
wire n_60;
wire n_39;
wire n_46;
wire n_42;
wire n_63;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_65;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;
wire n_61;

BUFx2_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_12),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_13),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_3),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_7),
.B(n_10),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_15),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_17),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_2),
.B(n_25),
.Y(n_37)
);

NAND2x1_ASAP7_75t_L g38 ( 
.A(n_24),
.B(n_26),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_1),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_18),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_14),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_29),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_31),
.B(n_22),
.C(n_20),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_25),
.B1(n_24),
.B2(n_22),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_33),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_32),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_38),
.B1(n_36),
.B2(n_33),
.C(n_35),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_42),
.A2(n_36),
.B1(n_35),
.B2(n_37),
.Y(n_48)
);

NAND2xp33_ASAP7_75t_R g49 ( 
.A(n_45),
.B(n_26),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

OAI31xp33_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_43),
.A3(n_46),
.B(n_39),
.Y(n_51)
);

OAI221xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_44),
.B1(n_40),
.B2(n_30),
.C(n_34),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_52),
.B(n_27),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_27),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

OAI221xp5_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_51),
.B1(n_30),
.B2(n_28),
.C(n_0),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_28),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_4),
.Y(n_58)
);

OA21x2_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_54),
.B(n_5),
.Y(n_59)
);

AOI21xp33_ASAP7_75t_SL g60 ( 
.A1(n_56),
.A2(n_9),
.B(n_6),
.Y(n_60)
);

NOR4xp75_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_19),
.C(n_16),
.D(n_11),
.Y(n_61)
);

CKINVDCx5p33_ASAP7_75t_R g62 ( 
.A(n_61),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_L g63 ( 
.A(n_60),
.B(n_21),
.Y(n_63)
);

NAND3xp33_ASAP7_75t_L g64 ( 
.A(n_59),
.B(n_23),
.C(n_43),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_62),
.Y(n_65)
);

AND2x4_ASAP7_75t_L g66 ( 
.A(n_64),
.B(n_59),
.Y(n_66)
);

NAND3xp33_ASAP7_75t_L g67 ( 
.A(n_66),
.B(n_63),
.C(n_65),
.Y(n_67)
);


endmodule