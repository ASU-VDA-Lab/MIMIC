module fake_netlist_659_2067_n_45 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_45);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_45;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_23;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

INVx2_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_3),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_13),
.B(n_2),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_19),
.B(n_14),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_8),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_11),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_5),
.Y(n_29)
);

CKINVDCx6p67_ASAP7_75t_R g30 ( 
.A(n_24),
.Y(n_30)
);

A2O1A1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_29),
.B(n_22),
.C(n_21),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_25),
.A2(n_1),
.B(n_0),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_30),
.B(n_23),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_33),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_32),
.B(n_25),
.Y(n_37)
);

AOI321xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_26),
.A3(n_19),
.B1(n_16),
.B2(n_18),
.C(n_27),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_37),
.B(n_16),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

BUFx6f_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_18),
.B1(n_7),
.B2(n_4),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_17),
.B1(n_10),
.B2(n_9),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_20),
.B1(n_42),
.B2(n_44),
.Y(n_45)
);


endmodule