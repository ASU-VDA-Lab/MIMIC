module fake_netlist_688_403_n_26 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_26);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_26;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

BUFx10_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_17),
.B(n_0),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_13),
.Y(n_21)
);

AOI32xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_14),
.A3(n_17),
.B1(n_18),
.B2(n_2),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_4),
.C(n_3),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_5),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_26)
);


endmodule