module fake_netlist_688_2962_n_8 (n_0, n_1, n_8);

input n_0;
input n_1;

output n_8;

wire n_4;
wire n_2;
wire n_7;
wire n_3;
wire n_5;
wire n_6;

CKINVDCx5p33_ASAP7_75t_R g2 ( 
.A(n_0),
.Y(n_2)
);

HB1xp67_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_3),
.Y(n_5)
);

AOI221xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_3),
.Y(n_6)
);

AND3x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.C(n_1),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_0),
.B1(n_1),
.B2(n_6),
.Y(n_8)
);


endmodule