module fake_netlist_688_172_n_25 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_25);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_25;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_13;
wire n_19;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_4),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_1),
.B(n_7),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_2),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_1),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_4),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_17),
.B(n_15),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_13),
.B1(n_14),
.B2(n_12),
.C(n_18),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_20),
.B1(n_13),
.B2(n_0),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_5),
.Y(n_23)
);

NAND5xp2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.C(n_6),
.D(n_3),
.E(n_8),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_6),
.B1(n_10),
.B2(n_9),
.Y(n_25)
);


endmodule