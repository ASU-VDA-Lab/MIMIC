module fake_netlist_688_3675_n_16 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_16);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_16;

wire n_8;
wire n_9;
wire n_15;
wire n_11;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx4_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

AND2x6_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_3),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_2),
.B(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_9),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B1(n_7),
.B2(n_4),
.C(n_6),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B1(n_7),
.B2(n_6),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_10),
.B(n_9),
.Y(n_16)
);


endmodule