module fake_netlist_688_4343_n_18 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_18);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_17;
wire n_9;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx11_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_5),
.A2(n_8),
.B1(n_4),
.B2(n_0),
.Y(n_11)
);

OAI21x1_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B1(n_9),
.B2(n_1),
.C(n_2),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_SL g16 ( 
.A(n_15),
.B(n_4),
.C(n_2),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_10),
.B1(n_7),
.B2(n_5),
.C(n_6),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_6),
.Y(n_18)
);


endmodule