module fake_netlist_688_2971_n_15 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_15);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_15;

wire n_9;
wire n_7;
wire n_14;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_12;

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

O2A1O1Ixp33_ASAP7_75t_SL g10 ( 
.A1(n_7),
.A2(n_5),
.B(n_4),
.C(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_SL g12 ( 
.A(n_11),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_9),
.B(n_7),
.Y(n_13)
);

NOR4xp25_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_8),
.C(n_4),
.D(n_1),
.Y(n_14)
);

AO22x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_0),
.B1(n_2),
.B2(n_11),
.Y(n_15)
);


endmodule