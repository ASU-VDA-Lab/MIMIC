module fake_netlist_688_3211_n_8 (n_3, n_0, n_2, n_1, n_8);

input n_3;
input n_0;
input n_2;
input n_1;

output n_8;

wire n_4;
wire n_7;
wire n_5;
wire n_6;

OA21x2_ASAP7_75t_L g4 ( 
.A1(n_0),
.A2(n_3),
.B(n_2),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_6),
.B2(n_4),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);


endmodule