module fake_netlist_688_680_n_19 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_19);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_19;

wire n_17;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_1),
.Y(n_12)
);

AND2x2_ASAP7_75t_SL g13 ( 
.A(n_5),
.B(n_7),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_6),
.B1(n_3),
.B2(n_0),
.C(n_2),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_12),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.C(n_4),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_13),
.B(n_9),
.Y(n_19)
);


endmodule