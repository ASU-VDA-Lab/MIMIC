module fake_netlist_688_389_n_18 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_18);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_9;
wire n_17;
wire n_14;
wire n_15;
wire n_7;
wire n_11;
wire n_13;
wire n_16;
wire n_8;
wire n_10;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

O2A1O1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_7),
.B1(n_6),
.B2(n_3),
.Y(n_18)
);


endmodule