module fake_netlist_688_3156_n_13 (n_0, n_2, n_1, n_13);

input n_0;
input n_2;
input n_1;

output n_13;

wire n_9;
wire n_4;
wire n_7;
wire n_3;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx2_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

AND2x4_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_0),
.Y(n_4)
);

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_1),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

NOR2x1p5_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVxp67_ASAP7_75t_SL g9 ( 
.A(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_6),
.B(n_4),
.Y(n_10)
);

AND3x4_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_5),
.C(n_2),
.Y(n_11)
);

NAND4xp75_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_6),
.C(n_8),
.D(n_2),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_8),
.B(n_12),
.Y(n_13)
);


endmodule