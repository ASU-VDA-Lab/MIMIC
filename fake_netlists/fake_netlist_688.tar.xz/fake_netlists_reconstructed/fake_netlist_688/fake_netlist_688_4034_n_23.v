module fake_netlist_688_4034_n_23 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_23);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_23;

wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_11;
wire n_19;
wire n_13;
wire n_14;
wire n_12;

AOI22xp33_ASAP7_75t_SL g11 ( 
.A1(n_7),
.A2(n_2),
.B1(n_0),
.B2(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

CKINVDCx6p67_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

BUFx10_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_6),
.B(n_4),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_7),
.B(n_6),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI221xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_11),
.B1(n_14),
.B2(n_15),
.C(n_13),
.Y(n_20)
);

NOR3xp33_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_16),
.C(n_9),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_16),
.Y(n_22)
);

AO22x2_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_10),
.B1(n_14),
.B2(n_18),
.Y(n_23)
);


endmodule