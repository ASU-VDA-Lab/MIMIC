module fake_netlist_688_4083_n_20 (n_4, n_2, n_3, n_1, n_5, n_0, n_20);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_20;

wire n_17;
wire n_6;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_7;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

BUFx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_1),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_2),
.Y(n_8)
);

OR2x2_ASAP7_75t_SL g9 ( 
.A(n_5),
.B(n_1),
.Y(n_9)
);

O2A1O1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_9),
.B(n_7),
.C(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_6),
.B(n_1),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_6),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_9),
.B(n_2),
.C(n_0),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B1(n_9),
.B2(n_0),
.Y(n_15)
);

NOR4xp25_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_3),
.C(n_2),
.D(n_0),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_4),
.C(n_3),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_17),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

AOI222xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_3),
.B1(n_4),
.B2(n_5),
.C1(n_19),
.C2(n_15),
.Y(n_20)
);


endmodule