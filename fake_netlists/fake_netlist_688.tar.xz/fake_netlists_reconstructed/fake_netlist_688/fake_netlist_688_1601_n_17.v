module fake_netlist_688_1601_n_17 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_17);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_17;

wire n_8;
wire n_9;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_1),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

NOR3x1_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.C(n_2),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_7),
.B(n_3),
.Y(n_17)
);


endmodule