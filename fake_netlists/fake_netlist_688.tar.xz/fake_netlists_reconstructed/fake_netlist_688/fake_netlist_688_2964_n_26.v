module fake_netlist_688_2964_n_26 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_26);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_26;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_SL g13 ( 
.A(n_0),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_2),
.B(n_1),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_7),
.B(n_6),
.C(n_8),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_16),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_13),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_17),
.Y(n_23)
);

OAI211xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_20),
.B(n_16),
.C(n_18),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_9),
.Y(n_25)
);

NAND2x1p5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_11),
.Y(n_26)
);


endmodule