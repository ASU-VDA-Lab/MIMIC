module fake_netlist_626_1937_n_67 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_67);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_67;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_18;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_58;
wire n_62;
wire n_52;
wire n_49;
wire n_51;
wire n_24;
wire n_48;
wire n_35;
wire n_45;
wire n_65;
wire n_25;
wire n_63;
wire n_26;
wire n_60;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_66;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_64;

BUFx3_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_4),
.B(n_7),
.Y(n_19)
);

NAND2x1p5_ASAP7_75t_L g20 ( 
.A(n_0),
.B(n_3),
.Y(n_20)
);

OAI22x1_ASAP7_75t_L g21 ( 
.A1(n_15),
.A2(n_9),
.B1(n_14),
.B2(n_11),
.Y(n_21)
);

AND2x6_ASAP7_75t_L g22 ( 
.A(n_2),
.B(n_13),
.Y(n_22)
);

CKINVDCx6p67_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_1),
.B(n_0),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_12),
.B(n_10),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_1),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_17),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_17),
.B(n_18),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_19),
.A2(n_6),
.B1(n_4),
.B2(n_3),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_23),
.B(n_16),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_19),
.A2(n_8),
.B1(n_18),
.B2(n_22),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

OAI21xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_19),
.B(n_27),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_32),
.Y(n_37)
);

BUFx12f_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

AO31x2_ASAP7_75t_L g39 ( 
.A1(n_28),
.A2(n_21),
.A3(n_25),
.B(n_23),
.Y(n_39)
);

OAI21x1_ASAP7_75t_L g40 ( 
.A1(n_30),
.A2(n_27),
.B(n_28),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_29),
.Y(n_42)
);

AO21x2_ASAP7_75t_L g43 ( 
.A1(n_36),
.A2(n_34),
.B(n_35),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_38),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

INVx3_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_38),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_39),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_38),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_39),
.Y(n_52)
);

AOI221xp5_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_47),
.B1(n_31),
.B2(n_36),
.C(n_29),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_39),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_43),
.B1(n_40),
.B2(n_21),
.Y(n_56)
);

NOR2x1p5_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_24),
.Y(n_57)
);

NAND4xp25_ASAP7_75t_SL g58 ( 
.A(n_53),
.B(n_39),
.C(n_20),
.D(n_22),
.Y(n_58)
);

AOI221xp5_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_20),
.B1(n_24),
.B2(n_43),
.C(n_39),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_54),
.B(n_39),
.Y(n_60)
);

NOR3xp33_ASAP7_75t_L g61 ( 
.A(n_58),
.B(n_59),
.C(n_60),
.Y(n_61)
);

NAND3xp33_ASAP7_75t_L g62 ( 
.A(n_57),
.B(n_24),
.C(n_46),
.Y(n_62)
);

NOR3xp33_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_34),
.C(n_46),
.Y(n_63)
);

NOR2xp33_ASAP7_75t_L g64 ( 
.A(n_62),
.B(n_24),
.Y(n_64)
);

AOI22xp33_ASAP7_75t_L g65 ( 
.A1(n_61),
.A2(n_22),
.B1(n_34),
.B2(n_35),
.Y(n_65)
);

OAI21xp33_ASAP7_75t_L g66 ( 
.A1(n_64),
.A2(n_63),
.B(n_22),
.Y(n_66)
);

OAI21xp5_ASAP7_75t_L g67 ( 
.A1(n_66),
.A2(n_65),
.B(n_34),
.Y(n_67)
);


endmodule