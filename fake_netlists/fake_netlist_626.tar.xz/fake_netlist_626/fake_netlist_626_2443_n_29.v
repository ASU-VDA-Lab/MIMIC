module fake_netlist_626_2443_n_29 (n_7, n_9, n_11, n_8, n_5, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_29);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_29;

wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_20;
wire n_23;
wire n_16;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_8),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_0),
.B(n_5),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_9),
.B(n_4),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

INVx4_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_12),
.Y(n_21)
);

NOR2x1_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_14),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_19),
.B(n_14),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_21),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

XOR2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_13),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_17),
.B1(n_16),
.B2(n_1),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_11),
.B1(n_6),
.B2(n_2),
.Y(n_29)
);


endmodule