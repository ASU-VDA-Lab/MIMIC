module fake_netlist_626_2722_n_73 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_25, n_26, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_73);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_25;
input n_26;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_73;

wire n_31;
wire n_37;
wire n_53;
wire n_54;
wire n_39;
wire n_40;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_61;
wire n_29;
wire n_34;
wire n_58;
wire n_28;
wire n_27;
wire n_62;
wire n_67;
wire n_52;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_65;
wire n_69;
wire n_63;
wire n_60;
wire n_46;
wire n_38;
wire n_47;
wire n_57;
wire n_70;
wire n_43;
wire n_56;
wire n_71;
wire n_66;
wire n_32;
wire n_42;
wire n_33;
wire n_72;
wire n_41;
wire n_55;
wire n_64;
wire n_68;

OAI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_10),
.A2(n_24),
.B1(n_8),
.B2(n_13),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_26),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_12),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_14),
.A2(n_23),
.B1(n_2),
.B2(n_18),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_9),
.Y(n_33)
);

INVx6_ASAP7_75t_L g34 ( 
.A(n_5),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_6),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_11),
.A2(n_6),
.B(n_21),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_19),
.Y(n_37)
);

OA21x2_ASAP7_75t_L g38 ( 
.A1(n_22),
.A2(n_7),
.B(n_1),
.Y(n_38)
);

BUFx6f_ASAP7_75t_L g39 ( 
.A(n_0),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_15),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_34),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_0),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_35),
.B(n_1),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_30),
.B(n_3),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_34),
.A2(n_4),
.B1(n_3),
.B2(n_17),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_31),
.B(n_40),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_42),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_29),
.B(n_31),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_41),
.Y(n_49)
);

AO31x2_ASAP7_75t_L g50 ( 
.A1(n_43),
.A2(n_32),
.A3(n_40),
.B(n_36),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_L g51 ( 
.A1(n_44),
.A2(n_28),
.B(n_38),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_45),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_45),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

BUFx6f_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

HB1xp67_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

OR2x2_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_48),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

INVx2_ASAP7_75t_SL g61 ( 
.A(n_57),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_59),
.Y(n_62)
);

AOI22xp33_ASAP7_75t_L g63 ( 
.A1(n_61),
.A2(n_54),
.B1(n_27),
.B2(n_56),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_SL g64 ( 
.A(n_62),
.B(n_56),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_60),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_65),
.B(n_39),
.Y(n_66)
);

NAND4xp25_ASAP7_75t_L g67 ( 
.A(n_64),
.B(n_33),
.C(n_56),
.D(n_63),
.Y(n_67)
);

OR2x2_ASAP7_75t_L g68 ( 
.A(n_66),
.B(n_33),
.Y(n_68)
);

INVx3_ASAP7_75t_L g69 ( 
.A(n_67),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_68),
.Y(n_70)
);

BUFx2_ASAP7_75t_L g71 ( 
.A(n_69),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_71),
.Y(n_72)
);

OR2x2_ASAP7_75t_L g73 ( 
.A(n_72),
.B(n_70),
.Y(n_73)
);


endmodule