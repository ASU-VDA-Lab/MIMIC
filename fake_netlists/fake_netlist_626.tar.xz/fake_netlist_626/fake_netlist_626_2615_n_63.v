module fake_netlist_626_2615_n_63 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_20, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_63);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_20;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_63;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_58;
wire n_62;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_60;
wire n_46;
wire n_38;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

BUFx12f_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_SL g22 ( 
.A1(n_20),
.A2(n_17),
.B1(n_13),
.B2(n_0),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_18),
.B(n_4),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_9),
.A2(n_18),
.B1(n_12),
.B2(n_3),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_19),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_26),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_27),
.B(n_2),
.Y(n_33)
);

AND2x2_ASAP7_75t_SL g34 ( 
.A(n_27),
.B(n_15),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_24),
.B(n_15),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_34),
.Y(n_36)
);

INVx4_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_32),
.B(n_23),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

BUFx2_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

NOR2x1_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_37),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

NAND3xp33_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_33),
.C(n_39),
.Y(n_44)
);

INVx2_ASAP7_75t_SL g45 ( 
.A(n_42),
.Y(n_45)
);

OAI211xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_36),
.B(n_33),
.C(n_31),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_21),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_21),
.Y(n_50)
);

A2O1A1Ixp33_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_47),
.B(n_49),
.C(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

NOR2x1_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_31),
.Y(n_53)
);

OR2x2_ASAP7_75t_L g54 ( 
.A(n_47),
.B(n_22),
.Y(n_54)
);

NAND4xp75_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_30),
.C(n_29),
.D(n_28),
.Y(n_55)
);

OR4x2_ASAP7_75t_L g56 ( 
.A(n_51),
.B(n_17),
.C(n_16),
.D(n_26),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

AOI32xp33_ASAP7_75t_L g58 ( 
.A1(n_50),
.A2(n_54),
.A3(n_16),
.B1(n_38),
.B2(n_51),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_57),
.B(n_26),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_58),
.B(n_26),
.Y(n_60)
);

XNOR2x1_ASAP7_75t_L g61 ( 
.A(n_55),
.B(n_1),
.Y(n_61)
);

OAI22xp5_ASAP7_75t_L g62 ( 
.A1(n_60),
.A2(n_56),
.B1(n_25),
.B2(n_5),
.Y(n_62)
);

AO221x2_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_61),
.B1(n_59),
.B2(n_6),
.C(n_7),
.Y(n_63)
);


endmodule