module fake_netlist_626_1436_n_42 (n_7, n_9, n_11, n_8, n_5, n_10, n_6, n_0, n_4, n_1, n_2, n_3, n_42);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_42;

wire n_31;
wire n_15;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;
wire n_14;
wire n_41;
wire n_13;
wire n_12;

AND2x2_ASAP7_75t_L g12 ( 
.A(n_4),
.B(n_0),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_4),
.B(n_7),
.Y(n_13)
);

INVx6_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_3),
.B(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_1),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_11),
.B1(n_8),
.B2(n_2),
.Y(n_21)
);

INVxp67_ASAP7_75t_SL g22 ( 
.A(n_19),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_18),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_19),
.Y(n_27)
);

OAI21xp5_ASAP7_75t_L g28 ( 
.A1(n_24),
.A2(n_18),
.B(n_17),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_R g30 ( 
.A(n_27),
.B(n_20),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

INVxp67_ASAP7_75t_SL g33 ( 
.A(n_30),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_29),
.A2(n_25),
.B1(n_28),
.B2(n_14),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_32),
.B(n_29),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_34),
.B1(n_31),
.B2(n_28),
.Y(n_36)
);

AO22x2_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_21),
.B1(n_15),
.B2(n_12),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AO22x2_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_12),
.B1(n_13),
.B2(n_14),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_40),
.B1(n_37),
.B2(n_39),
.Y(n_42)
);


endmodule