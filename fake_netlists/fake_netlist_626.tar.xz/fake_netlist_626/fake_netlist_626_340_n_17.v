module fake_netlist_626_340_n_17 (n_5, n_0, n_4, n_1, n_2, n_3, n_17);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_17;

wire n_7;
wire n_9;
wire n_11;
wire n_16;
wire n_8;
wire n_15;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_12;

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_5),
.B(n_2),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_2),
.B1(n_0),
.B2(n_3),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVxp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

AOI21x1_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B(n_12),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_13),
.B(n_10),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_8),
.B1(n_15),
.B2(n_3),
.Y(n_17)
);


endmodule