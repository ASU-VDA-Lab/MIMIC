module fake_netlist_626_970_n_25 (n_0, n_4, n_1, n_2, n_3, n_25);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_25;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_7;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_5;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_0),
.Y(n_10)
);

OA21x2_ASAP7_75t_L g11 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

AOI21x1_ASAP7_75t_L g13 ( 
.A1(n_5),
.A2(n_2),
.B(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AOI321xp33_ASAP7_75t_L g16 ( 
.A1(n_10),
.A2(n_8),
.A3(n_7),
.B1(n_6),
.B2(n_4),
.C(n_2),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

OAI211xp5_ASAP7_75t_SL g18 ( 
.A1(n_16),
.A2(n_8),
.B(n_6),
.C(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_SL g19 ( 
.A(n_15),
.Y(n_19)
);

AOI22x1_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_15),
.B1(n_14),
.B2(n_16),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_15),
.B1(n_7),
.B2(n_14),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_17),
.B1(n_4),
.B2(n_2),
.C(n_11),
.Y(n_22)
);

NOR2x1p5_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_13),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_22),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_11),
.B(n_23),
.Y(n_25)
);


endmodule