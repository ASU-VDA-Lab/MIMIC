module fake_netlist_626_142_n_62 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_27, n_17, n_4, n_1, n_24, n_7, n_25, n_26, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_62);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_27;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_25;
input n_26;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_62;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_61;
wire n_29;
wire n_34;
wire n_28;
wire n_58;
wire n_52;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_60;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_32;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

INVx2_ASAP7_75t_L g28 ( 
.A(n_7),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_17),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_14),
.B(n_21),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_24),
.B(n_6),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

AND2x6_ASAP7_75t_L g33 ( 
.A(n_1),
.B(n_16),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_2),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_25),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_13),
.B(n_26),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_15),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_29),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_28),
.B(n_23),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_32),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

AOI21xp33_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_27),
.B(n_23),
.Y(n_43)
);

O2A1O1Ixp33_ASAP7_75t_SL g44 ( 
.A1(n_41),
.A2(n_36),
.B(n_35),
.C(n_34),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_31),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_33),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_39),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_39),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_27),
.Y(n_49)
);

OAI21xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_44),
.B(n_37),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_30),
.B(n_33),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_0),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);

AOI21xp33_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_4),
.B(n_3),
.Y(n_54)
);

HB1xp67_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

AND2x4_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_5),
.Y(n_56)
);

AND2x4_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_8),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_54),
.B(n_9),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

NOR2xp33_ASAP7_75t_R g60 ( 
.A(n_56),
.B(n_57),
.Y(n_60)
);

AOI21xp33_ASAP7_75t_L g61 ( 
.A1(n_59),
.A2(n_57),
.B(n_58),
.Y(n_61)
);

AOI322xp5_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_60),
.A3(n_12),
.B1(n_11),
.B2(n_10),
.C1(n_20),
.C2(n_18),
.Y(n_62)
);


endmodule