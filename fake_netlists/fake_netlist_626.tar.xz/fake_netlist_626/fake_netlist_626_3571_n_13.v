module fake_netlist_626_3571_n_13 (n_5, n_0, n_4, n_1, n_2, n_3, n_13);

input n_5;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_13;

wire n_7;
wire n_11;
wire n_8;
wire n_10;
wire n_6;
wire n_12;
wire n_9;

OR2x2_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_4),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_4),
.B(n_1),
.Y(n_7)
);

OR2x6_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_8),
.Y(n_10)
);

NOR4xp75_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_5),
.C(n_1),
.D(n_2),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_5),
.B(n_3),
.Y(n_13)
);


endmodule