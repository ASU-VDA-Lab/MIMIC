module fake_netlist_626_2026_n_54 (n_7, n_9, n_11, n_16, n_8, n_5, n_15, n_14, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_54);

input n_7;
input n_9;
input n_11;
input n_16;
input n_8;
input n_5;
input n_15;
input n_14;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_54;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_50;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;

INVx1_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

AO21x2_ASAP7_75t_L g20 ( 
.A1(n_14),
.A2(n_8),
.B(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_15),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_12),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_9),
.B(n_11),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_13),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_18),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_27)
);

O2A1O1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_4),
.B(n_3),
.C(n_0),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_19),
.A2(n_7),
.B(n_3),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_18),
.B(n_4),
.Y(n_30)
);

O2A1O1Ixp5_ASAP7_75t_SL g31 ( 
.A1(n_17),
.A2(n_9),
.B(n_8),
.C(n_5),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_18),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_19),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

NAND2xp33_ASAP7_75t_SL g35 ( 
.A(n_32),
.B(n_25),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_29),
.A2(n_19),
.B(n_17),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_27),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_34),
.B(n_22),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_24),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

BUFx3_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_37),
.B1(n_35),
.B2(n_20),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_28),
.B1(n_21),
.B2(n_30),
.C(n_41),
.Y(n_46)
);

AOI21xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_36),
.B(n_20),
.Y(n_47)
);

OAI211xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_25),
.B(n_26),
.C(n_36),
.Y(n_48)
);

AND2x4_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_43),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

BUFx6f_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_46),
.B1(n_43),
.B2(n_20),
.Y(n_52)
);

OA22x2_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_31),
.B1(n_20),
.B2(n_16),
.Y(n_53)
);

AOI22xp33_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_16),
.B1(n_51),
.B2(n_52),
.Y(n_54)
);


endmodule