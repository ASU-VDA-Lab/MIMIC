module fake_netlist_626_1065_n_6 (n_1, n_0, n_6);

input n_1;
input n_0;

output n_6;

wire n_5;
wire n_4;
wire n_2;
wire n_3;

INVx1_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

AND2x2_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_0),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_3),
.Y(n_5)
);

AOI22xp33_ASAP7_75t_SL g6 ( 
.A1(n_5),
.A2(n_1),
.B1(n_4),
.B2(n_3),
.Y(n_6)
);


endmodule