module fake_netlist_626_3802_n_59 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_19, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_59);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_19;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_59;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_58;
wire n_52;
wire n_24;
wire n_51;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_4),
.B(n_5),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_19),
.B(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

OA21x2_ASAP7_75t_L g25 ( 
.A1(n_8),
.A2(n_17),
.B(n_6),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_15),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_3),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_7),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_12),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_15),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_2),
.B(n_14),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_24),
.B(n_13),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_26),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_30),
.B1(n_26),
.B2(n_31),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_20),
.Y(n_39)
);

NAND2xp33_ASAP7_75t_R g40 ( 
.A(n_39),
.B(n_22),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_34),
.B1(n_36),
.B2(n_33),
.C(n_31),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_41),
.B(n_23),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_34),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_34),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_43),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_13),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

AOI211xp5_ASAP7_75t_SL g48 ( 
.A1(n_45),
.A2(n_31),
.B(n_21),
.C(n_37),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_SL g49 ( 
.A1(n_45),
.A2(n_33),
.B(n_16),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

AND2x4_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_16),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_29),
.Y(n_52)
);

BUFx2_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

AND2x4_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_0),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_48),
.B1(n_25),
.B2(n_1),
.Y(n_58)
);

OAI221xp5_ASAP7_75t_R g59 ( 
.A1(n_58),
.A2(n_55),
.B1(n_57),
.B2(n_56),
.C(n_52),
.Y(n_59)
);


endmodule