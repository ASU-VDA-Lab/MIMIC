module fake_netlist_626_891_n_43 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_43);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_43;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;

BUFx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_12),
.B(n_5),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_2),
.B(n_11),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_7),
.B(n_3),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_10),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_1),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_25),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_R g33 ( 
.A(n_30),
.B(n_20),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_29),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_20),
.B(n_21),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_26),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_22),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_0),
.Y(n_39)
);

NOR2x1_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_4),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_6),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_41),
.Y(n_42)
);

AOI322xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_40),
.A3(n_14),
.B1(n_13),
.B2(n_8),
.C1(n_17),
.C2(n_15),
.Y(n_43)
);


endmodule