module fake_netlist_626_2948_n_64 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_64);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_64;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_22;
wire n_61;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_58;
wire n_62;
wire n_52;
wire n_24;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_63;
wire n_26;
wire n_60;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

INVx1_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_9),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_3),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_10),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_4),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_16),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_0),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_1),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_26),
.B(n_1),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_26),
.B(n_2),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_19),
.B(n_3),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_24),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_33),
.A2(n_29),
.B(n_27),
.C(n_24),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_30),
.B(n_32),
.Y(n_40)
);

AOI21xp33_ASAP7_75t_L g41 ( 
.A1(n_31),
.A2(n_23),
.B(n_20),
.Y(n_41)
);

INVx4_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

OAI33xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_38),
.A3(n_34),
.B1(n_36),
.B2(n_27),
.B3(n_24),
.Y(n_43)
);

AOI22xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_27),
.B1(n_37),
.B2(n_22),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_39),
.Y(n_45)
);

OR2x6_ASAP7_75t_L g46 ( 
.A(n_39),
.B(n_19),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_15),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_44),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

O2A1O1Ixp33_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_43),
.B(n_25),
.C(n_21),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_42),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_47),
.Y(n_54)
);

AOI21xp33_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_50),
.B(n_42),
.Y(n_55)
);

AND2x2_ASAP7_75t_SL g56 ( 
.A(n_51),
.B(n_21),
.Y(n_56)
);

INVx2_ASAP7_75t_SL g57 ( 
.A(n_54),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

NOR3xp33_ASAP7_75t_L g59 ( 
.A(n_57),
.B(n_6),
.C(n_5),
.Y(n_59)
);

CKINVDCx20_ASAP7_75t_R g60 ( 
.A(n_57),
.Y(n_60)
);

BUFx2_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

HB1xp67_ASAP7_75t_L g62 ( 
.A(n_61),
.Y(n_62)
);

HB1xp67_ASAP7_75t_L g63 ( 
.A(n_60),
.Y(n_63)
);

AOI322xp5_ASAP7_75t_L g64 ( 
.A1(n_63),
.A2(n_8),
.A3(n_12),
.B1(n_55),
.B2(n_59),
.C1(n_62),
.C2(n_56),
.Y(n_64)
);


endmodule