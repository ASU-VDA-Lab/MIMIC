module fake_netlist_626_3562_n_59 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_27, n_28, n_17, n_4, n_1, n_24, n_7, n_25, n_26, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_59);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_27;
input n_28;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_25;
input n_26;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_59;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_34;
wire n_58;
wire n_52;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_32;
wire n_42;
wire n_33;
wire n_41;
wire n_55;

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_14),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_27),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_2),
.Y(n_33)
);

INVx6_ASAP7_75t_L g34 ( 
.A(n_1),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_23),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_7),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_0),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_10),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_21),
.B(n_16),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_SL g40 ( 
.A(n_30),
.B(n_28),
.C(n_3),
.Y(n_40)
);

NOR3xp33_ASAP7_75t_SL g41 ( 
.A(n_37),
.B(n_28),
.C(n_4),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_36),
.B(n_5),
.Y(n_42)
);

BUFx6f_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

OAI22xp33_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_29),
.B1(n_34),
.B2(n_32),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_41),
.Y(n_45)
);

O2A1O1Ixp33_ASAP7_75t_SL g46 ( 
.A1(n_42),
.A2(n_34),
.B(n_39),
.C(n_31),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_43),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_33),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

OR2x2_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_35),
.Y(n_50)
);

O2A1O1Ixp33_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_46),
.B(n_8),
.C(n_6),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

AOI221xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_11),
.B1(n_9),
.B2(n_12),
.C(n_13),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

OR3x1_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_17),
.C(n_15),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_56),
.Y(n_57)
);

AOI22xp33_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_20),
.B1(n_19),
.B2(n_18),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_L g59 ( 
.A1(n_57),
.A2(n_25),
.B1(n_26),
.B2(n_58),
.Y(n_59)
);


endmodule