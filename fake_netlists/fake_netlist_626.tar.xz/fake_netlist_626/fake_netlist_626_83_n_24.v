module fake_netlist_626_83_n_24 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_24);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_24;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

INVx3_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_5),
.Y(n_10)
);

BUFx3_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_4),
.B(n_1),
.Y(n_12)
);

OA21x2_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_5),
.B(n_4),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_12),
.B(n_14),
.Y(n_18)
);

INVxp67_ASAP7_75t_SL g19 ( 
.A(n_15),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_9),
.B1(n_10),
.B2(n_16),
.C(n_17),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_11),
.B1(n_17),
.B2(n_13),
.C1(n_7),
.C2(n_6),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_13),
.B(n_11),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_7),
.B1(n_23),
.B2(n_20),
.Y(n_24)
);


endmodule