module fake_netlist_829_623_n_34 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_34);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

AO21x2_ASAP7_75t_L g18 ( 
.A1(n_7),
.A2(n_6),
.B(n_14),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_3),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_15),
.B(n_12),
.Y(n_23)
);

INVx3_ASAP7_75t_SL g24 ( 
.A(n_17),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_18),
.A2(n_16),
.B1(n_6),
.B2(n_0),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_20),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_22),
.C(n_25),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_18),
.Y(n_29)
);

INVxp67_ASAP7_75t_SL g30 ( 
.A(n_29),
.Y(n_30)
);

NAND5xp2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_27),
.C(n_23),
.D(n_5),
.E(n_9),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_32),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_21),
.B1(n_19),
.B2(n_10),
.Y(n_34)
);


endmodule