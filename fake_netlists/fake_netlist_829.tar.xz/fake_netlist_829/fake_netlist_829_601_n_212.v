module fake_netlist_829_601_n_212 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_212);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_212;

wire n_49;
wire n_132;
wire n_97;
wire n_194;
wire n_81;
wire n_182;
wire n_114;
wire n_130;
wire n_80;
wire n_166;
wire n_123;
wire n_173;
wire n_156;
wire n_126;
wire n_154;
wire n_78;
wire n_153;
wire n_187;
wire n_195;
wire n_210;
wire n_87;
wire n_167;
wire n_122;
wire n_54;
wire n_96;
wire n_95;
wire n_56;
wire n_59;
wire n_63;
wire n_94;
wire n_74;
wire n_64;
wire n_79;
wire n_177;
wire n_110;
wire n_61;
wire n_184;
wire n_86;
wire n_43;
wire n_45;
wire n_108;
wire n_192;
wire n_48;
wire n_162;
wire n_163;
wire n_209;
wire n_196;
wire n_158;
wire n_135;
wire n_171;
wire n_47;
wire n_118;
wire n_127;
wire n_202;
wire n_90;
wire n_76;
wire n_189;
wire n_160;
wire n_107;
wire n_125;
wire n_151;
wire n_99;
wire n_178;
wire n_72;
wire n_121;
wire n_73;
wire n_211;
wire n_37;
wire n_207;
wire n_42;
wire n_120;
wire n_103;
wire n_155;
wire n_145;
wire n_200;
wire n_175;
wire n_185;
wire n_52;
wire n_199;
wire n_143;
wire n_170;
wire n_77;
wire n_161;
wire n_27;
wire n_190;
wire n_179;
wire n_137;
wire n_57;
wire n_51;
wire n_138;
wire n_116;
wire n_136;
wire n_102;
wire n_119;
wire n_89;
wire n_152;
wire n_70;
wire n_172;
wire n_131;
wire n_128;
wire n_133;
wire n_139;
wire n_142;
wire n_115;
wire n_109;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_117;
wire n_53;
wire n_144;
wire n_84;
wire n_58;
wire n_68;
wire n_183;
wire n_146;
wire n_104;
wire n_105;
wire n_168;
wire n_33;
wire n_106;
wire n_149;
wire n_188;
wire n_85;
wire n_205;
wire n_55;
wire n_164;
wire n_65;
wire n_159;
wire n_75;
wire n_140;
wire n_176;
wire n_67;
wire n_66;
wire n_101;
wire n_98;
wire n_91;
wire n_36;
wire n_203;
wire n_204;
wire n_50;
wire n_191;
wire n_112;
wire n_129;
wire n_181;
wire n_157;
wire n_201;
wire n_198;
wire n_83;
wire n_60;
wire n_39;
wire n_111;
wire n_31;
wire n_32;
wire n_169;
wire n_180;
wire n_93;
wire n_174;
wire n_150;
wire n_71;
wire n_208;
wire n_92;
wire n_82;
wire n_186;
wire n_100;
wire n_69;
wire n_193;
wire n_165;
wire n_88;
wire n_29;
wire n_124;
wire n_197;
wire n_113;
wire n_30;
wire n_206;
wire n_147;
wire n_141;
wire n_134;
wire n_35;
wire n_148;
wire n_38;
wire n_46;

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_15),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_23),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

INVxp33_ASAP7_75t_SL g31 ( 
.A(n_25),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_12),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_2),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_12),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_13),
.Y(n_36)
);

INVxp33_ASAP7_75t_SL g37 ( 
.A(n_7),
.Y(n_37)
);

NOR2xp67_ASAP7_75t_L g38 ( 
.A(n_4),
.B(n_14),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_5),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_34),
.B(n_14),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_34),
.Y(n_41)
);

BUFx6f_ASAP7_75t_L g42 ( 
.A(n_36),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_31),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_43)
);

BUFx6f_ASAP7_75t_L g44 ( 
.A(n_36),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_29),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_29),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_30),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_30),
.Y(n_48)
);

OR2x6_ASAP7_75t_SL g49 ( 
.A(n_41),
.B(n_28),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_39),
.Y(n_50)
);

AND2x4_ASAP7_75t_L g51 ( 
.A(n_40),
.B(n_32),
.Y(n_51)
);

OAI221xp5_ASAP7_75t_L g52 ( 
.A1(n_45),
.A2(n_47),
.B1(n_48),
.B2(n_43),
.C(n_32),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_42),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_42),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_42),
.Y(n_55)
);

BUFx8_ASAP7_75t_L g56 ( 
.A(n_40),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_42),
.Y(n_57)
);

AND2x4_ASAP7_75t_L g58 ( 
.A(n_40),
.B(n_33),
.Y(n_58)
);

OAI221xp5_ASAP7_75t_L g59 ( 
.A1(n_45),
.A2(n_35),
.B1(n_33),
.B2(n_38),
.C(n_37),
.Y(n_59)
);

INVx1_ASAP7_75t_SL g60 ( 
.A(n_51),
.Y(n_60)
);

OAI22xp5_ASAP7_75t_L g61 ( 
.A1(n_52),
.A2(n_27),
.B1(n_48),
.B2(n_35),
.Y(n_61)
);

AND2x2_ASAP7_75t_L g62 ( 
.A(n_51),
.B(n_42),
.Y(n_62)
);

INVx2_ASAP7_75t_L g63 ( 
.A(n_53),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_58),
.Y(n_64)
);

NAND2x1p5_ASAP7_75t_L g65 ( 
.A(n_58),
.B(n_38),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_SL g66 ( 
.A(n_56),
.B(n_44),
.Y(n_66)
);

NAND2xp5_ASAP7_75t_L g67 ( 
.A(n_50),
.B(n_44),
.Y(n_67)
);

INVxp67_ASAP7_75t_SL g68 ( 
.A(n_56),
.Y(n_68)
);

NAND2xp5_ASAP7_75t_L g69 ( 
.A(n_58),
.B(n_51),
.Y(n_69)
);

NAND2x1p5_ASAP7_75t_L g70 ( 
.A(n_56),
.B(n_44),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_53),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_54),
.Y(n_72)
);

BUFx12f_ASAP7_75t_L g73 ( 
.A(n_49),
.Y(n_73)
);

OR2x2_ASAP7_75t_L g74 ( 
.A(n_59),
.B(n_16),
.Y(n_74)
);

CKINVDCx12_ASAP7_75t_R g75 ( 
.A(n_74),
.Y(n_75)
);

A2O1A1Ixp33_ASAP7_75t_SL g76 ( 
.A1(n_64),
.A2(n_57),
.B(n_55),
.C(n_54),
.Y(n_76)
);

AND2x2_ASAP7_75t_L g77 ( 
.A(n_60),
.B(n_49),
.Y(n_77)
);

NAND2xp5_ASAP7_75t_L g78 ( 
.A(n_60),
.B(n_44),
.Y(n_78)
);

NOR2xp67_ASAP7_75t_L g79 ( 
.A(n_64),
.B(n_0),
.Y(n_79)
);

AND2x2_ASAP7_75t_L g80 ( 
.A(n_69),
.B(n_27),
.Y(n_80)
);

HB1xp67_ASAP7_75t_L g81 ( 
.A(n_70),
.Y(n_81)
);

OA21x2_ASAP7_75t_L g82 ( 
.A1(n_67),
.A2(n_57),
.B(n_55),
.Y(n_82)
);

AND2x2_ASAP7_75t_L g83 ( 
.A(n_69),
.B(n_44),
.Y(n_83)
);

AND2x4_ASAP7_75t_L g84 ( 
.A(n_68),
.B(n_17),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_62),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_62),
.Y(n_86)
);

OR2x2_ASAP7_75t_L g87 ( 
.A(n_61),
.B(n_18),
.Y(n_87)
);

NAND2xp5_ASAP7_75t_L g88 ( 
.A(n_65),
.B(n_18),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_83),
.Y(n_89)
);

A2O1A1Ixp33_ASAP7_75t_L g90 ( 
.A1(n_79),
.A2(n_66),
.B(n_61),
.C(n_74),
.Y(n_90)
);

AND2x2_ASAP7_75t_L g91 ( 
.A(n_80),
.B(n_70),
.Y(n_91)
);

OR2x2_ASAP7_75t_L g92 ( 
.A(n_80),
.B(n_65),
.Y(n_92)
);

AND2x4_ASAP7_75t_L g93 ( 
.A(n_85),
.B(n_72),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_82),
.Y(n_94)
);

AOI22xp33_ASAP7_75t_L g95 ( 
.A1(n_80),
.A2(n_73),
.B1(n_65),
.B2(n_70),
.Y(n_95)
);

INVx1_ASAP7_75t_L g96 ( 
.A(n_83),
.Y(n_96)
);

INVx2_ASAP7_75t_L g97 ( 
.A(n_82),
.Y(n_97)
);

INVxp67_ASAP7_75t_L g98 ( 
.A(n_84),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_83),
.Y(n_99)
);

HB1xp67_ASAP7_75t_L g100 ( 
.A(n_84),
.Y(n_100)
);

NAND2xp5_ASAP7_75t_L g101 ( 
.A(n_91),
.B(n_92),
.Y(n_101)
);

BUFx2_ASAP7_75t_L g102 ( 
.A(n_100),
.Y(n_102)
);

AND2x2_ASAP7_75t_L g103 ( 
.A(n_91),
.B(n_87),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_97),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_97),
.Y(n_105)
);

INVx2_ASAP7_75t_L g106 ( 
.A(n_97),
.Y(n_106)
);

AO21x1_ASAP7_75t_L g107 ( 
.A1(n_94),
.A2(n_88),
.B(n_87),
.Y(n_107)
);

INVxp67_ASAP7_75t_SL g108 ( 
.A(n_98),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_94),
.Y(n_109)
);

NAND2xp5_ASAP7_75t_L g110 ( 
.A(n_92),
.B(n_77),
.Y(n_110)
);

INVx5_ASAP7_75t_SL g111 ( 
.A(n_106),
.Y(n_111)
);

INVx2_ASAP7_75t_L g112 ( 
.A(n_106),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_104),
.Y(n_113)
);

NAND4xp75_ASAP7_75t_L g114 ( 
.A(n_107),
.B(n_77),
.C(n_88),
.D(n_79),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_104),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_105),
.Y(n_116)
);

INVx2_ASAP7_75t_L g117 ( 
.A(n_106),
.Y(n_117)
);

INVx2_ASAP7_75t_L g118 ( 
.A(n_105),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_109),
.Y(n_119)
);

HB1xp67_ASAP7_75t_L g120 ( 
.A(n_118),
.Y(n_120)
);

INVx1_ASAP7_75t_L g121 ( 
.A(n_118),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_113),
.Y(n_122)
);

OA21x2_ASAP7_75t_L g123 ( 
.A1(n_114),
.A2(n_107),
.B(n_109),
.Y(n_123)
);

INVx1_ASAP7_75t_L g124 ( 
.A(n_115),
.Y(n_124)
);

AND2x2_ASAP7_75t_L g125 ( 
.A(n_112),
.B(n_103),
.Y(n_125)
);

NOR2x1_ASAP7_75t_L g126 ( 
.A(n_116),
.B(n_84),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_119),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_112),
.Y(n_128)
);

NOR2x1_ASAP7_75t_L g129 ( 
.A(n_117),
.B(n_84),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_117),
.Y(n_130)
);

AND2x2_ASAP7_75t_L g131 ( 
.A(n_111),
.B(n_103),
.Y(n_131)
);

AND2x2_ASAP7_75t_L g132 ( 
.A(n_125),
.B(n_111),
.Y(n_132)
);

AND2x2_ASAP7_75t_L g133 ( 
.A(n_125),
.B(n_111),
.Y(n_133)
);

INVxp67_ASAP7_75t_L g134 ( 
.A(n_120),
.Y(n_134)
);

AND2x2_ASAP7_75t_L g135 ( 
.A(n_121),
.B(n_111),
.Y(n_135)
);

AOI21xp33_ASAP7_75t_SL g136 ( 
.A1(n_131),
.A2(n_127),
.B(n_122),
.Y(n_136)
);

BUFx2_ASAP7_75t_L g137 ( 
.A(n_121),
.Y(n_137)
);

AND2x4_ASAP7_75t_L g138 ( 
.A(n_130),
.B(n_102),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_127),
.Y(n_139)
);

NAND2xp5_ASAP7_75t_L g140 ( 
.A(n_124),
.B(n_114),
.Y(n_140)
);

AND2x2_ASAP7_75t_L g141 ( 
.A(n_130),
.B(n_101),
.Y(n_141)
);

AOI22xp5_ASAP7_75t_L g142 ( 
.A1(n_126),
.A2(n_84),
.B1(n_110),
.B2(n_77),
.Y(n_142)
);

INVx2_ASAP7_75t_L g143 ( 
.A(n_128),
.Y(n_143)
);

AND2x2_ASAP7_75t_L g144 ( 
.A(n_123),
.B(n_131),
.Y(n_144)
);

AND2x2_ASAP7_75t_L g145 ( 
.A(n_123),
.B(n_129),
.Y(n_145)
);

AND2x2_ASAP7_75t_L g146 ( 
.A(n_123),
.B(n_102),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_121),
.Y(n_147)
);

NOR2xp33_ASAP7_75t_L g148 ( 
.A(n_122),
.B(n_73),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_139),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_139),
.Y(n_150)
);

NAND3xp33_ASAP7_75t_L g151 ( 
.A(n_148),
.B(n_90),
.C(n_95),
.Y(n_151)
);

NAND2xp33_ASAP7_75t_SL g152 ( 
.A(n_137),
.B(n_73),
.Y(n_152)
);

NAND2xp5_ASAP7_75t_L g153 ( 
.A(n_134),
.B(n_141),
.Y(n_153)
);

INVx2_ASAP7_75t_SL g154 ( 
.A(n_132),
.Y(n_154)
);

NOR2xp33_ASAP7_75t_L g155 ( 
.A(n_136),
.B(n_19),
.Y(n_155)
);

INVxp67_ASAP7_75t_L g156 ( 
.A(n_137),
.Y(n_156)
);

OAI21xp5_ASAP7_75t_SL g157 ( 
.A1(n_136),
.A2(n_81),
.B(n_75),
.Y(n_157)
);

NOR2xp33_ASAP7_75t_L g158 ( 
.A(n_140),
.B(n_144),
.Y(n_158)
);

NAND2xp5_ASAP7_75t_L g159 ( 
.A(n_141),
.B(n_19),
.Y(n_159)
);

HAxp5_ASAP7_75t_SL g160 ( 
.A(n_142),
.B(n_20),
.CON(n_160),
.SN(n_160)
);

NAND2xp5_ASAP7_75t_L g161 ( 
.A(n_147),
.B(n_20),
.Y(n_161)
);

NOR2xp33_ASAP7_75t_L g162 ( 
.A(n_140),
.B(n_21),
.Y(n_162)
);

NAND2xp5_ASAP7_75t_L g163 ( 
.A(n_147),
.B(n_21),
.Y(n_163)
);

INVxp67_ASAP7_75t_SL g164 ( 
.A(n_138),
.Y(n_164)
);

INVx1_ASAP7_75t_SL g165 ( 
.A(n_133),
.Y(n_165)
);

NOR2x1_ASAP7_75t_SL g166 ( 
.A(n_133),
.B(n_132),
.Y(n_166)
);

AOI22xp5_ASAP7_75t_L g167 ( 
.A1(n_142),
.A2(n_108),
.B1(n_96),
.B2(n_89),
.Y(n_167)
);

NAND2xp5_ASAP7_75t_SL g168 ( 
.A(n_138),
.B(n_93),
.Y(n_168)
);

AND3x1_ASAP7_75t_L g169 ( 
.A(n_157),
.B(n_144),
.C(n_145),
.Y(n_169)
);

INVxp67_ASAP7_75t_SL g170 ( 
.A(n_156),
.Y(n_170)
);

OAI22xp5_ASAP7_75t_L g171 ( 
.A1(n_155),
.A2(n_138),
.B1(n_135),
.B2(n_143),
.Y(n_171)
);

NAND2xp5_ASAP7_75t_L g172 ( 
.A(n_158),
.B(n_138),
.Y(n_172)
);

NAND2xp5_ASAP7_75t_L g173 ( 
.A(n_158),
.B(n_146),
.Y(n_173)
);

NOR2xp33_ASAP7_75t_L g174 ( 
.A(n_162),
.B(n_145),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_149),
.Y(n_175)
);

NOR2xp33_ASAP7_75t_L g176 ( 
.A(n_162),
.B(n_146),
.Y(n_176)
);

OAI21xp5_ASAP7_75t_L g177 ( 
.A1(n_155),
.A2(n_152),
.B(n_151),
.Y(n_177)
);

AOI21xp5_ASAP7_75t_L g178 ( 
.A1(n_168),
.A2(n_135),
.B(n_143),
.Y(n_178)
);

AND2x2_ASAP7_75t_L g179 ( 
.A(n_165),
.B(n_143),
.Y(n_179)
);

AND2x4_ASAP7_75t_L g180 ( 
.A(n_166),
.B(n_22),
.Y(n_180)
);

INVx2_ASAP7_75t_L g181 ( 
.A(n_150),
.Y(n_181)
);

INVx1_ASAP7_75t_L g182 ( 
.A(n_153),
.Y(n_182)
);

AOI222xp33_ASAP7_75t_L g183 ( 
.A1(n_159),
.A2(n_99),
.B1(n_96),
.B2(n_89),
.C1(n_93),
.C2(n_85),
.Y(n_183)
);

NAND2xp5_ASAP7_75t_SL g184 ( 
.A(n_164),
.B(n_81),
.Y(n_184)
);

OAI21xp5_ASAP7_75t_SL g185 ( 
.A1(n_167),
.A2(n_99),
.B(n_93),
.Y(n_185)
);

NOR2x1_ASAP7_75t_L g186 ( 
.A(n_180),
.B(n_163),
.Y(n_186)
);

INVx2_ASAP7_75t_L g187 ( 
.A(n_179),
.Y(n_187)
);

OAI211xp5_ASAP7_75t_L g188 ( 
.A1(n_177),
.A2(n_160),
.B(n_161),
.C(n_154),
.Y(n_188)
);

NAND3xp33_ASAP7_75t_L g189 ( 
.A(n_180),
.B(n_82),
.C(n_78),
.Y(n_189)
);

AO22x2_ASAP7_75t_L g190 ( 
.A1(n_182),
.A2(n_93),
.B1(n_86),
.B2(n_23),
.Y(n_190)
);

NOR2x1p5_ASAP7_75t_L g191 ( 
.A(n_173),
.B(n_24),
.Y(n_191)
);

OA22x2_ASAP7_75t_L g192 ( 
.A1(n_185),
.A2(n_26),
.B1(n_86),
.B2(n_78),
.Y(n_192)
);

NOR3xp33_ASAP7_75t_L g193 ( 
.A(n_171),
.B(n_76),
.C(n_26),
.Y(n_193)
);

NOR3x1_ASAP7_75t_L g194 ( 
.A(n_170),
.B(n_3),
.C(n_1),
.Y(n_194)
);

NOR2x1_ASAP7_75t_L g195 ( 
.A(n_184),
.B(n_82),
.Y(n_195)
);

NOR2xp33_ASAP7_75t_L g196 ( 
.A(n_174),
.B(n_6),
.Y(n_196)
);

NAND2x1p5_ASAP7_75t_L g197 ( 
.A(n_169),
.B(n_82),
.Y(n_197)
);

CKINVDCx20_ASAP7_75t_R g198 ( 
.A(n_196),
.Y(n_198)
);

OR2x2_ASAP7_75t_L g199 ( 
.A(n_187),
.B(n_172),
.Y(n_199)
);

NAND4xp75_ASAP7_75t_L g200 ( 
.A(n_194),
.B(n_174),
.C(n_176),
.D(n_178),
.Y(n_200)
);

NOR2x1p5_ASAP7_75t_L g201 ( 
.A(n_189),
.B(n_175),
.Y(n_201)
);

INVx1_ASAP7_75t_L g202 ( 
.A(n_186),
.Y(n_202)
);

NAND4xp25_ASAP7_75t_L g203 ( 
.A(n_188),
.B(n_183),
.C(n_176),
.D(n_184),
.Y(n_203)
);

AOI221x1_ASAP7_75t_L g204 ( 
.A1(n_190),
.A2(n_181),
.B1(n_72),
.B2(n_8),
.C(n_9),
.Y(n_204)
);

AOI211xp5_ASAP7_75t_SL g205 ( 
.A1(n_202),
.A2(n_193),
.B(n_191),
.C(n_192),
.Y(n_205)
);

OAI211xp5_ASAP7_75t_L g206 ( 
.A1(n_203),
.A2(n_195),
.B(n_190),
.C(n_181),
.Y(n_206)
);

AOI22xp5_ASAP7_75t_L g207 ( 
.A1(n_200),
.A2(n_197),
.B1(n_71),
.B2(n_63),
.Y(n_207)
);

AOI22xp5_ASAP7_75t_L g208 ( 
.A1(n_201),
.A2(n_71),
.B1(n_63),
.B2(n_10),
.Y(n_208)
);

XNOR2xp5_ASAP7_75t_L g209 ( 
.A(n_206),
.B(n_198),
.Y(n_209)
);

OAI22xp5_ASAP7_75t_SL g210 ( 
.A1(n_207),
.A2(n_204),
.B1(n_199),
.B2(n_11),
.Y(n_210)
);

OR2x2_ASAP7_75t_L g211 ( 
.A(n_209),
.B(n_208),
.Y(n_211)
);

AOI221xp5_ASAP7_75t_L g212 ( 
.A1(n_211),
.A2(n_210),
.B1(n_205),
.B2(n_63),
.C(n_71),
.Y(n_212)
);


endmodule