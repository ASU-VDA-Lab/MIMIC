module fake_netlist_829_1043_n_51 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_51);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_51;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_17;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

INVx2_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_11),
.B(n_9),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_5),
.B(n_10),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_8),
.B(n_15),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_17),
.B(n_0),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_17),
.B(n_1),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_20),
.B(n_1),
.Y(n_25)
);

AO31x2_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.A3(n_16),
.B(n_21),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_26),
.Y(n_29)
);

INVx1_ASAP7_75t_SL g30 ( 
.A(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_27),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_16),
.A3(n_19),
.B1(n_23),
.B2(n_22),
.C1(n_18),
.C2(n_29),
.Y(n_34)
);

O2A1O1Ixp5_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_33),
.B(n_22),
.C(n_32),
.Y(n_35)
);

XNOR2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_2),
.Y(n_36)
);

OAI21xp5_ASAP7_75t_L g37 ( 
.A1(n_31),
.A2(n_4),
.B(n_3),
.Y(n_37)
);

AND4x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_5),
.C(n_4),
.D(n_3),
.Y(n_38)
);

NAND4xp25_ASAP7_75t_SL g39 ( 
.A(n_34),
.B(n_31),
.C(n_33),
.D(n_6),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_36),
.B(n_32),
.Y(n_40)
);

NOR4xp25_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_32),
.C(n_10),
.D(n_7),
.Y(n_41)
);

AOI211xp5_ASAP7_75t_L g42 ( 
.A1(n_35),
.A2(n_32),
.B(n_11),
.C(n_7),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_12),
.Y(n_43)
);

NOR3xp33_ASAP7_75t_SL g44 ( 
.A(n_39),
.B(n_14),
.C(n_13),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_38),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_SL g46 ( 
.A(n_41),
.B(n_42),
.Y(n_46)
);

OAI22x1_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_44),
.B1(n_46),
.B2(n_43),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

INVx3_ASAP7_75t_L g49 ( 
.A(n_43),
.Y(n_49)
);

AOI21xp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_49),
.B(n_47),
.Y(n_50)
);

OR2x6_ASAP7_75t_L g51 ( 
.A(n_50),
.B(n_49),
.Y(n_51)
);


endmodule