module fake_netlist_829_1240_n_62 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_62);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_62;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

INVx2_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_14),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_17),
.B(n_11),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_6),
.B(n_2),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_7),
.B(n_19),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_18),
.B(n_16),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_21),
.B(n_5),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_3),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_10),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_31),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_31),
.B(n_16),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_30),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_24),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_27),
.B1(n_33),
.B2(n_32),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_27),
.B1(n_25),
.B2(n_24),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_35),
.A2(n_25),
.B1(n_26),
.B2(n_29),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_38),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_SL g43 ( 
.A1(n_40),
.A2(n_37),
.B(n_36),
.C(n_41),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_27),
.B1(n_28),
.B2(n_23),
.C(n_20),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_28),
.B1(n_23),
.B2(n_20),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_21),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_1),
.Y(n_49)
);

NAND2x1_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_4),
.Y(n_50)
);

XNOR2xp5_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_47),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_8),
.Y(n_53)
);

NOR2xp33_ASAP7_75t_L g54 ( 
.A(n_48),
.B(n_12),
.Y(n_54)
);

INVx2_ASAP7_75t_SL g55 ( 
.A(n_53),
.Y(n_55)
);

AND2x4_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_54),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_51),
.B(n_13),
.Y(n_57)
);

INVx1_ASAP7_75t_SL g58 ( 
.A(n_53),
.Y(n_58)
);

BUFx4f_ASAP7_75t_SL g59 ( 
.A(n_57),
.Y(n_59)
);

AOI221xp5_ASAP7_75t_R g60 ( 
.A1(n_57),
.A2(n_15),
.B1(n_58),
.B2(n_56),
.C(n_55),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

AOI222xp33_ASAP7_75t_L g62 ( 
.A1(n_59),
.A2(n_55),
.B1(n_56),
.B2(n_60),
.C1(n_61),
.C2(n_51),
.Y(n_62)
);


endmodule