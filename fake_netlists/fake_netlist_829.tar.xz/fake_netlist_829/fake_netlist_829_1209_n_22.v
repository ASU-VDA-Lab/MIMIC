module fake_netlist_829_1209_n_22 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_22);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_1),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_15),
.B(n_14),
.C(n_9),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_19),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_5),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_9),
.B1(n_11),
.B2(n_8),
.C1(n_7),
.C2(n_2),
.Y(n_22)
);


endmodule