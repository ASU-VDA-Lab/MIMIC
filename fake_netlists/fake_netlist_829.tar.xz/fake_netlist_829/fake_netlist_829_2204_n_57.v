module fake_netlist_829_2204_n_57 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_57);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_57;

wire n_48;
wire n_49;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_31;
wire n_32;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_30;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

AND2x2_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_4),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_5),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_R g32 ( 
.A(n_11),
.B(n_20),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_9),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_1),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_14),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_16),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_8),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_33),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_29),
.B(n_26),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_30),
.B(n_0),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_31),
.Y(n_42)
);

OAI22xp33_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_35),
.B1(n_37),
.B2(n_36),
.Y(n_43)
);

OAI221xp5_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_27),
.B1(n_34),
.B2(n_32),
.C(n_2),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_40),
.C(n_41),
.Y(n_45)
);

OAI222xp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_6),
.B1(n_3),
.B2(n_7),
.C1(n_12),
.C2(n_10),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_42),
.B1(n_34),
.B2(n_13),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

NAND3xp33_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_34),
.C(n_15),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_49),
.Y(n_51)
);

INVxp67_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_18),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_21),
.Y(n_54)
);

AND2x4_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_52),
.Y(n_55)
);

AND2x4_ASAP7_75t_L g56 ( 
.A(n_55),
.B(n_22),
.Y(n_56)
);

AOI22xp33_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_54),
.B1(n_24),
.B2(n_23),
.Y(n_57)
);


endmodule