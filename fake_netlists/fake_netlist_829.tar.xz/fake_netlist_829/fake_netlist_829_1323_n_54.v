module fake_netlist_829_1323_n_54 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_54);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_54;

wire n_49;
wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

AND2x4_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_21),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_6),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

NAND3xp33_ASAP7_75t_L g27 ( 
.A(n_8),
.B(n_7),
.C(n_23),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_22),
.B(n_16),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_5),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_20),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_17),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_12),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_9),
.B(n_1),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_14),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_31),
.B(n_0),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_25),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_24),
.Y(n_39)
);

OAI21x1_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_26),
.B(n_27),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_28),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_39),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_40),
.Y(n_45)
);

XNOR2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_29),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

OAI211xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_35),
.B(n_33),
.C(n_30),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_32),
.B1(n_3),
.B2(n_2),
.Y(n_50)
);

AO211x2_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_11),
.B(n_10),
.C(n_4),
.Y(n_51)
);

AND3x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_50),
.C(n_13),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);

AOI22xp33_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_51),
.B1(n_19),
.B2(n_18),
.Y(n_54)
);


endmodule