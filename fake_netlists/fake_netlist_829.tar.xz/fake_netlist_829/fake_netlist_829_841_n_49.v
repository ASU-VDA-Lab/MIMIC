module fake_netlist_829_841_n_49 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_49);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_49;

wire n_48;
wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_47;
wire n_17;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

CKINVDCx16_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_10),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_3),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_4),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_11),
.B(n_12),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_15),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_23),
.A2(n_16),
.B1(n_17),
.B2(n_20),
.C(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_16),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_26),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

NOR3xp33_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_24),
.C(n_4),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_34),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_5),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

OAI32xp33_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_24),
.A3(n_35),
.B1(n_5),
.B2(n_6),
.Y(n_41)
);

BUFx12f_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_42),
.Y(n_43)
);

NAND3xp33_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_18),
.C(n_38),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_18),
.B1(n_7),
.B2(n_6),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_18),
.B1(n_41),
.B2(n_7),
.Y(n_48)
);

AOI322xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_8),
.A3(n_13),
.B1(n_14),
.B2(n_41),
.C1(n_48),
.C2(n_46),
.Y(n_49)
);


endmodule