module fake_netlist_829_1871_n_40 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_40);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_40;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_3),
.A2(n_4),
.B(n_11),
.Y(n_19)
);

NAND2x1_ASAP7_75t_L g20 ( 
.A(n_6),
.B(n_10),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_2),
.B(n_9),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_17),
.Y(n_23)
);

INVx2_ASAP7_75t_SL g24 ( 
.A(n_7),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_13),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_24),
.B(n_10),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_23),
.B1(n_20),
.B2(n_27),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_19),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

OAI221xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_33),
.B1(n_30),
.B2(n_32),
.C(n_25),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_17),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_19),
.Y(n_36)
);

OAI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_21),
.B1(n_1),
.B2(n_0),
.Y(n_37)
);

CKINVDCx12_ASAP7_75t_R g38 ( 
.A(n_37),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

OAI321xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_12),
.A3(n_8),
.B1(n_14),
.B2(n_16),
.C(n_15),
.Y(n_40)
);


endmodule