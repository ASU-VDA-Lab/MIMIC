module fake_netlist_829_2146_n_242 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_28, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_242);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_28;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_242;

wire n_49;
wire n_132;
wire n_194;
wire n_97;
wire n_219;
wire n_221;
wire n_81;
wire n_182;
wire n_114;
wire n_130;
wire n_80;
wire n_239;
wire n_166;
wire n_123;
wire n_173;
wire n_240;
wire n_156;
wire n_222;
wire n_126;
wire n_154;
wire n_78;
wire n_153;
wire n_195;
wire n_187;
wire n_210;
wire n_87;
wire n_167;
wire n_122;
wire n_54;
wire n_96;
wire n_95;
wire n_56;
wire n_232;
wire n_59;
wire n_63;
wire n_94;
wire n_74;
wire n_64;
wire n_79;
wire n_177;
wire n_110;
wire n_61;
wire n_184;
wire n_86;
wire n_43;
wire n_45;
wire n_108;
wire n_192;
wire n_48;
wire n_162;
wire n_163;
wire n_209;
wire n_196;
wire n_230;
wire n_158;
wire n_135;
wire n_171;
wire n_47;
wire n_118;
wire n_214;
wire n_127;
wire n_202;
wire n_90;
wire n_213;
wire n_76;
wire n_189;
wire n_160;
wire n_107;
wire n_125;
wire n_99;
wire n_151;
wire n_178;
wire n_72;
wire n_121;
wire n_73;
wire n_211;
wire n_235;
wire n_37;
wire n_207;
wire n_42;
wire n_120;
wire n_155;
wire n_103;
wire n_145;
wire n_227;
wire n_200;
wire n_175;
wire n_199;
wire n_52;
wire n_185;
wire n_143;
wire n_170;
wire n_77;
wire n_161;
wire n_190;
wire n_224;
wire n_229;
wire n_138;
wire n_51;
wire n_57;
wire n_137;
wire n_136;
wire n_116;
wire n_179;
wire n_102;
wire n_217;
wire n_119;
wire n_226;
wire n_89;
wire n_152;
wire n_70;
wire n_172;
wire n_238;
wire n_131;
wire n_128;
wire n_133;
wire n_139;
wire n_142;
wire n_115;
wire n_109;
wire n_41;
wire n_62;
wire n_223;
wire n_44;
wire n_34;
wire n_40;
wire n_144;
wire n_53;
wire n_117;
wire n_84;
wire n_58;
wire n_68;
wire n_183;
wire n_146;
wire n_104;
wire n_105;
wire n_168;
wire n_225;
wire n_33;
wire n_106;
wire n_215;
wire n_149;
wire n_188;
wire n_85;
wire n_237;
wire n_205;
wire n_55;
wire n_164;
wire n_65;
wire n_159;
wire n_75;
wire n_140;
wire n_176;
wire n_67;
wire n_66;
wire n_101;
wire n_98;
wire n_91;
wire n_233;
wire n_36;
wire n_203;
wire n_204;
wire n_50;
wire n_191;
wire n_112;
wire n_129;
wire n_181;
wire n_157;
wire n_201;
wire n_198;
wire n_83;
wire n_228;
wire n_60;
wire n_39;
wire n_111;
wire n_31;
wire n_32;
wire n_169;
wire n_180;
wire n_93;
wire n_174;
wire n_216;
wire n_150;
wire n_220;
wire n_71;
wire n_208;
wire n_92;
wire n_82;
wire n_186;
wire n_100;
wire n_218;
wire n_69;
wire n_193;
wire n_234;
wire n_212;
wire n_165;
wire n_88;
wire n_29;
wire n_124;
wire n_197;
wire n_241;
wire n_113;
wire n_236;
wire n_30;
wire n_206;
wire n_147;
wire n_231;
wire n_141;
wire n_134;
wire n_35;
wire n_148;
wire n_38;
wire n_46;

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_8),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_18),
.Y(n_32)
);

CKINVDCx16_ASAP7_75t_R g33 ( 
.A(n_7),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_27),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_13),
.Y(n_36)
);

CKINVDCx16_ASAP7_75t_R g37 ( 
.A(n_9),
.Y(n_37)
);

INVxp67_ASAP7_75t_L g38 ( 
.A(n_10),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_27),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_18),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_21),
.Y(n_41)
);

CKINVDCx20_ASAP7_75t_R g42 ( 
.A(n_6),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_0),
.Y(n_43)
);

CKINVDCx16_ASAP7_75t_R g44 ( 
.A(n_20),
.Y(n_44)
);

CKINVDCx20_ASAP7_75t_R g45 ( 
.A(n_44),
.Y(n_45)
);

BUFx6f_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

INVx2_ASAP7_75t_SL g47 ( 
.A(n_43),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_31),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_31),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_36),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_42),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_33),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_37),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_36),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_35),
.Y(n_55)
);

CKINVDCx5p33_ASAP7_75t_R g56 ( 
.A(n_34),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_35),
.Y(n_57)
);

NOR2xp67_ASAP7_75t_L g58 ( 
.A(n_30),
.B(n_12),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_46),
.Y(n_59)
);

CKINVDCx5p33_ASAP7_75t_R g60 ( 
.A(n_52),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_46),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_46),
.Y(n_62)
);

AND2x4_ASAP7_75t_L g63 ( 
.A(n_47),
.B(n_39),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_46),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_55),
.Y(n_65)
);

AND2x6_ASAP7_75t_L g66 ( 
.A(n_48),
.B(n_39),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_46),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_55),
.Y(n_68)
);

NOR2xp33_ASAP7_75t_L g69 ( 
.A(n_53),
.B(n_38),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_46),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_57),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_57),
.Y(n_72)
);

NAND2xp5_ASAP7_75t_L g73 ( 
.A(n_48),
.B(n_49),
.Y(n_73)
);

NAND2xp5_ASAP7_75t_L g74 ( 
.A(n_49),
.B(n_34),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_54),
.Y(n_75)
);

BUFx10_ASAP7_75t_L g76 ( 
.A(n_60),
.Y(n_76)
);

NOR2xp33_ASAP7_75t_L g77 ( 
.A(n_74),
.B(n_50),
.Y(n_77)
);

A2O1A1Ixp33_ASAP7_75t_L g78 ( 
.A1(n_73),
.A2(n_50),
.B(n_54),
.C(n_47),
.Y(n_78)
);

AOI21xp33_ASAP7_75t_L g79 ( 
.A1(n_69),
.A2(n_56),
.B(n_29),
.Y(n_79)
);

CKINVDCx8_ASAP7_75t_R g80 ( 
.A(n_60),
.Y(n_80)
);

INVx1_ASAP7_75t_SL g81 ( 
.A(n_66),
.Y(n_81)
);

O2A1O1Ixp33_ASAP7_75t_L g82 ( 
.A1(n_65),
.A2(n_54),
.B(n_41),
.C(n_40),
.Y(n_82)
);

AND2x2_ASAP7_75t_L g83 ( 
.A(n_63),
.B(n_51),
.Y(n_83)
);

NOR2xp33_ASAP7_75t_L g84 ( 
.A(n_63),
.B(n_58),
.Y(n_84)
);

O2A1O1Ixp33_ASAP7_75t_L g85 ( 
.A1(n_68),
.A2(n_41),
.B(n_40),
.C(n_32),
.Y(n_85)
);

A2O1A1Ixp33_ASAP7_75t_L g86 ( 
.A1(n_71),
.A2(n_58),
.B(n_45),
.C(n_12),
.Y(n_86)
);

BUFx3_ASAP7_75t_L g87 ( 
.A(n_66),
.Y(n_87)
);

O2A1O1Ixp33_ASAP7_75t_L g88 ( 
.A1(n_72),
.A2(n_19),
.B(n_17),
.C(n_16),
.Y(n_88)
);

AOI21xp5_ASAP7_75t_L g89 ( 
.A1(n_75),
.A2(n_63),
.B(n_64),
.Y(n_89)
);

AOI21xp5_ASAP7_75t_L g90 ( 
.A1(n_75),
.A2(n_2),
.B(n_1),
.Y(n_90)
);

NOR2xp33_ASAP7_75t_L g91 ( 
.A(n_66),
.B(n_64),
.Y(n_91)
);

A2O1A1Ixp33_ASAP7_75t_L g92 ( 
.A1(n_67),
.A2(n_19),
.B(n_17),
.C(n_16),
.Y(n_92)
);

NOR3xp33_ASAP7_75t_SL g93 ( 
.A(n_67),
.B(n_23),
.C(n_20),
.Y(n_93)
);

O2A1O1Ixp5_ASAP7_75t_L g94 ( 
.A1(n_59),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_94)
);

AND2x2_ASAP7_75t_L g95 ( 
.A(n_66),
.B(n_23),
.Y(n_95)
);

AND2x2_ASAP7_75t_L g96 ( 
.A(n_77),
.B(n_66),
.Y(n_96)
);

AOI22xp33_ASAP7_75t_L g97 ( 
.A1(n_77),
.A2(n_66),
.B1(n_61),
.B2(n_59),
.Y(n_97)
);

INVx2_ASAP7_75t_L g98 ( 
.A(n_94),
.Y(n_98)
);

INVxp67_ASAP7_75t_SL g99 ( 
.A(n_87),
.Y(n_99)
);

AO21x2_ASAP7_75t_L g100 ( 
.A1(n_93),
.A2(n_62),
.B(n_61),
.Y(n_100)
);

INVx1_ASAP7_75t_SL g101 ( 
.A(n_87),
.Y(n_101)
);

AOI22xp33_ASAP7_75t_SL g102 ( 
.A1(n_95),
.A2(n_84),
.B1(n_83),
.B2(n_76),
.Y(n_102)
);

NOR2xp67_ASAP7_75t_L g103 ( 
.A(n_89),
.B(n_11),
.Y(n_103)
);

AOI21xp33_ASAP7_75t_L g104 ( 
.A1(n_82),
.A2(n_70),
.B(n_62),
.Y(n_104)
);

NAND2x1p5_ASAP7_75t_L g105 ( 
.A(n_81),
.B(n_70),
.Y(n_105)
);

INVx2_ASAP7_75t_L g106 ( 
.A(n_91),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_78),
.Y(n_107)
);

OAI21x1_ASAP7_75t_SL g108 ( 
.A1(n_88),
.A2(n_25),
.B(n_24),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_92),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_92),
.Y(n_110)
);

OAI21x1_ASAP7_75t_L g111 ( 
.A1(n_90),
.A2(n_15),
.B(n_14),
.Y(n_111)
);

INVx3_ASAP7_75t_L g112 ( 
.A(n_76),
.Y(n_112)
);

AO21x2_ASAP7_75t_L g113 ( 
.A1(n_86),
.A2(n_79),
.B(n_84),
.Y(n_113)
);

NOR2xp33_ASAP7_75t_L g114 ( 
.A(n_102),
.B(n_80),
.Y(n_114)
);

INVxp67_ASAP7_75t_SL g115 ( 
.A(n_99),
.Y(n_115)
);

AO31x2_ASAP7_75t_L g116 ( 
.A1(n_109),
.A2(n_91),
.A3(n_85),
.B(n_24),
.Y(n_116)
);

HB1xp67_ASAP7_75t_L g117 ( 
.A(n_101),
.Y(n_117)
);

BUFx3_ASAP7_75t_L g118 ( 
.A(n_105),
.Y(n_118)
);

OR2x2_ASAP7_75t_L g119 ( 
.A(n_112),
.B(n_25),
.Y(n_119)
);

NAND2xp5_ASAP7_75t_SL g120 ( 
.A(n_101),
.B(n_26),
.Y(n_120)
);

AND2x4_ASAP7_75t_L g121 ( 
.A(n_112),
.B(n_26),
.Y(n_121)
);

AND2x2_ASAP7_75t_L g122 ( 
.A(n_96),
.B(n_28),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_107),
.Y(n_123)
);

AND2x2_ASAP7_75t_L g124 ( 
.A(n_96),
.B(n_28),
.Y(n_124)
);

INVx2_ASAP7_75t_L g125 ( 
.A(n_98),
.Y(n_125)
);

INVx1_ASAP7_75t_L g126 ( 
.A(n_123),
.Y(n_126)
);

INVx3_ASAP7_75t_L g127 ( 
.A(n_118),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_123),
.Y(n_128)
);

OAI211xp5_ASAP7_75t_L g129 ( 
.A1(n_114),
.A2(n_102),
.B(n_110),
.C(n_109),
.Y(n_129)
);

NAND2xp33_ASAP7_75t_SL g130 ( 
.A(n_119),
.B(n_112),
.Y(n_130)
);

AOI22xp33_ASAP7_75t_L g131 ( 
.A1(n_122),
.A2(n_113),
.B1(n_108),
.B2(n_109),
.Y(n_131)
);

INVxp67_ASAP7_75t_SL g132 ( 
.A(n_115),
.Y(n_132)
);

INVx2_ASAP7_75t_L g133 ( 
.A(n_125),
.Y(n_133)
);

INVx2_ASAP7_75t_L g134 ( 
.A(n_125),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_125),
.Y(n_135)
);

NAND2xp5_ASAP7_75t_L g136 ( 
.A(n_129),
.B(n_110),
.Y(n_136)
);

OR2x2_ASAP7_75t_L g137 ( 
.A(n_132),
.B(n_119),
.Y(n_137)
);

AND2x4_ASAP7_75t_L g138 ( 
.A(n_127),
.B(n_118),
.Y(n_138)
);

AND2x4_ASAP7_75t_L g139 ( 
.A(n_127),
.B(n_118),
.Y(n_139)
);

BUFx3_ASAP7_75t_L g140 ( 
.A(n_127),
.Y(n_140)
);

NAND2xp5_ASAP7_75t_L g141 ( 
.A(n_129),
.B(n_110),
.Y(n_141)
);

NAND2xp5_ASAP7_75t_SL g142 ( 
.A(n_130),
.B(n_121),
.Y(n_142)
);

INVx2_ASAP7_75t_L g143 ( 
.A(n_133),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_126),
.Y(n_144)
);

INVx2_ASAP7_75t_SL g145 ( 
.A(n_127),
.Y(n_145)
);

AND2x2_ASAP7_75t_L g146 ( 
.A(n_135),
.B(n_122),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_144),
.Y(n_147)
);

HB1xp67_ASAP7_75t_L g148 ( 
.A(n_143),
.Y(n_148)
);

AND2x2_ASAP7_75t_L g149 ( 
.A(n_146),
.B(n_135),
.Y(n_149)
);

AO21x2_ASAP7_75t_L g150 ( 
.A1(n_136),
.A2(n_132),
.B(n_126),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_144),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_143),
.Y(n_152)
);

INVx2_ASAP7_75t_L g153 ( 
.A(n_143),
.Y(n_153)
);

NAND2x1p5_ASAP7_75t_L g154 ( 
.A(n_142),
.B(n_121),
.Y(n_154)
);

AND2x2_ASAP7_75t_L g155 ( 
.A(n_146),
.B(n_133),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_146),
.Y(n_156)
);

AND2x2_ASAP7_75t_L g157 ( 
.A(n_139),
.B(n_133),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_141),
.Y(n_158)
);

INVx1_ASAP7_75t_SL g159 ( 
.A(n_138),
.Y(n_159)
);

INVx1_ASAP7_75t_SL g160 ( 
.A(n_138),
.Y(n_160)
);

INVx1_ASAP7_75t_L g161 ( 
.A(n_141),
.Y(n_161)
);

INVx2_ASAP7_75t_L g162 ( 
.A(n_145),
.Y(n_162)
);

INVx1_ASAP7_75t_L g163 ( 
.A(n_147),
.Y(n_163)
);

A2O1A1Ixp33_ASAP7_75t_L g164 ( 
.A1(n_149),
.A2(n_121),
.B(n_137),
.C(n_131),
.Y(n_164)
);

AOI21xp5_ASAP7_75t_L g165 ( 
.A1(n_148),
.A2(n_137),
.B(n_115),
.Y(n_165)
);

AOI22xp5_ASAP7_75t_L g166 ( 
.A1(n_154),
.A2(n_121),
.B1(n_113),
.B2(n_131),
.Y(n_166)
);

OAI22xp5_ASAP7_75t_L g167 ( 
.A1(n_154),
.A2(n_145),
.B1(n_139),
.B2(n_138),
.Y(n_167)
);

O2A1O1Ixp33_ASAP7_75t_SL g168 ( 
.A1(n_159),
.A2(n_145),
.B(n_120),
.C(n_136),
.Y(n_168)
);

INVx2_ASAP7_75t_L g169 ( 
.A(n_153),
.Y(n_169)
);

OAI221xp5_ASAP7_75t_SL g170 ( 
.A1(n_156),
.A2(n_124),
.B1(n_122),
.B2(n_128),
.C(n_107),
.Y(n_170)
);

OAI22xp5_ASAP7_75t_L g171 ( 
.A1(n_154),
.A2(n_139),
.B1(n_138),
.B2(n_140),
.Y(n_171)
);

INVx2_ASAP7_75t_L g172 ( 
.A(n_153),
.Y(n_172)
);

OAI221xp5_ASAP7_75t_L g173 ( 
.A1(n_158),
.A2(n_112),
.B1(n_161),
.B2(n_128),
.C(n_107),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_147),
.Y(n_174)
);

OAI21xp5_ASAP7_75t_L g175 ( 
.A1(n_158),
.A2(n_124),
.B(n_111),
.Y(n_175)
);

INVxp67_ASAP7_75t_SL g176 ( 
.A(n_153),
.Y(n_176)
);

NAND2xp5_ASAP7_75t_L g177 ( 
.A(n_156),
.B(n_116),
.Y(n_177)
);

INVx1_ASAP7_75t_L g178 ( 
.A(n_151),
.Y(n_178)
);

OAI22xp5_ASAP7_75t_L g179 ( 
.A1(n_160),
.A2(n_139),
.B1(n_140),
.B2(n_124),
.Y(n_179)
);

AOI322xp5_ASAP7_75t_L g180 ( 
.A1(n_151),
.A2(n_108),
.A3(n_112),
.B1(n_134),
.B2(n_140),
.C1(n_117),
.C2(n_116),
.Y(n_180)
);

INVx1_ASAP7_75t_L g181 ( 
.A(n_149),
.Y(n_181)
);

OAI21xp33_ASAP7_75t_L g182 ( 
.A1(n_161),
.A2(n_162),
.B(n_157),
.Y(n_182)
);

NAND2xp5_ASAP7_75t_L g183 ( 
.A(n_155),
.B(n_116),
.Y(n_183)
);

AND2x2_ASAP7_75t_L g184 ( 
.A(n_181),
.B(n_150),
.Y(n_184)
);

NAND2xp5_ASAP7_75t_L g185 ( 
.A(n_163),
.B(n_155),
.Y(n_185)
);

AND2x2_ASAP7_75t_L g186 ( 
.A(n_174),
.B(n_178),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_176),
.Y(n_187)
);

NAND2xp5_ASAP7_75t_L g188 ( 
.A(n_177),
.B(n_152),
.Y(n_188)
);

AND2x2_ASAP7_75t_L g189 ( 
.A(n_169),
.B(n_150),
.Y(n_189)
);

AND2x2_ASAP7_75t_L g190 ( 
.A(n_169),
.B(n_150),
.Y(n_190)
);

NAND2xp5_ASAP7_75t_L g191 ( 
.A(n_183),
.B(n_152),
.Y(n_191)
);

INVx1_ASAP7_75t_L g192 ( 
.A(n_172),
.Y(n_192)
);

OR2x2_ASAP7_75t_L g193 ( 
.A(n_172),
.B(n_162),
.Y(n_193)
);

AND2x2_ASAP7_75t_L g194 ( 
.A(n_166),
.B(n_157),
.Y(n_194)
);

NAND2xp5_ASAP7_75t_L g195 ( 
.A(n_180),
.B(n_162),
.Y(n_195)
);

NAND2xp5_ASAP7_75t_SL g196 ( 
.A(n_182),
.B(n_112),
.Y(n_196)
);

INVx1_ASAP7_75t_L g197 ( 
.A(n_167),
.Y(n_197)
);

INVx1_ASAP7_75t_L g198 ( 
.A(n_171),
.Y(n_198)
);

OAI31xp33_ASAP7_75t_SL g199 ( 
.A1(n_179),
.A2(n_111),
.A3(n_134),
.B(n_108),
.Y(n_199)
);

NAND2xp5_ASAP7_75t_L g200 ( 
.A(n_165),
.B(n_116),
.Y(n_200)
);

NOR2xp33_ASAP7_75t_L g201 ( 
.A(n_170),
.B(n_113),
.Y(n_201)
);

NAND2xp5_ASAP7_75t_L g202 ( 
.A(n_164),
.B(n_173),
.Y(n_202)
);

INVxp67_ASAP7_75t_L g203 ( 
.A(n_175),
.Y(n_203)
);

INVx1_ASAP7_75t_L g204 ( 
.A(n_164),
.Y(n_204)
);

NOR3xp33_ASAP7_75t_L g205 ( 
.A(n_203),
.B(n_168),
.C(n_111),
.Y(n_205)
);

NAND2xp67_ASAP7_75t_SL g206 ( 
.A(n_184),
.B(n_168),
.Y(n_206)
);

AOI221x1_ASAP7_75t_L g207 ( 
.A1(n_195),
.A2(n_134),
.B1(n_98),
.B2(n_104),
.C(n_116),
.Y(n_207)
);

NOR2x1_ASAP7_75t_L g208 ( 
.A(n_196),
.B(n_100),
.Y(n_208)
);

INVx2_ASAP7_75t_L g209 ( 
.A(n_187),
.Y(n_209)
);

INVx1_ASAP7_75t_L g210 ( 
.A(n_186),
.Y(n_210)
);

NAND5xp2_ASAP7_75t_L g211 ( 
.A(n_199),
.B(n_201),
.C(n_202),
.D(n_204),
.E(n_198),
.Y(n_211)
);

AOI21xp33_ASAP7_75t_L g212 ( 
.A1(n_198),
.A2(n_113),
.B(n_100),
.Y(n_212)
);

A2O1A1O1Ixp25_ASAP7_75t_L g213 ( 
.A1(n_204),
.A2(n_116),
.B(n_113),
.C(n_104),
.D(n_100),
.Y(n_213)
);

AOI211xp5_ASAP7_75t_L g214 ( 
.A1(n_197),
.A2(n_103),
.B(n_111),
.C(n_117),
.Y(n_214)
);

NOR3xp33_ASAP7_75t_L g215 ( 
.A(n_197),
.B(n_103),
.C(n_96),
.Y(n_215)
);

AOI221xp5_ASAP7_75t_L g216 ( 
.A1(n_184),
.A2(n_194),
.B1(n_186),
.B2(n_191),
.C(n_200),
.Y(n_216)
);

NOR2xp33_ASAP7_75t_L g217 ( 
.A(n_185),
.B(n_100),
.Y(n_217)
);

OAI221xp5_ASAP7_75t_L g218 ( 
.A1(n_188),
.A2(n_97),
.B1(n_98),
.B2(n_106),
.C(n_99),
.Y(n_218)
);

AOI211xp5_ASAP7_75t_SL g219 ( 
.A1(n_194),
.A2(n_98),
.B(n_116),
.C(n_100),
.Y(n_219)
);

NAND3xp33_ASAP7_75t_L g220 ( 
.A(n_216),
.B(n_190),
.C(n_189),
.Y(n_220)
);

XOR2xp5_ASAP7_75t_L g221 ( 
.A(n_210),
.B(n_193),
.Y(n_221)
);

NOR3xp33_ASAP7_75t_L g222 ( 
.A(n_211),
.B(n_190),
.C(n_189),
.Y(n_222)
);

AOI22xp33_ASAP7_75t_L g223 ( 
.A1(n_215),
.A2(n_192),
.B1(n_193),
.B2(n_106),
.Y(n_223)
);

AOI22xp33_ASAP7_75t_L g224 ( 
.A1(n_215),
.A2(n_192),
.B1(n_106),
.B2(n_97),
.Y(n_224)
);

CKINVDCx5p33_ASAP7_75t_R g225 ( 
.A(n_209),
.Y(n_225)
);

AOI21xp5_ASAP7_75t_L g226 ( 
.A1(n_214),
.A2(n_105),
.B(n_106),
.Y(n_226)
);

AOI221xp5_ASAP7_75t_L g227 ( 
.A1(n_217),
.A2(n_105),
.B1(n_212),
.B2(n_205),
.C(n_218),
.Y(n_227)
);

AND2x2_ASAP7_75t_L g228 ( 
.A(n_208),
.B(n_105),
.Y(n_228)
);

CKINVDCx20_ASAP7_75t_R g229 ( 
.A(n_225),
.Y(n_229)
);

OAI22xp33_ASAP7_75t_L g230 ( 
.A1(n_220),
.A2(n_219),
.B1(n_213),
.B2(n_207),
.Y(n_230)
);

CKINVDCx5p33_ASAP7_75t_R g231 ( 
.A(n_221),
.Y(n_231)
);

HB1xp67_ASAP7_75t_L g232 ( 
.A(n_222),
.Y(n_232)
);

CKINVDCx20_ASAP7_75t_R g233 ( 
.A(n_228),
.Y(n_233)
);

BUFx2_ASAP7_75t_L g234 ( 
.A(n_227),
.Y(n_234)
);

AOI22xp5_ASAP7_75t_L g235 ( 
.A1(n_232),
.A2(n_223),
.B1(n_205),
.B2(n_224),
.Y(n_235)
);

INVx2_ASAP7_75t_L g236 ( 
.A(n_233),
.Y(n_236)
);

INVx1_ASAP7_75t_L g237 ( 
.A(n_234),
.Y(n_237)
);

AOI22xp33_ASAP7_75t_L g238 ( 
.A1(n_237),
.A2(n_230),
.B1(n_231),
.B2(n_229),
.Y(n_238)
);

CKINVDCx20_ASAP7_75t_R g239 ( 
.A(n_236),
.Y(n_239)
);

INVx1_ASAP7_75t_L g240 ( 
.A(n_239),
.Y(n_240)
);

AOI222xp33_ASAP7_75t_L g241 ( 
.A1(n_240),
.A2(n_238),
.B1(n_231),
.B2(n_224),
.C1(n_235),
.C2(n_206),
.Y(n_241)
);

AOI21xp5_ASAP7_75t_L g242 ( 
.A1(n_241),
.A2(n_226),
.B(n_105),
.Y(n_242)
);


endmodule