module fake_netlist_829_2033_n_42 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_42);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_42;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

AND2x6_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_0),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_5),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_1),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_4),
.Y(n_27)
);

INVx5_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_22),
.B(n_3),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVx2_ASAP7_75t_SL g31 ( 
.A(n_18),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_28),
.C(n_19),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_28),
.A2(n_20),
.B(n_26),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_25),
.B1(n_24),
.B2(n_23),
.Y(n_34)
);

NOR5xp2_ASAP7_75t_SL g35 ( 
.A(n_33),
.B(n_17),
.C(n_11),
.D(n_21),
.E(n_29),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_11),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_37),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_36),
.Y(n_39)
);

NOR2x1_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_27),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_30),
.Y(n_41)
);

OAI222xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_9),
.B1(n_7),
.B2(n_10),
.C1(n_16),
.C2(n_13),
.Y(n_42)
);


endmodule