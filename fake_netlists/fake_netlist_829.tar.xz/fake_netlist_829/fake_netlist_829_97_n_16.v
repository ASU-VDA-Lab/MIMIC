module fake_netlist_829_97_n_16 (n_4, n_2, n_3, n_0, n_1, n_16);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

NOR2xp33_ASAP7_75t_R g5 ( 
.A(n_2),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_R g7 ( 
.A(n_0),
.B(n_2),
.Y(n_7)
);

O2A1O1Ixp33_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_7),
.B(n_5),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_10),
.B1(n_8),
.B2(n_1),
.Y(n_12)
);

O2A1O1Ixp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_1),
.C(n_3),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_14),
.B1(n_4),
.B2(n_3),
.Y(n_16)
);


endmodule