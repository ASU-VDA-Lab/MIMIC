module fake_netlist_829_2149_n_34 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_34);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

INVx2_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_4),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_14),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_11),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_15),
.A2(n_7),
.B1(n_1),
.B2(n_0),
.Y(n_22)
);

BUFx4_ASAP7_75t_SL g23 ( 
.A(n_19),
.Y(n_23)
);

O2A1O1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_18),
.B(n_17),
.C(n_21),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

OAI211xp5_ASAP7_75t_SL g26 ( 
.A1(n_24),
.A2(n_20),
.B(n_16),
.C(n_2),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_5),
.C(n_3),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OAI21xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_16),
.B(n_6),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_12),
.B2(n_9),
.Y(n_34)
);


endmodule