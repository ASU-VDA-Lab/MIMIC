module fake_netlist_829_2558_n_22 (n_4, n_2, n_3, n_0, n_1, n_22);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

INVx4_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_0),
.B(n_4),
.Y(n_6)
);

AND2x6_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

O2A1O1Ixp33_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_10)
);

NAND2x1_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

OAI322xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.A3(n_6),
.B1(n_5),
.B2(n_10),
.C1(n_1),
.C2(n_2),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_SL g16 ( 
.A1(n_14),
.A2(n_5),
.B(n_7),
.Y(n_16)
);

NAND4xp25_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.C(n_2),
.D(n_3),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_7),
.B1(n_13),
.B2(n_12),
.C1(n_2),
.C2(n_3),
.Y(n_18)
);

AOI211x1_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_7),
.B(n_12),
.C(n_14),
.Y(n_19)
);

AO21x2_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_7),
.B(n_19),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_7),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_7),
.B(n_21),
.Y(n_22)
);


endmodule