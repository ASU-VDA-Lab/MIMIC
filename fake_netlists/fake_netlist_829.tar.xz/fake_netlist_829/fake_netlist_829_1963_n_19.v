module fake_netlist_829_1963_n_19 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_19);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

INVxp67_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_3),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

OAI221xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_5),
.B1(n_2),
.B2(n_6),
.C(n_7),
.Y(n_19)
);


endmodule