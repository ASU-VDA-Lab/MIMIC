module fake_netlist_829_2528_n_24 (n_4, n_2, n_3, n_0, n_1, n_24);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_24;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

AND3x2_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_2),
.C(n_1),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_3),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

BUFx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_SL g14 ( 
.A(n_12),
.B(n_7),
.C(n_6),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

OAI311xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_11),
.A3(n_15),
.B1(n_9),
.C1(n_14),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_15),
.C(n_10),
.Y(n_20)
);

AOI211xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_3),
.B(n_4),
.C(n_16),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_4),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_19),
.B1(n_21),
.B2(n_23),
.Y(n_24)
);


endmodule