module fake_netlist_842_112_n_40 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_40);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_40;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

INVx1_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_L g19 ( 
.A(n_1),
.B(n_7),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_15),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_6),
.B(n_16),
.Y(n_21)
);

OA21x2_ASAP7_75t_L g22 ( 
.A1(n_5),
.A2(n_14),
.B(n_4),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_8),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_13),
.B(n_1),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_19),
.B1(n_21),
.B2(n_24),
.C(n_18),
.Y(n_28)
);

BUFx3_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

AOI33xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_19),
.A3(n_22),
.B1(n_21),
.B2(n_24),
.B3(n_4),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_27),
.B1(n_22),
.B2(n_20),
.Y(n_31)
);

OR2x6_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_22),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_27),
.Y(n_34)
);

OAI221xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_23),
.B1(n_22),
.B2(n_30),
.C(n_5),
.Y(n_35)
);

AOI211xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_23),
.B(n_17),
.C(n_16),
.Y(n_36)
);

NOR2xp67_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_17),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_36),
.Y(n_38)
);

AND3x4_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_2),
.C(n_0),
.Y(n_39)
);

AOI322xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.A3(n_34),
.B1(n_11),
.B2(n_12),
.C1(n_9),
.C2(n_10),
.Y(n_40)
);


endmodule