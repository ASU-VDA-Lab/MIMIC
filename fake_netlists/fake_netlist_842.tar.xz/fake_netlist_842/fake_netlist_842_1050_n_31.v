module fake_netlist_842_1050_n_31 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_31);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_31;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

INVx1_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

NOR2xp67_ASAP7_75t_L g19 ( 
.A(n_5),
.B(n_12),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_14),
.B(n_15),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_23)
);

HB1xp67_ASAP7_75t_SL g24 ( 
.A(n_22),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

OAI222xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_24),
.B1(n_16),
.B2(n_20),
.C1(n_17),
.C2(n_3),
.Y(n_26)
);

AOI321xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_16),
.A3(n_5),
.B1(n_3),
.B2(n_6),
.C(n_4),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI32xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_26),
.A3(n_7),
.B1(n_4),
.B2(n_6),
.Y(n_29)
);

AO22x2_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_19),
.B1(n_21),
.B2(n_9),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_19),
.B2(n_13),
.Y(n_31)
);


endmodule