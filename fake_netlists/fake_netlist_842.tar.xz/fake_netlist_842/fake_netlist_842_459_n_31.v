module fake_netlist_842_459_n_31 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_31);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_31;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

INVxp67_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_1),
.B(n_7),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_5),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

NOR2x1_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_0),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_SL g18 ( 
.A(n_15),
.B(n_10),
.C(n_9),
.Y(n_18)
);

INVx6_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVx4_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx6_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_SL g22 ( 
.A1(n_20),
.A2(n_16),
.B1(n_11),
.B2(n_18),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVxp67_ASAP7_75t_SL g27 ( 
.A(n_24),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_R g28 ( 
.A(n_26),
.B(n_14),
.Y(n_28)
);

OR3x1_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_27),
.C(n_10),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

XNOR2xp5_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_8),
.Y(n_31)
);


endmodule