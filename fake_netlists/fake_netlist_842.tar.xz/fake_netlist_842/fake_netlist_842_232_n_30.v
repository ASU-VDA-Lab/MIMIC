module fake_netlist_842_232_n_30 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_30);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_7),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_3),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

NOR2xp67_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_6),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_14),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_14),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_19),
.C(n_16),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_23),
.B1(n_18),
.B2(n_17),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_4),
.B(n_2),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_27),
.B1(n_12),
.B2(n_10),
.C1(n_13),
.C2(n_11),
.Y(n_30)
);


endmodule