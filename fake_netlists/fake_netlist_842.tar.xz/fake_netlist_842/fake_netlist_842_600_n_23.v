module fake_netlist_842_600_n_23 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_23);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_5),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_3),
.B(n_8),
.C(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

O2A1O1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_4),
.A2(n_6),
.B(n_0),
.C(n_1),
.Y(n_14)
);

OAI221xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_1),
.B1(n_4),
.B2(n_9),
.C(n_10),
.Y(n_15)
);

AOI21x1_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_11),
.B(n_14),
.Y(n_16)
);

AO21x2_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_11),
.B(n_12),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_13),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

NAND4xp25_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_16),
.C(n_17),
.D(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_18),
.B2(n_17),
.Y(n_23)
);


endmodule