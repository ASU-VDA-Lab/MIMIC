module fake_netlist_842_783_n_37 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_37);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_37;

wire n_25;
wire n_20;
wire n_36;
wire n_17;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_14),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_15),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_7),
.Y(n_22)
);

XNOR2xp5_ASAP7_75t_L g23 ( 
.A(n_1),
.B(n_3),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_19),
.A2(n_5),
.B(n_2),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_SL g25 ( 
.A(n_17),
.B(n_6),
.C(n_4),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_20),
.A2(n_10),
.B(n_9),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_25),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_27),
.Y(n_30)
);

AOI221xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_22),
.B1(n_18),
.B2(n_23),
.C(n_26),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_SL g32 ( 
.A1(n_30),
.A2(n_18),
.B(n_16),
.C(n_4),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

NAND2xp33_ASAP7_75t_SL g34 ( 
.A(n_31),
.B(n_21),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_16),
.Y(n_35)
);

XNOR2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_11),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_36),
.B1(n_13),
.B2(n_12),
.Y(n_37)
);


endmodule