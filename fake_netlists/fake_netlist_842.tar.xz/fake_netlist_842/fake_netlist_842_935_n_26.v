module fake_netlist_842_935_n_26 (n_4, n_2, n_3, n_0, n_1, n_26);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_24;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_5;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_4),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_2),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_1),
.B(n_2),
.C(n_0),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_1),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

INVxp67_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_7),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_13),
.B1(n_16),
.B2(n_14),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_16),
.B1(n_12),
.B2(n_11),
.Y(n_20)
);

AND4x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_3),
.C(n_0),
.D(n_1),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_21),
.Y(n_22)
);

NOR2xp67_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_3),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_6),
.B1(n_7),
.B2(n_18),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_23),
.A2(n_6),
.B1(n_7),
.B2(n_9),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_3),
.B1(n_15),
.B2(n_25),
.Y(n_26)
);


endmodule