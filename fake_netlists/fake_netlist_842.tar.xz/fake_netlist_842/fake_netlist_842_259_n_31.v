module fake_netlist_842_259_n_31 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_31);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_31;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_27;

BUFx6f_ASAP7_75t_SL g14 ( 
.A(n_11),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_2),
.B(n_0),
.Y(n_15)
);

BUFx10_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_13),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_17),
.B(n_1),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_18),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

AOI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_22),
.B1(n_25),
.B2(n_19),
.C1(n_20),
.C2(n_15),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_7),
.C(n_6),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_12),
.B1(n_10),
.B2(n_8),
.Y(n_31)
);


endmodule