module fake_netlist_842_393_n_47 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_47);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_47;

wire n_25;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

NAND2x1p5_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_4),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

AND2x6_ASAP7_75t_L g24 ( 
.A(n_0),
.B(n_9),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_14),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_8),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_20),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_18),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_24),
.B1(n_28),
.B2(n_23),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_34),
.B(n_25),
.Y(n_35)
);

AOI322xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_31),
.A3(n_28),
.B1(n_19),
.B2(n_18),
.C1(n_29),
.C2(n_21),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_24),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_24),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NOR2x1_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_1),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AO22x2_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_7),
.B1(n_5),
.B2(n_3),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_41),
.Y(n_44)
);

AND2x4_ASAP7_75t_SL g45 ( 
.A(n_43),
.B(n_10),
.Y(n_45)
);

INVx4_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AOI322xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_12),
.A3(n_13),
.B1(n_15),
.B2(n_16),
.C1(n_43),
.C2(n_46),
.Y(n_47)
);


endmodule