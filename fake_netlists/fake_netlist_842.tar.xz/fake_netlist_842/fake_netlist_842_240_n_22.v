module fake_netlist_842_240_n_22 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_22);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

NAND2xp33_ASAP7_75t_L g11 ( 
.A(n_3),
.B(n_1),
.Y(n_11)
);

AOI21x1_ASAP7_75t_L g12 ( 
.A1(n_2),
.A2(n_6),
.B(n_4),
.Y(n_12)
);

AND3x2_ASAP7_75t_L g13 ( 
.A(n_5),
.B(n_6),
.C(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_8),
.B(n_4),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_5),
.B(n_7),
.C(n_10),
.Y(n_16)
);

OAI22xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_12),
.B1(n_10),
.B2(n_13),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NOR4xp25_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.C(n_11),
.D(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_10),
.Y(n_22)
);


endmodule