module fake_netlist_600_430_n_35 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_35);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_35;

wire n_11;
wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_33;
wire n_14;
wire n_13;
wire n_12;

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NOR2xp67_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_0),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_4),
.B(n_3),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_0),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_1),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_2),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_13),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_16),
.A2(n_10),
.B(n_11),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_18),
.Y(n_25)
);

AOI21xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_21),
.B(n_24),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_23),
.B1(n_21),
.B2(n_22),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_21),
.B1(n_23),
.B2(n_22),
.Y(n_28)
);

OAI211xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_19),
.B(n_11),
.C(n_17),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx2_ASAP7_75t_SL g31 ( 
.A(n_29),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_29),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_22),
.B1(n_15),
.B2(n_6),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_32),
.Y(n_34)
);

AOI222xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_6),
.B1(n_9),
.B2(n_30),
.C1(n_31),
.C2(n_34),
.Y(n_35)
);


endmodule