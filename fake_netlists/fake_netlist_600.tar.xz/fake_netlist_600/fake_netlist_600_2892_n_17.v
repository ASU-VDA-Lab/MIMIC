module fake_netlist_600_2892_n_17 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_17);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_17;

wire n_11;
wire n_8;
wire n_15;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_0),
.B(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_5),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_3),
.B(n_1),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_8),
.B(n_10),
.Y(n_15)
);

OAI31xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_6),
.A3(n_5),
.B(n_4),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_6),
.B2(n_7),
.C1(n_9),
.C2(n_10),
.Y(n_17)
);


endmodule