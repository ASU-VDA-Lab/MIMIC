module fake_netlist_600_1258_n_42 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_42);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_42;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_33;
wire n_41;

AND2x2_ASAP7_75t_L g19 ( 
.A(n_5),
.B(n_15),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_10),
.B(n_13),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_12),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_18),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_2),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_1),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_20),
.B(n_5),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_21),
.A2(n_17),
.B1(n_16),
.B2(n_0),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_24),
.Y(n_29)
);

A2O1A1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_26),
.A2(n_25),
.B(n_19),
.C(n_22),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_27),
.B1(n_28),
.B2(n_19),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_25),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_16),
.Y(n_33)
);

XNOR2x2_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_31),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

NOR2xp33_ASAP7_75t_R g36 ( 
.A(n_35),
.B(n_17),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

NAND2xp33_ASAP7_75t_R g38 ( 
.A(n_36),
.B(n_34),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_R g39 ( 
.A1(n_37),
.A2(n_23),
.B1(n_4),
.B2(n_3),
.Y(n_39)
);

OR3x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_7),
.C(n_6),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AOI322xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_8),
.A3(n_9),
.B1(n_11),
.B2(n_14),
.C1(n_22),
.C2(n_40),
.Y(n_42)
);


endmodule