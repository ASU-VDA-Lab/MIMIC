module fake_netlist_600_959_n_3 (n_1, n_0, n_3);

input n_1;
input n_0;

output n_3;

wire n_2;

INVx1_ASAP7_75t_L g2 ( 
.A(n_0),
.Y(n_2)
);

NOR3xp33_ASAP7_75t_L g3 ( 
.A(n_2),
.B(n_1),
.C(n_0),
.Y(n_3)
);


endmodule