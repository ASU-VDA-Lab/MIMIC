module fake_netlist_600_1418_n_5 (n_0, n_5);

input n_0;

output n_5;

wire n_4;
wire n_1;
wire n_2;
wire n_3;

INVx2_ASAP7_75t_SL g1 ( 
.A(n_0),
.Y(n_1)
);

INVx2_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

OAI21xp5_ASAP7_75t_L g3 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_3)
);

AND2x4_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

XNOR2xp5_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_3),
.Y(n_5)
);


endmodule