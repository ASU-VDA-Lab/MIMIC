module fake_netlist_600_1974_n_15 (n_0, n_4, n_1, n_2, n_3, n_15);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_15;

wire n_7;
wire n_11;
wire n_9;
wire n_8;
wire n_5;
wire n_14;
wire n_10;
wire n_13;
wire n_6;
wire n_12;

AND2x6_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_3),
.Y(n_7)
);

OAI21x1_ASAP7_75t_SL g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

A2O1A1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_10),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_11),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_3),
.B1(n_5),
.B2(n_6),
.C1(n_9),
.C2(n_8),
.Y(n_13)
);

NOR2x1_ASAP7_75t_R g14 ( 
.A(n_13),
.B(n_5),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);


endmodule