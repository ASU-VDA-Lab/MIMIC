module fake_netlist_600_1449_n_60 (n_7, n_9, n_11, n_8, n_5, n_10, n_13, n_6, n_0, n_4, n_1, n_12, n_2, n_3, n_60);

input n_7;
input n_9;
input n_11;
input n_8;
input n_5;
input n_10;
input n_13;
input n_6;
input n_0;
input n_4;
input n_1;
input n_12;
input n_2;
input n_3;

output n_60;

wire n_31;
wire n_15;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_21;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_18;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_17;
wire n_58;
wire n_52;
wire n_24;
wire n_51;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_42;
wire n_33;
wire n_14;
wire n_41;
wire n_55;

AND2x2_ASAP7_75t_L g14 ( 
.A(n_5),
.B(n_7),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_3),
.B(n_5),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_7),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_4),
.B(n_11),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_12),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_18),
.B(n_0),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_14),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_16),
.B(n_1),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_15),
.B(n_25),
.Y(n_31)
);

INVx6_ASAP7_75t_L g32 ( 
.A(n_17),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_19),
.B(n_4),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_17),
.Y(n_34)
);

CKINVDCx11_ASAP7_75t_R g35 ( 
.A(n_15),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_31),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_21),
.B(n_24),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_31),
.Y(n_38)
);

OAI21xp5_ASAP7_75t_L g39 ( 
.A1(n_27),
.A2(n_23),
.B(n_18),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_28),
.Y(n_40)
);

INVx4_ASAP7_75t_L g41 ( 
.A(n_32),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_36),
.A2(n_29),
.B1(n_31),
.B2(n_33),
.C(n_34),
.Y(n_44)
);

OAI221xp5_ASAP7_75t_L g45 ( 
.A1(n_38),
.A2(n_22),
.B1(n_27),
.B2(n_32),
.C(n_25),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_31),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_30),
.Y(n_47)
);

NAND5xp2_ASAP7_75t_SL g48 ( 
.A(n_44),
.B(n_35),
.C(n_37),
.D(n_39),
.E(n_6),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_R g50 ( 
.A(n_48),
.B(n_27),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

NOR2xp67_ASAP7_75t_L g52 ( 
.A(n_51),
.B(n_30),
.Y(n_52)
);

NOR4xp25_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_26),
.C(n_21),
.D(n_20),
.Y(n_53)
);

NAND4xp75_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_23),
.C(n_43),
.D(n_32),
.Y(n_54)
);

OR2x2_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_30),
.Y(n_55)
);

OAI322xp33_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_41),
.A3(n_6),
.B1(n_32),
.B2(n_50),
.C1(n_30),
.C2(n_10),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

INVx1_ASAP7_75t_SL g58 ( 
.A(n_57),
.Y(n_58)
);

CKINVDCx20_ASAP7_75t_R g59 ( 
.A(n_55),
.Y(n_59)
);

OAI21xp5_ASAP7_75t_L g60 ( 
.A1(n_58),
.A2(n_56),
.B(n_59),
.Y(n_60)
);


endmodule