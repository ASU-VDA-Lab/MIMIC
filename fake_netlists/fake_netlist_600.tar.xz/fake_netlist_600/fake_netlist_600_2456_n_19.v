module fake_netlist_600_2456_n_19 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_19);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_19;

wire n_11;
wire n_15;
wire n_18;
wire n_17;
wire n_10;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

BUFx2_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_4),
.Y(n_11)
);

XOR2xp5_ASAP7_75t_L g12 ( 
.A(n_4),
.B(n_5),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_1),
.B(n_2),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B1(n_13),
.B2(n_12),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B(n_3),
.Y(n_16)
);

OAI22xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_6),
.Y(n_18)
);

OAI21xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_7),
.B(n_9),
.Y(n_19)
);


endmodule