module fake_netlist_600_2742_n_20 (n_0, n_4, n_1, n_2, n_3, n_20);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_20;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_7;
wire n_19;
wire n_10;
wire n_16;
wire n_5;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

AND2x2_ASAP7_75t_SL g5 ( 
.A(n_1),
.B(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_SL g6 ( 
.A(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

AND2x2_ASAP7_75t_SL g8 ( 
.A(n_2),
.B(n_4),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx8_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_6),
.Y(n_12)
);

NOR2x1_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_5),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_11),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_15),
.B(n_11),
.Y(n_16)
);

AOI211xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_10),
.B(n_5),
.C(n_8),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_8),
.B1(n_1),
.B2(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_SL g19 ( 
.A(n_16),
.Y(n_19)
);

AOI222xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_0),
.B1(n_2),
.B2(n_4),
.C1(n_8),
.C2(n_19),
.Y(n_20)
);


endmodule