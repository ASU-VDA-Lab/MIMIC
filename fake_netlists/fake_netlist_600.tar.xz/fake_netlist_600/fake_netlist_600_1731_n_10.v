module fake_netlist_600_1731_n_10 (n_0, n_4, n_1, n_2, n_3, n_10);

input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_10;

wire n_7;
wire n_9;
wire n_8;
wire n_5;
wire n_6;

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI22xp33_ASAP7_75t_L g6 ( 
.A1(n_0),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_6)
);

INVxp67_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule