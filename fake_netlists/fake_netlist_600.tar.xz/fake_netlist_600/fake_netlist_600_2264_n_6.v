module fake_netlist_600_2264_n_6 (n_1, n_0, n_6);

input n_1;
input n_0;

output n_6;

wire n_5;
wire n_4;
wire n_2;
wire n_3;

BUFx6f_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVx1_ASAP7_75t_SL g3 ( 
.A(n_2),
.Y(n_3)
);

AOI21xp33_ASAP7_75t_SL g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);


endmodule