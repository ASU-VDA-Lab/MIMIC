module fake_netlist_840_4090_n_62 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_62);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_62;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_23;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

AOI22x1_ASAP7_75t_SL g19 ( 
.A1(n_14),
.A2(n_4),
.B1(n_1),
.B2(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_3),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_11),
.B(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_3),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_10),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_12),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_25),
.B(n_0),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_20),
.A2(n_7),
.B(n_6),
.Y(n_31)
);

NAND2x1p5_ASAP7_75t_L g32 ( 
.A(n_25),
.B(n_0),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_1),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

AOI21xp33_ASAP7_75t_SL g35 ( 
.A1(n_33),
.A2(n_24),
.B(n_21),
.Y(n_35)
);

OAI222xp33_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_19),
.B1(n_21),
.B2(n_22),
.C1(n_33),
.C2(n_30),
.Y(n_36)
);

AOI211xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_22),
.B(n_27),
.C(n_26),
.Y(n_37)
);

INVxp33_ASAP7_75t_SL g38 ( 
.A(n_29),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_35),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_32),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_25),
.B1(n_26),
.B2(n_20),
.Y(n_46)
);

INVx1_ASAP7_75t_SL g47 ( 
.A(n_44),
.Y(n_47)
);

OAI21xp5_ASAP7_75t_SL g48 ( 
.A1(n_43),
.A2(n_36),
.B(n_19),
.Y(n_48)
);

A2O1A1Ixp33_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_31),
.B(n_26),
.C(n_28),
.Y(n_49)
);

AOI21xp5_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_28),
.B(n_26),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_46),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_47),
.Y(n_53)
);

NAND3xp33_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_23),
.C(n_5),
.Y(n_54)
);

NAND3xp33_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_10),
.C(n_5),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_16),
.Y(n_56)
);

XNOR2xp5_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_16),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_52),
.B1(n_18),
.B2(n_17),
.Y(n_58)
);

HB1xp67_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

AOI22xp5_ASAP7_75t_L g60 ( 
.A1(n_58),
.A2(n_54),
.B1(n_18),
.B2(n_13),
.Y(n_60)
);

INVxp67_ASAP7_75t_SL g61 ( 
.A(n_59),
.Y(n_61)
);

OAI31xp33_ASAP7_75t_SL g62 ( 
.A1(n_61),
.A2(n_15),
.A3(n_57),
.B(n_60),
.Y(n_62)
);


endmodule