module fake_netlist_840_2226_n_34 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_34);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_27;

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_1),
.B(n_16),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

AOI21x1_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_23),
.B(n_22),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_25),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_26),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_SL g30 ( 
.A(n_29),
.B(n_21),
.C(n_19),
.Y(n_30)
);

OAI322xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_18),
.A3(n_17),
.B1(n_16),
.B2(n_2),
.C1(n_0),
.C2(n_3),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_17),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_4),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_8),
.A3(n_5),
.B1(n_14),
.B2(n_15),
.C1(n_9),
.C2(n_10),
.Y(n_34)
);


endmodule