module fake_netlist_840_4226_n_37 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_37);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_37;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_11;
wire n_27;

INVx2_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

INVxp67_ASAP7_75t_SL g12 ( 
.A(n_6),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_7),
.B(n_2),
.Y(n_13)
);

BUFx6f_ASAP7_75t_SL g14 ( 
.A(n_3),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

CKINVDCx6p67_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

AO22x2_ASAP7_75t_L g20 ( 
.A1(n_12),
.A2(n_5),
.B1(n_4),
.B2(n_0),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_15),
.A2(n_9),
.B(n_0),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_5),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_17),
.A2(n_6),
.B(n_18),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_12),
.Y(n_28)
);

OR2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_24),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_20),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_20),
.B1(n_27),
.B2(n_19),
.C1(n_23),
.C2(n_13),
.Y(n_32)
);

OA211x2_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_20),
.B(n_14),
.C(n_25),
.Y(n_33)
);

NOR2xp67_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_21),
.Y(n_34)
);

OAI21xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_31),
.B(n_25),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_14),
.B(n_36),
.Y(n_37)
);


endmodule