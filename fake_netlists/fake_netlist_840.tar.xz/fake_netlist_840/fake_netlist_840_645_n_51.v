module fake_netlist_840_645_n_51 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_51);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_51;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

INVx2_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

NAND2x1_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_8),
.Y(n_26)
);

XOR2xp5_ASAP7_75t_L g27 ( 
.A(n_3),
.B(n_14),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_7),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_9),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_2),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_25),
.B(n_16),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_23),
.B(n_16),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_24),
.B(n_26),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_18),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_32),
.B1(n_34),
.B2(n_33),
.Y(n_40)
);

NAND3xp33_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_28),
.C(n_31),
.Y(n_41)
);

OAI22xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_38),
.B1(n_27),
.B2(n_28),
.Y(n_42)
);

NAND2xp33_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_38),
.Y(n_43)
);

O2A1O1Ixp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_38),
.B(n_43),
.C(n_28),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_43),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_18),
.Y(n_46)
);

OA21x2_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_38),
.B(n_4),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

OA22x2_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_19),
.B1(n_11),
.B2(n_10),
.Y(n_49)
);

OAI21xp5_ASAP7_75t_SL g50 ( 
.A1(n_48),
.A2(n_19),
.B(n_12),
.Y(n_50)
);

OA331x2_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_49),
.A3(n_20),
.B1(n_15),
.B2(n_13),
.B3(n_22),
.C1(n_21),
.Y(n_51)
);


endmodule