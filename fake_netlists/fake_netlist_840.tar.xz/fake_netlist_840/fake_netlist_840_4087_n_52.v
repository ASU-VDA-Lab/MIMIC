module fake_netlist_840_4087_n_52 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_52);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_52;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_11),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_14),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_15),
.B(n_13),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_10),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_17),
.Y(n_31)
);

INVx3_ASAP7_75t_L g32 ( 
.A(n_7),
.Y(n_32)
);

INVxp33_ASAP7_75t_SL g33 ( 
.A(n_4),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_SL g34 ( 
.A(n_26),
.B(n_24),
.C(n_0),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_27),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_28),
.B1(n_25),
.B2(n_30),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

NAND2x1p5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_31),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_36),
.Y(n_40)
);

OAI31xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_32),
.A3(n_29),
.B(n_34),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_32),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_24),
.C(n_1),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_3),
.B(n_2),
.Y(n_44)
);

AOI21xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_8),
.B(n_6),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_16),
.B1(n_12),
.B2(n_9),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

NOR2x1_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_18),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_20),
.B(n_19),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_49),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_21),
.B1(n_23),
.B2(n_50),
.Y(n_52)
);


endmodule