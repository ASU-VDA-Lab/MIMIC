module fake_netlist_840_2139_n_26 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_26);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_6),
.B(n_10),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_5),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_11),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

AOI221x1_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_4),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_13),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_20),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_16),
.B1(n_12),
.B2(n_14),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_9),
.B(n_8),
.C(n_7),
.Y(n_26)
);


endmodule