module fake_netlist_840_2193_n_16 (n_4, n_2, n_3, n_0, n_1, n_16);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_2),
.Y(n_6)
);

INVx5_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

AO31x2_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_8)
);

OAI21xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_0),
.B(n_7),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_SL g12 ( 
.A(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_SL g14 ( 
.A(n_13),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_R g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_8),
.B2(n_7),
.Y(n_16)
);


endmodule