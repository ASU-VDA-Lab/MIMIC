module fake_netlist_840_2250_n_13 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_13);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_13;

wire n_10;
wire n_7;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_0),
.B1(n_5),
.B2(n_2),
.Y(n_7)
);

OAI22xp5_ASAP7_75t_L g8 ( 
.A1(n_1),
.A2(n_2),
.B1(n_3),
.B2(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_3),
.B(n_6),
.Y(n_9)
);

NAND4xp25_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_6),
.C(n_1),
.D(n_0),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_7),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_5),
.B2(n_4),
.Y(n_12)
);

XOR2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);


endmodule