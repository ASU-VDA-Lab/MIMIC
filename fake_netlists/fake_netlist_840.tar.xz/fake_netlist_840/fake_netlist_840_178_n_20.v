module fake_netlist_840_178_n_20 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_20);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

NOR2x1p5_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_9),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_2),
.B(n_5),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_5),
.B(n_4),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI211xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B(n_13),
.C(n_14),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.C(n_10),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_6),
.B(n_4),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_R g20 ( 
.A1(n_19),
.A2(n_6),
.B1(n_7),
.B2(n_13),
.Y(n_20)
);


endmodule