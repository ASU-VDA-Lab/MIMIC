module fake_netlist_840_114_n_64 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_64);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_64;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_53;
wire n_23;
wire n_31;
wire n_32;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_14),
.B(n_4),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_18),
.A2(n_11),
.B1(n_16),
.B2(n_2),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_6),
.B(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_1),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_19),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_0),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_17),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_18),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_27),
.A2(n_20),
.B1(n_17),
.B2(n_3),
.Y(n_36)
);

AO22x1_ASAP7_75t_L g37 ( 
.A1(n_26),
.A2(n_22),
.B1(n_21),
.B2(n_5),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

NAND2xp33_ASAP7_75t_L g39 ( 
.A(n_34),
.B(n_8),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_34),
.A2(n_22),
.B1(n_21),
.B2(n_9),
.Y(n_40)
);

OAI21x1_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_29),
.B(n_28),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI21xp5_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_26),
.B(n_29),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_35),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_31),
.Y(n_45)
);

BUFx6f_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_42),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_43),
.Y(n_49)
);

NOR3xp33_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_36),
.C(n_37),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_46),
.B1(n_40),
.B2(n_26),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

AOI221xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_48),
.B1(n_33),
.B2(n_24),
.C(n_25),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_49),
.B1(n_46),
.B2(n_24),
.Y(n_54)
);

OAI22xp5_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_46),
.B1(n_33),
.B2(n_25),
.Y(n_55)
);

AOI21xp5_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_26),
.B(n_32),
.Y(n_56)
);

NOR4xp25_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_30),
.C(n_32),
.D(n_23),
.Y(n_57)
);

NAND2x1p5_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_32),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

AND3x4_ASAP7_75t_L g60 ( 
.A(n_54),
.B(n_30),
.C(n_32),
.Y(n_60)
);

OAI221xp5_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_23),
.B1(n_13),
.B2(n_10),
.C(n_12),
.Y(n_61)
);

OAI22x1_ASAP7_75t_L g62 ( 
.A1(n_60),
.A2(n_15),
.B1(n_23),
.B2(n_59),
.Y(n_62)
);

OAI21x1_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_58),
.B(n_61),
.Y(n_63)
);

OAI221xp5_ASAP7_75t_R g64 ( 
.A1(n_63),
.A2(n_23),
.B1(n_36),
.B2(n_40),
.C(n_50),
.Y(n_64)
);


endmodule