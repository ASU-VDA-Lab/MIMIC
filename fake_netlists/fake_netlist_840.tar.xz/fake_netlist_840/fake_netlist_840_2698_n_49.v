module fake_netlist_840_2698_n_49 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_49);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_49;

wire n_48;
wire n_25;
wire n_36;
wire n_47;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_44;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

AND2x2_ASAP7_75t_L g22 ( 
.A(n_12),
.B(n_0),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_9),
.B(n_20),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_SL g28 ( 
.A(n_13),
.B(n_21),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

NAND2x1_ASAP7_75t_L g30 ( 
.A(n_1),
.B(n_11),
.Y(n_30)
);

NOR2xp67_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_16),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_19),
.B1(n_18),
.B2(n_16),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_18),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_23),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_19),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_22),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_34),
.Y(n_37)
);

OAI22xp33_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_32),
.B1(n_33),
.B2(n_28),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_30),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_28),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_24),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_24),
.Y(n_43)
);

OAI211xp5_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_25),
.B(n_24),
.C(n_2),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_3),
.Y(n_45)
);

OAI21x1_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_7),
.B(n_5),
.Y(n_46)
);

INVxp67_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_8),
.B1(n_17),
.B2(n_48),
.Y(n_49)
);


endmodule