module fake_netlist_875_2634_n_16 (n_0, n_1, n_2, n_16);

input n_0;
input n_1;
input n_2;

output n_16;

wire n_5;
wire n_3;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx4_ASAP7_75t_SL g5 ( 
.A(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_0),
.B(n_1),
.Y(n_6)
);

OAI221xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.B1(n_8),
.B2(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_11),
.B(n_7),
.C(n_6),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_1),
.B(n_2),
.C(n_0),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_1),
.C(n_2),
.Y(n_14)
);

AO22x2_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_15)
);

OAI33xp33_ASAP7_75t_R g16 ( 
.A1(n_15),
.A2(n_0),
.A3(n_2),
.B1(n_12),
.B2(n_14),
.B3(n_13),
.Y(n_16)
);


endmodule