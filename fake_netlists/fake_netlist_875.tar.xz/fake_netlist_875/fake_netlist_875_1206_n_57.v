module fake_netlist_875_1206_n_57 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_57);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_57;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_19;
wire n_27;
wire n_49;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_31;
wire n_21;
wire n_22;
wire n_35;
wire n_32;
wire n_42;
wire n_25;
wire n_41;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;
wire n_56;

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_12),
.B(n_15),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_0),
.B(n_3),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_L g27 ( 
.A1(n_19),
.A2(n_13),
.B(n_14),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

BUFx8_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_18),
.B(n_17),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_SL g32 ( 
.A1(n_27),
.A2(n_20),
.B(n_23),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_20),
.B1(n_22),
.B2(n_19),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_31),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_30),
.Y(n_37)
);

NAND2x1p5_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_30),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_SL g39 ( 
.A(n_35),
.B(n_22),
.C(n_32),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_29),
.B1(n_37),
.B2(n_24),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_38),
.B(n_36),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_29),
.B1(n_25),
.B2(n_24),
.Y(n_45)
);

AOI21xp33_ASAP7_75t_SL g46 ( 
.A1(n_43),
.A2(n_12),
.B(n_10),
.Y(n_46)
);

A2O1A1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_41),
.A2(n_18),
.B(n_28),
.C(n_29),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_SL g48 ( 
.A1(n_42),
.A2(n_44),
.B(n_41),
.Y(n_48)
);

NOR4xp75_ASAP7_75t_SL g49 ( 
.A(n_46),
.B(n_14),
.C(n_10),
.D(n_11),
.Y(n_49)
);

AOI211xp5_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_18),
.B(n_33),
.C(n_15),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_48),
.Y(n_51)
);

OR2x2_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_33),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_16),
.B1(n_9),
.B2(n_8),
.Y(n_54)
);

OAI221xp5_ASAP7_75t_L g55 ( 
.A1(n_49),
.A2(n_16),
.B1(n_9),
.B2(n_8),
.C(n_17),
.Y(n_55)
);

OAI22xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_54),
.B1(n_51),
.B2(n_53),
.Y(n_56)
);

AOI21xp33_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_1),
.B(n_5),
.Y(n_57)
);


endmodule