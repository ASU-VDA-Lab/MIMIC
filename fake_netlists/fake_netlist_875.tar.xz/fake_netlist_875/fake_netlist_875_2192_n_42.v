module fake_netlist_875_2192_n_42 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_42);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_42;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_14;
wire n_35;
wire n_13;
wire n_41;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_17),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

BUFx2_ASAP7_75t_SL g23 ( 
.A(n_19),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_11),
.B1(n_14),
.B2(n_16),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_18),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_16),
.B1(n_18),
.B2(n_26),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_26),
.C(n_20),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_18),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

NOR4xp25_ASAP7_75t_SL g34 ( 
.A(n_31),
.B(n_29),
.C(n_27),
.D(n_15),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_29),
.B1(n_33),
.B2(n_34),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

NOR2x1p5_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_13),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AOI322xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_40),
.A3(n_8),
.B1(n_9),
.B2(n_6),
.C1(n_4),
.C2(n_0),
.Y(n_42)
);


endmodule