module fake_netlist_875_3013_n_59 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_59);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_59;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_19;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_42;
wire n_41;
wire n_57;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;
wire n_56;

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_4),
.B(n_2),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_12),
.B(n_7),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_17),
.B(n_5),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_15),
.B(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_15),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_17),
.Y(n_30)
);

INVx4_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_24),
.B(n_26),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_7),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_27),
.Y(n_34)
);

AOI21xp33_ASAP7_75t_SL g35 ( 
.A1(n_29),
.A2(n_26),
.B(n_20),
.Y(n_35)
);

OAI211xp5_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_34),
.B(n_30),
.C(n_33),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_21),
.B1(n_23),
.B2(n_19),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_32),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_31),
.B1(n_22),
.B2(n_19),
.Y(n_39)
);

OAI21x1_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_25),
.B(n_23),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_35),
.B(n_31),
.Y(n_41)
);

INVxp67_ASAP7_75t_SL g42 ( 
.A(n_36),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_35),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_34),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_31),
.Y(n_45)
);

NOR3xp33_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_44),
.C(n_25),
.Y(n_46)
);

INVx2_ASAP7_75t_SL g47 ( 
.A(n_45),
.Y(n_47)
);

BUFx6f_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_43),
.B(n_40),
.Y(n_49)
);

XNOR2xp5_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_40),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_13),
.Y(n_51)
);

AOI221xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_47),
.B1(n_49),
.B2(n_18),
.C(n_14),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_14),
.Y(n_53)
);

CKINVDCx5p33_ASAP7_75t_R g54 ( 
.A(n_51),
.Y(n_54)
);

BUFx2_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

CKINVDCx5p33_ASAP7_75t_R g56 ( 
.A(n_50),
.Y(n_56)
);

AND2x4_ASAP7_75t_SL g57 ( 
.A(n_52),
.B(n_11),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_54),
.B1(n_57),
.B2(n_55),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_13),
.B1(n_9),
.B2(n_8),
.Y(n_59)
);


endmodule