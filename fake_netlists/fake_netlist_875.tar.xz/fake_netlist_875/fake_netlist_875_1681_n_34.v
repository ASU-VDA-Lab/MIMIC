module fake_netlist_875_1681_n_34 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_34);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_34;

wire n_33;
wire n_15;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_32;
wire n_26;
wire n_29;

INVx1_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_4),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_1),
.B1(n_5),
.B2(n_3),
.Y(n_17)
);

XNOR2xp5_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_1),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx11_ASAP7_75t_R g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_15),
.B1(n_16),
.B2(n_14),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_20),
.Y(n_24)
);

NAND2x1p5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_15),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_15),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

OAI211xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_24),
.B(n_16),
.C(n_2),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_27),
.B(n_11),
.Y(n_29)
);

AOI211xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_2),
.B(n_3),
.C(n_0),
.Y(n_30)
);

INVx5_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_28),
.B(n_0),
.Y(n_32)
);

XOR2xp5_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_6),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_30),
.B1(n_31),
.B2(n_10),
.Y(n_34)
);


endmodule