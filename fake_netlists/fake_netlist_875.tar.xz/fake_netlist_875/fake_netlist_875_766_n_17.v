module fake_netlist_875_766_n_17 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_17);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_17;

wire n_15;
wire n_11;
wire n_10;
wire n_13;
wire n_16;
wire n_12;
wire n_14;

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_1),
.A2(n_3),
.B1(n_6),
.B2(n_7),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_1),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_5),
.B(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_0),
.B1(n_10),
.B2(n_13),
.C1(n_11),
.C2(n_2),
.Y(n_17)
);


endmodule