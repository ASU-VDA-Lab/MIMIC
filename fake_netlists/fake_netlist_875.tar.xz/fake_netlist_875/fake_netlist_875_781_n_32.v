module fake_netlist_875_781_n_32 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_32);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_32;

wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_22;
wire n_25;
wire n_26;
wire n_29;

AND2x2_ASAP7_75t_L g16 ( 
.A(n_2),
.B(n_12),
.Y(n_16)
);

INVx4_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_16),
.A2(n_11),
.B1(n_8),
.B2(n_9),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_23),
.B1(n_20),
.B2(n_19),
.C(n_18),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_17),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_13),
.Y(n_27)
);

NAND3x1_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_7),
.C(n_5),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_14),
.B(n_3),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_28),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);


endmodule