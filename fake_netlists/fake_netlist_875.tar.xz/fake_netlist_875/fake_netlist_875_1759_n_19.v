module fake_netlist_875_1759_n_19 (n_0, n_2, n_3, n_4, n_1, n_19);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_19;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_12;
wire n_5;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

NAND3xp33_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_2),
.C(n_3),
.Y(n_6)
);

INVxp67_ASAP7_75t_SL g7 ( 
.A(n_5),
.Y(n_7)
);

OA21x2_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_0),
.B(n_1),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_5),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_5),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_8),
.Y(n_11)
);

NAND2x1_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_8),
.Y(n_12)
);

AOI211xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_10),
.B(n_8),
.C(n_0),
.Y(n_13)
);

OAI311xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_8),
.A3(n_4),
.B1(n_3),
.C1(n_2),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_13),
.Y(n_16)
);

AOI22x1_ASAP7_75t_SL g17 ( 
.A1(n_15),
.A2(n_14),
.B1(n_2),
.B2(n_4),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_16),
.B1(n_4),
.B2(n_1),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_0),
.B1(n_1),
.B2(n_18),
.Y(n_19)
);


endmodule