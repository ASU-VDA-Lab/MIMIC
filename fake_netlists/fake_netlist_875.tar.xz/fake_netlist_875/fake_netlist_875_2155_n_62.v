module fake_netlist_875_2155_n_62 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_62);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_62;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_41;
wire n_42;
wire n_57;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_48;
wire n_45;
wire n_38;
wire n_56;

INVx1_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

AND2x6_ASAP7_75t_L g21 ( 
.A(n_7),
.B(n_16),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_8),
.B(n_18),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_17),
.Y(n_25)
);

AND2x6_ASAP7_75t_L g26 ( 
.A(n_6),
.B(n_9),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_18),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

INVx4_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_20),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_22),
.A2(n_11),
.B(n_5),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_25),
.A2(n_24),
.B1(n_26),
.B2(n_21),
.Y(n_34)
);

OAI21x1_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_28),
.B(n_26),
.Y(n_35)
);

OAI21xp5_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_24),
.B(n_26),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_30),
.A2(n_29),
.B(n_23),
.Y(n_37)
);

OA21x2_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_25),
.B(n_29),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_30),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_38),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_38),
.Y(n_44)
);

OAI21xp33_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_23),
.B(n_29),
.Y(n_45)
);

NAND2x1_ASAP7_75t_SL g46 ( 
.A(n_42),
.B(n_38),
.Y(n_46)
);

NAND2x1p5_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_38),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_44),
.B1(n_29),
.B2(n_23),
.Y(n_49)
);

NAND3xp33_ASAP7_75t_SL g50 ( 
.A(n_45),
.B(n_47),
.C(n_33),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_SL g52 ( 
.A1(n_45),
.A2(n_21),
.B1(n_26),
.B2(n_30),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_9),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_49),
.A2(n_50),
.B1(n_52),
.B2(n_26),
.Y(n_54)
);

NOR3xp33_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_37),
.C(n_21),
.Y(n_55)
);

NAND5xp2_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_21),
.C(n_15),
.D(n_13),
.E(n_14),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_21),
.Y(n_57)
);

AOI21xp5_ASAP7_75t_L g58 ( 
.A1(n_54),
.A2(n_10),
.B(n_4),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

OAI31xp33_ASAP7_75t_L g60 ( 
.A1(n_56),
.A2(n_16),
.A3(n_13),
.B(n_19),
.Y(n_60)
);

A2O1A1Ixp33_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_3),
.B(n_12),
.C(n_1),
.Y(n_61)
);

AOI22xp33_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_57),
.B1(n_59),
.B2(n_58),
.Y(n_62)
);


endmodule