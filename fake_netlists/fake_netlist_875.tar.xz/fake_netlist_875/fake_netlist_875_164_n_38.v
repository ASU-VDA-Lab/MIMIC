module fake_netlist_875_164_n_38 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_38);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_38;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_22;
wire n_25;
wire n_32;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_0),
.B(n_14),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_13),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_13),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B1(n_22),
.B2(n_23),
.C(n_19),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_29),
.Y(n_30)
);

OAI211xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_27),
.B(n_28),
.C(n_21),
.Y(n_31)
);

AOI32xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_21),
.A3(n_20),
.B1(n_17),
.B2(n_14),
.Y(n_32)
);

OAI21xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_31),
.B(n_10),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_2),
.B(n_1),
.Y(n_34)
);

OA22x2_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_35)
);

AOI211xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_12),
.B(n_11),
.C(n_8),
.Y(n_36)
);

INVxp67_ASAP7_75t_SL g37 ( 
.A(n_36),
.Y(n_37)
);

AOI322xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_35),
.A3(n_8),
.B1(n_15),
.B2(n_4),
.C1(n_5),
.C2(n_3),
.Y(n_38)
);


endmodule