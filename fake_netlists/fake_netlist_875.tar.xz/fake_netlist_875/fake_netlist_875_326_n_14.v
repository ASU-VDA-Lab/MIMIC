module fake_netlist_875_326_n_14 (n_0, n_1, n_3, n_2, n_14);

input n_0;
input n_1;
input n_3;
input n_2;

output n_14;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

INVx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

AOI21x1_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B(n_2),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx4_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

NAND4xp25_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_5),
.C(n_4),
.D(n_2),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_5),
.B1(n_4),
.B2(n_9),
.C(n_6),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_9),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_9),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_0),
.B1(n_3),
.B2(n_4),
.C1(n_11),
.C2(n_5),
.Y(n_14)
);


endmodule