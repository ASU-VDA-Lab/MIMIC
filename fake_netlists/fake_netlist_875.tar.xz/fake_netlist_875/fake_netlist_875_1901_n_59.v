module fake_netlist_875_1901_n_59 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_59);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_59;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_22;
wire n_32;
wire n_35;
wire n_41;
wire n_42;
wire n_25;
wire n_57;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_45;
wire n_44;
wire n_48;
wire n_38;
wire n_56;

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_0),
.B(n_10),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_2),
.A2(n_10),
.B1(n_12),
.B2(n_1),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_16),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_8),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_11),
.A2(n_0),
.B1(n_14),
.B2(n_15),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_4),
.B(n_14),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_3),
.B(n_6),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_7),
.Y(n_29)
);

AND3x1_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_17),
.C(n_15),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_23),
.B(n_13),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_22),
.A2(n_29),
.B1(n_20),
.B2(n_24),
.Y(n_32)
);

OR2x6_ASAP7_75t_L g33 ( 
.A(n_21),
.B(n_19),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_22),
.B(n_17),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

OAI21xp5_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_27),
.B(n_26),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_26),
.B(n_22),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_27),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_31),
.Y(n_39)
);

BUFx3_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NOR2x1_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_35),
.Y(n_41)
);

O2A1O1Ixp33_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_36),
.B(n_20),
.C(n_33),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_36),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_39),
.B1(n_38),
.B2(n_40),
.Y(n_44)
);

NAND2x1_ASAP7_75t_SL g45 ( 
.A(n_43),
.B(n_27),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

NAND3xp33_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_30),
.C(n_33),
.Y(n_47)
);

OAI211xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_28),
.B(n_45),
.C(n_44),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_SL g49 ( 
.A1(n_46),
.A2(n_33),
.B(n_25),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_44),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_21),
.B1(n_25),
.B2(n_37),
.Y(n_51)
);

NAND2xp33_ASAP7_75t_SL g52 ( 
.A(n_51),
.B(n_27),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

AOI22xp5_ASAP7_75t_L g54 ( 
.A1(n_48),
.A2(n_40),
.B1(n_18),
.B2(n_19),
.Y(n_54)
);

NOR3xp33_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_40),
.C(n_18),
.Y(n_55)
);

NOR4xp25_ASAP7_75t_SL g56 ( 
.A(n_52),
.B(n_49),
.C(n_53),
.D(n_55),
.Y(n_56)
);

OA22x2_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_13),
.B1(n_9),
.B2(n_7),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_57),
.Y(n_58)
);

AOI22xp33_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_56),
.B1(n_16),
.B2(n_5),
.Y(n_59)
);


endmodule