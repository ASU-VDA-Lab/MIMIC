module fake_netlist_875_1471_n_56 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_56);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_56;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_54;
wire n_28;
wire n_53;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_35;
wire n_41;
wire n_32;
wire n_25;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_13),
.B(n_6),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_16),
.B(n_11),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_5),
.B(n_22),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_8),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_10),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_7),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_2),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_18),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_14),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_9),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_21),
.B1(n_12),
.B2(n_22),
.Y(n_36)
);

BUFx4f_ASAP7_75t_L g37 ( 
.A(n_26),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_28),
.B(n_24),
.Y(n_38)
);

INVxp67_ASAP7_75t_SL g39 ( 
.A(n_27),
.Y(n_39)
);

OAI221xp5_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_30),
.B1(n_34),
.B2(n_35),
.C(n_31),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_37),
.Y(n_41)
);

INVx4_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

OAI33xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_38),
.A3(n_30),
.B1(n_32),
.B2(n_29),
.B3(n_25),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_42),
.B(n_40),
.Y(n_46)
);

NAND4xp75_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_29),
.C(n_26),
.D(n_12),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

AOI221xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_32),
.B1(n_21),
.B2(n_20),
.C(n_23),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

NAND4xp75_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_49),
.C(n_51),
.D(n_20),
.Y(n_52)
);

NAND4xp75_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_23),
.C(n_17),
.D(n_15),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

OR2x6_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_19),
.Y(n_55)
);

AOI222xp33_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_55),
.B1(n_3),
.B2(n_4),
.C1(n_0),
.C2(n_1),
.Y(n_56)
);


endmodule