module fake_netlist_875_2838_n_15 (n_0, n_2, n_3, n_4, n_1, n_15);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_15;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

NOR3xp33_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_1),
.C(n_3),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

OAI21xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_3),
.Y(n_7)
);

OAI21x1_ASAP7_75t_SL g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND4xp25_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_1),
.C(n_3),
.D(n_0),
.Y(n_11)
);

OAI211xp5_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_10),
.B(n_4),
.C(n_2),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_4),
.C(n_2),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_0),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_1),
.B(n_2),
.Y(n_15)
);


endmodule