module fake_netlist_875_1523_n_82 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_26, n_10, n_8, n_82);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_26;
input n_10;
input n_8;

output n_82;

wire n_60;
wire n_52;
wire n_30;
wire n_64;
wire n_66;
wire n_65;
wire n_71;
wire n_80;
wire n_29;
wire n_69;
wire n_51;
wire n_50;
wire n_55;
wire n_46;
wire n_54;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_62;
wire n_44;
wire n_79;
wire n_33;
wire n_77;
wire n_53;
wire n_81;
wire n_61;
wire n_43;
wire n_48;
wire n_72;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_34;
wire n_37;
wire n_75;
wire n_47;
wire n_68;
wire n_63;
wire n_58;
wire n_49;
wire n_67;
wire n_35;
wire n_57;
wire n_36;
wire n_45;
wire n_73;
wire n_78;

OA21x2_ASAP7_75t_L g29 ( 
.A1(n_0),
.A2(n_5),
.B(n_12),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_17),
.B(n_22),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_15),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_23),
.B(n_6),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_18),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_11),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_9),
.A2(n_24),
.B(n_20),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_10),
.B(n_25),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_8),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_27),
.Y(n_39)
);

BUFx3_ASAP7_75t_L g40 ( 
.A(n_4),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_7),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_2),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_33),
.Y(n_43)
);

INVxp67_ASAP7_75t_L g44 ( 
.A(n_33),
.Y(n_44)
);

OR2x6_ASAP7_75t_L g45 ( 
.A(n_39),
.B(n_25),
.Y(n_45)
);

A2O1A1Ixp33_ASAP7_75t_L g46 ( 
.A1(n_36),
.A2(n_39),
.B(n_40),
.C(n_37),
.Y(n_46)
);

AND2x4_ASAP7_75t_L g47 ( 
.A(n_40),
.B(n_35),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_35),
.Y(n_48)
);

AND3x1_ASAP7_75t_L g49 ( 
.A(n_42),
.B(n_14),
.C(n_23),
.Y(n_49)
);

A2O1A1Ixp33_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_48),
.B(n_36),
.C(n_47),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_44),
.Y(n_51)
);

INVx4_ASAP7_75t_L g52 ( 
.A(n_45),
.Y(n_52)
);

BUFx8_ASAP7_75t_L g53 ( 
.A(n_43),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

INVx2_ASAP7_75t_SL g55 ( 
.A(n_51),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

OR2x2_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_45),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_45),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_56),
.Y(n_60)
);

AND2x4_ASAP7_75t_L g61 ( 
.A(n_59),
.B(n_54),
.Y(n_61)
);

AND2x2_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_54),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_49),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_60),
.Y(n_64)
);

OAI211xp5_ASAP7_75t_SL g65 ( 
.A1(n_63),
.A2(n_57),
.B(n_32),
.C(n_38),
.Y(n_65)
);

OAI22xp33_ASAP7_75t_L g66 ( 
.A1(n_62),
.A2(n_31),
.B1(n_41),
.B2(n_42),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_64),
.Y(n_67)
);

OR2x2_ASAP7_75t_L g68 ( 
.A(n_62),
.B(n_31),
.Y(n_68)
);

OAI221xp5_ASAP7_75t_L g69 ( 
.A1(n_64),
.A2(n_30),
.B1(n_53),
.B2(n_29),
.C(n_61),
.Y(n_69)
);

OAI211xp5_ASAP7_75t_L g70 ( 
.A1(n_65),
.A2(n_30),
.B(n_29),
.C(n_53),
.Y(n_70)
);

NAND4xp25_ASAP7_75t_SL g71 ( 
.A(n_69),
.B(n_27),
.C(n_28),
.D(n_14),
.Y(n_71)
);

O2A1O1Ixp33_ASAP7_75t_L g72 ( 
.A1(n_66),
.A2(n_61),
.B(n_29),
.C(n_28),
.Y(n_72)
);

NAND2xp5_ASAP7_75t_L g73 ( 
.A(n_68),
.B(n_61),
.Y(n_73)
);

OAI211xp5_ASAP7_75t_SL g74 ( 
.A1(n_67),
.A2(n_26),
.B(n_29),
.C(n_34),
.Y(n_74)
);

AOI22xp5_ASAP7_75t_L g75 ( 
.A1(n_71),
.A2(n_73),
.B1(n_70),
.B2(n_74),
.Y(n_75)
);

NOR2xp33_ASAP7_75t_L g76 ( 
.A(n_72),
.B(n_26),
.Y(n_76)
);

NAND4xp75_ASAP7_75t_L g77 ( 
.A(n_73),
.B(n_3),
.C(n_21),
.D(n_19),
.Y(n_77)
);

NOR2xp33_ASAP7_75t_L g78 ( 
.A(n_73),
.B(n_13),
.Y(n_78)
);

O2A1O1Ixp33_ASAP7_75t_SL g79 ( 
.A1(n_76),
.A2(n_34),
.B(n_1),
.C(n_16),
.Y(n_79)
);

XOR2xp5_ASAP7_75t_L g80 ( 
.A(n_77),
.B(n_34),
.Y(n_80)
);

NAND3xp33_ASAP7_75t_L g81 ( 
.A(n_79),
.B(n_75),
.C(n_78),
.Y(n_81)
);

NOR2x1_ASAP7_75t_SL g82 ( 
.A(n_81),
.B(n_80),
.Y(n_82)
);


endmodule