module fake_netlist_875_250_n_63 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_63);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_63;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_21;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_32;
wire n_22;
wire n_57;
wire n_43;
wire n_62;
wire n_44;
wire n_29;
wire n_36;
wire n_45;
wire n_48;
wire n_26;
wire n_38;
wire n_56;

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_2),
.B(n_19),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_10),
.B(n_7),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_8),
.Y(n_28)
);

BUFx12f_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_11),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_17),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_17),
.Y(n_32)
);

BUFx3_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_20),
.B(n_24),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_20),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_24),
.A2(n_25),
.B1(n_23),
.B2(n_29),
.Y(n_36)
);

INVxp67_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_21),
.B(n_30),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_21),
.B(n_30),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_33),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_34),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_37),
.B(n_40),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_34),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_31),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_32),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_45),
.B1(n_44),
.B2(n_32),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_39),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_25),
.Y(n_49)
);

AOI221x1_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_22),
.B1(n_27),
.B2(n_30),
.C(n_21),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

AOI221xp5_ASAP7_75t_L g52 ( 
.A1(n_47),
.A2(n_22),
.B1(n_26),
.B2(n_27),
.C(n_30),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_38),
.Y(n_53)
);

AND2x4_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_38),
.Y(n_54)
);

OR2x2_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_13),
.Y(n_55)
);

OAI221xp5_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_21),
.B1(n_29),
.B2(n_16),
.C(n_14),
.Y(n_56)
);

OAI211xp5_ASAP7_75t_SL g57 ( 
.A1(n_50),
.A2(n_21),
.B(n_19),
.C(n_18),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_16),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

AOI222xp33_ASAP7_75t_L g60 ( 
.A1(n_56),
.A2(n_57),
.B1(n_26),
.B2(n_18),
.C1(n_6),
.C2(n_9),
.Y(n_60)
);

BUFx8_ASAP7_75t_SL g61 ( 
.A(n_59),
.Y(n_61)
);

OAI22xp5_ASAP7_75t_SL g62 ( 
.A1(n_58),
.A2(n_26),
.B1(n_4),
.B2(n_5),
.Y(n_62)
);

AOI222xp33_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_1),
.B1(n_3),
.B2(n_26),
.C1(n_60),
.C2(n_61),
.Y(n_63)
);


endmodule