module fake_netlist_875_2573_n_18 (n_0, n_2, n_3, n_4, n_1, n_18);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_18;

wire n_5;
wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_17;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

OAI21xp33_ASAP7_75t_L g5 ( 
.A1(n_1),
.A2(n_3),
.B(n_4),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_4),
.Y(n_6)
);

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_0),
.B(n_1),
.Y(n_9)
);

NOR3xp33_ASAP7_75t_SL g10 ( 
.A(n_8),
.B(n_5),
.C(n_7),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx2_ASAP7_75t_SL g13 ( 
.A(n_10),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_0),
.B2(n_3),
.Y(n_14)
);

XOR2x1_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_9),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_14),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_12),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_9),
.B(n_17),
.Y(n_18)
);


endmodule