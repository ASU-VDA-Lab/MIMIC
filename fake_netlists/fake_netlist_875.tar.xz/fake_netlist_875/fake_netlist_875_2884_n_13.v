module fake_netlist_875_2884_n_13 (n_0, n_1, n_2, n_13);

input n_0;
input n_1;
input n_2;

output n_13;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_2),
.Y(n_3)
);

AND2x4_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_0),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

BUFx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_4),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_6),
.B1(n_3),
.B2(n_5),
.Y(n_10)
);

AOI21xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B(n_7),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_12)
);

AOI222xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_1),
.B1(n_2),
.B2(n_6),
.C1(n_10),
.C2(n_9),
.Y(n_13)
);


endmodule