module fake_netlist_875_78_n_37 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_37);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_37;

wire n_33;
wire n_34;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_22;
wire n_25;
wire n_32;
wire n_35;
wire n_26;
wire n_36;
wire n_29;

INVx1_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_8),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_15),
.B(n_8),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_12),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_16),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_14),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx4_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_21),
.Y(n_27)
);

OAI211xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_23),
.B(n_24),
.C(n_22),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_26),
.Y(n_29)
);

AND2x2_ASAP7_75t_SL g30 ( 
.A(n_28),
.B(n_20),
.Y(n_30)
);

AO21x1_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_20),
.B(n_19),
.Y(n_31)
);

AOI32xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_29),
.A3(n_7),
.B1(n_5),
.B2(n_4),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_9),
.B1(n_3),
.B2(n_2),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_33),
.Y(n_34)
);

NAND2x1p5_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_1),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_10),
.B2(n_0),
.Y(n_37)
);


endmodule