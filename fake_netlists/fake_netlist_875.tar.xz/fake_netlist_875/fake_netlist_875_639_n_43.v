module fake_netlist_875_639_n_43 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_43);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_43;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_13;
wire n_32;
wire n_22;
wire n_14;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_2),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_3),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_0),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_1),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_1),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_L g23 ( 
.A(n_14),
.B(n_4),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

AND2x4_ASAP7_75t_SL g26 ( 
.A(n_24),
.B(n_17),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_22),
.B(n_16),
.C(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_23),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_26),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

A2O1A1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_27),
.B(n_12),
.C(n_5),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_31),
.B1(n_27),
.B2(n_12),
.C(n_29),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_6),
.C(n_0),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_6),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_36),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

OR3x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_33),
.C(n_11),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_7),
.B1(n_10),
.B2(n_38),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_39),
.B1(n_40),
.B2(n_42),
.Y(n_43)
);


endmodule