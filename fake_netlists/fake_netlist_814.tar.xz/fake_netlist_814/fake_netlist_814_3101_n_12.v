module fake_netlist_814_3101_n_12 (n_2, n_0, n_3, n_1, n_12);

input n_2;
input n_0;
input n_3;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_9;
wire n_11;
wire n_8;

INVx2_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AOI21xp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_7),
.B(n_0),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_8),
.C(n_2),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

AOI222xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_3),
.B2(n_6),
.C1(n_4),
.C2(n_7),
.Y(n_12)
);


endmodule