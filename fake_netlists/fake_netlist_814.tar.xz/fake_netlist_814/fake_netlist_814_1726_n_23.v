module fake_netlist_814_1726_n_23 (n_4, n_2, n_3, n_0, n_1, n_23);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_0),
.Y(n_5)
);

BUFx10_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_1),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_1),
.B1(n_3),
.B2(n_2),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_6),
.B(n_4),
.Y(n_12)
);

O2A1O1Ixp5_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_5),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_6),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_11),
.B(n_15),
.Y(n_19)
);

NOR2x1_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_19),
.Y(n_23)
);


endmodule