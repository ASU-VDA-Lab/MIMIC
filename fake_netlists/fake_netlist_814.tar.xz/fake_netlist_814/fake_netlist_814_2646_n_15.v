module fake_netlist_814_2646_n_15 (n_2, n_0, n_1, n_15);

input n_2;
input n_0;
input n_1;

output n_15;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

BUFx6f_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

BUFx10_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

INVxp67_ASAP7_75t_SL g6 ( 
.A(n_3),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI221x1_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_8),
.B1(n_7),
.B2(n_5),
.C(n_1),
.Y(n_11)
);

OAI221xp5_ASAP7_75t_SL g12 ( 
.A1(n_10),
.A2(n_4),
.B1(n_7),
.B2(n_8),
.C(n_2),
.Y(n_12)
);

OA22x2_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_8),
.B1(n_4),
.B2(n_2),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_8),
.B1(n_13),
.B2(n_12),
.Y(n_15)
);


endmodule