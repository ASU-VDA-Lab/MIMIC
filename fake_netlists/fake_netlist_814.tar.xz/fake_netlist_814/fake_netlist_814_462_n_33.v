module fake_netlist_814_462_n_33 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_33);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_33;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_27;

AO21x2_ASAP7_75t_L g17 ( 
.A1(n_4),
.A2(n_15),
.B(n_1),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_8),
.Y(n_19)
);

BUFx10_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_14),
.B1(n_2),
.B2(n_0),
.Y(n_22)
);

INVx5_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

NAND2x1p5_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_3),
.Y(n_24)
);

BUFx3_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_26),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_SL g29 ( 
.A1(n_27),
.A2(n_22),
.B(n_18),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_23),
.B1(n_25),
.B2(n_28),
.C1(n_19),
.C2(n_20),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_17),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_16),
.B1(n_11),
.B2(n_10),
.Y(n_33)
);


endmodule