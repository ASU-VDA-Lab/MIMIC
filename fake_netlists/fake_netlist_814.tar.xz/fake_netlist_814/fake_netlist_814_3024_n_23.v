module fake_netlist_814_3024_n_23 (n_4, n_2, n_3, n_0, n_1, n_23);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

INVx4_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

NAND2xp33_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_4),
.Y(n_7)
);

BUFx3_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_0),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_0),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

NOR2x1_ASAP7_75t_R g13 ( 
.A(n_10),
.B(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_6),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_7),
.B1(n_6),
.B2(n_11),
.C(n_8),
.Y(n_16)
);

NAND4xp25_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_6),
.C(n_8),
.D(n_5),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_7),
.B1(n_5),
.B2(n_13),
.C(n_0),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_SL g19 ( 
.A(n_17),
.B(n_2),
.C(n_1),
.Y(n_19)
);

XNOR2x1_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_2),
.Y(n_20)
);

AOI21x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_5),
.B(n_3),
.Y(n_21)
);

XOR2xp5_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_4),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_18),
.B(n_21),
.Y(n_23)
);


endmodule