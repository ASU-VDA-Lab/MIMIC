module fake_netlist_814_2589_n_50 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_50);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_50;

wire n_49;
wire n_48;
wire n_25;
wire n_20;
wire n_36;
wire n_47;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_17),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_1),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_11),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_SL g27 ( 
.A1(n_22),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_19),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_23),
.B(n_4),
.Y(n_29)
);

INVx6_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_22),
.B1(n_24),
.B2(n_18),
.C1(n_26),
.C2(n_21),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_27),
.A2(n_25),
.B1(n_20),
.B2(n_5),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_29),
.C(n_30),
.Y(n_35)
);

NAND2xp33_ASAP7_75t_SL g36 ( 
.A(n_34),
.B(n_32),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

NAND3x1_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_37),
.C(n_16),
.Y(n_39)
);

INVx1_ASAP7_75t_SL g40 ( 
.A(n_37),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_20),
.B(n_0),
.Y(n_41)
);

XNOR2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_3),
.Y(n_42)
);

OAI21xp5_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_20),
.B(n_6),
.Y(n_43)
);

NOR4xp25_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_40),
.C(n_20),
.D(n_7),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_8),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_12),
.Y(n_46)
);

INVx1_ASAP7_75t_SL g47 ( 
.A(n_45),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

OAI221xp5_ASAP7_75t_R g50 ( 
.A1(n_49),
.A2(n_13),
.B1(n_15),
.B2(n_47),
.C(n_48),
.Y(n_50)
);


endmodule