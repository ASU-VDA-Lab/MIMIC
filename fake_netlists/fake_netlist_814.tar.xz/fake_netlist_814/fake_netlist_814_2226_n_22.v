module fake_netlist_814_2226_n_22 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_22);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_21;
wire n_16;

AND2x2_ASAP7_75t_SL g12 ( 
.A(n_9),
.B(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_3),
.B(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_15),
.Y(n_17)
);

NAND4xp25_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_14),
.C(n_7),
.D(n_6),
.Y(n_18)
);

CKINVDCx14_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

AO221x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_12),
.B1(n_7),
.B2(n_6),
.C(n_17),
.Y(n_20)
);

AOI31xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_14),
.A3(n_17),
.B(n_0),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_11),
.B1(n_5),
.B2(n_4),
.Y(n_22)
);


endmodule