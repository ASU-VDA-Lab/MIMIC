module fake_netlist_814_2130_n_22 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_22);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

INVx3_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVxp67_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_2),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_1),
.Y(n_13)
);

NOR2xp67_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_2),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_7),
.B(n_3),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_12),
.B(n_9),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI221xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_10),
.B1(n_14),
.B2(n_16),
.C(n_12),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_15),
.B(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI32xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_5),
.A3(n_6),
.B1(n_8),
.B2(n_11),
.Y(n_22)
);


endmodule