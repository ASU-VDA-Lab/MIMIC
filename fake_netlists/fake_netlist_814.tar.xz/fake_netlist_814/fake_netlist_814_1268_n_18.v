module fake_netlist_814_1268_n_18 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_18);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_18;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;

AND2x6_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_2),
.Y(n_10)
);

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_0),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_4),
.B(n_1),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B1(n_10),
.B2(n_4),
.Y(n_14)
);

OAI221xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_13),
.B1(n_7),
.B2(n_5),
.C(n_6),
.Y(n_15)
);

NAND2xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_11),
.B1(n_7),
.B2(n_5),
.C(n_10),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_8),
.B(n_3),
.Y(n_18)
);


endmodule