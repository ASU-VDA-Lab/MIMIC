module fake_netlist_814_2956_n_16 (n_4, n_2, n_3, n_0, n_1, n_16);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_0),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_8),
.B1(n_5),
.B2(n_0),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_1),
.B1(n_2),
.B2(n_4),
.C(n_11),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_1),
.C(n_2),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);


endmodule