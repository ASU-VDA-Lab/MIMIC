module fake_netlist_814_1291_n_14 (n_4, n_2, n_3, n_0, n_1, n_14);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

BUFx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

XNOR2xp5_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_1),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_7),
.Y(n_10)
);

AOI21xp33_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_9),
.B(n_1),
.Y(n_11)
);

AOI322xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.A3(n_5),
.B1(n_1),
.B2(n_2),
.C1(n_0),
.C2(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_4),
.B1(n_8),
.B2(n_7),
.C1(n_6),
.C2(n_12),
.Y(n_14)
);


endmodule