module fake_netlist_814_2332_n_27 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_27);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;
wire n_11;

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_4),
.B1(n_5),
.B2(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_1),
.A2(n_8),
.B1(n_4),
.B2(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_1),
.Y(n_16)
);

NAND3x1_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_7),
.C(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_0),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_16),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

O2A1O1Ixp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_19),
.B(n_14),
.C(n_12),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_22),
.B(n_11),
.Y(n_24)
);

AO22x2_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_17),
.B1(n_10),
.B2(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);


endmodule