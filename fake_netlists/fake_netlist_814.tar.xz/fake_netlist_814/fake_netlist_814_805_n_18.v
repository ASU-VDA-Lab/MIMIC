module fake_netlist_814_805_n_18 (n_4, n_2, n_5, n_3, n_0, n_1, n_18);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_18;

wire n_6;
wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_16;
wire n_17;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_R g7 ( 
.A(n_4),
.B(n_0),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_R g8 ( 
.A(n_0),
.B(n_3),
.Y(n_8)
);

A2O1A1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_9)
);

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_9),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_11),
.B(n_8),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_5),
.B2(n_2),
.Y(n_14)
);

INVx5_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_5),
.B1(n_3),
.B2(n_2),
.Y(n_16)
);

NOR2x1_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_13),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_15),
.B1(n_14),
.B2(n_17),
.Y(n_18)
);


endmodule