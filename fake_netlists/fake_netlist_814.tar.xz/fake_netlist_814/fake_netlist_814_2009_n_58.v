module fake_netlist_814_2009_n_58 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_58);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_58;

wire n_49;
wire n_48;
wire n_25;
wire n_51;
wire n_20;
wire n_36;
wire n_47;
wire n_17;
wire n_50;
wire n_22;
wire n_41;
wire n_44;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_23;
wire n_53;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_30;
wire n_18;
wire n_55;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_57;

INVx2_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_7),
.A2(n_0),
.B1(n_14),
.B2(n_2),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_12),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

BUFx12f_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_25),
.A2(n_13),
.B1(n_5),
.B2(n_3),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_20),
.B(n_13),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_28),
.B(n_24),
.Y(n_33)
);

BUFx12f_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_29),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_30),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

BUFx3_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_32),
.C(n_27),
.Y(n_40)
);

NAND2xp33_ASAP7_75t_R g41 ( 
.A(n_37),
.B(n_35),
.Y(n_41)
);

INVx5_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_39),
.Y(n_44)
);

OAI32xp33_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_39),
.A3(n_31),
.B1(n_33),
.B2(n_30),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_27),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_25),
.B1(n_22),
.B2(n_27),
.Y(n_48)
);

NOR2x1_ASAP7_75t_L g49 ( 
.A(n_43),
.B(n_33),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

NAND3xp33_ASAP7_75t_SL g52 ( 
.A(n_48),
.B(n_22),
.C(n_21),
.Y(n_52)
);

NOR3xp33_ASAP7_75t_SL g53 ( 
.A(n_47),
.B(n_34),
.C(n_23),
.Y(n_53)
);

BUFx2_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

INVxp67_ASAP7_75t_SL g55 ( 
.A(n_54),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_34),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_34),
.B1(n_18),
.B2(n_16),
.Y(n_57)
);

AOI222xp33_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_57),
.B1(n_55),
.B2(n_51),
.C1(n_34),
.C2(n_8),
.Y(n_58)
);


endmodule