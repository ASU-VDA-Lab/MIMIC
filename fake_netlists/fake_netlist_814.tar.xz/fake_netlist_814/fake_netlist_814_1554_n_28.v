module fake_netlist_814_1554_n_28 (n_4, n_2, n_5, n_3, n_0, n_1, n_28);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;
wire n_8;

INVxp33_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

NAND3xp33_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_3),
.C(n_1),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_6),
.A2(n_8),
.B(n_9),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_2),
.B(n_0),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_7),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_7),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_6),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_9),
.B(n_7),
.C(n_16),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_15),
.B1(n_13),
.B2(n_10),
.C(n_2),
.Y(n_21)
);

O2A1O1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_10),
.B(n_4),
.C(n_2),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_20),
.B(n_17),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_22),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AO221x1_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_3),
.B1(n_5),
.B2(n_24),
.C(n_23),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_27),
.Y(n_28)
);


endmodule