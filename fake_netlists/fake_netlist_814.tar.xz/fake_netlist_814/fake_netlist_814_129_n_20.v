module fake_netlist_814_129_n_20 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_20);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

NAND3xp33_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_0),
.C(n_4),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_7),
.C(n_4),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_6),
.A2(n_7),
.B1(n_1),
.B2(n_3),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_0),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B1(n_10),
.B2(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.C(n_5),
.Y(n_17)
);

NOR4xp75_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_9),
.C(n_5),
.D(n_2),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.Y(n_19)
);

AOI21xp33_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_18),
.B(n_9),
.Y(n_20)
);


endmodule