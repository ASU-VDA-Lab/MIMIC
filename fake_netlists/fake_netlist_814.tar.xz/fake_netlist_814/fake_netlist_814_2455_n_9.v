module fake_netlist_814_2455_n_9 (n_0, n_1, n_9);

input n_0;
input n_1;

output n_9;

wire n_6;
wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_3;
wire n_8;

BUFx6f_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

OAI211xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_3),
.B(n_1),
.C(n_0),
.Y(n_6)
);

NOR3xp33_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.C(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_0),
.B(n_6),
.Y(n_9)
);


endmodule