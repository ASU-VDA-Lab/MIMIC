module fake_netlist_814_678_n_66 (n_20, n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_66);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_66;

wire n_48;
wire n_49;
wire n_25;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_23;
wire n_34;
wire n_40;
wire n_44;
wire n_39;
wire n_28;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_26;
wire n_24;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_64;
wire n_55;
wire n_65;
wire n_35;
wire n_52;
wire n_38;
wire n_61;
wire n_27;
wire n_43;
wire n_45;
wire n_46;
wire n_51;

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_10),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_7),
.B(n_16),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_0),
.B(n_8),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_12),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_2),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_15),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_22),
.B(n_18),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_25),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_27),
.B(n_23),
.Y(n_36)
);

INVx3_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_24),
.Y(n_38)
);

OAI22xp33_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_29),
.B1(n_31),
.B2(n_26),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_32),
.Y(n_40)
);

INVx4_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_36),
.B(n_18),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

OAI31xp33_ASAP7_75t_L g44 ( 
.A1(n_39),
.A2(n_33),
.A3(n_38),
.B(n_19),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

NAND2xp33_ASAP7_75t_R g47 ( 
.A(n_46),
.B(n_35),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_43),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_42),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_44),
.B(n_33),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_49),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_1),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_47),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_28),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_9),
.B1(n_5),
.B2(n_3),
.Y(n_56)
);

BUFx6f_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

BUFx3_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

CKINVDCx5p33_ASAP7_75t_R g59 ( 
.A(n_58),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_57),
.B(n_13),
.Y(n_60)
);

CKINVDCx16_ASAP7_75t_R g61 ( 
.A(n_57),
.Y(n_61)
);

OR3x2_ASAP7_75t_L g62 ( 
.A(n_55),
.B(n_56),
.C(n_14),
.Y(n_62)
);

HB1xp67_ASAP7_75t_L g63 ( 
.A(n_59),
.Y(n_63)
);

OAI22xp5_ASAP7_75t_L g64 ( 
.A1(n_62),
.A2(n_21),
.B1(n_20),
.B2(n_17),
.Y(n_64)
);

INVx8_ASAP7_75t_L g65 ( 
.A(n_61),
.Y(n_65)
);

AOI22xp5_ASAP7_75t_SL g66 ( 
.A1(n_64),
.A2(n_60),
.B1(n_63),
.B2(n_65),
.Y(n_66)
);


endmodule