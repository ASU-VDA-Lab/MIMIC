module fake_netlist_814_1596_n_27 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_27);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

NOR2xp67_ASAP7_75t_L g16 ( 
.A(n_2),
.B(n_9),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_5),
.B(n_10),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_20)
);

NAND2x1_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_16),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_18),
.B1(n_17),
.B2(n_6),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_25),
.A2(n_12),
.B1(n_11),
.B2(n_7),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.Y(n_27)
);


endmodule