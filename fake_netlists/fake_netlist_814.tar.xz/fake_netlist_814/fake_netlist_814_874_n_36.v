module fake_netlist_814_874_n_36 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_36);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_36;

wire n_25;
wire n_20;
wire n_22;
wire n_23;
wire n_34;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_35;
wire n_27;

CKINVDCx16_ASAP7_75t_R g18 ( 
.A(n_11),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_12),
.B(n_1),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_15),
.B(n_6),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_14),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_16),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_16),
.Y(n_26)
);

OR2x2_ASAP7_75t_SL g27 ( 
.A(n_25),
.B(n_22),
.Y(n_27)
);

OAI22xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_24),
.B1(n_23),
.B2(n_17),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_17),
.Y(n_29)
);

INVxp67_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI211xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B(n_21),
.C(n_20),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OAI22xp33_ASAP7_75t_SL g34 ( 
.A1(n_32),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_9),
.B1(n_8),
.B2(n_4),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_33),
.B1(n_34),
.B2(n_13),
.Y(n_36)
);


endmodule