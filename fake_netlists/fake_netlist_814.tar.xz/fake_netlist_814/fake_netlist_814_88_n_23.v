module fake_netlist_814_88_n_23 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_23);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;
wire n_11;

BUFx2_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

NAND2xp33_ASAP7_75t_R g12 ( 
.A(n_8),
.B(n_3),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_10),
.B(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_11),
.B(n_1),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.Y(n_18)
);

NAND2x1_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_15),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.B(n_12),
.C(n_15),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_9),
.B1(n_7),
.B2(n_5),
.Y(n_23)
);


endmodule