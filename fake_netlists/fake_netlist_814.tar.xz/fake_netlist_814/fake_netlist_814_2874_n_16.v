module fake_netlist_814_2874_n_16 (n_2, n_0, n_1, n_16);

input n_2;
input n_0;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_3;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

AND2x2_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_1),
.Y(n_4)
);

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_3),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_3),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_8),
.B(n_5),
.Y(n_11)
);

NAND4xp25_ASAP7_75t_SL g12 ( 
.A(n_10),
.B(n_4),
.C(n_6),
.D(n_0),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_5),
.B1(n_9),
.B2(n_1),
.Y(n_13)
);

OAI21xp33_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_13),
.B(n_9),
.Y(n_14)
);

AOI22x1_ASAP7_75t_SL g15 ( 
.A1(n_12),
.A2(n_2),
.B1(n_1),
.B2(n_9),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_2),
.B(n_15),
.Y(n_16)
);


endmodule