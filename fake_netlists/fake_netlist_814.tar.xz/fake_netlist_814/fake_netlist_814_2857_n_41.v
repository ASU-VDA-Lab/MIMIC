module fake_netlist_814_2857_n_41 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_41);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_41;

wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_17;
wire n_22;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

BUFx3_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

AND2x6_ASAP7_75t_L g16 ( 
.A(n_0),
.B(n_6),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_13),
.B(n_8),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_10),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_15),
.B(n_1),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_19),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_14),
.B1(n_5),
.B2(n_4),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_19),
.B1(n_18),
.B2(n_16),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_SL g27 ( 
.A1(n_22),
.A2(n_17),
.B1(n_18),
.B2(n_19),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_23),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

INVx2_ASAP7_75t_SL g31 ( 
.A(n_30),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_22),
.Y(n_32)
);

NOR2xp67_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_23),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

AO22x2_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_32),
.B1(n_21),
.B2(n_5),
.Y(n_36)
);

AOI332xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_14),
.A3(n_16),
.B1(n_33),
.B2(n_11),
.B3(n_7),
.C1(n_3),
.C2(n_9),
.Y(n_37)
);

AOI21xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_12),
.B(n_16),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_36),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

AOI322xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_16),
.A3(n_37),
.B1(n_38),
.B2(n_39),
.C1(n_27),
.C2(n_25),
.Y(n_41)
);


endmodule