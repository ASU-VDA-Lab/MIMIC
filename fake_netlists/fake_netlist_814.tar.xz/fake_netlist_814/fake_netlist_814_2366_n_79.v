module fake_netlist_814_2366_n_79 (n_25, n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_28, n_9, n_26, n_24, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_27, n_1, n_8, n_79);

input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_28;
input n_9;
input n_26;
input n_24;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_27;
input n_1;
input n_8;

output n_79;

wire n_49;
wire n_78;
wire n_54;
wire n_56;
wire n_59;
wire n_63;
wire n_74;
wire n_64;
wire n_61;
wire n_43;
wire n_45;
wire n_48;
wire n_47;
wire n_76;
wire n_72;
wire n_73;
wire n_37;
wire n_42;
wire n_52;
wire n_77;
wire n_57;
wire n_51;
wire n_70;
wire n_41;
wire n_62;
wire n_34;
wire n_44;
wire n_40;
wire n_53;
wire n_58;
wire n_68;
wire n_33;
wire n_55;
wire n_65;
wire n_75;
wire n_67;
wire n_66;
wire n_36;
wire n_50;
wire n_60;
wire n_39;
wire n_31;
wire n_32;
wire n_71;
wire n_69;
wire n_29;
wire n_30;
wire n_35;
wire n_38;
wire n_46;

AND2x2_ASAP7_75t_L g29 ( 
.A(n_0),
.B(n_13),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_22),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_3),
.Y(n_31)
);

NOR2x1_ASAP7_75t_L g32 ( 
.A(n_8),
.B(n_9),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_10),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_25),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_2),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_25),
.B(n_22),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_15),
.A2(n_28),
.B1(n_17),
.B2(n_19),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_4),
.Y(n_38)
);

INVx3_ASAP7_75t_L g39 ( 
.A(n_1),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_6),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_21),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_18),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_16),
.B(n_27),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_36),
.B(n_20),
.Y(n_44)
);

NAND2x1p5_ASAP7_75t_L g45 ( 
.A(n_39),
.B(n_5),
.Y(n_45)
);

NOR2x1p5_ASAP7_75t_L g46 ( 
.A(n_34),
.B(n_20),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_SL g47 ( 
.A(n_36),
.B(n_23),
.Y(n_47)
);

BUFx6f_ASAP7_75t_L g48 ( 
.A(n_38),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_30),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_36),
.A2(n_26),
.B1(n_24),
.B2(n_23),
.Y(n_50)
);

OAI21xp5_ASAP7_75t_L g51 ( 
.A1(n_42),
.A2(n_26),
.B(n_24),
.Y(n_51)
);

INVxp67_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

AO31x2_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_35),
.A3(n_42),
.B(n_31),
.Y(n_53)
);

AOI21xp5_ASAP7_75t_L g54 ( 
.A1(n_44),
.A2(n_40),
.B(n_33),
.Y(n_54)
);

AO32x2_ASAP7_75t_L g55 ( 
.A1(n_44),
.A2(n_37),
.A3(n_34),
.B1(n_39),
.B2(n_32),
.Y(n_55)
);

OAI21xp5_ASAP7_75t_L g56 ( 
.A1(n_45),
.A2(n_41),
.B(n_43),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_47),
.Y(n_57)
);

AOI211xp5_ASAP7_75t_L g58 ( 
.A1(n_54),
.A2(n_47),
.B(n_50),
.C(n_35),
.Y(n_58)
);

INVx2_ASAP7_75t_SL g59 ( 
.A(n_53),
.Y(n_59)
);

AND2x4_ASAP7_75t_L g60 ( 
.A(n_52),
.B(n_46),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_56),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_59),
.Y(n_62)
);

HB1xp67_ASAP7_75t_L g63 ( 
.A(n_60),
.Y(n_63)
);

INVx2_ASAP7_75t_SL g64 ( 
.A(n_63),
.Y(n_64)
);

AOI221xp5_ASAP7_75t_L g65 ( 
.A1(n_61),
.A2(n_60),
.B1(n_58),
.B2(n_55),
.C(n_45),
.Y(n_65)
);

O2A1O1Ixp33_ASAP7_75t_L g66 ( 
.A1(n_62),
.A2(n_55),
.B(n_39),
.C(n_29),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_62),
.Y(n_67)
);

AOI21x1_ASAP7_75t_L g68 ( 
.A1(n_67),
.A2(n_61),
.B(n_29),
.Y(n_68)
);

XOR2x2_ASAP7_75t_L g69 ( 
.A(n_65),
.B(n_27),
.Y(n_69)
);

OAI22xp5_ASAP7_75t_L g70 ( 
.A1(n_66),
.A2(n_38),
.B1(n_48),
.B2(n_28),
.Y(n_70)
);

OR2x2_ASAP7_75t_L g71 ( 
.A(n_69),
.B(n_64),
.Y(n_71)
);

INVx3_ASAP7_75t_SL g72 ( 
.A(n_70),
.Y(n_72)
);

NOR3xp33_ASAP7_75t_L g73 ( 
.A(n_70),
.B(n_38),
.C(n_7),
.Y(n_73)
);

OR2x2_ASAP7_75t_L g74 ( 
.A(n_68),
.B(n_11),
.Y(n_74)
);

NOR3xp33_ASAP7_75t_SL g75 ( 
.A(n_71),
.B(n_14),
.C(n_12),
.Y(n_75)
);

OR2x2_ASAP7_75t_L g76 ( 
.A(n_72),
.B(n_38),
.Y(n_76)
);

OAI22xp33_ASAP7_75t_L g77 ( 
.A1(n_74),
.A2(n_48),
.B1(n_72),
.B2(n_71),
.Y(n_77)
);

AOI22xp5_ASAP7_75t_L g78 ( 
.A1(n_77),
.A2(n_48),
.B1(n_73),
.B2(n_75),
.Y(n_78)
);

AOI22xp5_ASAP7_75t_L g79 ( 
.A1(n_78),
.A2(n_73),
.B1(n_76),
.B2(n_48),
.Y(n_79)
);


endmodule