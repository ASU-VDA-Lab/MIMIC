module fake_netlist_814_1348_n_44 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_44);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_44;

wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_21;
wire n_16;
wire n_35;
wire n_38;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_5),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_15),
.B(n_1),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_22),
.A2(n_14),
.B1(n_15),
.B2(n_17),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_14),
.B1(n_20),
.B2(n_16),
.C(n_17),
.Y(n_27)
);

NAND2x1_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_15),
.Y(n_28)
);

OAI221xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_27),
.B1(n_25),
.B2(n_24),
.C(n_23),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_18),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_30),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_18),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_30),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_8),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_2),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_4),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_33),
.B1(n_7),
.B2(n_4),
.C(n_6),
.Y(n_37)
);

BUFx6f_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

NAND2xp33_ASAP7_75t_SL g39 ( 
.A(n_36),
.B(n_7),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_39),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

NOR2x1_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_34),
.Y(n_42)
);

INVxp67_ASAP7_75t_SL g43 ( 
.A(n_42),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_43),
.A2(n_40),
.B1(n_41),
.B2(n_10),
.Y(n_44)
);


endmodule