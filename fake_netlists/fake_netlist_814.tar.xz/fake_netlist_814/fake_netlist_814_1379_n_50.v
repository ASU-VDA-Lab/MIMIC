module fake_netlist_814_1379_n_50 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_50);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_50;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_47;
wire n_17;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;
wire n_46;

INVx3_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_11),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

BUFx4f_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_SL g28 ( 
.A(n_18),
.B(n_4),
.C(n_0),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_19),
.B(n_0),
.Y(n_29)
);

AND2x6_ASAP7_75t_L g30 ( 
.A(n_16),
.B(n_2),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

INVx6_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_17),
.B1(n_20),
.B2(n_18),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_29),
.A2(n_30),
.B1(n_27),
.B2(n_20),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_30),
.B1(n_27),
.B2(n_29),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_26),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_23),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_23),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_32),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_SL g41 ( 
.A1(n_38),
.A2(n_36),
.B(n_40),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_32),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_42),
.B(n_28),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_22),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_21),
.B1(n_16),
.B2(n_15),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_15),
.B1(n_6),
.B2(n_5),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_44),
.A2(n_46),
.B1(n_15),
.B2(n_14),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_47),
.B1(n_9),
.B2(n_8),
.Y(n_50)
);


endmodule