module fake_netlist_856_2944_n_33 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_33);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_33;

wire n_25;
wire n_20;
wire n_15;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_6),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_14),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_6),
.B1(n_3),
.B2(n_1),
.Y(n_22)
);

O2A1O1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_17),
.A2(n_8),
.B(n_5),
.C(n_4),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

O2A1O1Ixp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_18),
.B(n_15),
.C(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_19),
.B(n_24),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_29),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_21),
.B1(n_11),
.B2(n_9),
.C(n_10),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_31),
.A2(n_13),
.B1(n_21),
.B2(n_32),
.Y(n_33)
);


endmodule