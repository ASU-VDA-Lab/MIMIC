module fake_netlist_856_1320_n_13 (n_4, n_2, n_5, n_3, n_0, n_1, n_13);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_13;

wire n_6;
wire n_10;
wire n_7;
wire n_11;
wire n_9;
wire n_12;
wire n_8;

NOR3xp33_ASAP7_75t_SL g6 ( 
.A(n_2),
.B(n_0),
.C(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_1),
.Y(n_10)
);

OAI21xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B(n_7),
.Y(n_11)
);

NOR3xp33_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_10),
.C(n_9),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_5),
.B(n_3),
.Y(n_13)
);


endmodule