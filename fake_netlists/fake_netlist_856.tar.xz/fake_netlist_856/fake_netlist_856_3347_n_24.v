module fake_netlist_856_3347_n_24 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_24);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_24;

wire n_20;
wire n_15;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

INVx2_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

NOR2x1p5_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_3),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_2),
.B(n_11),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_1),
.B(n_0),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_14),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_7),
.Y(n_20)
);

AOI21xp33_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_16),
.B(n_4),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_5),
.Y(n_22)
);

OAI22x1_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_15),
.B1(n_9),
.B2(n_6),
.Y(n_23)
);

AO21x2_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_13),
.B(n_12),
.Y(n_24)
);


endmodule