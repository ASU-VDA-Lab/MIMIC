module fake_netlist_856_3509_n_10 (n_4, n_2, n_3, n_0, n_1, n_10);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_10;

wire n_6;
wire n_7;
wire n_5;
wire n_9;
wire n_8;

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_4),
.Y(n_6)
);

OAI221xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_0),
.B2(n_3),
.C(n_4),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_SL g8 ( 
.A1(n_7),
.A2(n_5),
.B1(n_6),
.B2(n_0),
.Y(n_8)
);

NOR3xp33_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_3),
.C(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);


endmodule