module fake_netlist_856_1704_n_16 (n_2, n_0, n_3, n_1, n_16);

input n_2;
input n_0;
input n_3;
input n_1;

output n_16;

wire n_6;
wire n_10;
wire n_15;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_14;
wire n_12;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g4 ( 
.A(n_3),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_2),
.Y(n_5)
);

AND2x6_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_1),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_SL g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_6),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_5),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_8),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AOI211xp5_ASAP7_75t_SL g13 ( 
.A1(n_11),
.A2(n_10),
.B(n_9),
.C(n_1),
.Y(n_13)
);

XNOR2x1_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_10),
.Y(n_14)
);

NAND4xp75_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_10),
.C(n_14),
.D(n_1),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_3),
.B1(n_8),
.B2(n_9),
.C1(n_11),
.C2(n_6),
.Y(n_16)
);


endmodule