module fake_netlist_856_1330_n_27 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_27);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_27;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;

INVx1_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_4),
.B(n_6),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_8),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_4),
.B(n_5),
.Y(n_13)
);

AO22x2_ASAP7_75t_L g14 ( 
.A1(n_0),
.A2(n_7),
.B1(n_3),
.B2(n_5),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_1),
.B(n_6),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_7),
.B(n_11),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_14),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_17),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_17),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_21),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_17),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_16),
.B(n_17),
.Y(n_26)
);

AO21x2_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_16),
.B(n_25),
.Y(n_27)
);


endmodule