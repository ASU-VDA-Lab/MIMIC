module fake_netlist_856_1892_n_20 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_20);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

AND2x2_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_1),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

XOR2xp5_ASAP7_75t_L g12 ( 
.A(n_1),
.B(n_0),
.Y(n_12)
);

XOR2xp5_ASAP7_75t_L g13 ( 
.A(n_2),
.B(n_8),
.Y(n_13)
);

OAI21xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI32xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_9),
.A3(n_11),
.B1(n_12),
.B2(n_13),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_2),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_5),
.B1(n_4),
.B2(n_6),
.C(n_7),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_8),
.B(n_15),
.Y(n_20)
);


endmodule