module fake_netlist_856_1228_n_25 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_25);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_25;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_21;
wire n_16;
wire n_11;

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_5),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

OAI22x1_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.Y(n_17)
);

O2A1O1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_11),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_18),
.B1(n_11),
.B2(n_17),
.C(n_13),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_13),
.B1(n_6),
.B2(n_2),
.C(n_4),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_13),
.B(n_7),
.C(n_6),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_13),
.B1(n_10),
.B2(n_8),
.Y(n_25)
);


endmodule