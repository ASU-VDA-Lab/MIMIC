module fake_netlist_856_1187_n_24 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_24);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_24;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_19;
wire n_18;
wire n_21;
wire n_16;

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_3),
.Y(n_13)
);

INVx4_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

NAND2x1p5_ASAP7_75t_L g15 ( 
.A(n_4),
.B(n_1),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_10),
.B(n_9),
.Y(n_18)
);

O2A1O1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_14),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_14),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_15),
.B1(n_18),
.B2(n_16),
.Y(n_22)
);

OR4x1_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_19),
.C(n_6),
.D(n_5),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_12),
.B(n_7),
.Y(n_24)
);


endmodule