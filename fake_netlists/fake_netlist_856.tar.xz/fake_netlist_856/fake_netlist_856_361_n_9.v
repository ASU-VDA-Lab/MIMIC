module fake_netlist_856_361_n_9 (n_2, n_0, n_1, n_9);

input n_2;
input n_0;
input n_1;

output n_9;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_8;

NOR2xp67_ASAP7_75t_SL g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

BUFx12f_ASAP7_75t_SL g4 ( 
.A(n_0),
.Y(n_4)
);

INVx3_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

A2O1A1Ixp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_3),
.B(n_5),
.C(n_4),
.Y(n_7)
);

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_5),
.B1(n_1),
.B2(n_0),
.Y(n_8)
);

AOI221xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_6),
.Y(n_9)
);


endmodule