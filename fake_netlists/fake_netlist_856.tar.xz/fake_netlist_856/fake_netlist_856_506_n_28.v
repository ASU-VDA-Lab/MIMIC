module fake_netlist_856_506_n_28 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_28);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_28;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_26;
wire n_24;
wire n_19;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

INVx1_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_8),
.A2(n_7),
.B(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

OA21x2_ASAP7_75t_L g18 ( 
.A1(n_5),
.A2(n_4),
.B(n_6),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_15),
.B(n_4),
.Y(n_19)
);

AND3x2_ASAP7_75t_SL g20 ( 
.A(n_18),
.B(n_5),
.C(n_0),
.Y(n_20)
);

AOI221x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_14),
.B1(n_13),
.B2(n_16),
.C(n_15),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_17),
.Y(n_23)
);

OAI21xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_17),
.B(n_18),
.Y(n_24)
);

AOI332xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_23),
.A3(n_18),
.B1(n_16),
.B2(n_11),
.B3(n_9),
.C1(n_1),
.C2(n_10),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_16),
.B1(n_23),
.B2(n_26),
.Y(n_28)
);


endmodule