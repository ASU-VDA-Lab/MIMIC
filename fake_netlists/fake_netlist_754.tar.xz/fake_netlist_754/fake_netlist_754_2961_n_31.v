module fake_netlist_754_2961_n_31 (n_1, n_2, n_3, n_4, n_5, n_7, n_6, n_0, n_8, n_31);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_31;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_30;
wire n_9;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_29;

INVx1_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_4),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_15),
.Y(n_17)
);

AO21x2_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_9),
.B(n_13),
.Y(n_18)
);

INVx2_ASAP7_75t_SL g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_18),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_16),
.B(n_14),
.Y(n_23)
);

XOR2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_18),
.Y(n_24)
);

NOR2xp67_ASAP7_75t_SL g25 ( 
.A(n_22),
.B(n_10),
.Y(n_25)
);

AOI21xp33_ASAP7_75t_SL g26 ( 
.A1(n_24),
.A2(n_6),
.B(n_4),
.Y(n_26)
);

NOR2x1p5_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_10),
.Y(n_27)
);

OAI22x1_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_11),
.B1(n_10),
.B2(n_25),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_11),
.B1(n_2),
.B2(n_1),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AOI22x1_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_8),
.B2(n_5),
.Y(n_31)
);


endmodule