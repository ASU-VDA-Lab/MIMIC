module fake_netlist_754_2347_n_47 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_47);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_47;

wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_22),
.B(n_1),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_19),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_19),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_5),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_18),
.B(n_10),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_0),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_14),
.B1(n_20),
.B2(n_8),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_18),
.B(n_3),
.C(n_2),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_25),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_SL g35 ( 
.A(n_33),
.B(n_26),
.C(n_27),
.Y(n_35)
);

O2A1O1Ixp33_ASAP7_75t_SL g36 ( 
.A1(n_34),
.A2(n_30),
.B(n_24),
.C(n_28),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_29),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_32),
.Y(n_38)
);

NAND2xp33_ASAP7_75t_SL g39 ( 
.A(n_38),
.B(n_4),
.Y(n_39)
);

INVxp67_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NOR2x1_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_37),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_37),
.B1(n_9),
.B2(n_6),
.C(n_7),
.Y(n_42)
);

CKINVDCx5p33_ASAP7_75t_R g43 ( 
.A(n_41),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

OAI22x1_ASAP7_75t_SL g45 ( 
.A1(n_43),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_15),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_16),
.B1(n_17),
.B2(n_45),
.Y(n_47)
);


endmodule