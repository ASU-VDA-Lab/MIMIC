module fake_netlist_754_2445_n_40 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_40);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_40;

wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_13),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_16),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

AND3x2_ASAP7_75t_L g26 ( 
.A(n_10),
.B(n_11),
.C(n_8),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_12),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_7),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_24),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_25),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_29),
.B1(n_28),
.B2(n_22),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NAND2xp33_ASAP7_75t_SL g34 ( 
.A(n_32),
.B(n_23),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_34),
.Y(n_35)
);

OAI21xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_31),
.B(n_26),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_14),
.B1(n_9),
.B2(n_6),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_37),
.Y(n_38)
);

CKINVDCx20_ASAP7_75t_R g39 ( 
.A(n_38),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_21),
.B1(n_19),
.B2(n_18),
.Y(n_40)
);


endmodule