module fake_netlist_754_21_n_211 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_28, n_27, n_24, n_10, n_5, n_26, n_6, n_31, n_30, n_2, n_3, n_9, n_4, n_25, n_7, n_17, n_21, n_12, n_15, n_19, n_29, n_0, n_8, n_211);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_28;
input n_27;
input n_24;
input n_10;
input n_5;
input n_26;
input n_6;
input n_31;
input n_30;
input n_2;
input n_3;
input n_9;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_29;
input n_0;
input n_8;

output n_211;

wire n_77;
wire n_71;
wire n_80;
wire n_62;
wire n_186;
wire n_156;
wire n_36;
wire n_175;
wire n_153;
wire n_81;
wire n_106;
wire n_200;
wire n_104;
wire n_68;
wire n_73;
wire n_192;
wire n_176;
wire n_173;
wire n_112;
wire n_127;
wire n_139;
wire n_182;
wire n_189;
wire n_155;
wire n_94;
wire n_183;
wire n_105;
wire n_60;
wire n_53;
wire n_57;
wire n_41;
wire n_157;
wire n_119;
wire n_84;
wire n_86;
wire n_195;
wire n_55;
wire n_131;
wire n_201;
wire n_191;
wire n_126;
wire n_151;
wire n_210;
wire n_140;
wire n_184;
wire n_46;
wire n_64;
wire n_82;
wire n_196;
wire n_76;
wire n_194;
wire n_193;
wire n_72;
wire n_108;
wire n_145;
wire n_51;
wire n_78;
wire n_98;
wire n_102;
wire n_97;
wire n_118;
wire n_75;
wire n_197;
wire n_42;
wire n_132;
wire n_85;
wire n_160;
wire n_33;
wire n_147;
wire n_198;
wire n_95;
wire n_180;
wire n_149;
wire n_174;
wire n_70;
wire n_63;
wire n_69;
wire n_166;
wire n_144;
wire n_100;
wire n_56;
wire n_167;
wire n_204;
wire n_111;
wire n_125;
wire n_92;
wire n_52;
wire n_141;
wire n_136;
wire n_61;
wire n_110;
wire n_172;
wire n_207;
wire n_45;
wire n_190;
wire n_137;
wire n_90;
wire n_65;
wire n_148;
wire n_169;
wire n_150;
wire n_87;
wire n_187;
wire n_128;
wire n_117;
wire n_133;
wire n_50;
wire n_96;
wire n_138;
wire n_203;
wire n_79;
wire n_130;
wire n_35;
wire n_101;
wire n_122;
wire n_43;
wire n_165;
wire n_209;
wire n_58;
wire n_91;
wire n_188;
wire n_103;
wire n_123;
wire n_163;
wire n_115;
wire n_74;
wire n_199;
wire n_121;
wire n_116;
wire n_44;
wire n_66;
wire n_159;
wire n_34;
wire n_39;
wire n_99;
wire n_181;
wire n_205;
wire n_48;
wire n_49;
wire n_170;
wire n_134;
wire n_114;
wire n_37;
wire n_59;
wire n_89;
wire n_161;
wire n_135;
wire n_162;
wire n_40;
wire n_109;
wire n_120;
wire n_158;
wire n_38;
wire n_124;
wire n_168;
wire n_107;
wire n_208;
wire n_179;
wire n_154;
wire n_164;
wire n_143;
wire n_178;
wire n_129;
wire n_67;
wire n_171;
wire n_177;
wire n_206;
wire n_142;
wire n_47;
wire n_88;
wire n_152;
wire n_93;
wire n_146;
wire n_54;
wire n_32;
wire n_185;
wire n_83;
wire n_202;
wire n_113;

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_2),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_16),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_1),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_4),
.Y(n_37)
);

INVx1_ASAP7_75t_SL g38 ( 
.A(n_24),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_16),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_19),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_21),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_28),
.Y(n_42)
);

INVxp33_ASAP7_75t_L g43 ( 
.A(n_1),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_5),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_33),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_33),
.Y(n_46)
);

CKINVDCx20_ASAP7_75t_R g47 ( 
.A(n_38),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_33),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_39),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_39),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_46),
.Y(n_51)
);

A2O1A1Ixp33_ASAP7_75t_L g52 ( 
.A1(n_45),
.A2(n_46),
.B(n_49),
.C(n_50),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_45),
.Y(n_53)
);

NAND2x1p5_ASAP7_75t_L g54 ( 
.A(n_46),
.B(n_32),
.Y(n_54)
);

BUFx3_ASAP7_75t_L g55 ( 
.A(n_49),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_SL g56 ( 
.A(n_48),
.B(n_32),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_50),
.Y(n_57)
);

AO22x2_ASAP7_75t_L g58 ( 
.A1(n_50),
.A2(n_36),
.B1(n_35),
.B2(n_34),
.Y(n_58)
);

A2O1A1Ixp33_ASAP7_75t_L g59 ( 
.A1(n_52),
.A2(n_48),
.B(n_35),
.C(n_34),
.Y(n_59)
);

AOI21xp5_ASAP7_75t_L g60 ( 
.A1(n_56),
.A2(n_52),
.B(n_58),
.Y(n_60)
);

AND2x4_ASAP7_75t_L g61 ( 
.A(n_56),
.B(n_55),
.Y(n_61)
);

A2O1A1Ixp33_ASAP7_75t_SL g62 ( 
.A1(n_51),
.A2(n_40),
.B(n_37),
.C(n_36),
.Y(n_62)
);

INVx5_ASAP7_75t_L g63 ( 
.A(n_55),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_58),
.Y(n_64)
);

O2A1O1Ixp33_ASAP7_75t_SL g65 ( 
.A1(n_53),
.A2(n_41),
.B(n_40),
.C(n_37),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_51),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_58),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_54),
.B(n_43),
.Y(n_68)
);

NAND2xp5_ASAP7_75t_L g69 ( 
.A(n_68),
.B(n_54),
.Y(n_69)
);

NOR2xp33_ASAP7_75t_L g70 ( 
.A(n_68),
.B(n_61),
.Y(n_70)
);

OAI21xp5_ASAP7_75t_L g71 ( 
.A1(n_66),
.A2(n_54),
.B(n_53),
.Y(n_71)
);

OAI22xp5_ASAP7_75t_L g72 ( 
.A1(n_64),
.A2(n_54),
.B1(n_58),
.B2(n_47),
.Y(n_72)
);

NOR2x1p5_ASAP7_75t_L g73 ( 
.A(n_64),
.B(n_47),
.Y(n_73)
);

INVx3_ASAP7_75t_SL g74 ( 
.A(n_63),
.Y(n_74)
);

AOI22xp5_ASAP7_75t_L g75 ( 
.A1(n_61),
.A2(n_58),
.B1(n_55),
.B2(n_57),
.Y(n_75)
);

AOI22x1_ASAP7_75t_L g76 ( 
.A1(n_60),
.A2(n_58),
.B1(n_51),
.B2(n_57),
.Y(n_76)
);

A2O1A1Ixp33_ASAP7_75t_L g77 ( 
.A1(n_60),
.A2(n_55),
.B(n_51),
.C(n_41),
.Y(n_77)
);

OAI22xp5_ASAP7_75t_L g78 ( 
.A1(n_75),
.A2(n_72),
.B1(n_67),
.B2(n_69),
.Y(n_78)
);

INVxp67_ASAP7_75t_L g79 ( 
.A(n_70),
.Y(n_79)
);

NAND2xp33_ASAP7_75t_R g80 ( 
.A(n_71),
.B(n_67),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_76),
.Y(n_81)
);

AND2x2_ASAP7_75t_L g82 ( 
.A(n_73),
.B(n_66),
.Y(n_82)
);

NOR3xp33_ASAP7_75t_SL g83 ( 
.A(n_77),
.B(n_59),
.C(n_42),
.Y(n_83)
);

NAND2xp5_ASAP7_75t_L g84 ( 
.A(n_73),
.B(n_66),
.Y(n_84)
);

AO21x2_ASAP7_75t_L g85 ( 
.A1(n_81),
.A2(n_62),
.B(n_65),
.Y(n_85)
);

A2O1A1Ixp33_ASAP7_75t_L g86 ( 
.A1(n_79),
.A2(n_83),
.B(n_78),
.C(n_84),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_82),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_82),
.Y(n_88)
);

OR2x2_ASAP7_75t_L g89 ( 
.A(n_78),
.B(n_61),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_82),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_87),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_87),
.Y(n_92)
);

INVxp67_ASAP7_75t_SL g93 ( 
.A(n_89),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_89),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_88),
.Y(n_95)
);

INVxp67_ASAP7_75t_L g96 ( 
.A(n_88),
.Y(n_96)
);

INVx1_ASAP7_75t_L g97 ( 
.A(n_90),
.Y(n_97)
);

AND2x4_ASAP7_75t_SL g98 ( 
.A(n_90),
.B(n_83),
.Y(n_98)
);

INVx1_ASAP7_75t_SL g99 ( 
.A(n_95),
.Y(n_99)
);

INVx1_ASAP7_75t_L g100 ( 
.A(n_91),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_91),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_92),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_92),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_97),
.Y(n_104)
);

INVx2_ASAP7_75t_L g105 ( 
.A(n_95),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_97),
.Y(n_106)
);

OR2x6_ASAP7_75t_L g107 ( 
.A(n_94),
.B(n_96),
.Y(n_107)
);

OR2x6_ASAP7_75t_L g108 ( 
.A(n_94),
.B(n_86),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_95),
.Y(n_109)
);

OR2x2_ASAP7_75t_L g110 ( 
.A(n_94),
.B(n_84),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_96),
.Y(n_111)
);

OAI21xp33_ASAP7_75t_L g112 ( 
.A1(n_108),
.A2(n_98),
.B(n_93),
.Y(n_112)
);

AND2x2_ASAP7_75t_L g113 ( 
.A(n_105),
.B(n_93),
.Y(n_113)
);

HB1xp67_ASAP7_75t_L g114 ( 
.A(n_99),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_100),
.Y(n_115)
);

OAI21xp5_ASAP7_75t_L g116 ( 
.A1(n_108),
.A2(n_79),
.B(n_62),
.Y(n_116)
);

NAND2xp5_ASAP7_75t_L g117 ( 
.A(n_101),
.B(n_98),
.Y(n_117)
);

INVx1_ASAP7_75t_SL g118 ( 
.A(n_105),
.Y(n_118)
);

OR2x2_ASAP7_75t_L g119 ( 
.A(n_107),
.B(n_98),
.Y(n_119)
);

AOI21xp5_ASAP7_75t_L g120 ( 
.A1(n_108),
.A2(n_81),
.B(n_76),
.Y(n_120)
);

NAND2xp5_ASAP7_75t_L g121 ( 
.A(n_102),
.B(n_98),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_103),
.Y(n_122)
);

AOI221xp5_ASAP7_75t_L g123 ( 
.A1(n_111),
.A2(n_44),
.B1(n_42),
.B2(n_65),
.C(n_58),
.Y(n_123)
);

OR2x2_ASAP7_75t_L g124 ( 
.A(n_107),
.B(n_44),
.Y(n_124)
);

INVx1_ASAP7_75t_L g125 ( 
.A(n_104),
.Y(n_125)
);

NAND2xp5_ASAP7_75t_L g126 ( 
.A(n_106),
.B(n_85),
.Y(n_126)
);

INVx2_ASAP7_75t_L g127 ( 
.A(n_109),
.Y(n_127)
);

AND2x2_ASAP7_75t_L g128 ( 
.A(n_107),
.B(n_85),
.Y(n_128)
);

O2A1O1Ixp33_ASAP7_75t_L g129 ( 
.A1(n_108),
.A2(n_61),
.B(n_85),
.C(n_74),
.Y(n_129)
);

OAI21xp5_ASAP7_75t_L g130 ( 
.A1(n_110),
.A2(n_61),
.B(n_80),
.Y(n_130)
);

INVx2_ASAP7_75t_L g131 ( 
.A(n_107),
.Y(n_131)
);

OAI21xp33_ASAP7_75t_SL g132 ( 
.A1(n_119),
.A2(n_110),
.B(n_0),
.Y(n_132)
);

NAND2xp5_ASAP7_75t_L g133 ( 
.A(n_115),
.B(n_0),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_115),
.Y(n_134)
);

NOR3x1_ASAP7_75t_L g135 ( 
.A(n_119),
.B(n_3),
.C(n_2),
.Y(n_135)
);

OR2x2_ASAP7_75t_L g136 ( 
.A(n_114),
.B(n_3),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_122),
.Y(n_137)
);

OR2x2_ASAP7_75t_L g138 ( 
.A(n_118),
.B(n_4),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_122),
.Y(n_139)
);

NAND2xp5_ASAP7_75t_L g140 ( 
.A(n_125),
.B(n_5),
.Y(n_140)
);

INVxp67_ASAP7_75t_L g141 ( 
.A(n_124),
.Y(n_141)
);

INVx1_ASAP7_75t_L g142 ( 
.A(n_125),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_124),
.Y(n_143)
);

AND2x2_ASAP7_75t_L g144 ( 
.A(n_128),
.B(n_6),
.Y(n_144)
);

NAND2xp5_ASAP7_75t_L g145 ( 
.A(n_113),
.B(n_6),
.Y(n_145)
);

INVx1_ASAP7_75t_L g146 ( 
.A(n_127),
.Y(n_146)
);

NAND2xp5_ASAP7_75t_L g147 ( 
.A(n_113),
.B(n_7),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_127),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_127),
.Y(n_149)
);

NAND2xp5_ASAP7_75t_SL g150 ( 
.A(n_112),
.B(n_74),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_126),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_117),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_126),
.Y(n_153)
);

NAND2xp5_ASAP7_75t_L g154 ( 
.A(n_121),
.B(n_7),
.Y(n_154)
);

INVx1_ASAP7_75t_L g155 ( 
.A(n_117),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_118),
.Y(n_156)
);

AOI221xp5_ASAP7_75t_L g157 ( 
.A1(n_141),
.A2(n_112),
.B1(n_129),
.B2(n_120),
.C(n_116),
.Y(n_157)
);

NOR2xp33_ASAP7_75t_R g158 ( 
.A(n_144),
.B(n_121),
.Y(n_158)
);

NAND4xp25_ASAP7_75t_L g159 ( 
.A(n_135),
.B(n_129),
.C(n_120),
.D(n_116),
.Y(n_159)
);

OAI221xp5_ASAP7_75t_L g160 ( 
.A1(n_132),
.A2(n_130),
.B1(n_131),
.B2(n_123),
.C(n_128),
.Y(n_160)
);

INVx2_ASAP7_75t_SL g161 ( 
.A(n_156),
.Y(n_161)
);

AOI221xp5_ASAP7_75t_L g162 ( 
.A1(n_143),
.A2(n_130),
.B1(n_131),
.B2(n_123),
.C(n_8),
.Y(n_162)
);

OAI21xp5_ASAP7_75t_SL g163 ( 
.A1(n_150),
.A2(n_131),
.B(n_8),
.Y(n_163)
);

OAI21xp5_ASAP7_75t_SL g164 ( 
.A1(n_150),
.A2(n_144),
.B(n_136),
.Y(n_164)
);

AOI221x1_ASAP7_75t_SL g165 ( 
.A1(n_145),
.A2(n_10),
.B1(n_9),
.B2(n_11),
.C(n_13),
.Y(n_165)
);

AOI22xp5_ASAP7_75t_L g166 ( 
.A1(n_152),
.A2(n_74),
.B1(n_10),
.B2(n_9),
.Y(n_166)
);

AND2x2_ASAP7_75t_L g167 ( 
.A(n_155),
.B(n_11),
.Y(n_167)
);

OAI221xp5_ASAP7_75t_SL g168 ( 
.A1(n_136),
.A2(n_17),
.B1(n_13),
.B2(n_18),
.C(n_19),
.Y(n_168)
);

INVx1_ASAP7_75t_L g169 ( 
.A(n_134),
.Y(n_169)
);

AOI221x1_ASAP7_75t_L g170 ( 
.A1(n_133),
.A2(n_18),
.B1(n_17),
.B2(n_20),
.C(n_22),
.Y(n_170)
);

AOI221xp5_ASAP7_75t_L g171 ( 
.A1(n_154),
.A2(n_22),
.B1(n_20),
.B2(n_23),
.C(n_24),
.Y(n_171)
);

AOI21xp5_ASAP7_75t_L g172 ( 
.A1(n_147),
.A2(n_63),
.B(n_23),
.Y(n_172)
);

OAI21xp5_ASAP7_75t_SL g173 ( 
.A1(n_138),
.A2(n_26),
.B(n_25),
.Y(n_173)
);

NOR2x1_ASAP7_75t_L g174 ( 
.A(n_138),
.B(n_25),
.Y(n_174)
);

AOI221xp5_ASAP7_75t_L g175 ( 
.A1(n_140),
.A2(n_27),
.B1(n_26),
.B2(n_28),
.C(n_29),
.Y(n_175)
);

CKINVDCx20_ASAP7_75t_R g176 ( 
.A(n_137),
.Y(n_176)
);

OAI211xp5_ASAP7_75t_L g177 ( 
.A1(n_151),
.A2(n_31),
.B(n_30),
.C(n_27),
.Y(n_177)
);

AND2x2_ASAP7_75t_L g178 ( 
.A(n_151),
.B(n_30),
.Y(n_178)
);

INVx1_ASAP7_75t_L g179 ( 
.A(n_139),
.Y(n_179)
);

NOR2x1p5_ASAP7_75t_L g180 ( 
.A(n_159),
.B(n_153),
.Y(n_180)
);

OAI21x1_ASAP7_75t_SL g181 ( 
.A1(n_164),
.A2(n_142),
.B(n_156),
.Y(n_181)
);

NOR3xp33_ASAP7_75t_L g182 ( 
.A(n_168),
.B(n_153),
.C(n_148),
.Y(n_182)
);

NOR2x1p5_ASAP7_75t_L g183 ( 
.A(n_163),
.B(n_178),
.Y(n_183)
);

NAND3x1_ASAP7_75t_L g184 ( 
.A(n_174),
.B(n_148),
.C(n_146),
.Y(n_184)
);

CKINVDCx6p67_ASAP7_75t_R g185 ( 
.A(n_176),
.Y(n_185)
);

O2A1O1Ixp33_ASAP7_75t_SL g186 ( 
.A1(n_173),
.A2(n_149),
.B(n_31),
.C(n_12),
.Y(n_186)
);

AOI321xp33_ASAP7_75t_L g187 ( 
.A1(n_160),
.A2(n_14),
.A3(n_15),
.B1(n_63),
.B2(n_157),
.C(n_162),
.Y(n_187)
);

AOI222xp33_ASAP7_75t_L g188 ( 
.A1(n_178),
.A2(n_63),
.B1(n_175),
.B2(n_171),
.C1(n_167),
.C2(n_177),
.Y(n_188)
);

OAI21xp33_ASAP7_75t_L g189 ( 
.A1(n_158),
.A2(n_63),
.B(n_161),
.Y(n_189)
);

INVx1_ASAP7_75t_SL g190 ( 
.A(n_176),
.Y(n_190)
);

NAND2xp5_ASAP7_75t_SL g191 ( 
.A(n_161),
.B(n_63),
.Y(n_191)
);

INVx1_ASAP7_75t_L g192 ( 
.A(n_169),
.Y(n_192)
);

NAND3xp33_ASAP7_75t_L g193 ( 
.A(n_170),
.B(n_63),
.C(n_172),
.Y(n_193)
);

AOI221xp5_ASAP7_75t_L g194 ( 
.A1(n_165),
.A2(n_63),
.B1(n_158),
.B2(n_179),
.C(n_166),
.Y(n_194)
);

INVx1_ASAP7_75t_L g195 ( 
.A(n_192),
.Y(n_195)
);

BUFx2_ASAP7_75t_L g196 ( 
.A(n_185),
.Y(n_196)
);

AOI211xp5_ASAP7_75t_L g197 ( 
.A1(n_186),
.A2(n_194),
.B(n_189),
.C(n_193),
.Y(n_197)
);

XNOR2xp5_ASAP7_75t_L g198 ( 
.A(n_183),
.B(n_190),
.Y(n_198)
);

CKINVDCx20_ASAP7_75t_R g199 ( 
.A(n_191),
.Y(n_199)
);

NOR2xp33_ASAP7_75t_L g200 ( 
.A(n_191),
.B(n_182),
.Y(n_200)
);

CKINVDCx5p33_ASAP7_75t_R g201 ( 
.A(n_180),
.Y(n_201)
);

CKINVDCx5p33_ASAP7_75t_R g202 ( 
.A(n_184),
.Y(n_202)
);

INVx1_ASAP7_75t_L g203 ( 
.A(n_195),
.Y(n_203)
);

INVx1_ASAP7_75t_L g204 ( 
.A(n_195),
.Y(n_204)
);

HB1xp67_ASAP7_75t_L g205 ( 
.A(n_196),
.Y(n_205)
);

OAI221xp5_ASAP7_75t_L g206 ( 
.A1(n_198),
.A2(n_187),
.B1(n_182),
.B2(n_188),
.C(n_181),
.Y(n_206)
);

INVx1_ASAP7_75t_L g207 ( 
.A(n_205),
.Y(n_207)
);

OAI22xp5_ASAP7_75t_L g208 ( 
.A1(n_206),
.A2(n_201),
.B1(n_202),
.B2(n_198),
.Y(n_208)
);

AOI211xp5_ASAP7_75t_L g209 ( 
.A1(n_208),
.A2(n_196),
.B(n_200),
.C(n_197),
.Y(n_209)
);

AOI211xp5_ASAP7_75t_SL g210 ( 
.A1(n_209),
.A2(n_207),
.B(n_197),
.C(n_199),
.Y(n_210)
);

AOI221xp5_ASAP7_75t_L g211 ( 
.A1(n_210),
.A2(n_203),
.B1(n_204),
.B2(n_208),
.C(n_209),
.Y(n_211)
);


endmodule