module fake_netlist_754_325_n_44 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_44);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_44;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_6),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_8),
.B(n_5),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

NAND2xp33_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_2),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_19),
.B(n_1),
.Y(n_29)
);

AO21x1_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_21),
.B(n_26),
.Y(n_30)
);

OAI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_20),
.B1(n_25),
.B2(n_23),
.Y(n_31)
);

AO21x2_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_22),
.B(n_24),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OAI222xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_24),
.B1(n_16),
.B2(n_1),
.C1(n_17),
.C2(n_5),
.Y(n_34)
);

AOI33xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_27),
.A3(n_18),
.B1(n_17),
.B2(n_7),
.B3(n_3),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_34),
.B(n_27),
.Y(n_37)
);

AND3x4_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_34),
.C(n_18),
.Y(n_38)
);

AOI221xp5_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_32),
.B1(n_27),
.B2(n_9),
.C(n_12),
.Y(n_39)
);

CKINVDCx20_ASAP7_75t_R g40 ( 
.A(n_38),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

AOI222xp33_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_13),
.B1(n_14),
.B2(n_15),
.C1(n_27),
.C2(n_42),
.Y(n_44)
);


endmodule