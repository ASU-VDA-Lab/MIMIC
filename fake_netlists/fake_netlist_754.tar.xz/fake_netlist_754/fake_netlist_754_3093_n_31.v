module fake_netlist_754_3093_n_31 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_31);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_31;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_30;
wire n_9;
wire n_25;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;
wire n_29;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_0),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

BUFx8_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_4),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_SL g15 ( 
.A(n_12),
.B(n_4),
.Y(n_15)
);

INVx4_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_6),
.B(n_5),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_16),
.Y(n_18)
);

AO31x2_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_9),
.A3(n_6),
.B(n_8),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_SL g20 ( 
.A(n_14),
.B(n_9),
.C(n_10),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_16),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_20),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_15),
.B1(n_17),
.B2(n_13),
.C(n_19),
.Y(n_23)
);

NOR4xp25_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_19),
.C(n_6),
.D(n_1),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_13),
.B1(n_21),
.B2(n_19),
.Y(n_25)
);

OR2x6_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_1),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_27),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_28),
.A2(n_25),
.B1(n_24),
.B2(n_2),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_29),
.A2(n_28),
.B1(n_30),
.B2(n_3),
.Y(n_31)
);


endmodule