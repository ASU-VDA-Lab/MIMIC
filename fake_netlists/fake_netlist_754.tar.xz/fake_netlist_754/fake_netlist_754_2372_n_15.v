module fake_netlist_754_2372_n_15 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_7;
wire n_13;
wire n_8;

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_0),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.C(n_4),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_11),
.C(n_5),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_6),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);


endmodule