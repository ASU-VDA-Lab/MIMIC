module fake_netlist_754_301_n_40 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_40);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_40;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

AND2x2_ASAP7_75t_SL g19 ( 
.A(n_18),
.B(n_6),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_2),
.B(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_27),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_26),
.A2(n_19),
.B1(n_24),
.B2(n_23),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_20),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_33),
.B(n_0),
.Y(n_35)
);

AOI31xp33_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_5),
.A3(n_4),
.B(n_3),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_10),
.B(n_8),
.Y(n_37)
);

NOR3xp33_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_14),
.C(n_13),
.Y(n_38)
);

INVx8_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_37),
.B1(n_16),
.B2(n_15),
.Y(n_40)
);


endmodule