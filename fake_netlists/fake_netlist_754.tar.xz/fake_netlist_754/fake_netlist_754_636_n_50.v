module fake_netlist_754_636_n_50 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_0, n_8, n_50);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_0;
input n_8;

output n_50;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVx1_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_18),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_4),
.B(n_14),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_16),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_10),
.B(n_16),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

INVx3_ASAP7_75t_SL g31 ( 
.A(n_21),
.Y(n_31)
);

AO21x1_ASAP7_75t_L g32 ( 
.A1(n_28),
.A2(n_27),
.B(n_19),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_29),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NOR2x1_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_26),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVxp67_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AO22x2_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_33),
.B1(n_32),
.B2(n_25),
.Y(n_40)
);

AOI21xp33_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_32),
.B(n_36),
.Y(n_41)
);

A2O1A1Ixp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_25),
.B(n_23),
.C(n_30),
.Y(n_42)
);

OAI21xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_23),
.B(n_15),
.Y(n_43)
);

NAND4xp75_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_18),
.C(n_17),
.D(n_15),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_17),
.C(n_2),
.Y(n_45)
);

NOR2xp67_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_5),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_7),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_SL g48 ( 
.A1(n_44),
.A2(n_12),
.B1(n_9),
.B2(n_8),
.Y(n_48)
);

INVxp33_ASAP7_75t_SL g49 ( 
.A(n_48),
.Y(n_49)
);

AOI22x1_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_45),
.B1(n_47),
.B2(n_13),
.Y(n_50)
);


endmodule