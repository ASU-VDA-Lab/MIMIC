module fake_netlist_754_1237_n_47 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_47);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_47;

wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_37;
wire n_27;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_19),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_18),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_4),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_17),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_25),
.B(n_1),
.C(n_0),
.Y(n_32)
);

NOR3xp33_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_5),
.C(n_2),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_29),
.A2(n_8),
.B(n_7),
.C(n_6),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_28),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_36),
.Y(n_39)
);

OAI221xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_27),
.B1(n_34),
.B2(n_30),
.C(n_31),
.Y(n_40)
);

NOR3xp33_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_26),
.C(n_24),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_12),
.B(n_10),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_13),
.Y(n_43)
);

BUFx6f_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

CKINVDCx20_ASAP7_75t_R g45 ( 
.A(n_43),
.Y(n_45)
);

AOI22x1_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_20),
.B1(n_16),
.B2(n_14),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_21),
.B1(n_22),
.B2(n_46),
.Y(n_47)
);


endmodule