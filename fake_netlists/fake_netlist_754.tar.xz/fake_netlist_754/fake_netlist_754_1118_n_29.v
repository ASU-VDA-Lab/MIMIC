module fake_netlist_754_1118_n_29 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_29);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_29;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_6),
.B(n_2),
.Y(n_13)
);

OA21x2_ASAP7_75t_L g14 ( 
.A1(n_0),
.A2(n_5),
.B(n_3),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_10),
.Y(n_16)
);

INVx4_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_17),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_12),
.Y(n_19)
);

CKINVDCx6p67_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_16),
.Y(n_21)
);

O2A1O1Ixp5_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_12),
.B(n_11),
.C(n_13),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_11),
.B1(n_19),
.B2(n_20),
.C(n_6),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_14),
.B(n_1),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_SL g25 ( 
.A(n_22),
.B(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_24),
.B(n_7),
.Y(n_27)
);

INVx6_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B1(n_14),
.B2(n_9),
.Y(n_29)
);


endmodule