module fake_netlist_754_3010_n_52 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_52);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_52;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_12),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_7),
.B(n_0),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_5),
.B(n_4),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_25),
.B(n_4),
.C(n_1),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_5),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_16),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_23),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_28),
.B(n_22),
.Y(n_33)
);

CKINVDCx11_ASAP7_75t_R g34 ( 
.A(n_31),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_29),
.B1(n_27),
.B2(n_22),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

OR2x4_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_34),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_R g40 ( 
.A(n_37),
.B(n_16),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_29),
.B1(n_19),
.B2(n_20),
.C(n_24),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_2),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

CKINVDCx16_ASAP7_75t_R g44 ( 
.A(n_43),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_40),
.B1(n_9),
.B2(n_3),
.C(n_8),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

INVx1_ASAP7_75t_SL g47 ( 
.A(n_44),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_10),
.Y(n_48)
);

INVx1_ASAP7_75t_SL g49 ( 
.A(n_45),
.Y(n_49)
);

INVxp67_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_48),
.Y(n_51)
);

AOI222xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_11),
.B1(n_14),
.B2(n_48),
.C1(n_49),
.C2(n_51),
.Y(n_52)
);


endmodule