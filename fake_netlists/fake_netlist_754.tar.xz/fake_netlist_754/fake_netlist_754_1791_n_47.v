module fake_netlist_754_1791_n_47 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_47);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_47;

wire n_46;
wire n_44;
wire n_36;
wire n_39;
wire n_34;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_1),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_11),
.B(n_23),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_15),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_12),
.B(n_8),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_16),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_9),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_6),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_3),
.B(n_2),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

AOI21xp5_ASAP7_75t_L g34 ( 
.A1(n_27),
.A2(n_5),
.B(n_4),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_33),
.B(n_24),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_31),
.B1(n_24),
.B2(n_26),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_31),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

OAI21xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_30),
.B(n_25),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_37),
.B1(n_34),
.B2(n_28),
.C(n_16),
.Y(n_41)
);

AOI221xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_37),
.B1(n_19),
.B2(n_17),
.C(n_18),
.Y(n_42)
);

OAI211xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_19),
.B(n_18),
.C(n_17),
.Y(n_43)
);

NAND3xp33_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_21),
.C(n_7),
.Y(n_44)
);

XOR2xp5_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_21),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_14),
.B1(n_13),
.B2(n_10),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_20),
.B1(n_22),
.B2(n_46),
.Y(n_47)
);


endmodule