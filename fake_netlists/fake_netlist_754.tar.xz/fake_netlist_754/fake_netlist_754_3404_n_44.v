module fake_netlist_754_3404_n_44 (n_12, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_44);

input n_12;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_44;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_15;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_4),
.B(n_0),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_3),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_0),
.B(n_11),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_3),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_SL g23 ( 
.A(n_15),
.B(n_1),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_21),
.B(n_8),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_16),
.B1(n_22),
.B2(n_19),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

NOR2x1_ASAP7_75t_SL g29 ( 
.A(n_26),
.B(n_22),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_R g30 ( 
.A(n_28),
.B(n_17),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_18),
.B1(n_16),
.B2(n_19),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_23),
.B1(n_19),
.B2(n_16),
.C(n_1),
.Y(n_32)
);

AND3x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_16),
.C(n_23),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_28),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_29),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_2),
.Y(n_37)
);

XNOR2xp5_ASAP7_75t_L g38 ( 
.A(n_33),
.B(n_4),
.Y(n_38)
);

A2O1A1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_34),
.B(n_37),
.C(n_19),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_38),
.B1(n_29),
.B2(n_5),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_6),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_41),
.B1(n_7),
.B2(n_14),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_43),
.A2(n_42),
.B1(n_41),
.B2(n_7),
.Y(n_44)
);


endmodule