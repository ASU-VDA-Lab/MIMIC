module fake_netlist_754_2678_n_25 (n_1, n_2, n_3, n_4, n_5, n_0, n_25);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_25;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_24;
wire n_10;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_5),
.Y(n_6)
);

INVx2_ASAP7_75t_SL g7 ( 
.A(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_5),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_1),
.A2(n_4),
.B1(n_5),
.B2(n_0),
.Y(n_9)
);

NAND2xp33_ASAP7_75t_L g10 ( 
.A(n_2),
.B(n_4),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_2),
.B(n_0),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_8),
.B(n_2),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_8),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

AOI211x1_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_17),
.B(n_14),
.C(n_9),
.Y(n_20)
);

NOR4xp25_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_10),
.C(n_16),
.D(n_17),
.Y(n_21)
);

NAND5xp2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_4),
.C(n_3),
.D(n_11),
.E(n_19),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_3),
.B1(n_15),
.B2(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);


endmodule