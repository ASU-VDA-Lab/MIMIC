module fake_netlist_754_2042_n_12 (n_0, n_2, n_1, n_3, n_12);

input n_0;
input n_2;
input n_1;
input n_3;

output n_12;

wire n_11;
wire n_9;
wire n_10;
wire n_4;
wire n_5;
wire n_7;
wire n_6;
wire n_8;

NOR2xp33_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_3),
.Y(n_4)
);

INVxp67_ASAP7_75t_SL g5 ( 
.A(n_3),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_4),
.Y(n_8)
);

NAND3xp33_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_7),
.C(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_2),
.B(n_9),
.Y(n_12)
);


endmodule