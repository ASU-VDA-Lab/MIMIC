module fake_netlist_754_536_n_8 (n_0, n_2, n_1, n_3, n_8);

input n_0;
input n_2;
input n_1;
input n_3;

output n_8;

wire n_4;
wire n_5;
wire n_7;
wire n_6;

INVx2_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AOI22xp33_ASAP7_75t_L g5 ( 
.A1(n_0),
.A2(n_3),
.B1(n_1),
.B2(n_2),
.Y(n_5)
);

AOI21xp5_ASAP7_75t_SL g6 ( 
.A1(n_2),
.A2(n_0),
.B(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_1),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_5),
.B(n_6),
.Y(n_8)
);


endmodule