module fake_netlist_754_3377_n_24 (n_1, n_2, n_3, n_4, n_0, n_24);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_24;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_8;

NAND2xp33_ASAP7_75t_SL g5 ( 
.A(n_1),
.B(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_4),
.Y(n_11)
);

OA21x2_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_7),
.B(n_3),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_7),
.Y(n_16)
);

OAI21xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_14),
.B(n_12),
.Y(n_17)
);

NAND4xp25_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_5),
.C(n_4),
.D(n_12),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_17),
.B(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

NAND2x1p5_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_16),
.Y(n_21)
);

XNOR2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_12),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

AO21x2_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_19),
.B(n_23),
.Y(n_24)
);


endmodule