module fake_netlist_754_1197_n_19 (n_0, n_2, n_1, n_3, n_19);

input n_0;
input n_2;
input n_1;
input n_3;

output n_19;

wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_4;
wire n_7;
wire n_17;
wire n_15;
wire n_12;
wire n_8;

AND2x2_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_3),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_3),
.B(n_2),
.Y(n_5)
);

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_1),
.A2(n_2),
.B1(n_3),
.B2(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_0),
.Y(n_9)
);

BUFx2_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

INVxp67_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_4),
.Y(n_12)
);

AOI33xp33_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_6),
.A3(n_7),
.B1(n_2),
.B2(n_1),
.B3(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_10),
.B2(n_13),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_12),
.B1(n_6),
.B2(n_10),
.C(n_0),
.Y(n_17)
);

OR5x1_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_1),
.C(n_0),
.D(n_2),
.E(n_3),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C1(n_17),
.C2(n_7),
.Y(n_19)
);


endmodule