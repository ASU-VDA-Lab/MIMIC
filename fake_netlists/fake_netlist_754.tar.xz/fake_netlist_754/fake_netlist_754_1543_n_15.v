module fake_netlist_754_1543_n_15 (n_1, n_2, n_3, n_4, n_5, n_0, n_15);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_15;

wire n_12;
wire n_14;
wire n_8;
wire n_9;
wire n_10;
wire n_7;
wire n_13;
wire n_6;
wire n_11;

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

OAI22xp33_ASAP7_75t_L g7 ( 
.A1(n_3),
.A2(n_0),
.B1(n_5),
.B2(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_9)
);

INVxp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

OAI211xp5_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_7),
.B(n_8),
.C(n_0),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_1),
.B1(n_4),
.B2(n_3),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_1),
.B1(n_13),
.B2(n_9),
.Y(n_15)
);


endmodule