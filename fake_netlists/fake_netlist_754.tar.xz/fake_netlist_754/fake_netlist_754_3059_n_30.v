module fake_netlist_754_3059_n_30 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_30);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_30;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_29;

INVx4_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

OAI21x1_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_9),
.B(n_8),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_12),
.B(n_10),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_4),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_13),
.Y(n_23)
);

OAI211xp5_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_19),
.B(n_17),
.C(n_16),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_22),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_22),
.Y(n_26)
);

AOI211xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B(n_20),
.C(n_14),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_14),
.B1(n_7),
.B2(n_4),
.C(n_6),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_20),
.B(n_14),
.Y(n_29)
);

AO21x2_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_28),
.B(n_7),
.Y(n_30)
);


endmodule