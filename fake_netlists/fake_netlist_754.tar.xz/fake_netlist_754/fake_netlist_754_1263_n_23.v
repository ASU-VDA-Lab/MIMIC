module fake_netlist_754_1263_n_23 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_23);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_23;

wire n_20;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_17;
wire n_21;
wire n_15;
wire n_19;
wire n_12;

INVx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AND2x6_ASAP7_75t_L g11 ( 
.A(n_4),
.B(n_0),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_1),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_9),
.Y(n_14)
);

BUFx4f_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_14),
.Y(n_18)
);

OAI21xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_14),
.B(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_12),
.Y(n_21)
);

XNOR2x1_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_2),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_6),
.B1(n_5),
.B2(n_3),
.Y(n_23)
);


endmodule