module fake_netlist_754_2336_n_50 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_50);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_50;

wire n_46;
wire n_44;
wire n_36;
wire n_39;
wire n_34;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVx1_ASAP7_75t_L g24 ( 
.A(n_11),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_2),
.B(n_1),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_12),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_7),
.B(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_14),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_16),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_19),
.B(n_5),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_21),
.Y(n_33)
);

AND3x1_ASAP7_75t_SL g34 ( 
.A(n_24),
.B(n_17),
.C(n_16),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_35)
);

BUFx3_ASAP7_75t_L g36 ( 
.A(n_30),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_31),
.B1(n_33),
.B2(n_27),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_27),
.Y(n_39)
);

OAI221xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_28),
.B1(n_29),
.B2(n_25),
.C(n_32),
.Y(n_40)
);

NAND2x1p5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_25),
.Y(n_41)
);

OAI211xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_34),
.B(n_29),
.C(n_26),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_39),
.Y(n_45)
);

NOR2x1_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_34),
.Y(n_46)
);

AOI311xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_21),
.A3(n_20),
.B(n_18),
.C(n_0),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_4),
.Y(n_48)
);

OR3x1_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_9),
.C(n_6),
.Y(n_49)
);

AOI322xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_48),
.A3(n_15),
.B1(n_13),
.B2(n_10),
.C1(n_23),
.C2(n_22),
.Y(n_50)
);


endmodule