module fake_netlist_736_157_n_17 (n_1, n_2, n_3, n_4, n_0, n_17);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_17;

wire n_12;
wire n_15;
wire n_14;
wire n_9;
wire n_11;
wire n_10;
wire n_5;
wire n_7;
wire n_13;
wire n_16;
wire n_6;
wire n_8;

INVx2_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.C(n_3),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_0),
.Y(n_10)
);

OAI31xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_4),
.A3(n_3),
.B(n_0),
.Y(n_11)
);

OAI322xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_2),
.A3(n_3),
.B1(n_4),
.B2(n_7),
.C1(n_6),
.C2(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_12),
.Y(n_13)
);

NAND4xp25_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_10),
.C(n_2),
.D(n_3),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI222xp33_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_2),
.B1(n_4),
.B2(n_11),
.C1(n_12),
.C2(n_9),
.Y(n_16)
);

OAI222xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_4),
.B1(n_12),
.B2(n_13),
.C1(n_14),
.C2(n_16),
.Y(n_17)
);


endmodule