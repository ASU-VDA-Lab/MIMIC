module fake_netlist_736_815_n_18 (n_1, n_2, n_3, n_4, n_5, n_0, n_18);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_18;

wire n_12;
wire n_15;
wire n_14;
wire n_11;
wire n_9;
wire n_10;
wire n_13;
wire n_7;
wire n_17;
wire n_16;
wire n_6;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_1),
.Y(n_9)
);

INVx5_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

OAI21xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_7),
.B(n_8),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_7),
.Y(n_12)
);

OAI321xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_8),
.A3(n_1),
.B1(n_10),
.B2(n_2),
.C(n_0),
.Y(n_13)
);

OAI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B(n_10),
.C(n_0),
.Y(n_14)
);

INVxp33_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B1(n_3),
.B2(n_2),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_3),
.B1(n_5),
.B2(n_16),
.Y(n_18)
);


endmodule