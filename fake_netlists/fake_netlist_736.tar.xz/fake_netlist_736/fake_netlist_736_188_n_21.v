module fake_netlist_736_188_n_21 (n_1, n_2, n_3, n_9, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_21);

input n_1;
input n_2;
input n_3;
input n_9;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_21;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_17;
wire n_15;
wire n_12;
wire n_19;

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_0),
.Y(n_14)
);

NOR2xp67_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_11),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B1(n_12),
.B2(n_7),
.Y(n_16)
);

INVx2_ASAP7_75t_SL g17 ( 
.A(n_16),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_2),
.B(n_1),
.Y(n_18)
);

NAND5xp2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_7),
.C(n_10),
.D(n_4),
.E(n_8),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx2_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);


endmodule