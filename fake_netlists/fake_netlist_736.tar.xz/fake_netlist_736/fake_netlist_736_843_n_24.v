module fake_netlist_736_843_n_24 (n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_6, n_0, n_8, n_24);

input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_24;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;

AOI21x1_ASAP7_75t_L g12 ( 
.A1(n_5),
.A2(n_1),
.B(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_10),
.A2(n_3),
.B1(n_6),
.B2(n_4),
.Y(n_15)
);

INVx5_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

O2A1O1Ixp5_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_2),
.B(n_0),
.C(n_6),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_7),
.B(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVxp67_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

OAI211xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_15),
.B(n_17),
.C(n_18),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_7),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_16),
.B1(n_22),
.B2(n_21),
.Y(n_24)
);


endmodule