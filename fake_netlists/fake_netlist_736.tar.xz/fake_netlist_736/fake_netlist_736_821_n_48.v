module fake_netlist_736_821_n_48 (n_12, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_48);

input n_12;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_48;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_19;
wire n_15;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_12),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_2),
.B(n_6),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_11),
.B(n_14),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_16),
.B(n_1),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_18),
.B(n_1),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_SL g25 ( 
.A(n_20),
.B(n_6),
.C(n_5),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_19),
.A2(n_7),
.B1(n_5),
.B2(n_8),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_21),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_SL g30 ( 
.A(n_27),
.B(n_15),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

OA21x2_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_17),
.B(n_25),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_19),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx5_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_32),
.B1(n_35),
.B2(n_33),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

AOI211xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_22),
.B(n_32),
.C(n_9),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

INVx3_ASAP7_75t_SL g44 ( 
.A(n_41),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_R g45 ( 
.A1(n_42),
.A2(n_36),
.B1(n_44),
.B2(n_43),
.Y(n_45)
);

HB1xp67_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

AOI322xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_10),
.A3(n_13),
.B1(n_22),
.B2(n_32),
.C1(n_47),
.C2(n_45),
.Y(n_48)
);


endmodule