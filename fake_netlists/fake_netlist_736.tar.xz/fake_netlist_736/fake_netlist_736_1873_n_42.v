module fake_netlist_736_1873_n_42 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_42);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_42;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_41;
wire n_29;
wire n_32;

BUFx2_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

INVx4_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_11),
.B(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_13),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_15),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_0),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

NAND2xp33_ASAP7_75t_SL g26 ( 
.A(n_18),
.B(n_14),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_SL g27 ( 
.A(n_21),
.B(n_19),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_21),
.Y(n_28)
);

AOI222xp33_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_19),
.B1(n_20),
.B2(n_22),
.C1(n_24),
.C2(n_14),
.Y(n_29)
);

OAI221xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_25),
.B1(n_27),
.B2(n_28),
.C(n_16),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_20),
.B1(n_17),
.B2(n_16),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_30),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_17),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_1),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_5),
.B1(n_4),
.B2(n_6),
.C(n_8),
.Y(n_37)
);

XNOR2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_37),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_39),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_41),
.A2(n_40),
.B1(n_12),
.B2(n_10),
.Y(n_42)
);


endmodule