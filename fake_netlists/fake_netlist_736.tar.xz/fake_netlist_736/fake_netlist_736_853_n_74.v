module fake_netlist_736_853_n_74 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_74);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_74;

wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_66;
wire n_22;
wire n_62;
wire n_64;
wire n_71;
wire n_72;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_68;
wire n_73;
wire n_49;
wire n_28;
wire n_65;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_57;
wire n_35;
wire n_63;
wire n_25;
wire n_69;
wire n_21;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_67;
wire n_55;
wire n_47;
wire n_29;
wire n_70;
wire n_52;
wire n_54;
wire n_32;

INVx1_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

INVx5_ASAP7_75t_L g22 ( 
.A(n_12),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

BUFx12f_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_13),
.B(n_16),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_4),
.B(n_7),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_6),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_3),
.B(n_5),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_17),
.B(n_10),
.Y(n_31)
);

INVx4_ASAP7_75t_L g32 ( 
.A(n_8),
.Y(n_32)
);

BUFx3_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_26),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_21),
.Y(n_38)
);

BUFx3_ASAP7_75t_L g39 ( 
.A(n_25),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_22),
.B(n_17),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_27),
.B(n_28),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_35),
.B(n_32),
.Y(n_42)
);

BUFx12f_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

OAI21x1_ASAP7_75t_L g44 ( 
.A1(n_37),
.A2(n_30),
.B(n_31),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_34),
.Y(n_45)
);

BUFx6f_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_35),
.Y(n_47)
);

INVx1_ASAP7_75t_SL g48 ( 
.A(n_43),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_33),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_33),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_46),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_46),
.Y(n_53)
);

INVx1_ASAP7_75t_SL g54 ( 
.A(n_50),
.Y(n_54)
);

AOI22xp33_ASAP7_75t_SL g55 ( 
.A1(n_51),
.A2(n_48),
.B1(n_46),
.B2(n_25),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_41),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_53),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

AOI221xp5_ASAP7_75t_L g59 ( 
.A1(n_55),
.A2(n_38),
.B1(n_41),
.B2(n_45),
.C(n_40),
.Y(n_59)
);

NAND3xp33_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_40),
.C(n_29),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_29),
.B1(n_53),
.B2(n_22),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_54),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_58),
.Y(n_63)
);

AND2x4_ASAP7_75t_L g64 ( 
.A(n_62),
.B(n_22),
.Y(n_64)
);

AND2x4_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_18),
.Y(n_65)
);

AOI21xp5_ASAP7_75t_L g66 ( 
.A1(n_59),
.A2(n_22),
.B(n_1),
.Y(n_66)
);

NAND2xp5_ASAP7_75t_L g67 ( 
.A(n_61),
.B(n_18),
.Y(n_67)
);

AO21x2_ASAP7_75t_L g68 ( 
.A1(n_66),
.A2(n_19),
.B(n_2),
.Y(n_68)
);

INVx2_ASAP7_75t_L g69 ( 
.A(n_63),
.Y(n_69)
);

AOI311xp33_ASAP7_75t_L g70 ( 
.A1(n_67),
.A2(n_9),
.A3(n_14),
.B(n_19),
.C(n_64),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_64),
.Y(n_71)
);

OAI22xp5_ASAP7_75t_L g72 ( 
.A1(n_71),
.A2(n_65),
.B1(n_69),
.B2(n_70),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_69),
.Y(n_73)
);

OAI21xp5_ASAP7_75t_L g74 ( 
.A1(n_72),
.A2(n_68),
.B(n_73),
.Y(n_74)
);


endmodule