module fake_netlist_736_686_n_34 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_34);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_34;

wire n_20;
wire n_23;
wire n_22;
wire n_16;
wire n_18;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_2),
.B(n_0),
.Y(n_17)
);

BUFx10_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_5),
.B1(n_9),
.B2(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_7),
.A2(n_4),
.B(n_13),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_19),
.B1(n_20),
.B2(n_18),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

AO21x2_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_21),
.B(n_17),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_22),
.B1(n_18),
.B2(n_21),
.Y(n_28)
);

NOR2x1_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_4),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_6),
.Y(n_30)
);

NAND5xp2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_15),
.C(n_6),
.D(n_8),
.E(n_11),
.Y(n_31)
);

INVxp67_ASAP7_75t_SL g32 ( 
.A(n_29),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_31),
.B1(n_32),
.B2(n_15),
.Y(n_34)
);


endmodule