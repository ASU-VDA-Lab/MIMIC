module fake_netlist_736_839_n_18 (n_1, n_2, n_3, n_4, n_0, n_18);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_18;

wire n_12;
wire n_15;
wire n_14;
wire n_8;
wire n_9;
wire n_10;
wire n_13;
wire n_5;
wire n_7;
wire n_16;
wire n_17;
wire n_6;
wire n_11;

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_2),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_1),
.Y(n_7)
);

INVxp33_ASAP7_75t_SL g8 ( 
.A(n_3),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.Y(n_9)
);

BUFx8_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_0),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_1),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_8),
.B1(n_12),
.B2(n_10),
.C(n_2),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_10),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B1(n_10),
.B2(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);


endmodule