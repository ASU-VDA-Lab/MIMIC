module fake_netlist_736_879_n_23 (n_1, n_2, n_3, n_4, n_5, n_0, n_23);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_23;

wire n_20;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

INVx4_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

AND2x4_ASAP7_75t_SL g9 ( 
.A(n_5),
.B(n_0),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_2),
.Y(n_10)
);

OAI221xp5_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_3),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_1),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_6),
.A2(n_4),
.B(n_3),
.Y(n_14)
);

AO21x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_6),
.B(n_10),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_8),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI22xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_11),
.B1(n_8),
.B2(n_12),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.B1(n_15),
.B2(n_9),
.Y(n_19)
);

OAI221xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_8),
.B1(n_13),
.B2(n_9),
.C(n_15),
.Y(n_20)
);

OAI22x1_ASAP7_75t_SL g21 ( 
.A1(n_19),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_21)
);

AND3x1_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_5),
.C(n_13),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_R g23 ( 
.A1(n_21),
.A2(n_15),
.B1(n_22),
.B2(n_19),
.C(n_11),
.Y(n_23)
);


endmodule