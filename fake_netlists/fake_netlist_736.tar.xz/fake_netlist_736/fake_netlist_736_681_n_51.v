module fake_netlist_736_681_n_51 (n_20, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_51);

input n_20;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_51;

wire n_23;
wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_27;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_20),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_17),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_12),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_6),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_3),
.Y(n_30)
);

CKINVDCx16_ASAP7_75t_R g31 ( 
.A(n_4),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_13),
.Y(n_32)
);

BUFx10_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_23),
.B(n_16),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_29),
.A2(n_19),
.B1(n_18),
.B2(n_0),
.Y(n_36)
);

OAI211xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_25),
.B(n_30),
.C(n_26),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_26),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_34),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

NAND4xp25_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_37),
.C(n_25),
.D(n_27),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_33),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_40),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

AOI322xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_29),
.A3(n_27),
.B1(n_18),
.B2(n_33),
.C1(n_24),
.C2(n_32),
.Y(n_45)
);

INVxp67_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

NOR2x1p5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_1),
.Y(n_47)
);

AND2x4_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_2),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_49)
);

OAI22x1_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_14),
.B1(n_11),
.B2(n_10),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_15),
.B1(n_22),
.B2(n_50),
.Y(n_51)
);


endmodule