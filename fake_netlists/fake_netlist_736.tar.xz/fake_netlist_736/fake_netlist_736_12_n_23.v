module fake_netlist_736_12_n_23 (n_1, n_2, n_3, n_4, n_5, n_0, n_23);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_0;

output n_23;

wire n_20;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_10;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_15;
wire n_12;
wire n_19;
wire n_8;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_2),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_2),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_2),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_5),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

OA21x2_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_4),
.B(n_3),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_3),
.B1(n_6),
.B2(n_7),
.C(n_8),
.Y(n_14)
);

OAI21x1_ASAP7_75t_SL g15 ( 
.A1(n_11),
.A2(n_6),
.B(n_8),
.Y(n_15)
);

NAND3xp33_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_11),
.C(n_8),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_10),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_10),
.Y(n_21)
);

XNOR2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_13),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_20),
.B1(n_16),
.B2(n_19),
.Y(n_23)
);


endmodule