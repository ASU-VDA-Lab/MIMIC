module fake_netlist_736_910_n_12 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_12);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_12;

wire n_9;
wire n_11;
wire n_10;
wire n_7;
wire n_8;

NAND3xp33_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_3),
.C(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

O2A1O1Ixp33_ASAP7_75t_L g9 ( 
.A1(n_0),
.A2(n_5),
.B(n_1),
.C(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

O2A1O1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B(n_7),
.C(n_2),
.Y(n_11)
);

INVxp67_ASAP7_75t_SL g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule