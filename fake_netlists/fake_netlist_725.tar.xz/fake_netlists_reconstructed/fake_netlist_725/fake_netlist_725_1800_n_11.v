module fake_netlist_725_1800_n_11 (n_0, n_1, n_11);

input n_0;
input n_1;

output n_11;

wire n_8;
wire n_2;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_3;
wire n_4;
wire n_5;

INVx1_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

AOI21xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_0),
.Y(n_8)
);

A2O1A1Ixp33_ASAP7_75t_SL g9 ( 
.A1(n_8),
.A2(n_7),
.B(n_6),
.C(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_0),
.B1(n_1),
.B2(n_8),
.Y(n_11)
);


endmodule