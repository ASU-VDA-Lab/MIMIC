module fake_netlist_725_4998_n_29 (n_8, n_1, n_2, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_29);

input n_8;
input n_1;
input n_2;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_29;

wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_28;
wire n_11;
wire n_25;
wire n_12;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_6),
.B(n_5),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_6),
.B(n_10),
.Y(n_14)
);

NOR2xp67_ASAP7_75t_L g15 ( 
.A(n_5),
.B(n_7),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_9),
.B(n_0),
.Y(n_16)
);

OAI22x1_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.B1(n_15),
.B2(n_13),
.Y(n_19)
);

CKINVDCx16_ASAP7_75t_R g20 ( 
.A(n_17),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B1(n_16),
.B2(n_15),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_SL g24 ( 
.A(n_22),
.B(n_17),
.C(n_2),
.Y(n_24)
);

NAND4xp25_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_8),
.C(n_4),
.D(n_3),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_26),
.B1(n_8),
.B2(n_4),
.Y(n_29)
);


endmodule