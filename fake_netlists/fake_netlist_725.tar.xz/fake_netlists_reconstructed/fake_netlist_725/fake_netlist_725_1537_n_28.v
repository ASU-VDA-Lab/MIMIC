module fake_netlist_725_1537_n_28 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_28);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_28;

wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_11;
wire n_25;
wire n_12;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_3),
.B(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_0),
.Y(n_16)
);

A2O1A1Ixp33_ASAP7_75t_SL g17 ( 
.A1(n_12),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_2),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_14),
.B1(n_11),
.B2(n_15),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_11),
.B(n_12),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_19),
.Y(n_21)
);

OA21x2_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_20),
.B(n_12),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_12),
.B2(n_14),
.Y(n_23)
);

AOI322xp5_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_19),
.A3(n_17),
.B1(n_6),
.B2(n_8),
.C1(n_4),
.C2(n_5),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_10),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_9),
.B1(n_25),
.B2(n_26),
.Y(n_28)
);


endmodule