module fake_netlist_725_2406_n_18 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_18);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_18;

wire n_12;
wire n_10;
wire n_15;
wire n_14;
wire n_17;
wire n_11;
wire n_13;
wire n_16;
wire n_9;

CKINVDCx16_ASAP7_75t_R g9 ( 
.A(n_7),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_1),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_6),
.Y(n_12)
);

BUFx8_ASAP7_75t_SL g13 ( 
.A(n_10),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_9),
.B1(n_10),
.B2(n_12),
.C(n_13),
.Y(n_15)
);

AOI211xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_3),
.B(n_2),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_8),
.B1(n_7),
.B2(n_4),
.Y(n_18)
);


endmodule