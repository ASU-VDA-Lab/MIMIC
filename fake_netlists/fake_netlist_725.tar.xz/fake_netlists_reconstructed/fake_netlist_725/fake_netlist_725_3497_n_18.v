module fake_netlist_725_3497_n_18 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_18);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_18;

wire n_12;
wire n_10;
wire n_15;
wire n_14;
wire n_17;
wire n_13;
wire n_16;
wire n_9;
wire n_11;

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_8),
.B1(n_5),
.B2(n_1),
.Y(n_9)
);

CKINVDCx11_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

OAI322xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.A3(n_10),
.B1(n_7),
.B2(n_0),
.C1(n_6),
.C2(n_3),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_11),
.C(n_6),
.Y(n_16)
);

XNOR2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_7),
.Y(n_17)
);

XNOR2x1_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.Y(n_18)
);


endmodule