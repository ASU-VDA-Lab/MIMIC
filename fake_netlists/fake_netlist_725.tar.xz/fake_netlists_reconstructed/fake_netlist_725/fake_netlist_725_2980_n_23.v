module fake_netlist_725_2980_n_23 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_23);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_23;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_0),
.B(n_6),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_4),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI22xp5_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_7),
.B1(n_5),
.B2(n_4),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_9),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_10),
.B(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_12),
.B(n_17),
.C(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_3),
.B(n_2),
.Y(n_23)
);


endmodule