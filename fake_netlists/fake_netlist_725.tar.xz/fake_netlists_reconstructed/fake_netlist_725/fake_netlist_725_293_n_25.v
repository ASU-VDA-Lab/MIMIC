module fake_netlist_725_293_n_25 (n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_25);

input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_25;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_9;
wire n_11;
wire n_12;
wire n_8;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

INVxp33_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_3),
.Y(n_9)
);

AND2x6_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_1),
.Y(n_10)
);

INVx5_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_7),
.B(n_6),
.Y(n_12)
);

NAND2x1_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_7),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_0),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_15)
);

OAI21xp5_ASAP7_75t_L g16 ( 
.A1(n_8),
.A2(n_4),
.B(n_2),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVxp67_ASAP7_75t_SL g18 ( 
.A(n_14),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_17),
.B1(n_18),
.B2(n_15),
.C(n_9),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_17),
.B1(n_20),
.B2(n_13),
.Y(n_23)
);

OAI22x1_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_11),
.B1(n_10),
.B2(n_4),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_10),
.B1(n_11),
.B2(n_5),
.Y(n_25)
);


endmodule