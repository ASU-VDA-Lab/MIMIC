module fake_netlist_725_2070_n_19 (n_8, n_1, n_2, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_19);

input n_8;
input n_1;
input n_2;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_19;

wire n_14;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_15;
wire n_16;

AND2x2_ASAP7_75t_L g11 ( 
.A(n_4),
.B(n_6),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_10),
.Y(n_12)
);

INVx4_ASAP7_75t_SL g13 ( 
.A(n_8),
.Y(n_13)
);

INVxp67_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

OAI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_12),
.B1(n_13),
.B2(n_4),
.C(n_6),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B1(n_7),
.B2(n_0),
.Y(n_17)
);

XNOR2x1_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_7),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.C1(n_9),
.C2(n_5),
.Y(n_19)
);


endmodule