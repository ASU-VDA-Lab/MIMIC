module fake_netlist_725_96_n_11 (n_1, n_2, n_0, n_3, n_4, n_11);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_11;

wire n_8;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_5;

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_0),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx4_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

NAND4xp25_ASAP7_75t_SL g10 ( 
.A(n_8),
.B(n_2),
.C(n_9),
.D(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);


endmodule