module fake_netlist_725_943_n_36 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_36);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_36;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_11;
wire n_25;
wire n_12;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_26;
wire n_34;
wire n_16;
wire n_22;
wire n_19;

INVxp67_ASAP7_75t_SL g10 ( 
.A(n_8),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_0),
.B(n_1),
.C(n_2),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_3),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_4),
.B(n_6),
.Y(n_14)
);

CKINVDCx6p67_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_5),
.B(n_4),
.Y(n_18)
);

AO31x2_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_7),
.A3(n_13),
.B(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_15),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_10),
.A2(n_14),
.B(n_16),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_14),
.Y(n_22)
);

OR2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_11),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_22),
.Y(n_24)
);

OAI22xp33_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_17),
.B1(n_18),
.B2(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

O2A1O1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_25),
.B(n_17),
.C(n_23),
.Y(n_30)
);

OAI211xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_17),
.B(n_18),
.C(n_19),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_29),
.Y(n_32)
);

AND3x4_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_19),
.C(n_17),
.Y(n_33)
);

AO21x2_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_19),
.B(n_33),
.Y(n_34)
);

XNOR2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_19),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_34),
.Y(n_36)
);


endmodule