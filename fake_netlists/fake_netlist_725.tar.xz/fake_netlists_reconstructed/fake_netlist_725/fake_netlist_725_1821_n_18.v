module fake_netlist_725_1821_n_18 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_18);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_18;

wire n_12;
wire n_10;
wire n_15;
wire n_14;
wire n_17;
wire n_13;
wire n_16;
wire n_9;
wire n_11;

OR2x2_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_0),
.Y(n_9)
);

INVx4_ASAP7_75t_SL g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_1),
.B(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_SL g13 ( 
.A(n_9),
.B(n_7),
.Y(n_13)
);

AND2x4_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_11),
.B2(n_7),
.C(n_4),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

NOR2x1p5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_6),
.Y(n_18)
);


endmodule