module fake_netlist_725_3343_n_17 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_17);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_17;

wire n_12;
wire n_10;
wire n_15;
wire n_14;
wire n_13;
wire n_16;
wire n_9;
wire n_11;

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_6),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

O2A1O1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B(n_9),
.C(n_12),
.Y(n_14)
);

NAND4xp25_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_13),
.C(n_10),
.D(n_1),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_10),
.B1(n_6),
.B2(n_5),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.C1(n_7),
.C2(n_9),
.Y(n_17)
);


endmodule