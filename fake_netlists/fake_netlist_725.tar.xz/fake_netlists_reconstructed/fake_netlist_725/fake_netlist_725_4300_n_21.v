module fake_netlist_725_4300_n_21 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_21);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_21;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_10;
wire n_15;
wire n_16;
wire n_19;

INVx2_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_1),
.Y(n_12)
);

AO22x2_ASAP7_75t_L g13 ( 
.A1(n_6),
.A2(n_3),
.B1(n_7),
.B2(n_5),
.Y(n_13)
);

AO31x2_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_6),
.A3(n_5),
.B(n_4),
.Y(n_14)
);

NOR2xp67_ASAP7_75t_SL g15 ( 
.A(n_12),
.B(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI31xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_12),
.A3(n_13),
.B(n_14),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_R g19 ( 
.A(n_18),
.B(n_2),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_13),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_4),
.B1(n_7),
.B2(n_8),
.C1(n_14),
.C2(n_13),
.Y(n_21)
);


endmodule