module fake_netlist_725_581_n_7 (n_0, n_3, n_2, n_1, n_7);

input n_0;
input n_3;
input n_2;
input n_1;

output n_7;

wire n_6;
wire n_4;
wire n_5;

NAND2x1p5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_1),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI31xp33_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_5),
.A3(n_1),
.B(n_0),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_2),
.B1(n_4),
.B2(n_5),
.Y(n_7)
);


endmodule