module fake_netlist_908_1575_n_61 (n_3, n_15, n_11, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_61);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_61;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_54;
wire n_28;
wire n_53;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_57;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_45;
wire n_44;
wire n_48;
wire n_38;
wire n_56;

OA21x2_ASAP7_75t_L g24 ( 
.A1(n_9),
.A2(n_20),
.B(n_12),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_17),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_5),
.B(n_2),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_11),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

OA21x2_ASAP7_75t_L g31 ( 
.A1(n_17),
.A2(n_18),
.B(n_16),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_18),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_4),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_21),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_30),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

NOR2x1p5_ASAP7_75t_L g37 ( 
.A(n_27),
.B(n_16),
.Y(n_37)
);

CKINVDCx20_ASAP7_75t_R g38 ( 
.A(n_29),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_33),
.Y(n_39)
);

A2O1A1Ixp33_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_28),
.B(n_25),
.C(n_26),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_29),
.B1(n_31),
.B2(n_32),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

AND2x4_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_32),
.Y(n_43)
);

AND2x4_ASAP7_75t_SL g44 ( 
.A(n_43),
.B(n_38),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_38),
.Y(n_45)
);

AOI222xp33_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_39),
.B1(n_43),
.B2(n_42),
.C1(n_32),
.C2(n_28),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_31),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_31),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_32),
.B1(n_24),
.B2(n_34),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

OAI211xp5_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_24),
.B(n_34),
.C(n_19),
.Y(n_51)
);

NOR3xp33_ASAP7_75t_L g52 ( 
.A(n_51),
.B(n_24),
.C(n_34),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

NAND3xp33_ASAP7_75t_SL g54 ( 
.A(n_49),
.B(n_34),
.C(n_0),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_3),
.Y(n_55)
);

INVx1_ASAP7_75t_SL g56 ( 
.A(n_53),
.Y(n_56)
);

HB1xp67_ASAP7_75t_L g57 ( 
.A(n_55),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_52),
.Y(n_58)
);

AOI222xp33_ASAP7_75t_SL g59 ( 
.A1(n_56),
.A2(n_7),
.B1(n_6),
.B2(n_8),
.C1(n_14),
.C2(n_10),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_54),
.B1(n_23),
.B2(n_22),
.Y(n_60)
);

AO21x2_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_58),
.B(n_59),
.Y(n_61)
);


endmodule