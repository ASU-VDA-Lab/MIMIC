module fake_netlist_908_2540_n_11 (n_0, n_2, n_5, n_3, n_4, n_1, n_11);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_11;

wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_7;

AOI21xp5_ASAP7_75t_L g6 ( 
.A1(n_2),
.A2(n_3),
.B(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_4),
.Y(n_7)
);

BUFx4f_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_8),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_6),
.B(n_7),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_4),
.B1(n_0),
.B2(n_5),
.Y(n_11)
);


endmodule