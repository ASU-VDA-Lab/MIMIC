module fake_netlist_908_1979_n_26 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_26);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_26;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;

INVx1_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_6),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_9),
.Y(n_17)
);

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_0),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_2),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NOR2xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_13),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI222xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_14),
.B1(n_18),
.B2(n_16),
.C1(n_17),
.C2(n_3),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_4),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_11),
.B1(n_10),
.B2(n_7),
.Y(n_26)
);


endmodule