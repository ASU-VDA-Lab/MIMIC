module fake_netlist_908_2543_n_70 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_70);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_70;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_68;
wire n_46;
wire n_63;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_66;
wire n_65;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_67;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_42;
wire n_41;
wire n_57;
wire n_43;
wire n_62;
wire n_26;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_29;
wire n_69;
wire n_38;
wire n_56;

INVx2_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_4),
.A2(n_5),
.B1(n_7),
.B2(n_17),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

OA21x2_ASAP7_75t_L g26 ( 
.A1(n_6),
.A2(n_8),
.B(n_11),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_14),
.Y(n_27)
);

INVx4_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_19),
.A2(n_7),
.B1(n_1),
.B2(n_16),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_9),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_25),
.B(n_2),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_25),
.A2(n_8),
.B1(n_3),
.B2(n_2),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_28),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

AOI21xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_24),
.B(n_26),
.Y(n_37)
);

OAI21x1_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_26),
.B(n_22),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_24),
.B(n_26),
.Y(n_39)
);

AO31x2_ASAP7_75t_L g40 ( 
.A1(n_32),
.A2(n_22),
.A3(n_31),
.B(n_28),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_40),
.B(n_23),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_37),
.A2(n_35),
.B1(n_36),
.B2(n_34),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_40),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

INVx1_ASAP7_75t_SL g47 ( 
.A(n_41),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_41),
.Y(n_48)
);

NAND2x1_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_26),
.Y(n_49)
);

INVxp67_ASAP7_75t_SL g50 ( 
.A(n_47),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_45),
.B(n_41),
.Y(n_51)
);

AOI332xp33_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_41),
.A3(n_31),
.B1(n_33),
.B2(n_23),
.B3(n_34),
.C1(n_32),
.C2(n_27),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_SL g53 ( 
.A(n_48),
.B(n_50),
.Y(n_53)
);

O2A1O1Ixp5_ASAP7_75t_L g54 ( 
.A1(n_49),
.A2(n_41),
.B(n_44),
.C(n_39),
.Y(n_54)
);

AOI222xp33_ASAP7_75t_L g55 ( 
.A1(n_51),
.A2(n_30),
.B1(n_29),
.B2(n_33),
.C1(n_28),
.C2(n_27),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_51),
.A2(n_30),
.B1(n_28),
.B2(n_29),
.Y(n_56)
);

NOR3x1_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_10),
.C(n_3),
.Y(n_57)
);

AOI221xp5_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_46),
.B1(n_43),
.B2(n_36),
.C(n_44),
.Y(n_58)
);

NAND3xp33_ASAP7_75t_SL g59 ( 
.A(n_55),
.B(n_43),
.C(n_46),
.Y(n_59)
);

NOR2xp33_ASAP7_75t_L g60 ( 
.A(n_56),
.B(n_11),
.Y(n_60)
);

AOI222xp33_ASAP7_75t_L g61 ( 
.A1(n_53),
.A2(n_36),
.B1(n_14),
.B2(n_12),
.C1(n_15),
.C2(n_13),
.Y(n_61)
);

NOR3xp33_ASAP7_75t_SL g62 ( 
.A(n_60),
.B(n_13),
.C(n_12),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_57),
.B(n_40),
.Y(n_63)
);

AND2x4_ASAP7_75t_L g64 ( 
.A(n_61),
.B(n_36),
.Y(n_64)
);

AOI22xp5_ASAP7_75t_L g65 ( 
.A1(n_59),
.A2(n_36),
.B1(n_54),
.B2(n_15),
.Y(n_65)
);

OAI22xp5_ASAP7_75t_L g66 ( 
.A1(n_64),
.A2(n_58),
.B1(n_36),
.B2(n_16),
.Y(n_66)
);

OAI321xp33_ASAP7_75t_L g67 ( 
.A1(n_63),
.A2(n_18),
.A3(n_20),
.B1(n_21),
.B2(n_36),
.C(n_65),
.Y(n_67)
);

OAI22xp5_ASAP7_75t_SL g68 ( 
.A1(n_64),
.A2(n_21),
.B1(n_18),
.B2(n_36),
.Y(n_68)
);

OA21x2_ASAP7_75t_L g69 ( 
.A1(n_67),
.A2(n_62),
.B(n_63),
.Y(n_69)
);

AOI22xp5_ASAP7_75t_SL g70 ( 
.A1(n_69),
.A2(n_64),
.B1(n_66),
.B2(n_68),
.Y(n_70)
);


endmodule