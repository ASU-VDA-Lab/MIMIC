module fake_netlist_908_878_n_29 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_29);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_29;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;

INVxp67_ASAP7_75t_SL g9 ( 
.A(n_0),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_4),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_1),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_13),
.Y(n_17)
);

AO31x2_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_11),
.A3(n_9),
.B(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI21xp33_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_14),
.B(n_9),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_10),
.B1(n_11),
.B2(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_20),
.B1(n_10),
.B2(n_18),
.C(n_2),
.Y(n_23)
);

AOI322xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_3),
.A3(n_2),
.B1(n_6),
.B2(n_7),
.C1(n_4),
.C2(n_5),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_26),
.A2(n_18),
.B1(n_6),
.B2(n_3),
.Y(n_28)
);

OAI321xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_8),
.A3(n_25),
.B1(n_27),
.B2(n_21),
.C(n_23),
.Y(n_29)
);


endmodule