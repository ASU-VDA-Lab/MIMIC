module fake_netlist_908_1010_n_48 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_48);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_48;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_38;

INVx1_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_19),
.B(n_3),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_20),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_14),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_12),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_7),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_R g29 ( 
.A(n_8),
.B(n_18),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_4),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_21),
.B(n_18),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_25),
.B(n_0),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_26),
.A2(n_5),
.B1(n_2),
.B2(n_1),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_28),
.Y(n_34)
);

AND2x6_ASAP7_75t_L g35 ( 
.A(n_31),
.B(n_30),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_23),
.Y(n_36)
);

AO21x2_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_29),
.B(n_22),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_32),
.Y(n_40)
);

INVxp67_ASAP7_75t_SL g41 ( 
.A(n_40),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_24),
.B1(n_33),
.B2(n_27),
.C(n_35),
.Y(n_43)
);

A2O1A1Ixp33_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_29),
.B(n_13),
.C(n_9),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_15),
.Y(n_45)
);

INVxp67_ASAP7_75t_SL g46 ( 
.A(n_43),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

AOI22xp33_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_45),
.B1(n_17),
.B2(n_16),
.Y(n_48)
);


endmodule