module fake_netlist_908_1090_n_69 (n_3, n_15, n_11, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_69);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_69;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_68;
wire n_46;
wire n_63;
wire n_30;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_66;
wire n_65;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_67;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_32;
wire n_35;
wire n_25;
wire n_42;
wire n_41;
wire n_57;
wire n_43;
wire n_62;
wire n_26;
wire n_44;
wire n_36;
wire n_45;
wire n_48;
wire n_29;
wire n_38;
wire n_56;

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_4),
.B(n_13),
.Y(n_25)
);

CKINVDCx20_ASAP7_75t_R g26 ( 
.A(n_15),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_11),
.B(n_17),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_18),
.B(n_17),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_19),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_5),
.Y(n_31)
);

BUFx3_ASAP7_75t_L g32 ( 
.A(n_16),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_22),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_20),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_3),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_26),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_24),
.B(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_30),
.B(n_23),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_31),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_28),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_35),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_25),
.B(n_27),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_37),
.B(n_32),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_42),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_47),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_42),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_38),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_49),
.B(n_36),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_L g57 ( 
.A1(n_53),
.A2(n_36),
.B1(n_52),
.B2(n_26),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

O2A1O1Ixp33_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_51),
.B(n_41),
.C(n_29),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_55),
.Y(n_60)
);

AOI322xp5_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_33),
.A3(n_23),
.B1(n_2),
.B2(n_6),
.C1(n_0),
.C2(n_1),
.Y(n_61)
);

OAI21xp5_ASAP7_75t_L g62 ( 
.A1(n_59),
.A2(n_57),
.B(n_58),
.Y(n_62)
);

AOI21xp5_ASAP7_75t_L g63 ( 
.A1(n_59),
.A2(n_33),
.B(n_7),
.Y(n_63)
);

AOI22xp5_ASAP7_75t_L g64 ( 
.A1(n_57),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_62),
.Y(n_65)
);

INVx2_ASAP7_75t_L g66 ( 
.A(n_64),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_63),
.Y(n_67)
);

A2O1A1Ixp33_ASAP7_75t_L g68 ( 
.A1(n_65),
.A2(n_61),
.B(n_14),
.C(n_12),
.Y(n_68)
);

OAI21xp5_ASAP7_75t_L g69 ( 
.A1(n_68),
.A2(n_66),
.B(n_67),
.Y(n_69)
);


endmodule