module fake_netlist_908_2476_n_57 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_10, n_8, n_57);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_10;
input n_8;

output n_57;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_54;
wire n_28;
wire n_53;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;
wire n_56;

AND2x2_ASAP7_75t_L g26 ( 
.A(n_4),
.B(n_18),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_9),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_8),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_7),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_19),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_17),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_12),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_R g33 ( 
.A(n_23),
.B(n_16),
.Y(n_33)
);

BUFx8_ASAP7_75t_L g34 ( 
.A(n_1),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_20),
.B(n_5),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_21),
.B1(n_17),
.B2(n_16),
.Y(n_36)
);

A2O1A1Ixp33_ASAP7_75t_L g37 ( 
.A1(n_32),
.A2(n_25),
.B(n_24),
.C(n_21),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_SL g39 ( 
.A1(n_29),
.A2(n_25),
.B1(n_24),
.B2(n_0),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_30),
.B1(n_35),
.B2(n_26),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AOI21x1_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_35),
.B(n_28),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_37),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

NAND2x1p5_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_42),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_43),
.B1(n_39),
.B2(n_33),
.C(n_28),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_SL g48 ( 
.A1(n_45),
.A2(n_34),
.B1(n_28),
.B2(n_2),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_SL g50 ( 
.A(n_47),
.B(n_34),
.Y(n_50)
);

NOR2x1_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_3),
.Y(n_51)
);

O2A1O1Ixp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_11),
.B(n_10),
.C(n_6),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_13),
.Y(n_53)
);

AOI22x1_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_22),
.B1(n_15),
.B2(n_14),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_53),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

OR2x2_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_56),
.Y(n_57)
);


endmodule