module fake_netlist_908_1417_n_54 (n_3, n_15, n_11, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_54);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_54;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_28;
wire n_53;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_35;
wire n_41;
wire n_42;
wire n_25;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

BUFx8_ASAP7_75t_L g24 ( 
.A(n_0),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_15),
.B(n_1),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_18),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_9),
.B(n_14),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_7),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_3),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_12),
.B(n_17),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_26),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_16),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

BUFx2_ASAP7_75t_R g37 ( 
.A(n_35),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_29),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_33),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_30),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_37),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_32),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_34),
.B1(n_28),
.B2(n_24),
.Y(n_45)
);

OAI31xp33_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_28),
.A3(n_25),
.B(n_24),
.Y(n_46)
);

INVxp33_ASAP7_75t_SL g47 ( 
.A(n_45),
.Y(n_47)
);

NAND4xp75_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_19),
.C(n_4),
.D(n_2),
.Y(n_48)
);

NOR2x1_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_31),
.Y(n_49)
);

OAI21xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_33),
.B(n_19),
.Y(n_50)
);

OAI31xp33_ASAP7_75t_SL g51 ( 
.A1(n_48),
.A2(n_8),
.A3(n_6),
.B(n_5),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_33),
.B1(n_13),
.B2(n_11),
.Y(n_52)
);

BUFx6f_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

AOI22xp33_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_21),
.B1(n_23),
.B2(n_52),
.Y(n_54)
);


endmodule