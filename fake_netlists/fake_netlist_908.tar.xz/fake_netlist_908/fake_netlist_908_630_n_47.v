module fake_netlist_908_630_n_47 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_47);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_47;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_38;

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_0),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_1),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

OR2x6_ASAP7_75t_L g26 ( 
.A(n_3),
.B(n_13),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_11),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_7),
.B(n_12),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

BUFx12f_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_19),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_23),
.B(n_19),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_SL g34 ( 
.A1(n_32),
.A2(n_22),
.B(n_28),
.C(n_25),
.Y(n_34)
);

AO21x2_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_32),
.B(n_30),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_24),
.B1(n_29),
.B2(n_25),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_29),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_2),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_4),
.Y(n_39)
);

NOR4xp25_ASAP7_75t_SL g40 ( 
.A(n_37),
.B(n_9),
.C(n_8),
.D(n_6),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AOI21xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_14),
.B(n_10),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

NAND3xp33_ASAP7_75t_SL g44 ( 
.A(n_42),
.B(n_16),
.C(n_15),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_44),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_45),
.B1(n_20),
.B2(n_17),
.Y(n_47)
);


endmodule