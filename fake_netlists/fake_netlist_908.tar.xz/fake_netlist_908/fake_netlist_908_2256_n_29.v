module fake_netlist_908_2256_n_29 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_29);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_29;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;

INVx2_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_4),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

NAND2x1p5_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_7),
.Y(n_15)
);

INVxp67_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_9),
.A2(n_7),
.B(n_0),
.Y(n_17)
);

AOI21x1_ASAP7_75t_L g18 ( 
.A1(n_11),
.A2(n_12),
.B(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_10),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_12),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_21),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_15),
.B1(n_20),
.B2(n_13),
.C(n_14),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_19),
.B1(n_17),
.B2(n_1),
.Y(n_25)
);

NAND4xp75_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_5),
.C(n_4),
.D(n_3),
.Y(n_26)
);

OAI221xp5_ASAP7_75t_SL g27 ( 
.A1(n_25),
.A2(n_3),
.B1(n_6),
.B2(n_24),
.C(n_22),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_27),
.B(n_6),
.Y(n_29)
);


endmodule