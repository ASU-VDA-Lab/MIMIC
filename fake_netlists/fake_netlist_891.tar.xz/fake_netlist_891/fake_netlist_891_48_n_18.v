module fake_netlist_891_48_n_18 (n_0, n_2, n_5, n_3, n_4, n_1, n_18);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_18;

wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_17;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_2),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_2),
.B1(n_0),
.B2(n_3),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NAND3xp33_ASAP7_75t_SL g12 ( 
.A(n_8),
.B(n_3),
.C(n_0),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_6),
.B1(n_7),
.B2(n_9),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_SL g15 ( 
.A1(n_13),
.A2(n_8),
.B1(n_6),
.B2(n_7),
.Y(n_15)
);

AOI221x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B1(n_14),
.B2(n_7),
.C(n_4),
.Y(n_16)
);

BUFx12f_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);


endmodule