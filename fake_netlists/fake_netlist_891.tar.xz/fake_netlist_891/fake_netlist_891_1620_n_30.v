module fake_netlist_891_1620_n_30 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_30);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_30;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_29;

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_6),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_1),
.Y(n_16)
);

BUFx3_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_5),
.B(n_3),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_R g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AND2x2_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_16),
.Y(n_24)
);

AOI211xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_20),
.B(n_18),
.C(n_15),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_25),
.Y(n_27)
);

NAND5xp2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_4),
.C(n_2),
.D(n_7),
.E(n_8),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_26),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_29),
.B1(n_11),
.B2(n_9),
.Y(n_30)
);


endmodule