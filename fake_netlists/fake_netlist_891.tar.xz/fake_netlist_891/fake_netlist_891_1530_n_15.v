module fake_netlist_891_1530_n_15 (n_0, n_1, n_2, n_15);

input n_0;
input n_1;
input n_2;

output n_15;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

AND2x4_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_2),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

INVx4_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

OAI22xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_8)
);

OAI33xp33_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.A3(n_2),
.B1(n_3),
.B2(n_5),
.B3(n_6),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_5),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_3),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_3),
.B1(n_5),
.B2(n_8),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_10),
.B(n_3),
.C(n_5),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_5),
.B1(n_12),
.B2(n_1),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_R g15 ( 
.A(n_14),
.B(n_11),
.Y(n_15)
);


endmodule