module fake_netlist_891_1432_n_28 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_28);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_28;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_8),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_7),
.Y(n_16)
);

BUFx3_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_1),
.B(n_0),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_SL g20 ( 
.A(n_18),
.B(n_16),
.C(n_15),
.Y(n_20)
);

BUFx10_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

O2A1O1Ixp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_21),
.B(n_13),
.C(n_14),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_14),
.B1(n_7),
.B2(n_6),
.Y(n_26)
);

OAI22x1_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_14),
.B1(n_4),
.B2(n_3),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_25),
.B1(n_9),
.B2(n_5),
.Y(n_28)
);


endmodule