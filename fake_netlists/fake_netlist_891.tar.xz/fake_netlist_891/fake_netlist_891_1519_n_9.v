module fake_netlist_891_1519_n_9 (n_0, n_1, n_2, n_9);

input n_0;
input n_1;
input n_2;

output n_9;

wire n_5;
wire n_3;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

BUFx5_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

INVx3_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

BUFx2_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

NOR2x1_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_3),
.Y(n_6)
);

OAI21xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_3),
.B(n_1),
.Y(n_7)
);

CKINVDCx20_ASAP7_75t_R g8 ( 
.A(n_7),
.Y(n_8)
);

OA21x2_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_0),
.B(n_1),
.Y(n_9)
);


endmodule