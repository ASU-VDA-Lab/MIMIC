module fake_netlist_891_824_n_44 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_44);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_44;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_14;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_3),
.B(n_12),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_3),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_1),
.B(n_4),
.Y(n_18)
);

NAND2xp33_ASAP7_75t_SL g19 ( 
.A(n_2),
.B(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_16),
.B(n_0),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

NAND3xp33_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_19),
.C(n_16),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_27),
.B(n_18),
.Y(n_29)
);

OAI21xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_14),
.B(n_19),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_27),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

A2O1A1Ixp33_ASAP7_75t_SL g33 ( 
.A1(n_30),
.A2(n_15),
.B(n_17),
.C(n_27),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_31),
.Y(n_34)
);

AOI322xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_17),
.A3(n_15),
.B1(n_2),
.B2(n_5),
.C1(n_0),
.C2(n_1),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_30),
.C(n_32),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_31),
.Y(n_37)
);

AO22x2_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_31),
.B1(n_7),
.B2(n_6),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AND3x1_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_7),
.C(n_6),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_33),
.B(n_38),
.Y(n_41)
);

XNOR2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_11),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_43)
);

NAND3xp33_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_39),
.C(n_43),
.Y(n_44)
);


endmodule