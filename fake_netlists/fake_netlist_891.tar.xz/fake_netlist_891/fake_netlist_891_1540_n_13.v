module fake_netlist_891_1540_n_13 (n_0, n_1, n_3, n_2, n_13);

input n_0;
input n_1;
input n_3;
input n_2;

output n_13;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

AND2x6_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_0),
.B(n_3),
.Y(n_6)
);

HB1xp67_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

AO21x1_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NOR4xp25_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_8),
.C(n_4),
.D(n_7),
.Y(n_10)
);

NAND4xp25_ASAP7_75t_SL g11 ( 
.A(n_10),
.B(n_9),
.C(n_3),
.D(n_2),
.Y(n_11)
);

AND3x4_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.C(n_1),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_3),
.B(n_2),
.Y(n_13)
);


endmodule