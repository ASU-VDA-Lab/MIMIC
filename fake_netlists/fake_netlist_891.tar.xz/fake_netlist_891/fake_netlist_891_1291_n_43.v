module fake_netlist_891_1291_n_43 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_43);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_43;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_14;
wire n_35;
wire n_41;
wire n_42;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_6),
.B(n_10),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_18),
.B(n_0),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_0),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_18),
.B(n_2),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

NOR2xp67_ASAP7_75t_SL g25 ( 
.A(n_22),
.B(n_19),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_19),
.B1(n_17),
.B2(n_16),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_26),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_21),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_15),
.B(n_25),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_17),
.B1(n_16),
.B2(n_23),
.C(n_14),
.Y(n_34)
);

XNOR2x1_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_2),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_35),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_33),
.B(n_15),
.Y(n_38)
);

OAI211xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_36),
.B(n_4),
.C(n_3),
.Y(n_39)
);

NAND3xp33_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_7),
.C(n_5),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

OAI22xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_39),
.B1(n_11),
.B2(n_13),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);


endmodule