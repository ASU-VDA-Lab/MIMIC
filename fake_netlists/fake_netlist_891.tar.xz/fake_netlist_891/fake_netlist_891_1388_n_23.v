module fake_netlist_891_1388_n_23 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_23);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_23;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_5),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_2),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NOR3xp33_ASAP7_75t_SL g12 ( 
.A(n_7),
.B(n_3),
.C(n_1),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_13),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_10),
.B1(n_8),
.B2(n_7),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_12),
.B1(n_11),
.B2(n_13),
.C(n_9),
.Y(n_17)
);

AOI31xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_6),
.A3(n_4),
.B(n_1),
.Y(n_18)
);

NOR2x1p5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_17),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_22),
.B1(n_6),
.B2(n_0),
.Y(n_23)
);


endmodule