module fake_netlist_891_1596_n_22 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_7, n_22);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;
input n_7;

output n_22;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_14;
wire n_10;
wire n_8;

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_2),
.Y(n_8)
);

NOR2x1p5_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

NAND3xp33_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_0),
.C(n_5),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_4),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_4),
.B(n_1),
.Y(n_13)
);

AO21x1_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_10),
.B(n_9),
.Y(n_14)
);

OAI21x1_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_5),
.B(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AO21x2_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_8),
.B(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B1(n_13),
.B2(n_17),
.C(n_15),
.Y(n_19)
);

NAND5xp2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_6),
.C(n_7),
.D(n_17),
.E(n_8),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_17),
.Y(n_22)
);


endmodule