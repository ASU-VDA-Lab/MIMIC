module fake_netlist_891_776_n_27 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_27);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_27;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_18;
wire n_17;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

INVx3_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_0),
.B(n_3),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_15),
.Y(n_17)
);

OAI22x1_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_16),
.B1(n_13),
.B2(n_12),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_17),
.Y(n_21)
);

OR2x6_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_19),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_20),
.B(n_14),
.C(n_13),
.Y(n_23)
);

AOI311xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_17),
.A3(n_21),
.B(n_5),
.C(n_6),
.Y(n_24)
);

NOR3x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_12),
.C(n_9),
.Y(n_25)
);

NOR2x1_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_12),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_25),
.B1(n_11),
.B2(n_10),
.Y(n_27)
);


endmodule