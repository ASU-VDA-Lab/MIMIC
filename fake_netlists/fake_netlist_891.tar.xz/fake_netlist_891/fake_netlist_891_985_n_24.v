module fake_netlist_891_985_n_24 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_24);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_24;

wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_18;
wire n_17;
wire n_13;
wire n_21;
wire n_22;
wire n_14;

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_1),
.B(n_6),
.Y(n_11)
);

BUFx6f_ASAP7_75t_L g12 ( 
.A(n_2),
.Y(n_12)
);

NOR3xp33_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_7),
.C(n_6),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_4),
.B(n_3),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

AO31x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_5),
.A3(n_8),
.B(n_0),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_9),
.B(n_14),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

NAND2xp33_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_13),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

NAND2x1p5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_17),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_12),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_12),
.Y(n_24)
);


endmodule