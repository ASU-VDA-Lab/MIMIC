module fake_netlist_891_371_n_28 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_28);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_28;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;

INVx2_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

NAND2xp33_ASAP7_75t_R g13 ( 
.A(n_4),
.B(n_3),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_12),
.B1(n_14),
.B2(n_16),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_14),
.B1(n_13),
.B2(n_5),
.C(n_6),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

XNOR2x1_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_5),
.Y(n_23)
);

OAI211xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_7),
.B(n_6),
.C(n_0),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_8),
.C(n_2),
.Y(n_25)
);

CKINVDCx12_ASAP7_75t_R g26 ( 
.A(n_24),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

XNOR2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_9),
.Y(n_28)
);


endmodule