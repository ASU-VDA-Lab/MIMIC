module fake_netlist_891_1750_n_22 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_22);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_22;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

OR2x6_ASAP7_75t_L g13 ( 
.A(n_4),
.B(n_3),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_1),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_7),
.B(n_0),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_13),
.Y(n_19)
);

NOR4xp25_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_14),
.C(n_5),
.D(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_10),
.B(n_6),
.Y(n_22)
);


endmodule