module fake_netlist_703_1094_n_24 (n_4, n_2, n_3, n_1, n_0, n_24);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_24;

wire n_21;
wire n_17;
wire n_6;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_5;
wire n_7;
wire n_23;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_4),
.B(n_0),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

O2A1O1Ixp5_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

AND3x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_7),
.C(n_8),
.Y(n_15)
);

NAND2x1p5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_5),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B1(n_14),
.B2(n_10),
.C(n_9),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_14),
.B1(n_9),
.B2(n_10),
.C1(n_1),
.C2(n_0),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_16),
.C(n_3),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_3),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

OA22x2_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_4),
.C(n_2),
.D(n_1),
.Y(n_23)
);

AO21x2_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_19),
.B(n_23),
.Y(n_24)
);


endmodule