module fake_netlist_703_456_n_28 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_28);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_28;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_8;
wire n_11;
wire n_19;
wire n_25;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_2),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_2),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_5),
.B(n_6),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

BUFx2_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_1),
.Y(n_15)
);

AOI21x1_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_3),
.B(n_4),
.Y(n_16)
);

AO31x2_ASAP7_75t_L g17 ( 
.A1(n_10),
.A2(n_6),
.A3(n_7),
.B(n_12),
.Y(n_17)
);

AND2x4_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_8),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

OAI21xp33_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_15),
.B(n_17),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B1(n_18),
.B2(n_8),
.Y(n_23)
);

INVx3_ASAP7_75t_SL g24 ( 
.A(n_22),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_18),
.B1(n_21),
.B2(n_8),
.C(n_19),
.Y(n_25)
);

NAND3x1_ASAP7_75t_SL g26 ( 
.A(n_23),
.B(n_7),
.C(n_17),
.Y(n_26)
);

OAI31xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_17),
.A3(n_18),
.B(n_25),
.Y(n_27)
);

OAI21xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_21),
.B(n_25),
.Y(n_28)
);


endmodule