module fake_netlist_703_1858_n_54 (n_9, n_4, n_2, n_7, n_14, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_54);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_54;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_16;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_19;
wire n_39;

NOR2xp67_ASAP7_75t_L g15 ( 
.A(n_6),
.B(n_2),
.Y(n_15)
);

OA21x2_ASAP7_75t_L g16 ( 
.A1(n_3),
.A2(n_0),
.B(n_12),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_6),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_7),
.Y(n_20)
);

CKINVDCx14_ASAP7_75t_R g21 ( 
.A(n_13),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_18),
.B(n_1),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_2),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_18),
.B(n_3),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_19),
.A2(n_8),
.B1(n_5),
.B2(n_4),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_19),
.B(n_5),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_19),
.B(n_8),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_L g32 ( 
.A1(n_25),
.A2(n_20),
.B1(n_23),
.B2(n_22),
.C(n_17),
.Y(n_32)
);

CKINVDCx11_ASAP7_75t_R g33 ( 
.A(n_29),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_28),
.A2(n_23),
.B1(n_20),
.B2(n_22),
.Y(n_34)
);

AOI21xp33_ASAP7_75t_L g35 ( 
.A1(n_26),
.A2(n_21),
.B(n_16),
.Y(n_35)
);

OAI22xp33_ASAP7_75t_L g36 ( 
.A1(n_27),
.A2(n_15),
.B1(n_22),
.B2(n_16),
.Y(n_36)
);

OAI332xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_30),
.A3(n_31),
.B1(n_21),
.B2(n_15),
.B3(n_11),
.C1(n_10),
.C2(n_16),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_32),
.B1(n_36),
.B2(n_35),
.C(n_29),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_33),
.A2(n_16),
.B(n_14),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_16),
.B1(n_11),
.B2(n_10),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_40),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

AOI211x1_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_41),
.B(n_37),
.C(n_42),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

CKINVDCx20_ASAP7_75t_R g47 ( 
.A(n_46),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_41),
.B(n_46),
.Y(n_48)
);

AND2x4_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_44),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_47),
.Y(n_51)
);

BUFx2_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);

OAI211xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_51),
.B(n_50),
.C(n_48),
.Y(n_54)
);


endmodule