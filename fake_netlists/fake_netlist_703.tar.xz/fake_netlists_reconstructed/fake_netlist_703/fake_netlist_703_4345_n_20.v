module fake_netlist_703_4345_n_20 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_20);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_20;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_4),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_11),
.B(n_9),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_R g14 ( 
.A(n_12),
.B(n_8),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OAI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_14),
.B1(n_5),
.B2(n_0),
.C(n_1),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_5),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

AOI22xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_6),
.B2(n_3),
.Y(n_20)
);


endmodule