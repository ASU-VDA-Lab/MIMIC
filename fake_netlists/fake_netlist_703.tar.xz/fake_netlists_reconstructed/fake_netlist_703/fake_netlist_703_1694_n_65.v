module fake_netlist_703_1694_n_65 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_65);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_65;

wire n_54;
wire n_24;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_23;
wire n_46;
wire n_41;
wire n_31;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_19;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_10),
.B(n_1),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

OA21x2_ASAP7_75t_L g22 ( 
.A1(n_7),
.A2(n_12),
.B(n_15),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_8),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_15),
.B(n_13),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

INVx4_ASAP7_75t_L g28 ( 
.A(n_0),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

INVx4_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_25),
.B(n_27),
.Y(n_33)
);

BUFx4f_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

NOR2x1p5_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_28),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_26),
.B(n_14),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_19),
.B(n_16),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_30),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_34),
.A2(n_22),
.B1(n_24),
.B2(n_30),
.Y(n_40)
);

CKINVDCx12_ASAP7_75t_R g41 ( 
.A(n_33),
.Y(n_41)
);

AO21x2_ASAP7_75t_L g42 ( 
.A1(n_38),
.A2(n_18),
.B(n_20),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_35),
.A2(n_21),
.B(n_19),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_32),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_35),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_L g47 ( 
.A1(n_40),
.A2(n_23),
.B1(n_34),
.B2(n_36),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_42),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_47),
.Y(n_50)
);

NAND2x1_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_22),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_49),
.Y(n_54)
);

INVxp33_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

NAND2xp5_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_42),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_31),
.Y(n_57)
);

OAI22xp5_ASAP7_75t_L g58 ( 
.A1(n_51),
.A2(n_29),
.B1(n_39),
.B2(n_37),
.Y(n_58)
);

OR2x2_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_56),
.Y(n_59)
);

NOR3xp33_ASAP7_75t_L g60 ( 
.A(n_58),
.B(n_44),
.C(n_17),
.Y(n_60)
);

NOR2x1_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_32),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_59),
.Y(n_62)
);

INVx2_ASAP7_75t_SL g63 ( 
.A(n_61),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_62),
.B(n_60),
.Y(n_64)
);

AOI22xp33_ASAP7_75t_L g65 ( 
.A1(n_64),
.A2(n_62),
.B1(n_63),
.B2(n_9),
.Y(n_65)
);


endmodule