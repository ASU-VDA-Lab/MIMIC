module fake_netlist_703_958_n_35 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_35);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_35;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_34;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_13;
wire n_33;
wire n_8;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_5),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_5),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_3),
.B(n_6),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

O2A1O1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_8),
.A2(n_7),
.B(n_6),
.C(n_0),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_7),
.B(n_6),
.Y(n_16)
);

INVx4_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_8),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_3),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_14),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_SL g23 ( 
.A(n_19),
.B(n_10),
.C(n_9),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_20),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_11),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_SL g27 ( 
.A1(n_25),
.A2(n_21),
.B(n_15),
.Y(n_27)
);

OAI31xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_13),
.A3(n_21),
.B(n_16),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_24),
.B1(n_11),
.B2(n_26),
.Y(n_29)
);

NAND3xp33_ASAP7_75t_SL g30 ( 
.A(n_28),
.B(n_24),
.C(n_23),
.Y(n_30)
);

AOI221xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_23),
.B1(n_28),
.B2(n_18),
.C(n_13),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_18),
.B1(n_22),
.B2(n_17),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_4),
.B1(n_22),
.B2(n_34),
.Y(n_35)
);


endmodule