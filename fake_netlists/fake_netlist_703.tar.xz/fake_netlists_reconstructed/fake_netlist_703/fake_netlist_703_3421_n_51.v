module fake_netlist_703_3421_n_51 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_51);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_51;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

AND2x2_ASAP7_75t_L g20 ( 
.A(n_11),
.B(n_6),
.Y(n_20)
);

CKINVDCx11_ASAP7_75t_R g21 ( 
.A(n_17),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_0),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

OA21x2_ASAP7_75t_L g25 ( 
.A1(n_18),
.A2(n_16),
.B(n_9),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_14),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_10),
.A2(n_4),
.B1(n_3),
.B2(n_8),
.Y(n_28)
);

INVx5_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_SL g31 ( 
.A(n_26),
.B(n_0),
.Y(n_31)
);

OAI21x1_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_26),
.B(n_22),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_24),
.B(n_20),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_21),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_21),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_33),
.Y(n_39)
);

AOI221x1_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_28),
.B1(n_23),
.B2(n_30),
.C(n_32),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_29),
.Y(n_43)
);

AND3x4_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_19),
.C(n_25),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_23),
.C(n_29),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_41),
.A2(n_23),
.B1(n_32),
.B2(n_1),
.C(n_5),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_23),
.B1(n_32),
.B2(n_7),
.Y(n_47)
);

INVx2_ASAP7_75t_SL g48 ( 
.A(n_45),
.Y(n_48)
);

OA22x2_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_12),
.B1(n_44),
.B2(n_42),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_49),
.B(n_47),
.Y(n_51)
);


endmodule