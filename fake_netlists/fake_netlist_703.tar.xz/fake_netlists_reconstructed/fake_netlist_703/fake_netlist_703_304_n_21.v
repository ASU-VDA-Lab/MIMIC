module fake_netlist_703_304_n_21 (n_3, n_0, n_2, n_1, n_21);

input n_3;
input n_0;
input n_2;
input n_1;

output n_21;

wire n_17;
wire n_6;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_5;
wire n_7;
wire n_8;
wire n_4;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

BUFx2_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_0),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

BUFx3_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

HB1xp67_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_1),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_5),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_SL g16 ( 
.A1(n_14),
.A2(n_5),
.B1(n_6),
.B2(n_13),
.C(n_2),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_6),
.B(n_13),
.C(n_14),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_15),
.Y(n_19)
);

OAI21x1_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_6),
.B(n_19),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_18),
.B(n_6),
.Y(n_21)
);


endmodule