module fake_netlist_703_1432_n_53 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_53);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_53;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_19),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_3),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_11),
.B(n_13),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_23),
.B(n_1),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_SL g31 ( 
.A(n_16),
.B(n_12),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_9),
.B(n_18),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_2),
.B(n_19),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_27),
.A2(n_18),
.B1(n_16),
.B2(n_0),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_32),
.Y(n_36)
);

BUFx4f_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_24),
.B1(n_33),
.B2(n_28),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_25),
.B(n_30),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_35),
.Y(n_40)
);

INVxp67_ASAP7_75t_SL g41 ( 
.A(n_39),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_37),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_34),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_31),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_25),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_29),
.B(n_4),
.Y(n_46)
);

OAI21xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_29),
.B(n_5),
.Y(n_47)
);

BUFx6f_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

NOR4xp25_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_14),
.C(n_7),
.D(n_6),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_49),
.B1(n_17),
.B2(n_15),
.Y(n_52)
);

AOI22x1_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_51),
.B1(n_21),
.B2(n_20),
.Y(n_53)
);


endmodule