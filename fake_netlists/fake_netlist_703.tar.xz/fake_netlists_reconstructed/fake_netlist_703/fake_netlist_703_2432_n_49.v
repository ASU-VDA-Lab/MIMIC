module fake_netlist_703_2432_n_49 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_49);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_49;

wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_39;

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_16),
.B(n_6),
.Y(n_25)
);

OA21x2_ASAP7_75t_L g26 ( 
.A1(n_4),
.A2(n_18),
.B(n_17),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_1),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_5),
.B(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_3),
.Y(n_29)
);

OA21x2_ASAP7_75t_L g30 ( 
.A1(n_12),
.A2(n_20),
.B(n_0),
.Y(n_30)
);

NAND3xp33_ASAP7_75t_L g31 ( 
.A(n_7),
.B(n_2),
.C(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_13),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

INVx5_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

CKINVDCx11_ASAP7_75t_R g36 ( 
.A(n_33),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_34),
.Y(n_38)
);

AOI211xp5_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_32),
.B(n_31),
.C(n_28),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_26),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NOR2x1_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_30),
.Y(n_43)
);

AOI221xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_9),
.B1(n_8),
.B2(n_10),
.C(n_11),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_14),
.Y(n_45)
);

XOR2xp5_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_19),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

OAI221xp5_ASAP7_75t_R g49 ( 
.A1(n_48),
.A2(n_46),
.B1(n_23),
.B2(n_21),
.C(n_22),
.Y(n_49)
);


endmodule