module fake_netlist_703_2385_n_10 (n_0, n_1, n_10);

input n_0;
input n_1;

output n_10;

wire n_9;
wire n_4;
wire n_2;
wire n_7;
wire n_3;
wire n_8;
wire n_5;
wire n_6;

CKINVDCx5p33_ASAP7_75t_R g2 ( 
.A(n_0),
.Y(n_2)
);

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

INVx2_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

AOI221xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B1(n_3),
.B2(n_1),
.C(n_0),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_2),
.Y(n_7)
);

OAI211xp5_ASAP7_75t_SL g8 ( 
.A1(n_7),
.A2(n_4),
.B(n_0),
.C(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI222xp33_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_1),
.B1(n_5),
.B2(n_3),
.C1(n_8),
.C2(n_0),
.Y(n_10)
);


endmodule