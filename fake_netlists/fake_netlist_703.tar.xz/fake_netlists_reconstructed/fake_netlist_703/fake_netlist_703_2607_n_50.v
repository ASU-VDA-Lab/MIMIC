module fake_netlist_703_2607_n_50 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_50);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_50;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_31;
wire n_23;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_19;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

INVx2_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_4),
.B(n_6),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_12),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_7),
.B(n_17),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_0),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

AND2x2_ASAP7_75t_SL g28 ( 
.A(n_25),
.B(n_12),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_13),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_13),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

INVx2_ASAP7_75t_SL g32 ( 
.A(n_31),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_22),
.B1(n_21),
.B2(n_23),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_28),
.A2(n_23),
.B1(n_26),
.B2(n_20),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_29),
.Y(n_35)
);

CKINVDCx16_ASAP7_75t_R g36 ( 
.A(n_32),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_33),
.B1(n_30),
.B2(n_18),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_18),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_38),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_R g42 ( 
.A(n_39),
.B(n_14),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

NAND2xp33_ASAP7_75t_SL g44 ( 
.A(n_41),
.B(n_19),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_42),
.Y(n_45)
);

CKINVDCx20_ASAP7_75t_R g46 ( 
.A(n_44),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

OA22x2_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

AOI222xp33_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_46),
.B1(n_45),
.B2(n_48),
.C1(n_16),
.C2(n_15),
.Y(n_50)
);


endmodule