module fake_netlist_703_137_n_28 (n_4, n_2, n_3, n_1, n_5, n_0, n_28);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_28;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_6;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_7;
wire n_23;
wire n_8;
wire n_11;
wire n_19;
wire n_25;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_0),
.B(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_5),
.Y(n_9)
);

INVx3_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_1),
.B(n_4),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_2),
.B(n_0),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_2),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_3),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

AOI31xp33_ASAP7_75t_SL g17 ( 
.A1(n_14),
.A2(n_11),
.A3(n_7),
.B(n_8),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

AND2x2_ASAP7_75t_SL g19 ( 
.A(n_16),
.B(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_15),
.B(n_19),
.Y(n_23)
);

XNOR2x1_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_19),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_22),
.B(n_13),
.Y(n_25)
);

XNOR2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_19),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B1(n_6),
.B2(n_9),
.Y(n_27)
);

AO221x2_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_5),
.B1(n_25),
.B2(n_11),
.C(n_7),
.Y(n_28)
);


endmodule