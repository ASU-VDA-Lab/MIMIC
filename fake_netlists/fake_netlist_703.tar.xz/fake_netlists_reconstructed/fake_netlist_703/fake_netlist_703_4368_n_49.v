module fake_netlist_703_4368_n_49 (n_2, n_21, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_49);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_49;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_39;

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

NOR2x1_ASAP7_75t_L g25 ( 
.A(n_16),
.B(n_9),
.Y(n_25)
);

CKINVDCx11_ASAP7_75t_R g26 ( 
.A(n_7),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_2),
.A2(n_4),
.B1(n_21),
.B2(n_0),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_L g29 ( 
.A(n_6),
.B(n_5),
.C(n_3),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_23),
.A2(n_19),
.B1(n_18),
.B2(n_1),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_26),
.B(n_8),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_31),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_30),
.B1(n_32),
.B2(n_34),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_28),
.B1(n_29),
.B2(n_31),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI222xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_22),
.B1(n_19),
.B2(n_18),
.C1(n_11),
.C2(n_10),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_43),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_22),
.Y(n_46)
);

OAI21x1_ASAP7_75t_SL g47 ( 
.A1(n_44),
.A2(n_20),
.B(n_13),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_22),
.B1(n_45),
.B2(n_47),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);


endmodule