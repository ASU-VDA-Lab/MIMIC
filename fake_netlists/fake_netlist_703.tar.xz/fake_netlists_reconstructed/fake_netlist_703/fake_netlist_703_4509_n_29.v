module fake_netlist_703_4509_n_29 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_29);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_29;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_12;
wire n_28;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

AND2x6_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_7),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_5),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

AND3x2_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_7),
.C(n_6),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_6),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_12),
.B1(n_15),
.B2(n_13),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_12),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVxp67_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_19),
.B1(n_21),
.B2(n_13),
.C(n_0),
.Y(n_24)
);

AO22x2_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_9),
.B1(n_3),
.B2(n_1),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_26),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_25),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_25),
.B1(n_11),
.B2(n_10),
.Y(n_29)
);


endmodule