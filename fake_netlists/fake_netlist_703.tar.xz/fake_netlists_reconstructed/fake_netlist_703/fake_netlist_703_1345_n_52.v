module fake_netlist_703_1345_n_52 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_52);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_52;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_46;
wire n_41;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

BUFx3_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_14),
.B(n_15),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_7),
.B(n_17),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_1),
.B(n_12),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_13),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_3),
.B(n_6),
.Y(n_31)
);

AND2x6_ASAP7_75t_L g32 ( 
.A(n_10),
.B(n_18),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_2),
.Y(n_33)
);

INVxp67_ASAP7_75t_SL g34 ( 
.A(n_25),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_SL g35 ( 
.A(n_28),
.B(n_19),
.C(n_18),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_26),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_30),
.B1(n_24),
.B2(n_29),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_32),
.B(n_27),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OAI21xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_36),
.B(n_37),
.Y(n_41)
);

OR2x6_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_32),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_19),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_35),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_32),
.Y(n_46)
);

AND2x4_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_0),
.Y(n_47)
);

NOR3xp33_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_31),
.C(n_8),
.Y(n_48)
);

BUFx2_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

NOR2x1_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_9),
.Y(n_51)
);

AOI322xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_11),
.A3(n_16),
.B1(n_20),
.B2(n_21),
.C1(n_22),
.C2(n_51),
.Y(n_52)
);


endmodule