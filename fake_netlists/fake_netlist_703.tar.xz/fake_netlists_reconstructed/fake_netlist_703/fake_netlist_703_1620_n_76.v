module fake_netlist_703_1620_n_76 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_76);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_76;

wire n_54;
wire n_50;
wire n_61;
wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_22;
wire n_66;
wire n_47;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_71;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_70;
wire n_23;
wire n_46;
wire n_41;
wire n_31;
wire n_69;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_68;
wire n_72;
wire n_33;
wire n_65;
wire n_73;
wire n_74;
wire n_36;
wire n_75;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_67;
wire n_39;
wire n_55;

AND2x4_ASAP7_75t_L g21 ( 
.A(n_9),
.B(n_13),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_11),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_8),
.B(n_1),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_14),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_4),
.B(n_0),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_19),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_12),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_6),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_7),
.B(n_0),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_10),
.B(n_16),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_20),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_2),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_29),
.B(n_2),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_27),
.B(n_16),
.Y(n_36)
);

INVx3_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

NOR3xp33_ASAP7_75t_SL g38 ( 
.A(n_33),
.B(n_19),
.C(n_17),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_29),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_27),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_23),
.Y(n_41)
);

NAND2xp33_ASAP7_75t_SL g42 ( 
.A(n_26),
.B(n_17),
.Y(n_42)
);

OAI21xp5_ASAP7_75t_L g43 ( 
.A1(n_21),
.A2(n_5),
.B(n_3),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_26),
.B(n_21),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_25),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_34),
.Y(n_46)
);

OAI22xp5_ASAP7_75t_L g47 ( 
.A1(n_41),
.A2(n_22),
.B1(n_28),
.B2(n_26),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_37),
.B(n_30),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_37),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_42),
.A2(n_22),
.B1(n_26),
.B2(n_21),
.Y(n_50)
);

OR2x6_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_43),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

OAI31xp33_ASAP7_75t_L g53 ( 
.A1(n_47),
.A2(n_50),
.A3(n_41),
.B(n_34),
.Y(n_53)
);

AOI31xp33_ASAP7_75t_L g54 ( 
.A1(n_44),
.A2(n_35),
.A3(n_36),
.B(n_38),
.Y(n_54)
);

OR2x2_ASAP7_75t_L g55 ( 
.A(n_45),
.B(n_37),
.Y(n_55)
);

HB1xp67_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_44),
.Y(n_57)
);

OAI31xp33_ASAP7_75t_L g58 ( 
.A1(n_53),
.A2(n_48),
.A3(n_23),
.B(n_21),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_51),
.B(n_37),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_59),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_59),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_57),
.Y(n_62)
);

INVx4_ASAP7_75t_L g63 ( 
.A(n_56),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_58),
.B(n_53),
.Y(n_64)
);

AOI21xp5_ASAP7_75t_L g65 ( 
.A1(n_62),
.A2(n_51),
.B(n_54),
.Y(n_65)
);

NAND2xp33_ASAP7_75t_SL g66 ( 
.A(n_64),
.B(n_31),
.Y(n_66)
);

AOI21xp33_ASAP7_75t_SL g67 ( 
.A1(n_60),
.A2(n_20),
.B(n_32),
.Y(n_67)
);

AND2x4_ASAP7_75t_L g68 ( 
.A(n_61),
.B(n_52),
.Y(n_68)
);

NAND2x1_ASAP7_75t_SL g69 ( 
.A(n_63),
.B(n_39),
.Y(n_69)
);

AOI22xp33_ASAP7_75t_L g70 ( 
.A1(n_66),
.A2(n_62),
.B1(n_63),
.B2(n_39),
.Y(n_70)
);

OAI22xp5_ASAP7_75t_L g71 ( 
.A1(n_65),
.A2(n_67),
.B1(n_63),
.B2(n_68),
.Y(n_71)
);

NOR2x1p5_ASAP7_75t_L g72 ( 
.A(n_69),
.B(n_39),
.Y(n_72)
);

AOI22xp33_ASAP7_75t_R g73 ( 
.A1(n_68),
.A2(n_15),
.B1(n_24),
.B2(n_56),
.Y(n_73)
);

CKINVDCx20_ASAP7_75t_R g74 ( 
.A(n_71),
.Y(n_74)
);

NAND2xp33_ASAP7_75t_SL g75 ( 
.A(n_72),
.B(n_70),
.Y(n_75)
);

AOI22xp33_ASAP7_75t_L g76 ( 
.A1(n_74),
.A2(n_72),
.B1(n_73),
.B2(n_75),
.Y(n_76)
);


endmodule