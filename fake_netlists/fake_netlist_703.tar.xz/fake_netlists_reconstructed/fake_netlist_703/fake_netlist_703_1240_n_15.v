module fake_netlist_703_1240_n_15 (n_0, n_2, n_1, n_15);

input n_0;
input n_2;
input n_1;

output n_15;

wire n_9;
wire n_7;
wire n_4;
wire n_14;
wire n_3;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

CKINVDCx20_ASAP7_75t_R g3 ( 
.A(n_1),
.Y(n_3)
);

INVx5_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

BUFx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVxp67_ASAP7_75t_SL g8 ( 
.A(n_5),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_4),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_4),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_8),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_6),
.B(n_4),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_6),
.B(n_3),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.C1(n_11),
.C2(n_13),
.Y(n_15)
);


endmodule