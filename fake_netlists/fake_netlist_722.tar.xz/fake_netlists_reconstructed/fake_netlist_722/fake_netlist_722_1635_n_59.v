module fake_netlist_722_1635_n_59 (n_3, n_14, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_19, n_5, n_59);

input n_3;
input n_14;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_19;
input n_5;

output n_59;

wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_20;
wire n_27;
wire n_24;
wire n_36;
wire n_37;
wire n_29;
wire n_41;
wire n_55;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_57;
wire n_25;
wire n_46;
wire n_23;
wire n_56;
wire n_21;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_22;

INVx6_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_0),
.B1(n_12),
.B2(n_15),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_10),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

OA21x2_ASAP7_75t_L g24 ( 
.A1(n_1),
.A2(n_9),
.B(n_13),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_3),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_2),
.B(n_6),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_14),
.B(n_5),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_2),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_0),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

A2O1A1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_22),
.A2(n_16),
.B(n_15),
.C(n_11),
.Y(n_32)
);

AOI21x1_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_28),
.B(n_24),
.Y(n_33)
);

AO31x2_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_30),
.A3(n_26),
.B(n_23),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_34),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_23),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_35),
.Y(n_41)
);

OAI21xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_36),
.B(n_29),
.Y(n_42)
);

OAI21xp33_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_29),
.B(n_21),
.Y(n_43)
);

A2O1A1Ixp33_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_22),
.B(n_21),
.C(n_27),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_33),
.B(n_22),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_L g46 ( 
.A1(n_41),
.A2(n_24),
.B(n_22),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

NAND4xp25_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_31),
.C(n_17),
.D(n_11),
.Y(n_48)
);

NOR3xp33_ASAP7_75t_L g49 ( 
.A(n_42),
.B(n_45),
.C(n_46),
.Y(n_49)
);

OAI211xp5_ASAP7_75t_SL g50 ( 
.A1(n_43),
.A2(n_25),
.B(n_20),
.C(n_18),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_43),
.B(n_25),
.Y(n_51)
);

NAND4xp75_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_24),
.C(n_19),
.D(n_18),
.Y(n_52)
);

AOI31xp33_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_19),
.A3(n_25),
.B(n_24),
.Y(n_53)
);

NAND2xp33_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_25),
.Y(n_54)
);

OR2x2_ASAP7_75t_L g55 ( 
.A(n_48),
.B(n_25),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_55),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

AOI221xp5_ASAP7_75t_L g58 ( 
.A1(n_56),
.A2(n_53),
.B1(n_50),
.B2(n_52),
.C(n_20),
.Y(n_58)
);

AO221x2_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_56),
.B1(n_57),
.B2(n_7),
.C(n_8),
.Y(n_59)
);


endmodule