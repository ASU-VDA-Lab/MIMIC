module fake_netlist_722_2703_n_76 (n_3, n_14, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_16, n_6, n_5, n_76);

input n_3;
input n_14;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_16;
input n_6;
input n_5;

output n_76;

wire n_60;
wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_61;
wire n_72;
wire n_75;
wire n_30;
wire n_63;
wire n_35;
wire n_54;
wire n_68;
wire n_20;
wire n_73;
wire n_27;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_66;
wire n_55;
wire n_57;
wire n_31;
wire n_39;
wire n_28;
wire n_45;
wire n_52;
wire n_43;
wire n_71;
wire n_65;
wire n_25;
wire n_46;
wire n_70;
wire n_23;
wire n_56;
wire n_21;
wire n_47;
wire n_67;
wire n_26;
wire n_44;
wire n_74;
wire n_42;
wire n_53;
wire n_64;
wire n_62;
wire n_69;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_59;
wire n_22;
wire n_19;

INVx2_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_15),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

INVx5_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_3),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_11),
.Y(n_27)
);

OA21x2_ASAP7_75t_L g28 ( 
.A1(n_8),
.A2(n_10),
.B(n_1),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_9),
.B(n_16),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_17),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_19),
.B(n_0),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_24),
.B(n_0),
.Y(n_32)
);

AND2x4_ASAP7_75t_SL g33 ( 
.A(n_29),
.B(n_12),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_22),
.A2(n_5),
.B1(n_2),
.B2(n_1),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_22),
.B(n_2),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_19),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_26),
.B(n_5),
.Y(n_37)
);

NOR3xp33_ASAP7_75t_SL g38 ( 
.A(n_30),
.B(n_17),
.C(n_23),
.Y(n_38)
);

BUFx6f_ASAP7_75t_L g39 ( 
.A(n_20),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_25),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_37),
.A2(n_29),
.B(n_27),
.Y(n_41)
);

AO31x2_ASAP7_75t_L g42 ( 
.A1(n_31),
.A2(n_30),
.A3(n_25),
.B(n_26),
.Y(n_42)
);

AOI31xp67_ASAP7_75t_L g43 ( 
.A1(n_32),
.A2(n_21),
.A3(n_27),
.B(n_29),
.Y(n_43)
);

AO31x2_ASAP7_75t_L g44 ( 
.A1(n_38),
.A2(n_35),
.A3(n_33),
.B(n_34),
.Y(n_44)
);

NAND2x1p5_ASAP7_75t_L g45 ( 
.A(n_39),
.B(n_27),
.Y(n_45)
);

OAI21x1_ASAP7_75t_L g46 ( 
.A1(n_34),
.A2(n_28),
.B(n_21),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_42),
.B(n_38),
.Y(n_47)
);

AO21x2_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_41),
.B(n_21),
.Y(n_48)
);

AO21x2_ASAP7_75t_L g49 ( 
.A1(n_41),
.A2(n_28),
.B(n_20),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_42),
.Y(n_50)
);

OAI21x1_ASAP7_75t_L g51 ( 
.A1(n_45),
.A2(n_28),
.B(n_24),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_L g53 ( 
.A(n_47),
.B(n_40),
.C(n_20),
.Y(n_53)
);

INVxp67_ASAP7_75t_SL g54 ( 
.A(n_51),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_54),
.B(n_47),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_55),
.A2(n_50),
.B1(n_47),
.B2(n_45),
.Y(n_59)
);

INVx1_ASAP7_75t_SL g60 ( 
.A(n_58),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_L g61 ( 
.A1(n_58),
.A2(n_53),
.B1(n_48),
.B2(n_55),
.Y(n_61)
);

AOI22xp5_ASAP7_75t_L g62 ( 
.A1(n_56),
.A2(n_48),
.B1(n_49),
.B2(n_51),
.Y(n_62)
);

AOI21xp5_ASAP7_75t_L g63 ( 
.A1(n_59),
.A2(n_48),
.B(n_49),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_SL g64 ( 
.A(n_57),
.B(n_24),
.Y(n_64)
);

AOI211xp5_ASAP7_75t_L g65 ( 
.A1(n_60),
.A2(n_20),
.B(n_39),
.C(n_44),
.Y(n_65)
);

AOI222xp33_ASAP7_75t_L g66 ( 
.A1(n_64),
.A2(n_20),
.B1(n_24),
.B2(n_44),
.C1(n_43),
.C2(n_39),
.Y(n_66)
);

OAI211xp5_ASAP7_75t_L g67 ( 
.A1(n_63),
.A2(n_24),
.B(n_44),
.C(n_39),
.Y(n_67)
);

NOR4xp75_ASAP7_75t_L g68 ( 
.A(n_62),
.B(n_42),
.C(n_49),
.D(n_48),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_61),
.Y(n_69)
);

NOR3xp33_ASAP7_75t_L g70 ( 
.A(n_67),
.B(n_49),
.C(n_65),
.Y(n_70)
);

AND2x2_ASAP7_75t_L g71 ( 
.A(n_69),
.B(n_66),
.Y(n_71)
);

AND2x4_ASAP7_75t_L g72 ( 
.A(n_68),
.B(n_69),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_72),
.Y(n_73)
);

NOR2xp33_ASAP7_75t_L g74 ( 
.A(n_72),
.B(n_71),
.Y(n_74)
);

NOR2x1_ASAP7_75t_L g75 ( 
.A(n_73),
.B(n_70),
.Y(n_75)
);

OA21x2_ASAP7_75t_L g76 ( 
.A1(n_75),
.A2(n_74),
.B(n_70),
.Y(n_76)
);


endmodule