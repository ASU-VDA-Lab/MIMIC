module fake_netlist_722_198_n_45 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_6, n_19, n_5, n_45);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_6;
input n_19;
input n_5;

output n_45;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_24;
wire n_37;
wire n_29;
wire n_41;
wire n_43;
wire n_31;
wire n_28;
wire n_39;
wire n_25;
wire n_22;
wire n_23;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_26;

INVx1_ASAP7_75t_SL g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_14),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_15),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_2),
.B(n_0),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_21),
.B(n_12),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_9),
.B(n_3),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_8),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_6),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_25),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_26),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_32),
.B1(n_35),
.B2(n_33),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_23),
.B1(n_22),
.B2(n_30),
.C(n_27),
.Y(n_37)
);

OAI211xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_29),
.B(n_28),
.C(n_18),
.Y(n_38)
);

NAND4xp25_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_18),
.C(n_7),
.D(n_1),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_10),
.Y(n_40)
);

O2A1O1Ixp33_ASAP7_75t_SL g41 ( 
.A1(n_40),
.A2(n_17),
.B(n_16),
.C(n_11),
.Y(n_41)
);

NAND2x1_ASAP7_75t_SL g42 ( 
.A(n_41),
.B(n_19),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_20),
.C(n_38),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);


endmodule