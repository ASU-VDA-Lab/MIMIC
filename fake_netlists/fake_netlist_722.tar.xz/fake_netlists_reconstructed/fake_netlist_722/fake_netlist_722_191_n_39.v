module fake_netlist_722_191_n_39 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_17, n_5, n_39);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_17;
input n_5;

output n_39;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_24;
wire n_37;
wire n_29;
wire n_36;
wire n_18;
wire n_31;
wire n_28;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_38;
wire n_34;
wire n_22;
wire n_19;

NOR3xp33_ASAP7_75t_L g18 ( 
.A(n_5),
.B(n_2),
.C(n_13),
.Y(n_18)
);

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_5),
.A2(n_11),
.B(n_14),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_3),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_7),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_9),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_6),
.B(n_16),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_22),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_15),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

AOI221x1_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_18),
.B1(n_21),
.B2(n_24),
.C(n_19),
.Y(n_29)
);

OAI21xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_25),
.B(n_26),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_25),
.B1(n_18),
.B2(n_21),
.C(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_31),
.Y(n_34)
);

XNOR2x1_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_15),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NOR3xp33_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_19),
.C(n_20),
.Y(n_37)
);

AOI322xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_17),
.A3(n_16),
.B1(n_8),
.B2(n_10),
.C1(n_0),
.C2(n_1),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_36),
.B1(n_17),
.B2(n_12),
.Y(n_39)
);


endmodule