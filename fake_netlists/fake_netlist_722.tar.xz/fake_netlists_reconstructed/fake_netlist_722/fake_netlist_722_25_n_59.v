module fake_netlist_722_25_n_59 (n_3, n_14, n_20, n_0, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_25, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_59);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_25;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_59;

wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_27;
wire n_36;
wire n_37;
wire n_29;
wire n_41;
wire n_55;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_57;
wire n_46;
wire n_56;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;

INVx1_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_4),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_L g29 ( 
.A(n_3),
.B(n_23),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_11),
.B(n_22),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_8),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_9),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_12),
.A2(n_14),
.B1(n_1),
.B2(n_13),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_10),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_5),
.Y(n_35)
);

BUFx6f_ASAP7_75t_L g36 ( 
.A(n_19),
.Y(n_36)
);

INVx2_ASAP7_75t_SL g37 ( 
.A(n_35),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_28),
.B(n_24),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_31),
.Y(n_39)
);

BUFx3_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

INVx2_ASAP7_75t_SL g41 ( 
.A(n_40),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_26),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_L g43 ( 
.A1(n_38),
.A2(n_33),
.B1(n_32),
.B2(n_30),
.Y(n_43)
);

AO21x2_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_38),
.B(n_29),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_37),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_41),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

BUFx3_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_24),
.Y(n_49)
);

OAI211xp5_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_27),
.B(n_36),
.C(n_0),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_27),
.Y(n_51)
);

OAI221xp5_ASAP7_75t_SL g52 ( 
.A1(n_48),
.A2(n_7),
.B1(n_6),
.B2(n_15),
.C(n_16),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

OR2x2_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_17),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

INVx2_ASAP7_75t_SL g56 ( 
.A(n_53),
.Y(n_56)
);

OA21x2_ASAP7_75t_L g57 ( 
.A1(n_55),
.A2(n_20),
.B(n_18),
.Y(n_57)
);

CKINVDCx20_ASAP7_75t_R g58 ( 
.A(n_56),
.Y(n_58)
);

AOI22x1_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_54),
.B1(n_57),
.B2(n_21),
.Y(n_59)
);


endmodule