module fake_netlist_722_1835_n_67 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_17, n_5, n_67);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_17;
input n_5;

output n_67;

wire n_60;
wire n_58;
wire n_32;
wire n_33;
wire n_48;
wire n_61;
wire n_30;
wire n_63;
wire n_54;
wire n_35;
wire n_20;
wire n_27;
wire n_37;
wire n_36;
wire n_29;
wire n_24;
wire n_41;
wire n_66;
wire n_55;
wire n_43;
wire n_18;
wire n_31;
wire n_39;
wire n_45;
wire n_52;
wire n_28;
wire n_57;
wire n_65;
wire n_25;
wire n_22;
wire n_46;
wire n_23;
wire n_56;
wire n_21;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_64;
wire n_62;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_59;
wire n_26;
wire n_19;

INVx1_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_0),
.A2(n_1),
.B(n_16),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_15),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_2),
.B(n_8),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_14),
.B(n_4),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_17),
.A2(n_12),
.B1(n_0),
.B2(n_5),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_7),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_13),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_6),
.Y(n_31)
);

NAND2x1_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_1),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_25),
.B(n_2),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_25),
.B(n_3),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_23),
.B(n_9),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_25),
.B(n_29),
.Y(n_37)
);

NOR2x1p5_ASAP7_75t_L g38 ( 
.A(n_21),
.B(n_20),
.Y(n_38)
);

INVx4_ASAP7_75t_L g39 ( 
.A(n_29),
.Y(n_39)
);

OA21x2_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_27),
.B(n_18),
.Y(n_40)
);

AOI221x1_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_31),
.B1(n_27),
.B2(n_18),
.C(n_24),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_33),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_34),
.A2(n_26),
.B1(n_22),
.B2(n_19),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

INVx3_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_40),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

BUFx2_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_45),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_44),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_46),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_49),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_41),
.Y(n_55)
);

NOR3xp33_ASAP7_75t_L g56 ( 
.A(n_55),
.B(n_32),
.C(n_34),
.Y(n_56)
);

AOI22xp33_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_35),
.B1(n_51),
.B2(n_38),
.Y(n_57)
);

OAI22xp5_ASAP7_75t_L g58 ( 
.A1(n_52),
.A2(n_53),
.B1(n_51),
.B2(n_54),
.Y(n_58)
);

AND4x1_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_19),
.C(n_43),
.D(n_28),
.Y(n_59)
);

NOR2xp67_ASAP7_75t_L g60 ( 
.A(n_58),
.B(n_47),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_40),
.Y(n_61)
);

AND3x4_ASAP7_75t_L g62 ( 
.A(n_59),
.B(n_28),
.C(n_60),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_61),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_63),
.Y(n_64)
);

NOR2xp33_ASAP7_75t_L g65 ( 
.A(n_62),
.B(n_28),
.Y(n_65)
);

OR2x6_ASAP7_75t_L g66 ( 
.A(n_65),
.B(n_64),
.Y(n_66)
);

OR2x6_ASAP7_75t_L g67 ( 
.A(n_66),
.B(n_62),
.Y(n_67)
);


endmodule