module fake_netlist_722_108_n_35 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_6, n_14, n_0, n_3, n_4, n_5, n_35);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_35;

wire n_32;
wire n_33;
wire n_30;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_31;
wire n_18;
wire n_28;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_34;
wire n_16;
wire n_22;
wire n_19;

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_15),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

NAND2x1_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_18),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_28),
.Y(n_29)
);

NAND4xp75_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_25),
.C(n_24),
.D(n_1),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_17),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_20),
.B1(n_18),
.B2(n_2),
.Y(n_33)
);

OR3x1_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_32),
.C(n_4),
.Y(n_34)
);

AOI322xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_7),
.A3(n_6),
.B1(n_13),
.B2(n_14),
.C1(n_8),
.C2(n_9),
.Y(n_35)
);


endmodule