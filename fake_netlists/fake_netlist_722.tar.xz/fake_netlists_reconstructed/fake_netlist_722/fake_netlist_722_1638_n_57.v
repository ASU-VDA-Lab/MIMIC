module fake_netlist_722_1638_n_57 (n_3, n_14, n_20, n_0, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_25, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_26, n_16, n_22, n_6, n_19, n_5, n_57);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_25;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_26;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_57;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_27;
wire n_36;
wire n_29;
wire n_41;
wire n_37;
wire n_55;
wire n_43;
wire n_31;
wire n_39;
wire n_28;
wire n_45;
wire n_52;
wire n_46;
wire n_56;
wire n_47;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_40;
wire n_34;
wire n_51;

AND2x4_ASAP7_75t_L g27 ( 
.A(n_17),
.B(n_7),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_18),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_8),
.B(n_24),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_4),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_16),
.Y(n_31)
);

AND2x6_ASAP7_75t_L g32 ( 
.A(n_20),
.B(n_15),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_25),
.B(n_22),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_5),
.B(n_13),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_2),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_31),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_37)
);

OAI21xp5_ASAP7_75t_L g38 ( 
.A1(n_30),
.A2(n_9),
.B(n_6),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_35),
.B(n_10),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_31),
.Y(n_41)
);

INVx3_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_38),
.A2(n_35),
.B(n_29),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_37),
.Y(n_44)
);

OR2x2_ASAP7_75t_SL g45 ( 
.A(n_41),
.B(n_28),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_42),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_42),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_43),
.Y(n_48)
);

INVxp67_ASAP7_75t_L g49 ( 
.A(n_46),
.Y(n_49)
);

OAI322xp33_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_34),
.A3(n_33),
.B1(n_43),
.B2(n_32),
.C1(n_27),
.C2(n_11),
.Y(n_50)
);

A2O1A1Ixp33_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_27),
.B(n_32),
.C(n_12),
.Y(n_51)
);

NOR2x1_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_32),
.Y(n_52)
);

BUFx2_ASAP7_75t_L g53 ( 
.A(n_51),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);

HB1xp67_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_54),
.Y(n_56)
);

AOI322xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_55),
.A3(n_21),
.B1(n_19),
.B2(n_14),
.C1(n_26),
.C2(n_23),
.Y(n_57)
);


endmodule