module fake_netlist_722_3400_n_24 (n_1, n_2, n_0, n_3, n_4, n_5, n_24);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;
input n_5;

output n_24;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_7;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_8;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_6;
wire n_19;

NAND2xp33_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_2),
.Y(n_6)
);

AOI22xp5_ASAP7_75t_L g7 ( 
.A1(n_1),
.A2(n_2),
.B1(n_3),
.B2(n_5),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_3),
.B(n_4),
.Y(n_9)
);

BUFx10_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

INVx8_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_10),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_11),
.B(n_7),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_14),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_14),
.B1(n_13),
.B2(n_9),
.Y(n_19)
);

A2O1A1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_12),
.B(n_15),
.C(n_14),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_14),
.B1(n_15),
.B2(n_2),
.C(n_3),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_5),
.B1(n_4),
.B2(n_0),
.Y(n_23)
);

AOI222xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_0),
.B1(n_22),
.B2(n_6),
.C1(n_21),
.C2(n_11),
.Y(n_24)
);


endmodule