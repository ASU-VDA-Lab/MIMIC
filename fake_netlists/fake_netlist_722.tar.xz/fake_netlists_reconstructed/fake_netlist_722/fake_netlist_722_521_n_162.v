module fake_netlist_722_521_n_162 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_6, n_19, n_5, n_162);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_6;
input n_19;
input n_5;

output n_162;

wire n_154;
wire n_68;
wire n_82;
wire n_37;
wire n_112;
wire n_141;
wire n_31;
wire n_39;
wire n_121;
wire n_65;
wire n_140;
wire n_144;
wire n_128;
wire n_56;
wire n_130;
wire n_159;
wire n_94;
wire n_62;
wire n_69;
wire n_123;
wire n_97;
wire n_135;
wire n_139;
wire n_55;
wire n_148;
wire n_110;
wire n_102;
wire n_60;
wire n_105;
wire n_33;
wire n_75;
wire n_61;
wire n_106;
wire n_79;
wire n_30;
wire n_118;
wire n_54;
wire n_73;
wire n_77;
wire n_27;
wire n_125;
wire n_24;
wire n_131;
wire n_85;
wire n_126;
wire n_120;
wire n_116;
wire n_132;
wire n_70;
wire n_142;
wire n_129;
wire n_67;
wire n_81;
wire n_92;
wire n_155;
wire n_44;
wire n_74;
wire n_124;
wire n_53;
wire n_64;
wire n_107;
wire n_138;
wire n_49;
wire n_40;
wire n_51;
wire n_147;
wire n_59;
wire n_111;
wire n_161;
wire n_117;
wire n_22;
wire n_93;
wire n_158;
wire n_84;
wire n_32;
wire n_48;
wire n_143;
wire n_35;
wire n_136;
wire n_96;
wire n_104;
wire n_115;
wire n_41;
wire n_98;
wire n_100;
wire n_145;
wire n_76;
wire n_57;
wire n_43;
wire n_137;
wire n_71;
wire n_25;
wire n_113;
wire n_80;
wire n_108;
wire n_119;
wire n_160;
wire n_87;
wire n_42;
wire n_156;
wire n_34;
wire n_89;
wire n_58;
wire n_86;
wire n_72;
wire n_114;
wire n_151;
wire n_90;
wire n_63;
wire n_101;
wire n_127;
wire n_146;
wire n_36;
wire n_29;
wire n_66;
wire n_83;
wire n_91;
wire n_95;
wire n_150;
wire n_152;
wire n_45;
wire n_28;
wire n_52;
wire n_133;
wire n_78;
wire n_153;
wire n_46;
wire n_122;
wire n_88;
wire n_134;
wire n_23;
wire n_99;
wire n_157;
wire n_47;
wire n_50;
wire n_38;
wire n_109;
wire n_103;
wire n_149;
wire n_26;

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

INVxp67_ASAP7_75t_SL g24 ( 
.A(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_21),
.Y(n_26)
);

INVxp67_ASAP7_75t_SL g27 ( 
.A(n_2),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_5),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_15),
.Y(n_32)
);

CKINVDCx11_ASAP7_75t_R g33 ( 
.A(n_23),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_22),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_31),
.Y(n_36)
);

BUFx10_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_28),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_23),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_34),
.Y(n_41)
);

NOR2xp33_ASAP7_75t_L g42 ( 
.A(n_36),
.B(n_31),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_35),
.A2(n_29),
.B1(n_26),
.B2(n_25),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_36),
.B(n_24),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_34),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_34),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_36),
.Y(n_47)
);

INVxp67_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

AO31x2_ASAP7_75t_L g49 ( 
.A1(n_42),
.A2(n_35),
.A3(n_39),
.B(n_36),
.Y(n_49)
);

OAI21x1_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_34),
.B(n_35),
.Y(n_50)
);

INVx3_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_46),
.Y(n_52)
);

BUFx12f_ASAP7_75t_L g53 ( 
.A(n_44),
.Y(n_53)
);

AOI21x1_ASAP7_75t_SL g54 ( 
.A1(n_43),
.A2(n_37),
.B(n_38),
.Y(n_54)
);

AOI21xp5_ASAP7_75t_L g55 ( 
.A1(n_40),
.A2(n_46),
.B(n_41),
.Y(n_55)
);

NAND2x1p5_ASAP7_75t_L g56 ( 
.A(n_42),
.B(n_34),
.Y(n_56)
);

OAI21x1_ASAP7_75t_L g57 ( 
.A1(n_43),
.A2(n_34),
.B(n_39),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_SL g58 ( 
.A(n_40),
.B(n_37),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_50),
.Y(n_59)
);

AOI21xp5_ASAP7_75t_SL g60 ( 
.A1(n_56),
.A2(n_27),
.B(n_38),
.Y(n_60)
);

OA21x2_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_38),
.B(n_25),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_50),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_50),
.Y(n_63)
);

HB1xp67_ASAP7_75t_L g64 ( 
.A(n_48),
.Y(n_64)
);

OAI22xp5_ASAP7_75t_L g65 ( 
.A1(n_56),
.A2(n_38),
.B1(n_34),
.B2(n_26),
.Y(n_65)
);

OAI22xp5_ASAP7_75t_L g66 ( 
.A1(n_56),
.A2(n_38),
.B1(n_30),
.B2(n_29),
.Y(n_66)
);

BUFx2_ASAP7_75t_L g67 ( 
.A(n_53),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_52),
.Y(n_68)
);

BUFx2_ASAP7_75t_L g69 ( 
.A(n_67),
.Y(n_69)
);

INVx2_ASAP7_75t_SL g70 ( 
.A(n_68),
.Y(n_70)
);

AND2x2_ASAP7_75t_L g71 ( 
.A(n_68),
.B(n_49),
.Y(n_71)
);

NOR4xp25_ASAP7_75t_SL g72 ( 
.A(n_67),
.B(n_24),
.C(n_32),
.D(n_30),
.Y(n_72)
);

BUFx2_ASAP7_75t_L g73 ( 
.A(n_64),
.Y(n_73)
);

AND2x2_ASAP7_75t_L g74 ( 
.A(n_68),
.B(n_49),
.Y(n_74)
);

INVx2_ASAP7_75t_L g75 ( 
.A(n_59),
.Y(n_75)
);

BUFx3_ASAP7_75t_L g76 ( 
.A(n_59),
.Y(n_76)
);

AND4x1_ASAP7_75t_L g77 ( 
.A(n_71),
.B(n_33),
.C(n_60),
.D(n_62),
.Y(n_77)
);

AO21x2_ASAP7_75t_L g78 ( 
.A1(n_75),
.A2(n_63),
.B(n_62),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_70),
.Y(n_79)
);

INVx2_ASAP7_75t_L g80 ( 
.A(n_75),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_75),
.Y(n_81)
);

OR2x2_ASAP7_75t_L g82 ( 
.A(n_73),
.B(n_74),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_70),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_82),
.Y(n_84)
);

NAND2x1_ASAP7_75t_L g85 ( 
.A(n_80),
.B(n_75),
.Y(n_85)
);

OR2x2_ASAP7_75t_L g86 ( 
.A(n_82),
.B(n_73),
.Y(n_86)
);

OR2x2_ASAP7_75t_L g87 ( 
.A(n_80),
.B(n_73),
.Y(n_87)
);

AND2x4_ASAP7_75t_SL g88 ( 
.A(n_79),
.B(n_71),
.Y(n_88)
);

INVx2_ASAP7_75t_SL g89 ( 
.A(n_77),
.Y(n_89)
);

INVx1_ASAP7_75t_SL g90 ( 
.A(n_80),
.Y(n_90)
);

INVx2_ASAP7_75t_L g91 ( 
.A(n_90),
.Y(n_91)
);

INVx1_ASAP7_75t_L g92 ( 
.A(n_90),
.Y(n_92)
);

AOI21xp33_ASAP7_75t_SL g93 ( 
.A1(n_89),
.A2(n_86),
.B(n_87),
.Y(n_93)
);

HB1xp67_ASAP7_75t_L g94 ( 
.A(n_85),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_84),
.Y(n_95)
);

INVxp33_ASAP7_75t_L g96 ( 
.A(n_88),
.Y(n_96)
);

OAI31xp33_ASAP7_75t_L g97 ( 
.A1(n_88),
.A2(n_66),
.A3(n_69),
.B(n_65),
.Y(n_97)
);

INVx1_ASAP7_75t_SL g98 ( 
.A(n_90),
.Y(n_98)
);

AOI21xp33_ASAP7_75t_SL g99 ( 
.A1(n_89),
.A2(n_74),
.B(n_71),
.Y(n_99)
);

OAI221xp5_ASAP7_75t_SL g100 ( 
.A1(n_89),
.A2(n_77),
.B1(n_69),
.B2(n_48),
.C(n_64),
.Y(n_100)
);

A2O1A1Ixp33_ASAP7_75t_L g101 ( 
.A1(n_100),
.A2(n_69),
.B(n_74),
.C(n_66),
.Y(n_101)
);

AOI222xp33_ASAP7_75t_L g102 ( 
.A1(n_95),
.A2(n_33),
.B1(n_65),
.B2(n_53),
.C1(n_70),
.C2(n_81),
.Y(n_102)
);

O2A1O1Ixp33_ASAP7_75t_L g103 ( 
.A1(n_100),
.A2(n_56),
.B(n_70),
.C(n_72),
.Y(n_103)
);

AOI21xp33_ASAP7_75t_SL g104 ( 
.A1(n_97),
.A2(n_6),
.B(n_5),
.Y(n_104)
);

INVx5_ASAP7_75t_L g105 ( 
.A(n_91),
.Y(n_105)
);

O2A1O1Ixp33_ASAP7_75t_L g106 ( 
.A1(n_97),
.A2(n_72),
.B(n_81),
.C(n_79),
.Y(n_106)
);

AOI221x1_ASAP7_75t_L g107 ( 
.A1(n_93),
.A2(n_81),
.B1(n_83),
.B2(n_63),
.C(n_6),
.Y(n_107)
);

AOI21xp5_ASAP7_75t_L g108 ( 
.A1(n_94),
.A2(n_76),
.B(n_78),
.Y(n_108)
);

AOI32xp33_ASAP7_75t_L g109 ( 
.A1(n_96),
.A2(n_95),
.A3(n_99),
.B1(n_98),
.B2(n_94),
.Y(n_109)
);

O2A1O1Ixp5_ASAP7_75t_L g110 ( 
.A1(n_96),
.A2(n_83),
.B(n_55),
.C(n_52),
.Y(n_110)
);

AOI21xp5_ASAP7_75t_L g111 ( 
.A1(n_98),
.A2(n_76),
.B(n_78),
.Y(n_111)
);

OAI21xp5_ASAP7_75t_L g112 ( 
.A1(n_99),
.A2(n_57),
.B(n_76),
.Y(n_112)
);

AOI21x1_ASAP7_75t_L g113 ( 
.A1(n_92),
.A2(n_61),
.B(n_57),
.Y(n_113)
);

OAI21xp5_ASAP7_75t_SL g114 ( 
.A1(n_93),
.A2(n_8),
.B(n_7),
.Y(n_114)
);

NAND2xp5_ASAP7_75t_L g115 ( 
.A(n_109),
.B(n_92),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_105),
.Y(n_116)
);

INVx1_ASAP7_75t_L g117 ( 
.A(n_105),
.Y(n_117)
);

NAND2xp5_ASAP7_75t_L g118 ( 
.A(n_101),
.B(n_91),
.Y(n_118)
);

AOI32xp33_ASAP7_75t_L g119 ( 
.A1(n_114),
.A2(n_91),
.A3(n_11),
.B1(n_9),
.B2(n_10),
.Y(n_119)
);

HB1xp67_ASAP7_75t_L g120 ( 
.A(n_105),
.Y(n_120)
);

INVx1_ASAP7_75t_L g121 ( 
.A(n_108),
.Y(n_121)
);

INVx1_ASAP7_75t_L g122 ( 
.A(n_110),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_106),
.Y(n_123)
);

AND2x2_ASAP7_75t_L g124 ( 
.A(n_112),
.B(n_78),
.Y(n_124)
);

INVx1_ASAP7_75t_L g125 ( 
.A(n_107),
.Y(n_125)
);

NAND2xp5_ASAP7_75t_SL g126 ( 
.A(n_111),
.B(n_76),
.Y(n_126)
);

NAND2xp5_ASAP7_75t_L g127 ( 
.A(n_104),
.B(n_78),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_113),
.Y(n_128)
);

NAND2xp5_ASAP7_75t_L g129 ( 
.A(n_102),
.B(n_9),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_103),
.Y(n_130)
);

NOR2x1_ASAP7_75t_L g131 ( 
.A(n_114),
.B(n_61),
.Y(n_131)
);

XNOR2xp5_ASAP7_75t_L g132 ( 
.A(n_129),
.B(n_11),
.Y(n_132)
);

NAND2xp5_ASAP7_75t_L g133 ( 
.A(n_115),
.B(n_12),
.Y(n_133)
);

NAND2xp5_ASAP7_75t_L g134 ( 
.A(n_130),
.B(n_12),
.Y(n_134)
);

NOR4xp75_ASAP7_75t_SL g135 ( 
.A(n_118),
.B(n_127),
.C(n_120),
.D(n_119),
.Y(n_135)
);

HB1xp67_ASAP7_75t_L g136 ( 
.A(n_128),
.Y(n_136)
);

AND2x4_ASAP7_75t_L g137 ( 
.A(n_116),
.B(n_117),
.Y(n_137)
);

AND2x4_ASAP7_75t_L g138 ( 
.A(n_124),
.B(n_13),
.Y(n_138)
);

NOR3xp33_ASAP7_75t_L g139 ( 
.A(n_123),
.B(n_14),
.C(n_13),
.Y(n_139)
);

OR2x2_ASAP7_75t_L g140 ( 
.A(n_126),
.B(n_14),
.Y(n_140)
);

NOR2xp67_ASAP7_75t_L g141 ( 
.A(n_126),
.B(n_15),
.Y(n_141)
);

NOR3xp33_ASAP7_75t_L g142 ( 
.A(n_125),
.B(n_17),
.C(n_16),
.Y(n_142)
);

INVx1_ASAP7_75t_SL g143 ( 
.A(n_124),
.Y(n_143)
);

NOR3xp33_ASAP7_75t_SL g144 ( 
.A(n_122),
.B(n_18),
.C(n_16),
.Y(n_144)
);

OA21x2_ASAP7_75t_L g145 ( 
.A1(n_121),
.A2(n_55),
.B(n_18),
.Y(n_145)
);

AOI322xp5_ASAP7_75t_L g146 ( 
.A1(n_133),
.A2(n_143),
.A3(n_134),
.B1(n_138),
.B2(n_142),
.C1(n_139),
.C2(n_135),
.Y(n_146)
);

O2A1O1Ixp33_ASAP7_75t_L g147 ( 
.A1(n_144),
.A2(n_122),
.B(n_131),
.C(n_121),
.Y(n_147)
);

AOI322xp5_ASAP7_75t_L g148 ( 
.A1(n_138),
.A2(n_53),
.A3(n_20),
.B1(n_19),
.B2(n_49),
.C1(n_54),
.C2(n_61),
.Y(n_148)
);

AOI322xp5_ASAP7_75t_L g149 ( 
.A1(n_138),
.A2(n_53),
.A3(n_20),
.B1(n_19),
.B2(n_49),
.C1(n_54),
.C2(n_61),
.Y(n_149)
);

AND2x2_ASAP7_75t_L g150 ( 
.A(n_137),
.B(n_0),
.Y(n_150)
);

NOR3xp33_ASAP7_75t_L g151 ( 
.A(n_140),
.B(n_51),
.C(n_49),
.Y(n_151)
);

AOI322xp5_ASAP7_75t_L g152 ( 
.A1(n_136),
.A2(n_49),
.A3(n_61),
.B1(n_4),
.B2(n_51),
.C1(n_37),
.C2(n_58),
.Y(n_152)
);

OAI22xp5_ASAP7_75t_SL g153 ( 
.A1(n_132),
.A2(n_49),
.B1(n_51),
.B2(n_37),
.Y(n_153)
);

OAI22x1_ASAP7_75t_L g154 ( 
.A1(n_146),
.A2(n_137),
.B1(n_136),
.B2(n_145),
.Y(n_154)
);

INVx2_ASAP7_75t_SL g155 ( 
.A(n_150),
.Y(n_155)
);

OAI21x1_ASAP7_75t_L g156 ( 
.A1(n_147),
.A2(n_145),
.B(n_141),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_151),
.Y(n_157)
);

OR2x6_ASAP7_75t_L g158 ( 
.A(n_156),
.B(n_153),
.Y(n_158)
);

OAI21x1_ASAP7_75t_L g159 ( 
.A1(n_156),
.A2(n_152),
.B(n_148),
.Y(n_159)
);

NOR2xp33_ASAP7_75t_L g160 ( 
.A(n_155),
.B(n_149),
.Y(n_160)
);

AOI31xp33_ASAP7_75t_L g161 ( 
.A1(n_160),
.A2(n_157),
.A3(n_154),
.B(n_155),
.Y(n_161)
);

OAI22xp5_ASAP7_75t_SL g162 ( 
.A1(n_161),
.A2(n_158),
.B1(n_159),
.B2(n_37),
.Y(n_162)
);


endmodule