module fake_netlist_722_3143_n_16 (n_0, n_2, n_1, n_16);

input n_0;
input n_2;
input n_1;

output n_16;

wire n_12;
wire n_8;
wire n_11;
wire n_3;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_15;
wire n_14;
wire n_6;
wire n_4;
wire n_5;

INVx2_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_2),
.Y(n_7)
);

AOI21xp5_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_2),
.B(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_4),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_9),
.B(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AOI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_0),
.B1(n_3),
.B2(n_5),
.C(n_11),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_5),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_R g16 ( 
.A1(n_15),
.A2(n_3),
.B1(n_14),
.B2(n_5),
.Y(n_16)
);


endmodule