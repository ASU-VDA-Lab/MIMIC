module fake_netlist_722_3087_n_28 (n_12, n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_28);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_28;

wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_25;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

INVx2_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_L g14 ( 
.A(n_1),
.B(n_6),
.C(n_12),
.Y(n_14)
);

OAI22xp33_ASAP7_75t_L g15 ( 
.A1(n_1),
.A2(n_11),
.B1(n_3),
.B2(n_2),
.Y(n_15)
);

INVx2_ASAP7_75t_SL g16 ( 
.A(n_5),
.Y(n_16)
);

AOI21x1_ASAP7_75t_L g17 ( 
.A1(n_0),
.A2(n_5),
.B(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_19),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_13),
.A2(n_8),
.B(n_7),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_18),
.Y(n_23)
);

AOI221x1_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_15),
.B1(n_14),
.B2(n_18),
.C(n_13),
.Y(n_24)
);

OAI211xp5_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_15),
.B(n_21),
.C(n_17),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_4),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_24),
.B(n_9),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_27),
.Y(n_28)
);


endmodule