module fake_netlist_722_2385_n_53 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_5, n_53);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_53;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_17;
wire n_37;
wire n_36;
wire n_29;
wire n_41;
wire n_24;
wire n_43;
wire n_18;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_52;
wire n_25;
wire n_46;
wire n_23;
wire n_21;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_22;
wire n_19;

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_4),
.B(n_10),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

INVx1_ASAP7_75t_SL g19 ( 
.A(n_10),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_R g20 ( 
.A(n_13),
.B(n_14),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_9),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_8),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_3),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_5),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_15),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_21),
.B(n_0),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

OR2x6_ASAP7_75t_L g30 ( 
.A(n_18),
.B(n_0),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_6),
.B(n_1),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_7),
.B1(n_3),
.B2(n_2),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_21),
.B(n_8),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_19),
.A2(n_12),
.B(n_11),
.C(n_9),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_29),
.B(n_23),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_30),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

OR2x6_ASAP7_75t_L g38 ( 
.A(n_30),
.B(n_17),
.Y(n_38)
);

AO31x2_ASAP7_75t_L g39 ( 
.A1(n_32),
.A2(n_22),
.A3(n_17),
.B(n_20),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_R g40 ( 
.A(n_28),
.B(n_25),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_35),
.B(n_30),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_38),
.Y(n_43)
);

OA21x2_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_31),
.B(n_33),
.Y(n_44)
);

OAI22xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_36),
.B1(n_38),
.B2(n_24),
.Y(n_45)
);

NAND4xp75_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_22),
.C(n_34),
.D(n_39),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_26),
.B1(n_20),
.B2(n_40),
.C(n_39),
.Y(n_47)
);

OR2x2_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_39),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_48),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_SL g52 ( 
.A1(n_50),
.A2(n_44),
.B1(n_14),
.B2(n_12),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_47),
.B1(n_38),
.B2(n_51),
.Y(n_53)
);


endmodule