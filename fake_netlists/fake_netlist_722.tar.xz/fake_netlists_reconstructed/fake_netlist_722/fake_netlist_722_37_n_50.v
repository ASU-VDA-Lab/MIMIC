module fake_netlist_722_37_n_50 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_50);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_50;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_27;
wire n_36;
wire n_24;
wire n_29;
wire n_37;
wire n_41;
wire n_43;
wire n_31;
wire n_45;
wire n_28;
wire n_39;
wire n_25;
wire n_46;
wire n_47;
wire n_44;
wire n_42;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_26;

AND2x4_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_5),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_20),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_23),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

CKINVDCx8_ASAP7_75t_R g30 ( 
.A(n_9),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_18),
.B(n_4),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_8),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_28),
.B(n_18),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_24),
.A2(n_19),
.B1(n_1),
.B2(n_0),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_27),
.Y(n_36)
);

INVx3_ASAP7_75t_SL g37 ( 
.A(n_36),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_34),
.B(n_24),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_29),
.B(n_31),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_33),
.B1(n_25),
.B2(n_26),
.Y(n_40)
);

NAND3xp33_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_32),
.C(n_30),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_37),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_39),
.B1(n_19),
.B2(n_2),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_SL g45 ( 
.A(n_43),
.B(n_3),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_45),
.B1(n_11),
.B2(n_6),
.C(n_7),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_13),
.B(n_12),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_22),
.B1(n_21),
.B2(n_14),
.Y(n_50)
);


endmodule