module fake_netlist_722_2412_n_52 (n_3, n_14, n_20, n_0, n_2, n_17, n_13, n_7, n_18, n_11, n_9, n_4, n_12, n_8, n_1, n_10, n_15, n_21, n_16, n_22, n_6, n_19, n_5, n_52);

input n_3;
input n_14;
input n_20;
input n_0;
input n_2;
input n_17;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_12;
input n_8;
input n_1;
input n_10;
input n_15;
input n_21;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_52;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_27;
wire n_24;
wire n_37;
wire n_29;
wire n_36;
wire n_41;
wire n_43;
wire n_31;
wire n_28;
wire n_39;
wire n_45;
wire n_25;
wire n_46;
wire n_23;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_50;
wire n_38;
wire n_49;
wire n_40;
wire n_34;
wire n_51;

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_10),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_5),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_SL g26 ( 
.A(n_17),
.B(n_13),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_4),
.B(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_3),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_6),
.A2(n_22),
.B1(n_3),
.B2(n_18),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_7),
.B(n_9),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_23),
.B(n_11),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_28),
.B1(n_35),
.B2(n_25),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_25),
.B1(n_23),
.B2(n_24),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_30),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AND2x2_ASAP7_75t_SL g41 ( 
.A(n_39),
.B(n_25),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_36),
.Y(n_42)
);

O2A1O1Ixp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_27),
.B(n_26),
.C(n_31),
.Y(n_43)
);

OAI21xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_34),
.B(n_32),
.Y(n_44)
);

AOI322xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_41),
.A3(n_42),
.B1(n_18),
.B2(n_19),
.C1(n_11),
.C2(n_16),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_SL g46 ( 
.A1(n_43),
.A2(n_20),
.B1(n_19),
.B2(n_21),
.C(n_22),
.Y(n_46)
);

O2A1O1Ixp33_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_34),
.B(n_32),
.C(n_0),
.Y(n_47)
);

NAND4xp25_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_34),
.C(n_2),
.D(n_1),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_48),
.B1(n_12),
.B2(n_8),
.Y(n_49)
);

INVx3_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

BUFx3_ASAP7_75t_L g51 ( 
.A(n_50),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_SL g52 ( 
.A1(n_51),
.A2(n_15),
.B1(n_49),
.B2(n_50),
.Y(n_52)
);


endmodule