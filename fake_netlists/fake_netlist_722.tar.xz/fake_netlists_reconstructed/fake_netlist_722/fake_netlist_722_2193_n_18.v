module fake_netlist_722_2193_n_18 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_18);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_18;

wire n_12;
wire n_10;
wire n_15;
wire n_14;
wire n_17;
wire n_13;
wire n_16;
wire n_9;
wire n_11;

OAI21xp33_ASAP7_75t_L g9 ( 
.A1(n_0),
.A2(n_7),
.B(n_1),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_8),
.B(n_2),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_8),
.B(n_2),
.Y(n_11)
);

BUFx4f_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.B(n_6),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_9),
.B2(n_10),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_SL g15 ( 
.A1(n_14),
.A2(n_11),
.B(n_6),
.Y(n_15)
);

NAND4xp25_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_6),
.C(n_1),
.D(n_0),
.Y(n_16)
);

NAND4xp25_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_5),
.C(n_4),
.D(n_3),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_18)
);


endmodule