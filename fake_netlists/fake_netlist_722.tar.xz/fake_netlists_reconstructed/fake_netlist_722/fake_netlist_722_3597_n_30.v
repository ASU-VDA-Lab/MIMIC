module fake_netlist_722_3597_n_30 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_6, n_14, n_0, n_3, n_4, n_5, n_30);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_30;

wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_18;
wire n_28;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

BUFx3_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_5),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

AOI211xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_16),
.B1(n_19),
.B2(n_18),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_17),
.B1(n_7),
.B2(n_6),
.Y(n_28)
);

NOR4xp25_ASAP7_75t_SL g29 ( 
.A(n_28),
.B(n_10),
.C(n_9),
.D(n_8),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_30)
);


endmodule