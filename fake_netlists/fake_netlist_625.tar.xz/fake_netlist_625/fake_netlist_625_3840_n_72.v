module fake_netlist_625_3840_n_72 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_25, n_26, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_72);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_25;
input n_26;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_72;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_59;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_61;
wire n_29;
wire n_34;
wire n_58;
wire n_28;
wire n_62;
wire n_27;
wire n_67;
wire n_52;
wire n_51;
wire n_49;
wire n_48;
wire n_35;
wire n_45;
wire n_65;
wire n_69;
wire n_63;
wire n_60;
wire n_46;
wire n_38;
wire n_47;
wire n_57;
wire n_70;
wire n_43;
wire n_56;
wire n_71;
wire n_66;
wire n_32;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_64;
wire n_68;

INVx6_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_19),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_23),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_4),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_6),
.B(n_17),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_0),
.Y(n_33)
);

INVx3_ASAP7_75t_L g34 ( 
.A(n_11),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_14),
.Y(n_35)
);

OA21x2_ASAP7_75t_L g36 ( 
.A1(n_21),
.A2(n_20),
.B(n_22),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_7),
.Y(n_37)
);

OA21x2_ASAP7_75t_L g38 ( 
.A1(n_25),
.A2(n_15),
.B(n_18),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_16),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_24),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_2),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_35),
.B(n_1),
.Y(n_42)
);

HB1xp67_ASAP7_75t_L g43 ( 
.A(n_33),
.Y(n_43)
);

BUFx6f_ASAP7_75t_L g44 ( 
.A(n_37),
.Y(n_44)
);

BUFx8_ASAP7_75t_L g45 ( 
.A(n_32),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_34),
.B(n_3),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_34),
.B(n_3),
.Y(n_47)
);

OAI21x1_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_34),
.B(n_39),
.Y(n_48)
);

OA21x2_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_31),
.B(n_39),
.Y(n_49)
);

INVxp67_ASAP7_75t_SL g50 ( 
.A(n_42),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_SL g51 ( 
.A1(n_45),
.A2(n_33),
.B1(n_30),
.B2(n_41),
.Y(n_51)
);

INVx2_ASAP7_75t_SL g52 ( 
.A(n_45),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_48),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_43),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_55),
.B(n_52),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_53),
.B(n_49),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_54),
.Y(n_58)
);

AND2x2_ASAP7_75t_SL g59 ( 
.A(n_57),
.B(n_54),
.Y(n_59)
);

INVx2_ASAP7_75t_SL g60 ( 
.A(n_56),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_58),
.B(n_49),
.Y(n_61)
);

AOI221xp5_ASAP7_75t_L g62 ( 
.A1(n_60),
.A2(n_37),
.B1(n_40),
.B2(n_28),
.C(n_29),
.Y(n_62)
);

AOI21xp5_ASAP7_75t_L g63 ( 
.A1(n_59),
.A2(n_36),
.B(n_38),
.Y(n_63)
);

AND2x4_ASAP7_75t_L g64 ( 
.A(n_61),
.B(n_40),
.Y(n_64)
);

XNOR2xp5_ASAP7_75t_L g65 ( 
.A(n_62),
.B(n_5),
.Y(n_65)
);

AOI21xp5_ASAP7_75t_L g66 ( 
.A1(n_63),
.A2(n_36),
.B(n_38),
.Y(n_66)
);

OR2x2_ASAP7_75t_L g67 ( 
.A(n_64),
.B(n_7),
.Y(n_67)
);

AOI211xp5_ASAP7_75t_L g68 ( 
.A1(n_65),
.A2(n_44),
.B(n_27),
.C(n_36),
.Y(n_68)
);

OAI211xp5_ASAP7_75t_SL g69 ( 
.A1(n_67),
.A2(n_44),
.B(n_9),
.C(n_8),
.Y(n_69)
);

AO21x2_ASAP7_75t_L g70 ( 
.A1(n_66),
.A2(n_13),
.B(n_10),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_69),
.Y(n_71)
);

AOI22xp5_ASAP7_75t_SL g72 ( 
.A1(n_71),
.A2(n_68),
.B1(n_69),
.B2(n_70),
.Y(n_72)
);


endmodule