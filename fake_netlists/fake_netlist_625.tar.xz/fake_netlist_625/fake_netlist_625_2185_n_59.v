module fake_netlist_625_2185_n_59 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_59);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_59;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_58;
wire n_27;
wire n_28;
wire n_52;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_49;
wire n_25;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_57;
wire n_43;
wire n_56;
wire n_32;
wire n_42;
wire n_33;
wire n_41;
wire n_55;
wire n_34;

INVx2_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_8),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_2),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_5),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_0),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_24),
.Y(n_31)
);

BUFx6f_ASAP7_75t_L g32 ( 
.A(n_16),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_14),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_4),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_11),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_29),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_26),
.A2(n_24),
.B1(n_23),
.B2(n_1),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_27),
.B(n_23),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_28),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_34),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

OAI21x1_ASAP7_75t_SL g42 ( 
.A1(n_37),
.A2(n_30),
.B(n_25),
.Y(n_42)
);

INVx2_ASAP7_75t_SL g43 ( 
.A(n_41),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_42),
.B1(n_41),
.B2(n_39),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_44),
.Y(n_46)
);

INVxp33_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

OAI21xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_35),
.B(n_42),
.Y(n_48)
);

AOI21xp33_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_48),
.B(n_46),
.Y(n_49)
);

AOI221xp5_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_31),
.B1(n_33),
.B2(n_32),
.C(n_3),
.Y(n_50)
);

CKINVDCx5p33_ASAP7_75t_R g51 ( 
.A(n_48),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_33),
.B1(n_32),
.B2(n_6),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_49),
.Y(n_53)
);

NAND4xp25_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_10),
.C(n_9),
.D(n_7),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_53),
.B(n_12),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_52),
.B1(n_17),
.B2(n_13),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_SL g57 ( 
.A1(n_56),
.A2(n_21),
.B1(n_20),
.B2(n_19),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

OAI21xp33_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_57),
.B(n_22),
.Y(n_59)
);


endmodule