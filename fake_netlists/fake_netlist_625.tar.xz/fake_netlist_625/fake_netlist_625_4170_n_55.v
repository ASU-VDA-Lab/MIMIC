module fake_netlist_625_4170_n_55 (n_11, n_8, n_15, n_3, n_21, n_18, n_22, n_17, n_4, n_1, n_24, n_7, n_25, n_19, n_10, n_20, n_23, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_55);

input n_11;
input n_8;
input n_15;
input n_3;
input n_21;
input n_18;
input n_22;
input n_17;
input n_4;
input n_1;
input n_24;
input n_7;
input n_25;
input n_19;
input n_10;
input n_20;
input n_23;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_55;

wire n_31;
wire n_37;
wire n_39;
wire n_53;
wire n_54;
wire n_40;
wire n_30;
wire n_44;
wire n_50;
wire n_36;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_52;
wire n_49;
wire n_51;
wire n_48;
wire n_35;
wire n_45;
wire n_26;
wire n_38;
wire n_46;
wire n_47;
wire n_43;
wire n_32;
wire n_42;
wire n_33;
wire n_41;

INVx1_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_21),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_1),
.B(n_16),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_10),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_5),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_15),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_9),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_6),
.B(n_23),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_11),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_24),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_25),
.Y(n_36)
);

INVx5_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_26),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_30),
.A2(n_25),
.B1(n_2),
.B2(n_0),
.Y(n_39)
);

BUFx5_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

OAI21x1_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_28),
.B(n_27),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_37),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_37),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_43),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_39),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_34),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_33),
.Y(n_47)
);

CKINVDCx6p67_ASAP7_75t_R g48 ( 
.A(n_46),
.Y(n_48)
);

OAI22xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_33),
.B1(n_31),
.B2(n_29),
.Y(n_49)
);

NOR2xp33_ASAP7_75t_R g50 ( 
.A(n_48),
.B(n_3),
.Y(n_50)
);

OAI222xp33_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_32),
.B1(n_8),
.B2(n_4),
.C1(n_12),
.C2(n_7),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_18),
.B1(n_14),
.B2(n_13),
.Y(n_53)
);

OAI22x1_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_19),
.B1(n_20),
.B2(n_52),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_54),
.Y(n_55)
);


endmodule