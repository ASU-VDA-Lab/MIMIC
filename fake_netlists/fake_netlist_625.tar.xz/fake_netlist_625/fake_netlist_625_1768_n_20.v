module fake_netlist_625_1768_n_20 (n_1, n_2, n_3, n_0, n_20);

input n_1;
input n_2;
input n_3;
input n_0;

output n_20;

wire n_11;
wire n_8;
wire n_15;
wire n_18;
wire n_17;
wire n_4;
wire n_7;
wire n_19;
wire n_10;
wire n_16;
wire n_5;
wire n_14;
wire n_13;
wire n_6;
wire n_12;
wire n_9;

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

AND2x6_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_0),
.Y(n_6)
);

AOI21xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

AOI22x1_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_8)
);

AO22x2_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_2),
.B1(n_1),
.B2(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_6),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_6),
.Y(n_14)
);

NOR3x1_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.C(n_9),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_13),
.A2(n_10),
.B(n_11),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_12),
.B(n_11),
.C(n_9),
.Y(n_17)
);

INVx1_ASAP7_75t_SL g18 ( 
.A(n_15),
.Y(n_18)
);

AOI32xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_2),
.A3(n_3),
.B1(n_9),
.B2(n_4),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);


endmodule