module fake_netlist_625_2626_n_41 (n_11, n_8, n_15, n_3, n_18, n_17, n_4, n_1, n_7, n_10, n_16, n_5, n_14, n_13, n_6, n_0, n_12, n_2, n_9, n_41);

input n_11;
input n_8;
input n_15;
input n_3;
input n_18;
input n_17;
input n_4;
input n_1;
input n_7;
input n_10;
input n_16;
input n_5;
input n_14;
input n_13;
input n_6;
input n_0;
input n_12;
input n_2;
input n_9;

output n_41;

wire n_31;
wire n_37;
wire n_39;
wire n_40;
wire n_21;
wire n_30;
wire n_36;
wire n_22;
wire n_29;
wire n_34;
wire n_27;
wire n_28;
wire n_24;
wire n_35;
wire n_25;
wire n_26;
wire n_19;
wire n_38;
wire n_20;
wire n_32;
wire n_23;
wire n_33;

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_13),
.B(n_14),
.Y(n_20)
);

OA21x2_ASAP7_75t_L g21 ( 
.A1(n_10),
.A2(n_17),
.B(n_2),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_18),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_18),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_16),
.A2(n_6),
.B1(n_17),
.B2(n_9),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_0),
.B(n_15),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_R g28 ( 
.A(n_23),
.B(n_1),
.Y(n_28)
);

O2A1O1Ixp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_20),
.B(n_21),
.C(n_19),
.Y(n_29)
);

OAI22xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_22),
.B1(n_26),
.B2(n_21),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_31),
.Y(n_33)
);

INVx1_ASAP7_75t_SL g34 ( 
.A(n_33),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_30),
.B1(n_24),
.B2(n_19),
.Y(n_36)
);

OAI22xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_19),
.B1(n_28),
.B2(n_29),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_15),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_SL g40 ( 
.A1(n_39),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_SL g41 ( 
.A1(n_40),
.A2(n_38),
.B1(n_12),
.B2(n_7),
.Y(n_41)
);


endmodule