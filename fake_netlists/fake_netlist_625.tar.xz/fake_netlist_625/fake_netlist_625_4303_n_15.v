module fake_netlist_625_4303_n_15 (n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_15);

input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_15;

wire n_7;
wire n_9;
wire n_11;
wire n_8;
wire n_14;
wire n_10;
wire n_13;
wire n_12;

INVx3_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

AOI21x1_ASAP7_75t_L g8 ( 
.A1(n_3),
.A2(n_5),
.B(n_4),
.Y(n_8)
);

AOI221xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_3),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_7),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

OAI211xp5_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_7),
.B(n_8),
.C(n_0),
.Y(n_12)
);

NAND5xp2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_11),
.C(n_5),
.D(n_2),
.E(n_4),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.C(n_6),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_6),
.Y(n_15)
);


endmodule