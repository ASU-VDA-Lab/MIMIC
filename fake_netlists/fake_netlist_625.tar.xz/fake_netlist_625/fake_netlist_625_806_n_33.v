module fake_netlist_625_806_n_33 (n_7, n_9, n_8, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_33);

input n_7;
input n_9;
input n_8;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_33;

wire n_11;
wire n_31;
wire n_15;
wire n_21;
wire n_30;
wire n_18;
wire n_22;
wire n_29;
wire n_27;
wire n_28;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_32;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;

INVx2_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_0),
.B(n_4),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_10),
.B(n_6),
.Y(n_17)
);

OAI22x1_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_7),
.B1(n_6),
.B2(n_2),
.Y(n_18)
);

O2A1O1Ixp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_7),
.B(n_3),
.C(n_2),
.Y(n_19)
);

AO32x2_ASAP7_75t_L g20 ( 
.A1(n_11),
.A2(n_7),
.A3(n_9),
.B1(n_5),
.B2(n_8),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

OR2x2_ASAP7_75t_L g24 ( 
.A(n_17),
.B(n_14),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_14),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_20),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_24),
.Y(n_29)
);

NAND4xp75_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_27),
.C(n_26),
.D(n_20),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_18),
.B1(n_28),
.B2(n_22),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_15),
.B1(n_20),
.B2(n_5),
.Y(n_32)
);

AOI31xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_8),
.A3(n_20),
.B(n_31),
.Y(n_33)
);


endmodule