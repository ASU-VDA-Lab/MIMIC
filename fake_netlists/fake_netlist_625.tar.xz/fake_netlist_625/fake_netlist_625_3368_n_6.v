module fake_netlist_625_3368_n_6 (n_1, n_2, n_3, n_0, n_6);

input n_1;
input n_2;
input n_3;
input n_0;

output n_6;

wire n_5;
wire n_4;

INVx3_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_3),
.Y(n_5)
);

OAI211xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_0),
.B(n_1),
.C(n_5),
.Y(n_6)
);


endmodule