module fake_netlist_625_2751_n_27 (n_7, n_5, n_6, n_0, n_4, n_1, n_2, n_3, n_27);

input n_7;
input n_5;
input n_6;
input n_0;
input n_4;
input n_1;
input n_2;
input n_3;

output n_27;

wire n_11;
wire n_8;
wire n_15;
wire n_21;
wire n_18;
wire n_22;
wire n_17;
wire n_24;
wire n_25;
wire n_26;
wire n_19;
wire n_10;
wire n_20;
wire n_23;
wire n_16;
wire n_14;
wire n_13;
wire n_12;
wire n_9;

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_2),
.B(n_6),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_4),
.A2(n_1),
.B1(n_5),
.B2(n_6),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_1),
.Y(n_13)
);

INVx4_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_4),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_8),
.A2(n_0),
.B1(n_5),
.B2(n_13),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_8),
.B(n_12),
.Y(n_17)
);

NOR2x1_ASAP7_75t_SL g18 ( 
.A(n_17),
.B(n_12),
.Y(n_18)
);

INVx6_ASAP7_75t_L g19 ( 
.A(n_14),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_21),
.Y(n_23)
);

AOI211xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_16),
.B(n_22),
.C(n_10),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);


endmodule