module fake_netlist_894_3755_n_36 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_36);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_36;

wire n_33;
wire n_15;
wire n_11;
wire n_34;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_13;
wire n_21;
wire n_32;
wire n_25;
wire n_14;
wire n_22;
wire n_35;
wire n_26;
wire n_29;

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_4),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_3),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_9),
.B(n_5),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

NOR2x1_ASAP7_75t_SL g20 ( 
.A(n_16),
.B(n_0),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

O2A1O1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_16),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_22)
);

NAND2xp33_ASAP7_75t_R g23 ( 
.A(n_18),
.B(n_12),
.Y(n_23)
);

AOI22xp33_ASAP7_75t_SL g24 ( 
.A1(n_20),
.A2(n_13),
.B1(n_11),
.B2(n_1),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_21),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVx2_ASAP7_75t_SL g27 ( 
.A(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

OAI21xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_24),
.B(n_26),
.Y(n_29)
);

OAI22xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_24),
.B1(n_25),
.B2(n_22),
.Y(n_30)
);

NOR3xp33_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_6),
.C(n_3),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_31),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

OAI22x1_ASAP7_75t_SL g35 ( 
.A1(n_32),
.A2(n_28),
.B1(n_7),
.B2(n_10),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_33),
.B1(n_34),
.B2(n_7),
.Y(n_36)
);


endmodule