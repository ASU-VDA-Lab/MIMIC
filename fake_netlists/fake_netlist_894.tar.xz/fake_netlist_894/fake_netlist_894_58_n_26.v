module fake_netlist_894_58_n_26 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_26);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_26;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_0),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_10),
.Y(n_12)
);

INVx4_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_1),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

BUFx3_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_15),
.B(n_16),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_SL g20 ( 
.A1(n_17),
.A2(n_15),
.B(n_13),
.C(n_12),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_18),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_14),
.C(n_20),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_26)
);


endmodule