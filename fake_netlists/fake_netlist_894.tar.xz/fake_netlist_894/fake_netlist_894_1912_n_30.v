module fake_netlist_894_1912_n_30 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_30);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_30;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_29;

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_2),
.B(n_10),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_7),
.Y(n_17)
);

XOR2xp5_ASAP7_75t_L g18 ( 
.A(n_4),
.B(n_9),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_13),
.A2(n_3),
.B(n_1),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_21),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI322xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_23),
.A3(n_16),
.B1(n_17),
.B2(n_22),
.C1(n_18),
.C2(n_14),
.Y(n_25)
);

NAND4xp25_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_20),
.C(n_6),
.D(n_16),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx6_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

AO21x2_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_28),
.B(n_11),
.Y(n_30)
);


endmodule