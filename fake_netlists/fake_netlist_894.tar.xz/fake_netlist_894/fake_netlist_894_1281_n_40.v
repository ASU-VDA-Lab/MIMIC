module fake_netlist_894_1281_n_40 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_40);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_40;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_35;
wire n_25;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

INVx1_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_10),
.B(n_15),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_3),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

INVx2_ASAP7_75t_SL g26 ( 
.A(n_22),
.Y(n_26)
);

NAND3xp33_ASAP7_75t_SL g27 ( 
.A(n_21),
.B(n_1),
.C(n_0),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_24),
.B1(n_20),
.B2(n_18),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_16),
.B1(n_17),
.B2(n_19),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_27),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_23),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_17),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_SL g35 ( 
.A(n_34),
.B(n_31),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_0),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_1),
.Y(n_37)
);

AOI321xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_35),
.A3(n_5),
.B1(n_2),
.B2(n_14),
.C(n_4),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_R g39 ( 
.A1(n_38),
.A2(n_15),
.B1(n_19),
.B2(n_7),
.Y(n_39)
);

OAI221xp5_ASAP7_75t_R g40 ( 
.A1(n_39),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.C(n_25),
.Y(n_40)
);


endmodule