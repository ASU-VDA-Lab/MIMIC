module fake_netlist_894_226_n_27 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_27);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_27;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_9),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_3),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_12),
.B(n_7),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_10),
.A2(n_7),
.B1(n_1),
.B2(n_0),
.Y(n_16)
);

OAI222xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B1(n_11),
.B2(n_10),
.C1(n_14),
.C2(n_12),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_12),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.B(n_13),
.C(n_11),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_14),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_7),
.Y(n_21)
);

OAI32xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_17),
.A3(n_2),
.B1(n_0),
.B2(n_1),
.Y(n_22)
);

OAI33xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_19),
.A3(n_17),
.B1(n_2),
.B2(n_1),
.B3(n_0),
.Y(n_23)
);

AOI321xp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_3),
.A3(n_2),
.B1(n_4),
.B2(n_6),
.C(n_5),
.Y(n_24)
);

NOR4xp25_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_6),
.C(n_5),
.D(n_3),
.Y(n_25)
);

XNOR2x1_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_8),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_23),
.B1(n_25),
.B2(n_8),
.Y(n_27)
);


endmodule