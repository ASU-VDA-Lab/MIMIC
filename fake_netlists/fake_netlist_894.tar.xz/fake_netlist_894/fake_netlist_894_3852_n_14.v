module fake_netlist_894_3852_n_14 (n_0, n_1, n_3, n_2, n_14);

input n_0;
input n_1;
input n_3;
input n_2;

output n_14;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

NAND3x1_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.C(n_0),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_1),
.Y(n_5)
);

NAND2x1_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

NOR3xp33_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_1),
.C(n_0),
.Y(n_8)
);

NAND3xp33_ASAP7_75t_SL g9 ( 
.A(n_6),
.B(n_1),
.C(n_0),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_0),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B1(n_3),
.B2(n_1),
.C(n_2),
.Y(n_11)
);

OAI221xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B1(n_3),
.B2(n_2),
.Y(n_14)
);


endmodule