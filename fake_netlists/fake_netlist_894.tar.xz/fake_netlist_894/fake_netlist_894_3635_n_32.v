module fake_netlist_894_3635_n_32 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_32);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_32;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;
wire n_29;

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_4),
.B(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_3),
.B(n_6),
.Y(n_13)
);

CKINVDCx16_ASAP7_75t_R g14 ( 
.A(n_8),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_13),
.B(n_3),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_13),
.B1(n_14),
.B2(n_10),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

AND2x4_ASAP7_75t_SL g21 ( 
.A(n_18),
.B(n_15),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_20),
.B(n_5),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_16),
.Y(n_23)
);

NOR2xp67_ASAP7_75t_SL g24 ( 
.A(n_23),
.B(n_21),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_22),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_21),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_25),
.B(n_5),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_24),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_0),
.Y(n_30)
);

INVx1_ASAP7_75t_SL g31 ( 
.A(n_29),
.Y(n_31)
);

AOI322xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_7),
.A3(n_27),
.B1(n_30),
.B2(n_29),
.C1(n_28),
.C2(n_11),
.Y(n_32)
);


endmodule