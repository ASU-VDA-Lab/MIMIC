module fake_netlist_894_3931_n_12 (n_0, n_1, n_2, n_12);

input n_0;
input n_1;
input n_2;

output n_12;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_2),
.Y(n_3)
);

AND2x6_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_1),
.Y(n_4)
);

AOI221xp5_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.C(n_4),
.Y(n_5)
);

OR2x6_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_2),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_4),
.Y(n_7)
);

OAI33xp33_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_0),
.A3(n_1),
.B1(n_2),
.B2(n_3),
.B3(n_4),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_0),
.Y(n_9)
);

AOI221xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.B1(n_7),
.B2(n_2),
.C(n_0),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

AOI222xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C1(n_9),
.C2(n_10),
.Y(n_12)
);


endmodule