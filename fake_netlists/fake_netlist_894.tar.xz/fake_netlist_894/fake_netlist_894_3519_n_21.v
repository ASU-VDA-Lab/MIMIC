module fake_netlist_894_3519_n_21 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_21);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_21;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_14;

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NAND2xp33_ASAP7_75t_R g12 ( 
.A(n_5),
.B(n_9),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

AO21x2_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_2),
.B(n_0),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NOR4xp25_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.C(n_13),
.D(n_12),
.Y(n_19)
);

AOI21xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_12),
.B(n_6),
.Y(n_20)
);

OAI221xp5_ASAP7_75t_R g21 ( 
.A1(n_20),
.A2(n_7),
.B1(n_6),
.B2(n_3),
.C(n_8),
.Y(n_21)
);


endmodule