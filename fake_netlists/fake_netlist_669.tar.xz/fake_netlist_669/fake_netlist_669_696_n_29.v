module fake_netlist_669_696_n_29 (n_9, n_4, n_7, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_29);

input n_9;
input n_4;
input n_7;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_29;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_26;

NOR2xp33_ASAP7_75t_L g14 ( 
.A(n_5),
.B(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_4),
.B(n_10),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_SL g21 ( 
.A(n_16),
.B(n_1),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_15),
.B1(n_14),
.B2(n_17),
.Y(n_22)
);

OAI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_14),
.B2(n_18),
.C(n_5),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_6),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_24),
.Y(n_25)
);

OAI221xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_7),
.B1(n_9),
.B2(n_2),
.C(n_3),
.Y(n_26)
);

NAND2x1_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

NOR2x1_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_7),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_29)
);


endmodule