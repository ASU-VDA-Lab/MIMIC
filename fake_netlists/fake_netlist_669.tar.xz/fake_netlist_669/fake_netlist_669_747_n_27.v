module fake_netlist_669_747_n_27 (n_4, n_1, n_2, n_0, n_5, n_3, n_27);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_27;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_26;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

BUFx4f_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx5_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_0),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_5),
.Y(n_9)
);

BUFx12f_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_SL g12 ( 
.A1(n_9),
.A2(n_4),
.B(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AO21x2_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_8),
.B(n_6),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_10),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_14),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_10),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_6),
.B1(n_9),
.B2(n_7),
.C1(n_10),
.C2(n_11),
.Y(n_19)
);

AOI222xp33_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_6),
.B1(n_7),
.B2(n_11),
.C1(n_4),
.C2(n_1),
.Y(n_20)
);

OAI32xp33_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_13),
.A3(n_15),
.B1(n_7),
.B2(n_11),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_15),
.B(n_13),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_19),
.C(n_1),
.Y(n_23)
);

NAND4xp75_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_4),
.C(n_3),
.D(n_2),
.Y(n_24)
);

AOI22x1_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_11),
.B1(n_5),
.B2(n_2),
.Y(n_25)
);

AOI21xp33_ASAP7_75t_SL g26 ( 
.A1(n_23),
.A2(n_11),
.B(n_24),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);


endmodule