module fake_netlist_669_519_n_31 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_31);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_31;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_29;
wire n_26;

AO21x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B(n_6),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_3),
.Y(n_17)
);

CKINVDCx16_ASAP7_75t_R g18 ( 
.A(n_13),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_1),
.B(n_11),
.Y(n_21)
);

BUFx2_ASAP7_75t_SL g22 ( 
.A(n_19),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_L g23 ( 
.A1(n_18),
.A2(n_7),
.B1(n_2),
.B2(n_0),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AOI21xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B(n_17),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_20),
.B1(n_21),
.B2(n_16),
.C(n_7),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OR3x1_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_16),
.C(n_4),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_12),
.B1(n_10),
.B2(n_5),
.Y(n_31)
);


endmodule