module fake_netlist_669_411_n_56 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_56);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_56;

wire n_36;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_17),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_11),
.B(n_2),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_SL g25 ( 
.A(n_19),
.B(n_15),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_13),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_14),
.B(n_3),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_8),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_15),
.Y(n_30)
);

CKINVDCx20_ASAP7_75t_R g31 ( 
.A(n_30),
.Y(n_31)
);

CKINVDCx14_ASAP7_75t_R g32 ( 
.A(n_26),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

INVx3_ASAP7_75t_L g35 ( 
.A(n_23),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_29),
.B1(n_28),
.B2(n_20),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_31),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_32),
.Y(n_39)
);

BUFx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

NAND3xp33_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_32),
.C(n_25),
.Y(n_41)
);

INVx2_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

AND2x4_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_35),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_35),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OAI21xp33_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_37),
.B(n_27),
.Y(n_46)
);

AOI221xp5_ASAP7_75t_L g47 ( 
.A1(n_43),
.A2(n_44),
.B1(n_42),
.B2(n_34),
.C(n_22),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_24),
.B(n_27),
.Y(n_48)
);

NOR3xp33_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_18),
.C(n_17),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_18),
.B1(n_4),
.B2(n_0),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_7),
.B(n_6),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_49),
.Y(n_52)
);

NOR2x1p5_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_10),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_SL g54 ( 
.A(n_51),
.B(n_48),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_L g56 ( 
.A1(n_55),
.A2(n_53),
.B1(n_54),
.B2(n_12),
.Y(n_56)
);


endmodule