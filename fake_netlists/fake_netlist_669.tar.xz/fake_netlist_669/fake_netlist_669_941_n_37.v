module fake_netlist_669_941_n_37 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_37);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_37;

wire n_36;
wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

INVx3_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_7),
.A2(n_12),
.B1(n_16),
.B2(n_17),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_4),
.A2(n_6),
.B1(n_13),
.B2(n_11),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_1),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_3),
.B(n_0),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_8),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_19),
.Y(n_28)
);

OAI21xp5_ASAP7_75t_L g29 ( 
.A1(n_23),
.A2(n_5),
.B(n_2),
.Y(n_29)
);

NAND2xp33_ASAP7_75t_R g30 ( 
.A(n_28),
.B(n_29),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_29),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_22),
.Y(n_33)
);

NAND3xp33_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_30),
.C(n_21),
.Y(n_34)
);

CKINVDCx16_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_24),
.B1(n_26),
.B2(n_19),
.Y(n_36)
);

OAI221xp5_ASAP7_75t_R g37 ( 
.A1(n_36),
.A2(n_25),
.B1(n_15),
.B2(n_9),
.C(n_14),
.Y(n_37)
);


endmodule