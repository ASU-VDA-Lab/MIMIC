module fake_netlist_669_1276_n_43 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_43);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_43;

wire n_36;
wire n_34;
wire n_38;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_12),
.B(n_21),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_20),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_15),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_8),
.Y(n_26)
);

CKINVDCx16_ASAP7_75t_R g27 ( 
.A(n_18),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_4),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_5),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_27),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_1),
.B(n_0),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_24),
.B(n_25),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_30),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_R g34 ( 
.A(n_32),
.B(n_26),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_34),
.Y(n_35)
);

OAI21xp5_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_31),
.B(n_28),
.Y(n_36)
);

OAI32xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_22),
.A3(n_7),
.B1(n_3),
.B2(n_6),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_36),
.B(n_9),
.Y(n_38)
);

CKINVDCx16_ASAP7_75t_R g39 ( 
.A(n_38),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

OAI22x1_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_13),
.B1(n_11),
.B2(n_10),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

AOI222xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_41),
.B1(n_17),
.B2(n_14),
.C1(n_19),
.C2(n_16),
.Y(n_43)
);


endmodule