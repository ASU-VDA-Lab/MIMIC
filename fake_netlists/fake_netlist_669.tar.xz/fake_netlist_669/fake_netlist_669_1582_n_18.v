module fake_netlist_669_1582_n_18 (n_3, n_1, n_2, n_0, n_18);

input n_3;
input n_1;
input n_2;
input n_0;

output n_18;

wire n_9;
wire n_4;
wire n_7;
wire n_17;
wire n_14;
wire n_15;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_16;
wire n_6;

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

INVx2_ASAP7_75t_SL g5 ( 
.A(n_3),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

AO21x2_ASAP7_75t_L g9 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_6),
.C(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

AOI31xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_5),
.A3(n_9),
.B(n_8),
.Y(n_13)
);

NAND2x1_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_8),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_11),
.B1(n_9),
.B2(n_3),
.C(n_1),
.Y(n_15)
);

AOI322xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_1),
.A3(n_2),
.B1(n_3),
.B2(n_9),
.C1(n_10),
.C2(n_4),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_2),
.B1(n_9),
.B2(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);


endmodule