module fake_netlist_669_2001_n_25 (n_4, n_1, n_2, n_0, n_5, n_3, n_25);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_25;

wire n_18;
wire n_19;
wire n_10;
wire n_24;
wire n_11;
wire n_15;
wire n_7;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_SL g7 ( 
.A(n_0),
.Y(n_7)
);

BUFx3_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_3),
.Y(n_9)
);

NOR2xp67_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_1),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_1),
.B(n_2),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_9),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_14),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_7),
.B(n_12),
.C(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_12),
.Y(n_19)
);

OAI221xp5_ASAP7_75t_SL g20 ( 
.A1(n_17),
.A2(n_13),
.B1(n_10),
.B2(n_12),
.C(n_11),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_11),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_11),
.B(n_2),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

AOI222xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_24),
.B1(n_5),
.B2(n_3),
.C1(n_4),
.C2(n_22),
.Y(n_25)
);


endmodule