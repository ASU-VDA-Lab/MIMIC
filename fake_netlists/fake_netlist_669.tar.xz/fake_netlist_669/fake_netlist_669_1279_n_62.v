module fake_netlist_669_1279_n_62 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_62);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_62;

wire n_36;
wire n_59;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_60;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;
wire n_61;

INVx1_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_7),
.B1(n_15),
.B2(n_8),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_11),
.A2(n_5),
.B1(n_9),
.B2(n_13),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_16),
.B(n_0),
.Y(n_24)
);

INVx6_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_4),
.B(n_2),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_3),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_16),
.B1(n_2),
.B2(n_1),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

BUFx3_ASAP7_75t_L g32 ( 
.A(n_27),
.Y(n_32)
);

NOR2x1_ASAP7_75t_R g33 ( 
.A(n_25),
.B(n_17),
.Y(n_33)
);

A2O1A1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_20),
.A2(n_29),
.B(n_28),
.C(n_22),
.Y(n_34)
);

INVx4_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_31),
.Y(n_36)
);

NOR2xp67_ASAP7_75t_L g37 ( 
.A(n_30),
.B(n_21),
.Y(n_37)
);

OAI22xp33_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_24),
.B1(n_27),
.B2(n_26),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_34),
.Y(n_40)
);

BUFx3_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_37),
.Y(n_44)
);

INVxp67_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_40),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_40),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_42),
.B(n_34),
.Y(n_48)
);

AOI211xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_33),
.B(n_38),
.C(n_23),
.Y(n_49)
);

AOI211xp5_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_38),
.B(n_24),
.C(n_43),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_45),
.A2(n_43),
.B1(n_41),
.B2(n_39),
.Y(n_51)
);

O2A1O1Ixp33_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_39),
.B(n_41),
.C(n_18),
.Y(n_52)
);

AOI21xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_41),
.B(n_6),
.Y(n_53)
);

INVx3_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

INVx1_ASAP7_75t_SL g55 ( 
.A(n_49),
.Y(n_55)
);

NAND3xp33_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_19),
.C(n_10),
.Y(n_56)
);

INVxp67_ASAP7_75t_L g57 ( 
.A(n_55),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_54),
.B(n_14),
.Y(n_58)
);

INVxp67_ASAP7_75t_SL g59 ( 
.A(n_54),
.Y(n_59)
);

CKINVDCx20_ASAP7_75t_R g60 ( 
.A(n_57),
.Y(n_60)
);

NOR2x1_ASAP7_75t_L g61 ( 
.A(n_58),
.B(n_56),
.Y(n_61)
);

AOI22xp33_ASAP7_75t_SL g62 ( 
.A1(n_60),
.A2(n_53),
.B1(n_59),
.B2(n_61),
.Y(n_62)
);


endmodule