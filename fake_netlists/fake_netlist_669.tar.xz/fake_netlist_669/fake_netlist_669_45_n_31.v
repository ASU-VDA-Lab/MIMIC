module fake_netlist_669_45_n_31 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_31);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_31;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_21;
wire n_27;
wire n_29;
wire n_26;

INVxp67_ASAP7_75t_SL g15 ( 
.A(n_9),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_7),
.B(n_14),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_0),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_20),
.B(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_18),
.Y(n_23)
);

CKINVDCx11_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_15),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_16),
.Y(n_27)
);

AOI211x1_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_22),
.B(n_19),
.C(n_24),
.Y(n_28)
);

NAND4xp75_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_8),
.C(n_6),
.D(n_4),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_13),
.B1(n_12),
.B2(n_10),
.Y(n_31)
);


endmodule