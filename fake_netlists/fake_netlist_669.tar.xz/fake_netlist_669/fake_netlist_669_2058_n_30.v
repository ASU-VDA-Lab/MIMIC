module fake_netlist_669_2058_n_30 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_15, n_6, n_3, n_30);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_15;
input n_6;
input n_3;

output n_30;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_21;
wire n_27;
wire n_29;
wire n_26;

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_5),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_6),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_6),
.B(n_3),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_16),
.B(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

O2A1O1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_17),
.B(n_20),
.C(n_18),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_17),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_23),
.B1(n_20),
.B2(n_19),
.Y(n_26)
);

AOI221xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_21),
.B1(n_5),
.B2(n_1),
.C(n_4),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_7),
.C(n_4),
.Y(n_28)
);

OAI22x1_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_7),
.B1(n_2),
.B2(n_0),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_10),
.B1(n_8),
.B2(n_11),
.C1(n_15),
.C2(n_13),
.Y(n_30)
);


endmodule