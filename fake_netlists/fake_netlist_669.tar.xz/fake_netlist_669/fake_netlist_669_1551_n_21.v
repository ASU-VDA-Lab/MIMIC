module fake_netlist_669_1551_n_21 (n_4, n_1, n_2, n_0, n_3, n_21);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_15;
wire n_11;
wire n_7;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

AND2x2_ASAP7_75t_L g5 ( 
.A(n_2),
.B(n_1),
.Y(n_5)
);

INVx2_ASAP7_75t_SL g6 ( 
.A(n_2),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

OR2x6_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_4),
.Y(n_8)
);

OAI21x1_ASAP7_75t_L g9 ( 
.A1(n_5),
.A2(n_6),
.B(n_7),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_10)
);

A2O1A1Ixp33_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_4),
.B(n_2),
.C(n_0),
.Y(n_11)
);

AOI221xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_5),
.B1(n_6),
.B2(n_7),
.C(n_8),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_8),
.Y(n_14)
);

INVx2_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_8),
.B1(n_10),
.B2(n_7),
.Y(n_16)
);

AOI21xp5_ASAP7_75t_R g17 ( 
.A1(n_13),
.A2(n_8),
.B(n_10),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_8),
.C(n_0),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_7),
.B(n_8),
.C(n_4),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.B1(n_7),
.B2(n_3),
.Y(n_20)
);

AOI221x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_7),
.B1(n_18),
.B2(n_11),
.C(n_17),
.Y(n_21)
);


endmodule