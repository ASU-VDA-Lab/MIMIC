module fake_netlist_669_1_n_14 (n_4, n_1, n_2, n_0, n_3, n_14);

input n_4;
input n_1;
input n_2;
input n_0;
input n_3;

output n_14;

wire n_7;
wire n_13;
wire n_10;
wire n_12;
wire n_5;
wire n_11;
wire n_8;
wire n_6;
wire n_9;

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

OR2x2_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_0),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);

NOR3xp33_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_4),
.C(n_3),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_5),
.Y(n_13)
);

OA21x2_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_8),
.B(n_7),
.Y(n_14)
);


endmodule