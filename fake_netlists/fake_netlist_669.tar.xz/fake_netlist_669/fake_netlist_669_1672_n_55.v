module fake_netlist_669_1672_n_55 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_55);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_55;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_23;
wire n_48;
wire n_22;
wire n_39;
wire n_17;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_14),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_7),
.B(n_5),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_9),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_6),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_2),
.B(n_11),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_0),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_8),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_24),
.B(n_18),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_21),
.B(n_0),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_23),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_31),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_26),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_28),
.A2(n_22),
.B1(n_25),
.B2(n_27),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_30),
.B(n_22),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_30),
.B(n_25),
.Y(n_39)
);

OAI21xp33_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_33),
.B(n_29),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_34),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_32),
.B1(n_29),
.B2(n_34),
.Y(n_42)
);

HB1xp67_ASAP7_75t_L g43 ( 
.A(n_35),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_39),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_36),
.Y(n_46)
);

OAI21xp5_ASAP7_75t_L g47 ( 
.A1(n_44),
.A2(n_46),
.B(n_40),
.Y(n_47)
);

NOR4xp25_ASAP7_75t_SL g48 ( 
.A(n_45),
.B(n_40),
.C(n_35),
.D(n_37),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_1),
.Y(n_49)
);

OR2x2_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_13),
.Y(n_50)
);

A2O1A1Ixp33_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_19),
.B(n_15),
.C(n_3),
.Y(n_51)
);

AOI21xp5_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_48),
.B(n_4),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_15),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_53),
.Y(n_54)
);

AOI322xp5_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_10),
.A3(n_12),
.B1(n_52),
.B2(n_53),
.C1(n_22),
.C2(n_20),
.Y(n_55)
);


endmodule