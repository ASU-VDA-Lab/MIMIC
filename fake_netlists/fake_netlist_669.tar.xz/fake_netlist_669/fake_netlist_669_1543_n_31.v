module fake_netlist_669_1543_n_31 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_31);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_31;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_29;
wire n_26;

OR2x2_ASAP7_75t_L g17 ( 
.A(n_3),
.B(n_14),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

OA21x2_ASAP7_75t_L g20 ( 
.A1(n_5),
.A2(n_10),
.B(n_7),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

O2A1O1Ixp33_ASAP7_75t_SL g23 ( 
.A1(n_17),
.A2(n_16),
.B(n_1),
.C(n_0),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_18),
.B(n_16),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_22),
.Y(n_26)
);

AOI21xp33_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_20),
.B(n_19),
.Y(n_27)
);

NAND4xp25_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_23),
.C(n_21),
.D(n_4),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_6),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_15),
.B1(n_11),
.B2(n_8),
.Y(n_31)
);


endmodule