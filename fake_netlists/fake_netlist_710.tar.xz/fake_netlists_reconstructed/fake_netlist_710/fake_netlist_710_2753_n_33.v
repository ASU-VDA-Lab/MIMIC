module fake_netlist_710_2753_n_33 (n_9, n_4, n_2, n_7, n_14, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_33);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_33;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_14),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_10),
.B(n_4),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_3),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_15),
.B(n_1),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_17),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

OAI21xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_22),
.B(n_16),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_24),
.A2(n_17),
.B(n_19),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_20),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_27),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_13),
.B1(n_7),
.B2(n_2),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI222xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_13),
.B1(n_11),
.B2(n_8),
.C1(n_12),
.C2(n_9),
.Y(n_33)
);


endmodule