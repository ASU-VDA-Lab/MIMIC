module fake_netlist_710_18_n_27 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_12;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

NOR2xp33_ASAP7_75t_R g10 ( 
.A(n_7),
.B(n_8),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_2),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_4),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

NOR2xp67_ASAP7_75t_L g15 ( 
.A(n_5),
.B(n_9),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_3),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_13),
.B(n_11),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_SL g18 ( 
.A1(n_12),
.A2(n_6),
.B1(n_4),
.B2(n_3),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_18),
.B1(n_16),
.B2(n_14),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_11),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_21),
.B(n_10),
.C(n_15),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_22),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B1(n_1),
.B2(n_0),
.Y(n_27)
);


endmodule