module fake_netlist_710_2521_n_12 (n_3, n_0, n_2, n_1, n_12);

input n_3;
input n_0;
input n_2;
input n_1;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

INVx2_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

NAND3xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.C(n_2),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_7),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_9),
.Y(n_10)
);

OA22x2_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B1(n_1),
.B2(n_5),
.Y(n_11)
);

OR2x6_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_2),
.Y(n_12)
);


endmodule