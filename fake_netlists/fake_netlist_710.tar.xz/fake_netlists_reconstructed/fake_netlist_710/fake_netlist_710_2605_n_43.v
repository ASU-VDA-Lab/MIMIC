module fake_netlist_710_2605_n_43 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_43);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_43;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;

INVx1_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

OR2x6_ASAP7_75t_L g20 ( 
.A(n_9),
.B(n_6),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_13),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_4),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_R g25 ( 
.A(n_18),
.B(n_0),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_1),
.A2(n_15),
.B1(n_18),
.B2(n_12),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_2),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_L g29 ( 
.A(n_21),
.B(n_2),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_28),
.A2(n_26),
.B1(n_22),
.B2(n_25),
.Y(n_30)
);

OR2x2_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_3),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI221xp5_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_29),
.B1(n_28),
.B2(n_23),
.C(n_25),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_29),
.Y(n_34)
);

OAI31xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_23),
.A3(n_20),
.B(n_3),
.Y(n_35)
);

OAI211xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_20),
.B(n_10),
.C(n_5),
.Y(n_36)
);

AOI21xp33_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_20),
.B(n_5),
.Y(n_37)
);

INVxp67_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

NAND4xp75_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_16),
.C(n_11),
.D(n_10),
.Y(n_40)
);

AOI211xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_34),
.B(n_17),
.C(n_11),
.Y(n_41)
);

AND2x4_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_39),
.Y(n_42)
);

AOI322xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_7),
.A3(n_8),
.B1(n_17),
.B2(n_41),
.C1(n_38),
.C2(n_30),
.Y(n_43)
);


endmodule