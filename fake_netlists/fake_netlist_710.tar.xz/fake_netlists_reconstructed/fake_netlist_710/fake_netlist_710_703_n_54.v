module fake_netlist_710_703_n_54 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_54);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_54;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_6),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_1),
.B(n_9),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_16),
.B(n_22),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_11),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_3),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_17),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_8),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_4),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_7),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_13),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_30),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_24),
.A2(n_23),
.B1(n_2),
.B2(n_0),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_29),
.B(n_23),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

OAI21x1_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_26),
.B(n_31),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_36),
.B(n_34),
.Y(n_42)
);

AOI221xp5_ASAP7_75t_L g43 ( 
.A1(n_40),
.A2(n_37),
.B1(n_28),
.B2(n_32),
.C(n_25),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_33),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_44),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_41),
.Y(n_46)
);

OA22x2_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_12),
.B1(n_10),
.B2(n_5),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_33),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_48),
.B(n_35),
.Y(n_49)
);

NOR2x1_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_35),
.Y(n_50)
);

AOI211xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_19),
.B(n_18),
.C(n_15),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_50),
.Y(n_52)
);

BUFx2_ASAP7_75t_L g53 ( 
.A(n_52),
.Y(n_53)
);

NAND3xp33_ASAP7_75t_L g54 ( 
.A(n_53),
.B(n_51),
.C(n_20),
.Y(n_54)
);


endmodule