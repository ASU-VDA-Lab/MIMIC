module fake_netlist_710_2569_n_37 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_37);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_37;

wire n_24;
wire n_21;
wire n_27;
wire n_22;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_19;
wire n_25;

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_8),
.B(n_3),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_15),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_16),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_9),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_4),
.B(n_13),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_22),
.B(n_12),
.Y(n_28)
);

CKINVDCx11_ASAP7_75t_R g29 ( 
.A(n_27),
.Y(n_29)
);

OAI33xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_28),
.A3(n_25),
.B1(n_24),
.B2(n_20),
.B3(n_23),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_21),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_31),
.B(n_23),
.C(n_19),
.Y(n_32)
);

OAI21xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B(n_26),
.Y(n_33)
);

NAND2x1_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_22),
.Y(n_34)
);

OAI222xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_14),
.B1(n_5),
.B2(n_1),
.C1(n_6),
.C2(n_2),
.Y(n_35)
);

OR3x1_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_33),
.C(n_7),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_27),
.B1(n_17),
.B2(n_11),
.Y(n_37)
);


endmodule