module fake_netlist_710_1618_n_83 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_83);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_83;

wire n_61;
wire n_40;
wire n_66;
wire n_47;
wire n_35;
wire n_52;
wire n_71;
wire n_60;
wire n_33;
wire n_30;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_45;
wire n_64;
wire n_58;
wire n_62;
wire n_76;
wire n_63;
wire n_70;
wire n_69;
wire n_53;
wire n_74;
wire n_28;
wire n_75;
wire n_81;
wire n_55;
wire n_54;
wire n_78;
wire n_44;
wire n_38;
wire n_42;
wire n_34;
wire n_43;
wire n_37;
wire n_51;
wire n_68;
wire n_32;
wire n_77;
wire n_82;
wire n_79;
wire n_46;
wire n_31;
wire n_73;
wire n_41;
wire n_29;
wire n_56;
wire n_72;
wire n_65;
wire n_80;
wire n_36;
wire n_57;
wire n_49;

AND2x4_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_11),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_9),
.B(n_7),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_17),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_2),
.A2(n_5),
.B1(n_15),
.B2(n_13),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_4),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

INVx4_ASAP7_75t_L g35 ( 
.A(n_14),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_8),
.Y(n_36)
);

OA21x2_ASAP7_75t_L g37 ( 
.A1(n_12),
.A2(n_1),
.B(n_24),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_16),
.B(n_22),
.Y(n_38)
);

BUFx6f_ASAP7_75t_L g39 ( 
.A(n_25),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_10),
.B(n_0),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_3),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_34),
.A2(n_27),
.B1(n_26),
.B2(n_6),
.Y(n_42)
);

INVx3_ASAP7_75t_L g43 ( 
.A(n_30),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_41),
.B(n_26),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_36),
.Y(n_45)
);

AND2x4_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_27),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_31),
.B(n_18),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_SL g48 ( 
.A1(n_46),
.A2(n_29),
.B(n_28),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_43),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_45),
.B(n_35),
.Y(n_51)
);

OA21x2_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_47),
.B(n_45),
.Y(n_52)
);

AOI221xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_44),
.B1(n_46),
.B2(n_42),
.C(n_39),
.Y(n_53)
);

AO21x2_ASAP7_75t_L g54 ( 
.A1(n_48),
.A2(n_40),
.B(n_28),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_52),
.B(n_39),
.Y(n_55)
);

HB1xp67_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_54),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_39),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_30),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_56),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

INVx2_ASAP7_75t_L g62 ( 
.A(n_55),
.Y(n_62)
);

OAI21xp33_ASAP7_75t_L g63 ( 
.A1(n_59),
.A2(n_57),
.B(n_29),
.Y(n_63)
);

NAND2xp5_ASAP7_75t_L g64 ( 
.A(n_60),
.B(n_30),
.Y(n_64)
);

AOI21xp33_ASAP7_75t_SL g65 ( 
.A1(n_61),
.A2(n_32),
.B(n_37),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_62),
.B(n_30),
.Y(n_66)
);

NAND2xp5_ASAP7_75t_L g67 ( 
.A(n_62),
.B(n_35),
.Y(n_67)
);

NOR3xp33_ASAP7_75t_L g68 ( 
.A(n_65),
.B(n_38),
.C(n_43),
.Y(n_68)
);

NOR2xp33_ASAP7_75t_L g69 ( 
.A(n_67),
.B(n_40),
.Y(n_69)
);

NOR3xp33_ASAP7_75t_L g70 ( 
.A(n_64),
.B(n_38),
.C(n_43),
.Y(n_70)
);

INVxp67_ASAP7_75t_SL g71 ( 
.A(n_66),
.Y(n_71)
);

NOR3xp33_ASAP7_75t_SL g72 ( 
.A(n_63),
.B(n_37),
.C(n_31),
.Y(n_72)
);

NOR3xp33_ASAP7_75t_L g73 ( 
.A(n_65),
.B(n_33),
.C(n_49),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_71),
.Y(n_74)
);

AND2x2_ASAP7_75t_L g75 ( 
.A(n_68),
.B(n_33),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_70),
.Y(n_76)
);

BUFx2_ASAP7_75t_L g77 ( 
.A(n_72),
.Y(n_77)
);

NOR4xp25_ASAP7_75t_L g78 ( 
.A(n_69),
.B(n_49),
.C(n_21),
.D(n_19),
.Y(n_78)
);

NAND2xp5_ASAP7_75t_L g79 ( 
.A(n_74),
.B(n_73),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_76),
.Y(n_80)
);

OR3x1_ASAP7_75t_L g81 ( 
.A(n_77),
.B(n_23),
.C(n_78),
.Y(n_81)
);

NAND3xp33_ASAP7_75t_L g82 ( 
.A(n_80),
.B(n_75),
.C(n_79),
.Y(n_82)
);

OA21x2_ASAP7_75t_L g83 ( 
.A1(n_82),
.A2(n_75),
.B(n_81),
.Y(n_83)
);


endmodule