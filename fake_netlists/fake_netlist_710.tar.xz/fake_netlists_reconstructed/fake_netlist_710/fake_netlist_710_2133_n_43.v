module fake_netlist_710_2133_n_43 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_43);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_43;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_19;
wire n_30;
wire n_25;
wire n_39;
wire n_14;

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_0),
.B(n_4),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_L g15 ( 
.A(n_2),
.B(n_12),
.Y(n_15)
);

INVx6_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_20),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_21),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_16),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_5),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_28),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_14),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

NAND4xp75_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_19),
.C(n_18),
.D(n_15),
.Y(n_35)
);

NOR2x1p5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_20),
.Y(n_36)
);

AND3x4_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_7),
.C(n_6),
.Y(n_37)
);

OA22x2_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_7),
.B1(n_6),
.B2(n_3),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_20),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

AOI222xp33_ASAP7_75t_SL g41 ( 
.A1(n_38),
.A2(n_25),
.B1(n_22),
.B2(n_26),
.C1(n_11),
.C2(n_8),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

AOI21xp33_ASAP7_75t_SL g43 ( 
.A1(n_42),
.A2(n_39),
.B(n_41),
.Y(n_43)
);


endmodule