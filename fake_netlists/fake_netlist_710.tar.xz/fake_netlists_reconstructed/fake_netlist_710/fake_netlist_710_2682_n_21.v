module fake_netlist_710_2682_n_21 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_21);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_21;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_8;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_R g9 ( 
.A(n_7),
.B(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

CKINVDCx16_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_8),
.B1(n_10),
.B2(n_0),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI221x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_14),
.B2(n_0),
.C(n_1),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OR2x2_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_4),
.B(n_2),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_5),
.B1(n_6),
.B2(n_20),
.Y(n_21)
);


endmodule