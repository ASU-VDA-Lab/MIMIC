module fake_netlist_710_1511_n_12 (n_4, n_2, n_3, n_1, n_0, n_12);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_12;

wire n_9;
wire n_7;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

NOR2xp67_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_3),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_0),
.Y(n_6)
);

NOR3xp33_ASAP7_75t_SL g7 ( 
.A(n_4),
.B(n_2),
.C(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_1),
.Y(n_10)
);

NOR4xp75_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_5),
.C(n_6),
.D(n_9),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule