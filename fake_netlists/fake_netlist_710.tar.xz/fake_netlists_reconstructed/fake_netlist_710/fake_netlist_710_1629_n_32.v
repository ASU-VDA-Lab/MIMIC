module fake_netlist_710_1629_n_32 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_32);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_32;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_12;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

AND2x2_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_11),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_4),
.B(n_9),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

AND2x4_ASAP7_75t_L g19 ( 
.A(n_13),
.B(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_15),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_0),
.Y(n_21)
);

NOR2x1p5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_13),
.Y(n_22)
);

OAI21x1_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_16),
.B(n_17),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_19),
.B(n_17),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_12),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_26),
.B(n_10),
.Y(n_27)
);

NAND3xp33_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_18),
.C(n_3),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_18),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_7),
.B1(n_30),
.B2(n_29),
.Y(n_32)
);


endmodule