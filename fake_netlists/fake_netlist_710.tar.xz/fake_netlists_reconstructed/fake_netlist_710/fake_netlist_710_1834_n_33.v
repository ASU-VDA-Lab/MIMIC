module fake_netlist_710_1834_n_33 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_33);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_33;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_3),
.Y(n_14)
);

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_11),
.B(n_0),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_9),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_18),
.B1(n_19),
.B2(n_14),
.C(n_16),
.Y(n_20)
);

INVx5_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

INVx4_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_20),
.Y(n_23)
);

AND2x4_ASAP7_75t_SL g24 ( 
.A(n_22),
.B(n_16),
.Y(n_24)
);

INVxp67_ASAP7_75t_SL g25 ( 
.A(n_22),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_24),
.Y(n_28)
);

OAI31xp33_ASAP7_75t_SL g29 ( 
.A1(n_27),
.A2(n_7),
.A3(n_17),
.B(n_1),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

OAI221xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_7),
.B1(n_10),
.B2(n_4),
.C(n_8),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_13),
.B2(n_12),
.Y(n_33)
);


endmodule