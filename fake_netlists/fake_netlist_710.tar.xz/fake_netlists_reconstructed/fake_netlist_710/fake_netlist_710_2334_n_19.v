module fake_netlist_710_2334_n_19 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_19);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_19;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_8;
wire n_11;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_6),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_0),
.Y(n_12)
);

AO21x1_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_9),
.B(n_8),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_SL g15 ( 
.A(n_14),
.Y(n_15)
);

AOI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B1(n_13),
.B2(n_10),
.C(n_0),
.Y(n_16)
);

AOI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_17)
);

OAI31xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_5),
.A3(n_4),
.B(n_1),
.Y(n_18)
);

AOI21xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_7),
.B(n_16),
.Y(n_19)
);


endmodule