module fake_netlist_710_551_n_65 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_65);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_65;

wire n_54;
wire n_24;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_20;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_23;
wire n_46;
wire n_31;
wire n_41;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_19;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

AND2x2_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_8),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_4),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_23),
.B(n_0),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

BUFx4f_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_20),
.Y(n_32)
);

NOR2x1p5_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_0),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_21),
.Y(n_34)
);

OAI22xp33_ASAP7_75t_L g35 ( 
.A1(n_30),
.A2(n_24),
.B1(n_25),
.B2(n_22),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_32),
.A2(n_27),
.B(n_21),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_32),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_25),
.B1(n_22),
.B2(n_19),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_36),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

OAI22xp33_ASAP7_75t_L g42 ( 
.A1(n_35),
.A2(n_34),
.B1(n_29),
.B2(n_26),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_37),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_38),
.C(n_35),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_45),
.B(n_42),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

OAI21xp5_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_41),
.B(n_44),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

OAI21xp5_ASAP7_75t_L g51 ( 
.A1(n_46),
.A2(n_41),
.B(n_31),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_47),
.A2(n_31),
.B1(n_34),
.B2(n_37),
.Y(n_52)
);

AND3x2_ASAP7_75t_L g53 ( 
.A(n_47),
.B(n_19),
.C(n_27),
.Y(n_53)
);

XNOR2xp5_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_1),
.Y(n_54)
);

NAND4xp25_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_28),
.C(n_48),
.D(n_1),
.Y(n_55)
);

NOR2x1_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_28),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_31),
.B1(n_5),
.B2(n_2),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_2),
.Y(n_58)
);

NAND4xp75_ASAP7_75t_L g59 ( 
.A(n_52),
.B(n_17),
.C(n_11),
.D(n_10),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_55),
.Y(n_60)
);

AOI221xp5_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_51),
.B1(n_18),
.B2(n_10),
.C(n_6),
.Y(n_61)
);

AOI22xp33_ASAP7_75t_L g62 ( 
.A1(n_56),
.A2(n_58),
.B1(n_59),
.B2(n_18),
.Y(n_62)
);

OAI22xp33_ASAP7_75t_L g63 ( 
.A1(n_60),
.A2(n_12),
.B1(n_9),
.B2(n_7),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_62),
.Y(n_64)
);

AOI22xp33_ASAP7_75t_L g65 ( 
.A1(n_64),
.A2(n_15),
.B1(n_61),
.B2(n_63),
.Y(n_65)
);


endmodule