module fake_netlist_710_2884_n_61 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_61);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_61;

wire n_54;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_58;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_24),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_11),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_0),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_17),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_13),
.Y(n_32)
);

AND2x4_ASAP7_75t_L g33 ( 
.A(n_7),
.B(n_15),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_3),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_19),
.B(n_25),
.Y(n_35)
);

BUFx3_ASAP7_75t_L g36 ( 
.A(n_10),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_1),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_16),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_29),
.B(n_16),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_17),
.Y(n_41)
);

BUFx6f_ASAP7_75t_L g42 ( 
.A(n_31),
.Y(n_42)
);

NOR2xp67_ASAP7_75t_SL g43 ( 
.A(n_38),
.B(n_37),
.Y(n_43)
);

NAND3xp33_ASAP7_75t_SL g44 ( 
.A(n_40),
.B(n_30),
.C(n_26),
.Y(n_44)
);

OAI22xp5_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_27),
.B1(n_35),
.B2(n_32),
.Y(n_45)
);

INVx4_ASAP7_75t_L g46 ( 
.A(n_43),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_39),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

NOR4xp25_ASAP7_75t_SL g49 ( 
.A(n_46),
.B(n_27),
.C(n_34),
.D(n_44),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_46),
.Y(n_50)
);

OAI211xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_40),
.B(n_42),
.C(n_39),
.Y(n_51)
);

AND2x2_ASAP7_75t_L g52 ( 
.A(n_48),
.B(n_41),
.Y(n_52)
);

AOI211xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_33),
.B(n_42),
.C(n_24),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_42),
.Y(n_54)
);

OAI21xp5_ASAP7_75t_SL g55 ( 
.A1(n_52),
.A2(n_33),
.B(n_25),
.Y(n_55)
);

NOR3xp33_ASAP7_75t_L g56 ( 
.A(n_55),
.B(n_50),
.C(n_2),
.Y(n_56)
);

NOR3xp33_ASAP7_75t_SL g57 ( 
.A(n_54),
.B(n_5),
.C(n_4),
.Y(n_57)
);

NAND4xp25_ASAP7_75t_SL g58 ( 
.A(n_53),
.B(n_9),
.C(n_8),
.D(n_6),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_12),
.Y(n_59)
);

INVxp67_ASAP7_75t_SL g60 ( 
.A(n_57),
.Y(n_60)
);

AOI322xp5_ASAP7_75t_L g61 ( 
.A1(n_60),
.A2(n_14),
.A3(n_18),
.B1(n_20),
.B2(n_23),
.C1(n_58),
.C2(n_59),
.Y(n_61)
);


endmodule