module fake_netlist_710_514_n_72 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_72);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_72;

wire n_54;
wire n_50;
wire n_24;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_22;
wire n_66;
wire n_47;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_71;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_70;
wire n_46;
wire n_31;
wire n_41;
wire n_23;
wire n_69;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_68;
wire n_33;
wire n_65;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_67;
wire n_39;
wire n_55;

AND2x4_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_9),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_11),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_10),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_4),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_SL g27 ( 
.A(n_6),
.B(n_13),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_2),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_16),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_2),
.Y(n_30)
);

OA21x2_ASAP7_75t_L g31 ( 
.A1(n_12),
.A2(n_0),
.B(n_19),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_21),
.A2(n_18),
.B1(n_16),
.B2(n_0),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

BUFx12f_ASAP7_75t_L g35 ( 
.A(n_21),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_21),
.A2(n_20),
.B1(n_19),
.B2(n_18),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_25),
.B(n_20),
.Y(n_37)
);

O2A1O1Ixp33_ASAP7_75t_L g38 ( 
.A1(n_28),
.A2(n_8),
.B(n_3),
.C(n_1),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_32),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_35),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_32),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_35),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_33),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_41),
.B(n_36),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_40),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_44),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_44),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_45),
.B(n_42),
.Y(n_51)
);

INVxp67_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

OAI21xp33_ASAP7_75t_L g53 ( 
.A1(n_48),
.A2(n_46),
.B(n_37),
.Y(n_53)
);

OAI211xp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_38),
.B(n_29),
.C(n_30),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_51),
.Y(n_55)
);

OAI211xp5_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_49),
.B(n_29),
.C(n_22),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_52),
.B(n_31),
.Y(n_57)
);

OAI22xp5_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_24),
.B1(n_31),
.B2(n_23),
.Y(n_58)
);

AOI221xp5_ASAP7_75t_L g59 ( 
.A1(n_53),
.A2(n_34),
.B1(n_26),
.B2(n_24),
.C(n_39),
.Y(n_59)
);

AO21x1_ASAP7_75t_L g60 ( 
.A1(n_55),
.A2(n_27),
.B(n_26),
.Y(n_60)
);

INVxp67_ASAP7_75t_SL g61 ( 
.A(n_57),
.Y(n_61)
);

NAND2xp33_ASAP7_75t_R g62 ( 
.A(n_56),
.B(n_31),
.Y(n_62)
);

O2A1O1Ixp33_ASAP7_75t_L g63 ( 
.A1(n_58),
.A2(n_39),
.B(n_34),
.C(n_14),
.Y(n_63)
);

HB1xp67_ASAP7_75t_L g64 ( 
.A(n_60),
.Y(n_64)
);

AND2x2_ASAP7_75t_L g65 ( 
.A(n_59),
.B(n_34),
.Y(n_65)
);

AND2x2_ASAP7_75t_L g66 ( 
.A(n_61),
.B(n_34),
.Y(n_66)
);

CKINVDCx20_ASAP7_75t_R g67 ( 
.A(n_64),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_65),
.Y(n_68)
);

INVx2_ASAP7_75t_L g69 ( 
.A(n_65),
.Y(n_69)
);

AOI22xp5_ASAP7_75t_SL g70 ( 
.A1(n_67),
.A2(n_62),
.B1(n_63),
.B2(n_15),
.Y(n_70)
);

OAI21xp33_ASAP7_75t_L g71 ( 
.A1(n_67),
.A2(n_63),
.B(n_66),
.Y(n_71)
);

OAI22xp33_ASAP7_75t_L g72 ( 
.A1(n_70),
.A2(n_68),
.B1(n_69),
.B2(n_71),
.Y(n_72)
);


endmodule