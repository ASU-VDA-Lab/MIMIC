module fake_netlist_710_503_n_22 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_22);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_22;

wire n_21;
wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_7;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_SL g11 ( 
.A(n_10),
.Y(n_11)
);

INVxp67_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AO31x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_7),
.A3(n_8),
.B(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_8),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_7),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_8),
.B1(n_13),
.B2(n_4),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_13),
.B1(n_6),
.B2(n_4),
.C(n_0),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx4_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B1(n_5),
.B2(n_3),
.Y(n_22)
);


endmodule