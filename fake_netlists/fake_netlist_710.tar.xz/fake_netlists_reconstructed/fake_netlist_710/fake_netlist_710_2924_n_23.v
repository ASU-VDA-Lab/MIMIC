module fake_netlist_710_2924_n_23 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_23);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_23;

wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_11;
wire n_19;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_5),
.Y(n_12)
);

BUFx6f_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_L g14 ( 
.A(n_3),
.B(n_10),
.C(n_9),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_R g15 ( 
.A(n_6),
.B(n_4),
.Y(n_15)
);

OAI21x1_ASAP7_75t_L g16 ( 
.A1(n_11),
.A2(n_1),
.B(n_0),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_17),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_15),
.C(n_14),
.Y(n_20)
);

AND3x4_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_12),
.C(n_7),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

OR2x6_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_13),
.Y(n_23)
);


endmodule