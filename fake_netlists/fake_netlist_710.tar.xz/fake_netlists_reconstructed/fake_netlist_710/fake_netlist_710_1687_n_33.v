module fake_netlist_710_1687_n_33 (n_9, n_4, n_2, n_7, n_14, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_33);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_33;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

INVx2_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

NOR2xp67_ASAP7_75t_L g16 ( 
.A(n_5),
.B(n_8),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_5),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_7),
.B(n_2),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_1),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_3),
.B1(n_0),
.B2(n_4),
.C(n_6),
.Y(n_22)
);

O2A1O1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_7),
.B(n_4),
.C(n_3),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_18),
.B1(n_15),
.B2(n_19),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_17),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_15),
.Y(n_26)
);

O2A1O1Ixp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_17),
.B(n_24),
.C(n_21),
.Y(n_27)
);

OAI322xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_26),
.A3(n_16),
.B1(n_11),
.B2(n_8),
.C1(n_10),
.C2(n_9),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_10),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_11),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_27),
.B1(n_14),
.B2(n_13),
.Y(n_31)
);

XNOR2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_29),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_29),
.B1(n_30),
.B2(n_31),
.Y(n_33)
);


endmodule