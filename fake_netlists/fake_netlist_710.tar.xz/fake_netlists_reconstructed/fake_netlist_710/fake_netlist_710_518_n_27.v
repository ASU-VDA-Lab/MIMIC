module fake_netlist_710_518_n_27 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_12;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

OR2x6_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_7),
.Y(n_10)
);

OR2x2_ASAP7_75t_L g11 ( 
.A(n_4),
.B(n_5),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_8),
.B(n_2),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_6),
.B(n_3),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_L g14 ( 
.A(n_1),
.B(n_9),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_5),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_11),
.B(n_13),
.Y(n_17)
);

AO31x2_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_15),
.A3(n_16),
.B(n_12),
.Y(n_18)
);

OAI21x1_ASAP7_75t_L g19 ( 
.A1(n_10),
.A2(n_16),
.B(n_12),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_18),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_10),
.Y(n_22)
);

NAND2x1p5_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_17),
.Y(n_23)
);

OAI21xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_21),
.B(n_20),
.Y(n_24)
);

OR2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_22),
.Y(n_25)
);

INVxp67_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_21),
.Y(n_27)
);


endmodule