module fake_netlist_710_2732_n_54 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_54);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_54;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_9),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_22),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_11),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_4),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_23),
.B(n_10),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_6),
.B(n_12),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_2),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_7),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_SL g33 ( 
.A(n_32),
.B(n_31),
.C(n_28),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx2_ASAP7_75t_SL g35 ( 
.A(n_26),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_29),
.B(n_27),
.Y(n_36)
);

OAI21x1_ASAP7_75t_SL g37 ( 
.A1(n_34),
.A2(n_29),
.B(n_24),
.Y(n_37)
);

OAI22xp33_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_30),
.B1(n_25),
.B2(n_16),
.Y(n_38)
);

NAND3xp33_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_30),
.C(n_16),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

BUFx3_ASAP7_75t_L g41 ( 
.A(n_37),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_40),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

NOR3xp33_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_38),
.C(n_43),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_36),
.B(n_35),
.Y(n_46)
);

AOI211xp5_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_30),
.B(n_19),
.C(n_18),
.Y(n_47)
);

NOR2xp67_ASAP7_75t_L g48 ( 
.A(n_46),
.B(n_18),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_19),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_49),
.Y(n_50)
);

HB1xp67_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

OAI22xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_13),
.B1(n_8),
.B2(n_5),
.Y(n_53)
);

AOI221xp5_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_14),
.B1(n_17),
.B2(n_20),
.C(n_52),
.Y(n_54)
);


endmodule