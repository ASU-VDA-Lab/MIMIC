module fake_netlist_710_412_n_17 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_17);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_17;

wire n_8;
wire n_9;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

INVxp33_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AND2x6_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_7),
.Y(n_10)
);

AOI221x1_ASAP7_75t_L g11 ( 
.A1(n_8),
.A2(n_10),
.B1(n_9),
.B2(n_1),
.C(n_3),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

INVxp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.C(n_10),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_4),
.Y(n_15)
);

AOI22x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_16)
);

AOI21x1_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_6),
.B(n_15),
.Y(n_17)
);


endmodule