module fake_netlist_710_2723_n_38 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_38);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_38;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_19;
wire n_25;

OAI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_6),
.B1(n_2),
.B2(n_8),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_0),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_9),
.Y(n_19)
);

OAI21xp33_ASAP7_75t_L g20 ( 
.A1(n_6),
.A2(n_4),
.B(n_11),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

INVx4_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_7),
.Y(n_23)
);

AO31x2_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_7),
.A3(n_5),
.B(n_1),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_18),
.A2(n_13),
.B(n_12),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_17),
.A2(n_14),
.B(n_5),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_26),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_24),
.B(n_22),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_22),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_SL g32 ( 
.A1(n_30),
.A2(n_20),
.B(n_16),
.C(n_27),
.Y(n_32)
);

AOI221xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_16),
.B1(n_19),
.B2(n_17),
.C(n_21),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_24),
.Y(n_34)
);

CKINVDCx16_ASAP7_75t_R g35 ( 
.A(n_32),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_19),
.Y(n_36)
);

OAI22xp5_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_21),
.B1(n_25),
.B2(n_35),
.Y(n_37)
);

NOR2x1_ASAP7_75t_SL g38 ( 
.A(n_37),
.B(n_36),
.Y(n_38)
);


endmodule