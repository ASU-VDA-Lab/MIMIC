module fake_netlist_710_2419_n_51 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_51);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_51;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

AND2x2_ASAP7_75t_L g23 ( 
.A(n_9),
.B(n_11),
.Y(n_23)
);

INVx2_ASAP7_75t_SL g24 ( 
.A(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

XOR2x2_ASAP7_75t_L g26 ( 
.A(n_12),
.B(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_21),
.A2(n_10),
.B1(n_1),
.B2(n_5),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_15),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_6),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_24),
.B(n_18),
.Y(n_32)
);

CKINVDCx8_ASAP7_75t_R g33 ( 
.A(n_30),
.Y(n_33)
);

AND2x6_ASAP7_75t_L g34 ( 
.A(n_23),
.B(n_27),
.Y(n_34)
);

AND2x6_ASAP7_75t_SL g35 ( 
.A(n_32),
.B(n_26),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_30),
.Y(n_36)
);

INVx3_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_33),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_37),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_34),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_35),
.Y(n_42)
);

AND2x4_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_18),
.Y(n_43)
);

OAI21xp5_ASAP7_75t_L g44 ( 
.A1(n_43),
.A2(n_28),
.B(n_29),
.Y(n_44)
);

XNOR2x1_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_28),
.Y(n_45)
);

NAND4xp25_ASAP7_75t_SL g46 ( 
.A(n_44),
.B(n_19),
.C(n_3),
.D(n_2),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

CKINVDCx20_ASAP7_75t_R g49 ( 
.A(n_47),
.Y(n_49)
);

AOI222xp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_19),
.B1(n_13),
.B2(n_4),
.C1(n_16),
.C2(n_7),
.Y(n_50)
);

AOI22x1_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_49),
.B1(n_22),
.B2(n_20),
.Y(n_51)
);


endmodule