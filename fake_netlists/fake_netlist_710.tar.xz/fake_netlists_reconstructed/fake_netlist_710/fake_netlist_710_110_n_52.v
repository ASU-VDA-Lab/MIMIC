module fake_netlist_710_110_n_52 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_52);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_52;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_7),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_4),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_19),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_5),
.B(n_3),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_10),
.B(n_13),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_0),
.B(n_9),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_20),
.Y(n_33)
);

INVxp67_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_27),
.B(n_19),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_36),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_37),
.B1(n_35),
.B2(n_30),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_24),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_33),
.C(n_30),
.Y(n_43)
);

OAI221xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_31),
.B1(n_25),
.B2(n_32),
.C(n_1),
.Y(n_44)
);

NOR2x1p5_ASAP7_75t_SL g45 ( 
.A(n_43),
.B(n_32),
.Y(n_45)
);

AOI21xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_6),
.B(n_2),
.Y(n_46)
);

AOI22xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_14),
.B1(n_11),
.B2(n_8),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

CKINVDCx20_ASAP7_75t_R g49 ( 
.A(n_46),
.Y(n_49)
);

AND2x4_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_15),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_49),
.Y(n_51)
);

AOI222xp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_16),
.B1(n_18),
.B2(n_21),
.C1(n_22),
.C2(n_51),
.Y(n_52)
);


endmodule