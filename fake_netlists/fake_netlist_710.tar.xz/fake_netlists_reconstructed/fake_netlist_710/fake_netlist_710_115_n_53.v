module fake_netlist_710_115_n_53 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_53);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_53;

wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_46;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_48;
wire n_49;
wire n_39;

INVx1_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_4),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_0),
.B(n_1),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_8),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_11),
.B(n_21),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_15),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_14),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_12),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_25),
.B1(n_3),
.B2(n_2),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_SL g36 ( 
.A(n_33),
.B(n_25),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_27),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_26),
.B(n_5),
.Y(n_38)
);

INVx3_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_38),
.Y(n_40)
);

HB1xp67_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

AOI31xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_35),
.A3(n_36),
.B(n_28),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_30),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_29),
.Y(n_44)
);

XNOR2xp5_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_34),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_31),
.Y(n_46)
);

O2A1O1Ixp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_9),
.B(n_7),
.C(n_6),
.Y(n_47)
);

NAND3x1_ASAP7_75t_SL g48 ( 
.A(n_45),
.B(n_13),
.C(n_10),
.Y(n_48)
);

HB1xp67_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

CKINVDCx20_ASAP7_75t_R g51 ( 
.A(n_49),
.Y(n_51)
);

HB1xp67_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

OAI332xp33_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_17),
.A3(n_19),
.B1(n_20),
.B2(n_22),
.B3(n_23),
.C1(n_24),
.C2(n_52),
.Y(n_53)
);


endmodule