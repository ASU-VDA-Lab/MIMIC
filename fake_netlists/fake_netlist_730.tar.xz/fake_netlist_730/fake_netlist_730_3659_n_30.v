module fake_netlist_730_3659_n_30 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_30);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_30;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_28;
wire n_27;
wire n_24;
wire n_10;
wire n_26;
wire n_25;
wire n_17;
wire n_21;
wire n_12;
wire n_19;
wire n_15;
wire n_29;

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_0),
.B(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_6),
.B(n_9),
.Y(n_13)
);

BUFx6f_ASAP7_75t_SL g14 ( 
.A(n_9),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_1),
.Y(n_15)
);

INVxp33_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_0),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_11),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_18)
);

NAND3xp33_ASAP7_75t_SL g19 ( 
.A(n_11),
.B(n_4),
.C(n_3),
.Y(n_19)
);

NOR4xp25_ASAP7_75t_L g20 ( 
.A(n_10),
.B(n_6),
.C(n_5),
.D(n_4),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_12),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_12),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_12),
.Y(n_23)
);

NAND2x1_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_12),
.Y(n_24)
);

OAI21xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_22),
.B(n_20),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_18),
.C(n_13),
.Y(n_26)
);

INVx2_ASAP7_75t_SL g27 ( 
.A(n_26),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_19),
.Y(n_28)
);

OAI21x1_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_15),
.B(n_5),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_R g30 ( 
.A1(n_29),
.A2(n_14),
.B1(n_27),
.B2(n_11),
.Y(n_30)
);


endmodule