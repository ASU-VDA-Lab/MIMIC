module fake_netlist_730_2507_n_34 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_6, n_0, n_8, n_34);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_6;
input n_0;
input n_8;

output n_34;

wire n_20;
wire n_23;
wire n_22;
wire n_18;
wire n_28;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_25;
wire n_17;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

AND2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_13),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_11),
.B(n_8),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_4),
.B(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_19),
.B(n_20),
.Y(n_23)
);

INVx5_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

OAI22xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_22),
.B1(n_18),
.B2(n_17),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_23),
.Y(n_29)
);

NAND2x1_ASAP7_75t_SL g30 ( 
.A(n_29),
.B(n_18),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_25),
.B1(n_16),
.B2(n_15),
.Y(n_31)
);

OAI221xp5_ASAP7_75t_SL g32 ( 
.A1(n_30),
.A2(n_16),
.B1(n_15),
.B2(n_0),
.C(n_1),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_31),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_10),
.B2(n_9),
.Y(n_34)
);


endmodule