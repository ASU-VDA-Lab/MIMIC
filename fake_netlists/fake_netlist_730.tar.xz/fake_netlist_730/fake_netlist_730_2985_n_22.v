module fake_netlist_730_2985_n_22 (n_1, n_2, n_3, n_9, n_4, n_5, n_7, n_6, n_0, n_8, n_22);

input n_1;
input n_2;
input n_3;
input n_9;
input n_4;
input n_5;
input n_7;
input n_6;
input n_0;
input n_8;

output n_22;

wire n_20;
wire n_14;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_10;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_SL g11 ( 
.A1(n_6),
.A2(n_1),
.B1(n_8),
.B2(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx5_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_6),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_4),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_13),
.Y(n_17)
);

HB1xp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI211xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B(n_11),
.C(n_7),
.Y(n_19)
);

NAND2xp33_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_0),
.Y(n_20)
);

NAND2x1_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_2),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_9),
.B1(n_13),
.B2(n_10),
.Y(n_22)
);


endmodule