module fake_netlist_730_1017_n_41 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_41);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_41;

wire n_23;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_29;
wire n_32;

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_7),
.Y(n_26)
);

INVx4_ASAP7_75t_L g27 ( 
.A(n_13),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_SL g28 ( 
.A(n_24),
.B(n_23),
.C(n_22),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_L g29 ( 
.A(n_25),
.B(n_0),
.Y(n_29)
);

NAND3xp33_ASAP7_75t_SL g30 ( 
.A(n_26),
.B(n_27),
.C(n_21),
.Y(n_30)
);

OAI22xp33_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_27),
.B1(n_21),
.B2(n_18),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_28),
.Y(n_32)
);

BUFx3_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_31),
.Y(n_35)
);

AOI332xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_19),
.A3(n_18),
.B1(n_33),
.B2(n_29),
.B3(n_1),
.C1(n_3),
.C2(n_2),
.Y(n_36)
);

NAND4xp25_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_6),
.C(n_5),
.D(n_4),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

AOI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_36),
.A2(n_11),
.B1(n_9),
.B2(n_8),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_SL g40 ( 
.A1(n_39),
.A2(n_17),
.B1(n_15),
.B2(n_14),
.Y(n_40)
);

OAI21xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_38),
.B(n_20),
.Y(n_41)
);


endmodule