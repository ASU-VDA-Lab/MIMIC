module fake_netlist_730_1946_n_78 (n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_12, n_15, n_19, n_0, n_8, n_78);

input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_78;

wire n_20;
wire n_77;
wire n_71;
wire n_62;
wire n_36;
wire n_68;
wire n_73;
wire n_24;
wire n_60;
wire n_53;
wire n_57;
wire n_41;
wire n_55;
wire n_23;
wire n_46;
wire n_64;
wire n_22;
wire n_76;
wire n_72;
wire n_51;
wire n_75;
wire n_42;
wire n_33;
wire n_70;
wire n_63;
wire n_25;
wire n_69;
wire n_56;
wire n_52;
wire n_61;
wire n_45;
wire n_28;
wire n_65;
wire n_50;
wire n_35;
wire n_21;
wire n_43;
wire n_58;
wire n_74;
wire n_44;
wire n_66;
wire n_34;
wire n_39;
wire n_48;
wire n_49;
wire n_37;
wire n_27;
wire n_59;
wire n_26;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_67;
wire n_29;
wire n_47;
wire n_54;
wire n_32;

INVx1_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

NOR2xp67_ASAP7_75t_L g23 ( 
.A(n_18),
.B(n_1),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_3),
.B(n_2),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_5),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_7),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_9),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_12),
.B(n_19),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_17),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_21),
.A2(n_26),
.B(n_20),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_29),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_29),
.B(n_1),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_28),
.Y(n_38)
);

AND2x6_ASAP7_75t_SL g39 ( 
.A(n_30),
.B(n_16),
.Y(n_39)
);

INVx2_ASAP7_75t_SL g40 ( 
.A(n_28),
.Y(n_40)
);

NAND3xp33_ASAP7_75t_SL g41 ( 
.A(n_32),
.B(n_19),
.C(n_17),
.Y(n_41)
);

NAND3xp33_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_32),
.C(n_31),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_34),
.Y(n_43)
);

OA21x2_ASAP7_75t_L g44 ( 
.A1(n_35),
.A2(n_24),
.B(n_22),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_37),
.A2(n_31),
.B1(n_23),
.B2(n_22),
.Y(n_45)
);

OAI21x1_ASAP7_75t_L g46 ( 
.A1(n_38),
.A2(n_27),
.B(n_24),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_36),
.B(n_27),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_38),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

BUFx3_ASAP7_75t_L g51 ( 
.A(n_43),
.Y(n_51)
);

BUFx2_ASAP7_75t_L g52 ( 
.A(n_42),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_52),
.B(n_45),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_47),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_48),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_49),
.Y(n_57)
);

OAI32xp33_ASAP7_75t_L g58 ( 
.A1(n_57),
.A2(n_38),
.A3(n_34),
.B1(n_36),
.B2(n_43),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

OAI221xp5_ASAP7_75t_SL g60 ( 
.A1(n_53),
.A2(n_40),
.B1(n_36),
.B2(n_33),
.C(n_39),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_53),
.B(n_50),
.Y(n_61)
);

OAI21xp5_ASAP7_75t_L g62 ( 
.A1(n_56),
.A2(n_44),
.B(n_40),
.Y(n_62)
);

INVx1_ASAP7_75t_SL g63 ( 
.A(n_59),
.Y(n_63)
);

OAI221xp5_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_54),
.B1(n_33),
.B2(n_41),
.C(n_44),
.Y(n_64)
);

OAI21xp5_ASAP7_75t_L g65 ( 
.A1(n_62),
.A2(n_56),
.B(n_44),
.Y(n_65)
);

AOI221xp5_ASAP7_75t_L g66 ( 
.A1(n_61),
.A2(n_39),
.B1(n_25),
.B2(n_0),
.C(n_4),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_61),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_67),
.Y(n_68)
);

NOR3x2_ASAP7_75t_L g69 ( 
.A(n_66),
.B(n_58),
.C(n_8),
.Y(n_69)
);

XNOR2xp5_ASAP7_75t_L g70 ( 
.A(n_63),
.B(n_10),
.Y(n_70)
);

INVxp33_ASAP7_75t_SL g71 ( 
.A(n_65),
.Y(n_71)
);

XNOR2xp5_ASAP7_75t_L g72 ( 
.A(n_64),
.B(n_13),
.Y(n_72)
);

CKINVDCx20_ASAP7_75t_R g73 ( 
.A(n_70),
.Y(n_73)
);

INVxp67_ASAP7_75t_L g74 ( 
.A(n_68),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_72),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_74),
.B(n_71),
.Y(n_76)
);

INVx2_ASAP7_75t_L g77 ( 
.A(n_75),
.Y(n_77)
);

AOI222xp33_ASAP7_75t_L g78 ( 
.A1(n_76),
.A2(n_58),
.B1(n_69),
.B2(n_71),
.C1(n_73),
.C2(n_77),
.Y(n_78)
);


endmodule