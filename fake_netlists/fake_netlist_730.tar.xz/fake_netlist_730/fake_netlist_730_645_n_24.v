module fake_netlist_730_645_n_24 (n_1, n_2, n_3, n_4, n_0, n_24);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_24;

wire n_20;
wire n_23;
wire n_14;
wire n_22;
wire n_18;
wire n_16;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

INVx4_ASAP7_75t_SL g5 ( 
.A(n_4),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

INVx4_ASAP7_75t_SL g10 ( 
.A(n_5),
.Y(n_10)
);

INVx6_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVxp33_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVxp67_ASAP7_75t_SL g13 ( 
.A(n_12),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_6),
.Y(n_14)
);

NAND4xp25_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_7),
.C(n_5),
.D(n_0),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_7),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

INVxp33_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

XNOR2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_17),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_15),
.B(n_10),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_4),
.B1(n_1),
.B2(n_11),
.C(n_3),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

OR3x1_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_20),
.C(n_15),
.Y(n_23)
);

XNOR2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_23),
.Y(n_24)
);


endmodule