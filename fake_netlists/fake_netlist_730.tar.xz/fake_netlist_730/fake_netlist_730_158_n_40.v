module fake_netlist_730_158_n_40 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_16, n_17, n_6, n_0, n_8, n_40);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_16;
input n_17;
input n_6;
input n_0;
input n_8;

output n_40;

wire n_20;
wire n_23;
wire n_22;
wire n_36;
wire n_18;
wire n_34;
wire n_39;
wire n_28;
wire n_27;
wire n_37;
wire n_24;
wire n_26;
wire n_33;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_21;
wire n_19;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_14),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_4),
.B(n_17),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_13),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

OAI33xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_26),
.A3(n_23),
.B1(n_25),
.B2(n_22),
.B3(n_20),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_24),
.B1(n_21),
.B2(n_16),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_24),
.Y(n_32)
);

OAI211xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_30),
.B(n_17),
.C(n_16),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_0),
.Y(n_34)
);

AOI221xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_3),
.B1(n_1),
.B2(n_5),
.C(n_7),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND3xp33_ASAP7_75t_SL g37 ( 
.A(n_35),
.B(n_9),
.C(n_8),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_36),
.B(n_10),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_37),
.B1(n_12),
.B2(n_11),
.Y(n_40)
);


endmodule