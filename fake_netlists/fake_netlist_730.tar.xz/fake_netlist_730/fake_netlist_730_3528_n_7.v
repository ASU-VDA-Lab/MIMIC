module fake_netlist_730_3528_n_7 (n_0, n_1, n_7);

input n_0;
input n_1;

output n_7;

wire n_2;
wire n_3;
wire n_4;
wire n_5;
wire n_6;

BUFx3_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

INVx2_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

BUFx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

AND2x4_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_0),
.Y(n_5)
);

AOI211xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_0),
.B(n_4),
.C(n_3),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);


endmodule