module fake_netlist_730_2603_n_52 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_52);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_52;

wire n_46;
wire n_44;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

NOR2xp67_ASAP7_75t_L g30 ( 
.A(n_15),
.B(n_8),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_14),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_0),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_22),
.B(n_18),
.Y(n_33)
);

AND2x6_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_26),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_R g35 ( 
.A(n_31),
.B(n_1),
.Y(n_35)
);

INVx2_ASAP7_75t_SL g36 ( 
.A(n_27),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_28),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_25),
.B1(n_32),
.B2(n_29),
.Y(n_38)
);

BUFx8_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NOR4xp25_ASAP7_75t_SL g40 ( 
.A(n_39),
.B(n_24),
.C(n_35),
.D(n_34),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_34),
.Y(n_42)
);

INVxp67_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

INVx2_ASAP7_75t_SL g44 ( 
.A(n_42),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_SL g45 ( 
.A(n_43),
.B(n_30),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_SL g46 ( 
.A(n_44),
.B(n_30),
.Y(n_46)
);

NAND3xp33_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_3),
.C(n_2),
.Y(n_47)
);

AND4x1_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_7),
.C(n_5),
.D(n_4),
.Y(n_48)
);

NOR3xp33_ASAP7_75t_SL g49 ( 
.A(n_46),
.B(n_11),
.C(n_9),
.Y(n_49)
);

INVx2_ASAP7_75t_SL g50 ( 
.A(n_48),
.Y(n_50)
);

OR2x2_ASAP7_75t_L g51 ( 
.A(n_49),
.B(n_12),
.Y(n_51)
);

AOI322xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_13),
.A3(n_17),
.B1(n_19),
.B2(n_20),
.C1(n_21),
.C2(n_51),
.Y(n_52)
);


endmodule