module fake_netlist_730_2978_n_13 (n_1, n_2, n_3, n_4, n_5, n_6, n_0, n_13);

input n_1;
input n_2;
input n_3;
input n_4;
input n_5;
input n_6;
input n_0;

output n_13;

wire n_12;
wire n_8;
wire n_9;
wire n_10;
wire n_7;
wire n_11;

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx4_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_1),
.A2(n_6),
.B1(n_2),
.B2(n_4),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

BUFx3_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

OAI22xp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B1(n_9),
.B2(n_10),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_8),
.B1(n_1),
.B2(n_0),
.Y(n_13)
);


endmodule