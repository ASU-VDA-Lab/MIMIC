module fake_netlist_730_1082_n_22 (n_1, n_2, n_3, n_4, n_0, n_22);

input n_1;
input n_2;
input n_3;
input n_4;
input n_0;

output n_22;

wire n_20;
wire n_14;
wire n_16;
wire n_18;
wire n_13;
wire n_11;
wire n_10;
wire n_5;
wire n_6;
wire n_9;
wire n_7;
wire n_17;
wire n_21;
wire n_12;
wire n_15;
wire n_19;
wire n_8;

OR2x2_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_3),
.Y(n_7)
);

NAND3xp33_ASAP7_75t_L g8 ( 
.A(n_4),
.B(n_0),
.C(n_3),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

NAND4xp25_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_8),
.C(n_9),
.D(n_0),
.Y(n_15)
);

OAI21xp33_ASAP7_75t_L g16 ( 
.A1(n_12),
.A2(n_9),
.B(n_11),
.Y(n_16)
);

A2O1A1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_11),
.B(n_3),
.C(n_2),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_14),
.B1(n_13),
.B2(n_2),
.C(n_3),
.Y(n_18)
);

NAND4xp25_ASAP7_75t_L g19 ( 
.A(n_17),
.B(n_1),
.C(n_0),
.D(n_2),
.Y(n_19)
);

INVxp33_ASAP7_75t_SL g20 ( 
.A(n_16),
.Y(n_20)
);

NAND4xp25_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_4),
.C(n_19),
.D(n_20),
.Y(n_21)
);

BUFx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);


endmodule