module fake_netlist_730_534_n_56 (n_12, n_15, n_14, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_56);

input n_12;
input n_15;
input n_14;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_56;

wire n_20;
wire n_23;
wire n_46;
wire n_44;
wire n_22;
wire n_36;
wire n_16;
wire n_18;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_37;
wire n_42;
wire n_27;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_19;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_1),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_6),
.B(n_10),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

INVx1_ASAP7_75t_SL g20 ( 
.A(n_3),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_4),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_11),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_10),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_12),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_17),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_14),
.B(n_9),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_1),
.B(n_0),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_21),
.B(n_0),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_19),
.A2(n_3),
.B(n_2),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_23),
.B(n_2),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

OR2x6_ASAP7_75t_L g36 ( 
.A(n_30),
.B(n_18),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_29),
.Y(n_37)
);

AND2x4_ASAP7_75t_SL g38 ( 
.A(n_26),
.B(n_18),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_20),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NAND3xp33_ASAP7_75t_SL g41 ( 
.A(n_34),
.B(n_31),
.C(n_24),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_20),
.Y(n_42)
);

AOI321xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_33),
.A3(n_28),
.B1(n_27),
.B2(n_36),
.C(n_37),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_36),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

O2A1O1Ixp33_ASAP7_75t_SL g47 ( 
.A1(n_46),
.A2(n_35),
.B(n_5),
.C(n_4),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

AND4x2_ASAP7_75t_L g49 ( 
.A(n_43),
.B(n_8),
.C(n_7),
.D(n_6),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_48),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_45),
.Y(n_53)
);

CKINVDCx16_ASAP7_75t_R g54 ( 
.A(n_51),
.Y(n_54)
);

AO22x2_ASAP7_75t_L g55 ( 
.A1(n_52),
.A2(n_43),
.B1(n_8),
.B2(n_7),
.Y(n_55)
);

AOI22xp5_ASAP7_75t_SL g56 ( 
.A1(n_55),
.A2(n_54),
.B1(n_51),
.B2(n_53),
.Y(n_56)
);


endmodule