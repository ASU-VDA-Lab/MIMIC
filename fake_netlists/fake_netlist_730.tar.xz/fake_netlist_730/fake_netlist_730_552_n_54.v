module fake_netlist_730_552_n_54 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_54);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_54;

wire n_46;
wire n_44;
wire n_36;
wire n_34;
wire n_39;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_47;
wire n_52;
wire n_32;

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

OA21x2_ASAP7_75t_L g25 ( 
.A1(n_12),
.A2(n_14),
.B(n_23),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

NOR2x1_ASAP7_75t_L g28 ( 
.A(n_8),
.B(n_22),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_16),
.B(n_13),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_1),
.B(n_3),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_2),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_4),
.B(n_20),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_26),
.B(n_16),
.Y(n_33)
);

INVxp67_ASAP7_75t_SL g34 ( 
.A(n_26),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_29),
.A2(n_19),
.B1(n_18),
.B2(n_5),
.Y(n_35)
);

BUFx8_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

OA21x2_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_27),
.B(n_30),
.Y(n_37)
);

BUFx2_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

AO31x2_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_27),
.A3(n_31),
.B(n_32),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

NAND2xp33_ASAP7_75t_SL g44 ( 
.A(n_43),
.B(n_24),
.Y(n_44)
);

INVxp67_ASAP7_75t_SL g45 ( 
.A(n_42),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_42),
.B1(n_24),
.B2(n_28),
.C(n_39),
.Y(n_46)
);

AOI31xp33_ASAP7_75t_L g47 ( 
.A1(n_45),
.A2(n_36),
.A3(n_18),
.B(n_25),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_25),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_7),
.B1(n_6),
.B2(n_9),
.C(n_10),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_47),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_11),
.Y(n_51)
);

AND2x4_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_15),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_51),
.B(n_49),
.Y(n_53)
);

OA22x2_ASAP7_75t_L g54 ( 
.A1(n_53),
.A2(n_21),
.B1(n_52),
.B2(n_50),
.Y(n_54)
);


endmodule