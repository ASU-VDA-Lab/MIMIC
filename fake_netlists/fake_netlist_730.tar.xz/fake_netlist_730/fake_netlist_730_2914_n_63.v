module fake_netlist_730_2914_n_63 (n_20, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_63);

input n_20;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_63;

wire n_23;
wire n_46;
wire n_44;
wire n_61;
wire n_62;
wire n_36;
wire n_39;
wire n_34;
wire n_51;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_42;
wire n_37;
wire n_24;
wire n_59;
wire n_26;
wire n_33;
wire n_60;
wire n_40;
wire n_31;
wire n_50;
wire n_30;
wire n_38;
wire n_53;
wire n_35;
wire n_57;
wire n_25;
wire n_43;
wire n_56;
wire n_58;
wire n_41;
wire n_55;
wire n_29;
wire n_47;
wire n_52;
wire n_54;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_6),
.Y(n_25)
);

INVx4_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_12),
.Y(n_27)
);

HB1xp67_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_17),
.B(n_21),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_11),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_9),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_14),
.B(n_10),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_19),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_16),
.B(n_2),
.Y(n_34)
);

OAI21xp5_ASAP7_75t_L g35 ( 
.A1(n_25),
.A2(n_3),
.B(n_0),
.Y(n_35)
);

INVx1_ASAP7_75t_SL g36 ( 
.A(n_29),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_SL g37 ( 
.A(n_25),
.B(n_15),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_25),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_28),
.B(n_15),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_27),
.B(n_17),
.Y(n_40)
);

CKINVDCx11_ASAP7_75t_R g41 ( 
.A(n_36),
.Y(n_41)
);

AO21x2_ASAP7_75t_L g42 ( 
.A1(n_35),
.A2(n_32),
.B(n_30),
.Y(n_42)
);

OAI21x1_ASAP7_75t_L g43 ( 
.A1(n_38),
.A2(n_27),
.B(n_30),
.Y(n_43)
);

NAND3xp33_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_31),
.C(n_33),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx3_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_36),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_41),
.Y(n_48)
);

AND2x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_39),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_46),
.B1(n_42),
.B2(n_44),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_46),
.Y(n_51)
);

NOR2x1_ASAP7_75t_L g52 ( 
.A(n_47),
.B(n_37),
.Y(n_52)
);

OAI322xp33_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_24),
.A3(n_31),
.B1(n_29),
.B2(n_26),
.C1(n_38),
.C2(n_49),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

OAI21xp5_ASAP7_75t_L g55 ( 
.A1(n_50),
.A2(n_34),
.B(n_24),
.Y(n_55)
);

AOI221xp5_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_26),
.B1(n_34),
.B2(n_23),
.C(n_18),
.Y(n_56)
);

OR2x2_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_19),
.Y(n_57)
);

NAND4xp75_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_22),
.C(n_21),
.D(n_20),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_57),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_L g60 ( 
.A1(n_58),
.A2(n_7),
.B1(n_5),
.B2(n_4),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_56),
.B(n_8),
.Y(n_61)
);

CKINVDCx20_ASAP7_75t_R g62 ( 
.A(n_59),
.Y(n_62)
);

OAI21xp33_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_61),
.B(n_60),
.Y(n_63)
);


endmodule