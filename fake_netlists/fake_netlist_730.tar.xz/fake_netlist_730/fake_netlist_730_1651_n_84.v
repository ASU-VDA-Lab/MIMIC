module fake_netlist_730_1651_n_84 (n_20, n_23, n_14, n_22, n_16, n_18, n_13, n_11, n_1, n_24, n_10, n_5, n_26, n_6, n_2, n_3, n_9, n_4, n_25, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_84);

input n_20;
input n_23;
input n_14;
input n_22;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_24;
input n_10;
input n_5;
input n_26;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_25;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_84;

wire n_77;
wire n_71;
wire n_80;
wire n_62;
wire n_36;
wire n_81;
wire n_68;
wire n_73;
wire n_60;
wire n_53;
wire n_57;
wire n_41;
wire n_55;
wire n_46;
wire n_64;
wire n_82;
wire n_76;
wire n_72;
wire n_51;
wire n_78;
wire n_75;
wire n_42;
wire n_33;
wire n_70;
wire n_63;
wire n_69;
wire n_56;
wire n_52;
wire n_61;
wire n_45;
wire n_28;
wire n_65;
wire n_50;
wire n_79;
wire n_35;
wire n_43;
wire n_58;
wire n_74;
wire n_44;
wire n_66;
wire n_34;
wire n_39;
wire n_48;
wire n_49;
wire n_37;
wire n_27;
wire n_59;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_67;
wire n_29;
wire n_47;
wire n_54;
wire n_32;
wire n_83;

BUFx3_ASAP7_75t_L g27 ( 
.A(n_16),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_18),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_17),
.Y(n_31)
);

NAND2xp33_ASAP7_75t_L g32 ( 
.A(n_21),
.B(n_1),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_0),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_12),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_11),
.B(n_26),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_19),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_25),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_26),
.Y(n_38)
);

INVx5_ASAP7_75t_L g39 ( 
.A(n_3),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_7),
.B(n_20),
.Y(n_40)
);

INVxp33_ASAP7_75t_L g41 ( 
.A(n_10),
.Y(n_41)
);

INVx3_ASAP7_75t_L g42 ( 
.A(n_38),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_SL g43 ( 
.A(n_41),
.B(n_29),
.Y(n_43)
);

BUFx6f_ASAP7_75t_L g44 ( 
.A(n_34),
.Y(n_44)
);

AO22x1_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_37),
.B1(n_35),
.B2(n_28),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_31),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_29),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_27),
.B(n_22),
.Y(n_48)
);

AND2x6_ASAP7_75t_L g49 ( 
.A(n_40),
.B(n_2),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_42),
.Y(n_50)
);

OAI21x1_ASAP7_75t_L g51 ( 
.A1(n_43),
.A2(n_33),
.B(n_30),
.Y(n_51)
);

INVx3_ASAP7_75t_L g52 ( 
.A(n_42),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_43),
.B(n_36),
.Y(n_53)
);

AOI22xp33_ASAP7_75t_L g54 ( 
.A1(n_49),
.A2(n_32),
.B1(n_27),
.B2(n_34),
.Y(n_54)
);

BUFx8_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

AND2x2_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_45),
.Y(n_56)
);

HB1xp67_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

CKINVDCx5p33_ASAP7_75t_R g58 ( 
.A(n_53),
.Y(n_58)
);

OR2x2_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_46),
.Y(n_59)
);

A2O1A1Ixp33_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_51),
.B(n_54),
.C(n_58),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_48),
.Y(n_61)
);

AND2x2_ASAP7_75t_L g62 ( 
.A(n_55),
.B(n_54),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_59),
.Y(n_63)
);

AOI222xp33_ASAP7_75t_L g64 ( 
.A1(n_62),
.A2(n_55),
.B1(n_47),
.B2(n_32),
.C1(n_49),
.C2(n_39),
.Y(n_64)
);

O2A1O1Ixp33_ASAP7_75t_L g65 ( 
.A1(n_60),
.A2(n_49),
.B(n_23),
.C(n_22),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_61),
.Y(n_66)
);

NAND2xp5_ASAP7_75t_L g67 ( 
.A(n_61),
.B(n_49),
.Y(n_67)
);

AOI21xp33_ASAP7_75t_L g68 ( 
.A1(n_64),
.A2(n_34),
.B(n_39),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_66),
.Y(n_69)
);

NOR2xp33_ASAP7_75t_SL g70 ( 
.A(n_63),
.B(n_49),
.Y(n_70)
);

OA22x2_ASAP7_75t_L g71 ( 
.A1(n_63),
.A2(n_25),
.B1(n_24),
.B2(n_23),
.Y(n_71)
);

AOI221xp5_ASAP7_75t_L g72 ( 
.A1(n_65),
.A2(n_44),
.B1(n_39),
.B2(n_24),
.C(n_4),
.Y(n_72)
);

NOR3xp33_ASAP7_75t_L g73 ( 
.A(n_68),
.B(n_67),
.C(n_39),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_69),
.Y(n_74)
);

INVx2_ASAP7_75t_L g75 ( 
.A(n_71),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_70),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_72),
.Y(n_77)
);

NOR2xp67_ASAP7_75t_L g78 ( 
.A(n_75),
.B(n_5),
.Y(n_78)
);

AO22x2_ASAP7_75t_L g79 ( 
.A1(n_74),
.A2(n_14),
.B1(n_9),
.B2(n_8),
.Y(n_79)
);

NOR2xp33_ASAP7_75t_L g80 ( 
.A(n_77),
.B(n_15),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_76),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_81),
.Y(n_82)
);

AOI22xp33_ASAP7_75t_R g83 ( 
.A1(n_79),
.A2(n_44),
.B1(n_73),
.B2(n_80),
.Y(n_83)
);

AOI22xp5_ASAP7_75t_L g84 ( 
.A1(n_82),
.A2(n_78),
.B1(n_79),
.B2(n_83),
.Y(n_84)
);


endmodule