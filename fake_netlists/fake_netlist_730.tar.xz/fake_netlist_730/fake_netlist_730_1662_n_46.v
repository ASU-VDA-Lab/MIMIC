module fake_netlist_730_1662_n_46 (n_20, n_14, n_16, n_18, n_13, n_11, n_1, n_10, n_5, n_6, n_2, n_3, n_9, n_4, n_7, n_17, n_21, n_12, n_15, n_19, n_0, n_8, n_46);

input n_20;
input n_14;
input n_16;
input n_18;
input n_13;
input n_11;
input n_1;
input n_10;
input n_5;
input n_6;
input n_2;
input n_3;
input n_9;
input n_4;
input n_7;
input n_17;
input n_21;
input n_12;
input n_15;
input n_19;
input n_0;
input n_8;

output n_46;

wire n_23;
wire n_44;
wire n_22;
wire n_36;
wire n_34;
wire n_39;
wire n_45;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_43;
wire n_41;
wire n_29;
wire n_32;

INVx1_ASAP7_75t_L g22 ( 
.A(n_2),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_14),
.B(n_5),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_7),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_16),
.B(n_18),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_16),
.B(n_8),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_10),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

AOI222xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_27),
.B1(n_22),
.B2(n_29),
.C1(n_25),
.C2(n_28),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_SL g34 ( 
.A1(n_30),
.A2(n_27),
.B1(n_22),
.B2(n_24),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_31),
.B1(n_19),
.B2(n_17),
.Y(n_35)
);

AO21x2_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_1),
.B(n_0),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_20),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_20),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_37),
.Y(n_39)
);

NOR2xp33_ASAP7_75t_R g40 ( 
.A(n_38),
.B(n_21),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_38),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NAND3xp33_ASAP7_75t_SL g43 ( 
.A(n_42),
.B(n_36),
.C(n_21),
.Y(n_43)
);

NOR3xp33_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_39),
.C(n_3),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_R g45 ( 
.A1(n_43),
.A2(n_12),
.B1(n_11),
.B2(n_9),
.Y(n_45)
);

AOI22xp5_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_44),
.B1(n_15),
.B2(n_13),
.Y(n_46)
);


endmodule