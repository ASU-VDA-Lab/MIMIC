module fake_netlist_730_2531_n_50 (n_12, n_1, n_2, n_3, n_9, n_11, n_10, n_4, n_5, n_7, n_13, n_6, n_0, n_8, n_50);

input n_12;
input n_1;
input n_2;
input n_3;
input n_9;
input n_11;
input n_10;
input n_4;
input n_5;
input n_7;
input n_13;
input n_6;
input n_0;
input n_8;

output n_50;

wire n_20;
wire n_23;
wire n_46;
wire n_14;
wire n_44;
wire n_22;
wire n_36;
wire n_18;
wire n_16;
wire n_34;
wire n_39;
wire n_45;
wire n_48;
wire n_49;
wire n_28;
wire n_27;
wire n_37;
wire n_42;
wire n_24;
wire n_26;
wire n_33;
wire n_40;
wire n_31;
wire n_30;
wire n_38;
wire n_35;
wire n_25;
wire n_17;
wire n_21;
wire n_43;
wire n_15;
wire n_19;
wire n_41;
wire n_29;
wire n_47;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_10),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

BUFx3_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_5),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_12),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_6),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_23),
.Y(n_24)
);

INVx3_ASAP7_75t_SL g25 ( 
.A(n_14),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

INVx1_ASAP7_75t_SL g28 ( 
.A(n_18),
.Y(n_28)
);

A2O1A1Ixp33_ASAP7_75t_L g29 ( 
.A1(n_23),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_29)
);

A2O1A1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_20),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_30)
);

CKINVDCx16_ASAP7_75t_R g31 ( 
.A(n_28),
.Y(n_31)
);

OAI21xp33_ASAP7_75t_L g32 ( 
.A1(n_24),
.A2(n_17),
.B(n_16),
.Y(n_32)
);

AND2x4_ASAP7_75t_SL g33 ( 
.A(n_26),
.B(n_15),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_17),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_25),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_31),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_31),
.B(n_27),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_33),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AOI22x1_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_22),
.B1(n_16),
.B2(n_19),
.Y(n_41)
);

NAND4xp25_ASAP7_75t_SL g42 ( 
.A(n_39),
.B(n_30),
.C(n_29),
.D(n_35),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_R g43 ( 
.A(n_39),
.B(n_36),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_41),
.Y(n_44)
);

BUFx4f_ASAP7_75t_SL g45 ( 
.A(n_43),
.Y(n_45)
);

OR2x2_ASAP7_75t_L g46 ( 
.A(n_42),
.B(n_33),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_SL g47 ( 
.A1(n_45),
.A2(n_22),
.B1(n_29),
.B2(n_30),
.Y(n_47)
);

OAI22xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_32),
.B1(n_6),
.B2(n_4),
.Y(n_48)
);

INVxp67_ASAP7_75t_SL g49 ( 
.A(n_44),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_SL g50 ( 
.A1(n_48),
.A2(n_7),
.B1(n_49),
.B2(n_47),
.Y(n_50)
);


endmodule