module fake_netlist_826_2914_n_21 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_21);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_21;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_2),
.B(n_0),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_10),
.B(n_3),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_11),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_12),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.C(n_10),
.Y(n_18)
);

NOR3x1_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_5),
.C(n_4),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_7),
.B1(n_12),
.B2(n_15),
.Y(n_21)
);


endmodule