module fake_netlist_826_2750_n_4 (n_2, n_0, n_1, n_4);

input n_2;
input n_0;
input n_1;

output n_4;

wire n_3;

INVx3_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

AOI21xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_4)
);


endmodule