module fake_netlist_826_1079_n_21 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_21);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_21;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

INVx1_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_5),
.B(n_1),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_4),
.B(n_1),
.Y(n_14)
);

A2O1A1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_7),
.B(n_6),
.C(n_4),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_12),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_13),
.B1(n_11),
.B2(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_14),
.B2(n_2),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_9),
.B(n_8),
.Y(n_21)
);


endmodule