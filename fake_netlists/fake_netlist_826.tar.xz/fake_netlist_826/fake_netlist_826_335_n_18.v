module fake_netlist_826_335_n_18 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_18);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_18;

wire n_10;
wire n_15;
wire n_7;
wire n_13;
wire n_16;
wire n_17;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

OAI22xp5_ASAP7_75t_L g9 ( 
.A1(n_3),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_3),
.Y(n_10)
);

AO21x2_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_4),
.B(n_1),
.Y(n_11)
);

OA21x2_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_6),
.B(n_4),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_9),
.B1(n_8),
.B2(n_4),
.C(n_6),
.Y(n_14)
);

NOR2x1_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_11),
.Y(n_15)
);

AOI211xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B(n_8),
.C(n_11),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_12),
.B1(n_5),
.B2(n_6),
.Y(n_18)
);


endmodule