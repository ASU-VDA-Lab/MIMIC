module fake_netlist_826_1354_n_12 (n_2, n_0, n_1, n_12);

input n_2;
input n_0;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

O2A1O1Ixp33_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AO22x2_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B1(n_8),
.B2(n_2),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_0),
.B1(n_2),
.B2(n_9),
.Y(n_12)
);


endmodule