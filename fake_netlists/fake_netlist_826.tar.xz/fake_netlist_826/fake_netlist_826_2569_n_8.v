module fake_netlist_826_2569_n_8 (n_4, n_2, n_5, n_3, n_0, n_1, n_8);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_8;

wire n_6;
wire n_7;

AND2x4_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_5),
.Y(n_7)
);

NAND4xp25_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_1),
.C(n_4),
.D(n_6),
.Y(n_8)
);


endmodule