module fake_netlist_826_669_n_22 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_22);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_18;
wire n_16;
wire n_21;

INVx2_ASAP7_75t_SL g13 ( 
.A(n_5),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_4),
.B(n_2),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_6),
.B(n_4),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_13),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_16),
.B1(n_15),
.B2(n_17),
.Y(n_19)
);

NAND4xp25_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_7),
.C(n_16),
.D(n_0),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_8),
.B(n_1),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_7),
.B1(n_11),
.B2(n_9),
.C1(n_12),
.C2(n_10),
.Y(n_22)
);


endmodule