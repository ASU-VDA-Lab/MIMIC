module fake_netlist_826_93_n_25 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_25);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_25;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_9;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

BUFx8_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_6),
.Y(n_13)
);

OR2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_0),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_1),
.Y(n_15)
);

AOI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B1(n_9),
.B2(n_12),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_13),
.B1(n_11),
.B2(n_9),
.Y(n_17)
);

INVxp67_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OAI21xp33_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_16),
.B(n_15),
.Y(n_19)
);

AOI211xp5_ASAP7_75t_SL g20 ( 
.A1(n_19),
.A2(n_9),
.B(n_2),
.C(n_1),
.Y(n_20)
);

AOI211xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_20),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

OAI22x1_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_23),
.B1(n_8),
.B2(n_7),
.Y(n_25)
);


endmodule