module fake_netlist_826_567_n_18 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_18);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_18;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;
wire n_9;

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_1),
.A2(n_3),
.B1(n_0),
.B2(n_8),
.Y(n_9)
);

INVx4_ASAP7_75t_SL g10 ( 
.A(n_1),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_5),
.B(n_7),
.Y(n_11)
);

AO22x2_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_6),
.B1(n_2),
.B2(n_4),
.Y(n_12)
);

INVx3_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_12),
.B2(n_11),
.C(n_10),
.Y(n_14)
);

AND2x4_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

OAI211xp5_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_9),
.B(n_13),
.C(n_12),
.Y(n_16)
);

AO22x2_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_10),
.B1(n_5),
.B2(n_4),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_6),
.B(n_15),
.Y(n_18)
);


endmodule