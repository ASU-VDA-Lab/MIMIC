module fake_netlist_693_689_n_14 (n_3, n_0, n_2, n_1, n_14);

input n_3;
input n_0;
input n_2;
input n_1;

output n_14;

wire n_9;
wire n_4;
wire n_7;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx1_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_2),
.Y(n_5)
);

NOR4xp25_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_5),
.C(n_1),
.D(n_0),
.Y(n_6)
);

AOI21xp5_ASAP7_75t_SL g7 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_5),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_9),
.B(n_6),
.Y(n_11)
);

XNOR2xp5_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

OAI221xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_1),
.B1(n_2),
.B2(n_3),
.C(n_11),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B(n_3),
.Y(n_14)
);


endmodule