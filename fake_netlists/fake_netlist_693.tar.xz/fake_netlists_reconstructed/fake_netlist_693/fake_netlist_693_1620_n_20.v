module fake_netlist_693_1620_n_20 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_20);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_20;

wire n_17;
wire n_18;
wire n_15;
wire n_16;
wire n_13;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g10 ( 
.A(n_0),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

OR2x6_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_5),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NOR3xp33_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.C(n_13),
.Y(n_16)
);

NAND4xp25_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.C(n_7),
.D(n_12),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_12),
.Y(n_18)
);

XOR2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_4),
.Y(n_19)
);

OAI221xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_9),
.B2(n_6),
.C(n_8),
.Y(n_20)
);


endmodule