module fake_netlist_693_1059_n_28 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_28);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_28;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

BUFx2_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_0),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_5),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_7),
.B(n_6),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_13),
.B(n_12),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_12),
.B1(n_4),
.B2(n_2),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_19),
.Y(n_21)
);

AND2x2_ASAP7_75t_SL g22 ( 
.A(n_20),
.B(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

NOR2x1_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_21),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_14),
.B1(n_16),
.B2(n_18),
.C(n_17),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_25),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_26),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_28)
);


endmodule