module fake_netlist_693_1389_n_7 (n_0, n_2, n_1, n_7);

input n_0;
input n_2;
input n_1;

output n_7;

wire n_4;
wire n_3;
wire n_5;
wire n_6;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

AND2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

OAI21xp5_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_2),
.B(n_0),
.Y(n_6)
);

A2O1A1Ixp33_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_0),
.B(n_1),
.C(n_5),
.Y(n_7)
);


endmodule