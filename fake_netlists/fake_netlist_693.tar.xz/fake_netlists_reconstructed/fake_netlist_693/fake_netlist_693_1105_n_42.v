module fake_netlist_693_1105_n_42 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_42);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_42;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_11;
wire n_30;
wire n_19;
wire n_25;
wire n_10;
wire n_13;
wire n_39;
wire n_14;
wire n_12;

INVx2_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_0),
.B(n_2),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_4),
.B(n_5),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_8),
.Y(n_17)
);

INVx2_ASAP7_75t_SL g18 ( 
.A(n_12),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_14),
.A2(n_6),
.B1(n_5),
.B2(n_1),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_10),
.A2(n_7),
.B(n_1),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_10),
.A2(n_7),
.B(n_11),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_15),
.A2(n_17),
.B(n_12),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVx4_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_22),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_24),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_27),
.B(n_13),
.C(n_23),
.Y(n_31)
);

OAI21x1_ASAP7_75t_SL g32 ( 
.A1(n_30),
.A2(n_21),
.B(n_26),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_28),
.A2(n_25),
.B1(n_19),
.B2(n_13),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_29),
.Y(n_34)
);

AOI211xp5_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_16),
.B(n_25),
.C(n_30),
.Y(n_35)
);

NAND3xp33_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_25),
.C(n_26),
.Y(n_36)
);

CKINVDCx20_ASAP7_75t_R g37 ( 
.A(n_34),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_35),
.B(n_26),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

CKINVDCx20_ASAP7_75t_R g41 ( 
.A(n_37),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_25),
.B1(n_39),
.B2(n_40),
.Y(n_42)
);


endmodule