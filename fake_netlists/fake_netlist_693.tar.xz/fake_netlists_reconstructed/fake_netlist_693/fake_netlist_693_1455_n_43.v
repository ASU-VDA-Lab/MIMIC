module fake_netlist_693_1455_n_43 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_43);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_43;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_13;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;
wire n_14;

AND2x4_ASAP7_75t_L g13 ( 
.A(n_9),
.B(n_8),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_7),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_4),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_11),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_14),
.B(n_1),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_14),
.B(n_19),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_20),
.A2(n_18),
.B(n_16),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_23),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_23),
.Y(n_27)
);

AOI221xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_21),
.B1(n_22),
.B2(n_14),
.C(n_15),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_25),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_27),
.B1(n_21),
.B2(n_23),
.Y(n_30)
);

AOI221xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_21),
.B1(n_17),
.B2(n_23),
.C(n_19),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_SL g32 ( 
.A(n_29),
.B(n_13),
.Y(n_32)
);

AOI21xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_18),
.B(n_13),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_30),
.A2(n_13),
.B1(n_19),
.B2(n_20),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

OAI221xp5_ASAP7_75t_SL g36 ( 
.A1(n_35),
.A2(n_33),
.B1(n_34),
.B2(n_1),
.C(n_2),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVxp67_ASAP7_75t_SL g38 ( 
.A(n_35),
.Y(n_38)
);

AOI21xp5_ASAP7_75t_L g39 ( 
.A1(n_33),
.A2(n_13),
.B(n_19),
.Y(n_39)
);

OR4x1_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_37),
.C(n_39),
.D(n_38),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_19),
.Y(n_41)
);

INVxp67_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

AOI322xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_40),
.A3(n_6),
.B1(n_5),
.B2(n_3),
.C1(n_10),
.C2(n_7),
.Y(n_43)
);


endmodule