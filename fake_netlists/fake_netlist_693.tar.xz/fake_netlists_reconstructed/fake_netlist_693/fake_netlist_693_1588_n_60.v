module fake_netlist_693_1588_n_60 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_60);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_60;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_20;
wire n_58;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_23;
wire n_41;
wire n_46;
wire n_29;
wire n_56;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_19;
wire n_39;
wire n_55;

INVx1_ASAP7_75t_L g19 ( 
.A(n_3),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_5),
.B(n_6),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_11),
.Y(n_21)
);

AND2x6_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_0),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_15),
.B(n_13),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_10),
.A2(n_7),
.B1(n_16),
.B2(n_8),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_4),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_14),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_18),
.B(n_2),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_22),
.A2(n_16),
.B1(n_5),
.B2(n_1),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_24),
.A2(n_18),
.B1(n_1),
.B2(n_9),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_26),
.Y(n_33)
);

BUFx8_ASAP7_75t_L g34 ( 
.A(n_22),
.Y(n_34)
);

OAI21x1_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_25),
.B(n_20),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_25),
.B(n_27),
.Y(n_36)
);

NAND2x1p5_ASAP7_75t_L g37 ( 
.A(n_30),
.B(n_27),
.Y(n_37)
);

INVx4_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

INVxp67_ASAP7_75t_SL g39 ( 
.A(n_37),
.Y(n_39)
);

AND2x4_ASAP7_75t_SL g40 ( 
.A(n_36),
.B(n_29),
.Y(n_40)
);

OR2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_36),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_35),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

OAI22xp33_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_38),
.B1(n_29),
.B2(n_32),
.Y(n_45)
);

AOI33xp33_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_32),
.A3(n_21),
.B1(n_23),
.B2(n_38),
.B3(n_29),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_43),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_34),
.Y(n_49)
);

INVx1_ASAP7_75t_SL g50 ( 
.A(n_45),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

INVxp67_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

AOI311xp33_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_22),
.A3(n_34),
.B(n_26),
.C(n_23),
.Y(n_53)
);

CKINVDCx16_ASAP7_75t_R g54 ( 
.A(n_50),
.Y(n_54)
);

AND2x4_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_12),
.Y(n_55)
);

XNOR2x1_ASAP7_75t_L g56 ( 
.A(n_54),
.B(n_22),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

AOI22xp5_ASAP7_75t_SL g58 ( 
.A1(n_57),
.A2(n_52),
.B1(n_22),
.B2(n_53),
.Y(n_58)
);

HB1xp67_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

AOI22xp33_ASAP7_75t_SL g60 ( 
.A1(n_58),
.A2(n_59),
.B1(n_56),
.B2(n_55),
.Y(n_60)
);


endmodule