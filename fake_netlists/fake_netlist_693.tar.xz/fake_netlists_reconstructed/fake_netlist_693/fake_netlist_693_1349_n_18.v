module fake_netlist_693_1349_n_18 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_18);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_9;
wire n_17;
wire n_7;
wire n_14;
wire n_15;
wire n_11;
wire n_13;
wire n_16;
wire n_8;
wire n_10;
wire n_12;

CKINVDCx5p33_ASAP7_75t_R g7 ( 
.A(n_3),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_0),
.Y(n_8)
);

NAND3xp33_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_2),
.C(n_5),
.Y(n_9)
);

NOR3xp33_ASAP7_75t_SL g10 ( 
.A(n_9),
.B(n_6),
.C(n_1),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_1),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_SL g12 ( 
.A1(n_10),
.A2(n_9),
.B(n_6),
.C(n_1),
.Y(n_12)
);

INVx4_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

NAND2x1_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B1(n_11),
.B2(n_8),
.C(n_6),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_4),
.C(n_2),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_16),
.B1(n_5),
.B2(n_4),
.Y(n_18)
);


endmodule