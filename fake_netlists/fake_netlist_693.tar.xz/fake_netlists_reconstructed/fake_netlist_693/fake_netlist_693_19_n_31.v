module fake_netlist_693_19_n_31 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_31);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_31;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_29;
wire n_28;
wire n_19;
wire n_30;
wire n_25;
wire n_14;

BUFx3_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_8),
.B(n_11),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_13),
.B(n_3),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_10),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_16),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_22)
);

OAI21x1_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_21),
.B(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AND2x4_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_18),
.Y(n_25)
);

AND2x2_ASAP7_75t_SL g26 ( 
.A(n_25),
.B(n_24),
.Y(n_26)
);

NOR2x1_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_14),
.Y(n_27)
);

AOI21xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_27),
.B(n_22),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OAI22xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_19),
.B1(n_18),
.B2(n_15),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_9),
.B1(n_7),
.B2(n_5),
.Y(n_31)
);


endmodule