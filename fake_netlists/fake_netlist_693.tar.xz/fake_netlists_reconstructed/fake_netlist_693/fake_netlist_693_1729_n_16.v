module fake_netlist_693_1729_n_16 (n_3, n_0, n_2, n_1, n_16);

input n_3;
input n_0;
input n_2;
input n_1;

output n_16;

wire n_9;
wire n_4;
wire n_7;
wire n_15;
wire n_14;
wire n_11;
wire n_12;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_13;

INVx1_ASAP7_75t_SL g4 ( 
.A(n_1),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

CKINVDCx11_ASAP7_75t_R g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NOR3xp33_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_7),
.C(n_4),
.Y(n_12)
);

INVx1_ASAP7_75t_SL g13 ( 
.A(n_11),
.Y(n_13)
);

AOI22x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B1(n_5),
.B2(n_6),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_3),
.B(n_2),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_1),
.B1(n_13),
.B2(n_14),
.Y(n_16)
);


endmodule