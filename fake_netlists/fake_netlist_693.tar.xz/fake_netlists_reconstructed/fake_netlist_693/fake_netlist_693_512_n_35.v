module fake_netlist_693_512_n_35 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_35);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_35;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_34;
wire n_16;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

INVx3_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_1),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_SL g23 ( 
.A(n_20),
.B(n_5),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_7),
.B1(n_3),
.B2(n_2),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_21),
.B1(n_20),
.B2(n_16),
.Y(n_25)
);

OAI21xp33_ASAP7_75t_SL g26 ( 
.A1(n_23),
.A2(n_18),
.B(n_16),
.Y(n_26)
);

AO21x2_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_24),
.B(n_17),
.Y(n_27)
);

AOI222xp33_ASAP7_75t_SL g28 ( 
.A1(n_27),
.A2(n_16),
.B1(n_17),
.B2(n_7),
.C1(n_26),
.C2(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AO22x2_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_27),
.B1(n_19),
.B2(n_9),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_30),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_31),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_32),
.Y(n_34)
);

AOI322xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_31),
.A3(n_13),
.B1(n_12),
.B2(n_10),
.C1(n_15),
.C2(n_14),
.Y(n_35)
);


endmodule