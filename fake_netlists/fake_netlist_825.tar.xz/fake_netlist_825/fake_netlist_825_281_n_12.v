module fake_netlist_825_281_n_12 (n_4, n_2, n_5, n_3, n_0, n_1, n_12);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_7;
wire n_9;
wire n_11;
wire n_8;

NAND3xp33_ASAP7_75t_SL g6 ( 
.A(n_4),
.B(n_0),
.C(n_3),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_7),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);

CKINVDCx16_ASAP7_75t_R g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule