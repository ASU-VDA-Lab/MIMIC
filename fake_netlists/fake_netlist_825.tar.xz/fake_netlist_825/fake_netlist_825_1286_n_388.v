module fake_netlist_825_1286_n_388 (n_48, n_49, n_25, n_20, n_15, n_13, n_2, n_36, n_47, n_17, n_14, n_50, n_22, n_41, n_4, n_7, n_23, n_34, n_40, n_28, n_39, n_44, n_9, n_31, n_32, n_26, n_24, n_43, n_37, n_19, n_42, n_3, n_33, n_12, n_0, n_29, n_6, n_30, n_18, n_10, n_16, n_21, n_5, n_35, n_38, n_11, n_27, n_1, n_45, n_8, n_46, n_388);

input n_48;
input n_49;
input n_25;
input n_20;
input n_15;
input n_13;
input n_2;
input n_36;
input n_47;
input n_17;
input n_14;
input n_50;
input n_22;
input n_41;
input n_4;
input n_7;
input n_23;
input n_34;
input n_40;
input n_28;
input n_39;
input n_44;
input n_9;
input n_31;
input n_32;
input n_26;
input n_24;
input n_43;
input n_37;
input n_19;
input n_42;
input n_3;
input n_33;
input n_12;
input n_0;
input n_29;
input n_6;
input n_30;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_35;
input n_38;
input n_11;
input n_27;
input n_1;
input n_45;
input n_8;
input n_46;

output n_388;

wire n_298;
wire n_364;
wire n_114;
wire n_261;
wire n_316;
wire n_166;
wire n_240;
wire n_326;
wire n_154;
wire n_340;
wire n_153;
wire n_195;
wire n_210;
wire n_87;
wire n_95;
wire n_325;
wire n_232;
wire n_63;
wire n_110;
wire n_265;
wire n_61;
wire n_108;
wire n_163;
wire n_209;
wire n_196;
wire n_353;
wire n_294;
wire n_202;
wire n_90;
wire n_76;
wire n_299;
wire n_272;
wire n_160;
wire n_338;
wire n_329;
wire n_99;
wire n_366;
wire n_349;
wire n_155;
wire n_361;
wire n_314;
wire n_357;
wire n_52;
wire n_379;
wire n_229;
wire n_51;
wire n_382;
wire n_119;
wire n_312;
wire n_152;
wire n_131;
wire n_133;
wire n_274;
wire n_323;
wire n_223;
wire n_279;
wire n_84;
wire n_303;
wire n_270;
wire n_188;
wire n_343;
wire n_205;
wire n_65;
wire n_247;
wire n_300;
wire n_387;
wire n_309;
wire n_378;
wire n_281;
wire n_359;
wire n_365;
wire n_129;
wire n_198;
wire n_201;
wire n_169;
wire n_180;
wire n_220;
wire n_267;
wire n_370;
wire n_208;
wire n_82;
wire n_234;
wire n_165;
wire n_374;
wire n_141;
wire n_305;
wire n_280;
wire n_331;
wire n_221;
wire n_311;
wire n_293;
wire n_156;
wire n_347;
wire n_126;
wire n_296;
wire n_78;
wire n_187;
wire n_96;
wire n_94;
wire n_162;
wire n_135;
wire n_324;
wire n_275;
wire n_362;
wire n_369;
wire n_107;
wire n_301;
wire n_288;
wire n_384;
wire n_178;
wire n_121;
wire n_73;
wire n_211;
wire n_235;
wire n_371;
wire n_246;
wire n_344;
wire n_175;
wire n_185;
wire n_161;
wire n_224;
wire n_179;
wire n_137;
wire n_57;
wire n_226;
wire n_116;
wire n_284;
wire n_128;
wire n_139;
wire n_115;
wire n_339;
wire n_144;
wire n_328;
wire n_283;
wire n_183;
wire n_367;
wire n_345;
wire n_106;
wire n_149;
wire n_237;
wire n_373;
wire n_159;
wire n_91;
wire n_233;
wire n_333;
wire n_204;
wire n_191;
wire n_317;
wire n_181;
wire n_60;
wire n_356;
wire n_260;
wire n_372;
wire n_291;
wire n_186;
wire n_218;
wire n_69;
wire n_212;
wire n_241;
wire n_256;
wire n_134;
wire n_254;
wire n_148;
wire n_245;
wire n_376;
wire n_193;
wire n_132;
wire n_194;
wire n_219;
wire n_250;
wire n_81;
wire n_273;
wire n_80;
wire n_123;
wire n_290;
wire n_319;
wire n_167;
wire n_122;
wire n_289;
wire n_56;
wire n_59;
wire n_74;
wire n_341;
wire n_79;
wire n_177;
wire n_244;
wire n_158;
wire n_171;
wire n_259;
wire n_214;
wire n_127;
wire n_295;
wire n_213;
wire n_257;
wire n_72;
wire n_266;
wire n_320;
wire n_249;
wire n_120;
wire n_327;
wire n_145;
wire n_307;
wire n_200;
wire n_377;
wire n_170;
wire n_77;
wire n_383;
wire n_138;
wire n_217;
wire n_253;
wire n_238;
wire n_381;
wire n_322;
wire n_332;
wire n_62;
wire n_117;
wire n_351;
wire n_104;
wire n_354;
wire n_168;
wire n_360;
wire n_350;
wire n_285;
wire n_310;
wire n_176;
wire n_271;
wire n_330;
wire n_101;
wire n_336;
wire n_242;
wire n_313;
wire n_157;
wire n_83;
wire n_375;
wire n_348;
wire n_334;
wire n_346;
wire n_216;
wire n_150;
wire n_71;
wire n_92;
wire n_100;
wire n_124;
wire n_236;
wire n_206;
wire n_147;
wire n_363;
wire n_268;
wire n_380;
wire n_97;
wire n_182;
wire n_335;
wire n_130;
wire n_239;
wire n_173;
wire n_287;
wire n_318;
wire n_222;
wire n_277;
wire n_263;
wire n_269;
wire n_54;
wire n_304;
wire n_64;
wire n_278;
wire n_264;
wire n_297;
wire n_292;
wire n_184;
wire n_86;
wire n_192;
wire n_230;
wire n_118;
wire n_189;
wire n_125;
wire n_255;
wire n_151;
wire n_302;
wire n_258;
wire n_207;
wire n_385;
wire n_103;
wire n_227;
wire n_215;
wire n_199;
wire n_143;
wire n_190;
wire n_251;
wire n_352;
wire n_136;
wire n_102;
wire n_89;
wire n_262;
wire n_70;
wire n_172;
wire n_142;
wire n_337;
wire n_109;
wire n_53;
wire n_315;
wire n_58;
wire n_68;
wire n_146;
wire n_248;
wire n_105;
wire n_306;
wire n_321;
wire n_355;
wire n_225;
wire n_358;
wire n_85;
wire n_55;
wire n_164;
wire n_252;
wire n_75;
wire n_140;
wire n_342;
wire n_67;
wire n_66;
wire n_98;
wire n_386;
wire n_286;
wire n_203;
wire n_112;
wire n_228;
wire n_111;
wire n_93;
wire n_174;
wire n_197;
wire n_88;
wire n_243;
wire n_276;
wire n_113;
wire n_282;
wire n_231;
wire n_368;
wire n_308;

INVx1_ASAP7_75t_L g51 ( 
.A(n_35),
.Y(n_51)
);

CKINVDCx5p33_ASAP7_75t_R g52 ( 
.A(n_7),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_1),
.Y(n_53)
);

CKINVDCx16_ASAP7_75t_R g54 ( 
.A(n_1),
.Y(n_54)
);

CKINVDCx20_ASAP7_75t_R g55 ( 
.A(n_7),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_28),
.Y(n_56)
);

INVx2_ASAP7_75t_L g57 ( 
.A(n_38),
.Y(n_57)
);

NOR2xp67_ASAP7_75t_L g58 ( 
.A(n_8),
.B(n_4),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_49),
.Y(n_59)
);

CKINVDCx5p33_ASAP7_75t_R g60 ( 
.A(n_42),
.Y(n_60)
);

CKINVDCx5p33_ASAP7_75t_R g61 ( 
.A(n_14),
.Y(n_61)
);

BUFx8_ASAP7_75t_SL g62 ( 
.A(n_6),
.Y(n_62)
);

CKINVDCx5p33_ASAP7_75t_R g63 ( 
.A(n_17),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_44),
.Y(n_64)
);

CKINVDCx5p33_ASAP7_75t_R g65 ( 
.A(n_22),
.Y(n_65)
);

INVxp33_ASAP7_75t_L g66 ( 
.A(n_33),
.Y(n_66)
);

CKINVDCx20_ASAP7_75t_R g67 ( 
.A(n_37),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_0),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_41),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_31),
.Y(n_70)
);

CKINVDCx16_ASAP7_75t_R g71 ( 
.A(n_47),
.Y(n_71)
);

INVx3_ASAP7_75t_L g72 ( 
.A(n_57),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_57),
.Y(n_73)
);

CKINVDCx5p33_ASAP7_75t_R g74 ( 
.A(n_62),
.Y(n_74)
);

BUFx6f_ASAP7_75t_L g75 ( 
.A(n_51),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_51),
.B(n_0),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_68),
.Y(n_77)
);

BUFx6f_ASAP7_75t_L g78 ( 
.A(n_56),
.Y(n_78)
);

BUFx8_ASAP7_75t_L g79 ( 
.A(n_56),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_68),
.Y(n_80)
);

INVx3_ASAP7_75t_L g81 ( 
.A(n_59),
.Y(n_81)
);

INVx2_ASAP7_75t_L g82 ( 
.A(n_75),
.Y(n_82)
);

INVx1_ASAP7_75t_SL g83 ( 
.A(n_74),
.Y(n_83)
);

INVx1_ASAP7_75t_L g84 ( 
.A(n_77),
.Y(n_84)
);

INVx2_ASAP7_75t_SL g85 ( 
.A(n_79),
.Y(n_85)
);

INVx2_ASAP7_75t_L g86 ( 
.A(n_75),
.Y(n_86)
);

INVx1_ASAP7_75t_L g87 ( 
.A(n_77),
.Y(n_87)
);

BUFx3_ASAP7_75t_L g88 ( 
.A(n_75),
.Y(n_88)
);

INVx1_ASAP7_75t_L g89 ( 
.A(n_80),
.Y(n_89)
);

BUFx3_ASAP7_75t_L g90 ( 
.A(n_75),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_80),
.Y(n_91)
);

AND2x4_ASAP7_75t_L g92 ( 
.A(n_72),
.B(n_81),
.Y(n_92)
);

NOR2xp33_ASAP7_75t_L g93 ( 
.A(n_76),
.B(n_66),
.Y(n_93)
);

INVx1_ASAP7_75t_L g94 ( 
.A(n_73),
.Y(n_94)
);

INVx1_ASAP7_75t_L g95 ( 
.A(n_73),
.Y(n_95)
);

NAND3x1_ASAP7_75t_L g96 ( 
.A(n_76),
.B(n_64),
.C(n_59),
.Y(n_96)
);

INVx3_ASAP7_75t_L g97 ( 
.A(n_75),
.Y(n_97)
);

AOI22xp5_ASAP7_75t_L g98 ( 
.A1(n_93),
.A2(n_54),
.B1(n_55),
.B2(n_67),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_97),
.B(n_79),
.Y(n_99)
);

INVx1_ASAP7_75t_L g100 ( 
.A(n_84),
.Y(n_100)
);

AOI22xp33_ASAP7_75t_L g101 ( 
.A1(n_84),
.A2(n_79),
.B1(n_81),
.B2(n_72),
.Y(n_101)
);

INVx2_ASAP7_75t_L g102 ( 
.A(n_94),
.Y(n_102)
);

NAND2xp5_ASAP7_75t_L g103 ( 
.A(n_97),
.B(n_79),
.Y(n_103)
);

BUFx8_ASAP7_75t_L g104 ( 
.A(n_87),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_97),
.B(n_79),
.Y(n_105)
);

INVx2_ASAP7_75t_L g106 ( 
.A(n_94),
.Y(n_106)
);

A2O1A1Ixp33_ASAP7_75t_L g107 ( 
.A1(n_92),
.A2(n_81),
.B(n_72),
.C(n_73),
.Y(n_107)
);

AOI22xp33_ASAP7_75t_L g108 ( 
.A1(n_87),
.A2(n_79),
.B1(n_81),
.B2(n_72),
.Y(n_108)
);

NAND2xp5_ASAP7_75t_L g109 ( 
.A(n_97),
.B(n_81),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_89),
.Y(n_110)
);

INVx4_ASAP7_75t_L g111 ( 
.A(n_92),
.Y(n_111)
);

NOR3xp33_ASAP7_75t_SL g112 ( 
.A(n_89),
.B(n_54),
.C(n_52),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_91),
.Y(n_113)
);

NAND2x1p5_ASAP7_75t_L g114 ( 
.A(n_85),
.B(n_64),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_91),
.Y(n_115)
);

NAND2xp5_ASAP7_75t_SL g116 ( 
.A(n_83),
.B(n_71),
.Y(n_116)
);

NAND2xp5_ASAP7_75t_L g117 ( 
.A(n_88),
.B(n_72),
.Y(n_117)
);

AND2x4_ASAP7_75t_L g118 ( 
.A(n_92),
.B(n_69),
.Y(n_118)
);

BUFx6f_ASAP7_75t_SL g119 ( 
.A(n_118),
.Y(n_119)
);

NAND2xp5_ASAP7_75t_SL g120 ( 
.A(n_116),
.B(n_71),
.Y(n_120)
);

INVx2_ASAP7_75t_L g121 ( 
.A(n_102),
.Y(n_121)
);

AOI222xp33_ASAP7_75t_L g122 ( 
.A1(n_104),
.A2(n_58),
.B1(n_61),
.B2(n_53),
.C1(n_83),
.C2(n_69),
.Y(n_122)
);

INVx2_ASAP7_75t_L g123 ( 
.A(n_102),
.Y(n_123)
);

O2A1O1Ixp33_ASAP7_75t_L g124 ( 
.A1(n_100),
.A2(n_95),
.B(n_70),
.C(n_82),
.Y(n_124)
);

INVx2_ASAP7_75t_L g125 ( 
.A(n_106),
.Y(n_125)
);

INVx1_ASAP7_75t_L g126 ( 
.A(n_100),
.Y(n_126)
);

NAND2xp5_ASAP7_75t_L g127 ( 
.A(n_110),
.B(n_92),
.Y(n_127)
);

BUFx2_ASAP7_75t_L g128 ( 
.A(n_112),
.Y(n_128)
);

INVx1_ASAP7_75t_L g129 ( 
.A(n_110),
.Y(n_129)
);

BUFx2_ASAP7_75t_L g130 ( 
.A(n_104),
.Y(n_130)
);

HB1xp67_ASAP7_75t_L g131 ( 
.A(n_118),
.Y(n_131)
);

A2O1A1Ixp33_ASAP7_75t_L g132 ( 
.A1(n_118),
.A2(n_70),
.B(n_58),
.C(n_92),
.Y(n_132)
);

CKINVDCx5p33_ASAP7_75t_R g133 ( 
.A(n_104),
.Y(n_133)
);

INVxp67_ASAP7_75t_SL g134 ( 
.A(n_117),
.Y(n_134)
);

NOR2xp33_ASAP7_75t_L g135 ( 
.A(n_111),
.B(n_74),
.Y(n_135)
);

NAND2xp5_ASAP7_75t_L g136 ( 
.A(n_113),
.B(n_88),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_121),
.Y(n_137)
);

INVx2_ASAP7_75t_SL g138 ( 
.A(n_131),
.Y(n_138)
);

OA21x2_ASAP7_75t_L g139 ( 
.A1(n_132),
.A2(n_107),
.B(n_109),
.Y(n_139)
);

INVx2_ASAP7_75t_L g140 ( 
.A(n_121),
.Y(n_140)
);

AOI21xp5_ASAP7_75t_L g141 ( 
.A1(n_127),
.A2(n_111),
.B(n_105),
.Y(n_141)
);

BUFx3_ASAP7_75t_L g142 ( 
.A(n_126),
.Y(n_142)
);

OAI21x1_ASAP7_75t_L g143 ( 
.A1(n_136),
.A2(n_114),
.B(n_99),
.Y(n_143)
);

NAND2xp5_ASAP7_75t_L g144 ( 
.A(n_126),
.B(n_106),
.Y(n_144)
);

OR2x2_ASAP7_75t_L g145 ( 
.A(n_120),
.B(n_98),
.Y(n_145)
);

OAI21x1_ASAP7_75t_L g146 ( 
.A1(n_121),
.A2(n_114),
.B(n_103),
.Y(n_146)
);

AOI22xp33_ASAP7_75t_L g147 ( 
.A1(n_129),
.A2(n_98),
.B1(n_115),
.B2(n_113),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_123),
.Y(n_148)
);

AOI22xp33_ASAP7_75t_SL g149 ( 
.A1(n_145),
.A2(n_128),
.B1(n_130),
.B2(n_138),
.Y(n_149)
);

NAND3xp33_ASAP7_75t_L g150 ( 
.A(n_145),
.B(n_122),
.C(n_135),
.Y(n_150)
);

OAI22xp5_ASAP7_75t_L g151 ( 
.A1(n_142),
.A2(n_129),
.B1(n_134),
.B2(n_114),
.Y(n_151)
);

AND2x2_ASAP7_75t_L g152 ( 
.A(n_145),
.B(n_128),
.Y(n_152)
);

BUFx2_ASAP7_75t_SL g153 ( 
.A(n_138),
.Y(n_153)
);

OAI21xp5_ASAP7_75t_L g154 ( 
.A1(n_141),
.A2(n_144),
.B(n_137),
.Y(n_154)
);

AOI221xp5_ASAP7_75t_L g155 ( 
.A1(n_147),
.A2(n_115),
.B1(n_108),
.B2(n_101),
.C(n_95),
.Y(n_155)
);

AOI21xp33_ASAP7_75t_L g156 ( 
.A1(n_138),
.A2(n_111),
.B(n_125),
.Y(n_156)
);

AND2x4_ASAP7_75t_L g157 ( 
.A(n_142),
.B(n_130),
.Y(n_157)
);

OAI21xp33_ASAP7_75t_L g158 ( 
.A1(n_147),
.A2(n_133),
.B(n_125),
.Y(n_158)
);

AND2x2_ASAP7_75t_L g159 ( 
.A(n_142),
.B(n_133),
.Y(n_159)
);

AOI21xp5_ASAP7_75t_L g160 ( 
.A1(n_141),
.A2(n_123),
.B(n_85),
.Y(n_160)
);

HB1xp67_ASAP7_75t_L g161 ( 
.A(n_157),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_154),
.Y(n_162)
);

AND2x2_ASAP7_75t_L g163 ( 
.A(n_152),
.B(n_142),
.Y(n_163)
);

AND2x2_ASAP7_75t_L g164 ( 
.A(n_159),
.B(n_144),
.Y(n_164)
);

INVx1_ASAP7_75t_L g165 ( 
.A(n_153),
.Y(n_165)
);

INVx2_ASAP7_75t_SL g166 ( 
.A(n_157),
.Y(n_166)
);

NOR2xp33_ASAP7_75t_L g167 ( 
.A(n_150),
.B(n_137),
.Y(n_167)
);

AND2x2_ASAP7_75t_L g168 ( 
.A(n_149),
.B(n_137),
.Y(n_168)
);

OR2x2_ASAP7_75t_L g169 ( 
.A(n_158),
.B(n_148),
.Y(n_169)
);

AND2x2_ASAP7_75t_L g170 ( 
.A(n_155),
.B(n_148),
.Y(n_170)
);

BUFx2_ASAP7_75t_L g171 ( 
.A(n_151),
.Y(n_171)
);

AND2x2_ASAP7_75t_L g172 ( 
.A(n_155),
.B(n_148),
.Y(n_172)
);

INVx1_ASAP7_75t_L g173 ( 
.A(n_160),
.Y(n_173)
);

INVx2_ASAP7_75t_L g174 ( 
.A(n_160),
.Y(n_174)
);

AND2x2_ASAP7_75t_L g175 ( 
.A(n_156),
.B(n_140),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_154),
.Y(n_176)
);

NAND2xp5_ASAP7_75t_L g177 ( 
.A(n_152),
.B(n_140),
.Y(n_177)
);

OAI33xp33_ASAP7_75t_L g178 ( 
.A1(n_177),
.A2(n_65),
.A3(n_63),
.B1(n_60),
.B2(n_96),
.B3(n_123),
.Y(n_178)
);

INVx4_ASAP7_75t_L g179 ( 
.A(n_164),
.Y(n_179)
);

AOI22xp33_ASAP7_75t_L g180 ( 
.A1(n_167),
.A2(n_119),
.B1(n_139),
.B2(n_140),
.Y(n_180)
);

AND2x2_ASAP7_75t_L g181 ( 
.A(n_164),
.B(n_139),
.Y(n_181)
);

BUFx3_ASAP7_75t_L g182 ( 
.A(n_163),
.Y(n_182)
);

INVx1_ASAP7_75t_L g183 ( 
.A(n_173),
.Y(n_183)
);

INVx1_ASAP7_75t_L g184 ( 
.A(n_173),
.Y(n_184)
);

INVx2_ASAP7_75t_L g185 ( 
.A(n_174),
.Y(n_185)
);

INVx1_ASAP7_75t_L g186 ( 
.A(n_162),
.Y(n_186)
);

OAI22xp5_ASAP7_75t_L g187 ( 
.A1(n_165),
.A2(n_119),
.B1(n_140),
.B2(n_96),
.Y(n_187)
);

INVx1_ASAP7_75t_L g188 ( 
.A(n_162),
.Y(n_188)
);

AND2x2_ASAP7_75t_L g189 ( 
.A(n_163),
.B(n_139),
.Y(n_189)
);

NAND4xp25_ASAP7_75t_SL g190 ( 
.A(n_165),
.B(n_96),
.C(n_3),
.D(n_2),
.Y(n_190)
);

AND2x4_ASAP7_75t_L g191 ( 
.A(n_166),
.B(n_161),
.Y(n_191)
);

HB1xp67_ASAP7_75t_L g192 ( 
.A(n_161),
.Y(n_192)
);

OR2x2_ASAP7_75t_L g193 ( 
.A(n_176),
.B(n_139),
.Y(n_193)
);

OR2x2_ASAP7_75t_L g194 ( 
.A(n_176),
.B(n_139),
.Y(n_194)
);

AND2x2_ASAP7_75t_L g195 ( 
.A(n_168),
.B(n_167),
.Y(n_195)
);

INVx2_ASAP7_75t_L g196 ( 
.A(n_174),
.Y(n_196)
);

OR2x2_ASAP7_75t_L g197 ( 
.A(n_169),
.B(n_139),
.Y(n_197)
);

HB1xp67_ASAP7_75t_L g198 ( 
.A(n_166),
.Y(n_198)
);

AND2x2_ASAP7_75t_L g199 ( 
.A(n_168),
.B(n_143),
.Y(n_199)
);

AND2x2_ASAP7_75t_L g200 ( 
.A(n_177),
.B(n_143),
.Y(n_200)
);

OAI22xp5_ASAP7_75t_L g201 ( 
.A1(n_171),
.A2(n_119),
.B1(n_85),
.B2(n_75),
.Y(n_201)
);

INVx2_ASAP7_75t_L g202 ( 
.A(n_174),
.Y(n_202)
);

INVx2_ASAP7_75t_L g203 ( 
.A(n_169),
.Y(n_203)
);

HB1xp67_ASAP7_75t_L g204 ( 
.A(n_166),
.Y(n_204)
);

INVx2_ASAP7_75t_L g205 ( 
.A(n_170),
.Y(n_205)
);

AND2x2_ASAP7_75t_L g206 ( 
.A(n_195),
.B(n_170),
.Y(n_206)
);

INVx1_ASAP7_75t_L g207 ( 
.A(n_183),
.Y(n_207)
);

INVx1_ASAP7_75t_L g208 ( 
.A(n_203),
.Y(n_208)
);

OR2x2_ASAP7_75t_L g209 ( 
.A(n_203),
.B(n_171),
.Y(n_209)
);

INVx1_ASAP7_75t_L g210 ( 
.A(n_203),
.Y(n_210)
);

OR2x2_ASAP7_75t_L g211 ( 
.A(n_199),
.B(n_175),
.Y(n_211)
);

HB1xp67_ASAP7_75t_L g212 ( 
.A(n_192),
.Y(n_212)
);

AOI211xp5_ASAP7_75t_L g213 ( 
.A1(n_190),
.A2(n_172),
.B(n_78),
.C(n_75),
.Y(n_213)
);

INVx1_ASAP7_75t_L g214 ( 
.A(n_186),
.Y(n_214)
);

NAND2xp5_ASAP7_75t_L g215 ( 
.A(n_195),
.B(n_172),
.Y(n_215)
);

INVx1_ASAP7_75t_L g216 ( 
.A(n_186),
.Y(n_216)
);

AND2x2_ASAP7_75t_L g217 ( 
.A(n_199),
.B(n_175),
.Y(n_217)
);

HB1xp67_ASAP7_75t_L g218 ( 
.A(n_182),
.Y(n_218)
);

AND2x2_ASAP7_75t_L g219 ( 
.A(n_189),
.B(n_143),
.Y(n_219)
);

OR2x2_ASAP7_75t_L g220 ( 
.A(n_197),
.B(n_143),
.Y(n_220)
);

INVx1_ASAP7_75t_L g221 ( 
.A(n_188),
.Y(n_221)
);

OR2x2_ASAP7_75t_L g222 ( 
.A(n_197),
.B(n_146),
.Y(n_222)
);

AND2x4_ASAP7_75t_L g223 ( 
.A(n_191),
.B(n_146),
.Y(n_223)
);

INVx1_ASAP7_75t_L g224 ( 
.A(n_188),
.Y(n_224)
);

AND2x2_ASAP7_75t_L g225 ( 
.A(n_189),
.B(n_146),
.Y(n_225)
);

INVx1_ASAP7_75t_L g226 ( 
.A(n_183),
.Y(n_226)
);

INVxp33_ASAP7_75t_L g227 ( 
.A(n_191),
.Y(n_227)
);

AND2x2_ASAP7_75t_L g228 ( 
.A(n_205),
.B(n_75),
.Y(n_228)
);

NAND2xp5_ASAP7_75t_SL g229 ( 
.A(n_179),
.B(n_78),
.Y(n_229)
);

AND2x4_ASAP7_75t_SL g230 ( 
.A(n_179),
.B(n_82),
.Y(n_230)
);

INVx1_ASAP7_75t_L g231 ( 
.A(n_184),
.Y(n_231)
);

OR2x2_ASAP7_75t_L g232 ( 
.A(n_200),
.B(n_78),
.Y(n_232)
);

NAND2xp5_ASAP7_75t_L g233 ( 
.A(n_205),
.B(n_182),
.Y(n_233)
);

OR2x2_ASAP7_75t_L g234 ( 
.A(n_200),
.B(n_78),
.Y(n_234)
);

HB1xp67_ASAP7_75t_L g235 ( 
.A(n_182),
.Y(n_235)
);

INVx4_ASAP7_75t_L g236 ( 
.A(n_191),
.Y(n_236)
);

INVx1_ASAP7_75t_L g237 ( 
.A(n_184),
.Y(n_237)
);

INVx1_ASAP7_75t_L g238 ( 
.A(n_205),
.Y(n_238)
);

INVx1_ASAP7_75t_SL g239 ( 
.A(n_191),
.Y(n_239)
);

CKINVDCx5p33_ASAP7_75t_R g240 ( 
.A(n_198),
.Y(n_240)
);

AND2x2_ASAP7_75t_L g241 ( 
.A(n_181),
.B(n_78),
.Y(n_241)
);

AND2x2_ASAP7_75t_L g242 ( 
.A(n_181),
.B(n_179),
.Y(n_242)
);

INVx2_ASAP7_75t_L g243 ( 
.A(n_185),
.Y(n_243)
);

INVx1_ASAP7_75t_L g244 ( 
.A(n_185),
.Y(n_244)
);

AND2x4_ASAP7_75t_L g245 ( 
.A(n_179),
.B(n_15),
.Y(n_245)
);

AND2x2_ASAP7_75t_L g246 ( 
.A(n_194),
.B(n_78),
.Y(n_246)
);

NAND2xp5_ASAP7_75t_SL g247 ( 
.A(n_213),
.B(n_204),
.Y(n_247)
);

NAND2xp5_ASAP7_75t_L g248 ( 
.A(n_212),
.B(n_185),
.Y(n_248)
);

INVx2_ASAP7_75t_L g249 ( 
.A(n_207),
.Y(n_249)
);

NAND2xp5_ASAP7_75t_L g250 ( 
.A(n_206),
.B(n_215),
.Y(n_250)
);

AOI21xp5_ASAP7_75t_L g251 ( 
.A1(n_229),
.A2(n_201),
.B(n_196),
.Y(n_251)
);

INVx2_ASAP7_75t_L g252 ( 
.A(n_207),
.Y(n_252)
);

AOI21xp33_ASAP7_75t_SL g253 ( 
.A1(n_240),
.A2(n_187),
.B(n_2),
.Y(n_253)
);

NOR2xp33_ASAP7_75t_L g254 ( 
.A(n_240),
.B(n_178),
.Y(n_254)
);

INVx1_ASAP7_75t_L g255 ( 
.A(n_214),
.Y(n_255)
);

NOR2xp33_ASAP7_75t_L g256 ( 
.A(n_227),
.B(n_194),
.Y(n_256)
);

INVx1_ASAP7_75t_L g257 ( 
.A(n_216),
.Y(n_257)
);

INVxp67_ASAP7_75t_L g258 ( 
.A(n_218),
.Y(n_258)
);

OR2x2_ASAP7_75t_L g259 ( 
.A(n_211),
.B(n_193),
.Y(n_259)
);

AND2x2_ASAP7_75t_L g260 ( 
.A(n_217),
.B(n_211),
.Y(n_260)
);

AND2x2_ASAP7_75t_L g261 ( 
.A(n_217),
.B(n_193),
.Y(n_261)
);

NAND2xp5_ASAP7_75t_L g262 ( 
.A(n_206),
.B(n_196),
.Y(n_262)
);

INVx1_ASAP7_75t_L g263 ( 
.A(n_221),
.Y(n_263)
);

AND2x2_ASAP7_75t_L g264 ( 
.A(n_242),
.B(n_180),
.Y(n_264)
);

INVx2_ASAP7_75t_L g265 ( 
.A(n_226),
.Y(n_265)
);

AND2x2_ASAP7_75t_L g266 ( 
.A(n_242),
.B(n_196),
.Y(n_266)
);

NOR2xp33_ASAP7_75t_L g267 ( 
.A(n_227),
.B(n_201),
.Y(n_267)
);

INVx2_ASAP7_75t_L g268 ( 
.A(n_231),
.Y(n_268)
);

OR2x2_ASAP7_75t_L g269 ( 
.A(n_209),
.B(n_202),
.Y(n_269)
);

NAND2xp5_ASAP7_75t_L g270 ( 
.A(n_233),
.B(n_202),
.Y(n_270)
);

INVxp67_ASAP7_75t_SL g271 ( 
.A(n_209),
.Y(n_271)
);

AND2x2_ASAP7_75t_L g272 ( 
.A(n_235),
.B(n_202),
.Y(n_272)
);

INVx1_ASAP7_75t_L g273 ( 
.A(n_224),
.Y(n_273)
);

NAND4xp25_ASAP7_75t_L g274 ( 
.A(n_237),
.B(n_5),
.C(n_4),
.D(n_3),
.Y(n_274)
);

OR2x2_ASAP7_75t_L g275 ( 
.A(n_239),
.B(n_78),
.Y(n_275)
);

NAND2xp5_ASAP7_75t_L g276 ( 
.A(n_208),
.B(n_78),
.Y(n_276)
);

OR2x2_ASAP7_75t_L g277 ( 
.A(n_210),
.B(n_5),
.Y(n_277)
);

INVx1_ASAP7_75t_L g278 ( 
.A(n_238),
.Y(n_278)
);

NOR2xp33_ASAP7_75t_L g279 ( 
.A(n_236),
.B(n_220),
.Y(n_279)
);

NAND2xp5_ASAP7_75t_L g280 ( 
.A(n_241),
.B(n_6),
.Y(n_280)
);

AND2x4_ASAP7_75t_L g281 ( 
.A(n_236),
.B(n_16),
.Y(n_281)
);

INVxp67_ASAP7_75t_L g282 ( 
.A(n_241),
.Y(n_282)
);

NAND2xp5_ASAP7_75t_L g283 ( 
.A(n_219),
.B(n_8),
.Y(n_283)
);

INVx2_ASAP7_75t_L g284 ( 
.A(n_243),
.Y(n_284)
);

OR2x2_ASAP7_75t_L g285 ( 
.A(n_220),
.B(n_9),
.Y(n_285)
);

AND2x2_ASAP7_75t_L g286 ( 
.A(n_236),
.B(n_9),
.Y(n_286)
);

NAND2xp5_ASAP7_75t_L g287 ( 
.A(n_219),
.B(n_10),
.Y(n_287)
);

AOI22xp33_ASAP7_75t_L g288 ( 
.A1(n_245),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_288)
);

NAND2xp5_ASAP7_75t_L g289 ( 
.A(n_225),
.B(n_11),
.Y(n_289)
);

INVx2_ASAP7_75t_L g290 ( 
.A(n_243),
.Y(n_290)
);

NAND2xp5_ASAP7_75t_L g291 ( 
.A(n_225),
.B(n_12),
.Y(n_291)
);

NOR2x1_ASAP7_75t_SL g292 ( 
.A(n_234),
.B(n_232),
.Y(n_292)
);

OR2x2_ASAP7_75t_L g293 ( 
.A(n_222),
.B(n_13),
.Y(n_293)
);

AND2x4_ASAP7_75t_L g294 ( 
.A(n_223),
.B(n_244),
.Y(n_294)
);

INVx1_ASAP7_75t_L g295 ( 
.A(n_249),
.Y(n_295)
);

OAI21xp5_ASAP7_75t_L g296 ( 
.A1(n_247),
.A2(n_245),
.B(n_232),
.Y(n_296)
);

OR2x2_ASAP7_75t_L g297 ( 
.A(n_271),
.B(n_222),
.Y(n_297)
);

OAI221xp5_ASAP7_75t_L g298 ( 
.A1(n_274),
.A2(n_288),
.B1(n_254),
.B2(n_253),
.C(n_247),
.Y(n_298)
);

AOI22xp5_ASAP7_75t_L g299 ( 
.A1(n_254),
.A2(n_245),
.B1(n_223),
.B2(n_230),
.Y(n_299)
);

AOI22xp33_ASAP7_75t_L g300 ( 
.A1(n_288),
.A2(n_223),
.B1(n_230),
.B2(n_234),
.Y(n_300)
);

INVx1_ASAP7_75t_L g301 ( 
.A(n_249),
.Y(n_301)
);

INVx2_ASAP7_75t_SL g302 ( 
.A(n_286),
.Y(n_302)
);

INVx1_ASAP7_75t_L g303 ( 
.A(n_252),
.Y(n_303)
);

NAND2xp5_ASAP7_75t_L g304 ( 
.A(n_260),
.B(n_250),
.Y(n_304)
);

INVx1_ASAP7_75t_L g305 ( 
.A(n_252),
.Y(n_305)
);

INVx1_ASAP7_75t_L g306 ( 
.A(n_265),
.Y(n_306)
);

INVx1_ASAP7_75t_L g307 ( 
.A(n_265),
.Y(n_307)
);

O2A1O1Ixp33_ASAP7_75t_L g308 ( 
.A1(n_280),
.A2(n_228),
.B(n_246),
.C(n_124),
.Y(n_308)
);

INVx2_ASAP7_75t_L g309 ( 
.A(n_268),
.Y(n_309)
);

AOI21xp5_ASAP7_75t_L g310 ( 
.A1(n_251),
.A2(n_246),
.B(n_228),
.Y(n_310)
);

OAI332xp33_ASAP7_75t_L g311 ( 
.A1(n_283),
.A2(n_287),
.A3(n_289),
.B1(n_291),
.B2(n_293),
.B3(n_285),
.C1(n_277),
.C2(n_248),
.Y(n_311)
);

INVx1_ASAP7_75t_L g312 ( 
.A(n_268),
.Y(n_312)
);

NAND2xp5_ASAP7_75t_L g313 ( 
.A(n_260),
.B(n_13),
.Y(n_313)
);

NAND2x1p5_ASAP7_75t_L g314 ( 
.A(n_281),
.B(n_269),
.Y(n_314)
);

AND2x2_ASAP7_75t_L g315 ( 
.A(n_261),
.B(n_14),
.Y(n_315)
);

INVx1_ASAP7_75t_L g316 ( 
.A(n_255),
.Y(n_316)
);

OAI21xp33_ASAP7_75t_L g317 ( 
.A1(n_267),
.A2(n_86),
.B(n_82),
.Y(n_317)
);

INVx1_ASAP7_75t_L g318 ( 
.A(n_257),
.Y(n_318)
);

INVx1_ASAP7_75t_L g319 ( 
.A(n_263),
.Y(n_319)
);

AND2x2_ASAP7_75t_L g320 ( 
.A(n_261),
.B(n_18),
.Y(n_320)
);

AOI22xp5_ASAP7_75t_L g321 ( 
.A1(n_267),
.A2(n_86),
.B1(n_90),
.B2(n_88),
.Y(n_321)
);

INVx1_ASAP7_75t_L g322 ( 
.A(n_273),
.Y(n_322)
);

INVx1_ASAP7_75t_SL g323 ( 
.A(n_294),
.Y(n_323)
);

OAI22xp5_ASAP7_75t_L g324 ( 
.A1(n_282),
.A2(n_21),
.B1(n_20),
.B2(n_19),
.Y(n_324)
);

OAI32xp33_ASAP7_75t_L g325 ( 
.A1(n_258),
.A2(n_24),
.A3(n_23),
.B1(n_25),
.B2(n_26),
.Y(n_325)
);

INVx1_ASAP7_75t_L g326 ( 
.A(n_278),
.Y(n_326)
);

AND2x2_ASAP7_75t_L g327 ( 
.A(n_266),
.B(n_27),
.Y(n_327)
);

INVx1_ASAP7_75t_SL g328 ( 
.A(n_294),
.Y(n_328)
);

NOR2xp33_ASAP7_75t_SL g329 ( 
.A(n_281),
.B(n_279),
.Y(n_329)
);

OAI22xp5_ASAP7_75t_SL g330 ( 
.A1(n_281),
.A2(n_32),
.B1(n_30),
.B2(n_29),
.Y(n_330)
);

INVx1_ASAP7_75t_L g331 ( 
.A(n_284),
.Y(n_331)
);

INVx1_ASAP7_75t_L g332 ( 
.A(n_284),
.Y(n_332)
);

INVx1_ASAP7_75t_L g333 ( 
.A(n_290),
.Y(n_333)
);

HB1xp67_ASAP7_75t_L g334 ( 
.A(n_297),
.Y(n_334)
);

INVx1_ASAP7_75t_L g335 ( 
.A(n_295),
.Y(n_335)
);

INVx1_ASAP7_75t_L g336 ( 
.A(n_306),
.Y(n_336)
);

HB1xp67_ASAP7_75t_L g337 ( 
.A(n_331),
.Y(n_337)
);

INVx1_ASAP7_75t_L g338 ( 
.A(n_301),
.Y(n_338)
);

INVx1_ASAP7_75t_L g339 ( 
.A(n_303),
.Y(n_339)
);

INVx1_ASAP7_75t_L g340 ( 
.A(n_307),
.Y(n_340)
);

AOI22xp5_ASAP7_75t_SL g341 ( 
.A1(n_313),
.A2(n_302),
.B1(n_315),
.B2(n_296),
.Y(n_341)
);

NAND2xp5_ASAP7_75t_L g342 ( 
.A(n_304),
.B(n_279),
.Y(n_342)
);

XNOR2x1_ASAP7_75t_L g343 ( 
.A(n_311),
.B(n_264),
.Y(n_343)
);

AND2x2_ASAP7_75t_L g344 ( 
.A(n_323),
.B(n_294),
.Y(n_344)
);

XOR2x2_ASAP7_75t_L g345 ( 
.A(n_298),
.B(n_292),
.Y(n_345)
);

INVxp67_ASAP7_75t_SL g346 ( 
.A(n_332),
.Y(n_346)
);

INVx2_ASAP7_75t_L g347 ( 
.A(n_305),
.Y(n_347)
);

NAND2xp5_ASAP7_75t_L g348 ( 
.A(n_316),
.B(n_256),
.Y(n_348)
);

AOI22xp33_ASAP7_75t_L g349 ( 
.A1(n_330),
.A2(n_256),
.B1(n_259),
.B2(n_262),
.Y(n_349)
);

BUFx3_ASAP7_75t_L g350 ( 
.A(n_314),
.Y(n_350)
);

OAI321xp33_ASAP7_75t_L g351 ( 
.A1(n_296),
.A2(n_270),
.A3(n_275),
.B1(n_276),
.B2(n_272),
.C(n_290),
.Y(n_351)
);

AOI22xp5_ASAP7_75t_L g352 ( 
.A1(n_329),
.A2(n_86),
.B1(n_90),
.B2(n_34),
.Y(n_352)
);

INVx1_ASAP7_75t_L g353 ( 
.A(n_312),
.Y(n_353)
);

INVx2_ASAP7_75t_L g354 ( 
.A(n_333),
.Y(n_354)
);

NAND2x1p5_ASAP7_75t_L g355 ( 
.A(n_310),
.B(n_323),
.Y(n_355)
);

NAND2xp5_ASAP7_75t_L g356 ( 
.A(n_318),
.B(n_36),
.Y(n_356)
);

INVx2_ASAP7_75t_L g357 ( 
.A(n_309),
.Y(n_357)
);

A2O1A1Ixp33_ASAP7_75t_L g358 ( 
.A1(n_341),
.A2(n_329),
.B(n_325),
.C(n_299),
.Y(n_358)
);

OA22x2_ASAP7_75t_L g359 ( 
.A1(n_352),
.A2(n_328),
.B1(n_322),
.B2(n_319),
.Y(n_359)
);

XNOR2xp5_ASAP7_75t_L g360 ( 
.A(n_343),
.B(n_320),
.Y(n_360)
);

NAND2xp33_ASAP7_75t_R g361 ( 
.A(n_348),
.B(n_326),
.Y(n_361)
);

NAND2xp5_ASAP7_75t_L g362 ( 
.A(n_342),
.B(n_328),
.Y(n_362)
);

AOI21xp5_ASAP7_75t_L g363 ( 
.A1(n_343),
.A2(n_308),
.B(n_324),
.Y(n_363)
);

OAI21xp5_ASAP7_75t_L g364 ( 
.A1(n_345),
.A2(n_324),
.B(n_314),
.Y(n_364)
);

AOI221xp5_ASAP7_75t_L g365 ( 
.A1(n_351),
.A2(n_300),
.B1(n_317),
.B2(n_327),
.C(n_321),
.Y(n_365)
);

OAI221xp5_ASAP7_75t_L g366 ( 
.A1(n_345),
.A2(n_40),
.B1(n_39),
.B2(n_43),
.C(n_45),
.Y(n_366)
);

BUFx3_ASAP7_75t_L g367 ( 
.A(n_350),
.Y(n_367)
);

AOI22xp5_ASAP7_75t_L g368 ( 
.A1(n_349),
.A2(n_355),
.B1(n_356),
.B2(n_346),
.Y(n_368)
);

INVxp67_ASAP7_75t_L g369 ( 
.A(n_334),
.Y(n_369)
);

XNOR2x1_ASAP7_75t_L g370 ( 
.A(n_355),
.B(n_46),
.Y(n_370)
);

AOI211xp5_ASAP7_75t_L g371 ( 
.A1(n_363),
.A2(n_350),
.B(n_340),
.C(n_336),
.Y(n_371)
);

BUFx2_ASAP7_75t_L g372 ( 
.A(n_367),
.Y(n_372)
);

NAND2xp5_ASAP7_75t_SL g373 ( 
.A(n_364),
.B(n_355),
.Y(n_373)
);

AOI221xp5_ASAP7_75t_L g374 ( 
.A1(n_360),
.A2(n_353),
.B1(n_339),
.B2(n_335),
.C(n_338),
.Y(n_374)
);

INVx2_ASAP7_75t_L g375 ( 
.A(n_369),
.Y(n_375)
);

NOR2xp67_ASAP7_75t_L g376 ( 
.A(n_368),
.B(n_337),
.Y(n_376)
);

AOI211xp5_ASAP7_75t_SL g377 ( 
.A1(n_366),
.A2(n_353),
.B(n_338),
.C(n_335),
.Y(n_377)
);

NOR3xp33_ASAP7_75t_L g378 ( 
.A(n_373),
.B(n_358),
.C(n_368),
.Y(n_378)
);

CKINVDCx5p33_ASAP7_75t_R g379 ( 
.A(n_372),
.Y(n_379)
);

NAND2xp5_ASAP7_75t_L g380 ( 
.A(n_374),
.B(n_362),
.Y(n_380)
);

AOI22xp5_ASAP7_75t_L g381 ( 
.A1(n_378),
.A2(n_376),
.B1(n_361),
.B2(n_371),
.Y(n_381)
);

AOI22xp5_ASAP7_75t_L g382 ( 
.A1(n_380),
.A2(n_370),
.B1(n_375),
.B2(n_359),
.Y(n_382)
);

NAND3xp33_ASAP7_75t_L g383 ( 
.A(n_381),
.B(n_377),
.C(n_379),
.Y(n_383)
);

OAI22xp5_ASAP7_75t_L g384 ( 
.A1(n_383),
.A2(n_382),
.B1(n_365),
.B2(n_339),
.Y(n_384)
);

AOI222xp33_ASAP7_75t_SL g385 ( 
.A1(n_384),
.A2(n_354),
.B1(n_347),
.B2(n_357),
.C1(n_344),
.C2(n_48),
.Y(n_385)
);

OAI22xp33_ASAP7_75t_L g386 ( 
.A1(n_385),
.A2(n_347),
.B1(n_354),
.B2(n_357),
.Y(n_386)
);

INVx1_ASAP7_75t_L g387 ( 
.A(n_386),
.Y(n_387)
);

AOI22xp33_ASAP7_75t_L g388 ( 
.A1(n_387),
.A2(n_344),
.B1(n_90),
.B2(n_50),
.Y(n_388)
);


endmodule