module fake_netlist_825_662_n_24 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_24);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_24;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_19;
wire n_12;
wire n_18;
wire n_21;
wire n_16;

INVx3_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

NAND3xp33_ASAP7_75t_L g13 ( 
.A(n_3),
.B(n_4),
.C(n_2),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_8),
.B(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_12),
.B(n_0),
.Y(n_18)
);

HB1xp67_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_15),
.Y(n_20)
);

NAND4xp25_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_13),
.C(n_16),
.D(n_18),
.Y(n_21)
);

NOR3xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_7),
.C(n_6),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_9),
.Y(n_24)
);


endmodule