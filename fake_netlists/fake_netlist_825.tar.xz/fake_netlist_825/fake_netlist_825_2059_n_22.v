module fake_netlist_825_2059_n_22 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_22);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;
wire n_11;

INVx1_ASAP7_75t_L g11 ( 
.A(n_4),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_2),
.B(n_1),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

INVx2_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

NOR4xp25_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_11),
.C(n_13),
.D(n_4),
.Y(n_18)
);

AOI211x1_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_11),
.B(n_15),
.C(n_6),
.Y(n_19)
);

NAND5xp2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_7),
.C(n_9),
.D(n_5),
.E(n_8),
.Y(n_20)
);

INVxp33_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AO21x2_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_10),
.B(n_7),
.Y(n_22)
);


endmodule