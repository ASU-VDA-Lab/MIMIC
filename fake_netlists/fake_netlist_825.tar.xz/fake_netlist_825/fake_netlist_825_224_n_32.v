module fake_netlist_825_224_n_32 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_3),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_4),
.Y(n_14)
);

BUFx6f_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_8),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_15),
.B(n_1),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_1),
.Y(n_18)
);

O2A1O1Ixp5_ASAP7_75t_SL g19 ( 
.A1(n_14),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_11),
.Y(n_22)
);

AND2x2_ASAP7_75t_SL g23 ( 
.A(n_20),
.B(n_12),
.Y(n_23)
);

INVxp67_ASAP7_75t_SL g24 ( 
.A(n_22),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

NOR3xp33_ASAP7_75t_SL g26 ( 
.A(n_25),
.B(n_21),
.C(n_13),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

OAI221xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_24),
.B1(n_12),
.B2(n_15),
.C(n_23),
.Y(n_28)
);

INVxp67_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_24),
.B1(n_15),
.B2(n_19),
.Y(n_30)
);

XNOR2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_0),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_9),
.B1(n_10),
.B2(n_31),
.Y(n_32)
);


endmodule