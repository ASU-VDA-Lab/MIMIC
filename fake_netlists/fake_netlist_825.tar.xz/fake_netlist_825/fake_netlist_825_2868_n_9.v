module fake_netlist_825_2868_n_9 (n_4, n_2, n_3, n_0, n_1, n_9);

input n_4;
input n_2;
input n_3;
input n_0;
input n_1;

output n_9;

wire n_6;
wire n_7;
wire n_5;
wire n_8;

AOI22xp5_ASAP7_75t_L g5 ( 
.A1(n_0),
.A2(n_3),
.B1(n_1),
.B2(n_4),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_2),
.A2(n_4),
.B(n_1),
.Y(n_7)
);

OAI22xp33_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_2),
.B1(n_6),
.B2(n_7),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_7),
.Y(n_9)
);


endmodule