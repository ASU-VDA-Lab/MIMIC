module fake_netlist_825_616_n_21 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_21);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_21;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_1),
.B(n_4),
.Y(n_10)
);

NAND2xp33_ASAP7_75t_R g11 ( 
.A(n_6),
.B(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

INVxp67_ASAP7_75t_SL g14 ( 
.A(n_10),
.Y(n_14)
);

AOI221xp5_ASAP7_75t_SL g15 ( 
.A1(n_13),
.A2(n_1),
.B1(n_0),
.B2(n_4),
.C(n_5),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_13),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

OAI322xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_11),
.A3(n_16),
.B1(n_12),
.B2(n_15),
.C1(n_5),
.C2(n_6),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_17),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_17),
.B1(n_15),
.B2(n_3),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_7),
.B(n_17),
.Y(n_21)
);


endmodule