module fake_netlist_825_165_n_22 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_22);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_22;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_8;

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_6),
.B(n_1),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

NOR2x1_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_0),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

CKINVDCx11_ASAP7_75t_R g14 ( 
.A(n_11),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_8),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

AOI211x1_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_9),
.B(n_14),
.C(n_15),
.Y(n_17)
);

OAI211xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_9),
.B(n_3),
.C(n_2),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_17),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_SL g21 ( 
.A1(n_19),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_20),
.B1(n_19),
.B2(n_16),
.Y(n_22)
);


endmodule