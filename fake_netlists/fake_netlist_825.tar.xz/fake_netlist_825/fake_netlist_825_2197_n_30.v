module fake_netlist_825_2197_n_30 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_30);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_30;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_9;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_29;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_8),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

HB1xp67_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

BUFx3_ASAP7_75t_L g14 ( 
.A(n_9),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_13),
.A2(n_11),
.B1(n_12),
.B2(n_10),
.Y(n_16)
);

AO21x2_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_13),
.B(n_14),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_14),
.C(n_0),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_15),
.B1(n_14),
.B2(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_18),
.C(n_14),
.Y(n_22)
);

NOR4xp75_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_3),
.C(n_2),
.D(n_1),
.Y(n_23)
);

NAND4xp75_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_20),
.C(n_4),
.D(n_2),
.Y(n_24)
);

INVx1_ASAP7_75t_SL g25 ( 
.A(n_23),
.Y(n_25)
);

NOR3xp33_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_5),
.C(n_4),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_24),
.B(n_6),
.C(n_5),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

AOI221xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_6),
.B1(n_7),
.B2(n_27),
.C(n_28),
.Y(n_30)
);


endmodule