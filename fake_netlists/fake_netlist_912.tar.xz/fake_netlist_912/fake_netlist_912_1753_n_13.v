module fake_netlist_912_1753_n_13 (n_0, n_1, n_2, n_13);

input n_0;
input n_1;
input n_2;

output n_13;

wire n_5;
wire n_3;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

NAND2xp5_ASAP7_75t_SL g4 ( 
.A(n_1),
.B(n_2),
.Y(n_4)
);

BUFx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI221xp5_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_4),
.Y(n_6)
);

OR2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_0),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

NOR3xp33_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_2),
.C(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_9),
.B(n_11),
.Y(n_13)
);


endmodule