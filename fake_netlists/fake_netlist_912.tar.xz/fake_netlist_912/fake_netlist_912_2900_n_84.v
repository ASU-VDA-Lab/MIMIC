module fake_netlist_912_2900_n_84 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_84);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_84;

wire n_60;
wire n_52;
wire n_30;
wire n_23;
wire n_64;
wire n_66;
wire n_65;
wire n_27;
wire n_71;
wire n_80;
wire n_29;
wire n_69;
wire n_83;
wire n_51;
wire n_50;
wire n_55;
wire n_46;
wire n_54;
wire n_28;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_62;
wire n_26;
wire n_44;
wire n_79;
wire n_33;
wire n_24;
wire n_77;
wire n_53;
wire n_81;
wire n_61;
wire n_22;
wire n_43;
wire n_48;
wire n_72;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_34;
wire n_37;
wire n_75;
wire n_47;
wire n_68;
wire n_63;
wire n_58;
wire n_49;
wire n_67;
wire n_25;
wire n_35;
wire n_57;
wire n_36;
wire n_45;
wire n_73;
wire n_82;
wire n_78;

INVx2_ASAP7_75t_L g22 ( 
.A(n_5),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_14),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_12),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

AND2x6_ASAP7_75t_L g27 ( 
.A(n_4),
.B(n_16),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_18),
.B(n_19),
.Y(n_28)
);

NOR2x1_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_10),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_3),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_2),
.B(n_6),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_17),
.B(n_16),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_18),
.Y(n_33)
);

INVx6_ASAP7_75t_L g34 ( 
.A(n_8),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_20),
.B(n_3),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_25),
.B(n_2),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_19),
.B1(n_17),
.B2(n_11),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_24),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_25),
.B(n_11),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_22),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_24),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_SL g42 ( 
.A(n_26),
.B(n_21),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_33),
.B(n_35),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_34),
.B(n_21),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_22),
.B(n_0),
.Y(n_45)
);

OAI21xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_45),
.B(n_38),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

AOI221xp5_ASAP7_75t_L g48 ( 
.A1(n_38),
.A2(n_35),
.B1(n_28),
.B2(n_32),
.C(n_30),
.Y(n_48)
);

AOI21xp5_ASAP7_75t_L g49 ( 
.A1(n_41),
.A2(n_23),
.B(n_31),
.Y(n_49)
);

OAI21xp5_ASAP7_75t_L g50 ( 
.A1(n_41),
.A2(n_27),
.B(n_31),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_40),
.Y(n_51)
);

AO31x2_ASAP7_75t_L g52 ( 
.A1(n_40),
.A2(n_27),
.A3(n_34),
.B(n_30),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_47),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_46),
.B(n_39),
.Y(n_55)
);

INVxp67_ASAP7_75t_SL g56 ( 
.A(n_50),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_55),
.B(n_50),
.Y(n_59)
);

OR2x2_ASAP7_75t_L g60 ( 
.A(n_54),
.B(n_37),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_54),
.B(n_52),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_57),
.Y(n_62)
);

INVxp33_ASAP7_75t_L g63 ( 
.A(n_60),
.Y(n_63)
);

OR2x2_ASAP7_75t_L g64 ( 
.A(n_60),
.B(n_57),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_62),
.Y(n_65)
);

AND2x2_ASAP7_75t_L g66 ( 
.A(n_59),
.B(n_56),
.Y(n_66)
);

INVx1_ASAP7_75t_SL g67 ( 
.A(n_61),
.Y(n_67)
);

OAI22xp5_ASAP7_75t_L g68 ( 
.A1(n_67),
.A2(n_59),
.B1(n_58),
.B2(n_61),
.Y(n_68)
);

AOI22xp33_ASAP7_75t_SL g69 ( 
.A1(n_64),
.A2(n_27),
.B1(n_34),
.B2(n_36),
.Y(n_69)
);

NOR2xp33_ASAP7_75t_L g70 ( 
.A(n_63),
.B(n_64),
.Y(n_70)
);

OAI32xp33_ASAP7_75t_L g71 ( 
.A1(n_65),
.A2(n_44),
.A3(n_42),
.B1(n_27),
.B2(n_29),
.Y(n_71)
);

OAI21xp33_ASAP7_75t_L g72 ( 
.A1(n_65),
.A2(n_48),
.B(n_49),
.Y(n_72)
);

OAI211xp5_ASAP7_75t_SL g73 ( 
.A1(n_70),
.A2(n_72),
.B(n_69),
.C(n_68),
.Y(n_73)
);

HB1xp67_ASAP7_75t_L g74 ( 
.A(n_71),
.Y(n_74)
);

AND2x2_ASAP7_75t_L g75 ( 
.A(n_70),
.B(n_33),
.Y(n_75)
);

AND4x1_ASAP7_75t_L g76 ( 
.A(n_70),
.B(n_66),
.C(n_27),
.D(n_33),
.Y(n_76)
);

NOR2xp33_ASAP7_75t_L g77 ( 
.A(n_70),
.B(n_66),
.Y(n_77)
);

AND4x1_ASAP7_75t_L g78 ( 
.A(n_75),
.B(n_33),
.C(n_27),
.D(n_34),
.Y(n_78)
);

INVxp67_ASAP7_75t_SL g79 ( 
.A(n_77),
.Y(n_79)
);

NAND4xp75_ASAP7_75t_L g80 ( 
.A(n_77),
.B(n_30),
.C(n_33),
.D(n_7),
.Y(n_80)
);

AOI22x1_ASAP7_75t_L g81 ( 
.A1(n_79),
.A2(n_30),
.B1(n_74),
.B2(n_26),
.Y(n_81)
);

NAND4xp75_ASAP7_75t_L g82 ( 
.A(n_78),
.B(n_76),
.C(n_73),
.D(n_30),
.Y(n_82)
);

OAI21xp5_ASAP7_75t_SL g83 ( 
.A1(n_82),
.A2(n_81),
.B(n_26),
.Y(n_83)
);

AO221x2_ASAP7_75t_L g84 ( 
.A1(n_83),
.A2(n_80),
.B1(n_15),
.B2(n_13),
.C(n_26),
.Y(n_84)
);


endmodule