module fake_netlist_912_1976_n_16 (n_0, n_2, n_3, n_4, n_1, n_16);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_16;

wire n_5;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

INVx4_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

OR2x6_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_4),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

NAND2x1p5_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_2),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B1(n_6),
.B2(n_7),
.Y(n_12)
);

OAI22xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_6),
.B1(n_7),
.B2(n_3),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_6),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

NAND4xp75_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_3),
.C(n_7),
.D(n_14),
.Y(n_16)
);


endmodule