module fake_netlist_912_2120_n_38 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_38);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_38;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_16),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_7),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_3),
.Y(n_22)
);

BUFx10_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_14),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_18),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_15),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_23),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_25),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NAND5xp2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_26),
.C(n_29),
.D(n_19),
.E(n_23),
.Y(n_31)
);

XNOR2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_15),
.Y(n_32)
);

OA22x2_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_22),
.B1(n_20),
.B2(n_0),
.Y(n_33)
);

NOR2xp67_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_1),
.Y(n_34)
);

AOI311xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_4),
.A3(n_2),
.B(n_5),
.C(n_6),
.Y(n_35)
);

OR3x1_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_10),
.C(n_8),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_SL g38 ( 
.A1(n_37),
.A2(n_35),
.B1(n_13),
.B2(n_12),
.Y(n_38)
);


endmodule