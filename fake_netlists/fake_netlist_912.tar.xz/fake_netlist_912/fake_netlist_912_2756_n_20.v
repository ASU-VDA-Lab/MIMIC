module fake_netlist_912_2756_n_20 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_20);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_20;

wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_12;
wire n_17;
wire n_18;
wire n_13;
wire n_14;
wire n_10;

BUFx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_SL g13 ( 
.A1(n_8),
.A2(n_5),
.B1(n_2),
.B2(n_9),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_3),
.B(n_0),
.Y(n_14)
);

AO21x2_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_4),
.B(n_0),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_10),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_13),
.B1(n_15),
.B2(n_5),
.C(n_6),
.Y(n_18)
);

OA22x2_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_14),
.B1(n_15),
.B2(n_6),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.B1(n_14),
.B2(n_17),
.Y(n_20)
);


endmodule