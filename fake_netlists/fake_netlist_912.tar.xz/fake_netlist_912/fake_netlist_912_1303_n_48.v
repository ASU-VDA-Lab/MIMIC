module fake_netlist_912_1303_n_48 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_48);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_48;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_35;
wire n_25;
wire n_42;
wire n_41;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_16),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_0),
.B(n_14),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

OA21x2_ASAP7_75t_L g25 ( 
.A1(n_3),
.A2(n_7),
.B(n_12),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_19),
.B(n_15),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_11),
.B(n_4),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_24),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_22),
.B(n_18),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_21),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_32),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_32),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_24),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_23),
.Y(n_38)
);

INVx1_ASAP7_75t_SL g39 ( 
.A(n_38),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_28),
.Y(n_40)
);

AOI22xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_25),
.B1(n_29),
.B2(n_23),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_29),
.B1(n_26),
.B2(n_2),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_5),
.Y(n_44)
);

XOR2xp5_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_44),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_9),
.B1(n_8),
.B2(n_6),
.Y(n_46)
);

OAI21x1_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_13),
.B(n_10),
.Y(n_47)
);

XNOR2xp5_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_45),
.Y(n_48)
);


endmodule