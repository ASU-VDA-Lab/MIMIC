module fake_netlist_912_4181_n_73 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_26, n_10, n_8, n_73);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_26;
input n_10;
input n_8;

output n_73;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_52;
wire n_37;
wire n_47;
wire n_68;
wire n_46;
wire n_63;
wire n_30;
wire n_54;
wire n_64;
wire n_53;
wire n_66;
wire n_65;
wire n_71;
wire n_59;
wire n_49;
wire n_58;
wire n_70;
wire n_67;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_41;
wire n_42;
wire n_32;
wire n_57;
wire n_35;
wire n_43;
wire n_62;
wire n_44;
wire n_29;
wire n_48;
wire n_45;
wire n_36;
wire n_69;
wire n_72;
wire n_38;
wire n_56;

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_16),
.B(n_17),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_1),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_2),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_9),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_18),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_5),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_7),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_11),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_20),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_12),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_23),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_13),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_26),
.Y(n_42)
);

BUFx10_ASAP7_75t_L g43 ( 
.A(n_15),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_28),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_38),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_38),
.B(n_20),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_38),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_31),
.B(n_22),
.Y(n_48)
);

BUFx10_ASAP7_75t_L g49 ( 
.A(n_37),
.Y(n_49)
);

INVx2_ASAP7_75t_L g50 ( 
.A(n_31),
.Y(n_50)
);

OAI221xp5_ASAP7_75t_L g51 ( 
.A1(n_40),
.A2(n_23),
.B1(n_22),
.B2(n_24),
.C(n_25),
.Y(n_51)
);

AOI21xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_41),
.B(n_37),
.Y(n_52)
);

OAI22xp5_ASAP7_75t_L g53 ( 
.A1(n_47),
.A2(n_42),
.B1(n_32),
.B2(n_40),
.Y(n_53)
);

AOI22xp33_ASAP7_75t_L g54 ( 
.A1(n_46),
.A2(n_44),
.B1(n_42),
.B2(n_41),
.Y(n_54)
);

OAI211xp5_ASAP7_75t_SL g55 ( 
.A1(n_51),
.A2(n_44),
.B(n_33),
.C(n_30),
.Y(n_55)
);

AND2x4_ASAP7_75t_SL g56 ( 
.A(n_54),
.B(n_49),
.Y(n_56)
);

AOI21xp5_ASAP7_75t_L g57 ( 
.A1(n_52),
.A2(n_48),
.B(n_29),
.Y(n_57)
);

OAI221xp5_ASAP7_75t_L g58 ( 
.A1(n_55),
.A2(n_45),
.B1(n_50),
.B2(n_39),
.C(n_30),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_53),
.Y(n_59)
);

AND2x2_ASAP7_75t_L g60 ( 
.A(n_57),
.B(n_49),
.Y(n_60)
);

AND2x2_ASAP7_75t_L g61 ( 
.A(n_58),
.B(n_43),
.Y(n_61)
);

OR2x2_ASAP7_75t_L g62 ( 
.A(n_56),
.B(n_39),
.Y(n_62)
);

AOI32xp33_ASAP7_75t_L g63 ( 
.A1(n_59),
.A2(n_36),
.A3(n_31),
.B1(n_43),
.B2(n_24),
.Y(n_63)
);

NOR2x1_ASAP7_75t_L g64 ( 
.A(n_62),
.B(n_36),
.Y(n_64)
);

XOR2x2_ASAP7_75t_L g65 ( 
.A(n_61),
.B(n_25),
.Y(n_65)
);

CKINVDCx5p33_ASAP7_75t_R g66 ( 
.A(n_65),
.Y(n_66)
);

OAI211xp5_ASAP7_75t_SL g67 ( 
.A1(n_63),
.A2(n_36),
.B(n_60),
.C(n_26),
.Y(n_67)
);

AOI22xp5_ASAP7_75t_L g68 ( 
.A1(n_64),
.A2(n_35),
.B1(n_34),
.B2(n_27),
.Y(n_68)
);

CKINVDCx5p33_ASAP7_75t_R g69 ( 
.A(n_66),
.Y(n_69)
);

OR2x2_ASAP7_75t_L g70 ( 
.A(n_68),
.B(n_34),
.Y(n_70)
);

OAI222xp33_ASAP7_75t_L g71 ( 
.A1(n_70),
.A2(n_67),
.B1(n_4),
.B2(n_0),
.C1(n_6),
.C2(n_3),
.Y(n_71)
);

AOI221xp5_ASAP7_75t_R g72 ( 
.A1(n_69),
.A2(n_10),
.B1(n_8),
.B2(n_14),
.C(n_19),
.Y(n_72)
);

AOI22xp33_ASAP7_75t_L g73 ( 
.A1(n_72),
.A2(n_34),
.B1(n_35),
.B2(n_71),
.Y(n_73)
);


endmodule