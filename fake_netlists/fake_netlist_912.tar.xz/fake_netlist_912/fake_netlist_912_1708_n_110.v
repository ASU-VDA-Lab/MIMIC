module fake_netlist_912_1708_n_110 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_26, n_10, n_8, n_110);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_26;
input n_10;
input n_8;

output n_110;

wire n_100;
wire n_60;
wire n_104;
wire n_101;
wire n_52;
wire n_99;
wire n_30;
wire n_64;
wire n_102;
wire n_93;
wire n_66;
wire n_65;
wire n_88;
wire n_94;
wire n_91;
wire n_71;
wire n_80;
wire n_29;
wire n_69;
wire n_83;
wire n_96;
wire n_51;
wire n_50;
wire n_55;
wire n_46;
wire n_54;
wire n_28;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_62;
wire n_44;
wire n_79;
wire n_87;
wire n_33;
wire n_77;
wire n_107;
wire n_95;
wire n_53;
wire n_106;
wire n_90;
wire n_81;
wire n_84;
wire n_61;
wire n_43;
wire n_48;
wire n_72;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_34;
wire n_103;
wire n_37;
wire n_108;
wire n_75;
wire n_47;
wire n_68;
wire n_86;
wire n_63;
wire n_105;
wire n_85;
wire n_49;
wire n_58;
wire n_109;
wire n_67;
wire n_35;
wire n_57;
wire n_97;
wire n_98;
wire n_36;
wire n_45;
wire n_73;
wire n_89;
wire n_92;
wire n_82;
wire n_78;

INVx6_ASAP7_75t_L g28 ( 
.A(n_11),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_9),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_0),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_2),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_22),
.B(n_4),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_18),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_17),
.B(n_3),
.Y(n_36)
);

BUFx12f_ASAP7_75t_L g37 ( 
.A(n_20),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_7),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_13),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_6),
.B(n_15),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_23),
.B(n_18),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_24),
.Y(n_42)
);

NAND2x1_ASAP7_75t_L g43 ( 
.A(n_25),
.B(n_16),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_16),
.B(n_10),
.Y(n_44)
);

BUFx6f_ASAP7_75t_L g45 ( 
.A(n_21),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_22),
.B(n_21),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_19),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_19),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_31),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_35),
.B(n_23),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_35),
.B(n_25),
.Y(n_51)
);

NOR3xp33_ASAP7_75t_L g52 ( 
.A(n_41),
.B(n_27),
.C(n_26),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_29),
.B(n_26),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_31),
.Y(n_54)
);

BUFx6f_ASAP7_75t_SL g55 ( 
.A(n_36),
.Y(n_55)
);

AOI22xp33_ASAP7_75t_L g56 ( 
.A1(n_34),
.A2(n_27),
.B1(n_5),
.B2(n_1),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_42),
.B(n_8),
.Y(n_57)
);

NAND2xp33_ASAP7_75t_L g58 ( 
.A(n_45),
.B(n_12),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_39),
.Y(n_59)
);

AOI22xp33_ASAP7_75t_L g60 ( 
.A1(n_34),
.A2(n_48),
.B1(n_45),
.B2(n_32),
.Y(n_60)
);

NOR2xp33_ASAP7_75t_L g61 ( 
.A(n_28),
.B(n_14),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_SL g62 ( 
.A(n_38),
.B(n_39),
.Y(n_62)
);

HB1xp67_ASAP7_75t_L g63 ( 
.A(n_47),
.Y(n_63)
);

BUFx8_ASAP7_75t_L g64 ( 
.A(n_55),
.Y(n_64)
);

OAI21x1_ASAP7_75t_L g65 ( 
.A1(n_59),
.A2(n_40),
.B(n_38),
.Y(n_65)
);

BUFx6f_ASAP7_75t_L g66 ( 
.A(n_49),
.Y(n_66)
);

BUFx5_ASAP7_75t_L g67 ( 
.A(n_59),
.Y(n_67)
);

OAI21x1_ASAP7_75t_L g68 ( 
.A1(n_62),
.A2(n_33),
.B(n_30),
.Y(n_68)
);

OR2x2_ASAP7_75t_L g69 ( 
.A(n_63),
.B(n_47),
.Y(n_69)
);

AO31x2_ASAP7_75t_L g70 ( 
.A1(n_53),
.A2(n_48),
.A3(n_46),
.B(n_34),
.Y(n_70)
);

A2O1A1Ixp33_ASAP7_75t_L g71 ( 
.A1(n_49),
.A2(n_36),
.B(n_43),
.C(n_45),
.Y(n_71)
);

O2A1O1Ixp33_ASAP7_75t_SL g72 ( 
.A1(n_53),
.A2(n_43),
.B(n_44),
.C(n_28),
.Y(n_72)
);

AOI21xp5_ASAP7_75t_SL g73 ( 
.A1(n_71),
.A2(n_55),
.B(n_36),
.Y(n_73)
);

INVx6_ASAP7_75t_L g74 ( 
.A(n_66),
.Y(n_74)
);

INVx4_ASAP7_75t_L g75 ( 
.A(n_67),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_67),
.Y(n_76)
);

AND2x2_ASAP7_75t_L g77 ( 
.A(n_70),
.B(n_69),
.Y(n_77)
);

BUFx3_ASAP7_75t_L g78 ( 
.A(n_64),
.Y(n_78)
);

INVx2_ASAP7_75t_L g79 ( 
.A(n_75),
.Y(n_79)
);

BUFx2_ASAP7_75t_L g80 ( 
.A(n_75),
.Y(n_80)
);

NOR2xp67_ASAP7_75t_L g81 ( 
.A(n_78),
.B(n_50),
.Y(n_81)
);

AND2x4_ASAP7_75t_L g82 ( 
.A(n_78),
.B(n_77),
.Y(n_82)
);

AND2x2_ASAP7_75t_L g83 ( 
.A(n_77),
.B(n_70),
.Y(n_83)
);

AOI21xp33_ASAP7_75t_SL g84 ( 
.A1(n_82),
.A2(n_52),
.B(n_77),
.Y(n_84)
);

NAND2xp5_ASAP7_75t_L g85 ( 
.A(n_83),
.B(n_70),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_80),
.Y(n_86)
);

INVx1_ASAP7_75t_SL g87 ( 
.A(n_82),
.Y(n_87)
);

AND2x2_ASAP7_75t_L g88 ( 
.A(n_83),
.B(n_75),
.Y(n_88)
);

INVx1_ASAP7_75t_SL g89 ( 
.A(n_80),
.Y(n_89)
);

AOI22xp5_ASAP7_75t_L g90 ( 
.A1(n_88),
.A2(n_82),
.B1(n_81),
.B2(n_37),
.Y(n_90)
);

OAI221xp5_ASAP7_75t_L g91 ( 
.A1(n_84),
.A2(n_78),
.B1(n_71),
.B2(n_51),
.C(n_72),
.Y(n_91)
);

OAI321xp33_ASAP7_75t_L g92 ( 
.A1(n_85),
.A2(n_56),
.A3(n_45),
.B1(n_60),
.B2(n_61),
.C(n_57),
.Y(n_92)
);

OAI221xp5_ASAP7_75t_L g93 ( 
.A1(n_84),
.A2(n_78),
.B1(n_72),
.B2(n_73),
.C(n_54),
.Y(n_93)
);

AOI222xp33_ASAP7_75t_L g94 ( 
.A1(n_88),
.A2(n_37),
.B1(n_64),
.B2(n_55),
.C1(n_45),
.C2(n_54),
.Y(n_94)
);

OAI221xp5_ASAP7_75t_L g95 ( 
.A1(n_87),
.A2(n_79),
.B1(n_76),
.B2(n_75),
.C(n_66),
.Y(n_95)
);

AOI31xp33_ASAP7_75t_L g96 ( 
.A1(n_89),
.A2(n_79),
.A3(n_76),
.B(n_28),
.Y(n_96)
);

NAND5xp2_ASAP7_75t_L g97 ( 
.A(n_94),
.B(n_86),
.C(n_76),
.D(n_28),
.E(n_89),
.Y(n_97)
);

NAND3xp33_ASAP7_75t_L g98 ( 
.A(n_91),
.B(n_58),
.C(n_66),
.Y(n_98)
);

NAND3xp33_ASAP7_75t_SL g99 ( 
.A(n_90),
.B(n_86),
.C(n_75),
.Y(n_99)
);

NAND2xp5_ASAP7_75t_SL g100 ( 
.A(n_96),
.B(n_67),
.Y(n_100)
);

NOR3xp33_ASAP7_75t_L g101 ( 
.A(n_93),
.B(n_58),
.C(n_65),
.Y(n_101)
);

NAND4xp25_ASAP7_75t_SL g102 ( 
.A(n_90),
.B(n_68),
.C(n_67),
.D(n_74),
.Y(n_102)
);

NAND4xp25_ASAP7_75t_L g103 ( 
.A(n_97),
.B(n_95),
.C(n_92),
.D(n_67),
.Y(n_103)
);

NOR3xp33_ASAP7_75t_SL g104 ( 
.A(n_99),
.B(n_74),
.C(n_102),
.Y(n_104)
);

AND2x2_ASAP7_75t_SL g105 ( 
.A(n_101),
.B(n_100),
.Y(n_105)
);

INVx2_ASAP7_75t_L g106 ( 
.A(n_98),
.Y(n_106)
);

AOI22xp5_ASAP7_75t_L g107 ( 
.A1(n_103),
.A2(n_74),
.B1(n_105),
.B2(n_106),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_103),
.Y(n_108)
);

OAI21xp5_ASAP7_75t_L g109 ( 
.A1(n_108),
.A2(n_104),
.B(n_74),
.Y(n_109)
);

AOI31xp33_ASAP7_75t_L g110 ( 
.A1(n_109),
.A2(n_74),
.A3(n_107),
.B(n_108),
.Y(n_110)
);


endmodule