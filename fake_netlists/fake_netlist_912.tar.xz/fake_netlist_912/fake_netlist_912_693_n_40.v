module fake_netlist_912_693_n_40 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_17, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_40);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_17;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_40;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_39;
wire n_18;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_14),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_8),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_12),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_1),
.B(n_2),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_3),
.Y(n_25)
);

INVxp67_ASAP7_75t_SL g26 ( 
.A(n_22),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_19),
.B(n_16),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_20),
.A2(n_5),
.B1(n_4),
.B2(n_0),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

OAI221xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B1(n_23),
.B2(n_21),
.C(n_18),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_29),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_32),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_34),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_SL g36 ( 
.A1(n_33),
.A2(n_29),
.B1(n_24),
.B2(n_25),
.C(n_6),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_35),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AOI322xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_38),
.A3(n_10),
.B1(n_9),
.B2(n_7),
.C1(n_15),
.C2(n_13),
.Y(n_40)
);


endmodule