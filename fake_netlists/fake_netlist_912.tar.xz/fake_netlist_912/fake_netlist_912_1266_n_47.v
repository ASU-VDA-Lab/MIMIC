module fake_netlist_912_1266_n_47 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_47);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_47;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_25;
wire n_35;
wire n_41;
wire n_42;
wire n_43;
wire n_26;
wire n_36;
wire n_29;
wire n_44;
wire n_45;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_0),
.A2(n_13),
.B(n_20),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_19),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_15),
.Y(n_28)
);

BUFx8_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

BUFx6f_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_27),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_24),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_26),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_28),
.B1(n_23),
.B2(n_30),
.C(n_29),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_25),
.B1(n_7),
.B2(n_5),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_33),
.Y(n_36)
);

NOR2x1_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_8),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

NAND2xp33_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_10),
.Y(n_40)
);

NOR3xp33_ASAP7_75t_SL g41 ( 
.A(n_38),
.B(n_12),
.C(n_11),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_14),
.Y(n_42)
);

NOR2x1_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_17),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

CKINVDCx16_ASAP7_75t_R g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_45),
.B1(n_22),
.B2(n_21),
.Y(n_47)
);


endmodule