module fake_netlist_912_3280_n_16 (n_0, n_2, n_3, n_4, n_1, n_16);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_16;

wire n_5;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_1),
.B(n_3),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_4),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVxp67_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_6),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_10),
.Y(n_12)
);

OAI22xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_9),
.B1(n_12),
.B2(n_7),
.Y(n_13)
);

NOR3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_5),
.C(n_7),
.Y(n_14)
);

AND2x2_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_7),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_0),
.B1(n_2),
.B2(n_4),
.C1(n_7),
.C2(n_13),
.Y(n_16)
);


endmodule