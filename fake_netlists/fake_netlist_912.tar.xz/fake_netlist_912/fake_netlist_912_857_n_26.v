module fake_netlist_912_857_n_26 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_26);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_26;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_10;

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_3),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_SL g15 ( 
.A(n_13),
.B(n_4),
.C(n_3),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_10),
.B1(n_14),
.B2(n_11),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_15),
.B1(n_16),
.B2(n_11),
.C(n_12),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_4),
.Y(n_21)
);

OAI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_6),
.B1(n_5),
.B2(n_0),
.Y(n_22)
);

CKINVDCx6p67_ASAP7_75t_R g23 ( 
.A(n_21),
.Y(n_23)
);

OAI21x1_ASAP7_75t_SL g24 ( 
.A1(n_22),
.A2(n_6),
.B(n_5),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_23),
.B(n_1),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_23),
.C(n_24),
.Y(n_26)
);


endmodule