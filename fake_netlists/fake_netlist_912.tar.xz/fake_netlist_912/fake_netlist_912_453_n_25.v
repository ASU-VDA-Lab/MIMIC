module fake_netlist_912_453_n_25 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_25;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

BUFx2_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_3),
.B(n_5),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_1),
.Y(n_10)
);

BUFx10_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

INVx2_ASAP7_75t_SL g13 ( 
.A(n_11),
.Y(n_13)
);

BUFx8_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_2),
.Y(n_15)
);

INVx4_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_7),
.Y(n_17)
);

CKINVDCx6p67_ASAP7_75t_R g18 ( 
.A(n_15),
.Y(n_18)
);

OAI31xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_13),
.A3(n_9),
.B(n_14),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_21),
.B(n_2),
.Y(n_22)
);

BUFx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);


endmodule