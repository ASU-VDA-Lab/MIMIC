module fake_netlist_912_1699_n_17 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_17);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_17;

wire n_15;
wire n_11;
wire n_9;
wire n_13;
wire n_16;
wire n_14;
wire n_10;
wire n_12;

AOI22x1_ASAP7_75t_L g9 ( 
.A1(n_3),
.A2(n_4),
.B1(n_8),
.B2(n_7),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_1),
.B1(n_0),
.B2(n_5),
.Y(n_11)
);

AOI21x1_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

AO221x2_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.C(n_2),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_12),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_9),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_2),
.Y(n_16)
);

AOI321xp33_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_5),
.A3(n_4),
.B1(n_6),
.B2(n_8),
.C(n_7),
.Y(n_17)
);


endmodule