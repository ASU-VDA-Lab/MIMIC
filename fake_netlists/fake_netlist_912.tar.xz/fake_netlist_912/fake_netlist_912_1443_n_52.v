module fake_netlist_912_1443_n_52 (n_3, n_15, n_11, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_52);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_52;

wire n_51;
wire n_33;
wire n_50;
wire n_34;
wire n_24;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_28;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_35;
wire n_42;
wire n_41;
wire n_25;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_44;
wire n_45;
wire n_48;
wire n_38;

AND2x4_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_5),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_8),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_21),
.B(n_12),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_11),
.B(n_7),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_23),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_1),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_10),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_19),
.B(n_2),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_19),
.B1(n_18),
.B2(n_0),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_29),
.A2(n_18),
.B(n_4),
.C(n_3),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_6),
.Y(n_36)
);

XOR2xp5_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_24),
.Y(n_37)
);

HB1xp67_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_28),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_34),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_29),
.Y(n_42)
);

HB1xp67_ASAP7_75t_L g43 ( 
.A(n_42),
.Y(n_43)
);

NOR2xp67_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_40),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_SL g45 ( 
.A(n_43),
.B(n_30),
.C(n_36),
.Y(n_45)
);

A2O1A1Ixp33_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_30),
.B(n_27),
.C(n_25),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_25),
.B1(n_14),
.B2(n_9),
.C(n_13),
.Y(n_49)
);

XNOR2xp5_ASAP7_75t_L g50 ( 
.A(n_48),
.B(n_15),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_50),
.Y(n_51)
);

AOI22xp33_ASAP7_75t_L g52 ( 
.A1(n_51),
.A2(n_49),
.B1(n_17),
.B2(n_16),
.Y(n_52)
);


endmodule