module fake_netlist_912_1543_n_87 (n_3, n_15, n_11, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_87);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_87;

wire n_60;
wire n_52;
wire n_30;
wire n_64;
wire n_66;
wire n_65;
wire n_27;
wire n_71;
wire n_80;
wire n_29;
wire n_69;
wire n_83;
wire n_51;
wire n_50;
wire n_55;
wire n_46;
wire n_54;
wire n_28;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_62;
wire n_44;
wire n_26;
wire n_79;
wire n_33;
wire n_24;
wire n_77;
wire n_53;
wire n_81;
wire n_84;
wire n_61;
wire n_43;
wire n_48;
wire n_72;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_34;
wire n_37;
wire n_75;
wire n_47;
wire n_68;
wire n_86;
wire n_63;
wire n_85;
wire n_49;
wire n_58;
wire n_67;
wire n_25;
wire n_35;
wire n_57;
wire n_36;
wire n_45;
wire n_73;
wire n_82;
wire n_78;

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_12),
.B(n_13),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_SL g26 ( 
.A1(n_9),
.A2(n_21),
.B1(n_18),
.B2(n_10),
.Y(n_26)
);

OAI21x1_ASAP7_75t_L g27 ( 
.A1(n_15),
.A2(n_17),
.B(n_7),
.Y(n_27)
);

OAI22x1_ASAP7_75t_SL g28 ( 
.A1(n_23),
.A2(n_17),
.B1(n_2),
.B2(n_11),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_20),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_6),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_1),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_5),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_3),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_0),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_8),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_20),
.B(n_16),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_L g38 ( 
.A(n_19),
.B(n_4),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_30),
.Y(n_39)
);

OR2x2_ASAP7_75t_L g40 ( 
.A(n_25),
.B(n_32),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_30),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_36),
.B(n_18),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_SL g43 ( 
.A(n_31),
.B(n_19),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_33),
.B(n_22),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_34),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_35),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_29),
.B(n_22),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_24),
.A2(n_14),
.B(n_27),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_39),
.Y(n_49)
);

BUFx6f_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_41),
.Y(n_51)
);

OAI21xp5_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_38),
.B(n_37),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_41),
.Y(n_53)
);

AO31x2_ASAP7_75t_L g54 ( 
.A1(n_44),
.A2(n_28),
.A3(n_26),
.B(n_29),
.Y(n_54)
);

AO32x2_ASAP7_75t_L g55 ( 
.A1(n_42),
.A2(n_26),
.A3(n_28),
.B1(n_29),
.B2(n_43),
.Y(n_55)
);

AO21x2_ASAP7_75t_L g56 ( 
.A1(n_52),
.A2(n_46),
.B(n_45),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_49),
.Y(n_57)
);

INVx3_ASAP7_75t_L g58 ( 
.A(n_50),
.Y(n_58)
);

AND2x2_ASAP7_75t_L g59 ( 
.A(n_53),
.B(n_40),
.Y(n_59)
);

HB1xp67_ASAP7_75t_SL g60 ( 
.A(n_53),
.Y(n_60)
);

BUFx2_ASAP7_75t_L g61 ( 
.A(n_59),
.Y(n_61)
);

AND2x4_ASAP7_75t_L g62 ( 
.A(n_59),
.B(n_51),
.Y(n_62)
);

INVx2_ASAP7_75t_SL g63 ( 
.A(n_59),
.Y(n_63)
);

AND2x4_ASAP7_75t_L g64 ( 
.A(n_57),
.B(n_50),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_58),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_63),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_63),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_62),
.B(n_57),
.Y(n_68)
);

INVx2_ASAP7_75t_SL g69 ( 
.A(n_62),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_62),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_68),
.Y(n_71)
);

NOR3xp33_ASAP7_75t_L g72 ( 
.A(n_69),
.B(n_61),
.C(n_52),
.Y(n_72)
);

AOI211xp5_ASAP7_75t_SL g73 ( 
.A1(n_68),
.A2(n_60),
.B(n_64),
.C(n_58),
.Y(n_73)
);

OAI21xp5_ASAP7_75t_L g74 ( 
.A1(n_66),
.A2(n_64),
.B(n_58),
.Y(n_74)
);

AOI221xp5_ASAP7_75t_L g75 ( 
.A1(n_70),
.A2(n_64),
.B1(n_50),
.B2(n_56),
.C(n_60),
.Y(n_75)
);

AOI221xp5_ASAP7_75t_L g76 ( 
.A1(n_72),
.A2(n_69),
.B1(n_67),
.B2(n_56),
.C(n_55),
.Y(n_76)
);

NOR3xp33_ASAP7_75t_L g77 ( 
.A(n_75),
.B(n_58),
.C(n_55),
.Y(n_77)
);

NAND3xp33_ASAP7_75t_L g78 ( 
.A(n_73),
.B(n_58),
.C(n_65),
.Y(n_78)
);

NAND5xp2_ASAP7_75t_L g79 ( 
.A(n_71),
.B(n_55),
.C(n_54),
.D(n_56),
.E(n_65),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_74),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_76),
.B(n_56),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_79),
.Y(n_82)
);

NAND2xp5_ASAP7_75t_L g83 ( 
.A(n_77),
.B(n_56),
.Y(n_83)
);

AOI22xp5_ASAP7_75t_L g84 ( 
.A1(n_82),
.A2(n_80),
.B1(n_78),
.B2(n_54),
.Y(n_84)
);

NAND2xp5_ASAP7_75t_L g85 ( 
.A(n_81),
.B(n_83),
.Y(n_85)
);

XOR2xp5_ASAP7_75t_L g86 ( 
.A(n_84),
.B(n_85),
.Y(n_86)
);

OAI21x1_ASAP7_75t_L g87 ( 
.A1(n_86),
.A2(n_54),
.B(n_85),
.Y(n_87)
);


endmodule