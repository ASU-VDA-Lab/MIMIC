module fake_netlist_681_267_n_47 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_47);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_47;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_5),
.B(n_6),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_11),
.B(n_20),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_7),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_0),
.B(n_2),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_1),
.B(n_12),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_16),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_25),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

OAI21x1_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_23),
.B(n_21),
.Y(n_32)
);

OAI21x1_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_26),
.B(n_27),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_26),
.B(n_30),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_30),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

OAI21xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_33),
.B(n_22),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_24),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_17),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_41)
);

OR3x1_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_19),
.C(n_18),
.Y(n_42)
);

NAND3x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_4),
.C(n_3),
.Y(n_43)
);

OAI31xp33_ASAP7_75t_SL g44 ( 
.A1(n_42),
.A2(n_13),
.A3(n_9),
.B(n_8),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_43),
.A2(n_15),
.B(n_14),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

XNOR2xp5_ASAP7_75t_L g47 ( 
.A(n_46),
.B(n_44),
.Y(n_47)
);


endmodule