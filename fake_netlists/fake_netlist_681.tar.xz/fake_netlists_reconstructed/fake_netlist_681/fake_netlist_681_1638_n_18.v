module fake_netlist_681_1638_n_18 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_18);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_8;
wire n_17;
wire n_9;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_2),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_1),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_10)
);

BUFx3_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

NOR2x1_ASAP7_75t_R g12 ( 
.A(n_8),
.B(n_3),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI211xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_12),
.B(n_10),
.C(n_11),
.Y(n_15)
);

AND2x4_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_13),
.Y(n_16)
);

XNOR2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_7),
.B(n_0),
.Y(n_18)
);


endmodule