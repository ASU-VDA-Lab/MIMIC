module fake_netlist_681_175_n_28 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_28);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_28;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_12;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_2),
.B(n_5),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_4),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_SL g18 ( 
.A1(n_16),
.A2(n_7),
.B(n_6),
.C(n_3),
.Y(n_18)
);

BUFx3_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

NAND2xp33_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_14),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_23),
.Y(n_25)
);

NAND2xp33_ASAP7_75t_R g26 ( 
.A(n_25),
.B(n_15),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_24),
.A2(n_12),
.B1(n_7),
.B2(n_18),
.Y(n_27)
);

OAI221xp5_ASAP7_75t_R g28 ( 
.A1(n_26),
.A2(n_27),
.B1(n_24),
.B2(n_8),
.C(n_10),
.Y(n_28)
);


endmodule