module fake_netlist_681_1303_n_23 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_23);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_23;

wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_13;
wire n_11;
wire n_19;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_3),
.B(n_7),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_10),
.Y(n_14)
);

XNOR2xp5_ASAP7_75t_L g15 ( 
.A(n_6),
.B(n_4),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND4xp25_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_16),
.C(n_14),
.D(n_15),
.Y(n_20)
);

NOR4xp75_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_6),
.C(n_5),
.D(n_4),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_17),
.B(n_13),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_5),
.B(n_2),
.Y(n_23)
);


endmodule