module fake_netlist_681_2046_n_50 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_50);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_50;

wire n_24;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

BUFx2_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_5),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_8),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_1),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_18),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

NAND2xp33_ASAP7_75t_SL g27 ( 
.A(n_15),
.B(n_17),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

BUFx10_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_10),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_13),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_25),
.B(n_14),
.C(n_13),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_20),
.B(n_15),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_27),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_34)
);

NAND2xp33_ASAP7_75t_SL g35 ( 
.A(n_33),
.B(n_25),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_26),
.Y(n_36)
);

NAND3xp33_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_34),
.C(n_32),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_36),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_31),
.B1(n_23),
.B2(n_22),
.Y(n_39)
);

AND2x6_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_31),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

OAI221xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_32),
.B1(n_30),
.B2(n_23),
.C(n_21),
.Y(n_42)
);

NOR3xp33_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_41),
.C(n_31),
.Y(n_43)
);

OAI322xp33_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_31),
.A3(n_24),
.B1(n_21),
.B2(n_29),
.C1(n_16),
.C2(n_19),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_40),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_45),
.Y(n_46)
);

NAND3xp33_ASAP7_75t_L g47 ( 
.A(n_43),
.B(n_24),
.C(n_29),
.Y(n_47)
);

INVx2_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_48),
.A2(n_46),
.B1(n_47),
.B2(n_29),
.Y(n_49)
);

AOI322xp5_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_19),
.A3(n_6),
.B1(n_3),
.B2(n_0),
.C1(n_9),
.C2(n_7),
.Y(n_50)
);


endmodule