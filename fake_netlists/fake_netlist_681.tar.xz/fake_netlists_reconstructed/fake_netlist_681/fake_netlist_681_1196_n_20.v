module fake_netlist_681_1196_n_20 (n_4, n_2, n_3, n_1, n_5, n_0, n_20);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_20;

wire n_17;
wire n_6;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_7;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_3),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_2),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_4),
.A2(n_1),
.B1(n_3),
.B2(n_2),
.Y(n_10)
);

AOI21x1_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_4),
.B(n_1),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

OA21x2_ASAP7_75t_L g13 ( 
.A1(n_8),
.A2(n_6),
.B(n_10),
.Y(n_13)
);

NOR2x1_ASAP7_75t_SL g14 ( 
.A(n_8),
.B(n_10),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.B(n_11),
.C(n_14),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_15),
.B1(n_14),
.B2(n_13),
.C(n_11),
.Y(n_18)
);

BUFx4f_ASAP7_75t_SL g19 ( 
.A(n_18),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_11),
.B1(n_13),
.B2(n_15),
.C(n_10),
.Y(n_20)
);


endmodule