module fake_netlist_681_432_n_45 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_45);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_45;

wire n_24;
wire n_44;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_9),
.B(n_7),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_19),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_18),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_10),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_8),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_17),
.Y(n_27)
);

CKINVDCx16_ASAP7_75t_R g28 ( 
.A(n_16),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_20),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_28),
.B(n_16),
.Y(n_30)
);

OAI22x1_ASAP7_75t_L g31 ( 
.A1(n_24),
.A2(n_20),
.B1(n_18),
.B2(n_17),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_R g33 ( 
.A(n_32),
.B(n_23),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_R g34 ( 
.A(n_30),
.B(n_25),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_33),
.B(n_31),
.Y(n_36)
);

AND2x2_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_36),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_21),
.B1(n_22),
.B2(n_26),
.Y(n_38)
);

AOI221xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_27),
.B1(n_21),
.B2(n_22),
.C(n_0),
.Y(n_39)
);

NAND4xp25_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_3),
.C(n_2),
.D(n_1),
.Y(n_40)
);

BUFx12f_ASAP7_75t_L g41 ( 
.A(n_40),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_11),
.B1(n_5),
.B2(n_4),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_SL g45 ( 
.A1(n_43),
.A2(n_41),
.B1(n_44),
.B2(n_15),
.Y(n_45)
);


endmodule