module fake_netlist_681_820_n_53 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_53);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_53;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_19;
wire n_39;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_2),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

AND2x6_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_10),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_8),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_0),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_7),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_16),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_15),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_3),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_6),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_15),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_19),
.B(n_12),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_SL g33 ( 
.A(n_23),
.B(n_12),
.Y(n_33)
);

BUFx6f_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_18),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_31),
.B(n_27),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_34),
.Y(n_38)
);

BUFx6f_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_32),
.B1(n_33),
.B2(n_35),
.Y(n_40)
);

OA21x2_ASAP7_75t_L g41 ( 
.A1(n_36),
.A2(n_30),
.B(n_25),
.Y(n_41)
);

NOR2xp67_ASAP7_75t_SL g42 ( 
.A(n_41),
.B(n_29),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_37),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_39),
.B(n_22),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_39),
.B1(n_44),
.B2(n_24),
.C(n_14),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_41),
.B(n_47),
.Y(n_48)
);

OA22x2_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_21),
.B1(n_5),
.B2(n_4),
.Y(n_49)
);

CKINVDCx5p33_ASAP7_75t_R g50 ( 
.A(n_49),
.Y(n_50)
);

NOR2xp67_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_9),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_SL g53 ( 
.A1(n_52),
.A2(n_21),
.B1(n_51),
.B2(n_11),
.Y(n_53)
);


endmodule