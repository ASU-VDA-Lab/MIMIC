module fake_netlist_681_860_n_17 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_17);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_17;

wire n_8;
wire n_9;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_0),
.A2(n_5),
.B1(n_1),
.B2(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_7),
.B(n_3),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_4),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_SL g14 ( 
.A(n_13),
.Y(n_14)
);

OAI211xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B(n_10),
.C(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI222xp33_ASAP7_75t_SL g17 ( 
.A1(n_16),
.A2(n_4),
.B1(n_6),
.B2(n_8),
.C1(n_12),
.C2(n_14),
.Y(n_17)
);


endmodule