module fake_netlist_681_1190_n_42 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_42);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_42;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_31;
wire n_23;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_39;

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_3),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_14),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_0),
.B(n_10),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_24),
.B(n_15),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_19),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_22),
.B1(n_25),
.B2(n_20),
.Y(n_31)
);

OR2x6_ASAP7_75t_L g32 ( 
.A(n_27),
.B(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_31),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_33),
.Y(n_36)
);

INVxp67_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

OAI221xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_30),
.B1(n_35),
.B2(n_28),
.C(n_21),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_39),
.B(n_17),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_38),
.B1(n_23),
.B2(n_26),
.Y(n_41)
);

AOI322xp5_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_40),
.A3(n_4),
.B1(n_2),
.B2(n_1),
.C1(n_8),
.C2(n_5),
.Y(n_42)
);


endmodule