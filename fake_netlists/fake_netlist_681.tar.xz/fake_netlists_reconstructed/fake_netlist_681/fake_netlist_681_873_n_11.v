module fake_netlist_681_873_n_11 (n_3, n_0, n_2, n_1, n_11);

input n_3;
input n_0;
input n_2;
input n_1;

output n_11;

wire n_9;
wire n_7;
wire n_4;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

INVx4_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_1),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

OAI22xp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_5),
.B1(n_4),
.B2(n_6),
.Y(n_8)
);

AOI221xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_3),
.Y(n_9)
);

NAND3xp33_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_1),
.C(n_0),
.Y(n_10)
);

AOI22xp33_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_0),
.B1(n_2),
.B2(n_9),
.Y(n_11)
);


endmodule