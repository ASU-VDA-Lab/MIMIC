module fake_netlist_681_2263_n_17 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_17);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_17;

wire n_9;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_5),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AND2x4_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_6),
.B2(n_4),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B1(n_7),
.B2(n_4),
.C1(n_6),
.C2(n_0),
.Y(n_15)
);

OA22x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_13),
.B1(n_7),
.B2(n_3),
.Y(n_16)
);

NAND2xp33_ASAP7_75t_R g17 ( 
.A(n_16),
.B(n_8),
.Y(n_17)
);


endmodule