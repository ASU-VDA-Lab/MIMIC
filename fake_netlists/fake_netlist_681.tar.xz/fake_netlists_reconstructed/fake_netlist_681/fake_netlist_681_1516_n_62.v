module fake_netlist_681_1516_n_62 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_62);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_62;

wire n_54;
wire n_24;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_20;
wire n_58;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_19;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

INVx1_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_6),
.B(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_L g23 ( 
.A(n_12),
.B(n_2),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_16),
.B(n_3),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_15),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_18),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_1),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_18),
.A2(n_9),
.B1(n_13),
.B2(n_10),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_25),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_2),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_25),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_3),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

AOI21xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_24),
.B(n_20),
.Y(n_35)
);

OAI21xp5_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_32),
.B(n_29),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_21),
.B1(n_19),
.B2(n_24),
.Y(n_37)
);

OR2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_19),
.Y(n_38)
);

OR2x2_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_21),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_37),
.B(n_34),
.Y(n_42)
);

AOI22xp5_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_23),
.B1(n_28),
.B2(n_34),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI221xp5_ASAP7_75t_L g45 ( 
.A1(n_41),
.A2(n_28),
.B1(n_26),
.B2(n_29),
.C(n_32),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

O2A1O1Ixp33_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_40),
.B(n_46),
.C(n_44),
.Y(n_48)
);

OAI221xp5_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_43),
.B1(n_27),
.B2(n_30),
.C(n_22),
.Y(n_49)
);

OAI22xp5_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_27),
.B1(n_22),
.B2(n_7),
.Y(n_50)
);

NOR2xp67_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_0),
.Y(n_51)
);

A2O1A1Ixp33_ASAP7_75t_L g52 ( 
.A1(n_46),
.A2(n_22),
.B(n_8),
.C(n_7),
.Y(n_52)
);

AO22x2_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_13),
.B1(n_9),
.B2(n_8),
.Y(n_53)
);

NOR3xp33_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_52),
.C(n_51),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_48),
.Y(n_55)
);

NOR2x1_ASAP7_75t_L g56 ( 
.A(n_48),
.B(n_22),
.Y(n_56)
);

OAI21xp5_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_15),
.B(n_14),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

OAI21xp5_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_17),
.B(n_22),
.Y(n_59)
);

OAI321xp33_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_53),
.A3(n_22),
.B1(n_17),
.B2(n_5),
.C(n_4),
.Y(n_60)
);

XNOR2xp5_ASAP7_75t_L g61 ( 
.A(n_57),
.B(n_53),
.Y(n_61)
);

OAI22xp33_ASAP7_75t_L g62 ( 
.A1(n_60),
.A2(n_61),
.B1(n_59),
.B2(n_58),
.Y(n_62)
);


endmodule