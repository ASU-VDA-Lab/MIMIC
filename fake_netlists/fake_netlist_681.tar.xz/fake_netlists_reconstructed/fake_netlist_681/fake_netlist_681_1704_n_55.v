module fake_netlist_681_1704_n_55 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_55);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_55;

wire n_54;
wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_19;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_3),
.B(n_15),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_12),
.B(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

INVx5_ASAP7_75t_L g20 ( 
.A(n_0),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_8),
.B(n_0),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_10),
.Y(n_23)
);

AND2x2_ASAP7_75t_SL g24 ( 
.A(n_13),
.B(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_1),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_17),
.Y(n_27)
);

BUFx3_ASAP7_75t_L g28 ( 
.A(n_22),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_23),
.B(n_1),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_27),
.B(n_22),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

HB1xp67_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

NAND3xp33_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_29),
.C(n_26),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_SL g35 ( 
.A1(n_32),
.A2(n_27),
.B1(n_24),
.B2(n_29),
.Y(n_35)
);

AOI22xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_21),
.B1(n_31),
.B2(n_24),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_28),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_34),
.B(n_21),
.Y(n_38)
);

OAI31xp33_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_21),
.A3(n_25),
.B(n_19),
.Y(n_39)
);

OAI332xp33_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_19),
.A3(n_25),
.B1(n_23),
.B2(n_26),
.B3(n_18),
.C1(n_28),
.C2(n_2),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

AOI31xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_40),
.A3(n_39),
.B(n_5),
.Y(n_42)
);

OAI21xp33_ASAP7_75t_SL g43 ( 
.A1(n_41),
.A2(n_10),
.B(n_5),
.Y(n_43)
);

AOI211xp5_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_16),
.B(n_15),
.C(n_14),
.Y(n_44)
);

OAI21xp5_ASAP7_75t_SL g45 ( 
.A1(n_39),
.A2(n_16),
.B(n_14),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_42),
.B1(n_45),
.B2(n_43),
.C(n_20),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_43),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_42),
.B(n_20),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_48),
.Y(n_50)
);

OAI22x1_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_20),
.B1(n_9),
.B2(n_4),
.Y(n_51)
);

INVxp67_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_46),
.B(n_20),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_52),
.B(n_47),
.Y(n_54)
);

AOI22xp5_ASAP7_75t_SL g55 ( 
.A1(n_54),
.A2(n_51),
.B1(n_50),
.B2(n_53),
.Y(n_55)
);


endmodule