module fake_netlist_681_1112_n_234 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_26, n_1, n_5, n_7, n_23, n_31, n_29, n_33, n_8, n_0, n_4, n_32, n_28, n_3, n_11, n_19, n_30, n_25, n_10, n_13, n_14, n_12, n_234);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_26;
input n_1;
input n_5;
input n_7;
input n_23;
input n_31;
input n_29;
input n_33;
input n_8;
input n_0;
input n_4;
input n_32;
input n_28;
input n_3;
input n_11;
input n_19;
input n_30;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_234;

wire n_61;
wire n_99;
wire n_210;
wire n_115;
wire n_233;
wire n_219;
wire n_110;
wire n_148;
wire n_86;
wire n_147;
wire n_171;
wire n_230;
wire n_102;
wire n_40;
wire n_66;
wire n_165;
wire n_88;
wire n_47;
wire n_119;
wire n_175;
wire n_35;
wire n_196;
wire n_52;
wire n_220;
wire n_213;
wire n_71;
wire n_150;
wire n_162;
wire n_157;
wire n_179;
wire n_121;
wire n_182;
wire n_60;
wire n_189;
wire n_89;
wire n_114;
wire n_181;
wire n_194;
wire n_211;
wire n_212;
wire n_112;
wire n_197;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_83;
wire n_113;
wire n_229;
wire n_131;
wire n_45;
wire n_204;
wire n_124;
wire n_158;
wire n_163;
wire n_130;
wire n_156;
wire n_64;
wire n_190;
wire n_146;
wire n_85;
wire n_136;
wire n_58;
wire n_218;
wire n_62;
wire n_200;
wire n_76;
wire n_63;
wire n_184;
wire n_70;
wire n_224;
wire n_69;
wire n_101;
wire n_141;
wire n_123;
wire n_53;
wire n_109;
wire n_231;
wire n_173;
wire n_168;
wire n_74;
wire n_188;
wire n_160;
wire n_176;
wire n_209;
wire n_226;
wire n_144;
wire n_170;
wire n_187;
wire n_208;
wire n_164;
wire n_94;
wire n_149;
wire n_81;
wire n_75;
wire n_161;
wire n_55;
wire n_192;
wire n_111;
wire n_54;
wire n_78;
wire n_207;
wire n_44;
wire n_38;
wire n_174;
wire n_203;
wire n_199;
wire n_91;
wire n_167;
wire n_42;
wire n_106;
wire n_116;
wire n_127;
wire n_34;
wire n_225;
wire n_100;
wire n_145;
wire n_43;
wire n_84;
wire n_177;
wire n_37;
wire n_51;
wire n_191;
wire n_68;
wire n_140;
wire n_92;
wire n_195;
wire n_129;
wire n_90;
wire n_143;
wire n_169;
wire n_77;
wire n_117;
wire n_82;
wire n_134;
wire n_152;
wire n_180;
wire n_228;
wire n_128;
wire n_202;
wire n_172;
wire n_93;
wire n_193;
wire n_97;
wire n_118;
wire n_186;
wire n_214;
wire n_216;
wire n_95;
wire n_98;
wire n_103;
wire n_135;
wire n_222;
wire n_125;
wire n_122;
wire n_79;
wire n_178;
wire n_154;
wire n_104;
wire n_105;
wire n_215;
wire n_139;
wire n_133;
wire n_183;
wire n_155;
wire n_120;
wire n_217;
wire n_137;
wire n_46;
wire n_87;
wire n_41;
wire n_73;
wire n_205;
wire n_185;
wire n_56;
wire n_159;
wire n_72;
wire n_65;
wire n_80;
wire n_107;
wire n_132;
wire n_232;
wire n_227;
wire n_138;
wire n_151;
wire n_153;
wire n_201;
wire n_36;
wire n_142;
wire n_126;
wire n_223;
wire n_221;
wire n_206;
wire n_49;
wire n_57;
wire n_96;
wire n_166;
wire n_198;
wire n_108;

INVx1_ASAP7_75t_L g34 ( 
.A(n_27),
.Y(n_34)
);

CKINVDCx20_ASAP7_75t_R g35 ( 
.A(n_20),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_0),
.Y(n_36)
);

INVxp67_ASAP7_75t_L g37 ( 
.A(n_3),
.Y(n_37)
);

CKINVDCx16_ASAP7_75t_R g38 ( 
.A(n_30),
.Y(n_38)
);

INVxp33_ASAP7_75t_L g39 ( 
.A(n_21),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_22),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_12),
.B(n_31),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_19),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_14),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_0),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_33),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_24),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_32),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_36),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_36),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_43),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_43),
.Y(n_51)
);

INVxp67_ASAP7_75t_L g52 ( 
.A(n_44),
.Y(n_52)
);

NOR2xp33_ASAP7_75t_L g53 ( 
.A(n_39),
.B(n_1),
.Y(n_53)
);

BUFx8_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_48),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_48),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_SL g57 ( 
.A(n_53),
.B(n_38),
.Y(n_57)
);

O2A1O1Ixp33_ASAP7_75t_L g58 ( 
.A1(n_52),
.A2(n_37),
.B(n_44),
.C(n_41),
.Y(n_58)
);

OR2x2_ASAP7_75t_L g59 ( 
.A(n_49),
.B(n_38),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_SL g60 ( 
.A(n_49),
.B(n_41),
.Y(n_60)
);

INVx2_ASAP7_75t_L g61 ( 
.A(n_50),
.Y(n_61)
);

INVx2_ASAP7_75t_SL g62 ( 
.A(n_50),
.Y(n_62)
);

BUFx6f_ASAP7_75t_L g63 ( 
.A(n_55),
.Y(n_63)
);

INVx3_ASAP7_75t_L g64 ( 
.A(n_56),
.Y(n_64)
);

AOI22xp33_ASAP7_75t_L g65 ( 
.A1(n_60),
.A2(n_45),
.B1(n_40),
.B2(n_34),
.Y(n_65)
);

AND2x6_ASAP7_75t_SL g66 ( 
.A(n_58),
.B(n_34),
.Y(n_66)
);

INVx2_ASAP7_75t_SL g67 ( 
.A(n_60),
.Y(n_67)
);

NOR2xp33_ASAP7_75t_L g68 ( 
.A(n_57),
.B(n_40),
.Y(n_68)
);

NAND2xp5_ASAP7_75t_L g69 ( 
.A(n_62),
.B(n_42),
.Y(n_69)
);

BUFx3_ASAP7_75t_L g70 ( 
.A(n_61),
.Y(n_70)
);

NAND2xp5_ASAP7_75t_L g71 ( 
.A(n_58),
.B(n_42),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_59),
.Y(n_72)
);

INVx2_ASAP7_75t_L g73 ( 
.A(n_54),
.Y(n_73)
);

CKINVDCx5p33_ASAP7_75t_R g74 ( 
.A(n_54),
.Y(n_74)
);

HB1xp67_ASAP7_75t_L g75 ( 
.A(n_72),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_64),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_64),
.Y(n_77)
);

AND2x4_ASAP7_75t_L g78 ( 
.A(n_67),
.B(n_47),
.Y(n_78)
);

AOI21xp5_ASAP7_75t_L g79 ( 
.A1(n_67),
.A2(n_47),
.B(n_45),
.Y(n_79)
);

BUFx3_ASAP7_75t_L g80 ( 
.A(n_70),
.Y(n_80)
);

AOI22xp5_ASAP7_75t_L g81 ( 
.A1(n_68),
.A2(n_45),
.B1(n_35),
.B2(n_46),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_64),
.Y(n_82)
);

NAND2xp5_ASAP7_75t_L g83 ( 
.A(n_67),
.B(n_68),
.Y(n_83)
);

AND2x4_ASAP7_75t_L g84 ( 
.A(n_67),
.B(n_1),
.Y(n_84)
);

AOI22xp5_ASAP7_75t_L g85 ( 
.A1(n_84),
.A2(n_65),
.B1(n_72),
.B2(n_71),
.Y(n_85)
);

INVx1_ASAP7_75t_L g86 ( 
.A(n_76),
.Y(n_86)
);

NAND2xp5_ASAP7_75t_L g87 ( 
.A(n_83),
.B(n_72),
.Y(n_87)
);

AND2x2_ASAP7_75t_L g88 ( 
.A(n_78),
.B(n_71),
.Y(n_88)
);

INVx2_ASAP7_75t_L g89 ( 
.A(n_76),
.Y(n_89)
);

OAI21x1_ASAP7_75t_L g90 ( 
.A1(n_77),
.A2(n_71),
.B(n_64),
.Y(n_90)
);

OAI21x1_ASAP7_75t_L g91 ( 
.A1(n_77),
.A2(n_64),
.B(n_65),
.Y(n_91)
);

INVx2_ASAP7_75t_SL g92 ( 
.A(n_80),
.Y(n_92)
);

INVx2_ASAP7_75t_L g93 ( 
.A(n_89),
.Y(n_93)
);

INVx2_ASAP7_75t_L g94 ( 
.A(n_89),
.Y(n_94)
);

INVx1_ASAP7_75t_SL g95 ( 
.A(n_88),
.Y(n_95)
);

AND2x2_ASAP7_75t_L g96 ( 
.A(n_88),
.B(n_78),
.Y(n_96)
);

OAI22xp5_ASAP7_75t_L g97 ( 
.A1(n_85),
.A2(n_81),
.B1(n_78),
.B2(n_65),
.Y(n_97)
);

BUFx3_ASAP7_75t_L g98 ( 
.A(n_92),
.Y(n_98)
);

INVxp67_ASAP7_75t_L g99 ( 
.A(n_87),
.Y(n_99)
);

NAND4xp25_ASAP7_75t_L g100 ( 
.A(n_99),
.B(n_81),
.C(n_73),
.D(n_69),
.Y(n_100)
);

BUFx3_ASAP7_75t_L g101 ( 
.A(n_98),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_93),
.Y(n_102)
);

AND2x4_ASAP7_75t_L g103 ( 
.A(n_96),
.B(n_92),
.Y(n_103)
);

AOI221xp5_ASAP7_75t_L g104 ( 
.A1(n_97),
.A2(n_75),
.B1(n_87),
.B2(n_88),
.C(n_85),
.Y(n_104)
);

INVx1_ASAP7_75t_L g105 ( 
.A(n_93),
.Y(n_105)
);

INVx1_ASAP7_75t_L g106 ( 
.A(n_94),
.Y(n_106)
);

INVx1_ASAP7_75t_L g107 ( 
.A(n_94),
.Y(n_107)
);

OR2x6_ASAP7_75t_L g108 ( 
.A(n_96),
.B(n_92),
.Y(n_108)
);

INVx1_ASAP7_75t_L g109 ( 
.A(n_102),
.Y(n_109)
);

INVx1_ASAP7_75t_SL g110 ( 
.A(n_103),
.Y(n_110)
);

AND2x2_ASAP7_75t_L g111 ( 
.A(n_105),
.B(n_95),
.Y(n_111)
);

INVx1_ASAP7_75t_L g112 ( 
.A(n_106),
.Y(n_112)
);

INVx2_ASAP7_75t_L g113 ( 
.A(n_107),
.Y(n_113)
);

INVxp67_ASAP7_75t_L g114 ( 
.A(n_100),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_101),
.Y(n_115)
);

OAI22xp33_ASAP7_75t_SL g116 ( 
.A1(n_108),
.A2(n_84),
.B1(n_78),
.B2(n_73),
.Y(n_116)
);

OR2x2_ASAP7_75t_L g117 ( 
.A(n_108),
.B(n_95),
.Y(n_117)
);

NAND2xp5_ASAP7_75t_L g118 ( 
.A(n_104),
.B(n_66),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_101),
.Y(n_119)
);

AND2x4_ASAP7_75t_L g120 ( 
.A(n_108),
.B(n_103),
.Y(n_120)
);

OR2x2_ASAP7_75t_L g121 ( 
.A(n_104),
.B(n_90),
.Y(n_121)
);

NAND2xp5_ASAP7_75t_L g122 ( 
.A(n_100),
.B(n_66),
.Y(n_122)
);

INVx1_ASAP7_75t_L g123 ( 
.A(n_102),
.Y(n_123)
);

AND2x2_ASAP7_75t_L g124 ( 
.A(n_121),
.B(n_90),
.Y(n_124)
);

AND2x2_ASAP7_75t_L g125 ( 
.A(n_121),
.B(n_90),
.Y(n_125)
);

AND2x4_ASAP7_75t_L g126 ( 
.A(n_120),
.B(n_119),
.Y(n_126)
);

AOI211xp5_ASAP7_75t_L g127 ( 
.A1(n_118),
.A2(n_84),
.B(n_79),
.C(n_73),
.Y(n_127)
);

INVx2_ASAP7_75t_L g128 ( 
.A(n_123),
.Y(n_128)
);

OR2x2_ASAP7_75t_L g129 ( 
.A(n_123),
.B(n_69),
.Y(n_129)
);

INVxp67_ASAP7_75t_SL g130 ( 
.A(n_117),
.Y(n_130)
);

INVx1_ASAP7_75t_L g131 ( 
.A(n_109),
.Y(n_131)
);

HB1xp67_ASAP7_75t_L g132 ( 
.A(n_119),
.Y(n_132)
);

AND2x2_ASAP7_75t_L g133 ( 
.A(n_111),
.B(n_84),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_112),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_113),
.Y(n_135)
);

NAND2x1_ASAP7_75t_L g136 ( 
.A(n_113),
.B(n_89),
.Y(n_136)
);

INVxp67_ASAP7_75t_L g137 ( 
.A(n_115),
.Y(n_137)
);

INVx2_ASAP7_75t_L g138 ( 
.A(n_111),
.Y(n_138)
);

NAND2xp5_ASAP7_75t_L g139 ( 
.A(n_122),
.B(n_117),
.Y(n_139)
);

AND2x2_ASAP7_75t_L g140 ( 
.A(n_120),
.B(n_98),
.Y(n_140)
);

AND2x4_ASAP7_75t_L g141 ( 
.A(n_120),
.B(n_98),
.Y(n_141)
);

NAND2xp5_ASAP7_75t_L g142 ( 
.A(n_114),
.B(n_66),
.Y(n_142)
);

OR2x4_ASAP7_75t_L g143 ( 
.A(n_116),
.B(n_86),
.Y(n_143)
);

AOI21xp33_ASAP7_75t_SL g144 ( 
.A1(n_110),
.A2(n_73),
.B(n_74),
.Y(n_144)
);

INVx1_ASAP7_75t_L g145 ( 
.A(n_123),
.Y(n_145)
);

NAND2xp5_ASAP7_75t_L g146 ( 
.A(n_139),
.B(n_89),
.Y(n_146)
);

NAND2xp5_ASAP7_75t_L g147 ( 
.A(n_139),
.B(n_86),
.Y(n_147)
);

NOR2xp33_ASAP7_75t_L g148 ( 
.A(n_142),
.B(n_144),
.Y(n_148)
);

NAND2xp5_ASAP7_75t_L g149 ( 
.A(n_145),
.B(n_69),
.Y(n_149)
);

BUFx3_ASAP7_75t_L g150 ( 
.A(n_143),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_145),
.Y(n_151)
);

NOR2xp33_ASAP7_75t_R g152 ( 
.A(n_142),
.B(n_74),
.Y(n_152)
);

INVx2_ASAP7_75t_L g153 ( 
.A(n_128),
.Y(n_153)
);

AND2x2_ASAP7_75t_L g154 ( 
.A(n_125),
.B(n_2),
.Y(n_154)
);

AND2x2_ASAP7_75t_L g155 ( 
.A(n_125),
.B(n_2),
.Y(n_155)
);

INVx1_ASAP7_75t_L g156 ( 
.A(n_128),
.Y(n_156)
);

NAND2xp5_ASAP7_75t_L g157 ( 
.A(n_138),
.B(n_3),
.Y(n_157)
);

O2A1O1Ixp33_ASAP7_75t_L g158 ( 
.A1(n_127),
.A2(n_73),
.B(n_64),
.C(n_82),
.Y(n_158)
);

AND2x2_ASAP7_75t_L g159 ( 
.A(n_124),
.B(n_4),
.Y(n_159)
);

OR2x2_ASAP7_75t_L g160 ( 
.A(n_138),
.B(n_4),
.Y(n_160)
);

INVx1_ASAP7_75t_L g161 ( 
.A(n_128),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_131),
.Y(n_162)
);

AND2x2_ASAP7_75t_L g163 ( 
.A(n_124),
.B(n_5),
.Y(n_163)
);

INVx2_ASAP7_75t_L g164 ( 
.A(n_135),
.Y(n_164)
);

NAND2xp5_ASAP7_75t_L g165 ( 
.A(n_138),
.B(n_5),
.Y(n_165)
);

OAI21xp33_ASAP7_75t_L g166 ( 
.A1(n_127),
.A2(n_64),
.B(n_82),
.Y(n_166)
);

INVx1_ASAP7_75t_L g167 ( 
.A(n_131),
.Y(n_167)
);

AND2x2_ASAP7_75t_L g168 ( 
.A(n_134),
.B(n_6),
.Y(n_168)
);

AND2x2_ASAP7_75t_L g169 ( 
.A(n_134),
.B(n_6),
.Y(n_169)
);

OR2x2_ASAP7_75t_L g170 ( 
.A(n_130),
.B(n_7),
.Y(n_170)
);

NAND2xp5_ASAP7_75t_L g171 ( 
.A(n_137),
.B(n_7),
.Y(n_171)
);

AND2x2_ASAP7_75t_L g172 ( 
.A(n_126),
.B(n_132),
.Y(n_172)
);

AO22x1_ASAP7_75t_L g173 ( 
.A1(n_126),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_173)
);

NAND2xp5_ASAP7_75t_L g174 ( 
.A(n_155),
.B(n_126),
.Y(n_174)
);

NAND3xp33_ASAP7_75t_L g175 ( 
.A(n_148),
.B(n_144),
.C(n_135),
.Y(n_175)
);

NOR3xp33_ASAP7_75t_L g176 ( 
.A(n_173),
.B(n_129),
.C(n_136),
.Y(n_176)
);

OAI21xp5_ASAP7_75t_L g177 ( 
.A1(n_158),
.A2(n_129),
.B(n_126),
.Y(n_177)
);

AOI21xp33_ASAP7_75t_L g178 ( 
.A1(n_157),
.A2(n_165),
.B(n_171),
.Y(n_178)
);

AND2x2_ASAP7_75t_L g179 ( 
.A(n_172),
.B(n_140),
.Y(n_179)
);

AOI211xp5_ASAP7_75t_L g180 ( 
.A1(n_173),
.A2(n_140),
.B(n_133),
.C(n_141),
.Y(n_180)
);

INVxp67_ASAP7_75t_L g181 ( 
.A(n_172),
.Y(n_181)
);

NAND2xp5_ASAP7_75t_SL g182 ( 
.A(n_150),
.B(n_141),
.Y(n_182)
);

AND4x1_ASAP7_75t_L g183 ( 
.A(n_155),
.B(n_133),
.C(n_143),
.D(n_8),
.Y(n_183)
);

AND3x1_ASAP7_75t_L g184 ( 
.A(n_168),
.B(n_143),
.C(n_9),
.Y(n_184)
);

INVx1_ASAP7_75t_L g185 ( 
.A(n_162),
.Y(n_185)
);

AND2x2_ASAP7_75t_L g186 ( 
.A(n_153),
.B(n_141),
.Y(n_186)
);

NAND2xp5_ASAP7_75t_L g187 ( 
.A(n_154),
.B(n_141),
.Y(n_187)
);

NAND3xp33_ASAP7_75t_L g188 ( 
.A(n_147),
.B(n_136),
.C(n_63),
.Y(n_188)
);

INVx1_ASAP7_75t_L g189 ( 
.A(n_162),
.Y(n_189)
);

AND2x2_ASAP7_75t_L g190 ( 
.A(n_153),
.B(n_10),
.Y(n_190)
);

NAND4xp25_ASAP7_75t_L g191 ( 
.A(n_166),
.B(n_70),
.C(n_12),
.D(n_11),
.Y(n_191)
);

NOR2xp33_ASAP7_75t_L g192 ( 
.A(n_151),
.B(n_11),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_167),
.Y(n_193)
);

NAND3xp33_ASAP7_75t_L g194 ( 
.A(n_146),
.B(n_63),
.C(n_70),
.Y(n_194)
);

OAI211xp5_ASAP7_75t_L g195 ( 
.A1(n_166),
.A2(n_15),
.B(n_14),
.C(n_13),
.Y(n_195)
);

NAND3xp33_ASAP7_75t_L g196 ( 
.A(n_154),
.B(n_63),
.C(n_70),
.Y(n_196)
);

AOI211xp5_ASAP7_75t_L g197 ( 
.A1(n_168),
.A2(n_16),
.B(n_15),
.C(n_13),
.Y(n_197)
);

OR2x2_ASAP7_75t_L g198 ( 
.A(n_164),
.B(n_16),
.Y(n_198)
);

NAND2xp5_ASAP7_75t_L g199 ( 
.A(n_185),
.B(n_167),
.Y(n_199)
);

NAND2x1p5_ASAP7_75t_L g200 ( 
.A(n_184),
.B(n_160),
.Y(n_200)
);

AOI22xp5_ASAP7_75t_L g201 ( 
.A1(n_191),
.A2(n_150),
.B1(n_163),
.B2(n_159),
.Y(n_201)
);

AO22x1_ASAP7_75t_L g202 ( 
.A1(n_192),
.A2(n_169),
.B1(n_150),
.B2(n_163),
.Y(n_202)
);

AND2x2_ASAP7_75t_L g203 ( 
.A(n_179),
.B(n_159),
.Y(n_203)
);

NAND2xp5_ASAP7_75t_L g204 ( 
.A(n_189),
.B(n_151),
.Y(n_204)
);

INVxp67_ASAP7_75t_SL g205 ( 
.A(n_186),
.Y(n_205)
);

AOI222xp33_ASAP7_75t_L g206 ( 
.A1(n_192),
.A2(n_169),
.B1(n_149),
.B2(n_161),
.C1(n_156),
.C2(n_164),
.Y(n_206)
);

XNOR2xp5_ASAP7_75t_L g207 ( 
.A(n_183),
.B(n_170),
.Y(n_207)
);

AOI322xp5_ASAP7_75t_L g208 ( 
.A1(n_176),
.A2(n_156),
.A3(n_161),
.B1(n_149),
.B2(n_153),
.C1(n_164),
.C2(n_152),
.Y(n_208)
);

AOI221xp5_ASAP7_75t_L g209 ( 
.A1(n_178),
.A2(n_170),
.B1(n_160),
.B2(n_63),
.C(n_70),
.Y(n_209)
);

INVx1_ASAP7_75t_L g210 ( 
.A(n_193),
.Y(n_210)
);

INVx2_ASAP7_75t_SL g211 ( 
.A(n_179),
.Y(n_211)
);

AOI221xp5_ASAP7_75t_L g212 ( 
.A1(n_197),
.A2(n_63),
.B1(n_80),
.B2(n_17),
.C(n_18),
.Y(n_212)
);

AOI22xp5_ASAP7_75t_L g213 ( 
.A1(n_195),
.A2(n_63),
.B1(n_91),
.B2(n_23),
.Y(n_213)
);

NOR2xp67_ASAP7_75t_L g214 ( 
.A(n_175),
.B(n_25),
.Y(n_214)
);

NAND3xp33_ASAP7_75t_SL g215 ( 
.A(n_208),
.B(n_180),
.C(n_198),
.Y(n_215)
);

NAND2xp5_ASAP7_75t_L g216 ( 
.A(n_206),
.B(n_190),
.Y(n_216)
);

NOR2xp67_ASAP7_75t_L g217 ( 
.A(n_211),
.B(n_181),
.Y(n_217)
);

INVx2_ASAP7_75t_L g218 ( 
.A(n_210),
.Y(n_218)
);

OAI21xp33_ASAP7_75t_L g219 ( 
.A1(n_201),
.A2(n_190),
.B(n_174),
.Y(n_219)
);

AOI222xp33_ASAP7_75t_L g220 ( 
.A1(n_207),
.A2(n_177),
.B1(n_196),
.B2(n_187),
.C1(n_182),
.C2(n_186),
.Y(n_220)
);

NOR3xp33_ASAP7_75t_L g221 ( 
.A(n_212),
.B(n_188),
.C(n_194),
.Y(n_221)
);

NAND2xp5_ASAP7_75t_L g222 ( 
.A(n_199),
.B(n_182),
.Y(n_222)
);

INVx1_ASAP7_75t_L g223 ( 
.A(n_204),
.Y(n_223)
);

AOI22xp33_ASAP7_75t_L g224 ( 
.A1(n_215),
.A2(n_200),
.B1(n_214),
.B2(n_209),
.Y(n_224)
);

INVx1_ASAP7_75t_L g225 ( 
.A(n_218),
.Y(n_225)
);

AOI221xp5_ASAP7_75t_L g226 ( 
.A1(n_216),
.A2(n_202),
.B1(n_203),
.B2(n_205),
.C(n_213),
.Y(n_226)
);

OA22x2_ASAP7_75t_L g227 ( 
.A1(n_219),
.A2(n_214),
.B1(n_91),
.B2(n_26),
.Y(n_227)
);

OAI22xp5_ASAP7_75t_L g228 ( 
.A1(n_217),
.A2(n_63),
.B1(n_91),
.B2(n_28),
.Y(n_228)
);

INVx1_ASAP7_75t_L g229 ( 
.A(n_225),
.Y(n_229)
);

NAND5xp2_ASAP7_75t_L g230 ( 
.A(n_226),
.B(n_220),
.C(n_221),
.D(n_223),
.E(n_222),
.Y(n_230)
);

NOR3xp33_ASAP7_75t_SL g231 ( 
.A(n_230),
.B(n_228),
.C(n_224),
.Y(n_231)
);

NAND2x1p5_ASAP7_75t_L g232 ( 
.A(n_231),
.B(n_229),
.Y(n_232)
);

INVxp67_ASAP7_75t_SL g233 ( 
.A(n_232),
.Y(n_233)
);

AOI221xp5_ASAP7_75t_L g234 ( 
.A1(n_233),
.A2(n_229),
.B1(n_227),
.B2(n_63),
.C(n_29),
.Y(n_234)
);


endmodule