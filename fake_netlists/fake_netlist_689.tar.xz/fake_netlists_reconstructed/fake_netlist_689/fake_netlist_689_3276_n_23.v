module fake_netlist_689_3276_n_23 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_23);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_23;

wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_11;
wire n_19;
wire n_13;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g11 ( 
.A(n_2),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

OAI21xp33_ASAP7_75t_SL g14 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_14)
);

BUFx6f_ASAP7_75t_SL g15 ( 
.A(n_3),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_12),
.Y(n_16)
);

AO21x2_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_7),
.B(n_5),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_13),
.Y(n_19)
);

OAI211xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_14),
.B(n_17),
.C(n_15),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_SL g21 ( 
.A1(n_20),
.A2(n_17),
.B(n_7),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_21),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_8),
.B(n_6),
.Y(n_23)
);


endmodule