module fake_netlist_689_1650_n_21 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_21);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_21;

wire n_17;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_13;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_12;

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_0),
.A2(n_6),
.B1(n_3),
.B2(n_7),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

INVx2_ASAP7_75t_SL g14 ( 
.A(n_11),
.Y(n_14)
);

NOR4xp25_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_5),
.C(n_4),
.D(n_1),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.Y(n_17)
);

AOI322xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_12),
.A3(n_14),
.B1(n_15),
.B2(n_5),
.C1(n_4),
.C2(n_6),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

XNOR2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_2),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_9),
.B(n_15),
.Y(n_21)
);


endmodule