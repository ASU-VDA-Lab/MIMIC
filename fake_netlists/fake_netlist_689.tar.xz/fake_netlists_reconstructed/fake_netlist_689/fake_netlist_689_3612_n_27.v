module fake_netlist_689_3612_n_27 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_12;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_6),
.B(n_2),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_8),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_4),
.B(n_5),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_1),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_4),
.Y(n_18)
);

O2A1O1Ixp5_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_17),
.B(n_16),
.C(n_12),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_13),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

OA211x2_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_12),
.B(n_7),
.C(n_6),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_7),
.B(n_9),
.C(n_3),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

NOR2x1_ASAP7_75t_SL g25 ( 
.A(n_23),
.B(n_10),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_25),
.B(n_24),
.Y(n_27)
);


endmodule