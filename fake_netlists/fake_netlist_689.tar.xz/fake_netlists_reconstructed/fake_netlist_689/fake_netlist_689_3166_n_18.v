module fake_netlist_689_3166_n_18 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_18);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_17;
wire n_9;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_0),
.B(n_4),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_SL g11 ( 
.A1(n_3),
.A2(n_5),
.B1(n_6),
.B2(n_2),
.Y(n_11)
);

OR2x2_ASAP7_75t_L g12 ( 
.A(n_4),
.B(n_0),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_6),
.B(n_1),
.Y(n_13)
);

AO21x2_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_12),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B1(n_13),
.B2(n_7),
.C1(n_1),
.C2(n_14),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_SL g18 ( 
.A1(n_17),
.A2(n_15),
.B1(n_7),
.B2(n_8),
.Y(n_18)
);


endmodule