module fake_netlist_689_1596_n_21 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_21);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_21;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

CKINVDCx20_ASAP7_75t_R g9 ( 
.A(n_1),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_0),
.Y(n_10)
);

NOR2xp67_ASAP7_75t_L g11 ( 
.A(n_2),
.B(n_1),
.Y(n_11)
);

CKINVDCx16_ASAP7_75t_R g12 ( 
.A(n_8),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_11),
.B(n_12),
.Y(n_13)
);

AOI21x1_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_3),
.B(n_0),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_R g15 ( 
.A(n_13),
.B(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

HB1xp67_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_16),
.B1(n_14),
.B2(n_12),
.C(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI21xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_5),
.B(n_4),
.Y(n_20)
);

AOI22xp33_ASAP7_75t_R g21 ( 
.A1(n_20),
.A2(n_19),
.B1(n_7),
.B2(n_6),
.Y(n_21)
);


endmodule