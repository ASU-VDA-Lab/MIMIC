module fake_netlist_689_2754_n_19 (n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_19);

input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_19;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_1),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_2),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_4),
.Y(n_12)
);

OR2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_9),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.Y(n_14)
);

NAND3xp33_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.C(n_4),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.C(n_3),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_19)
);


endmodule