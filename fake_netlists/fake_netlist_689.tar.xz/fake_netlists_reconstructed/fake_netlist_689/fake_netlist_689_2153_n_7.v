module fake_netlist_689_2153_n_7 (n_0, n_2, n_1, n_7);

input n_0;
input n_2;
input n_1;

output n_7;

wire n_4;
wire n_3;
wire n_5;
wire n_6;

NAND2xp5_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

AO31x2_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_4)
);

OAI221xp5_ASAP7_75t_L g5 ( 
.A1(n_4),
.A2(n_0),
.B1(n_1),
.B2(n_2),
.C(n_3),
.Y(n_5)
);

NOR3xp33_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.C(n_0),
.Y(n_6)
);

OAI22xp33_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_7)
);


endmodule