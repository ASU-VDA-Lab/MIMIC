module fake_netlist_689_2008_n_16 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_16);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_16;

wire n_8;
wire n_9;
wire n_15;
wire n_11;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

AO22x2_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B1(n_4),
.B2(n_7),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_3),
.B(n_0),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B(n_6),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVxp67_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_8),
.B2(n_11),
.C(n_6),
.Y(n_14)
);

XNOR2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_8),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_9),
.B(n_2),
.Y(n_16)
);


endmodule