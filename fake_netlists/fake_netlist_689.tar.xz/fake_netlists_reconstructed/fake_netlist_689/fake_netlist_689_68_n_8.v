module fake_netlist_689_68_n_8 (n_4, n_2, n_3, n_1, n_0, n_8);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_8;

wire n_7;
wire n_5;
wire n_6;

OAI22xp5_ASAP7_75t_L g5 ( 
.A1(n_1),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_0),
.A2(n_2),
.B(n_4),
.Y(n_6)
);

OAI22xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_4),
.B2(n_6),
.Y(n_7)
);

INVx1_ASAP7_75t_SL g8 ( 
.A(n_7),
.Y(n_8)
);


endmodule