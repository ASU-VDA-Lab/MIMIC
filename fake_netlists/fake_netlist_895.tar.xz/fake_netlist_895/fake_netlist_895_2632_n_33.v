module fake_netlist_895_2632_n_33 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_33);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_33;

wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_26;
wire n_29;

NOR2xp33_ASAP7_75t_L g16 ( 
.A(n_8),
.B(n_3),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_SL g17 ( 
.A(n_9),
.B(n_0),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

BUFx8_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_0),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_23)
);

NOR2xp67_ASAP7_75t_SL g24 ( 
.A(n_22),
.B(n_20),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_17),
.B1(n_16),
.B2(n_19),
.C(n_1),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_4),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.B1(n_26),
.B2(n_19),
.Y(n_29)
);

AND3x1_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_6),
.C(n_5),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_5),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI322xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_30),
.A3(n_7),
.B1(n_13),
.B2(n_15),
.C1(n_11),
.C2(n_12),
.Y(n_33)
);


endmodule