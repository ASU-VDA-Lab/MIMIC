module fake_netlist_895_633_n_11 (n_0, n_2, n_5, n_3, n_4, n_1, n_11);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_11;

wire n_10;
wire n_9;
wire n_8;
wire n_6;
wire n_7;

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_2),
.Y(n_6)
);

A2O1A1Ixp33_ASAP7_75t_L g7 ( 
.A1(n_3),
.A2(n_4),
.B(n_1),
.C(n_5),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_0),
.B(n_1),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_8),
.Y(n_9)
);

AOI31xp33_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_7),
.A3(n_8),
.B(n_6),
.Y(n_10)
);

BUFx4f_ASAP7_75t_SL g11 ( 
.A(n_10),
.Y(n_11)
);


endmodule