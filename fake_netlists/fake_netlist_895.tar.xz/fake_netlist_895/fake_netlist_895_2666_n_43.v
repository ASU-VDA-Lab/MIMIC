module fake_netlist_895_2666_n_43 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_43);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_43;

wire n_33;
wire n_15;
wire n_34;
wire n_24;
wire n_37;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_40;
wire n_39;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_13;
wire n_25;
wire n_14;
wire n_22;
wire n_32;
wire n_35;
wire n_42;
wire n_41;
wire n_26;
wire n_36;
wire n_29;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_5),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_11),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_12),
.B(n_0),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_13),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_21)
);

XOR2xp5_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_3),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_20),
.B(n_19),
.Y(n_24)
);

OAI21xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_19),
.B(n_14),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_21),
.A2(n_18),
.B1(n_14),
.B2(n_16),
.Y(n_26)
);

NOR2x1_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_19),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_24),
.B(n_18),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_17),
.Y(n_31)
);

NAND2x1_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_29),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_30),
.Y(n_34)
);

AOI222xp33_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_28),
.B1(n_22),
.B2(n_7),
.C1(n_6),
.C2(n_4),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

XNOR2xp5_ASAP7_75t_L g37 ( 
.A(n_32),
.B(n_4),
.Y(n_37)
);

NOR4xp25_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_34),
.C(n_7),
.D(n_6),
.Y(n_38)
);

OAI211xp5_ASAP7_75t_SL g39 ( 
.A1(n_35),
.A2(n_11),
.B(n_10),
.C(n_8),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

INVx2_ASAP7_75t_SL g41 ( 
.A(n_40),
.Y(n_41)
);

OAI221xp5_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_38),
.B1(n_37),
.B2(n_8),
.C(n_10),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_9),
.B1(n_38),
.B2(n_41),
.Y(n_43)
);


endmodule