module fake_netlist_895_1829_n_13 (n_0, n_1, n_3, n_2, n_13);

input n_0;
input n_1;
input n_3;
input n_2;

output n_13;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_7;
wire n_12;

BUFx6f_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

BUFx3_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

OAI22xp5_ASAP7_75t_SL g6 ( 
.A1(n_5),
.A2(n_4),
.B1(n_1),
.B2(n_0),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_7)
);

OAI221xp5_ASAP7_75t_SL g8 ( 
.A1(n_7),
.A2(n_5),
.B1(n_3),
.B2(n_2),
.C(n_4),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_4),
.B1(n_3),
.B2(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_3),
.B1(n_4),
.B2(n_9),
.C(n_8),
.Y(n_11)
);

XNOR2x2_ASAP7_75t_L g12 ( 
.A(n_11),
.B(n_10),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_4),
.B(n_11),
.Y(n_13)
);


endmodule