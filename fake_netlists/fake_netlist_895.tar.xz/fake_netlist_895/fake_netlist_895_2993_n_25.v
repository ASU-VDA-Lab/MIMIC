module fake_netlist_895_2993_n_25 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_12, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;
input n_12;

output n_25;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_20;
wire n_18;
wire n_17;
wire n_13;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_3),
.B(n_1),
.Y(n_15)
);

OAI22xp33_ASAP7_75t_L g16 ( 
.A1(n_6),
.A2(n_2),
.B1(n_7),
.B2(n_9),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_L g17 ( 
.A(n_0),
.B(n_5),
.C(n_2),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_0),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_15),
.A2(n_10),
.B(n_8),
.Y(n_19)
);

OAI221xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_13),
.B1(n_17),
.B2(n_16),
.C(n_4),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_16),
.Y(n_21)
);

AOI222xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_5),
.B1(n_4),
.B2(n_6),
.C1(n_7),
.C2(n_19),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AO21x2_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_11),
.B(n_23),
.Y(n_25)
);


endmodule