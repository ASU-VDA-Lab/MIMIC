module fake_netlist_895_4175_n_31 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_31);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_31;

wire n_15;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_25;
wire n_14;
wire n_22;
wire n_26;
wire n_29;

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

NOR2xp67_ASAP7_75t_L g15 ( 
.A(n_2),
.B(n_12),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_0),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_9),
.B(n_5),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_1),
.Y(n_19)
);

AO22x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_21),
.B(n_17),
.Y(n_22)
);

OAI22xp33_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_16),
.B1(n_14),
.B2(n_17),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_16),
.Y(n_25)
);

OAI31xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_24),
.A3(n_18),
.B(n_20),
.Y(n_26)
);

INVx1_ASAP7_75t_SL g27 ( 
.A(n_26),
.Y(n_27)
);

OAI221xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_22),
.B1(n_6),
.B2(n_3),
.C(n_4),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_6),
.B1(n_4),
.B2(n_3),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_7),
.B1(n_11),
.B2(n_8),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_29),
.B1(n_7),
.B2(n_13),
.Y(n_31)
);


endmodule