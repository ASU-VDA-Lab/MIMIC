module fake_netlist_895_699_n_32 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_32);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_32;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_29;

OA21x2_ASAP7_75t_L g11 ( 
.A1(n_0),
.A2(n_1),
.B(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_2),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_12),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_14),
.B(n_16),
.Y(n_19)
);

OR2x2_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_6),
.Y(n_20)
);

CKINVDCx16_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

BUFx4f_ASAP7_75t_SL g22 ( 
.A(n_19),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_14),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_21),
.B1(n_22),
.B2(n_17),
.Y(n_25)
);

OAI222xp33_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_18),
.B1(n_13),
.B2(n_12),
.C1(n_15),
.C2(n_11),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B(n_13),
.Y(n_27)
);

NAND4xp25_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_15),
.C(n_11),
.D(n_6),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_29),
.A2(n_11),
.B1(n_15),
.B2(n_8),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_30),
.B1(n_11),
.B2(n_9),
.Y(n_32)
);


endmodule