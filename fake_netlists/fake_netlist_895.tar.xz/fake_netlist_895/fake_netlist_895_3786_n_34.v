module fake_netlist_895_3786_n_34 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_34);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_34;

wire n_33;
wire n_15;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_31;
wire n_21;
wire n_13;
wire n_25;
wire n_22;
wire n_14;
wire n_32;
wire n_26;
wire n_29;

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_10),
.Y(n_12)
);

INVxp33_ASAP7_75t_SL g13 ( 
.A(n_4),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_8),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_16),
.B(n_13),
.C(n_15),
.Y(n_20)
);

AOI21xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_18),
.B(n_12),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_17),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_17),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_17),
.Y(n_26)
);

OAI21xp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_6),
.B(n_5),
.Y(n_27)
);

A2O1A1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_26),
.A2(n_2),
.B(n_0),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

NOR2x1p5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_7),
.Y(n_31)
);

INVx1_ASAP7_75t_SL g32 ( 
.A(n_30),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AOI322xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_3),
.A3(n_9),
.B1(n_11),
.B2(n_31),
.C1(n_16),
.C2(n_33),
.Y(n_34)
);


endmodule