module fake_netlist_895_854_n_14 (n_0, n_1, n_3, n_2, n_14);

input n_0;
input n_1;
input n_3;
input n_2;

output n_14;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

NAND3x1_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_3),
.C(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

AOI221xp5_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_3),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

AND2x4_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B1(n_8),
.B2(n_9),
.C(n_2),
.Y(n_11)
);

OAI211xp5_ASAP7_75t_SL g12 ( 
.A1(n_10),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_12)
);

OAI211xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_9),
.B(n_1),
.C(n_2),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_1),
.B1(n_3),
.B2(n_12),
.C1(n_11),
.C2(n_7),
.Y(n_14)
);


endmodule