module fake_netlist_895_4884_n_17 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_17);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_17;

wire n_16;
wire n_15;
wire n_11;
wire n_10;
wire n_9;
wire n_8;
wire n_13;
wire n_7;
wire n_12;
wire n_14;

AND2x2_ASAP7_75t_L g7 ( 
.A(n_1),
.B(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_2),
.B(n_6),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_3),
.B(n_5),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_8),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

OAI21xp33_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_10),
.B(n_9),
.Y(n_14)
);

NAND2x1_ASAP7_75t_SL g15 ( 
.A(n_14),
.B(n_7),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

OR2x6_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_4),
.Y(n_17)
);


endmodule