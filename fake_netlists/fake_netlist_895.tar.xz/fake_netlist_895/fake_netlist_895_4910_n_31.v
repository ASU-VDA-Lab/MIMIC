module fake_netlist_895_4910_n_31 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_31);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;

output n_31;

wire n_15;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_29;

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_7),
.Y(n_15)
);

NOR2xp33_ASAP7_75t_R g16 ( 
.A(n_1),
.B(n_3),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_0),
.B(n_6),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_6),
.B1(n_5),
.B2(n_4),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_14),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_17),
.A2(n_13),
.B(n_5),
.C(n_4),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_18),
.Y(n_24)
);

OR2x6_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_17),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_23),
.Y(n_26)
);

INVxp67_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NAND4xp75_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_20),
.C(n_19),
.D(n_15),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_25),
.B1(n_16),
.B2(n_2),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_12),
.B1(n_9),
.B2(n_8),
.Y(n_31)
);


endmodule