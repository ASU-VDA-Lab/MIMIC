module fake_netlist_895_950_n_29 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_29);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_29;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_21;
wire n_13;
wire n_7;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;
wire n_8;

INVx1_ASAP7_75t_L g7 ( 
.A(n_3),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

BUFx10_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx6_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_5),
.Y(n_13)
);

OR2x6_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_1),
.Y(n_14)
);

OAI21x1_ASAP7_75t_SL g15 ( 
.A1(n_12),
.A2(n_1),
.B(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

AO31x2_ASAP7_75t_L g17 ( 
.A1(n_7),
.A2(n_4),
.A3(n_3),
.B(n_2),
.Y(n_17)
);

AOI221x1_ASAP7_75t_L g18 ( 
.A1(n_7),
.A2(n_13),
.B1(n_10),
.B2(n_8),
.C(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_18),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_20),
.Y(n_24)
);

AOI31xp33_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_20),
.A3(n_19),
.B(n_14),
.Y(n_25)
);

NAND4xp25_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_9),
.C(n_15),
.D(n_17),
.Y(n_26)
);

AND2x4_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_14),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_27),
.C(n_14),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_17),
.Y(n_29)
);


endmodule