module fake_netlist_895_3454_n_34 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_34);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_34;

wire n_33;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_25;
wire n_22;
wire n_32;
wire n_26;
wire n_29;

INVx2_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_12),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_7),
.B(n_13),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_7),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_5),
.B1(n_4),
.B2(n_1),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_23),
.Y(n_27)
);

NOR5xp2_ASAP7_75t_SL g28 ( 
.A(n_27),
.B(n_24),
.C(n_6),
.D(n_1),
.E(n_5),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_25),
.Y(n_29)
);

XOR2x2_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_6),
.Y(n_30)
);

NAND4xp25_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_20),
.C(n_18),
.D(n_16),
.Y(n_31)
);

BUFx2_ASAP7_75t_L g32 ( 
.A(n_31),
.Y(n_32)
);

AOI32xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_17),
.A3(n_26),
.B1(n_19),
.B2(n_0),
.Y(n_33)
);

AOI222xp33_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_8),
.B1(n_3),
.B2(n_11),
.C1(n_15),
.C2(n_14),
.Y(n_34)
);


endmodule