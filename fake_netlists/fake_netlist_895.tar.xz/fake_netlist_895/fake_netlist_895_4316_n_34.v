module fake_netlist_895_4316_n_34 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_34);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_34;

wire n_33;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_31;
wire n_21;
wire n_22;
wire n_25;
wire n_32;
wire n_26;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_12),
.Y(n_16)
);

AND3x2_ASAP7_75t_L g17 ( 
.A(n_9),
.B(n_11),
.C(n_4),
.Y(n_17)
);

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_8),
.Y(n_18)
);

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_13),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_0),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_6),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_16),
.A2(n_3),
.B(n_1),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_SL g24 ( 
.A(n_20),
.B(n_5),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_10),
.B(n_7),
.Y(n_25)
);

NOR2x1p5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_22),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_18),
.Y(n_27)
);

INVx4_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI21xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_27),
.B(n_25),
.Y(n_29)
);

NAND4xp75_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_26),
.C(n_19),
.D(n_17),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

XOR2xp5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_6),
.Y(n_32)
);

OAI21xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_17),
.B(n_15),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_32),
.B1(n_15),
.B2(n_14),
.Y(n_34)
);


endmodule