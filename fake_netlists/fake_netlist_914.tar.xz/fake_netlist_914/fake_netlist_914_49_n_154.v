module fake_netlist_914_49_n_154 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_10, n_8, n_154);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_10;
input n_8;

output n_154;

wire n_118;
wire n_100;
wire n_60;
wire n_104;
wire n_101;
wire n_52;
wire n_99;
wire n_127;
wire n_151;
wire n_152;
wire n_111;
wire n_153;
wire n_30;
wire n_116;
wire n_64;
wire n_102;
wire n_93;
wire n_66;
wire n_65;
wire n_143;
wire n_88;
wire n_27;
wire n_94;
wire n_91;
wire n_71;
wire n_135;
wire n_80;
wire n_149;
wire n_29;
wire n_69;
wire n_83;
wire n_134;
wire n_96;
wire n_128;
wire n_117;
wire n_131;
wire n_51;
wire n_50;
wire n_55;
wire n_123;
wire n_110;
wire n_46;
wire n_144;
wire n_54;
wire n_28;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_132;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_126;
wire n_62;
wire n_120;
wire n_141;
wire n_150;
wire n_148;
wire n_26;
wire n_44;
wire n_79;
wire n_87;
wire n_142;
wire n_115;
wire n_33;
wire n_113;
wire n_129;
wire n_77;
wire n_107;
wire n_95;
wire n_53;
wire n_106;
wire n_137;
wire n_90;
wire n_146;
wire n_81;
wire n_84;
wire n_140;
wire n_61;
wire n_130;
wire n_122;
wire n_43;
wire n_138;
wire n_139;
wire n_136;
wire n_48;
wire n_72;
wire n_133;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_125;
wire n_34;
wire n_103;
wire n_37;
wire n_108;
wire n_75;
wire n_47;
wire n_68;
wire n_86;
wire n_63;
wire n_105;
wire n_114;
wire n_124;
wire n_145;
wire n_85;
wire n_112;
wire n_49;
wire n_58;
wire n_109;
wire n_147;
wire n_67;
wire n_35;
wire n_57;
wire n_121;
wire n_98;
wire n_97;
wire n_119;
wire n_36;
wire n_45;
wire n_92;
wire n_89;
wire n_73;
wire n_82;
wire n_78;

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_7),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

CKINVDCx16_ASAP7_75t_R g29 ( 
.A(n_5),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_12),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_22),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_11),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_10),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_6),
.Y(n_35)
);

CKINVDCx20_ASAP7_75t_R g36 ( 
.A(n_25),
.Y(n_36)
);

INVxp33_ASAP7_75t_SL g37 ( 
.A(n_13),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_23),
.Y(n_38)
);

INVxp67_ASAP7_75t_SL g39 ( 
.A(n_3),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_27),
.Y(n_40)
);

AND2x4_ASAP7_75t_L g41 ( 
.A(n_26),
.B(n_0),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_27),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_28),
.Y(n_43)
);

OA21x2_ASAP7_75t_L g44 ( 
.A1(n_28),
.A2(n_1),
.B(n_0),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_L g45 ( 
.A(n_35),
.B(n_1),
.Y(n_45)
);

BUFx6f_ASAP7_75t_L g46 ( 
.A(n_30),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_46),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_SL g48 ( 
.A(n_40),
.B(n_31),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_42),
.B(n_29),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_SL g50 ( 
.A(n_41),
.B(n_37),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_40),
.B(n_38),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_46),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_41),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_41),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_48),
.Y(n_55)
);

INVx3_ASAP7_75t_L g56 ( 
.A(n_47),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_51),
.B(n_41),
.Y(n_57)
);

AND2x2_ASAP7_75t_L g58 ( 
.A(n_48),
.B(n_45),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_52),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_49),
.B(n_43),
.Y(n_60)
);

INVx3_ASAP7_75t_L g61 ( 
.A(n_56),
.Y(n_61)
);

AND2x2_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_44),
.Y(n_62)
);

INVx2_ASAP7_75t_L g63 ( 
.A(n_59),
.Y(n_63)
);

NAND3xp33_ASAP7_75t_SL g64 ( 
.A(n_60),
.B(n_34),
.C(n_32),
.Y(n_64)
);

AND2x4_ASAP7_75t_L g65 ( 
.A(n_58),
.B(n_43),
.Y(n_65)
);

INVx2_ASAP7_75t_SL g66 ( 
.A(n_60),
.Y(n_66)
);

INVx3_ASAP7_75t_L g67 ( 
.A(n_56),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_57),
.B(n_44),
.Y(n_68)
);

AOI21xp5_ASAP7_75t_L g69 ( 
.A1(n_53),
.A2(n_45),
.B(n_44),
.Y(n_69)
);

AND2x4_ASAP7_75t_L g70 ( 
.A(n_57),
.B(n_43),
.Y(n_70)
);

CKINVDCx5p33_ASAP7_75t_R g71 ( 
.A(n_64),
.Y(n_71)
);

INVx2_ASAP7_75t_SL g72 ( 
.A(n_66),
.Y(n_72)
);

INVx3_ASAP7_75t_L g73 ( 
.A(n_66),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_66),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_66),
.Y(n_75)
);

INVx2_ASAP7_75t_L g76 ( 
.A(n_63),
.Y(n_76)
);

INVx2_ASAP7_75t_L g77 ( 
.A(n_63),
.Y(n_77)
);

INVx3_ASAP7_75t_L g78 ( 
.A(n_63),
.Y(n_78)
);

NAND2xp5_ASAP7_75t_L g79 ( 
.A(n_65),
.B(n_54),
.Y(n_79)
);

AO21x2_ASAP7_75t_L g80 ( 
.A1(n_76),
.A2(n_69),
.B(n_68),
.Y(n_80)
);

NOR2xp67_ASAP7_75t_L g81 ( 
.A(n_72),
.B(n_68),
.Y(n_81)
);

OR2x2_ASAP7_75t_L g82 ( 
.A(n_76),
.B(n_70),
.Y(n_82)
);

AND2x2_ASAP7_75t_L g83 ( 
.A(n_76),
.B(n_65),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_76),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_77),
.Y(n_85)
);

AND2x2_ASAP7_75t_L g86 ( 
.A(n_77),
.B(n_65),
.Y(n_86)
);

BUFx2_ASAP7_75t_L g87 ( 
.A(n_72),
.Y(n_87)
);

NAND3xp33_ASAP7_75t_SL g88 ( 
.A(n_82),
.B(n_71),
.C(n_36),
.Y(n_88)
);

AND2x2_ASAP7_75t_L g89 ( 
.A(n_86),
.B(n_65),
.Y(n_89)
);

INVx2_ASAP7_75t_L g90 ( 
.A(n_84),
.Y(n_90)
);

INVx2_ASAP7_75t_L g91 ( 
.A(n_84),
.Y(n_91)
);

NAND2xp5_ASAP7_75t_L g92 ( 
.A(n_85),
.B(n_77),
.Y(n_92)
);

OAI21xp33_ASAP7_75t_L g93 ( 
.A1(n_85),
.A2(n_71),
.B(n_64),
.Y(n_93)
);

BUFx3_ASAP7_75t_L g94 ( 
.A(n_83),
.Y(n_94)
);

NAND2xp5_ASAP7_75t_L g95 ( 
.A(n_84),
.B(n_80),
.Y(n_95)
);

HB1xp67_ASAP7_75t_L g96 ( 
.A(n_83),
.Y(n_96)
);

NAND2x1_ASAP7_75t_L g97 ( 
.A(n_90),
.B(n_87),
.Y(n_97)
);

NOR3xp33_ASAP7_75t_L g98 ( 
.A(n_88),
.B(n_39),
.C(n_35),
.Y(n_98)
);

INVx2_ASAP7_75t_L g99 ( 
.A(n_95),
.Y(n_99)
);

AND2x2_ASAP7_75t_L g100 ( 
.A(n_91),
.B(n_80),
.Y(n_100)
);

AND2x2_ASAP7_75t_L g101 ( 
.A(n_96),
.B(n_80),
.Y(n_101)
);

BUFx3_ASAP7_75t_L g102 ( 
.A(n_94),
.Y(n_102)
);

NAND2x1p5_ASAP7_75t_L g103 ( 
.A(n_92),
.B(n_87),
.Y(n_103)
);

NOR2x1_ASAP7_75t_L g104 ( 
.A(n_88),
.B(n_81),
.Y(n_104)
);

NOR2xp33_ASAP7_75t_L g105 ( 
.A(n_93),
.B(n_89),
.Y(n_105)
);

OAI33xp33_ASAP7_75t_L g106 ( 
.A1(n_93),
.A2(n_33),
.A3(n_79),
.B1(n_75),
.B2(n_74),
.B3(n_54),
.Y(n_106)
);

INVxp67_ASAP7_75t_L g107 ( 
.A(n_101),
.Y(n_107)
);

NOR2xp33_ASAP7_75t_L g108 ( 
.A(n_105),
.B(n_2),
.Y(n_108)
);

INVx2_ASAP7_75t_L g109 ( 
.A(n_100),
.Y(n_109)
);

NAND2xp5_ASAP7_75t_L g110 ( 
.A(n_102),
.B(n_100),
.Y(n_110)
);

AND2x4_ASAP7_75t_L g111 ( 
.A(n_99),
.B(n_78),
.Y(n_111)
);

NOR2xp33_ASAP7_75t_L g112 ( 
.A(n_106),
.B(n_104),
.Y(n_112)
);

OAI21xp5_ASAP7_75t_L g113 ( 
.A1(n_98),
.A2(n_69),
.B(n_44),
.Y(n_113)
);

NOR2xp33_ASAP7_75t_L g114 ( 
.A(n_103),
.B(n_2),
.Y(n_114)
);

INVx1_ASAP7_75t_L g115 ( 
.A(n_97),
.Y(n_115)
);

INVx2_ASAP7_75t_L g116 ( 
.A(n_97),
.Y(n_116)
);

AND2x2_ASAP7_75t_L g117 ( 
.A(n_107),
.B(n_46),
.Y(n_117)
);

OR2x2_ASAP7_75t_L g118 ( 
.A(n_107),
.B(n_46),
.Y(n_118)
);

OAI31xp33_ASAP7_75t_L g119 ( 
.A1(n_108),
.A2(n_75),
.A3(n_70),
.B(n_74),
.Y(n_119)
);

NAND2xp5_ASAP7_75t_SL g120 ( 
.A(n_116),
.B(n_73),
.Y(n_120)
);

HB1xp67_ASAP7_75t_L g121 ( 
.A(n_110),
.Y(n_121)
);

AND2x2_ASAP7_75t_L g122 ( 
.A(n_115),
.B(n_44),
.Y(n_122)
);

XOR2xp5_ASAP7_75t_L g123 ( 
.A(n_113),
.B(n_4),
.Y(n_123)
);

AND2x2_ASAP7_75t_L g124 ( 
.A(n_111),
.B(n_112),
.Y(n_124)
);

INVx1_ASAP7_75t_L g125 ( 
.A(n_114),
.Y(n_125)
);

INVx2_ASAP7_75t_L g126 ( 
.A(n_109),
.Y(n_126)
);

AOI31xp33_ASAP7_75t_L g127 ( 
.A1(n_123),
.A2(n_69),
.A3(n_68),
.B(n_62),
.Y(n_127)
);

NAND4xp25_ASAP7_75t_L g128 ( 
.A(n_119),
.B(n_62),
.C(n_79),
.D(n_65),
.Y(n_128)
);

NOR2xp67_ASAP7_75t_L g129 ( 
.A(n_121),
.B(n_4),
.Y(n_129)
);

NAND2xp5_ASAP7_75t_L g130 ( 
.A(n_124),
.B(n_5),
.Y(n_130)
);

NOR2xp33_ASAP7_75t_L g131 ( 
.A(n_125),
.B(n_6),
.Y(n_131)
);

AOI21xp5_ASAP7_75t_L g132 ( 
.A1(n_123),
.A2(n_78),
.B(n_63),
.Y(n_132)
);

INVx2_ASAP7_75t_SL g133 ( 
.A(n_126),
.Y(n_133)
);

INVxp67_ASAP7_75t_L g134 ( 
.A(n_117),
.Y(n_134)
);

NAND3xp33_ASAP7_75t_L g135 ( 
.A(n_129),
.B(n_117),
.C(n_118),
.Y(n_135)
);

AOI21xp33_ASAP7_75t_L g136 ( 
.A1(n_130),
.A2(n_120),
.B(n_122),
.Y(n_136)
);

AOI21xp5_ASAP7_75t_L g137 ( 
.A1(n_127),
.A2(n_120),
.B(n_61),
.Y(n_137)
);

AOI21xp33_ASAP7_75t_L g138 ( 
.A1(n_131),
.A2(n_9),
.B(n_8),
.Y(n_138)
);

INVx2_ASAP7_75t_L g139 ( 
.A(n_133),
.Y(n_139)
);

INVx1_ASAP7_75t_L g140 ( 
.A(n_134),
.Y(n_140)
);

XOR2xp5_ASAP7_75t_L g141 ( 
.A(n_128),
.B(n_16),
.Y(n_141)
);

AOI21xp5_ASAP7_75t_L g142 ( 
.A1(n_132),
.A2(n_67),
.B(n_61),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_140),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_139),
.Y(n_144)
);

NAND4xp75_ASAP7_75t_L g145 ( 
.A(n_137),
.B(n_55),
.C(n_19),
.D(n_18),
.Y(n_145)
);

NAND4xp75_ASAP7_75t_L g146 ( 
.A(n_136),
.B(n_24),
.C(n_21),
.D(n_20),
.Y(n_146)
);

NAND2xp5_ASAP7_75t_L g147 ( 
.A(n_143),
.B(n_135),
.Y(n_147)
);

AO22x2_ASAP7_75t_L g148 ( 
.A1(n_144),
.A2(n_141),
.B1(n_142),
.B2(n_138),
.Y(n_148)
);

INVx1_ASAP7_75t_SL g149 ( 
.A(n_145),
.Y(n_149)
);

NOR2xp33_ASAP7_75t_SL g150 ( 
.A(n_149),
.B(n_146),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_150),
.Y(n_151)
);

INVxp67_ASAP7_75t_SL g152 ( 
.A(n_151),
.Y(n_152)
);

INVx1_ASAP7_75t_L g153 ( 
.A(n_152),
.Y(n_153)
);

AOI21xp5_ASAP7_75t_L g154 ( 
.A1(n_153),
.A2(n_148),
.B(n_147),
.Y(n_154)
);


endmodule