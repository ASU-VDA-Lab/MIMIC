module fake_netlist_914_1713_n_25 (n_0, n_2, n_5, n_3, n_4, n_1, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_25;

wire n_15;
wire n_11;
wire n_24;
wire n_6;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

NAND2xp33_ASAP7_75t_SL g7 ( 
.A(n_5),
.B(n_1),
.Y(n_7)
);

CKINVDCx16_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_6),
.A2(n_2),
.B(n_1),
.Y(n_10)
);

NOR4xp25_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_3),
.C(n_2),
.D(n_1),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_3),
.B(n_2),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_13),
.Y(n_16)
);

INVxp67_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

AOI221xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_11),
.B1(n_7),
.B2(n_14),
.C(n_15),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_14),
.B1(n_18),
.B2(n_4),
.C(n_0),
.Y(n_20)
);

INVx2_ASAP7_75t_SL g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_14),
.Y(n_23)
);

XOR2x2_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_21),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_22),
.B1(n_21),
.B2(n_23),
.Y(n_25)
);


endmodule