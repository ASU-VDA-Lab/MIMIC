module fake_netlist_914_638_n_25 (n_0, n_2, n_5, n_3, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_25;

wire n_15;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_3),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_8),
.B(n_7),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_12),
.Y(n_20)
);

OAI211xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_15),
.B(n_14),
.C(n_10),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_4),
.B1(n_2),
.B2(n_1),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_6),
.C(n_5),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

AOI22xp33_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_23),
.B1(n_11),
.B2(n_9),
.Y(n_25)
);


endmodule