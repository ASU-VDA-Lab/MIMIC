module fake_netlist_914_2617_n_24 (n_0, n_2, n_3, n_4, n_1, n_24);

input n_0;
input n_2;
input n_3;
input n_4;
input n_1;

output n_24;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_5;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_10;
wire n_8;

INVx2_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_1),
.B(n_2),
.Y(n_6)
);

NAND2xp33_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_3),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_5),
.B(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_5),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_8),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_0),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_11),
.Y(n_16)
);

NOR3xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_7),
.C(n_9),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_13),
.Y(n_18)
);

NOR2x1p5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_14),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_4),
.C(n_3),
.Y(n_20)
);

OAI311xp33_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_4),
.A3(n_3),
.B1(n_0),
.C1(n_1),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_19),
.A2(n_21),
.B1(n_20),
.B2(n_4),
.Y(n_23)
);

OR2x6_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_23),
.Y(n_24)
);


endmodule