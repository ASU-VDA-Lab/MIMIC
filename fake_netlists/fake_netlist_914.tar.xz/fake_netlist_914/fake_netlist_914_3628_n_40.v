module fake_netlist_914_3628_n_40 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_40);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_40;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_39;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_35;
wire n_26;
wire n_29;
wire n_36;
wire n_38;

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_19),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_16),
.B(n_3),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_9),
.B(n_16),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_10),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_13),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_15),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_22),
.A2(n_15),
.B1(n_1),
.B2(n_0),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_29),
.B(n_25),
.Y(n_32)
);

AO31x2_ASAP7_75t_L g33 ( 
.A1(n_30),
.A2(n_26),
.A3(n_24),
.B(n_23),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_21),
.B1(n_31),
.B2(n_27),
.Y(n_36)
);

O2A1O1Ixp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_35),
.B(n_26),
.C(n_33),
.Y(n_37)
);

XOR2xp5_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_6),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_11),
.B1(n_8),
.B2(n_7),
.Y(n_39)
);

OAI31xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_18),
.A3(n_17),
.B(n_14),
.Y(n_40)
);


endmodule