module fake_netlist_914_2127_n_67 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_67);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_67;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_63;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_64;
wire n_53;
wire n_66;
wire n_65;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_21;
wire n_32;
wire n_25;
wire n_22;
wire n_41;
wire n_35;
wire n_42;
wire n_57;
wire n_43;
wire n_62;
wire n_26;
wire n_44;
wire n_45;
wire n_48;
wire n_29;
wire n_36;
wire n_38;
wire n_56;

INVx2_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_2),
.Y(n_22)
);

BUFx6f_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_10),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_5),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_3),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_4),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_14),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_8),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_16),
.Y(n_30)
);

BUFx8_ASAP7_75t_L g31 ( 
.A(n_17),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_18),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_25),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_21),
.B(n_14),
.Y(n_34)
);

NOR3xp33_ASAP7_75t_SL g35 ( 
.A(n_30),
.B(n_16),
.C(n_15),
.Y(n_35)
);

AND2x6_ASAP7_75t_SL g36 ( 
.A(n_32),
.B(n_15),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_21),
.B(n_17),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_20),
.B(n_18),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_28),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_33),
.B(n_40),
.Y(n_41)
);

BUFx2_ASAP7_75t_L g42 ( 
.A(n_37),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_33),
.Y(n_44)
);

AOI21xp5_ASAP7_75t_L g45 ( 
.A1(n_39),
.A2(n_24),
.B(n_22),
.Y(n_45)
);

OAI221xp5_ASAP7_75t_L g46 ( 
.A1(n_41),
.A2(n_35),
.B1(n_38),
.B2(n_34),
.C(n_26),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_42),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_42),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_47),
.Y(n_51)
);

NAND3xp33_ASAP7_75t_L g52 ( 
.A(n_46),
.B(n_45),
.C(n_31),
.Y(n_52)
);

OAI21xp33_ASAP7_75t_L g53 ( 
.A1(n_48),
.A2(n_29),
.B(n_27),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_SL g54 ( 
.A(n_51),
.B(n_27),
.Y(n_54)
);

AND2x2_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_53),
.Y(n_55)
);

OR2x2_ASAP7_75t_L g56 ( 
.A(n_52),
.B(n_46),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_54),
.Y(n_57)
);

AOI222xp33_ASAP7_75t_L g58 ( 
.A1(n_54),
.A2(n_36),
.B1(n_23),
.B2(n_21),
.C1(n_1),
.C2(n_0),
.Y(n_58)
);

INVx3_ASAP7_75t_L g59 ( 
.A(n_56),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_55),
.Y(n_60)
);

INVxp33_ASAP7_75t_SL g61 ( 
.A(n_57),
.Y(n_61)
);

NAND5xp2_ASAP7_75t_L g62 ( 
.A(n_58),
.B(n_23),
.C(n_11),
.D(n_7),
.E(n_9),
.Y(n_62)
);

BUFx2_ASAP7_75t_L g63 ( 
.A(n_57),
.Y(n_63)
);

OAI21xp33_ASAP7_75t_L g64 ( 
.A1(n_59),
.A2(n_23),
.B(n_12),
.Y(n_64)
);

AND2x4_ASAP7_75t_L g65 ( 
.A(n_63),
.B(n_59),
.Y(n_65)
);

XNOR2xp5_ASAP7_75t_L g66 ( 
.A(n_61),
.B(n_60),
.Y(n_66)
);

AOI22xp33_ASAP7_75t_L g67 ( 
.A1(n_65),
.A2(n_64),
.B1(n_66),
.B2(n_62),
.Y(n_67)
);


endmodule