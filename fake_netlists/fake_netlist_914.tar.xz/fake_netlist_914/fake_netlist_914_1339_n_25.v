module fake_netlist_914_1339_n_25 (n_0, n_2, n_5, n_3, n_4, n_8, n_6, n_1, n_7, n_25);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_25;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_10;

INVx3_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

BUFx6f_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_6),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_2),
.Y(n_12)
);

NOR2x1_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_5),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_5),
.B1(n_4),
.B2(n_3),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_6),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_11),
.B1(n_9),
.B2(n_13),
.Y(n_16)
);

BUFx3_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_16),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_12),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_10),
.Y(n_21)
);

INVx1_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

O2A1O1Ixp33_ASAP7_75t_L g23 ( 
.A1(n_21),
.A2(n_10),
.B(n_1),
.C(n_0),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.C(n_22),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);


endmodule