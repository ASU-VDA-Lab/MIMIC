module fake_netlist_914_3586_n_37 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_37);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_37;

wire n_33;
wire n_34;
wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_20;
wire n_31;
wire n_21;
wire n_32;
wire n_22;
wire n_25;
wire n_35;
wire n_26;
wire n_36;
wire n_29;

INVx2_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_0),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

NAND2xp33_ASAP7_75t_SL g24 ( 
.A(n_12),
.B(n_19),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_R g25 ( 
.A(n_4),
.B(n_2),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

AOI21xp5_ASAP7_75t_L g27 ( 
.A1(n_20),
.A2(n_3),
.B(n_1),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_22),
.B(n_19),
.Y(n_28)
);

OA22x2_ASAP7_75t_L g29 ( 
.A1(n_24),
.A2(n_8),
.B1(n_7),
.B2(n_5),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_23),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_26),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_21),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

AOI221xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_30),
.B1(n_27),
.B2(n_25),
.C(n_9),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

OAI222xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_13),
.B1(n_10),
.B2(n_14),
.C1(n_16),
.C2(n_15),
.Y(n_37)
);


endmodule