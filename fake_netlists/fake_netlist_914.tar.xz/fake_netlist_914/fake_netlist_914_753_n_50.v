module fake_netlist_914_753_n_50 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_14, n_2, n_10, n_8, n_50);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_14;
input n_2;
input n_10;
input n_8;

output n_50;

wire n_33;
wire n_34;
wire n_24;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_28;
wire n_27;
wire n_49;
wire n_40;
wire n_39;
wire n_31;
wire n_32;
wire n_22;
wire n_35;
wire n_41;
wire n_42;
wire n_25;
wire n_43;
wire n_26;
wire n_29;
wire n_36;
wire n_45;
wire n_44;
wire n_48;
wire n_38;

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_5),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_8),
.B(n_13),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_14),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_12),
.Y(n_25)
);

OA21x2_ASAP7_75t_L g26 ( 
.A1(n_7),
.A2(n_6),
.B(n_18),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_4),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_1),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_9),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_10),
.B(n_16),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_11),
.A2(n_15),
.B1(n_19),
.B2(n_0),
.Y(n_31)
);

BUFx3_ASAP7_75t_L g32 ( 
.A(n_28),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_28),
.B(n_18),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_23),
.B(n_19),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_23),
.Y(n_36)
);

OR2x6_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_31),
.Y(n_37)
);

AND2x6_ASAP7_75t_SL g38 ( 
.A(n_37),
.B(n_33),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_32),
.B1(n_26),
.B2(n_22),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_38),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_39),
.B(n_36),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_SL g43 ( 
.A(n_40),
.Y(n_43)
);

OAI21xp5_ASAP7_75t_SL g44 ( 
.A1(n_43),
.A2(n_42),
.B(n_30),
.Y(n_44)
);

NOR2x1p5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_24),
.Y(n_45)
);

CKINVDCx5p33_ASAP7_75t_R g46 ( 
.A(n_45),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_44),
.Y(n_47)
);

AOI22xp5_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_26),
.B1(n_27),
.B2(n_25),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_46),
.B(n_2),
.Y(n_49)
);

AOI222xp33_ASAP7_75t_L g50 ( 
.A1(n_49),
.A2(n_3),
.B1(n_17),
.B2(n_20),
.C1(n_21),
.C2(n_48),
.Y(n_50)
);


endmodule