module fake_netlist_914_200_n_14 (n_0, n_1, n_3, n_2, n_14);

input n_0;
input n_1;
input n_3;
input n_2;

output n_14;

wire n_5;
wire n_11;
wire n_10;
wire n_9;
wire n_4;
wire n_8;
wire n_6;
wire n_13;
wire n_7;
wire n_12;

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

NOR2xp67_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_0),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_9),
.B2(n_0),
.C(n_1),
.Y(n_11)
);

AOI321xp33_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_1),
.A3(n_2),
.B1(n_3),
.B2(n_6),
.C(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI31xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.A3(n_2),
.B(n_6),
.Y(n_14)
);


endmodule