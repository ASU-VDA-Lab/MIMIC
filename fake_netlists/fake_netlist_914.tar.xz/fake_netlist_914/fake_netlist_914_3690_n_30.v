module fake_netlist_914_3690_n_30 (n_0, n_2, n_5, n_3, n_4, n_1, n_30);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_30;

wire n_15;
wire n_11;
wire n_24;
wire n_6;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_9;
wire n_18;
wire n_17;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;
wire n_29;
wire n_8;

INVx2_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_1),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_4),
.B(n_0),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_4),
.B(n_1),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_13),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_13),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_8),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_9),
.Y(n_19)
);

NOR2xp67_ASAP7_75t_SL g20 ( 
.A(n_15),
.B(n_14),
.Y(n_20)
);

OR2x2_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_9),
.Y(n_21)
);

OAI22xp5_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_15),
.B1(n_16),
.B2(n_8),
.Y(n_22)
);

NAND4xp75_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_6),
.C(n_4),
.D(n_1),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_6),
.B1(n_5),
.B2(n_3),
.Y(n_24)
);

AND4x1_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_3),
.C(n_5),
.D(n_23),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_5),
.Y(n_26)
);

BUFx4f_ASAP7_75t_SL g27 ( 
.A(n_24),
.Y(n_27)
);

OAI21xp5_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_25),
.B(n_27),
.Y(n_28)
);

INVxp67_ASAP7_75t_SL g29 ( 
.A(n_25),
.Y(n_29)
);

NAND2xp5_ASAP7_75t_SL g30 ( 
.A(n_28),
.B(n_29),
.Y(n_30)
);


endmodule