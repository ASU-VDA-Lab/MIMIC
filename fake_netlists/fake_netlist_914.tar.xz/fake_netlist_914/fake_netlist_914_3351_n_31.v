module fake_netlist_914_3351_n_31 (n_0, n_2, n_5, n_3, n_16, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_31);

input n_0;
input n_2;
input n_5;
input n_3;
input n_16;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_31;

wire n_24;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_21;
wire n_25;
wire n_22;
wire n_26;
wire n_29;

BUFx10_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_8),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_16),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

A2O1A1Ixp33_ASAP7_75t_SL g23 ( 
.A1(n_17),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_18),
.B(n_4),
.Y(n_24)
);

NAND2xp33_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_20),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_17),
.Y(n_26)
);

OAI32xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_22),
.A3(n_21),
.B1(n_19),
.B2(n_23),
.Y(n_27)
);

OAI211xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_28)
);

OR2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_10),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_14),
.B1(n_13),
.B2(n_11),
.Y(n_31)
);


endmodule