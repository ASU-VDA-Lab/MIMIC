module fake_netlist_914_1404_n_63 (n_3, n_15, n_11, n_24, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_26, n_10, n_8, n_63);

input n_3;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_26;
input n_10;
input n_8;

output n_63;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_54;
wire n_28;
wire n_53;
wire n_59;
wire n_49;
wire n_58;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_42;
wire n_32;
wire n_35;
wire n_41;
wire n_57;
wire n_43;
wire n_62;
wire n_44;
wire n_36;
wire n_29;
wire n_45;
wire n_48;
wire n_38;
wire n_56;

INVx1_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_12),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_0),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_9),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_11),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_25),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_6),
.Y(n_35)
);

CKINVDCx8_ASAP7_75t_R g36 ( 
.A(n_16),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_17),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_1),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_5),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_34),
.Y(n_40)
);

INVx3_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

NOR3xp33_ASAP7_75t_SL g42 ( 
.A(n_33),
.B(n_24),
.C(n_2),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_30),
.B(n_28),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_31),
.Y(n_44)
);

AOI22xp33_ASAP7_75t_L g45 ( 
.A1(n_40),
.A2(n_38),
.B1(n_29),
.B2(n_32),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

INVx2_ASAP7_75t_SL g47 ( 
.A(n_43),
.Y(n_47)
);

AND2x4_ASAP7_75t_L g48 ( 
.A(n_47),
.B(n_41),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_46),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_49),
.B(n_41),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_48),
.Y(n_51)
);

INVxp67_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

OR2x2_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_24),
.Y(n_53)
);

AND2x2_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_42),
.Y(n_54)
);

NOR2xp33_ASAP7_75t_R g55 ( 
.A(n_53),
.B(n_37),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

AOI322xp5_ASAP7_75t_L g57 ( 
.A1(n_54),
.A2(n_42),
.A3(n_35),
.B1(n_39),
.B2(n_4),
.C1(n_3),
.C2(n_7),
.Y(n_57)
);

OR3x2_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_10),
.C(n_8),
.Y(n_58)
);

AOI211xp5_ASAP7_75t_L g59 ( 
.A1(n_55),
.A2(n_35),
.B(n_14),
.C(n_13),
.Y(n_59)
);

OAI211xp5_ASAP7_75t_L g60 ( 
.A1(n_57),
.A2(n_35),
.B(n_19),
.C(n_18),
.Y(n_60)
);

OAI22xp5_ASAP7_75t_SL g61 ( 
.A1(n_59),
.A2(n_22),
.B1(n_21),
.B2(n_20),
.Y(n_61)
);

OR2x2_ASAP7_75t_L g62 ( 
.A(n_60),
.B(n_58),
.Y(n_62)
);

OAI221xp5_ASAP7_75t_R g63 ( 
.A1(n_62),
.A2(n_23),
.B1(n_26),
.B2(n_27),
.C(n_61),
.Y(n_63)
);


endmodule