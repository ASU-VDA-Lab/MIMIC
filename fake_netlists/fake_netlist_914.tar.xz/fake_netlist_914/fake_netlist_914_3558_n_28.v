module fake_netlist_914_3558_n_28 (n_0, n_2, n_5, n_3, n_4, n_6, n_1, n_28);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_6;
input n_1;

output n_28;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;
wire n_8;

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_2),
.B(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

INVx2_ASAP7_75t_L g10 ( 
.A(n_3),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

A2O1A1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_10),
.B(n_8),
.C(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_1),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_11),
.B(n_1),
.Y(n_15)
);

NOR4xp25_ASAP7_75t_SL g16 ( 
.A(n_12),
.B(n_6),
.C(n_4),
.D(n_0),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_11),
.Y(n_17)
);

A2O1A1Ixp33_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_6),
.B(n_4),
.C(n_0),
.Y(n_18)
);

AND2x2_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_6),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_16),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_18),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

NAND3x1_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_16),
.C(n_3),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_23),
.A2(n_22),
.B(n_5),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_23),
.A2(n_20),
.B1(n_21),
.B2(n_24),
.Y(n_27)
);

AO21x2_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_25),
.B(n_26),
.Y(n_28)
);


endmodule