module fake_netlist_914_3038_n_153 (n_3, n_33, n_15, n_11, n_24, n_6, n_16, n_0, n_30, n_23, n_28, n_4, n_19, n_12, n_5, n_27, n_20, n_9, n_17, n_18, n_31, n_1, n_13, n_7, n_21, n_22, n_14, n_25, n_2, n_32, n_26, n_10, n_29, n_8, n_153);

input n_3;
input n_33;
input n_15;
input n_11;
input n_24;
input n_6;
input n_16;
input n_0;
input n_30;
input n_23;
input n_28;
input n_4;
input n_19;
input n_12;
input n_5;
input n_27;
input n_20;
input n_9;
input n_17;
input n_18;
input n_31;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_25;
input n_2;
input n_32;
input n_26;
input n_10;
input n_29;
input n_8;

output n_153;

wire n_118;
wire n_100;
wire n_60;
wire n_104;
wire n_101;
wire n_99;
wire n_52;
wire n_127;
wire n_151;
wire n_152;
wire n_111;
wire n_116;
wire n_64;
wire n_102;
wire n_93;
wire n_66;
wire n_65;
wire n_143;
wire n_88;
wire n_94;
wire n_91;
wire n_71;
wire n_135;
wire n_80;
wire n_149;
wire n_69;
wire n_83;
wire n_134;
wire n_96;
wire n_128;
wire n_117;
wire n_131;
wire n_51;
wire n_50;
wire n_55;
wire n_123;
wire n_110;
wire n_46;
wire n_144;
wire n_54;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_132;
wire n_42;
wire n_41;
wire n_126;
wire n_62;
wire n_120;
wire n_148;
wire n_150;
wire n_141;
wire n_44;
wire n_79;
wire n_87;
wire n_142;
wire n_115;
wire n_113;
wire n_129;
wire n_77;
wire n_107;
wire n_95;
wire n_53;
wire n_106;
wire n_137;
wire n_90;
wire n_146;
wire n_81;
wire n_84;
wire n_140;
wire n_61;
wire n_130;
wire n_122;
wire n_43;
wire n_138;
wire n_136;
wire n_139;
wire n_72;
wire n_48;
wire n_133;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_125;
wire n_34;
wire n_103;
wire n_37;
wire n_108;
wire n_75;
wire n_47;
wire n_68;
wire n_86;
wire n_63;
wire n_105;
wire n_114;
wire n_124;
wire n_145;
wire n_85;
wire n_112;
wire n_58;
wire n_49;
wire n_109;
wire n_147;
wire n_67;
wire n_35;
wire n_57;
wire n_121;
wire n_98;
wire n_97;
wire n_119;
wire n_36;
wire n_45;
wire n_73;
wire n_92;
wire n_89;
wire n_82;
wire n_78;

INVx2_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_17),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_16),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_13),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_27),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_5),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_14),
.Y(n_40)
);

BUFx3_ASAP7_75t_L g41 ( 
.A(n_11),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_12),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_6),
.B(n_23),
.Y(n_43)
);

HB1xp67_ASAP7_75t_L g44 ( 
.A(n_33),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_31),
.Y(n_45)
);

INVxp33_ASAP7_75t_L g46 ( 
.A(n_25),
.Y(n_46)
);

NOR2xp33_ASAP7_75t_L g47 ( 
.A(n_15),
.B(n_18),
.Y(n_47)
);

INVxp33_ASAP7_75t_L g48 ( 
.A(n_4),
.Y(n_48)
);

BUFx2_ASAP7_75t_SL g49 ( 
.A(n_7),
.Y(n_49)
);

INVx2_ASAP7_75t_SL g50 ( 
.A(n_10),
.Y(n_50)
);

BUFx2_ASAP7_75t_L g51 ( 
.A(n_6),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_29),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_26),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_19),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_35),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_34),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_35),
.Y(n_57)
);

OAI21x1_ASAP7_75t_L g58 ( 
.A1(n_34),
.A2(n_9),
.B(n_8),
.Y(n_58)
);

INVx2_ASAP7_75t_L g59 ( 
.A(n_45),
.Y(n_59)
);

BUFx8_ASAP7_75t_L g60 ( 
.A(n_50),
.Y(n_60)
);

AND2x4_ASAP7_75t_L g61 ( 
.A(n_50),
.B(n_0),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_51),
.B(n_1),
.Y(n_62)
);

BUFx6f_ASAP7_75t_L g63 ( 
.A(n_45),
.Y(n_63)
);

BUFx6f_ASAP7_75t_L g64 ( 
.A(n_41),
.Y(n_64)
);

NAND2xp5_ASAP7_75t_SL g65 ( 
.A(n_46),
.B(n_1),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_51),
.B(n_2),
.Y(n_66)
);

NAND2xp5_ASAP7_75t_L g67 ( 
.A(n_44),
.B(n_2),
.Y(n_67)
);

INVx3_ASAP7_75t_L g68 ( 
.A(n_36),
.Y(n_68)
);

AND2x2_ASAP7_75t_L g69 ( 
.A(n_48),
.B(n_3),
.Y(n_69)
);

INVx2_ASAP7_75t_L g70 ( 
.A(n_36),
.Y(n_70)
);

AO22x2_ASAP7_75t_L g71 ( 
.A1(n_61),
.A2(n_43),
.B1(n_38),
.B2(n_37),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_70),
.Y(n_72)
);

INVx2_ASAP7_75t_SL g73 ( 
.A(n_60),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_70),
.Y(n_74)
);

BUFx6f_ASAP7_75t_L g75 ( 
.A(n_58),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_55),
.B(n_57),
.Y(n_76)
);

BUFx6f_ASAP7_75t_L g77 ( 
.A(n_58),
.Y(n_77)
);

INVx1_ASAP7_75t_L g78 ( 
.A(n_70),
.Y(n_78)
);

NAND3x1_ASAP7_75t_L g79 ( 
.A(n_62),
.B(n_38),
.C(n_37),
.Y(n_79)
);

INVx2_ASAP7_75t_L g80 ( 
.A(n_63),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_63),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_68),
.Y(n_82)
);

OR2x2_ASAP7_75t_SL g83 ( 
.A(n_62),
.B(n_43),
.Y(n_83)
);

AND2x6_ASAP7_75t_L g84 ( 
.A(n_61),
.B(n_40),
.Y(n_84)
);

BUFx3_ASAP7_75t_L g85 ( 
.A(n_73),
.Y(n_85)
);

NAND2xp5_ASAP7_75t_SL g86 ( 
.A(n_73),
.B(n_61),
.Y(n_86)
);

NAND2xp5_ASAP7_75t_L g87 ( 
.A(n_76),
.B(n_57),
.Y(n_87)
);

AOI22xp5_ASAP7_75t_L g88 ( 
.A1(n_71),
.A2(n_69),
.B1(n_57),
.B2(n_66),
.Y(n_88)
);

AOI22xp33_ASAP7_75t_L g89 ( 
.A1(n_84),
.A2(n_68),
.B1(n_59),
.B2(n_56),
.Y(n_89)
);

INVx1_ASAP7_75t_L g90 ( 
.A(n_72),
.Y(n_90)
);

BUFx2_ASAP7_75t_L g91 ( 
.A(n_71),
.Y(n_91)
);

HB1xp67_ASAP7_75t_L g92 ( 
.A(n_71),
.Y(n_92)
);

INVx2_ASAP7_75t_L g93 ( 
.A(n_74),
.Y(n_93)
);

OR2x6_ASAP7_75t_L g94 ( 
.A(n_71),
.B(n_79),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_78),
.Y(n_95)
);

AOI22xp5_ASAP7_75t_L g96 ( 
.A1(n_79),
.A2(n_67),
.B1(n_65),
.B2(n_39),
.Y(n_96)
);

NAND2xp5_ASAP7_75t_L g97 ( 
.A(n_84),
.B(n_60),
.Y(n_97)
);

INVx4_ASAP7_75t_L g98 ( 
.A(n_75),
.Y(n_98)
);

INVx2_ASAP7_75t_L g99 ( 
.A(n_75),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_75),
.Y(n_100)
);

INVx2_ASAP7_75t_L g101 ( 
.A(n_75),
.Y(n_101)
);

NOR2xp33_ASAP7_75t_SL g102 ( 
.A(n_75),
.B(n_42),
.Y(n_102)
);

BUFx6f_ASAP7_75t_L g103 ( 
.A(n_77),
.Y(n_103)
);

OR2x6_ASAP7_75t_L g104 ( 
.A(n_91),
.B(n_49),
.Y(n_104)
);

AOI21xp5_ASAP7_75t_L g105 ( 
.A1(n_86),
.A2(n_77),
.B(n_82),
.Y(n_105)
);

OAI22xp5_ASAP7_75t_L g106 ( 
.A1(n_88),
.A2(n_83),
.B1(n_59),
.B2(n_56),
.Y(n_106)
);

OAI22xp5_ASAP7_75t_L g107 ( 
.A1(n_88),
.A2(n_59),
.B1(n_56),
.B2(n_77),
.Y(n_107)
);

INVx2_ASAP7_75t_L g108 ( 
.A(n_93),
.Y(n_108)
);

BUFx4f_ASAP7_75t_L g109 ( 
.A(n_94),
.Y(n_109)
);

AOI21xp5_ASAP7_75t_L g110 ( 
.A1(n_85),
.A2(n_81),
.B(n_80),
.Y(n_110)
);

AOI21xp5_ASAP7_75t_L g111 ( 
.A1(n_85),
.A2(n_81),
.B(n_80),
.Y(n_111)
);

BUFx2_ASAP7_75t_L g112 ( 
.A(n_94),
.Y(n_112)
);

OAI22xp5_ASAP7_75t_L g113 ( 
.A1(n_92),
.A2(n_87),
.B1(n_96),
.B2(n_89),
.Y(n_113)
);

INVx5_ASAP7_75t_L g114 ( 
.A(n_98),
.Y(n_114)
);

OAI22xp5_ASAP7_75t_L g115 ( 
.A1(n_109),
.A2(n_95),
.B1(n_89),
.B2(n_90),
.Y(n_115)
);

INVx2_ASAP7_75t_L g116 ( 
.A(n_108),
.Y(n_116)
);

NAND2xp33_ASAP7_75t_R g117 ( 
.A(n_104),
.B(n_112),
.Y(n_117)
);

AOI21xp5_ASAP7_75t_L g118 ( 
.A1(n_105),
.A2(n_100),
.B(n_99),
.Y(n_118)
);

NAND2xp33_ASAP7_75t_R g119 ( 
.A(n_104),
.B(n_101),
.Y(n_119)
);

AND2x4_ASAP7_75t_L g120 ( 
.A(n_114),
.B(n_98),
.Y(n_120)
);

AOI21xp33_ASAP7_75t_L g121 ( 
.A1(n_113),
.A2(n_97),
.B(n_102),
.Y(n_121)
);

NAND2xp5_ASAP7_75t_L g122 ( 
.A(n_106),
.B(n_103),
.Y(n_122)
);

AO31x2_ASAP7_75t_L g123 ( 
.A1(n_107),
.A2(n_54),
.A3(n_53),
.B(n_52),
.Y(n_123)
);

AOI21xp5_ASAP7_75t_L g124 ( 
.A1(n_111),
.A2(n_103),
.B(n_47),
.Y(n_124)
);

OAI21x1_ASAP7_75t_L g125 ( 
.A1(n_110),
.A2(n_63),
.B(n_64),
.Y(n_125)
);

BUFx6f_ASAP7_75t_L g126 ( 
.A(n_120),
.Y(n_126)
);

INVx2_ASAP7_75t_L g127 ( 
.A(n_116),
.Y(n_127)
);

AOI21xp5_ASAP7_75t_L g128 ( 
.A1(n_124),
.A2(n_21),
.B(n_20),
.Y(n_128)
);

AO21x2_ASAP7_75t_L g129 ( 
.A1(n_121),
.A2(n_24),
.B(n_22),
.Y(n_129)
);

OAI22xp33_ASAP7_75t_L g130 ( 
.A1(n_119),
.A2(n_117),
.B1(n_122),
.B2(n_115),
.Y(n_130)
);

AOI21xp5_ASAP7_75t_L g131 ( 
.A1(n_118),
.A2(n_32),
.B(n_30),
.Y(n_131)
);

AO21x2_ASAP7_75t_L g132 ( 
.A1(n_130),
.A2(n_125),
.B(n_123),
.Y(n_132)
);

BUFx3_ASAP7_75t_L g133 ( 
.A(n_126),
.Y(n_133)
);

BUFx3_ASAP7_75t_L g134 ( 
.A(n_126),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_127),
.Y(n_135)
);

AO21x2_ASAP7_75t_L g136 ( 
.A1(n_129),
.A2(n_128),
.B(n_131),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_135),
.Y(n_137)
);

INVx2_ASAP7_75t_L g138 ( 
.A(n_132),
.Y(n_138)
);

INVx2_ASAP7_75t_L g139 ( 
.A(n_136),
.Y(n_139)
);

INVx2_ASAP7_75t_L g140 ( 
.A(n_136),
.Y(n_140)
);

AND2x2_ASAP7_75t_L g141 ( 
.A(n_133),
.B(n_134),
.Y(n_141)
);

INVx1_ASAP7_75t_L g142 ( 
.A(n_137),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_142),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_143),
.Y(n_144)
);

INVx1_ASAP7_75t_L g145 ( 
.A(n_144),
.Y(n_145)
);

INVx1_ASAP7_75t_L g146 ( 
.A(n_145),
.Y(n_146)
);

INVx1_ASAP7_75t_L g147 ( 
.A(n_146),
.Y(n_147)
);

CKINVDCx5p33_ASAP7_75t_R g148 ( 
.A(n_147),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_148),
.Y(n_149)
);

INVxp67_ASAP7_75t_L g150 ( 
.A(n_149),
.Y(n_150)
);

INVx1_ASAP7_75t_SL g151 ( 
.A(n_150),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_151),
.Y(n_152)
);

AOI221xp5_ASAP7_75t_L g153 ( 
.A1(n_152),
.A2(n_139),
.B1(n_140),
.B2(n_138),
.C(n_141),
.Y(n_153)
);


endmodule