module fake_netlist_914_3472_n_30 (n_0, n_2, n_5, n_3, n_15, n_11, n_10, n_9, n_4, n_8, n_6, n_1, n_13, n_7, n_12, n_14, n_30);

input n_0;
input n_2;
input n_5;
input n_3;
input n_15;
input n_11;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_13;
input n_7;
input n_12;
input n_14;

output n_30;

wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_25;
wire n_22;
wire n_26;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_14),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

INVx3_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_3),
.B(n_2),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

OAI22xp33_ASAP7_75t_L g21 ( 
.A1(n_11),
.A2(n_7),
.B1(n_8),
.B2(n_15),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_SL g22 ( 
.A1(n_18),
.A2(n_5),
.B(n_4),
.C(n_0),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_17),
.B(n_10),
.Y(n_23)
);

CKINVDCx16_ASAP7_75t_R g24 ( 
.A(n_23),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_16),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx2_ASAP7_75t_SL g28 ( 
.A(n_27),
.Y(n_28)
);

OAI22x1_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_20),
.B1(n_21),
.B2(n_19),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_13),
.B1(n_12),
.B2(n_22),
.Y(n_30)
);


endmodule