module fake_netlist_914_1332_n_29 (n_0, n_2, n_5, n_3, n_9, n_4, n_8, n_6, n_1, n_7, n_29);

input n_0;
input n_2;
input n_5;
input n_3;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_29;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_18;
wire n_17;
wire n_21;
wire n_13;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_10;

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_8),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_4),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_5),
.B(n_2),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_6),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_SL g15 ( 
.A(n_10),
.B(n_7),
.C(n_6),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_13),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_13),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_16),
.B(n_15),
.C(n_12),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_17),
.B(n_15),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_11),
.Y(n_21)
);

CKINVDCx16_ASAP7_75t_R g22 ( 
.A(n_19),
.Y(n_22)
);

OAI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_11),
.B1(n_12),
.B2(n_6),
.Y(n_23)
);

OAI311xp33_ASAP7_75t_L g24 ( 
.A1(n_21),
.A2(n_1),
.A3(n_0),
.B1(n_2),
.C1(n_3),
.Y(n_24)
);

OAI221xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_1),
.B1(n_0),
.B2(n_3),
.C(n_4),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_8),
.B(n_5),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_9),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_9),
.B1(n_24),
.B2(n_27),
.Y(n_29)
);


endmodule