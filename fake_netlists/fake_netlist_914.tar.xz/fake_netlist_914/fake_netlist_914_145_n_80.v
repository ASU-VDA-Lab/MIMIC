module fake_netlist_914_145_n_80 (n_3, n_15, n_11, n_6, n_16, n_0, n_23, n_4, n_19, n_12, n_5, n_20, n_9, n_17, n_18, n_1, n_13, n_7, n_21, n_22, n_14, n_2, n_10, n_8, n_80);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_23;
input n_4;
input n_19;
input n_12;
input n_5;
input n_20;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_21;
input n_22;
input n_14;
input n_2;
input n_10;
input n_8;

output n_80;

wire n_60;
wire n_52;
wire n_30;
wire n_64;
wire n_66;
wire n_65;
wire n_27;
wire n_71;
wire n_29;
wire n_69;
wire n_51;
wire n_50;
wire n_55;
wire n_46;
wire n_54;
wire n_28;
wire n_59;
wire n_70;
wire n_40;
wire n_39;
wire n_31;
wire n_42;
wire n_32;
wire n_41;
wire n_62;
wire n_26;
wire n_44;
wire n_79;
wire n_33;
wire n_24;
wire n_77;
wire n_53;
wire n_61;
wire n_43;
wire n_48;
wire n_72;
wire n_76;
wire n_38;
wire n_56;
wire n_74;
wire n_34;
wire n_37;
wire n_75;
wire n_47;
wire n_68;
wire n_63;
wire n_49;
wire n_58;
wire n_67;
wire n_25;
wire n_35;
wire n_57;
wire n_36;
wire n_45;
wire n_73;
wire n_78;

INVx1_ASAP7_75t_L g24 ( 
.A(n_20),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_21),
.B(n_10),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_17),
.B(n_21),
.Y(n_31)
);

NAND3xp33_ASAP7_75t_L g32 ( 
.A(n_14),
.B(n_23),
.C(n_22),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_1),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_12),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_19),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_14),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_8),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_5),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_18),
.B(n_3),
.Y(n_39)
);

INVxp67_ASAP7_75t_SL g40 ( 
.A(n_29),
.Y(n_40)
);

INVx4_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_39),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_R g43 ( 
.A(n_25),
.B(n_0),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_30),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_35),
.A2(n_17),
.B1(n_16),
.B2(n_15),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_SL g46 ( 
.A(n_30),
.B(n_15),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_29),
.B(n_16),
.Y(n_47)
);

AO21x2_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_26),
.B(n_31),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_L g49 ( 
.A(n_41),
.B(n_33),
.Y(n_49)
);

AOI22xp33_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_35),
.B1(n_28),
.B2(n_24),
.Y(n_50)
);

OAI21x1_ASAP7_75t_L g51 ( 
.A1(n_44),
.A2(n_34),
.B(n_33),
.Y(n_51)
);

NOR2x1_ASAP7_75t_SL g52 ( 
.A(n_41),
.B(n_38),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_41),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_52),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_49),
.B(n_42),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_51),
.Y(n_56)
);

NAND2xp5_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_42),
.Y(n_57)
);

NAND2x1p5_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_45),
.Y(n_58)
);

NAND2xp5_ASAP7_75t_L g59 ( 
.A(n_53),
.B(n_52),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_54),
.B(n_50),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_59),
.Y(n_61)
);

OAI21xp5_ASAP7_75t_SL g62 ( 
.A1(n_58),
.A2(n_45),
.B(n_47),
.Y(n_62)
);

OAI22xp33_ASAP7_75t_L g63 ( 
.A1(n_57),
.A2(n_56),
.B1(n_49),
.B2(n_32),
.Y(n_63)
);

OAI322xp33_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_36),
.A3(n_40),
.B1(n_44),
.B2(n_38),
.C1(n_27),
.C2(n_37),
.Y(n_64)
);

OAI31xp33_ASAP7_75t_L g65 ( 
.A1(n_58),
.A2(n_56),
.A3(n_34),
.B(n_48),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_62),
.B(n_48),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_61),
.Y(n_67)
);

AOI21xp33_ASAP7_75t_L g68 ( 
.A1(n_63),
.A2(n_48),
.B(n_51),
.Y(n_68)
);

AOI22xp5_ASAP7_75t_L g69 ( 
.A1(n_61),
.A2(n_48),
.B1(n_51),
.B2(n_43),
.Y(n_69)
);

INVxp67_ASAP7_75t_SL g70 ( 
.A(n_65),
.Y(n_70)
);

OAI31xp33_ASAP7_75t_L g71 ( 
.A1(n_64),
.A2(n_23),
.A3(n_19),
.B(n_18),
.Y(n_71)
);

NOR4xp75_ASAP7_75t_L g72 ( 
.A(n_71),
.B(n_7),
.C(n_6),
.D(n_4),
.Y(n_72)
);

NOR2xp67_ASAP7_75t_L g73 ( 
.A(n_67),
.B(n_9),
.Y(n_73)
);

OR2x2_ASAP7_75t_L g74 ( 
.A(n_70),
.B(n_69),
.Y(n_74)
);

CKINVDCx20_ASAP7_75t_R g75 ( 
.A(n_74),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_73),
.Y(n_76)
);

AND2x2_ASAP7_75t_SL g77 ( 
.A(n_74),
.B(n_68),
.Y(n_77)
);

INVx4_ASAP7_75t_L g78 ( 
.A(n_72),
.Y(n_78)
);

O2A1O1Ixp33_ASAP7_75t_SL g79 ( 
.A1(n_75),
.A2(n_66),
.B(n_45),
.C(n_76),
.Y(n_79)
);

OAI21xp5_ASAP7_75t_L g80 ( 
.A1(n_79),
.A2(n_77),
.B(n_78),
.Y(n_80)
);


endmodule