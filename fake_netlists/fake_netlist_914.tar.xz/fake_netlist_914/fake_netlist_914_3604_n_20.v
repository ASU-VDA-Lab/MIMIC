module fake_netlist_914_3604_n_20 (n_0, n_2, n_5, n_3, n_4, n_1, n_20);

input n_0;
input n_2;
input n_5;
input n_3;
input n_4;
input n_1;

output n_20;

wire n_15;
wire n_11;
wire n_6;
wire n_16;
wire n_19;
wire n_12;
wire n_9;
wire n_17;
wire n_18;
wire n_13;
wire n_7;
wire n_14;
wire n_10;
wire n_8;

INVxp67_ASAP7_75t_SL g6 ( 
.A(n_2),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

O2A1O1Ixp33_ASAP7_75t_SL g10 ( 
.A1(n_7),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

INVx3_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_8),
.Y(n_14)
);

NOR3xp33_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_10),
.C(n_12),
.Y(n_15)
);

OAI21xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_11),
.B(n_6),
.Y(n_16)
);

OA21x2_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B(n_11),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_16),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_5),
.B(n_18),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);


endmodule