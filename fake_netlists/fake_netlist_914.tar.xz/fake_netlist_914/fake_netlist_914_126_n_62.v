module fake_netlist_914_126_n_62 (n_3, n_15, n_11, n_6, n_16, n_0, n_4, n_19, n_12, n_5, n_9, n_17, n_18, n_1, n_13, n_7, n_14, n_2, n_10, n_8, n_62);

input n_3;
input n_15;
input n_11;
input n_6;
input n_16;
input n_0;
input n_4;
input n_19;
input n_12;
input n_5;
input n_9;
input n_17;
input n_18;
input n_1;
input n_13;
input n_7;
input n_14;
input n_2;
input n_10;
input n_8;

output n_62;

wire n_51;
wire n_60;
wire n_33;
wire n_50;
wire n_34;
wire n_55;
wire n_24;
wire n_52;
wire n_37;
wire n_47;
wire n_46;
wire n_30;
wire n_23;
wire n_54;
wire n_28;
wire n_53;
wire n_59;
wire n_27;
wire n_49;
wire n_58;
wire n_20;
wire n_40;
wire n_39;
wire n_61;
wire n_31;
wire n_21;
wire n_42;
wire n_25;
wire n_22;
wire n_35;
wire n_41;
wire n_32;
wire n_57;
wire n_43;
wire n_26;
wire n_36;
wire n_44;
wire n_29;
wire n_48;
wire n_45;
wire n_38;
wire n_56;

AND2x6_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_9),
.B(n_12),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_3),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_0),
.B(n_15),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_18),
.B(n_6),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_17),
.B(n_8),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_5),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_11),
.Y(n_29)
);

BUFx3_ASAP7_75t_L g30 ( 
.A(n_21),
.Y(n_30)
);

AND2x4_ASAP7_75t_SL g31 ( 
.A(n_22),
.B(n_7),
.Y(n_31)
);

BUFx3_ASAP7_75t_L g32 ( 
.A(n_21),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_22),
.B(n_1),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

OAI21x1_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_24),
.B(n_25),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI221x1_ASAP7_75t_L g37 ( 
.A1(n_31),
.A2(n_21),
.B1(n_24),
.B2(n_26),
.C(n_25),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_SL g38 ( 
.A1(n_30),
.A2(n_20),
.B1(n_23),
.B2(n_25),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_36),
.B(n_31),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_34),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_35),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_38),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_38),
.Y(n_43)
);

AND2x4_ASAP7_75t_SL g44 ( 
.A(n_39),
.B(n_41),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_L g45 ( 
.A1(n_42),
.A2(n_40),
.B1(n_30),
.B2(n_20),
.Y(n_45)
);

AOI221x1_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_23),
.B1(n_29),
.B2(n_21),
.C(n_37),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

OAI21xp5_ASAP7_75t_L g48 ( 
.A1(n_43),
.A2(n_37),
.B(n_32),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_32),
.B1(n_44),
.B2(n_29),
.C(n_26),
.Y(n_49)
);

OAI221xp5_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_32),
.B1(n_29),
.B2(n_26),
.C(n_28),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_47),
.B(n_20),
.Y(n_51)
);

AO22x2_ASAP7_75t_L g52 ( 
.A1(n_47),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_52)
);

NAND3xp33_ASAP7_75t_SL g53 ( 
.A(n_49),
.B(n_27),
.C(n_45),
.Y(n_53)
);

AOI221xp5_ASAP7_75t_L g54 ( 
.A1(n_52),
.A2(n_20),
.B1(n_11),
.B2(n_2),
.C(n_10),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

AND2x4_ASAP7_75t_L g56 ( 
.A(n_50),
.B(n_10),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_20),
.B1(n_18),
.B2(n_16),
.Y(n_57)
);

INVx2_ASAP7_75t_L g58 ( 
.A(n_55),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_56),
.A2(n_20),
.B1(n_19),
.B2(n_16),
.Y(n_59)
);

INVxp67_ASAP7_75t_L g60 ( 
.A(n_58),
.Y(n_60)
);

AOI22xp5_ASAP7_75t_L g61 ( 
.A1(n_57),
.A2(n_53),
.B1(n_54),
.B2(n_20),
.Y(n_61)
);

AOI222xp33_ASAP7_75t_L g62 ( 
.A1(n_60),
.A2(n_13),
.B1(n_14),
.B2(n_20),
.C1(n_59),
.C2(n_61),
.Y(n_62)
);


endmodule