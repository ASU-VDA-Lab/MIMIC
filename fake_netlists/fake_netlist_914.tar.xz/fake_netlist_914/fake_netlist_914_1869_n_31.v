module fake_netlist_914_1869_n_31 (n_0, n_2, n_5, n_3, n_10, n_9, n_4, n_8, n_6, n_1, n_7, n_31);

input n_0;
input n_2;
input n_5;
input n_3;
input n_10;
input n_9;
input n_4;
input n_8;
input n_6;
input n_1;
input n_7;

output n_31;

wire n_15;
wire n_11;
wire n_24;
wire n_16;
wire n_30;
wire n_23;
wire n_28;
wire n_19;
wire n_12;
wire n_27;
wire n_20;
wire n_17;
wire n_18;
wire n_13;
wire n_21;
wire n_22;
wire n_14;
wire n_25;
wire n_26;
wire n_29;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_9),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_7),
.B(n_8),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_10),
.Y(n_16)
);

NAND3xp33_ASAP7_75t_SL g17 ( 
.A(n_13),
.B(n_1),
.C(n_0),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_15),
.B(n_11),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_SL g19 ( 
.A(n_14),
.B(n_3),
.Y(n_19)
);

O2A1O1Ixp33_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_4),
.B(n_1),
.C(n_0),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_17),
.B(n_16),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

AND2x2_ASAP7_75t_SL g24 ( 
.A(n_22),
.B(n_19),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

OAI21x1_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_20),
.B(n_22),
.Y(n_26)
);

AOI222xp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_24),
.B1(n_23),
.B2(n_15),
.C1(n_12),
.C2(n_21),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_26),
.Y(n_28)
);

CKINVDCx14_ASAP7_75t_R g29 ( 
.A(n_27),
.Y(n_29)
);

AOI22xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_26),
.B1(n_25),
.B2(n_15),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B1(n_7),
.B2(n_6),
.Y(n_31)
);


endmodule