module fake_netlist_678_808_n_17 (n_3, n_0, n_2, n_1, n_17);

input n_3;
input n_0;
input n_2;
input n_1;

output n_17;

wire n_9;
wire n_7;
wire n_4;
wire n_14;
wire n_15;
wire n_11;
wire n_13;
wire n_16;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

INVx5_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

INVx8_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

CKINVDCx9p33_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

OR4x1_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_6),
.C(n_4),
.D(n_5),
.Y(n_11)
);

AND2x2_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_7),
.Y(n_12)
);

OAI221xp5_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_9),
.B1(n_1),
.B2(n_0),
.C(n_5),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_5),
.B(n_1),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_11),
.B1(n_3),
.B2(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_14),
.Y(n_16)
);

OAI22xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_0),
.B1(n_2),
.B2(n_15),
.Y(n_17)
);


endmodule