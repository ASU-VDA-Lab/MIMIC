module fake_netlist_678_723_n_45 (n_2, n_17, n_6, n_9, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_45);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_45;

wire n_24;
wire n_44;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_31;
wire n_23;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_39;

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_18),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_16),
.B(n_17),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_19),
.B(n_14),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_R g24 ( 
.A(n_6),
.B(n_5),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_15),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_1),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_10),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_10),
.B(n_9),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_8),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_28),
.A2(n_20),
.B1(n_11),
.B2(n_7),
.Y(n_30)
);

AND2x4_ASAP7_75t_L g31 ( 
.A(n_26),
.B(n_20),
.Y(n_31)
);

O2A1O1Ixp33_ASAP7_75t_L g32 ( 
.A1(n_22),
.A2(n_4),
.B(n_13),
.C(n_12),
.Y(n_32)
);

CKINVDCx5p33_ASAP7_75t_R g33 ( 
.A(n_31),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_SL g34 ( 
.A(n_31),
.B(n_27),
.C(n_29),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_30),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_25),
.B1(n_21),
.B2(n_29),
.Y(n_38)
);

NOR2x1_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_32),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_23),
.B1(n_24),
.B2(n_3),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_41),
.Y(n_43)
);

BUFx2_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

OAI211xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_0),
.B(n_2),
.C(n_43),
.Y(n_45)
);


endmodule