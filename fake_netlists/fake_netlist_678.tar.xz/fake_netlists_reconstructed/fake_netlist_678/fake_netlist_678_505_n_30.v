module fake_netlist_678_505_n_30 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_30);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_30;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_26;
wire n_23;
wire n_29;
wire n_28;
wire n_25;
wire n_19;

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_0),
.B(n_12),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_7),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_1),
.B(n_13),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_15),
.B(n_2),
.Y(n_21)
);

O2A1O1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_8),
.B(n_16),
.C(n_14),
.Y(n_22)
);

O2A1O1Ixp33_ASAP7_75t_SL g23 ( 
.A1(n_17),
.A2(n_8),
.B(n_16),
.C(n_9),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_SL g24 ( 
.A(n_22),
.B(n_18),
.C(n_20),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

A2O1A1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_20),
.B(n_21),
.C(n_18),
.Y(n_27)
);

BUFx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_23),
.B1(n_6),
.B2(n_3),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_4),
.B1(n_5),
.B2(n_11),
.Y(n_30)
);


endmodule