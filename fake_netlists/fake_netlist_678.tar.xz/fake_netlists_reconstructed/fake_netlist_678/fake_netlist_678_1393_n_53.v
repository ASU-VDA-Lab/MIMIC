module fake_netlist_678_1393_n_53 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_53);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_53;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_46;
wire n_41;
wire n_23;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_19;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_39;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_11),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_5),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_3),
.B(n_1),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_0),
.B(n_6),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_18),
.Y(n_25)
);

INVxp67_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_12),
.B(n_7),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_16),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_R g31 ( 
.A(n_22),
.B(n_13),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_19),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_20),
.Y(n_33)
);

INVx2_ASAP7_75t_L g34 ( 
.A(n_29),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_29),
.B(n_18),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_30),
.Y(n_36)
);

BUFx4f_ASAP7_75t_SL g37 ( 
.A(n_34),
.Y(n_37)
);

INVx4_ASAP7_75t_SL g38 ( 
.A(n_33),
.Y(n_38)
);

AOI22xp33_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_25),
.B1(n_21),
.B2(n_20),
.Y(n_39)
);

OR2x6_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_35),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_32),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_40),
.B(n_39),
.Y(n_43)
);

OR2x2_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_19),
.Y(n_44)
);

NAND3xp33_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_43),
.C(n_44),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_37),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_SL g47 ( 
.A(n_45),
.B(n_31),
.Y(n_47)
);

O2A1O1Ixp33_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_26),
.B(n_28),
.C(n_27),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_R g49 ( 
.A(n_46),
.B(n_14),
.Y(n_49)
);

OAI22x1_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_48),
.B1(n_49),
.B2(n_24),
.Y(n_50)
);

NAND3xp33_ASAP7_75t_SL g51 ( 
.A(n_48),
.B(n_23),
.C(n_16),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_50),
.Y(n_52)
);

AOI322xp5_ASAP7_75t_L g53 ( 
.A1(n_52),
.A2(n_51),
.A3(n_17),
.B1(n_9),
.B2(n_20),
.C1(n_33),
.C2(n_8),
.Y(n_53)
);


endmodule