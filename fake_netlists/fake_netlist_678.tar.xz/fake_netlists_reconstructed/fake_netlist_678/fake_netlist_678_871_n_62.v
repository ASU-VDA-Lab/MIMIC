module fake_netlist_678_871_n_62 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_62);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_62;

wire n_54;
wire n_24;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_58;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_46;
wire n_23;
wire n_41;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_19;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_7),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

XNOR2xp5_ASAP7_75t_L g23 ( 
.A(n_14),
.B(n_10),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_9),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_3),
.B(n_13),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_1),
.B(n_0),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_22),
.Y(n_29)
);

INVx5_ASAP7_75t_L g30 ( 
.A(n_20),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

BUFx4f_ASAP7_75t_SL g32 ( 
.A(n_20),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_25),
.B(n_24),
.Y(n_33)
);

INVx4_ASAP7_75t_L g34 ( 
.A(n_28),
.Y(n_34)
);

AND3x1_ASAP7_75t_SL g35 ( 
.A(n_18),
.B(n_17),
.C(n_15),
.Y(n_35)
);

AOI21xp5_ASAP7_75t_L g36 ( 
.A1(n_33),
.A2(n_26),
.B(n_28),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_31),
.Y(n_37)
);

OAI22xp33_ASAP7_75t_L g38 ( 
.A1(n_29),
.A2(n_18),
.B1(n_21),
.B2(n_19),
.Y(n_38)
);

BUFx2_ASAP7_75t_L g39 ( 
.A(n_32),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

NAND3xp33_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_34),
.C(n_21),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_40),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_30),
.Y(n_45)
);

AND2x2_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_30),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_40),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_44),
.B(n_46),
.Y(n_49)
);

OR2x2_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_38),
.Y(n_50)
);

INVx1_ASAP7_75t_SL g51 ( 
.A(n_47),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_50),
.Y(n_52)
);

OAI21xp33_ASAP7_75t_L g53 ( 
.A1(n_49),
.A2(n_23),
.B(n_48),
.Y(n_53)
);

NOR3xp33_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_41),
.C(n_19),
.Y(n_54)
);

OAI211xp5_ASAP7_75t_SL g55 ( 
.A1(n_52),
.A2(n_35),
.B(n_32),
.C(n_17),
.Y(n_55)
);

NOR2xp33_ASAP7_75t_L g56 ( 
.A(n_51),
.B(n_53),
.Y(n_56)
);

NOR2xp33_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_34),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_52),
.B(n_30),
.Y(n_58)
);

AND2x4_ASAP7_75t_L g59 ( 
.A(n_56),
.B(n_28),
.Y(n_59)
);

NAND3xp33_ASAP7_75t_L g60 ( 
.A(n_57),
.B(n_30),
.C(n_35),
.Y(n_60)
);

OAI22xp5_ASAP7_75t_L g61 ( 
.A1(n_58),
.A2(n_16),
.B1(n_6),
.B2(n_5),
.Y(n_61)
);

AOI322xp5_ASAP7_75t_L g62 ( 
.A1(n_59),
.A2(n_55),
.A3(n_60),
.B1(n_61),
.B2(n_8),
.C1(n_12),
.C2(n_4),
.Y(n_62)
);


endmodule