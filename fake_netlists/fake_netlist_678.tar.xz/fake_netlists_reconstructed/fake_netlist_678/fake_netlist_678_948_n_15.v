module fake_netlist_678_948_n_15 (n_4, n_2, n_3, n_1, n_0, n_15);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_15;

wire n_9;
wire n_7;
wire n_14;
wire n_11;
wire n_12;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_13;

NAND2x1p5_ASAP7_75t_L g5 ( 
.A(n_1),
.B(n_4),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

AOI22xp33_ASAP7_75t_L g7 ( 
.A1(n_6),
.A2(n_0),
.B1(n_2),
.B2(n_4),
.Y(n_7)
);

OA21x2_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_0),
.B(n_4),
.Y(n_8)
);

AOI221xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_5),
.B1(n_0),
.B2(n_4),
.C(n_3),
.Y(n_9)
);

OAI21x1_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_0),
.B(n_2),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

NOR2x1_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_8),
.Y(n_12)
);

OAI21xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_0),
.B(n_2),
.Y(n_13)
);

XNOR2x1_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_2),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_3),
.B1(n_9),
.B2(n_7),
.C1(n_13),
.C2(n_12),
.Y(n_15)
);


endmodule