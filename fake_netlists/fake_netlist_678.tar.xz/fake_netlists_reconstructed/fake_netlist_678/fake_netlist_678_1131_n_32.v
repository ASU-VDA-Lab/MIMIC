module fake_netlist_678_1131_n_32 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_32);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_32;

wire n_24;
wire n_21;
wire n_27;
wire n_22;
wire n_18;
wire n_20;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_16),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_1),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_7),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_20),
.B(n_14),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_23),
.B(n_15),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_22),
.Y(n_26)
);

INVxp67_ASAP7_75t_SL g27 ( 
.A(n_26),
.Y(n_27)
);

OAI221xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_21),
.B1(n_24),
.B2(n_19),
.C(n_18),
.Y(n_28)
);

OAI221xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_17),
.B1(n_12),
.B2(n_9),
.C(n_11),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

OAI22x1_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_10),
.B1(n_6),
.B2(n_5),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.Y(n_32)
);


endmodule