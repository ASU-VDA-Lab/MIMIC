module fake_netlist_678_834_n_16 (n_4, n_2, n_3, n_1, n_0, n_16);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_16;

wire n_9;
wire n_7;
wire n_14;
wire n_15;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx2_ASAP7_75t_L g5 ( 
.A(n_1),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_1),
.B(n_3),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_5),
.A2(n_0),
.B(n_4),
.Y(n_7)
);

OAI21xp5_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_0),
.B(n_4),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_8),
.B(n_7),
.Y(n_9)
);

AOI33xp33_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_0),
.A3(n_1),
.B1(n_3),
.B2(n_2),
.B3(n_4),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_7),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_SL g12 ( 
.A(n_9),
.Y(n_12)
);

OAI22xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B1(n_4),
.B2(n_3),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_11),
.Y(n_14)
);

XNOR2xp5_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_14),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_2),
.B1(n_8),
.B2(n_9),
.Y(n_16)
);


endmodule