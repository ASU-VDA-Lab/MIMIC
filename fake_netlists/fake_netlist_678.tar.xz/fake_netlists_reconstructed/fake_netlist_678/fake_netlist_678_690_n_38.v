module fake_netlist_678_690_n_38 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_38);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_38;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_12;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

AND2x6_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_4),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_7),
.Y(n_13)
);

BUFx3_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_10),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_1),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_1),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_16),
.Y(n_21)
);

OAI221xp5_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_15),
.B1(n_16),
.B2(n_14),
.C(n_13),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

OAI33xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_19),
.A3(n_18),
.B1(n_13),
.B2(n_17),
.B3(n_20),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_18),
.B1(n_20),
.B2(n_17),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_R g27 ( 
.A(n_24),
.B(n_8),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_23),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_12),
.C(n_5),
.Y(n_29)
);

AO22x2_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_28),
.B1(n_27),
.B2(n_6),
.Y(n_30)
);

AOI322xp5_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_2),
.A3(n_5),
.B1(n_0),
.B2(n_3),
.C1(n_6),
.C2(n_12),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_28),
.B(n_12),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_30),
.Y(n_33)
);

BUFx2_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_31),
.Y(n_35)
);

OAI322xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_0),
.A3(n_3),
.B1(n_11),
.B2(n_12),
.C1(n_33),
.C2(n_34),
.Y(n_36)
);

XNOR2xp5_ASAP7_75t_L g37 ( 
.A(n_33),
.B(n_12),
.Y(n_37)
);

AOI22xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_34),
.B1(n_12),
.B2(n_36),
.Y(n_38)
);


endmodule