module fake_netlist_678_1275_n_35 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_35);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_35;

wire n_24;
wire n_21;
wire n_27;
wire n_22;
wire n_20;
wire n_34;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

CKINVDCx20_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

NOR2xp33_ASAP7_75t_R g21 ( 
.A(n_13),
.B(n_7),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_14),
.B(n_17),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_11),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_L g25 ( 
.A1(n_22),
.A2(n_9),
.B1(n_18),
.B2(n_16),
.Y(n_25)
);

BUFx12f_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_24),
.B1(n_19),
.B2(n_20),
.Y(n_27)
);

OAI22xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_20),
.B1(n_16),
.B2(n_18),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_26),
.Y(n_30)
);

OAI321xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_27),
.A3(n_9),
.B1(n_20),
.B2(n_21),
.C(n_12),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_31),
.Y(n_32)
);

BUFx10_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_10),
.B1(n_8),
.B2(n_6),
.Y(n_34)
);

AOI322xp5_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_33),
.A3(n_15),
.B1(n_4),
.B2(n_0),
.C1(n_2),
.C2(n_1),
.Y(n_35)
);


endmodule