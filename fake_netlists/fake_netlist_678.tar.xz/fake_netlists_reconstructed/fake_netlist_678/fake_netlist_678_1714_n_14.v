module fake_netlist_678_1714_n_14 (n_0, n_2, n_1, n_14);

input n_0;
input n_2;
input n_1;

output n_14;

wire n_9;
wire n_4;
wire n_7;
wire n_3;
wire n_11;
wire n_12;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_13;

INVx1_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

A2O1A1Ixp33_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.C(n_2),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_4),
.B(n_1),
.Y(n_6)
);

NOR2xp33_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_1),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_1),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_6),
.B(n_1),
.Y(n_9)
);

OAI211xp5_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_7),
.B(n_2),
.C(n_0),
.Y(n_10)
);

NOR3xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_6),
.C(n_8),
.Y(n_11)
);

NOR2x1p5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_R g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_0),
.B2(n_2),
.Y(n_14)
);


endmodule