module fake_netlist_719_2038_n_16 (n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_16);

input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_16;

wire n_12;
wire n_8;
wire n_10;
wire n_15;
wire n_14;
wire n_13;
wire n_9;
wire n_11;

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

OAI22xp33_ASAP7_75t_L g9 ( 
.A1(n_2),
.A2(n_6),
.B1(n_4),
.B2(n_0),
.Y(n_9)
);

AOI22xp33_ASAP7_75t_L g10 ( 
.A1(n_4),
.A2(n_5),
.B1(n_6),
.B2(n_7),
.Y(n_10)
);

OAI21x1_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

AND2x2_ASAP7_75t_SL g12 ( 
.A(n_11),
.B(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_12),
.B(n_11),
.C(n_8),
.Y(n_14)
);

AOI21xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_9),
.B(n_1),
.Y(n_15)
);

AOI22xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_8),
.B1(n_7),
.B2(n_5),
.Y(n_16)
);


endmodule