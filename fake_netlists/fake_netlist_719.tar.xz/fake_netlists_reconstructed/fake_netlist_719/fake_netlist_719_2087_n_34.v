module fake_netlist_719_2087_n_34 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_17, n_5, n_34);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_17;
input n_5;

output n_34;

wire n_32;
wire n_33;
wire n_30;
wire n_20;
wire n_27;
wire n_24;
wire n_29;
wire n_31;
wire n_18;
wire n_28;
wire n_25;
wire n_22;
wire n_23;
wire n_21;
wire n_26;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_8),
.Y(n_20)
);

BUFx3_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_6),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_19),
.A2(n_1),
.B(n_0),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_20),
.A2(n_5),
.B(n_2),
.Y(n_26)
);

BUFx2_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_21),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_18),
.Y(n_29)
);

OAI22xp33_ASAP7_75t_SL g30 ( 
.A1(n_29),
.A2(n_28),
.B1(n_24),
.B2(n_22),
.Y(n_30)
);

NAND4xp25_ASAP7_75t_SL g31 ( 
.A(n_30),
.B(n_16),
.C(n_21),
.D(n_23),
.Y(n_31)
);

XNOR2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_16),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_32),
.A2(n_10),
.B1(n_9),
.B2(n_7),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_34)
);


endmodule