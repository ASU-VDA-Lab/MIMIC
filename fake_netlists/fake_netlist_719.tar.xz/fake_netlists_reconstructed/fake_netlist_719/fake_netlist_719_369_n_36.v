module fake_netlist_719_369_n_36 (n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_36);

input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_36;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_25;
wire n_12;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_34;
wire n_16;
wire n_22;
wire n_19;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_6),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_4),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_0),
.Y(n_15)
);

INVx3_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

AND2x4_ASAP7_75t_L g17 ( 
.A(n_7),
.B(n_10),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

NOR2xp67_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_0),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_16),
.B1(n_12),
.B2(n_13),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_16),
.B(n_12),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_18),
.A2(n_14),
.B(n_13),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_20),
.B(n_15),
.C(n_14),
.Y(n_23)
);

OAI221xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_19),
.B1(n_15),
.B2(n_17),
.C(n_1),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_21),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_21),
.Y(n_27)
);

O2A1O1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_26),
.B(n_17),
.C(n_1),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_26),
.B1(n_17),
.B2(n_2),
.Y(n_29)
);

NAND3xp33_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_26),
.C(n_2),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

OAI31xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_26),
.A3(n_4),
.B(n_3),
.Y(n_32)
);

INVx2_ASAP7_75t_SL g33 ( 
.A(n_31),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_5),
.Y(n_34)
);

AOI21xp5_ASAP7_75t_L g35 ( 
.A1(n_32),
.A2(n_11),
.B(n_8),
.Y(n_35)
);

AOI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_34),
.B1(n_33),
.B2(n_5),
.Y(n_36)
);


endmodule