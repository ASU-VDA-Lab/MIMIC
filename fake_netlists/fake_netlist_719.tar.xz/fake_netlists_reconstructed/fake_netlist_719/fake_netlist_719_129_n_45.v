module fake_netlist_719_129_n_45 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_6, n_14, n_0, n_3, n_4, n_5, n_45);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_45;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_36;
wire n_29;
wire n_37;
wire n_41;
wire n_43;
wire n_31;
wire n_18;
wire n_28;
wire n_39;
wire n_25;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_44;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_13),
.Y(n_15)
);

NAND2xp33_ASAP7_75t_L g16 ( 
.A(n_12),
.B(n_14),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_8),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_11),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_3),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_4),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_1),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_19),
.Y(n_23)
);

BUFx6f_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_23),
.Y(n_26)
);

OR2x2_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_20),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_22),
.A2(n_18),
.B1(n_16),
.B2(n_15),
.Y(n_28)
);

NAND3xp33_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_22),
.C(n_24),
.Y(n_29)
);

AOI33xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_22),
.A3(n_25),
.B1(n_18),
.B2(n_4),
.B3(n_1),
.Y(n_30)
);

NOR2xp33_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_26),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_30),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_29),
.B(n_24),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_25),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_31),
.Y(n_36)
);

NOR3xp33_ASAP7_75t_L g37 ( 
.A(n_36),
.B(n_6),
.C(n_5),
.Y(n_37)
);

AOI21xp5_ASAP7_75t_L g38 ( 
.A1(n_35),
.A2(n_24),
.B(n_0),
.Y(n_38)
);

INVx2_ASAP7_75t_SL g39 ( 
.A(n_34),
.Y(n_39)
);

HB1xp67_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

OR3x2_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_7),
.C(n_5),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_34),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

AOI322xp5_ASAP7_75t_L g45 ( 
.A1(n_44),
.A2(n_2),
.A3(n_9),
.B1(n_10),
.B2(n_24),
.C1(n_41),
.C2(n_43),
.Y(n_45)
);


endmodule