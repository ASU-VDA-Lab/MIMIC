module fake_netlist_719_963_n_231 (n_3, n_14, n_20, n_0, n_27, n_2, n_17, n_24, n_13, n_7, n_18, n_11, n_9, n_4, n_25, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_26, n_16, n_22, n_6, n_19, n_5, n_231);

input n_3;
input n_14;
input n_20;
input n_0;
input n_27;
input n_2;
input n_17;
input n_24;
input n_13;
input n_7;
input n_18;
input n_11;
input n_9;
input n_4;
input n_25;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_26;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_231;

wire n_154;
wire n_207;
wire n_224;
wire n_209;
wire n_68;
wire n_185;
wire n_82;
wire n_37;
wire n_112;
wire n_141;
wire n_198;
wire n_226;
wire n_218;
wire n_31;
wire n_188;
wire n_39;
wire n_173;
wire n_121;
wire n_162;
wire n_164;
wire n_65;
wire n_179;
wire n_140;
wire n_184;
wire n_144;
wire n_171;
wire n_230;
wire n_210;
wire n_128;
wire n_181;
wire n_212;
wire n_56;
wire n_130;
wire n_159;
wire n_165;
wire n_94;
wire n_227;
wire n_69;
wire n_62;
wire n_123;
wire n_97;
wire n_193;
wire n_135;
wire n_139;
wire n_202;
wire n_55;
wire n_148;
wire n_110;
wire n_172;
wire n_102;
wire n_60;
wire n_105;
wire n_195;
wire n_33;
wire n_61;
wire n_75;
wire n_174;
wire n_106;
wire n_79;
wire n_30;
wire n_194;
wire n_118;
wire n_186;
wire n_54;
wire n_168;
wire n_77;
wire n_73;
wire n_196;
wire n_125;
wire n_220;
wire n_131;
wire n_85;
wire n_208;
wire n_126;
wire n_169;
wire n_120;
wire n_116;
wire n_132;
wire n_70;
wire n_213;
wire n_142;
wire n_129;
wire n_67;
wire n_81;
wire n_92;
wire n_155;
wire n_44;
wire n_74;
wire n_124;
wire n_53;
wire n_107;
wire n_138;
wire n_64;
wire n_200;
wire n_204;
wire n_49;
wire n_40;
wire n_51;
wire n_147;
wire n_222;
wire n_163;
wire n_59;
wire n_111;
wire n_166;
wire n_161;
wire n_190;
wire n_117;
wire n_93;
wire n_158;
wire n_84;
wire n_180;
wire n_32;
wire n_48;
wire n_143;
wire n_228;
wire n_221;
wire n_35;
wire n_136;
wire n_96;
wire n_182;
wire n_104;
wire n_115;
wire n_201;
wire n_41;
wire n_98;
wire n_203;
wire n_183;
wire n_229;
wire n_100;
wire n_145;
wire n_76;
wire n_57;
wire n_43;
wire n_137;
wire n_71;
wire n_113;
wire n_80;
wire n_108;
wire n_119;
wire n_160;
wire n_189;
wire n_205;
wire n_87;
wire n_176;
wire n_42;
wire n_167;
wire n_156;
wire n_199;
wire n_34;
wire n_89;
wire n_58;
wire n_86;
wire n_72;
wire n_223;
wire n_192;
wire n_114;
wire n_151;
wire n_90;
wire n_197;
wire n_63;
wire n_219;
wire n_101;
wire n_217;
wire n_127;
wire n_146;
wire n_36;
wire n_29;
wire n_66;
wire n_83;
wire n_91;
wire n_95;
wire n_150;
wire n_215;
wire n_152;
wire n_206;
wire n_45;
wire n_28;
wire n_52;
wire n_187;
wire n_133;
wire n_78;
wire n_153;
wire n_46;
wire n_122;
wire n_88;
wire n_134;
wire n_191;
wire n_99;
wire n_157;
wire n_47;
wire n_214;
wire n_50;
wire n_38;
wire n_109;
wire n_178;
wire n_170;
wire n_225;
wire n_211;
wire n_216;
wire n_175;
wire n_103;
wire n_177;
wire n_149;

INVx1_ASAP7_75t_L g28 ( 
.A(n_12),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_4),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_14),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_7),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_0),
.Y(n_33)
);

BUFx10_ASAP7_75t_L g34 ( 
.A(n_16),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_4),
.Y(n_35)
);

INVxp67_ASAP7_75t_SL g36 ( 
.A(n_27),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_22),
.Y(n_37)
);

INVxp33_ASAP7_75t_SL g38 ( 
.A(n_27),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_12),
.Y(n_39)
);

CKINVDCx5p33_ASAP7_75t_R g40 ( 
.A(n_38),
.Y(n_40)
);

BUFx2_ASAP7_75t_L g41 ( 
.A(n_30),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_30),
.Y(n_42)
);

BUFx10_ASAP7_75t_L g43 ( 
.A(n_33),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_34),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_34),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_30),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_42),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_SL g48 ( 
.A(n_45),
.B(n_43),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_43),
.B(n_33),
.Y(n_49)
);

AO22x2_ASAP7_75t_L g50 ( 
.A1(n_42),
.A2(n_31),
.B1(n_29),
.B2(n_28),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_43),
.B(n_36),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_41),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_46),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_46),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_41),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_41),
.Y(n_56)
);

NOR2xp67_ASAP7_75t_SL g57 ( 
.A(n_49),
.B(n_28),
.Y(n_57)
);

NAND2x1p5_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_29),
.Y(n_58)
);

BUFx6f_ASAP7_75t_L g59 ( 
.A(n_47),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_51),
.B(n_55),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_52),
.B(n_43),
.Y(n_61)
);

NAND2xp5_ASAP7_75t_L g62 ( 
.A(n_56),
.B(n_43),
.Y(n_62)
);

AOI21xp5_ASAP7_75t_L g63 ( 
.A1(n_47),
.A2(n_32),
.B(n_31),
.Y(n_63)
);

BUFx6f_ASAP7_75t_L g64 ( 
.A(n_54),
.Y(n_64)
);

NAND2xp5_ASAP7_75t_L g65 ( 
.A(n_54),
.B(n_40),
.Y(n_65)
);

BUFx6f_ASAP7_75t_L g66 ( 
.A(n_53),
.Y(n_66)
);

NAND2xp5_ASAP7_75t_L g67 ( 
.A(n_48),
.B(n_40),
.Y(n_67)
);

NAND2xp5_ASAP7_75t_L g68 ( 
.A(n_53),
.B(n_35),
.Y(n_68)
);

AOI21x1_ASAP7_75t_L g69 ( 
.A1(n_50),
.A2(n_37),
.B(n_32),
.Y(n_69)
);

OAI21x1_ASAP7_75t_L g70 ( 
.A1(n_69),
.A2(n_63),
.B(n_58),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_59),
.Y(n_71)
);

INVx1_ASAP7_75t_L g72 ( 
.A(n_69),
.Y(n_72)
);

O2A1O1Ixp33_ASAP7_75t_SL g73 ( 
.A1(n_61),
.A2(n_39),
.B(n_37),
.C(n_62),
.Y(n_73)
);

OA21x2_ASAP7_75t_L g74 ( 
.A1(n_68),
.A2(n_39),
.B(n_35),
.Y(n_74)
);

INVx3_ASAP7_75t_L g75 ( 
.A(n_59),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_60),
.B(n_50),
.Y(n_76)
);

AOI21xp5_ASAP7_75t_L g77 ( 
.A1(n_65),
.A2(n_50),
.B(n_44),
.Y(n_77)
);

AOI22x1_ASAP7_75t_L g78 ( 
.A1(n_58),
.A2(n_50),
.B1(n_34),
.B2(n_44),
.Y(n_78)
);

BUFx2_ASAP7_75t_L g79 ( 
.A(n_59),
.Y(n_79)
);

CKINVDCx5p33_ASAP7_75t_R g80 ( 
.A(n_67),
.Y(n_80)
);

INVx2_ASAP7_75t_L g81 ( 
.A(n_71),
.Y(n_81)
);

NAND4xp25_ASAP7_75t_L g82 ( 
.A(n_77),
.B(n_76),
.C(n_73),
.D(n_34),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_71),
.Y(n_83)
);

BUFx2_ASAP7_75t_L g84 ( 
.A(n_79),
.Y(n_84)
);

AND2x2_ASAP7_75t_L g85 ( 
.A(n_76),
.B(n_57),
.Y(n_85)
);

INVx2_ASAP7_75t_L g86 ( 
.A(n_71),
.Y(n_86)
);

OAI21xp5_ASAP7_75t_L g87 ( 
.A1(n_72),
.A2(n_57),
.B(n_59),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_83),
.Y(n_88)
);

AND2x4_ASAP7_75t_L g89 ( 
.A(n_83),
.B(n_75),
.Y(n_89)
);

INVxp67_ASAP7_75t_SL g90 ( 
.A(n_84),
.Y(n_90)
);

BUFx3_ASAP7_75t_L g91 ( 
.A(n_85),
.Y(n_91)
);

INVxp67_ASAP7_75t_L g92 ( 
.A(n_84),
.Y(n_92)
);

AND2x2_ASAP7_75t_L g93 ( 
.A(n_85),
.B(n_76),
.Y(n_93)
);

AOI22xp33_ASAP7_75t_L g94 ( 
.A1(n_82),
.A2(n_78),
.B1(n_77),
.B2(n_74),
.Y(n_94)
);

INVx2_ASAP7_75t_L g95 ( 
.A(n_88),
.Y(n_95)
);

OR2x2_ASAP7_75t_L g96 ( 
.A(n_93),
.B(n_77),
.Y(n_96)
);

AND2x2_ASAP7_75t_L g97 ( 
.A(n_93),
.B(n_81),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_93),
.B(n_80),
.Y(n_98)
);

OR2x2_ASAP7_75t_L g99 ( 
.A(n_93),
.B(n_81),
.Y(n_99)
);

AND2x2_ASAP7_75t_L g100 ( 
.A(n_93),
.B(n_86),
.Y(n_100)
);

INVx1_ASAP7_75t_L g101 ( 
.A(n_88),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_88),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_88),
.Y(n_103)
);

AND2x2_ASAP7_75t_L g104 ( 
.A(n_91),
.B(n_86),
.Y(n_104)
);

NAND2xp67_ASAP7_75t_L g105 ( 
.A(n_94),
.B(n_71),
.Y(n_105)
);

AND2x2_ASAP7_75t_L g106 ( 
.A(n_100),
.B(n_91),
.Y(n_106)
);

NAND2xp5_ASAP7_75t_L g107 ( 
.A(n_100),
.B(n_91),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_101),
.Y(n_108)
);

AND2x2_ASAP7_75t_L g109 ( 
.A(n_97),
.B(n_91),
.Y(n_109)
);

AND2x2_ASAP7_75t_L g110 ( 
.A(n_97),
.B(n_91),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_101),
.Y(n_111)
);

OR2x6_ASAP7_75t_L g112 ( 
.A(n_105),
.B(n_91),
.Y(n_112)
);

CKINVDCx16_ASAP7_75t_R g113 ( 
.A(n_96),
.Y(n_113)
);

AND2x2_ASAP7_75t_L g114 ( 
.A(n_104),
.B(n_91),
.Y(n_114)
);

OR2x2_ASAP7_75t_L g115 ( 
.A(n_96),
.B(n_90),
.Y(n_115)
);

INVx2_ASAP7_75t_L g116 ( 
.A(n_95),
.Y(n_116)
);

AOI22xp33_ASAP7_75t_L g117 ( 
.A1(n_98),
.A2(n_78),
.B1(n_80),
.B2(n_94),
.Y(n_117)
);

OR2x2_ASAP7_75t_L g118 ( 
.A(n_99),
.B(n_90),
.Y(n_118)
);

NOR2xp33_ASAP7_75t_L g119 ( 
.A(n_99),
.B(n_92),
.Y(n_119)
);

INVxp67_ASAP7_75t_SL g120 ( 
.A(n_104),
.Y(n_120)
);

INVx1_ASAP7_75t_L g121 ( 
.A(n_102),
.Y(n_121)
);

NAND2xp5_ASAP7_75t_L g122 ( 
.A(n_95),
.B(n_102),
.Y(n_122)
);

OAI22xp5_ASAP7_75t_L g123 ( 
.A1(n_103),
.A2(n_94),
.B1(n_78),
.B2(n_90),
.Y(n_123)
);

NAND2xp5_ASAP7_75t_L g124 ( 
.A(n_119),
.B(n_92),
.Y(n_124)
);

INVx1_ASAP7_75t_SL g125 ( 
.A(n_118),
.Y(n_125)
);

A2O1A1Ixp33_ASAP7_75t_L g126 ( 
.A1(n_117),
.A2(n_92),
.B(n_70),
.C(n_78),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_108),
.Y(n_127)
);

INVxp67_ASAP7_75t_SL g128 ( 
.A(n_120),
.Y(n_128)
);

OAI22xp33_ASAP7_75t_L g129 ( 
.A1(n_123),
.A2(n_92),
.B1(n_79),
.B2(n_71),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_108),
.Y(n_130)
);

XOR2x2_ASAP7_75t_L g131 ( 
.A(n_123),
.B(n_6),
.Y(n_131)
);

NOR2xp33_ASAP7_75t_L g132 ( 
.A(n_118),
.B(n_6),
.Y(n_132)
);

NAND2xp5_ASAP7_75t_L g133 ( 
.A(n_106),
.B(n_95),
.Y(n_133)
);

A2O1A1Ixp33_ASAP7_75t_L g134 ( 
.A1(n_111),
.A2(n_70),
.B(n_87),
.C(n_121),
.Y(n_134)
);

A2O1A1Ixp33_ASAP7_75t_L g135 ( 
.A1(n_111),
.A2(n_70),
.B(n_103),
.C(n_89),
.Y(n_135)
);

AND2x2_ASAP7_75t_L g136 ( 
.A(n_109),
.B(n_74),
.Y(n_136)
);

INVx1_ASAP7_75t_L g137 ( 
.A(n_121),
.Y(n_137)
);

INVx2_ASAP7_75t_L g138 ( 
.A(n_116),
.Y(n_138)
);

INVx1_ASAP7_75t_L g139 ( 
.A(n_122),
.Y(n_139)
);

AND2x2_ASAP7_75t_L g140 ( 
.A(n_109),
.B(n_74),
.Y(n_140)
);

O2A1O1Ixp33_ASAP7_75t_L g141 ( 
.A1(n_122),
.A2(n_73),
.B(n_89),
.C(n_75),
.Y(n_141)
);

AND2x2_ASAP7_75t_L g142 ( 
.A(n_110),
.B(n_74),
.Y(n_142)
);

NOR4xp25_ASAP7_75t_L g143 ( 
.A(n_115),
.B(n_73),
.C(n_71),
.D(n_7),
.Y(n_143)
);

INVx1_ASAP7_75t_L g144 ( 
.A(n_116),
.Y(n_144)
);

INVx1_ASAP7_75t_L g145 ( 
.A(n_116),
.Y(n_145)
);

A2O1A1Ixp33_ASAP7_75t_L g146 ( 
.A1(n_115),
.A2(n_70),
.B(n_89),
.C(n_75),
.Y(n_146)
);

NAND3xp33_ASAP7_75t_SL g147 ( 
.A(n_107),
.B(n_79),
.C(n_72),
.Y(n_147)
);

AO21x1_ASAP7_75t_L g148 ( 
.A1(n_107),
.A2(n_89),
.B(n_70),
.Y(n_148)
);

INVx1_ASAP7_75t_L g149 ( 
.A(n_112),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_127),
.Y(n_150)
);

INVx1_ASAP7_75t_L g151 ( 
.A(n_130),
.Y(n_151)
);

OR2x2_ASAP7_75t_L g152 ( 
.A(n_125),
.B(n_113),
.Y(n_152)
);

NOR2xp67_ASAP7_75t_L g153 ( 
.A(n_144),
.B(n_110),
.Y(n_153)
);

INVx1_ASAP7_75t_L g154 ( 
.A(n_137),
.Y(n_154)
);

INVx3_ASAP7_75t_L g155 ( 
.A(n_149),
.Y(n_155)
);

INVx2_ASAP7_75t_SL g156 ( 
.A(n_149),
.Y(n_156)
);

NAND2xp5_ASAP7_75t_L g157 ( 
.A(n_124),
.B(n_114),
.Y(n_157)
);

INVx1_ASAP7_75t_L g158 ( 
.A(n_144),
.Y(n_158)
);

INVx1_ASAP7_75t_L g159 ( 
.A(n_145),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_145),
.Y(n_160)
);

NAND2xp5_ASAP7_75t_L g161 ( 
.A(n_139),
.B(n_113),
.Y(n_161)
);

NOR2xp33_ASAP7_75t_L g162 ( 
.A(n_132),
.B(n_13),
.Y(n_162)
);

NAND2xp5_ASAP7_75t_L g163 ( 
.A(n_139),
.B(n_112),
.Y(n_163)
);

AND2x2_ASAP7_75t_L g164 ( 
.A(n_136),
.B(n_112),
.Y(n_164)
);

NOR2xp33_ASAP7_75t_L g165 ( 
.A(n_133),
.B(n_13),
.Y(n_165)
);

INVx1_ASAP7_75t_L g166 ( 
.A(n_138),
.Y(n_166)
);

NAND2xp5_ASAP7_75t_L g167 ( 
.A(n_140),
.B(n_136),
.Y(n_167)
);

INVx1_ASAP7_75t_L g168 ( 
.A(n_138),
.Y(n_168)
);

AND2x2_ASAP7_75t_L g169 ( 
.A(n_140),
.B(n_112),
.Y(n_169)
);

NOR2x1_ASAP7_75t_L g170 ( 
.A(n_147),
.B(n_112),
.Y(n_170)
);

NAND2xp5_ASAP7_75t_SL g171 ( 
.A(n_131),
.B(n_143),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_128),
.Y(n_172)
);

NAND2xp5_ASAP7_75t_L g173 ( 
.A(n_142),
.B(n_131),
.Y(n_173)
);

AND2x2_ASAP7_75t_L g174 ( 
.A(n_142),
.B(n_74),
.Y(n_174)
);

NAND2xp5_ASAP7_75t_L g175 ( 
.A(n_129),
.B(n_74),
.Y(n_175)
);

AND2x2_ASAP7_75t_L g176 ( 
.A(n_148),
.B(n_74),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_135),
.Y(n_177)
);

NOR2x1_ASAP7_75t_L g178 ( 
.A(n_141),
.B(n_74),
.Y(n_178)
);

AOI221xp5_ASAP7_75t_SL g179 ( 
.A1(n_171),
.A2(n_173),
.B1(n_162),
.B2(n_177),
.C(n_126),
.Y(n_179)
);

AOI22xp5_ASAP7_75t_L g180 ( 
.A1(n_170),
.A2(n_165),
.B1(n_163),
.B2(n_161),
.Y(n_180)
);

OAI21xp5_ASAP7_75t_L g181 ( 
.A1(n_178),
.A2(n_134),
.B(n_146),
.Y(n_181)
);

INVx1_ASAP7_75t_L g182 ( 
.A(n_151),
.Y(n_182)
);

AOI221xp5_ASAP7_75t_L g183 ( 
.A1(n_177),
.A2(n_176),
.B1(n_154),
.B2(n_151),
.C(n_150),
.Y(n_183)
);

OAI221xp5_ASAP7_75t_SL g184 ( 
.A1(n_175),
.A2(n_176),
.B1(n_152),
.B2(n_164),
.C(n_169),
.Y(n_184)
);

NAND2xp5_ASAP7_75t_SL g185 ( 
.A(n_152),
.B(n_148),
.Y(n_185)
);

NAND2xp5_ASAP7_75t_SL g186 ( 
.A(n_157),
.B(n_89),
.Y(n_186)
);

AOI221xp5_ASAP7_75t_L g187 ( 
.A1(n_154),
.A2(n_172),
.B1(n_160),
.B2(n_159),
.C(n_158),
.Y(n_187)
);

A2O1A1Ixp33_ASAP7_75t_L g188 ( 
.A1(n_153),
.A2(n_89),
.B(n_15),
.C(n_14),
.Y(n_188)
);

NOR3xp33_ASAP7_75t_L g189 ( 
.A(n_155),
.B(n_156),
.C(n_174),
.Y(n_189)
);

AOI21xp33_ASAP7_75t_L g190 ( 
.A1(n_156),
.A2(n_74),
.B(n_16),
.Y(n_190)
);

OAI221xp5_ASAP7_75t_L g191 ( 
.A1(n_155),
.A2(n_75),
.B1(n_19),
.B2(n_17),
.C(n_18),
.Y(n_191)
);

NOR2xp33_ASAP7_75t_R g192 ( 
.A(n_174),
.B(n_17),
.Y(n_192)
);

AOI21xp33_ASAP7_75t_L g193 ( 
.A1(n_166),
.A2(n_19),
.B(n_18),
.Y(n_193)
);

AND2x2_ASAP7_75t_L g194 ( 
.A(n_167),
.B(n_20),
.Y(n_194)
);

INVx1_ASAP7_75t_L g195 ( 
.A(n_159),
.Y(n_195)
);

NOR2xp33_ASAP7_75t_R g196 ( 
.A(n_160),
.B(n_20),
.Y(n_196)
);

NAND2xp5_ASAP7_75t_L g197 ( 
.A(n_168),
.B(n_89),
.Y(n_197)
);

NAND3xp33_ASAP7_75t_L g198 ( 
.A(n_168),
.B(n_89),
.C(n_64),
.Y(n_198)
);

NAND4xp25_ASAP7_75t_L g199 ( 
.A(n_171),
.B(n_89),
.C(n_22),
.D(n_21),
.Y(n_199)
);

AOI221xp5_ASAP7_75t_L g200 ( 
.A1(n_171),
.A2(n_23),
.B1(n_21),
.B2(n_24),
.C(n_25),
.Y(n_200)
);

OAI211xp5_ASAP7_75t_L g201 ( 
.A1(n_171),
.A2(n_25),
.B(n_24),
.C(n_23),
.Y(n_201)
);

INVx1_ASAP7_75t_L g202 ( 
.A(n_195),
.Y(n_202)
);

NAND2xp5_ASAP7_75t_L g203 ( 
.A(n_182),
.B(n_89),
.Y(n_203)
);

OAI221xp5_ASAP7_75t_SL g204 ( 
.A1(n_200),
.A2(n_26),
.B1(n_75),
.B2(n_79),
.C(n_72),
.Y(n_204)
);

AOI22xp5_ASAP7_75t_L g205 ( 
.A1(n_199),
.A2(n_75),
.B1(n_64),
.B2(n_66),
.Y(n_205)
);

AO22x2_ASAP7_75t_L g206 ( 
.A1(n_185),
.A2(n_26),
.B1(n_72),
.B2(n_75),
.Y(n_206)
);

NAND3xp33_ASAP7_75t_SL g207 ( 
.A(n_196),
.B(n_2),
.C(n_1),
.Y(n_207)
);

O2A1O1Ixp33_ASAP7_75t_L g208 ( 
.A1(n_201),
.A2(n_75),
.B(n_5),
.C(n_3),
.Y(n_208)
);

AOI22xp5_ASAP7_75t_L g209 ( 
.A1(n_179),
.A2(n_180),
.B1(n_191),
.B2(n_188),
.Y(n_209)
);

AOI21xp5_ASAP7_75t_L g210 ( 
.A1(n_181),
.A2(n_64),
.B(n_66),
.Y(n_210)
);

AND2x4_ASAP7_75t_L g211 ( 
.A(n_189),
.B(n_64),
.Y(n_211)
);

NOR2xp33_ASAP7_75t_L g212 ( 
.A(n_194),
.B(n_184),
.Y(n_212)
);

OAI221xp5_ASAP7_75t_L g213 ( 
.A1(n_183),
.A2(n_66),
.B1(n_10),
.B2(n_8),
.C(n_9),
.Y(n_213)
);

OAI21xp33_ASAP7_75t_L g214 ( 
.A1(n_196),
.A2(n_66),
.B(n_11),
.Y(n_214)
);

CKINVDCx5p33_ASAP7_75t_R g215 ( 
.A(n_209),
.Y(n_215)
);

HB1xp67_ASAP7_75t_L g216 ( 
.A(n_202),
.Y(n_216)
);

INVx1_ASAP7_75t_L g217 ( 
.A(n_203),
.Y(n_217)
);

NAND4xp25_ASAP7_75t_L g218 ( 
.A(n_204),
.B(n_187),
.C(n_193),
.D(n_197),
.Y(n_218)
);

AOI21xp5_ASAP7_75t_L g219 ( 
.A1(n_213),
.A2(n_206),
.B(n_214),
.Y(n_219)
);

AOI21xp5_ASAP7_75t_L g220 ( 
.A1(n_206),
.A2(n_190),
.B(n_186),
.Y(n_220)
);

NOR2xp67_ASAP7_75t_L g221 ( 
.A(n_212),
.B(n_198),
.Y(n_221)
);

AND2x4_ASAP7_75t_L g222 ( 
.A(n_211),
.B(n_192),
.Y(n_222)
);

XNOR2xp5_ASAP7_75t_L g223 ( 
.A(n_215),
.B(n_205),
.Y(n_223)
);

OAI22xp5_ASAP7_75t_L g224 ( 
.A1(n_221),
.A2(n_210),
.B1(n_208),
.B2(n_192),
.Y(n_224)
);

CKINVDCx20_ASAP7_75t_R g225 ( 
.A(n_219),
.Y(n_225)
);

INVx1_ASAP7_75t_L g226 ( 
.A(n_216),
.Y(n_226)
);

AOI22x1_ASAP7_75t_L g227 ( 
.A1(n_223),
.A2(n_220),
.B1(n_222),
.B2(n_217),
.Y(n_227)
);

INVx1_ASAP7_75t_SL g228 ( 
.A(n_226),
.Y(n_228)
);

XOR2xp5_ASAP7_75t_L g229 ( 
.A(n_227),
.B(n_225),
.Y(n_229)
);

AOI22xp5_ASAP7_75t_SL g230 ( 
.A1(n_229),
.A2(n_228),
.B1(n_224),
.B2(n_227),
.Y(n_230)
);

AOI21xp5_ASAP7_75t_L g231 ( 
.A1(n_230),
.A2(n_218),
.B(n_207),
.Y(n_231)
);


endmodule