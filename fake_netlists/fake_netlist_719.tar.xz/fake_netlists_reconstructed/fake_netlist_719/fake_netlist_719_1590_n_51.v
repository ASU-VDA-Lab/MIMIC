module fake_netlist_719_1590_n_51 (n_12, n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_51);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_51;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_37;
wire n_29;
wire n_36;
wire n_41;
wire n_13;
wire n_43;
wire n_31;
wire n_18;
wire n_28;
wire n_39;
wire n_45;
wire n_25;
wire n_22;
wire n_46;
wire n_23;
wire n_15;
wire n_21;
wire n_47;
wire n_44;
wire n_42;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_16;
wire n_26;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_11),
.Y(n_13)
);

XNOR2xp5_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_3),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_6),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_4),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_0),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_8),
.Y(n_18)
);

INVxp67_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_0),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_4),
.Y(n_21)
);

AOI21xp5_ASAP7_75t_L g22 ( 
.A1(n_15),
.A2(n_12),
.B(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_16),
.B(n_1),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_15),
.A2(n_3),
.B(n_2),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

O2A1O1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_19),
.A2(n_6),
.B(n_5),
.C(n_2),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_26),
.Y(n_30)
);

OAI211xp5_ASAP7_75t_L g31 ( 
.A1(n_24),
.A2(n_23),
.B(n_17),
.C(n_28),
.Y(n_31)
);

INVx2_ASAP7_75t_L g32 ( 
.A(n_26),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_24),
.B(n_15),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_29),
.B(n_13),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_18),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_31),
.B(n_21),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_31),
.B(n_30),
.Y(n_37)
);

INVxp67_ASAP7_75t_SL g38 ( 
.A(n_37),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_35),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_36),
.B1(n_17),
.B2(n_14),
.C(n_34),
.Y(n_41)
);

AOI222xp33_ASAP7_75t_L g42 ( 
.A1(n_39),
.A2(n_14),
.B1(n_20),
.B2(n_32),
.C1(n_8),
.C2(n_7),
.Y(n_42)
);

OAI21xp5_ASAP7_75t_SL g43 ( 
.A1(n_40),
.A2(n_38),
.B(n_25),
.Y(n_43)
);

AOI322xp5_ASAP7_75t_L g44 ( 
.A1(n_38),
.A2(n_32),
.A3(n_10),
.B1(n_11),
.B2(n_7),
.C1(n_9),
.C2(n_22),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_44),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

BUFx2_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_42),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_47),
.Y(n_49)
);

NAND3xp33_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_45),
.C(n_48),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_SL g51 ( 
.A1(n_50),
.A2(n_40),
.B1(n_46),
.B2(n_49),
.Y(n_51)
);


endmodule