module fake_netlist_719_1316_n_26 (n_8, n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_26);

input n_8;
input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_26;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_11;
wire n_9;
wire n_25;
wire n_12;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_3),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_R g11 ( 
.A(n_8),
.B(n_0),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

NOR3xp33_ASAP7_75t_SL g13 ( 
.A(n_10),
.B(n_1),
.C(n_0),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

INVx4_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI221xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_10),
.B1(n_12),
.B2(n_13),
.C(n_14),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_SL g19 ( 
.A(n_17),
.B(n_9),
.C(n_11),
.Y(n_19)
);

AOI221x1_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_12),
.B1(n_15),
.B2(n_1),
.C(n_2),
.Y(n_20)
);

OA22x2_ASAP7_75t_L g21 ( 
.A1(n_18),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_L g23 ( 
.A(n_20),
.B(n_19),
.C(n_4),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_22),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_24),
.B1(n_7),
.B2(n_6),
.Y(n_26)
);


endmodule