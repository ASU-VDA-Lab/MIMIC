module fake_netlist_719_2606_n_55 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_5, n_55);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_5;

output n_55;

wire n_32;
wire n_33;
wire n_48;
wire n_30;
wire n_35;
wire n_54;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_37;
wire n_29;
wire n_36;
wire n_41;
wire n_43;
wire n_31;
wire n_18;
wire n_45;
wire n_28;
wire n_39;
wire n_52;
wire n_25;
wire n_46;
wire n_23;
wire n_21;
wire n_47;
wire n_26;
wire n_44;
wire n_42;
wire n_53;
wire n_50;
wire n_38;
wire n_49;
wire n_34;
wire n_40;
wire n_51;
wire n_22;
wire n_19;

INVx1_ASAP7_75t_L g17 ( 
.A(n_13),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_L g22 ( 
.A(n_15),
.B(n_1),
.Y(n_22)
);

NOR2xp67_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_3),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_18),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_0),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_17),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_23),
.A2(n_22),
.B1(n_24),
.B2(n_20),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_20),
.Y(n_32)
);

BUFx6f_ASAP7_75t_L g33 ( 
.A(n_29),
.Y(n_33)
);

OR2x2_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_31),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_29),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

AO21x2_ASAP7_75t_L g37 ( 
.A1(n_34),
.A2(n_28),
.B(n_21),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_R g38 ( 
.A(n_35),
.B(n_19),
.Y(n_38)
);

AND2x2_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_32),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_33),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_36),
.Y(n_41)
);

NAND2xp33_ASAP7_75t_SL g42 ( 
.A(n_39),
.B(n_27),
.Y(n_42)
);

O2A1O1Ixp33_ASAP7_75t_L g43 ( 
.A1(n_39),
.A2(n_40),
.B(n_41),
.C(n_27),
.Y(n_43)
);

OAI321xp33_ASAP7_75t_L g44 ( 
.A1(n_41),
.A2(n_17),
.A3(n_33),
.B1(n_38),
.B2(n_4),
.C(n_3),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

AOI221xp5_ASAP7_75t_SL g46 ( 
.A1(n_44),
.A2(n_26),
.B1(n_19),
.B2(n_38),
.C(n_4),
.Y(n_46)
);

HB1xp67_ASAP7_75t_L g47 ( 
.A(n_42),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_44),
.Y(n_48)
);

NOR2xp33_ASAP7_75t_L g49 ( 
.A(n_47),
.B(n_45),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_5),
.Y(n_50)
);

AOI22xp33_ASAP7_75t_R g51 ( 
.A1(n_48),
.A2(n_6),
.B1(n_19),
.B2(n_7),
.Y(n_51)
);

NOR3xp33_ASAP7_75t_SL g52 ( 
.A(n_48),
.B(n_6),
.C(n_8),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

CKINVDCx20_ASAP7_75t_R g54 ( 
.A(n_49),
.Y(n_54)
);

AOI322xp5_ASAP7_75t_L g55 ( 
.A1(n_54),
.A2(n_9),
.A3(n_12),
.B1(n_46),
.B2(n_51),
.C1(n_52),
.C2(n_53),
.Y(n_55)
);


endmodule