module fake_netlist_719_1126_n_6 (n_0, n_3, n_2, n_1, n_6);

input n_0;
input n_3;
input n_2;
input n_1;

output n_6;

wire n_4;
wire n_5;

AND2x2_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_0),
.Y(n_4)
);

HB1xp67_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

NAND4xp25_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_1),
.C(n_5),
.D(n_0),
.Y(n_6)
);


endmodule