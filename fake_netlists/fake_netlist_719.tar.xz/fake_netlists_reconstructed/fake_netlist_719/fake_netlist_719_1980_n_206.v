module fake_netlist_719_1980_n_206 (n_3, n_14, n_20, n_0, n_27, n_2, n_17, n_24, n_29, n_13, n_7, n_18, n_28, n_11, n_9, n_4, n_25, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_26, n_16, n_22, n_6, n_19, n_5, n_206);

input n_3;
input n_14;
input n_20;
input n_0;
input n_27;
input n_2;
input n_17;
input n_24;
input n_29;
input n_13;
input n_7;
input n_18;
input n_28;
input n_11;
input n_9;
input n_4;
input n_25;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_26;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_206;

wire n_154;
wire n_68;
wire n_185;
wire n_82;
wire n_37;
wire n_112;
wire n_141;
wire n_198;
wire n_31;
wire n_188;
wire n_39;
wire n_173;
wire n_121;
wire n_164;
wire n_162;
wire n_65;
wire n_179;
wire n_140;
wire n_184;
wire n_144;
wire n_171;
wire n_128;
wire n_181;
wire n_56;
wire n_130;
wire n_159;
wire n_165;
wire n_94;
wire n_62;
wire n_69;
wire n_123;
wire n_97;
wire n_193;
wire n_135;
wire n_139;
wire n_202;
wire n_55;
wire n_148;
wire n_110;
wire n_172;
wire n_102;
wire n_60;
wire n_105;
wire n_195;
wire n_33;
wire n_61;
wire n_75;
wire n_174;
wire n_106;
wire n_79;
wire n_30;
wire n_186;
wire n_118;
wire n_194;
wire n_54;
wire n_168;
wire n_73;
wire n_77;
wire n_196;
wire n_125;
wire n_131;
wire n_85;
wire n_126;
wire n_169;
wire n_120;
wire n_116;
wire n_132;
wire n_70;
wire n_142;
wire n_129;
wire n_67;
wire n_81;
wire n_92;
wire n_155;
wire n_44;
wire n_74;
wire n_124;
wire n_53;
wire n_64;
wire n_107;
wire n_138;
wire n_200;
wire n_204;
wire n_49;
wire n_40;
wire n_51;
wire n_147;
wire n_163;
wire n_59;
wire n_111;
wire n_166;
wire n_161;
wire n_190;
wire n_117;
wire n_93;
wire n_158;
wire n_84;
wire n_180;
wire n_32;
wire n_48;
wire n_143;
wire n_35;
wire n_136;
wire n_96;
wire n_182;
wire n_104;
wire n_115;
wire n_201;
wire n_41;
wire n_98;
wire n_203;
wire n_183;
wire n_100;
wire n_145;
wire n_76;
wire n_57;
wire n_43;
wire n_137;
wire n_71;
wire n_113;
wire n_80;
wire n_108;
wire n_119;
wire n_160;
wire n_189;
wire n_205;
wire n_87;
wire n_176;
wire n_42;
wire n_167;
wire n_156;
wire n_199;
wire n_34;
wire n_89;
wire n_58;
wire n_86;
wire n_72;
wire n_192;
wire n_114;
wire n_151;
wire n_90;
wire n_197;
wire n_63;
wire n_101;
wire n_127;
wire n_146;
wire n_36;
wire n_66;
wire n_83;
wire n_91;
wire n_95;
wire n_150;
wire n_152;
wire n_45;
wire n_52;
wire n_187;
wire n_133;
wire n_78;
wire n_153;
wire n_46;
wire n_122;
wire n_88;
wire n_134;
wire n_191;
wire n_99;
wire n_157;
wire n_47;
wire n_50;
wire n_38;
wire n_109;
wire n_178;
wire n_170;
wire n_175;
wire n_103;
wire n_177;
wire n_149;

INVx1_ASAP7_75t_L g30 ( 
.A(n_8),
.Y(n_30)
);

BUFx3_ASAP7_75t_L g31 ( 
.A(n_27),
.Y(n_31)
);

CKINVDCx20_ASAP7_75t_R g32 ( 
.A(n_2),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_4),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_14),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_16),
.Y(n_35)
);

INVxp33_ASAP7_75t_SL g36 ( 
.A(n_5),
.Y(n_36)
);

INVxp67_ASAP7_75t_L g37 ( 
.A(n_18),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_29),
.Y(n_38)
);

CKINVDCx5p33_ASAP7_75t_R g39 ( 
.A(n_4),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_12),
.Y(n_40)
);

INVxp67_ASAP7_75t_L g41 ( 
.A(n_7),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_6),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_9),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_33),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_33),
.Y(n_45)
);

INVx2_ASAP7_75t_L g46 ( 
.A(n_33),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_33),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_33),
.Y(n_48)
);

INVx3_ASAP7_75t_L g49 ( 
.A(n_33),
.Y(n_49)
);

NAND2xp33_ASAP7_75t_SL g50 ( 
.A(n_33),
.B(n_5),
.Y(n_50)
);

AOI22xp5_ASAP7_75t_L g51 ( 
.A1(n_36),
.A2(n_14),
.B1(n_7),
.B2(n_6),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_38),
.B(n_15),
.Y(n_52)
);

NOR2xp67_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_38),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_38),
.Y(n_54)
);

OR2x2_ASAP7_75t_L g55 ( 
.A(n_45),
.B(n_37),
.Y(n_55)
);

BUFx2_ASAP7_75t_L g56 ( 
.A(n_50),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_52),
.A2(n_36),
.B1(n_42),
.B2(n_39),
.Y(n_57)
);

OAI221xp5_ASAP7_75t_L g58 ( 
.A1(n_51),
.A2(n_37),
.B1(n_41),
.B2(n_31),
.C(n_34),
.Y(n_58)
);

AO22x2_ASAP7_75t_L g59 ( 
.A1(n_49),
.A2(n_35),
.B1(n_34),
.B2(n_38),
.Y(n_59)
);

AO22x2_ASAP7_75t_L g60 ( 
.A1(n_49),
.A2(n_35),
.B1(n_34),
.B2(n_38),
.Y(n_60)
);

AO22x2_ASAP7_75t_L g61 ( 
.A1(n_45),
.A2(n_35),
.B1(n_38),
.B2(n_30),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_47),
.Y(n_62)
);

INVx2_ASAP7_75t_L g63 ( 
.A(n_62),
.Y(n_63)
);

INVx2_ASAP7_75t_L g64 ( 
.A(n_54),
.Y(n_64)
);

INVx1_ASAP7_75t_L g65 ( 
.A(n_60),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_L g66 ( 
.A(n_53),
.B(n_47),
.Y(n_66)
);

OAI22xp5_ASAP7_75t_SL g67 ( 
.A1(n_58),
.A2(n_51),
.B1(n_42),
.B2(n_39),
.Y(n_67)
);

AOI22xp33_ASAP7_75t_L g68 ( 
.A1(n_59),
.A2(n_60),
.B1(n_61),
.B2(n_38),
.Y(n_68)
);

INVx1_ASAP7_75t_L g69 ( 
.A(n_60),
.Y(n_69)
);

OAI22xp5_ASAP7_75t_L g70 ( 
.A1(n_57),
.A2(n_41),
.B1(n_37),
.B2(n_31),
.Y(n_70)
);

INVx2_ASAP7_75t_L g71 ( 
.A(n_54),
.Y(n_71)
);

OR2x2_ASAP7_75t_L g72 ( 
.A(n_55),
.B(n_41),
.Y(n_72)
);

INVx1_ASAP7_75t_L g73 ( 
.A(n_59),
.Y(n_73)
);

O2A1O1Ixp33_ASAP7_75t_L g74 ( 
.A1(n_56),
.A2(n_48),
.B(n_46),
.C(n_44),
.Y(n_74)
);

A2O1A1Ixp33_ASAP7_75t_L g75 ( 
.A1(n_59),
.A2(n_48),
.B(n_46),
.C(n_44),
.Y(n_75)
);

INVx1_ASAP7_75t_L g76 ( 
.A(n_63),
.Y(n_76)
);

O2A1O1Ixp5_ASAP7_75t_L g77 ( 
.A1(n_75),
.A2(n_46),
.B(n_44),
.C(n_30),
.Y(n_77)
);

AND2x4_ASAP7_75t_L g78 ( 
.A(n_65),
.B(n_30),
.Y(n_78)
);

INVx8_ASAP7_75t_L g79 ( 
.A(n_68),
.Y(n_79)
);

NAND2xp5_ASAP7_75t_SL g80 ( 
.A(n_64),
.B(n_32),
.Y(n_80)
);

AND2x2_ASAP7_75t_L g81 ( 
.A(n_71),
.B(n_61),
.Y(n_81)
);

AND2x4_ASAP7_75t_L g82 ( 
.A(n_65),
.B(n_40),
.Y(n_82)
);

AND2x4_ASAP7_75t_L g83 ( 
.A(n_69),
.B(n_40),
.Y(n_83)
);

NOR2xp33_ASAP7_75t_SL g84 ( 
.A(n_67),
.B(n_32),
.Y(n_84)
);

BUFx2_ASAP7_75t_L g85 ( 
.A(n_69),
.Y(n_85)
);

OR2x2_ASAP7_75t_L g86 ( 
.A(n_72),
.B(n_31),
.Y(n_86)
);

NAND2xp5_ASAP7_75t_L g87 ( 
.A(n_71),
.B(n_61),
.Y(n_87)
);

NAND2xp5_ASAP7_75t_SL g88 ( 
.A(n_64),
.B(n_40),
.Y(n_88)
);

NOR3xp33_ASAP7_75t_L g89 ( 
.A(n_80),
.B(n_67),
.C(n_70),
.Y(n_89)
);

AND2x4_ASAP7_75t_L g90 ( 
.A(n_85),
.B(n_73),
.Y(n_90)
);

AO32x2_ASAP7_75t_L g91 ( 
.A1(n_77),
.A2(n_73),
.A3(n_74),
.B1(n_71),
.B2(n_63),
.Y(n_91)
);

AND2x2_ASAP7_75t_L g92 ( 
.A(n_81),
.B(n_85),
.Y(n_92)
);

NOR2xp33_ASAP7_75t_L g93 ( 
.A(n_84),
.B(n_72),
.Y(n_93)
);

AND2x2_ASAP7_75t_L g94 ( 
.A(n_81),
.B(n_63),
.Y(n_94)
);

O2A1O1Ixp33_ASAP7_75t_L g95 ( 
.A1(n_87),
.A2(n_66),
.B(n_31),
.C(n_43),
.Y(n_95)
);

OAI22xp5_ASAP7_75t_L g96 ( 
.A1(n_79),
.A2(n_31),
.B1(n_43),
.B2(n_15),
.Y(n_96)
);

AND2x2_ASAP7_75t_L g97 ( 
.A(n_81),
.B(n_43),
.Y(n_97)
);

INVxp67_ASAP7_75t_L g98 ( 
.A(n_86),
.Y(n_98)
);

AND2x2_ASAP7_75t_L g99 ( 
.A(n_98),
.B(n_86),
.Y(n_99)
);

INVx2_ASAP7_75t_L g100 ( 
.A(n_94),
.Y(n_100)
);

HB1xp67_ASAP7_75t_L g101 ( 
.A(n_92),
.Y(n_101)
);

INVx2_ASAP7_75t_SL g102 ( 
.A(n_90),
.Y(n_102)
);

INVx2_ASAP7_75t_L g103 ( 
.A(n_94),
.Y(n_103)
);

AOI21xp33_ASAP7_75t_L g104 ( 
.A1(n_93),
.A2(n_84),
.B(n_79),
.Y(n_104)
);

INVx2_ASAP7_75t_L g105 ( 
.A(n_90),
.Y(n_105)
);

INVx3_ASAP7_75t_L g106 ( 
.A(n_90),
.Y(n_106)
);

AND2x2_ASAP7_75t_L g107 ( 
.A(n_100),
.B(n_92),
.Y(n_107)
);

HB1xp67_ASAP7_75t_L g108 ( 
.A(n_101),
.Y(n_108)
);

OR2x2_ASAP7_75t_L g109 ( 
.A(n_100),
.B(n_79),
.Y(n_109)
);

INVx1_ASAP7_75t_L g110 ( 
.A(n_103),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_103),
.Y(n_111)
);

AND2x2_ASAP7_75t_L g112 ( 
.A(n_105),
.B(n_97),
.Y(n_112)
);

NOR2xp33_ASAP7_75t_L g113 ( 
.A(n_104),
.B(n_89),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_105),
.Y(n_114)
);

INVxp67_ASAP7_75t_L g115 ( 
.A(n_108),
.Y(n_115)
);

NAND2xp5_ASAP7_75t_L g116 ( 
.A(n_107),
.B(n_99),
.Y(n_116)
);

OR2x2_ASAP7_75t_L g117 ( 
.A(n_108),
.B(n_96),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_110),
.Y(n_118)
);

INVx1_ASAP7_75t_SL g119 ( 
.A(n_107),
.Y(n_119)
);

NOR2xp33_ASAP7_75t_L g120 ( 
.A(n_113),
.B(n_106),
.Y(n_120)
);

AND2x4_ASAP7_75t_L g121 ( 
.A(n_110),
.B(n_111),
.Y(n_121)
);

OR2x2_ASAP7_75t_L g122 ( 
.A(n_111),
.B(n_96),
.Y(n_122)
);

AND2x2_ASAP7_75t_L g123 ( 
.A(n_114),
.B(n_97),
.Y(n_123)
);

NOR2xp33_ASAP7_75t_L g124 ( 
.A(n_109),
.B(n_106),
.Y(n_124)
);

AOI22xp33_ASAP7_75t_L g125 ( 
.A1(n_109),
.A2(n_106),
.B1(n_102),
.B2(n_79),
.Y(n_125)
);

NAND2xp5_ASAP7_75t_L g126 ( 
.A(n_112),
.B(n_102),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_118),
.Y(n_127)
);

AND2x2_ASAP7_75t_L g128 ( 
.A(n_121),
.B(n_114),
.Y(n_128)
);

NAND2xp5_ASAP7_75t_L g129 ( 
.A(n_120),
.B(n_112),
.Y(n_129)
);

HB1xp67_ASAP7_75t_L g130 ( 
.A(n_115),
.Y(n_130)
);

INVx1_ASAP7_75t_L g131 ( 
.A(n_118),
.Y(n_131)
);

INVxp67_ASAP7_75t_L g132 ( 
.A(n_116),
.Y(n_132)
);

INVx1_ASAP7_75t_L g133 ( 
.A(n_121),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_121),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_121),
.Y(n_135)
);

INVxp67_ASAP7_75t_SL g136 ( 
.A(n_124),
.Y(n_136)
);

NOR2x1_ASAP7_75t_L g137 ( 
.A(n_117),
.B(n_95),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_122),
.Y(n_138)
);

AND2x2_ASAP7_75t_L g139 ( 
.A(n_119),
.B(n_78),
.Y(n_139)
);

NAND2xp5_ASAP7_75t_L g140 ( 
.A(n_117),
.B(n_78),
.Y(n_140)
);

HB1xp67_ASAP7_75t_L g141 ( 
.A(n_122),
.Y(n_141)
);

AND2x2_ASAP7_75t_L g142 ( 
.A(n_123),
.B(n_78),
.Y(n_142)
);

NAND2x1_ASAP7_75t_L g143 ( 
.A(n_125),
.B(n_123),
.Y(n_143)
);

NOR2xp33_ASAP7_75t_L g144 ( 
.A(n_126),
.B(n_90),
.Y(n_144)
);

INVx1_ASAP7_75t_L g145 ( 
.A(n_127),
.Y(n_145)
);

OR2x2_ASAP7_75t_L g146 ( 
.A(n_138),
.B(n_43),
.Y(n_146)
);

INVx1_ASAP7_75t_SL g147 ( 
.A(n_130),
.Y(n_147)
);

NOR2xp33_ASAP7_75t_L g148 ( 
.A(n_132),
.B(n_16),
.Y(n_148)
);

AND2x2_ASAP7_75t_L g149 ( 
.A(n_133),
.B(n_43),
.Y(n_149)
);

NAND3xp33_ASAP7_75t_SL g150 ( 
.A(n_140),
.B(n_95),
.C(n_88),
.Y(n_150)
);

NAND2xp5_ASAP7_75t_L g151 ( 
.A(n_136),
.B(n_78),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_127),
.Y(n_152)
);

NAND2xp5_ASAP7_75t_L g153 ( 
.A(n_141),
.B(n_78),
.Y(n_153)
);

O2A1O1Ixp33_ASAP7_75t_L g154 ( 
.A1(n_140),
.A2(n_82),
.B(n_83),
.C(n_87),
.Y(n_154)
);

OAI221xp5_ASAP7_75t_L g155 ( 
.A1(n_137),
.A2(n_143),
.B1(n_144),
.B2(n_129),
.C(n_138),
.Y(n_155)
);

AND2x2_ASAP7_75t_L g156 ( 
.A(n_133),
.B(n_134),
.Y(n_156)
);

NAND2xp5_ASAP7_75t_SL g157 ( 
.A(n_137),
.B(n_76),
.Y(n_157)
);

AND2x2_ASAP7_75t_L g158 ( 
.A(n_134),
.B(n_82),
.Y(n_158)
);

NAND4xp25_ASAP7_75t_L g159 ( 
.A(n_131),
.B(n_83),
.C(n_82),
.D(n_77),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_131),
.Y(n_160)
);

NAND2xp5_ASAP7_75t_L g161 ( 
.A(n_128),
.B(n_135),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_135),
.Y(n_162)
);

NOR2xp33_ASAP7_75t_L g163 ( 
.A(n_128),
.B(n_17),
.Y(n_163)
);

NOR3xp33_ASAP7_75t_L g164 ( 
.A(n_143),
.B(n_82),
.C(n_83),
.Y(n_164)
);

NAND2xp5_ASAP7_75t_L g165 ( 
.A(n_147),
.B(n_142),
.Y(n_165)
);

NAND2xp5_ASAP7_75t_L g166 ( 
.A(n_161),
.B(n_142),
.Y(n_166)
);

NOR2xp33_ASAP7_75t_L g167 ( 
.A(n_155),
.B(n_139),
.Y(n_167)
);

AO221x1_ASAP7_75t_L g168 ( 
.A1(n_145),
.A2(n_76),
.B1(n_19),
.B2(n_17),
.C(n_18),
.Y(n_168)
);

INVx1_ASAP7_75t_L g169 ( 
.A(n_145),
.Y(n_169)
);

NAND2xp5_ASAP7_75t_SL g170 ( 
.A(n_146),
.B(n_139),
.Y(n_170)
);

NAND2xp5_ASAP7_75t_L g171 ( 
.A(n_156),
.B(n_19),
.Y(n_171)
);

AOI21xp5_ASAP7_75t_L g172 ( 
.A1(n_157),
.A2(n_79),
.B(n_82),
.Y(n_172)
);

AND2x4_ASAP7_75t_L g173 ( 
.A(n_156),
.B(n_20),
.Y(n_173)
);

AOI21xp33_ASAP7_75t_SL g174 ( 
.A1(n_163),
.A2(n_21),
.B(n_20),
.Y(n_174)
);

INVx1_ASAP7_75t_L g175 ( 
.A(n_152),
.Y(n_175)
);

INVx1_ASAP7_75t_L g176 ( 
.A(n_152),
.Y(n_176)
);

NAND2xp5_ASAP7_75t_L g177 ( 
.A(n_149),
.B(n_21),
.Y(n_177)
);

NAND3xp33_ASAP7_75t_L g178 ( 
.A(n_146),
.B(n_164),
.C(n_149),
.Y(n_178)
);

NAND2xp5_ASAP7_75t_L g179 ( 
.A(n_162),
.B(n_160),
.Y(n_179)
);

INVxp67_ASAP7_75t_L g180 ( 
.A(n_148),
.Y(n_180)
);

INVx2_ASAP7_75t_L g181 ( 
.A(n_160),
.Y(n_181)
);

NAND3xp33_ASAP7_75t_L g182 ( 
.A(n_167),
.B(n_174),
.C(n_178),
.Y(n_182)
);

OAI21xp5_ASAP7_75t_L g183 ( 
.A1(n_167),
.A2(n_180),
.B(n_171),
.Y(n_183)
);

NOR3xp33_ASAP7_75t_L g184 ( 
.A(n_177),
.B(n_150),
.C(n_153),
.Y(n_184)
);

NAND4xp75_ASAP7_75t_L g185 ( 
.A(n_170),
.B(n_151),
.C(n_158),
.D(n_162),
.Y(n_185)
);

AO22x2_ASAP7_75t_L g186 ( 
.A1(n_173),
.A2(n_158),
.B1(n_83),
.B2(n_159),
.Y(n_186)
);

AND2x2_ASAP7_75t_L g187 ( 
.A(n_166),
.B(n_154),
.Y(n_187)
);

AND2x4_ASAP7_75t_L g188 ( 
.A(n_181),
.B(n_83),
.Y(n_188)
);

OAI31xp33_ASAP7_75t_L g189 ( 
.A1(n_173),
.A2(n_24),
.A3(n_23),
.B(n_22),
.Y(n_189)
);

NOR2x1p5_ASAP7_75t_L g190 ( 
.A(n_173),
.B(n_22),
.Y(n_190)
);

OAI221xp5_ASAP7_75t_L g191 ( 
.A1(n_165),
.A2(n_24),
.B1(n_23),
.B2(n_25),
.C(n_26),
.Y(n_191)
);

NAND3xp33_ASAP7_75t_L g192 ( 
.A(n_170),
.B(n_175),
.C(n_169),
.Y(n_192)
);

AOI211xp5_ASAP7_75t_L g193 ( 
.A1(n_182),
.A2(n_191),
.B(n_183),
.C(n_189),
.Y(n_193)
);

INVx2_ASAP7_75t_L g194 ( 
.A(n_192),
.Y(n_194)
);

OAI22xp5_ASAP7_75t_SL g195 ( 
.A1(n_190),
.A2(n_168),
.B1(n_176),
.B2(n_179),
.Y(n_195)
);

AOI322xp5_ASAP7_75t_L g196 ( 
.A1(n_187),
.A2(n_181),
.A3(n_27),
.B1(n_26),
.B2(n_25),
.C1(n_29),
.C2(n_28),
.Y(n_196)
);

OAI22xp5_ASAP7_75t_L g197 ( 
.A1(n_186),
.A2(n_185),
.B1(n_184),
.B2(n_172),
.Y(n_197)
);

NOR2x1p5_ASAP7_75t_L g198 ( 
.A(n_186),
.B(n_28),
.Y(n_198)
);

NOR2x1p5_ASAP7_75t_L g199 ( 
.A(n_188),
.B(n_0),
.Y(n_199)
);

AOI322xp5_ASAP7_75t_L g200 ( 
.A1(n_194),
.A2(n_188),
.A3(n_79),
.B1(n_91),
.B2(n_3),
.C1(n_1),
.C2(n_10),
.Y(n_200)
);

AOI211xp5_ASAP7_75t_L g201 ( 
.A1(n_195),
.A2(n_13),
.B(n_11),
.C(n_91),
.Y(n_201)
);

OAI22xp5_ASAP7_75t_L g202 ( 
.A1(n_197),
.A2(n_91),
.B1(n_193),
.B2(n_198),
.Y(n_202)
);

AOI21xp5_ASAP7_75t_L g203 ( 
.A1(n_202),
.A2(n_197),
.B(n_196),
.Y(n_203)
);

XOR2xp5_ASAP7_75t_L g204 ( 
.A(n_201),
.B(n_199),
.Y(n_204)
);

NAND2xp5_ASAP7_75t_L g205 ( 
.A(n_203),
.B(n_200),
.Y(n_205)
);

AOI221xp5_ASAP7_75t_L g206 ( 
.A1(n_205),
.A2(n_91),
.B1(n_204),
.B2(n_203),
.C(n_202),
.Y(n_206)
);


endmodule