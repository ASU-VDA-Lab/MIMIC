module fake_netlist_719_758_n_15 (n_1, n_2, n_0, n_3, n_4, n_15);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_15;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_14;
wire n_5;

INVx2_ASAP7_75t_L g5 ( 
.A(n_4),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_3),
.Y(n_6)
);

BUFx3_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AND2x4_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_0),
.Y(n_8)
);

NAND2x1p5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_2),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_8),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVxp33_ASAP7_75t_L g12 ( 
.A(n_9),
.Y(n_12)
);

OAI21xp33_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_8),
.B(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

AOI222xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_1),
.B1(n_12),
.B2(n_13),
.C1(n_8),
.C2(n_11),
.Y(n_15)
);


endmodule