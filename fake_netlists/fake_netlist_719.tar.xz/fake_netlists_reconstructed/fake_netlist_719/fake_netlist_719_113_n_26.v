module fake_netlist_719_113_n_26 (n_12, n_8, n_1, n_2, n_11, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_26);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_26;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_18;
wire n_25;
wire n_23;
wire n_15;
wire n_21;
wire n_16;
wire n_22;
wire n_19;

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_11),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_9),
.B(n_6),
.Y(n_17)
);

AOI21xp5_ASAP7_75t_L g18 ( 
.A1(n_13),
.A2(n_1),
.B(n_0),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_17),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_19),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI221xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_16),
.B1(n_15),
.B2(n_14),
.C(n_4),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_24),
.B(n_5),
.Y(n_25)
);

AOI22xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_10),
.B1(n_8),
.B2(n_7),
.Y(n_26)
);


endmodule