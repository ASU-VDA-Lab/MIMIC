module fake_netlist_719_2275_n_32 (n_8, n_1, n_2, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_32);

input n_8;
input n_1;
input n_2;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_32;

wire n_30;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_13;
wire n_18;
wire n_31;
wire n_28;
wire n_11;
wire n_25;
wire n_12;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_1),
.Y(n_12)
);

AND3x2_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_5),
.C(n_0),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_0),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_9),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_2),
.Y(n_16)
);

AOI21x1_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_2),
.B(n_1),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

A2O1A1Ixp33_ASAP7_75t_L g19 ( 
.A1(n_12),
.A2(n_16),
.B(n_14),
.C(n_11),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

NOR2xp67_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_3),
.Y(n_21)
);

AND2x4_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_13),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

O2A1O1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_19),
.B(n_16),
.C(n_12),
.Y(n_24)
);

AOI211xp5_ASAP7_75t_SL g25 ( 
.A1(n_22),
.A2(n_21),
.B(n_4),
.C(n_3),
.Y(n_25)
);

OAI22xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_22),
.B1(n_23),
.B2(n_18),
.Y(n_26)
);

O2A1O1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_26),
.Y(n_28)
);

INVx2_ASAP7_75t_SL g29 ( 
.A(n_27),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_26),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AOI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_10),
.B1(n_30),
.B2(n_28),
.Y(n_32)
);


endmodule