module fake_netlist_719_2283_n_27 (n_1, n_2, n_0, n_3, n_4, n_5, n_27);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;
input n_5;

output n_27;

wire n_14;
wire n_20;
wire n_17;
wire n_24;
wire n_13;
wire n_7;
wire n_18;
wire n_11;
wire n_9;
wire n_25;
wire n_12;
wire n_8;
wire n_23;
wire n_10;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_6;
wire n_19;

INVx2_ASAP7_75t_SL g6 ( 
.A(n_2),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_1),
.Y(n_9)
);

AND3x2_ASAP7_75t_L g10 ( 
.A(n_1),
.B(n_5),
.C(n_3),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_1),
.B(n_2),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_6),
.B(n_8),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_SL g13 ( 
.A1(n_7),
.A2(n_5),
.B(n_4),
.C(n_3),
.Y(n_13)
);

AO31x2_ASAP7_75t_L g14 ( 
.A1(n_8),
.A2(n_4),
.A3(n_9),
.B(n_7),
.Y(n_14)
);

AOI21xp33_ASAP7_75t_SL g15 ( 
.A1(n_12),
.A2(n_9),
.B(n_10),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_11),
.Y(n_16)
);

BUFx2_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_13),
.B(n_15),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_19),
.Y(n_21)
);

OAI31xp33_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_18),
.A3(n_17),
.B(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_20),
.Y(n_23)
);

NOR3xp33_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_21),
.C(n_22),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

XNOR2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_21),
.Y(n_26)
);

AO21x2_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_25),
.B(n_22),
.Y(n_27)
);


endmodule