module fake_netlist_719_1179_n_22 (n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_22);

input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_22;

wire n_14;
wire n_20;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_9;
wire n_12;
wire n_8;
wire n_10;
wire n_15;
wire n_21;
wire n_16;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_3),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_6),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_1),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_4),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

OR2x2_ASAP7_75t_SL g14 ( 
.A(n_13),
.B(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AO22x2_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_15),
.B1(n_12),
.B2(n_6),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI222xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_16),
.B1(n_11),
.B2(n_10),
.C1(n_7),
.C2(n_0),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_2),
.B(n_1),
.Y(n_20)
);

OAI22x1_ASAP7_75t_SL g21 ( 
.A1(n_18),
.A2(n_7),
.B1(n_3),
.B2(n_2),
.Y(n_21)
);

AOI22xp5_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_5),
.B1(n_18),
.B2(n_20),
.Y(n_22)
);


endmodule