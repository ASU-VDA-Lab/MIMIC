module fake_netlist_719_1084_n_14 (n_1, n_2, n_0, n_3, n_4, n_14);

input n_1;
input n_2;
input n_0;
input n_3;
input n_4;

output n_14;

wire n_12;
wire n_8;
wire n_11;
wire n_13;
wire n_7;
wire n_10;
wire n_9;
wire n_6;
wire n_5;

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_1),
.Y(n_5)
);

AND2x6_ASAP7_75t_L g6 ( 
.A(n_3),
.B(n_4),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

A2O1A1Ixp33_ASAP7_75t_L g8 ( 
.A1(n_7),
.A2(n_6),
.B(n_1),
.C(n_0),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

INVxp67_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_1),
.B2(n_0),
.C(n_2),
.Y(n_11)
);

XNOR2xp5_ASAP7_75t_L g12 ( 
.A(n_10),
.B(n_2),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

AOI222xp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_3),
.B1(n_4),
.B2(n_11),
.C1(n_12),
.C2(n_7),
.Y(n_14)
);


endmodule