module fake_netlist_719_270_n_37 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_15, n_16, n_6, n_14, n_0, n_3, n_4, n_17, n_5, n_37);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_15;
input n_16;
input n_6;
input n_14;
input n_0;
input n_3;
input n_4;
input n_17;
input n_5;

output n_37;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_20;
wire n_27;
wire n_24;
wire n_36;
wire n_29;
wire n_31;
wire n_18;
wire n_28;
wire n_25;
wire n_23;
wire n_21;
wire n_26;
wire n_34;
wire n_22;
wire n_19;

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_8),
.Y(n_18)
);

AOI21x1_ASAP7_75t_L g19 ( 
.A1(n_9),
.A2(n_2),
.B(n_1),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_11),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_17),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_16),
.Y(n_23)
);

NOR2xp33_ASAP7_75t_L g24 ( 
.A(n_3),
.B(n_14),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_13),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_0),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

INVx5_ASAP7_75t_L g28 ( 
.A(n_25),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_21),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_27),
.B(n_22),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_26),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_19),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

NOR4xp25_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_24),
.C(n_32),
.D(n_23),
.Y(n_34)
);

INVx1_ASAP7_75t_SL g35 ( 
.A(n_34),
.Y(n_35)
);

OAI22xp5_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_15),
.B1(n_12),
.B2(n_10),
.Y(n_37)
);


endmodule