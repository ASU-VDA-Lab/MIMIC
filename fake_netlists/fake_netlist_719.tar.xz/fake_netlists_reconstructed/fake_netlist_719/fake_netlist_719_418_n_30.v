module fake_netlist_719_418_n_30 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_30);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_30;

wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_24;
wire n_29;
wire n_18;
wire n_28;
wire n_25;
wire n_23;
wire n_15;
wire n_21;
wire n_26;
wire n_16;
wire n_22;
wire n_19;

INVx2_ASAP7_75t_L g14 ( 
.A(n_2),
.Y(n_14)
);

NOR2xp33_ASAP7_75t_R g15 ( 
.A(n_13),
.B(n_4),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_12),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_1),
.B(n_13),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_17),
.B(n_14),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_22)
);

AND2x2_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_18),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_21),
.Y(n_25)
);

OAI321xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_20),
.A3(n_23),
.B1(n_15),
.B2(n_12),
.C(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx1_ASAP7_75t_SL g29 ( 
.A(n_28),
.Y(n_29)
);

AOI322xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_7),
.A3(n_5),
.B1(n_10),
.B2(n_11),
.C1(n_8),
.C2(n_9),
.Y(n_30)
);


endmodule