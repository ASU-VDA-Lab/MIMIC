module fake_netlist_719_2203_n_19 (n_8, n_1, n_2, n_7, n_9, n_6, n_0, n_3, n_4, n_5, n_19);

input n_8;
input n_1;
input n_2;
input n_7;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_19;

wire n_14;
wire n_17;
wire n_13;
wire n_18;
wire n_11;
wire n_12;
wire n_10;
wire n_15;
wire n_16;

INVx2_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

INVxp33_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

BUFx4f_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

BUFx3_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_10),
.A2(n_5),
.B1(n_4),
.B2(n_6),
.C(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

OAI22xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B1(n_12),
.B2(n_13),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_12),
.B1(n_11),
.B2(n_13),
.C(n_4),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_6),
.B(n_0),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_8),
.B1(n_2),
.B2(n_1),
.Y(n_19)
);


endmodule