module fake_netlist_719_1480_n_17 (n_1, n_2, n_7, n_6, n_0, n_3, n_4, n_5, n_17);

input n_1;
input n_2;
input n_7;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_17;

wire n_12;
wire n_8;
wire n_10;
wire n_15;
wire n_14;
wire n_13;
wire n_16;
wire n_9;
wire n_11;

INVx3_ASAP7_75t_L g8 ( 
.A(n_2),
.Y(n_8)
);

NOR2xp33_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_0),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_SL g11 ( 
.A(n_7),
.B(n_6),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_8),
.A2(n_3),
.B(n_1),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_12),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

XNOR2x1_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.Y(n_15)
);

OAI22xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B1(n_8),
.B2(n_9),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_6),
.B(n_5),
.Y(n_17)
);


endmodule