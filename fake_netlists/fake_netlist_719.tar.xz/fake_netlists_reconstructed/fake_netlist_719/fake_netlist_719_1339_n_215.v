module fake_netlist_719_1339_n_215 (n_3, n_30, n_14, n_20, n_0, n_27, n_2, n_17, n_24, n_29, n_13, n_7, n_18, n_28, n_11, n_9, n_4, n_25, n_12, n_8, n_1, n_23, n_10, n_15, n_21, n_26, n_16, n_22, n_6, n_19, n_5, n_215);

input n_3;
input n_30;
input n_14;
input n_20;
input n_0;
input n_27;
input n_2;
input n_17;
input n_24;
input n_29;
input n_13;
input n_7;
input n_18;
input n_28;
input n_11;
input n_9;
input n_4;
input n_25;
input n_12;
input n_8;
input n_1;
input n_23;
input n_10;
input n_15;
input n_21;
input n_26;
input n_16;
input n_22;
input n_6;
input n_19;
input n_5;

output n_215;

wire n_154;
wire n_207;
wire n_209;
wire n_68;
wire n_185;
wire n_82;
wire n_37;
wire n_112;
wire n_141;
wire n_198;
wire n_31;
wire n_188;
wire n_39;
wire n_173;
wire n_121;
wire n_164;
wire n_162;
wire n_65;
wire n_184;
wire n_140;
wire n_179;
wire n_144;
wire n_171;
wire n_210;
wire n_128;
wire n_181;
wire n_212;
wire n_56;
wire n_130;
wire n_159;
wire n_165;
wire n_94;
wire n_62;
wire n_69;
wire n_123;
wire n_97;
wire n_193;
wire n_135;
wire n_139;
wire n_202;
wire n_55;
wire n_148;
wire n_110;
wire n_172;
wire n_102;
wire n_60;
wire n_105;
wire n_195;
wire n_33;
wire n_61;
wire n_75;
wire n_174;
wire n_106;
wire n_79;
wire n_186;
wire n_118;
wire n_194;
wire n_54;
wire n_168;
wire n_77;
wire n_73;
wire n_196;
wire n_125;
wire n_131;
wire n_85;
wire n_208;
wire n_126;
wire n_169;
wire n_120;
wire n_116;
wire n_132;
wire n_70;
wire n_213;
wire n_142;
wire n_129;
wire n_67;
wire n_92;
wire n_81;
wire n_155;
wire n_44;
wire n_74;
wire n_138;
wire n_53;
wire n_64;
wire n_107;
wire n_124;
wire n_200;
wire n_204;
wire n_49;
wire n_40;
wire n_51;
wire n_147;
wire n_163;
wire n_59;
wire n_111;
wire n_166;
wire n_161;
wire n_190;
wire n_117;
wire n_93;
wire n_158;
wire n_84;
wire n_180;
wire n_32;
wire n_48;
wire n_143;
wire n_35;
wire n_136;
wire n_96;
wire n_182;
wire n_104;
wire n_115;
wire n_201;
wire n_41;
wire n_98;
wire n_203;
wire n_183;
wire n_100;
wire n_145;
wire n_76;
wire n_57;
wire n_43;
wire n_137;
wire n_71;
wire n_113;
wire n_80;
wire n_108;
wire n_119;
wire n_160;
wire n_189;
wire n_205;
wire n_87;
wire n_176;
wire n_42;
wire n_167;
wire n_156;
wire n_199;
wire n_34;
wire n_89;
wire n_58;
wire n_86;
wire n_72;
wire n_192;
wire n_114;
wire n_151;
wire n_90;
wire n_197;
wire n_63;
wire n_101;
wire n_127;
wire n_146;
wire n_36;
wire n_66;
wire n_83;
wire n_91;
wire n_95;
wire n_150;
wire n_152;
wire n_206;
wire n_45;
wire n_52;
wire n_187;
wire n_133;
wire n_78;
wire n_153;
wire n_46;
wire n_122;
wire n_88;
wire n_134;
wire n_191;
wire n_99;
wire n_157;
wire n_47;
wire n_214;
wire n_50;
wire n_38;
wire n_109;
wire n_178;
wire n_170;
wire n_211;
wire n_175;
wire n_103;
wire n_177;
wire n_149;

BUFx3_ASAP7_75t_L g31 ( 
.A(n_16),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_13),
.Y(n_32)
);

INVxp33_ASAP7_75t_L g33 ( 
.A(n_2),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_15),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_5),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_21),
.Y(n_36)
);

INVxp67_ASAP7_75t_SL g37 ( 
.A(n_1),
.Y(n_37)
);

CKINVDCx5p33_ASAP7_75t_R g38 ( 
.A(n_4),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_18),
.Y(n_39)
);

CKINVDCx20_ASAP7_75t_R g40 ( 
.A(n_26),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_12),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_4),
.Y(n_42)
);

INVx2_ASAP7_75t_L g43 ( 
.A(n_32),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_32),
.Y(n_44)
);

CKINVDCx5p33_ASAP7_75t_R g45 ( 
.A(n_38),
.Y(n_45)
);

NOR2xp33_ASAP7_75t_L g46 ( 
.A(n_33),
.B(n_0),
.Y(n_46)
);

CKINVDCx5p33_ASAP7_75t_R g47 ( 
.A(n_42),
.Y(n_47)
);

CKINVDCx5p33_ASAP7_75t_R g48 ( 
.A(n_31),
.Y(n_48)
);

INVx2_ASAP7_75t_L g49 ( 
.A(n_43),
.Y(n_49)
);

BUFx8_ASAP7_75t_L g50 ( 
.A(n_43),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_43),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_46),
.A2(n_37),
.B1(n_40),
.B2(n_33),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_44),
.Y(n_53)
);

INVx1_ASAP7_75t_L g54 ( 
.A(n_44),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_44),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_48),
.Y(n_56)
);

INVx1_ASAP7_75t_L g57 ( 
.A(n_45),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_47),
.B(n_32),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_51),
.Y(n_59)
);

INVxp67_ASAP7_75t_L g60 ( 
.A(n_56),
.Y(n_60)
);

AOI22xp33_ASAP7_75t_L g61 ( 
.A1(n_52),
.A2(n_31),
.B1(n_35),
.B2(n_34),
.Y(n_61)
);

NOR2xp33_ASAP7_75t_L g62 ( 
.A(n_56),
.B(n_37),
.Y(n_62)
);

AND2x2_ASAP7_75t_L g63 ( 
.A(n_58),
.B(n_49),
.Y(n_63)
);

AOI22xp33_ASAP7_75t_L g64 ( 
.A1(n_50),
.A2(n_31),
.B1(n_35),
.B2(n_34),
.Y(n_64)
);

A2O1A1Ixp33_ASAP7_75t_L g65 ( 
.A1(n_51),
.A2(n_31),
.B(n_35),
.C(n_34),
.Y(n_65)
);

O2A1O1Ixp33_ASAP7_75t_L g66 ( 
.A1(n_53),
.A2(n_39),
.B(n_36),
.C(n_41),
.Y(n_66)
);

INVx4_ASAP7_75t_L g67 ( 
.A(n_49),
.Y(n_67)
);

OR2x2_ASAP7_75t_SL g68 ( 
.A(n_57),
.B(n_39),
.Y(n_68)
);

AOI21xp5_ASAP7_75t_L g69 ( 
.A1(n_55),
.A2(n_41),
.B(n_39),
.Y(n_69)
);

NOR2xp33_ASAP7_75t_L g70 ( 
.A(n_50),
.B(n_53),
.Y(n_70)
);

A2O1A1Ixp33_ASAP7_75t_L g71 ( 
.A1(n_54),
.A2(n_36),
.B(n_41),
.C(n_40),
.Y(n_71)
);

CKINVDCx11_ASAP7_75t_R g72 ( 
.A(n_68),
.Y(n_72)
);

OAI21x1_ASAP7_75t_SL g73 ( 
.A1(n_66),
.A2(n_55),
.B(n_54),
.Y(n_73)
);

NOR2xp33_ASAP7_75t_R g74 ( 
.A(n_62),
.B(n_50),
.Y(n_74)
);

AND2x4_ASAP7_75t_L g75 ( 
.A(n_63),
.B(n_0),
.Y(n_75)
);

OAI221xp5_ASAP7_75t_L g76 ( 
.A1(n_61),
.A2(n_5),
.B1(n_1),
.B2(n_6),
.C(n_7),
.Y(n_76)
);

OAI21x1_ASAP7_75t_L g77 ( 
.A1(n_69),
.A2(n_7),
.B(n_6),
.Y(n_77)
);

AOI21xp5_ASAP7_75t_L g78 ( 
.A1(n_63),
.A2(n_16),
.B(n_15),
.Y(n_78)
);

NAND2xp5_ASAP7_75t_L g79 ( 
.A(n_60),
.B(n_17),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_59),
.Y(n_80)
);

OAI21x1_ASAP7_75t_L g81 ( 
.A1(n_69),
.A2(n_66),
.B(n_59),
.Y(n_81)
);

INVx2_ASAP7_75t_SL g82 ( 
.A(n_67),
.Y(n_82)
);

NOR2xp33_ASAP7_75t_L g83 ( 
.A(n_79),
.B(n_68),
.Y(n_83)
);

NOR3xp33_ASAP7_75t_SL g84 ( 
.A(n_76),
.B(n_71),
.C(n_65),
.Y(n_84)
);

AOI22xp33_ASAP7_75t_SL g85 ( 
.A1(n_76),
.A2(n_64),
.B1(n_70),
.B2(n_17),
.Y(n_85)
);

BUFx3_ASAP7_75t_L g86 ( 
.A(n_75),
.Y(n_86)
);

CKINVDCx5p33_ASAP7_75t_R g87 ( 
.A(n_72),
.Y(n_87)
);

NAND2xp33_ASAP7_75t_R g88 ( 
.A(n_74),
.B(n_18),
.Y(n_88)
);

AND2x2_ASAP7_75t_L g89 ( 
.A(n_75),
.B(n_67),
.Y(n_89)
);

OAI22xp33_ASAP7_75t_L g90 ( 
.A1(n_86),
.A2(n_79),
.B1(n_78),
.B2(n_80),
.Y(n_90)
);

OAI22xp33_ASAP7_75t_L g91 ( 
.A1(n_86),
.A2(n_78),
.B1(n_80),
.B2(n_75),
.Y(n_91)
);

NOR2xp33_ASAP7_75t_L g92 ( 
.A(n_83),
.B(n_72),
.Y(n_92)
);

AOI21xp5_ASAP7_75t_L g93 ( 
.A1(n_89),
.A2(n_82),
.B(n_75),
.Y(n_93)
);

OR2x2_ASAP7_75t_L g94 ( 
.A(n_83),
.B(n_75),
.Y(n_94)
);

AOI21xp5_ASAP7_75t_L g95 ( 
.A1(n_89),
.A2(n_82),
.B(n_75),
.Y(n_95)
);

AND2x2_ASAP7_75t_L g96 ( 
.A(n_86),
.B(n_74),
.Y(n_96)
);

AND2x2_ASAP7_75t_L g97 ( 
.A(n_94),
.B(n_86),
.Y(n_97)
);

OR2x2_ASAP7_75t_L g98 ( 
.A(n_92),
.B(n_86),
.Y(n_98)
);

INVx1_ASAP7_75t_L g99 ( 
.A(n_91),
.Y(n_99)
);

INVx1_ASAP7_75t_L g100 ( 
.A(n_91),
.Y(n_100)
);

AND2x2_ASAP7_75t_L g101 ( 
.A(n_93),
.B(n_89),
.Y(n_101)
);

AND2x2_ASAP7_75t_L g102 ( 
.A(n_95),
.B(n_89),
.Y(n_102)
);

INVx2_ASAP7_75t_L g103 ( 
.A(n_96),
.Y(n_103)
);

AND2x2_ASAP7_75t_L g104 ( 
.A(n_90),
.B(n_84),
.Y(n_104)
);

NOR2x1p5_ASAP7_75t_L g105 ( 
.A(n_94),
.B(n_87),
.Y(n_105)
);

INVx1_ASAP7_75t_SL g106 ( 
.A(n_94),
.Y(n_106)
);

INVx2_ASAP7_75t_L g107 ( 
.A(n_94),
.Y(n_107)
);

INVx1_ASAP7_75t_L g108 ( 
.A(n_99),
.Y(n_108)
);

INVxp67_ASAP7_75t_L g109 ( 
.A(n_103),
.Y(n_109)
);

OAI211xp5_ASAP7_75t_L g110 ( 
.A1(n_104),
.A2(n_85),
.B(n_84),
.C(n_77),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_99),
.Y(n_111)
);

INVx3_ASAP7_75t_L g112 ( 
.A(n_101),
.Y(n_112)
);

HB1xp67_ASAP7_75t_L g113 ( 
.A(n_100),
.Y(n_113)
);

INVx1_ASAP7_75t_L g114 ( 
.A(n_100),
.Y(n_114)
);

AND2x2_ASAP7_75t_L g115 ( 
.A(n_104),
.B(n_101),
.Y(n_115)
);

INVx1_ASAP7_75t_L g116 ( 
.A(n_104),
.Y(n_116)
);

OR2x2_ASAP7_75t_L g117 ( 
.A(n_103),
.B(n_81),
.Y(n_117)
);

INVx1_ASAP7_75t_L g118 ( 
.A(n_101),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_102),
.Y(n_119)
);

HB1xp67_ASAP7_75t_L g120 ( 
.A(n_103),
.Y(n_120)
);

NAND2xp5_ASAP7_75t_L g121 ( 
.A(n_107),
.B(n_85),
.Y(n_121)
);

AND2x2_ASAP7_75t_L g122 ( 
.A(n_102),
.B(n_77),
.Y(n_122)
);

AOI22xp33_ASAP7_75t_L g123 ( 
.A1(n_107),
.A2(n_77),
.B1(n_73),
.B2(n_81),
.Y(n_123)
);

BUFx3_ASAP7_75t_L g124 ( 
.A(n_102),
.Y(n_124)
);

INVx2_ASAP7_75t_L g125 ( 
.A(n_107),
.Y(n_125)
);

INVx1_ASAP7_75t_L g126 ( 
.A(n_111),
.Y(n_126)
);

NAND2xp33_ASAP7_75t_SL g127 ( 
.A(n_116),
.B(n_88),
.Y(n_127)
);

INVx1_ASAP7_75t_L g128 ( 
.A(n_111),
.Y(n_128)
);

AND2x2_ASAP7_75t_L g129 ( 
.A(n_115),
.B(n_97),
.Y(n_129)
);

AND2x2_ASAP7_75t_L g130 ( 
.A(n_115),
.B(n_116),
.Y(n_130)
);

NAND2xp33_ASAP7_75t_SL g131 ( 
.A(n_115),
.B(n_88),
.Y(n_131)
);

OAI22xp5_ASAP7_75t_L g132 ( 
.A1(n_110),
.A2(n_98),
.B1(n_105),
.B2(n_106),
.Y(n_132)
);

OAI22xp5_ASAP7_75t_L g133 ( 
.A1(n_110),
.A2(n_105),
.B1(n_97),
.B2(n_87),
.Y(n_133)
);

INVx1_ASAP7_75t_L g134 ( 
.A(n_111),
.Y(n_134)
);

OAI221xp5_ASAP7_75t_L g135 ( 
.A1(n_121),
.A2(n_97),
.B1(n_67),
.B2(n_82),
.C(n_73),
.Y(n_135)
);

NOR2x1_ASAP7_75t_L g136 ( 
.A(n_108),
.B(n_67),
.Y(n_136)
);

AND2x2_ASAP7_75t_L g137 ( 
.A(n_119),
.B(n_81),
.Y(n_137)
);

INVx1_ASAP7_75t_L g138 ( 
.A(n_108),
.Y(n_138)
);

AND2x2_ASAP7_75t_L g139 ( 
.A(n_119),
.B(n_19),
.Y(n_139)
);

INVx1_ASAP7_75t_L g140 ( 
.A(n_114),
.Y(n_140)
);

OAI21xp33_ASAP7_75t_L g141 ( 
.A1(n_113),
.A2(n_20),
.B(n_19),
.Y(n_141)
);

INVx1_ASAP7_75t_L g142 ( 
.A(n_114),
.Y(n_142)
);

AOI21xp5_ASAP7_75t_L g143 ( 
.A1(n_123),
.A2(n_73),
.B(n_20),
.Y(n_143)
);

INVxp67_ASAP7_75t_SL g144 ( 
.A(n_117),
.Y(n_144)
);

HB1xp67_ASAP7_75t_L g145 ( 
.A(n_120),
.Y(n_145)
);

INVx1_ASAP7_75t_L g146 ( 
.A(n_113),
.Y(n_146)
);

OAI21xp5_ASAP7_75t_L g147 ( 
.A1(n_123),
.A2(n_22),
.B(n_21),
.Y(n_147)
);

INVx1_ASAP7_75t_L g148 ( 
.A(n_120),
.Y(n_148)
);

AOI22xp5_ASAP7_75t_L g149 ( 
.A1(n_109),
.A2(n_24),
.B1(n_23),
.B2(n_22),
.Y(n_149)
);

INVx1_ASAP7_75t_L g150 ( 
.A(n_126),
.Y(n_150)
);

OR2x2_ASAP7_75t_L g151 ( 
.A(n_146),
.B(n_112),
.Y(n_151)
);

INVx1_ASAP7_75t_L g152 ( 
.A(n_126),
.Y(n_152)
);

NAND2xp5_ASAP7_75t_L g153 ( 
.A(n_129),
.B(n_125),
.Y(n_153)
);

INVx2_ASAP7_75t_L g154 ( 
.A(n_128),
.Y(n_154)
);

INVx3_ASAP7_75t_L g155 ( 
.A(n_128),
.Y(n_155)
);

NOR2xp33_ASAP7_75t_L g156 ( 
.A(n_133),
.B(n_23),
.Y(n_156)
);

INVx1_ASAP7_75t_L g157 ( 
.A(n_134),
.Y(n_157)
);

AND2x2_ASAP7_75t_L g158 ( 
.A(n_130),
.B(n_137),
.Y(n_158)
);

NAND2xp5_ASAP7_75t_L g159 ( 
.A(n_130),
.B(n_125),
.Y(n_159)
);

OR2x2_ASAP7_75t_L g160 ( 
.A(n_146),
.B(n_112),
.Y(n_160)
);

AND2x2_ASAP7_75t_L g161 ( 
.A(n_137),
.B(n_112),
.Y(n_161)
);

INVx1_ASAP7_75t_L g162 ( 
.A(n_134),
.Y(n_162)
);

AND2x2_ASAP7_75t_L g163 ( 
.A(n_138),
.B(n_112),
.Y(n_163)
);

INVx1_ASAP7_75t_L g164 ( 
.A(n_138),
.Y(n_164)
);

AND2x2_ASAP7_75t_L g165 ( 
.A(n_140),
.B(n_112),
.Y(n_165)
);

NAND2xp5_ASAP7_75t_L g166 ( 
.A(n_139),
.B(n_109),
.Y(n_166)
);

NOR2xp33_ASAP7_75t_L g167 ( 
.A(n_139),
.B(n_24),
.Y(n_167)
);

INVx1_ASAP7_75t_L g168 ( 
.A(n_140),
.Y(n_168)
);

AND2x2_ASAP7_75t_L g169 ( 
.A(n_142),
.B(n_124),
.Y(n_169)
);

INVx1_ASAP7_75t_L g170 ( 
.A(n_142),
.Y(n_170)
);

NOR3xp33_ASAP7_75t_L g171 ( 
.A(n_141),
.B(n_117),
.C(n_122),
.Y(n_171)
);

INVx1_ASAP7_75t_L g172 ( 
.A(n_148),
.Y(n_172)
);

NAND2xp5_ASAP7_75t_L g173 ( 
.A(n_145),
.B(n_118),
.Y(n_173)
);

INVx1_ASAP7_75t_L g174 ( 
.A(n_144),
.Y(n_174)
);

O2A1O1Ixp33_ASAP7_75t_L g175 ( 
.A1(n_156),
.A2(n_147),
.B(n_143),
.C(n_132),
.Y(n_175)
);

NOR2xp33_ASAP7_75t_R g176 ( 
.A(n_167),
.B(n_131),
.Y(n_176)
);

AOI21x1_ASAP7_75t_L g177 ( 
.A1(n_150),
.A2(n_157),
.B(n_152),
.Y(n_177)
);

INVx2_ASAP7_75t_L g178 ( 
.A(n_155),
.Y(n_178)
);

AOI22x1_ASAP7_75t_L g179 ( 
.A1(n_155),
.A2(n_122),
.B1(n_117),
.B2(n_127),
.Y(n_179)
);

AOI221xp5_ASAP7_75t_L g180 ( 
.A1(n_171),
.A2(n_149),
.B1(n_135),
.B2(n_122),
.C(n_119),
.Y(n_180)
);

AOI32xp33_ASAP7_75t_L g181 ( 
.A1(n_169),
.A2(n_136),
.A3(n_124),
.B1(n_25),
.B2(n_26),
.Y(n_181)
);

AOI22xp33_ASAP7_75t_L g182 ( 
.A1(n_172),
.A2(n_124),
.B1(n_136),
.B2(n_25),
.Y(n_182)
);

OAI211xp5_ASAP7_75t_L g183 ( 
.A1(n_164),
.A2(n_124),
.B(n_28),
.C(n_27),
.Y(n_183)
);

OAI221xp5_ASAP7_75t_SL g184 ( 
.A1(n_166),
.A2(n_160),
.B1(n_151),
.B2(n_173),
.C(n_169),
.Y(n_184)
);

AOI221xp5_ASAP7_75t_L g185 ( 
.A1(n_164),
.A2(n_170),
.B1(n_168),
.B2(n_174),
.C(n_150),
.Y(n_185)
);

INVxp67_ASAP7_75t_SL g186 ( 
.A(n_155),
.Y(n_186)
);

O2A1O1Ixp33_ASAP7_75t_L g187 ( 
.A1(n_152),
.A2(n_29),
.B(n_28),
.C(n_27),
.Y(n_187)
);

OAI211xp5_ASAP7_75t_L g188 ( 
.A1(n_168),
.A2(n_30),
.B(n_29),
.C(n_3),
.Y(n_188)
);

AOI22xp5_ASAP7_75t_L g189 ( 
.A1(n_163),
.A2(n_30),
.B1(n_9),
.B2(n_8),
.Y(n_189)
);

AOI322xp5_ASAP7_75t_L g190 ( 
.A1(n_158),
.A2(n_10),
.A3(n_11),
.B1(n_14),
.B2(n_161),
.C1(n_165),
.C2(n_163),
.Y(n_190)
);

NAND2xp33_ASAP7_75t_R g191 ( 
.A(n_174),
.B(n_155),
.Y(n_191)
);

AOI211x1_ASAP7_75t_SL g192 ( 
.A1(n_154),
.A2(n_159),
.B(n_153),
.C(n_157),
.Y(n_192)
);

AOI211xp5_ASAP7_75t_L g193 ( 
.A1(n_160),
.A2(n_151),
.B(n_165),
.C(n_162),
.Y(n_193)
);

OAI221xp5_ASAP7_75t_L g194 ( 
.A1(n_181),
.A2(n_154),
.B1(n_161),
.B2(n_162),
.C(n_175),
.Y(n_194)
);

NAND2xp5_ASAP7_75t_L g195 ( 
.A(n_192),
.B(n_154),
.Y(n_195)
);

AND4x1_ASAP7_75t_L g196 ( 
.A(n_193),
.B(n_187),
.C(n_182),
.D(n_180),
.Y(n_196)
);

INVx1_ASAP7_75t_L g197 ( 
.A(n_177),
.Y(n_197)
);

NOR2x1_ASAP7_75t_L g198 ( 
.A(n_178),
.B(n_183),
.Y(n_198)
);

NOR2x1_ASAP7_75t_L g199 ( 
.A(n_178),
.B(n_188),
.Y(n_199)
);

NAND2xp5_ASAP7_75t_L g200 ( 
.A(n_185),
.B(n_186),
.Y(n_200)
);

AOI221xp5_ASAP7_75t_L g201 ( 
.A1(n_184),
.A2(n_176),
.B1(n_182),
.B2(n_189),
.C(n_191),
.Y(n_201)
);

AOI221xp5_ASAP7_75t_L g202 ( 
.A1(n_191),
.A2(n_175),
.B1(n_187),
.B2(n_156),
.C(n_181),
.Y(n_202)
);

INVx1_ASAP7_75t_L g203 ( 
.A(n_179),
.Y(n_203)
);

NOR2xp67_ASAP7_75t_L g204 ( 
.A(n_197),
.B(n_190),
.Y(n_204)
);

BUFx6f_ASAP7_75t_L g205 ( 
.A(n_203),
.Y(n_205)
);

BUFx2_ASAP7_75t_L g206 ( 
.A(n_195),
.Y(n_206)
);

INVx1_ASAP7_75t_L g207 ( 
.A(n_195),
.Y(n_207)
);

HB1xp67_ASAP7_75t_L g208 ( 
.A(n_200),
.Y(n_208)
);

INVx2_ASAP7_75t_L g209 ( 
.A(n_205),
.Y(n_209)
);

OAI22xp5_ASAP7_75t_SL g210 ( 
.A1(n_208),
.A2(n_194),
.B1(n_198),
.B2(n_199),
.Y(n_210)
);

INVx2_ASAP7_75t_L g211 ( 
.A(n_205),
.Y(n_211)
);

OAI22xp5_ASAP7_75t_L g212 ( 
.A1(n_210),
.A2(n_204),
.B1(n_202),
.B2(n_201),
.Y(n_212)
);

OAI221xp5_ASAP7_75t_L g213 ( 
.A1(n_212),
.A2(n_204),
.B1(n_206),
.B2(n_207),
.C(n_196),
.Y(n_213)
);

AOI22xp5_ASAP7_75t_L g214 ( 
.A1(n_213),
.A2(n_207),
.B1(n_206),
.B2(n_205),
.Y(n_214)
);

AOI21xp5_ASAP7_75t_L g215 ( 
.A1(n_214),
.A2(n_211),
.B(n_209),
.Y(n_215)
);


endmodule