module fake_netlist_719_20_n_43 (n_12, n_8, n_1, n_2, n_11, n_13, n_7, n_10, n_9, n_6, n_0, n_3, n_4, n_5, n_43);

input n_12;
input n_8;
input n_1;
input n_2;
input n_11;
input n_13;
input n_7;
input n_10;
input n_9;
input n_6;
input n_0;
input n_3;
input n_4;
input n_5;

output n_43;

wire n_32;
wire n_33;
wire n_30;
wire n_35;
wire n_14;
wire n_20;
wire n_27;
wire n_17;
wire n_36;
wire n_24;
wire n_29;
wire n_37;
wire n_41;
wire n_18;
wire n_31;
wire n_28;
wire n_39;
wire n_25;
wire n_22;
wire n_23;
wire n_15;
wire n_21;
wire n_42;
wire n_38;
wire n_34;
wire n_40;
wire n_16;
wire n_26;
wire n_19;

INVxp67_ASAP7_75t_SL g14 ( 
.A(n_10),
.Y(n_14)
);

INVx3_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_SL g16 ( 
.A(n_12),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_7),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_0),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_11),
.Y(n_20)
);

INVx4_ASAP7_75t_SL g21 ( 
.A(n_0),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_L g22 ( 
.A(n_4),
.B(n_3),
.C(n_8),
.Y(n_22)
);

INVx5_ASAP7_75t_L g23 ( 
.A(n_7),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_6),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_17),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_15),
.B(n_1),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_15),
.Y(n_27)
);

AO31x2_ASAP7_75t_L g28 ( 
.A1(n_18),
.A2(n_6),
.A3(n_5),
.B(n_1),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_19),
.Y(n_29)
);

A2O1A1Ixp33_ASAP7_75t_L g30 ( 
.A1(n_15),
.A2(n_13),
.B(n_9),
.C(n_2),
.Y(n_30)
);

AOI21xp5_ASAP7_75t_L g31 ( 
.A1(n_18),
.A2(n_23),
.B(n_14),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_29),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_27),
.Y(n_33)
);

INVx2_ASAP7_75t_SL g34 ( 
.A(n_26),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_28),
.Y(n_35)
);

NAND4xp25_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_25),
.C(n_26),
.D(n_22),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_33),
.Y(n_37)
);

AOI321xp33_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_20),
.A3(n_24),
.B1(n_34),
.B2(n_35),
.C(n_30),
.Y(n_38)
);

O2A1O1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_37),
.A2(n_35),
.B(n_31),
.C(n_16),
.Y(n_39)
);

AOI211xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_24),
.B(n_31),
.C(n_21),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_SL g41 ( 
.A(n_38),
.B(n_23),
.Y(n_41)
);

NAND2xp5_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_28),
.Y(n_42)
);

OAI22xp5_ASAP7_75t_L g43 ( 
.A1(n_42),
.A2(n_40),
.B1(n_23),
.B2(n_28),
.Y(n_43)
);


endmodule