module fake_netlist_806_2045_n_67 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_17, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_67);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_17;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_67;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_60;
wire n_36;
wire n_47;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_62;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_63;
wire n_30;
wire n_18;
wire n_64;
wire n_66;
wire n_55;
wire n_65;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_9),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_8),
.B(n_3),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_10),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_4),
.B(n_15),
.Y(n_22)
);

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_5),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_12),
.B(n_17),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_2),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_6),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_17),
.Y(n_28)
);

CKINVDCx16_ASAP7_75t_R g29 ( 
.A(n_16),
.Y(n_29)
);

INVx3_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_29),
.B(n_16),
.Y(n_31)
);

AND3x2_ASAP7_75t_SL g32 ( 
.A(n_23),
.B(n_1),
.C(n_0),
.Y(n_32)
);

INVx4_ASAP7_75t_L g33 ( 
.A(n_21),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_19),
.B(n_7),
.Y(n_34)
);

BUFx6f_ASAP7_75t_L g35 ( 
.A(n_18),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

INVx4_ASAP7_75t_L g37 ( 
.A(n_18),
.Y(n_37)
);

OAI21xp5_ASAP7_75t_SL g38 ( 
.A1(n_31),
.A2(n_25),
.B(n_22),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_34),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_33),
.B(n_36),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_33),
.Y(n_41)
);

CKINVDCx11_ASAP7_75t_R g42 ( 
.A(n_32),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_36),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_43),
.B(n_30),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_39),
.A2(n_34),
.B1(n_37),
.B2(n_26),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_38),
.B(n_40),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_47),
.Y(n_48)
);

OAI31xp33_ASAP7_75t_L g49 ( 
.A1(n_45),
.A2(n_42),
.A3(n_30),
.B(n_32),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_46),
.B(n_42),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_44),
.Y(n_51)
);

INVx3_ASAP7_75t_L g52 ( 
.A(n_51),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_37),
.Y(n_53)
);

AOI221xp5_ASAP7_75t_L g54 ( 
.A1(n_48),
.A2(n_27),
.B1(n_20),
.B2(n_18),
.C(n_35),
.Y(n_54)
);

NOR3xp33_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_14),
.C(n_11),
.Y(n_55)
);

OAI21xp33_ASAP7_75t_SL g56 ( 
.A1(n_54),
.A2(n_49),
.B(n_35),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_52),
.Y(n_57)
);

INVx1_ASAP7_75t_L g58 ( 
.A(n_53),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

CKINVDCx5p33_ASAP7_75t_R g60 ( 
.A(n_57),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_58),
.Y(n_61)
);

INVx3_ASAP7_75t_SL g62 ( 
.A(n_57),
.Y(n_62)
);

AND2x4_ASAP7_75t_L g63 ( 
.A(n_59),
.B(n_35),
.Y(n_63)
);

INVx1_ASAP7_75t_L g64 ( 
.A(n_61),
.Y(n_64)
);

AND2x4_ASAP7_75t_L g65 ( 
.A(n_60),
.B(n_35),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_63),
.Y(n_66)
);

AOI222xp33_ASAP7_75t_L g67 ( 
.A1(n_64),
.A2(n_56),
.B1(n_66),
.B2(n_62),
.C1(n_63),
.C2(n_65),
.Y(n_67)
);


endmodule