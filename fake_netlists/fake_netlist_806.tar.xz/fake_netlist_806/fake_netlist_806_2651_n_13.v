module fake_netlist_806_2651_n_13 (n_2, n_0, n_1, n_13);

input n_2;
input n_0;
input n_1;

output n_13;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_3;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

BUFx6f_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

AND2x6_ASAP7_75t_L g4 ( 
.A(n_2),
.B(n_0),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B(n_1),
.Y(n_6)
);

NAND4xp25_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_2),
.C(n_1),
.D(n_3),
.Y(n_7)
);

OAI211xp5_ASAP7_75t_SL g8 ( 
.A1(n_5),
.A2(n_0),
.B(n_4),
.C(n_6),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_7),
.B(n_4),
.Y(n_9)
);

OAI211xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.B(n_6),
.C(n_5),
.Y(n_10)
);

OAI21xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_6),
.B(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_4),
.Y(n_13)
);


endmodule