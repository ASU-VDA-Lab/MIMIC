module fake_netlist_806_4411_n_46 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_46);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_46;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_32;
wire n_31;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_33;
wire n_12;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;
wire n_45;

NOR2xp33_ASAP7_75t_R g12 ( 
.A(n_11),
.B(n_7),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_R g13 ( 
.A(n_1),
.B(n_8),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_2),
.Y(n_14)
);

INVx2_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_5),
.B(n_10),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_0),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_18),
.Y(n_21)
);

NAND2xp33_ASAP7_75t_R g22 ( 
.A(n_12),
.B(n_3),
.Y(n_22)
);

INVx3_ASAP7_75t_L g23 ( 
.A(n_16),
.Y(n_23)
);

INVx3_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_SL g25 ( 
.A(n_18),
.B(n_19),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_12),
.Y(n_26)
);

BUFx3_ASAP7_75t_L g27 ( 
.A(n_20),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_24),
.Y(n_28)
);

CKINVDCx5p33_ASAP7_75t_R g29 ( 
.A(n_22),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_21),
.Y(n_31)
);

AND2x2_ASAP7_75t_L g32 ( 
.A(n_26),
.B(n_23),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_28),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_27),
.B(n_14),
.Y(n_34)
);

AOI31xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_29),
.A3(n_17),
.B(n_25),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_27),
.Y(n_36)
);

NOR4xp25_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_33),
.C(n_13),
.D(n_28),
.Y(n_37)
);

AND2x2_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_27),
.Y(n_38)
);

INVxp33_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

XNOR2xp5_ASAP7_75t_L g40 ( 
.A(n_37),
.B(n_30),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_38),
.Y(n_41)
);

BUFx6f_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

OAI22xp5_ASAP7_75t_SL g44 ( 
.A1(n_42),
.A2(n_43),
.B1(n_41),
.B2(n_40),
.Y(n_44)
);

BUFx2_ASAP7_75t_L g45 ( 
.A(n_42),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_L g46 ( 
.A1(n_45),
.A2(n_31),
.B1(n_44),
.B2(n_42),
.Y(n_46)
);


endmodule