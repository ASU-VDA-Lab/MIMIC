module fake_netlist_806_1925_n_17 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_1, n_17);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_17;

wire n_15;
wire n_13;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;
wire n_9;
wire n_8;

BUFx3_ASAP7_75t_L g8 ( 
.A(n_0),
.Y(n_8)
);

OAI21xp33_ASAP7_75t_SL g9 ( 
.A1(n_3),
.A2(n_6),
.B(n_1),
.Y(n_9)
);

INVx4_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_4),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_12),
.B(n_10),
.Y(n_13)
);

AOI221x1_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_9),
.B1(n_8),
.B2(n_6),
.C(n_7),
.Y(n_14)
);

NOR2x1_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_13),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI22xp33_ASAP7_75t_R g17 ( 
.A1(n_16),
.A2(n_7),
.B1(n_5),
.B2(n_2),
.Y(n_17)
);


endmodule