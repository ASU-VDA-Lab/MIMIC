module fake_netlist_806_862_n_26 (n_2, n_0, n_3, n_1, n_26);

input n_2;
input n_0;
input n_3;
input n_1;

output n_26;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_4;
wire n_7;
wire n_23;
wire n_9;
wire n_24;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_5;
wire n_11;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_1),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

OAI21x1_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_7),
.B(n_5),
.Y(n_8)
);

AO31x2_ASAP7_75t_L g9 ( 
.A1(n_6),
.A2(n_2),
.A3(n_1),
.B(n_0),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_4),
.B(n_0),
.Y(n_10)
);

AOI221xp5_ASAP7_75t_L g11 ( 
.A1(n_5),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.C(n_3),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_8),
.B(n_7),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_10),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_9),
.Y(n_15)
);

OR2x2_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_9),
.Y(n_16)
);

AND2x2_ASAP7_75t_L g17 ( 
.A(n_12),
.B(n_9),
.Y(n_17)
);

NAND4xp25_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_11),
.C(n_13),
.D(n_0),
.Y(n_18)
);

OAI22xp5_ASAP7_75t_L g19 ( 
.A1(n_16),
.A2(n_13),
.B1(n_9),
.B2(n_3),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_3),
.B1(n_1),
.B2(n_0),
.Y(n_20)
);

NAND4xp75_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_17),
.C(n_3),
.D(n_0),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_L g22 ( 
.A(n_18),
.B(n_17),
.C(n_3),
.Y(n_22)
);

NOR2x1_ASAP7_75t_L g23 ( 
.A(n_19),
.B(n_1),
.Y(n_23)
);

XNOR2xp5_ASAP7_75t_L g24 ( 
.A(n_21),
.B(n_22),
.Y(n_24)
);

AOI221xp5_ASAP7_75t_L g25 ( 
.A1(n_23),
.A2(n_1),
.B1(n_2),
.B2(n_22),
.C(n_18),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_2),
.C(n_24),
.Y(n_26)
);


endmodule