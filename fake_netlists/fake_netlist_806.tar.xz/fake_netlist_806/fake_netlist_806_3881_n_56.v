module fake_netlist_806_3881_n_56 (n_20, n_15, n_13, n_2, n_17, n_14, n_22, n_4, n_7, n_23, n_9, n_19, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_21, n_5, n_11, n_1, n_8, n_56);

input n_20;
input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_22;
input n_4;
input n_7;
input n_23;
input n_9;
input n_19;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_21;
input n_5;
input n_11;
input n_1;
input n_8;

output n_56;

wire n_48;
wire n_49;
wire n_25;
wire n_36;
wire n_47;
wire n_50;
wire n_41;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_44;
wire n_53;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_42;
wire n_54;
wire n_33;
wire n_29;
wire n_30;
wire n_55;
wire n_35;
wire n_38;
wire n_52;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

INVx3_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_23),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_20),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_21),
.B(n_7),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_15),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_19),
.Y(n_32)
);

INVx2_ASAP7_75t_L g33 ( 
.A(n_17),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_11),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_25),
.B(n_24),
.Y(n_35)
);

INVx3_ASAP7_75t_L g36 ( 
.A(n_24),
.Y(n_36)
);

BUFx6f_ASAP7_75t_L g37 ( 
.A(n_26),
.Y(n_37)
);

NOR2xp33_ASAP7_75t_R g38 ( 
.A(n_28),
.B(n_1),
.Y(n_38)
);

OAI211xp5_ASAP7_75t_L g39 ( 
.A1(n_35),
.A2(n_27),
.B(n_31),
.C(n_30),
.Y(n_39)
);

OAI22xp5_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_34),
.B1(n_32),
.B2(n_33),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_36),
.B(n_26),
.Y(n_41)
);

HB1xp67_ASAP7_75t_L g42 ( 
.A(n_40),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_L g43 ( 
.A(n_39),
.B(n_29),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_42),
.B(n_41),
.Y(n_44)
);

INVx1_ASAP7_75t_SL g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_22),
.Y(n_47)
);

BUFx2_ASAP7_75t_L g48 ( 
.A(n_46),
.Y(n_48)
);

AOI221xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_44),
.B1(n_38),
.B2(n_26),
.C(n_37),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_46),
.A2(n_37),
.B1(n_23),
.B2(n_22),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_48),
.B(n_50),
.Y(n_51)
);

NAND3xp33_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_4),
.C(n_2),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_L g53 ( 
.A(n_48),
.B(n_5),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

O2A1O1Ixp33_ASAP7_75t_SL g55 ( 
.A1(n_53),
.A2(n_9),
.B(n_8),
.C(n_6),
.Y(n_55)
);

AOI322xp5_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_55),
.A3(n_52),
.B1(n_14),
.B2(n_16),
.C1(n_10),
.C2(n_12),
.Y(n_56)
);


endmodule