module fake_netlist_806_2323_n_19 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_19);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_19;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_11;

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_8),
.B(n_5),
.Y(n_10)
);

OAI22xp33_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_2),
.B1(n_4),
.B2(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_3),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_1),
.B(n_7),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_7),
.B(n_6),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

AOI21xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_11),
.B(n_10),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.Y(n_17)
);

BUFx3_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_10),
.B(n_6),
.Y(n_19)
);


endmodule