module fake_netlist_806_1131_n_11 (n_0, n_1, n_11);

input n_0;
input n_1;

output n_11;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_3;
wire n_9;
wire n_8;

BUFx6f_ASAP7_75t_L g2 ( 
.A(n_1),
.Y(n_2)
);

NAND2xp33_ASAP7_75t_L g3 ( 
.A(n_0),
.B(n_1),
.Y(n_3)
);

OAI21xp5_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_5)
);

AND2x2_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_4),
.Y(n_8)
);

AOI211xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_7),
.B(n_2),
.C(n_0),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_9),
.Y(n_10)
);

AOI222xp33_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_1),
.B1(n_4),
.B2(n_0),
.C1(n_3),
.C2(n_9),
.Y(n_11)
);


endmodule