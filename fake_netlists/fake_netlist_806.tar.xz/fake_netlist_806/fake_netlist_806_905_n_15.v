module fake_netlist_806_905_n_15 (n_6, n_4, n_2, n_5, n_3, n_0, n_1, n_15);

input n_6;
input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_15;

wire n_10;
wire n_7;
wire n_13;
wire n_11;
wire n_9;
wire n_14;
wire n_12;
wire n_8;

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_0),
.A2(n_6),
.B1(n_4),
.B2(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_1),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_9),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_10),
.B1(n_8),
.B2(n_1),
.Y(n_12)
);

AOI211x1_ASAP7_75t_SL g13 ( 
.A1(n_12),
.A2(n_8),
.B(n_11),
.C(n_2),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_11),
.C(n_2),
.Y(n_14)
);

OAI221xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_3),
.B1(n_4),
.B2(n_6),
.C(n_12),
.Y(n_15)
);


endmodule