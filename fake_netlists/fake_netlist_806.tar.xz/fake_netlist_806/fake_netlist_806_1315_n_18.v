module fake_netlist_806_1315_n_18 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_18);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_18;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_12;
wire n_10;
wire n_16;
wire n_11;

OAI22xp33_ASAP7_75t_L g10 ( 
.A1(n_1),
.A2(n_5),
.B1(n_7),
.B2(n_2),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_8),
.B(n_3),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_4),
.B(n_9),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_SL g13 ( 
.A1(n_10),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND4xp75_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.C(n_11),
.D(n_6),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_7),
.Y(n_16)
);

NOR2xp67_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);


endmodule