module fake_netlist_806_4064_n_42 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_42);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_42;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_41;
wire n_34;
wire n_23;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_5),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_15),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_13),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_3),
.B(n_1),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_0),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_17),
.B(n_18),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_10),
.Y(n_26)
);

BUFx10_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_2),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_21),
.Y(n_29)
);

NAND3x1_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_22),
.C(n_25),
.Y(n_30)
);

OAI21x1_ASAP7_75t_L g31 ( 
.A1(n_28),
.A2(n_23),
.B(n_19),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_26),
.B(n_30),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_27),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

INVxp33_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

OAI22xp33_ASAP7_75t_SL g36 ( 
.A1(n_34),
.A2(n_32),
.B1(n_6),
.B2(n_4),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_35),
.Y(n_37)
);

INVx3_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

NOR2x1p5_ASAP7_75t_L g39 ( 
.A(n_38),
.B(n_7),
.Y(n_39)
);

OAI211xp5_ASAP7_75t_L g40 ( 
.A1(n_37),
.A2(n_11),
.B(n_9),
.C(n_8),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_SL g42 ( 
.A1(n_41),
.A2(n_40),
.B1(n_14),
.B2(n_12),
.Y(n_42)
);


endmodule