module fake_netlist_806_2943_n_32 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_32);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_32;

wire n_25;
wire n_20;
wire n_17;
wire n_22;
wire n_23;
wire n_28;
wire n_31;
wire n_26;
wire n_24;
wire n_19;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_13),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_12),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

NAND2xp33_ASAP7_75t_R g20 ( 
.A(n_8),
.B(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_15),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_17),
.A2(n_7),
.B1(n_6),
.B2(n_1),
.Y(n_23)
);

OA21x2_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_19),
.B(n_18),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

OAI33xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_21),
.A3(n_17),
.B1(n_20),
.B2(n_7),
.B3(n_3),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_24),
.Y(n_27)
);

AOI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_24),
.B1(n_5),
.B2(n_4),
.Y(n_28)
);

NOR2xp67_ASAP7_75t_L g29 ( 
.A(n_28),
.B(n_9),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_10),
.B1(n_11),
.B2(n_14),
.C1(n_24),
.C2(n_17),
.Y(n_32)
);


endmodule