module fake_netlist_806_1641_n_62 (n_6, n_10, n_15, n_4, n_7, n_2, n_13, n_5, n_16, n_3, n_9, n_11, n_14, n_12, n_0, n_8, n_1, n_62);

input n_6;
input n_10;
input n_15;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_16;
input n_3;
input n_9;
input n_11;
input n_14;
input n_12;
input n_0;
input n_8;
input n_1;

output n_62;

wire n_48;
wire n_49;
wire n_25;
wire n_20;
wire n_60;
wire n_36;
wire n_47;
wire n_17;
wire n_57;
wire n_50;
wire n_22;
wire n_41;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_44;
wire n_39;
wire n_53;
wire n_32;
wire n_31;
wire n_58;
wire n_26;
wire n_24;
wire n_43;
wire n_37;
wire n_19;
wire n_42;
wire n_54;
wire n_33;
wire n_56;
wire n_29;
wire n_59;
wire n_30;
wire n_18;
wire n_55;
wire n_21;
wire n_35;
wire n_38;
wire n_52;
wire n_61;
wire n_27;
wire n_45;
wire n_46;
wire n_51;

BUFx2_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_8),
.B(n_0),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_4),
.B(n_16),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_16),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_3),
.B(n_5),
.Y(n_21)
);

INVx2_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_2),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_12),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_14),
.B(n_7),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_2),
.Y(n_27)
);

INVx3_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

AND2x4_ASAP7_75t_L g29 ( 
.A(n_20),
.B(n_1),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_27),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_22),
.Y(n_31)
);

OR2x6_ASAP7_75t_L g32 ( 
.A(n_17),
.B(n_23),
.Y(n_32)
);

BUFx6f_ASAP7_75t_SL g33 ( 
.A(n_21),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_25),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_1),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_22),
.Y(n_36)
);

OAI222xp33_ASAP7_75t_L g37 ( 
.A1(n_32),
.A2(n_19),
.B1(n_21),
.B2(n_18),
.C1(n_26),
.C2(n_24),
.Y(n_37)
);

NAND2x1p5_ASAP7_75t_L g38 ( 
.A(n_29),
.B(n_24),
.Y(n_38)
);

OAI21x1_ASAP7_75t_L g39 ( 
.A1(n_31),
.A2(n_10),
.B(n_9),
.Y(n_39)
);

OR2x6_ASAP7_75t_L g40 ( 
.A(n_32),
.B(n_15),
.Y(n_40)
);

INVxp67_ASAP7_75t_SL g41 ( 
.A(n_38),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_40),
.B(n_30),
.Y(n_42)
);

NOR2xp33_ASAP7_75t_L g43 ( 
.A(n_37),
.B(n_32),
.Y(n_43)
);

NOR2x1_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_35),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_41),
.Y(n_45)
);

NOR3xp33_ASAP7_75t_L g46 ( 
.A(n_43),
.B(n_34),
.C(n_28),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_42),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_44),
.B(n_38),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_45),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

NAND2xp5_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_48),
.Y(n_51)
);

AND3x2_ASAP7_75t_L g52 ( 
.A(n_50),
.B(n_36),
.C(n_31),
.Y(n_52)
);

NAND2xp5_ASAP7_75t_SL g53 ( 
.A(n_49),
.B(n_36),
.Y(n_53)
);

OR2x2_ASAP7_75t_L g54 ( 
.A(n_49),
.B(n_28),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_51),
.Y(n_55)
);

INVxp67_ASAP7_75t_L g56 ( 
.A(n_55),
.Y(n_56)
);

BUFx6f_ASAP7_75t_L g57 ( 
.A(n_52),
.Y(n_57)
);

NAND2xp5_ASAP7_75t_L g58 ( 
.A(n_54),
.B(n_39),
.Y(n_58)
);

NOR2xp67_ASAP7_75t_L g59 ( 
.A(n_53),
.B(n_33),
.Y(n_59)
);

HB1xp67_ASAP7_75t_L g60 ( 
.A(n_56),
.Y(n_60)
);

NOR3xp33_ASAP7_75t_L g61 ( 
.A(n_59),
.B(n_33),
.C(n_58),
.Y(n_61)
);

AOI22xp33_ASAP7_75t_L g62 ( 
.A1(n_61),
.A2(n_57),
.B1(n_60),
.B2(n_55),
.Y(n_62)
);


endmodule