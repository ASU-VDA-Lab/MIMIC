module fake_netlist_806_235_n_34 (n_4, n_2, n_5, n_3, n_0, n_1, n_34);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_34;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_7;
wire n_23;
wire n_28;
wire n_9;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_12;
wire n_29;
wire n_6;
wire n_30;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;
wire n_27;
wire n_8;

AND2x4_ASAP7_75t_L g6 ( 
.A(n_4),
.B(n_1),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_1),
.B(n_3),
.Y(n_8)
);

BUFx8_ASAP7_75t_SL g9 ( 
.A(n_2),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_4),
.Y(n_10)
);

AOI22xp5_ASAP7_75t_L g11 ( 
.A1(n_6),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_6),
.A2(n_4),
.B1(n_2),
.B2(n_0),
.Y(n_12)
);

AO21x1_ASAP7_75t_L g13 ( 
.A1(n_6),
.A2(n_10),
.B(n_8),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_6),
.B(n_10),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_6),
.Y(n_15)
);

HB1xp67_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_16),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_16),
.B(n_6),
.Y(n_21)
);

NAND2x2_ASAP7_75t_L g22 ( 
.A(n_19),
.B(n_8),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_20),
.A2(n_19),
.B1(n_18),
.B2(n_17),
.Y(n_23)
);

HB1xp67_ASAP7_75t_L g24 ( 
.A(n_21),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_21),
.A2(n_17),
.B(n_18),
.Y(n_25)
);

AOI222xp33_ASAP7_75t_L g26 ( 
.A1(n_22),
.A2(n_7),
.B1(n_17),
.B2(n_9),
.C1(n_11),
.C2(n_0),
.Y(n_26)
);

NOR3xp33_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_9),
.C(n_5),
.Y(n_27)
);

INVx2_ASAP7_75t_SL g28 ( 
.A(n_24),
.Y(n_28)
);

NOR4xp75_ASAP7_75t_L g29 ( 
.A(n_23),
.B(n_17),
.C(n_5),
.D(n_3),
.Y(n_29)
);

NOR2xp67_ASAP7_75t_L g30 ( 
.A(n_25),
.B(n_17),
.Y(n_30)
);

XNOR2xp5_ASAP7_75t_L g31 ( 
.A(n_27),
.B(n_7),
.Y(n_31)
);

OAI21xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_7),
.B(n_28),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_SL g33 ( 
.A1(n_28),
.A2(n_7),
.B1(n_27),
.B2(n_19),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_31),
.A2(n_29),
.B1(n_32),
.B2(n_33),
.Y(n_34)
);


endmodule