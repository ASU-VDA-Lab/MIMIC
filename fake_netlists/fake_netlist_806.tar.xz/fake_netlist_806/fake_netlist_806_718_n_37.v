module fake_netlist_806_718_n_37 (n_15, n_13, n_2, n_17, n_14, n_4, n_7, n_9, n_3, n_12, n_0, n_6, n_18, n_10, n_16, n_5, n_11, n_1, n_8, n_37);

input n_15;
input n_13;
input n_2;
input n_17;
input n_14;
input n_4;
input n_7;
input n_9;
input n_3;
input n_12;
input n_0;
input n_6;
input n_18;
input n_10;
input n_16;
input n_5;
input n_11;
input n_1;
input n_8;

output n_37;

wire n_25;
wire n_20;
wire n_36;
wire n_22;
wire n_34;
wire n_23;
wire n_28;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_21;
wire n_35;
wire n_27;

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_10),
.B(n_8),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_1),
.Y(n_21)
);

OAI21x1_ASAP7_75t_L g22 ( 
.A1(n_17),
.A2(n_2),
.B(n_6),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_13),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_16),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_21),
.B(n_18),
.Y(n_26)
);

INVxp67_ASAP7_75t_SL g27 ( 
.A(n_21),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_25),
.B1(n_19),
.B2(n_23),
.Y(n_28)
);

OR2x2_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_18),
.Y(n_29)
);

NAND3xp33_ASAP7_75t_L g30 ( 
.A(n_28),
.B(n_29),
.C(n_24),
.Y(n_30)
);

BUFx6f_ASAP7_75t_SL g31 ( 
.A(n_30),
.Y(n_31)
);

OAI211xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_22),
.B(n_20),
.C(n_3),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_L g33 ( 
.A(n_32),
.B(n_5),
.C(n_4),
.Y(n_33)
);

CKINVDCx20_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_35),
.Y(n_36)
);

AOI322xp5_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_34),
.A3(n_11),
.B1(n_9),
.B2(n_7),
.C1(n_14),
.C2(n_12),
.Y(n_37)
);


endmodule