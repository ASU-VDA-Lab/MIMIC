module fake_netlist_806_1122_n_20 (n_4, n_2, n_5, n_3, n_0, n_1, n_20);

input n_4;
input n_2;
input n_5;
input n_3;
input n_0;
input n_1;

output n_20;

wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_7;
wire n_9;
wire n_19;
wire n_12;
wire n_6;
wire n_18;
wire n_10;
wire n_16;
wire n_11;
wire n_8;

INVx3_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_1),
.B(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

INVx3_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

O2A1O1Ixp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_10)
);

AND2x4_ASAP7_75t_L g11 ( 
.A(n_6),
.B(n_0),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_SL g12 ( 
.A(n_9),
.B(n_4),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_11),
.B(n_9),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.Y(n_15)
);

NOR2x1_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_12),
.Y(n_16)
);

OAI322xp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_8),
.A3(n_7),
.B1(n_6),
.B2(n_9),
.C1(n_13),
.C2(n_10),
.Y(n_17)
);

NOR4xp75_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_6),
.C(n_5),
.D(n_16),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

OA21x2_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_8),
.B(n_13),
.Y(n_20)
);


endmodule