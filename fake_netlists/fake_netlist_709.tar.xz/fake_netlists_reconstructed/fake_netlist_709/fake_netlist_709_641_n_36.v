module fake_netlist_709_641_n_36 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_36);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_36;

wire n_24;
wire n_21;
wire n_27;
wire n_22;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_18),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_12),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_11),
.Y(n_22)
);

OAI22xp33_ASAP7_75t_SL g23 ( 
.A1(n_10),
.A2(n_7),
.B1(n_1),
.B2(n_9),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_5),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_16),
.Y(n_25)
);

A2O1A1Ixp33_ASAP7_75t_L g26 ( 
.A1(n_19),
.A2(n_24),
.B(n_22),
.C(n_21),
.Y(n_26)
);

NOR2xp33_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_16),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_23),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OAI22xp5_ASAP7_75t_L g30 ( 
.A1(n_26),
.A2(n_20),
.B1(n_17),
.B2(n_0),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_20),
.B1(n_30),
.B2(n_27),
.Y(n_32)
);

AOI311xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_17),
.A3(n_6),
.B(n_3),
.C(n_4),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_33),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

OAI221xp5_ASAP7_75t_R g36 ( 
.A1(n_35),
.A2(n_13),
.B1(n_8),
.B2(n_14),
.C(n_15),
.Y(n_36)
);


endmodule