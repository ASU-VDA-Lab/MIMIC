module fake_netlist_709_159_n_72 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_72);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_72;

wire n_54;
wire n_50;
wire n_24;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_22;
wire n_66;
wire n_47;
wire n_20;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_71;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_70;
wire n_31;
wire n_46;
wire n_41;
wire n_23;
wire n_69;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_68;
wire n_33;
wire n_65;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_19;
wire n_67;
wire n_39;
wire n_55;

AND2x4_ASAP7_75t_L g19 ( 
.A(n_5),
.B(n_10),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_3),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_17),
.Y(n_22)
);

INVx5_ASAP7_75t_L g23 ( 
.A(n_6),
.Y(n_23)
);

AND2x2_ASAP7_75t_SL g24 ( 
.A(n_14),
.B(n_12),
.Y(n_24)
);

CKINVDCx16_ASAP7_75t_R g25 ( 
.A(n_8),
.Y(n_25)
);

BUFx6f_ASAP7_75t_L g26 ( 
.A(n_4),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_9),
.B(n_16),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_1),
.B(n_2),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_18),
.B(n_0),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

HB1xp67_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

O2A1O1Ixp5_ASAP7_75t_L g33 ( 
.A1(n_19),
.A2(n_15),
.B(n_13),
.C(n_7),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_21),
.Y(n_34)
);

INVx1_ASAP7_75t_L g35 ( 
.A(n_19),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_22),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_20),
.B(n_5),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_20),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_32),
.Y(n_39)
);

OA21x2_ASAP7_75t_L g40 ( 
.A1(n_33),
.A2(n_28),
.B(n_27),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_32),
.Y(n_41)
);

AO22x2_ASAP7_75t_L g42 ( 
.A1(n_35),
.A2(n_28),
.B1(n_29),
.B2(n_27),
.Y(n_42)
);

OAI22xp33_ASAP7_75t_L g43 ( 
.A1(n_38),
.A2(n_25),
.B1(n_22),
.B2(n_29),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_31),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_39),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_41),
.Y(n_46)
);

AND2x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_37),
.Y(n_47)
);

BUFx3_ASAP7_75t_L g48 ( 
.A(n_40),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_43),
.B(n_34),
.Y(n_49)
);

AND2x2_ASAP7_75t_L g50 ( 
.A(n_45),
.B(n_42),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_46),
.B(n_42),
.Y(n_51)
);

INVx5_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

INVx1_ASAP7_75t_L g53 ( 
.A(n_47),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_53),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_SL g55 ( 
.A(n_52),
.B(n_49),
.Y(n_55)
);

AO22x1_ASAP7_75t_L g56 ( 
.A1(n_50),
.A2(n_51),
.B1(n_52),
.B2(n_37),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_51),
.A2(n_49),
.B1(n_47),
.B2(n_48),
.Y(n_57)
);

XNOR2x1_ASAP7_75t_L g58 ( 
.A(n_56),
.B(n_16),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_54),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_57),
.Y(n_60)
);

NAND2xp5_ASAP7_75t_L g61 ( 
.A(n_55),
.B(n_52),
.Y(n_61)
);

NAND2xp33_ASAP7_75t_R g62 ( 
.A(n_54),
.B(n_52),
.Y(n_62)
);

NAND2xp5_ASAP7_75t_L g63 ( 
.A(n_59),
.B(n_24),
.Y(n_63)
);

NOR3xp33_ASAP7_75t_SL g64 ( 
.A(n_62),
.B(n_33),
.C(n_23),
.Y(n_64)
);

NAND2xp33_ASAP7_75t_SL g65 ( 
.A(n_58),
.B(n_26),
.Y(n_65)
);

NAND2xp5_ASAP7_75t_SL g66 ( 
.A(n_60),
.B(n_61),
.Y(n_66)
);

OAI21xp5_ASAP7_75t_L g67 ( 
.A1(n_64),
.A2(n_23),
.B(n_36),
.Y(n_67)
);

HB1xp67_ASAP7_75t_L g68 ( 
.A(n_66),
.Y(n_68)
);

NAND2xp5_ASAP7_75t_L g69 ( 
.A(n_63),
.B(n_26),
.Y(n_69)
);

BUFx2_ASAP7_75t_L g70 ( 
.A(n_68),
.Y(n_70)
);

AOI22xp5_ASAP7_75t_L g71 ( 
.A1(n_69),
.A2(n_65),
.B1(n_62),
.B2(n_26),
.Y(n_71)
);

OAI211xp5_ASAP7_75t_L g72 ( 
.A1(n_71),
.A2(n_23),
.B(n_67),
.C(n_70),
.Y(n_72)
);


endmodule