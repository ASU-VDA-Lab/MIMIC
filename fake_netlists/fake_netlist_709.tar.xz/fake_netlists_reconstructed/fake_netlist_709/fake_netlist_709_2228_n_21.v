module fake_netlist_709_2228_n_21 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_21);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_21;

wire n_17;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_L g10 ( 
.A(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_0),
.Y(n_12)
);

AOI22xp5_ASAP7_75t_L g13 ( 
.A1(n_4),
.A2(n_3),
.B1(n_1),
.B2(n_6),
.Y(n_13)
);

OAI21x1_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_8),
.B(n_0),
.Y(n_14)
);

NAND3x1_ASAP7_75t_L g15 ( 
.A(n_13),
.B(n_4),
.C(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_13),
.Y(n_17)
);

AOI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_12),
.B1(n_15),
.B2(n_10),
.C1(n_5),
.C2(n_2),
.Y(n_18)
);

OAI211xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_15),
.B(n_6),
.C(n_5),
.Y(n_19)
);

OAI21x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_7),
.B(n_14),
.Y(n_20)
);

OR2x6_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_7),
.Y(n_21)
);


endmodule