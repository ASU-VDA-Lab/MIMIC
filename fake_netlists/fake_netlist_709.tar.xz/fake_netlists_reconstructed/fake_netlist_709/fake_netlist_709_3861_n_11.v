module fake_netlist_709_3861_n_11 (n_0, n_2, n_1, n_11);

input n_0;
input n_2;
input n_1;

output n_11;

wire n_9;
wire n_4;
wire n_7;
wire n_3;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

INVx2_ASAP7_75t_L g3 ( 
.A(n_0),
.Y(n_3)
);

OR2x2_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_0),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

NOR2xp33_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_1),
.Y(n_8)
);

NOR3xp33_ASAP7_75t_SL g9 ( 
.A(n_8),
.B(n_0),
.C(n_1),
.Y(n_9)
);

NAND4xp75_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_7),
.C(n_6),
.D(n_2),
.Y(n_10)
);

INVx2_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);


endmodule