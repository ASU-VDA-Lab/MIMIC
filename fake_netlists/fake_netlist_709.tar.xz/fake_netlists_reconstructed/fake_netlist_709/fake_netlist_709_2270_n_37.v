module fake_netlist_709_2270_n_37 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_37);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_37;

wire n_24;
wire n_21;
wire n_27;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

CKINVDCx20_ASAP7_75t_R g18 ( 
.A(n_16),
.Y(n_18)
);

BUFx2_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_11),
.B(n_5),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_2),
.Y(n_21)
);

AOI21x1_ASAP7_75t_L g22 ( 
.A1(n_15),
.A2(n_9),
.B(n_0),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_14),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_6),
.Y(n_24)
);

AOI21xp5_ASAP7_75t_L g25 ( 
.A1(n_19),
.A2(n_3),
.B(n_1),
.Y(n_25)
);

INVx6_ASAP7_75t_L g26 ( 
.A(n_20),
.Y(n_26)
);

AOI22xp33_ASAP7_75t_L g27 ( 
.A1(n_20),
.A2(n_17),
.B1(n_16),
.B2(n_4),
.Y(n_27)
);

NOR3xp33_ASAP7_75t_SL g28 ( 
.A(n_25),
.B(n_21),
.C(n_23),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_27),
.B1(n_18),
.B2(n_28),
.Y(n_31)
);

NOR2x1_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_18),
.Y(n_32)
);

INVx1_ASAP7_75t_SL g33 ( 
.A(n_32),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_17),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_24),
.Y(n_35)
);

OAI22x1_ASAP7_75t_SL g36 ( 
.A1(n_34),
.A2(n_22),
.B1(n_8),
.B2(n_7),
.Y(n_36)
);

AOI22xp5_ASAP7_75t_SL g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_12),
.B2(n_10),
.Y(n_37)
);


endmodule