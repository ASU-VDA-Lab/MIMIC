module fake_netlist_709_131_n_42 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_42);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_42;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_31;
wire n_23;
wire n_41;
wire n_29;
wire n_33;
wire n_8;
wire n_36;
wire n_32;
wire n_28;
wire n_11;
wire n_19;
wire n_30;
wire n_25;
wire n_10;
wire n_13;
wire n_39;
wire n_14;
wire n_12;

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_4),
.B(n_6),
.Y(n_8)
);

INVx5_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

OAI22xp5_ASAP7_75t_L g10 ( 
.A1(n_4),
.A2(n_5),
.B1(n_3),
.B2(n_0),
.Y(n_10)
);

NAND2xp33_ASAP7_75t_SL g11 ( 
.A(n_7),
.B(n_6),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_L g12 ( 
.A(n_0),
.B(n_2),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_3),
.B(n_1),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_7),
.B(n_15),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_9),
.B(n_7),
.C(n_12),
.Y(n_18)
);

BUFx2_ASAP7_75t_R g19 ( 
.A(n_8),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_13),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_10),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_17),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_11),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_17),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_21),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_22),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_18),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_24),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_25),
.B(n_21),
.Y(n_31)
);

NOR2xp33_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_23),
.Y(n_32)
);

NOR2xp33_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_25),
.Y(n_33)
);

NOR3xp33_ASAP7_75t_L g34 ( 
.A(n_28),
.B(n_25),
.C(n_18),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_33),
.Y(n_35)
);

NAND2x1p5_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_28),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_29),
.Y(n_37)
);

AOI211xp5_ASAP7_75t_L g38 ( 
.A1(n_33),
.A2(n_26),
.B(n_24),
.C(n_19),
.Y(n_38)
);

O2A1O1Ixp33_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_30),
.B(n_26),
.C(n_16),
.Y(n_39)
);

AND2x4_ASAP7_75t_L g40 ( 
.A(n_35),
.B(n_30),
.Y(n_40)
);

AOI22xp5_ASAP7_75t_L g41 ( 
.A1(n_38),
.A2(n_16),
.B1(n_20),
.B2(n_36),
.Y(n_41)
);

OAI222xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_16),
.B1(n_20),
.B2(n_37),
.C1(n_40),
.C2(n_39),
.Y(n_42)
);


endmodule