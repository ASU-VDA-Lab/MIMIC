module fake_netlist_709_3354_n_24 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_24);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_24;

wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_12;
wire n_11;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

CKINVDCx16_ASAP7_75t_R g11 ( 
.A(n_2),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_0),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

O2A1O1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_5),
.B(n_4),
.C(n_2),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_10),
.B(n_1),
.Y(n_16)
);

NOR2x1_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_16),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_12),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_3),
.Y(n_22)
);

HB1xp67_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_24)
);


endmodule