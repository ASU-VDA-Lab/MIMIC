module fake_netlist_709_1287_n_70 (n_2, n_17, n_6, n_9, n_18, n_15, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_10, n_13, n_14, n_12, n_70);

input n_2;
input n_17;
input n_6;
input n_9;
input n_18;
input n_15;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_10;
input n_13;
input n_14;
input n_12;

output n_70;

wire n_54;
wire n_24;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_22;
wire n_66;
wire n_47;
wire n_20;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_23;
wire n_31;
wire n_41;
wire n_46;
wire n_69;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_68;
wire n_33;
wire n_65;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_19;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_67;
wire n_39;
wire n_55;

NOR2x1_ASAP7_75t_L g19 ( 
.A(n_11),
.B(n_4),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_9),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_0),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_5),
.B(n_17),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_9),
.Y(n_23)
);

NAND2x1_ASAP7_75t_L g24 ( 
.A(n_15),
.B(n_2),
.Y(n_24)
);

BUFx6f_ASAP7_75t_L g25 ( 
.A(n_3),
.Y(n_25)
);

AND2x4_ASAP7_75t_L g26 ( 
.A(n_10),
.B(n_5),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_10),
.Y(n_27)
);

BUFx6f_ASAP7_75t_L g28 ( 
.A(n_13),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_6),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_7),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_20),
.B(n_0),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_20),
.B(n_1),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_21),
.B(n_1),
.Y(n_33)
);

A2O1A1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_20),
.A2(n_8),
.B(n_3),
.C(n_2),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_20),
.B(n_8),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_20),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_23),
.A2(n_26),
.B1(n_21),
.B2(n_25),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_26),
.B(n_11),
.Y(n_38)
);

AO21x2_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_22),
.B(n_26),
.Y(n_39)
);

AOI21xp5_ASAP7_75t_SL g40 ( 
.A1(n_32),
.A2(n_26),
.B(n_22),
.Y(n_40)
);

INVx2_ASAP7_75t_SL g41 ( 
.A(n_32),
.Y(n_41)
);

NOR2x1_ASAP7_75t_L g42 ( 
.A(n_31),
.B(n_26),
.Y(n_42)
);

AOI22xp33_ASAP7_75t_SL g43 ( 
.A1(n_33),
.A2(n_29),
.B1(n_27),
.B2(n_23),
.Y(n_43)
);

AOI21xp5_ASAP7_75t_L g44 ( 
.A1(n_37),
.A2(n_24),
.B(n_30),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_40),
.B(n_32),
.Y(n_45)
);

OAI21x1_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_35),
.B(n_36),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_41),
.Y(n_47)
);

AND2x2_ASAP7_75t_L g48 ( 
.A(n_40),
.B(n_32),
.Y(n_48)
);

AOI21xp5_ASAP7_75t_L g49 ( 
.A1(n_47),
.A2(n_41),
.B(n_42),
.Y(n_49)
);

OAI321xp33_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_34),
.A3(n_33),
.B1(n_28),
.B2(n_25),
.C(n_23),
.Y(n_50)
);

AOI211xp5_ASAP7_75t_L g51 ( 
.A1(n_45),
.A2(n_44),
.B(n_43),
.C(n_36),
.Y(n_51)
);

INVx3_ASAP7_75t_L g52 ( 
.A(n_47),
.Y(n_52)
);

AOI22xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_48),
.B1(n_29),
.B2(n_39),
.Y(n_53)
);

AOI322xp5_ASAP7_75t_L g54 ( 
.A1(n_50),
.A2(n_24),
.A3(n_19),
.B1(n_48),
.B2(n_28),
.C1(n_25),
.C2(n_12),
.Y(n_54)
);

INVx1_ASAP7_75t_SL g55 ( 
.A(n_52),
.Y(n_55)
);

AOI21xp5_ASAP7_75t_L g56 ( 
.A1(n_49),
.A2(n_47),
.B(n_52),
.Y(n_56)
);

AOI221x1_ASAP7_75t_L g57 ( 
.A1(n_56),
.A2(n_28),
.B1(n_25),
.B2(n_52),
.C(n_46),
.Y(n_57)
);

OAI211xp5_ASAP7_75t_SL g58 ( 
.A1(n_54),
.A2(n_19),
.B(n_39),
.C(n_25),
.Y(n_58)
);

INVx1_ASAP7_75t_SL g59 ( 
.A(n_55),
.Y(n_59)
);

HB1xp67_ASAP7_75t_L g60 ( 
.A(n_53),
.Y(n_60)
);

AOI21xp33_ASAP7_75t_L g61 ( 
.A1(n_53),
.A2(n_46),
.B(n_39),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_59),
.Y(n_62)
);

NAND4xp75_ASAP7_75t_L g63 ( 
.A(n_57),
.B(n_16),
.C(n_13),
.D(n_12),
.Y(n_63)
);

OAI22xp33_ASAP7_75t_R g64 ( 
.A1(n_60),
.A2(n_18),
.B1(n_17),
.B2(n_16),
.Y(n_64)
);

NAND2xp5_ASAP7_75t_L g65 ( 
.A(n_61),
.B(n_25),
.Y(n_65)
);

AOI22xp5_ASAP7_75t_L g66 ( 
.A1(n_64),
.A2(n_58),
.B1(n_28),
.B2(n_18),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_62),
.Y(n_67)
);

INVx2_ASAP7_75t_L g68 ( 
.A(n_65),
.Y(n_68)
);

AOI22x1_ASAP7_75t_L g69 ( 
.A1(n_67),
.A2(n_28),
.B1(n_63),
.B2(n_14),
.Y(n_69)
);

OAI22xp33_ASAP7_75t_L g70 ( 
.A1(n_69),
.A2(n_66),
.B1(n_68),
.B2(n_28),
.Y(n_70)
);


endmodule