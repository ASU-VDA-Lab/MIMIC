module fake_netlist_709_3499_n_25 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_25);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_25;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_12;
wire n_11;
wire n_19;
wire n_14;
wire n_13;

CKINVDCx16_ASAP7_75t_R g11 ( 
.A(n_5),
.Y(n_11)
);

XOR2x2_ASAP7_75t_SL g12 ( 
.A(n_9),
.B(n_1),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_0),
.Y(n_13)
);

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_8),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_3),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_11),
.B(n_13),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_15),
.Y(n_19)
);

INVx2_ASAP7_75t_SL g20 ( 
.A(n_19),
.Y(n_20)
);

OAI31xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_12),
.A3(n_10),
.B(n_16),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_SL g23 ( 
.A(n_22),
.Y(n_23)
);

INVxp67_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

AOI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_25)
);


endmodule