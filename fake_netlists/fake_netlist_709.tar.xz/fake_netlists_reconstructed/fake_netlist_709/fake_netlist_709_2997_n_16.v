module fake_netlist_709_2997_n_16 (n_3, n_0, n_2, n_1, n_16);

input n_3;
input n_0;
input n_2;
input n_1;

output n_16;

wire n_9;
wire n_4;
wire n_7;
wire n_14;
wire n_15;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx1_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

NAND2xp5_ASAP7_75t_SL g6 ( 
.A(n_2),
.B(n_0),
.Y(n_6)
);

INVx1_ASAP7_75t_L g7 ( 
.A(n_5),
.Y(n_7)
);

CKINVDCx11_ASAP7_75t_R g8 ( 
.A(n_5),
.Y(n_8)
);

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_4),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_6),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_1),
.Y(n_11)
);

OAI21xp5_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_9),
.B(n_8),
.Y(n_12)
);

AO22x1_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_8),
.B1(n_1),
.B2(n_3),
.Y(n_13)
);

AOI221xp5_ASAP7_75t_L g14 ( 
.A1(n_12),
.A2(n_10),
.B1(n_11),
.B2(n_1),
.C(n_3),
.Y(n_14)
);

OR4x1_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_10),
.C(n_11),
.D(n_13),
.Y(n_15)
);

XNOR2xp5_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_10),
.Y(n_16)
);


endmodule