module fake_netlist_709_2122_n_53 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_25, n_10, n_13, n_14, n_12, n_53);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_53;

wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_46;
wire n_31;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_48;
wire n_49;
wire n_39;

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_9),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_22),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_10),
.Y(n_28)
);

NAND2xp33_ASAP7_75t_R g29 ( 
.A(n_15),
.B(n_25),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_2),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_5),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_18),
.Y(n_32)
);

CKINVDCx20_ASAP7_75t_R g33 ( 
.A(n_1),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_6),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_30),
.B(n_24),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_33),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_30),
.B(n_24),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_35),
.Y(n_39)
);

OAI22xp33_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_29),
.B1(n_27),
.B2(n_26),
.Y(n_40)
);

NAND4xp25_ASAP7_75t_SL g41 ( 
.A(n_39),
.B(n_37),
.C(n_38),
.D(n_25),
.Y(n_41)
);

AOI22xp33_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_32),
.B1(n_31),
.B2(n_28),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_0),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_41),
.B(n_3),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_4),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

INVxp67_ASAP7_75t_L g47 ( 
.A(n_45),
.Y(n_47)
);

OAI22x1_ASAP7_75t_L g48 ( 
.A1(n_46),
.A2(n_11),
.B1(n_8),
.B2(n_7),
.Y(n_48)
);

BUFx3_ASAP7_75t_L g49 ( 
.A(n_48),
.Y(n_49)
);

NAND2xp5_ASAP7_75t_L g50 ( 
.A(n_47),
.B(n_12),
.Y(n_50)
);

INVx2_ASAP7_75t_L g51 ( 
.A(n_49),
.Y(n_51)
);

AOI22xp5_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_16),
.B1(n_14),
.B2(n_13),
.Y(n_52)
);

AOI322xp5_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_17),
.A3(n_19),
.B1(n_20),
.B2(n_21),
.C1(n_23),
.C2(n_52),
.Y(n_53)
);


endmodule