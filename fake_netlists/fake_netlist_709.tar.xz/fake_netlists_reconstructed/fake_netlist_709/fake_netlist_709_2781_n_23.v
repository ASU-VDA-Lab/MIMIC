module fake_netlist_709_2781_n_23 (n_4, n_2, n_3, n_1, n_0, n_23);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_23;

wire n_21;
wire n_17;
wire n_6;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_5;
wire n_7;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx3_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

INVx5_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

NAND2x1p5_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_1),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_SL g8 ( 
.A(n_1),
.B(n_3),
.Y(n_8)
);

INVx2_ASAP7_75t_SL g9 ( 
.A(n_3),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_1),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_4),
.B1(n_2),
.B2(n_0),
.Y(n_12)
);

AOI22xp33_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_4),
.B1(n_5),
.B2(n_6),
.Y(n_13)
);

NAND3xp33_ASAP7_75t_SL g14 ( 
.A(n_12),
.B(n_7),
.C(n_8),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_11),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_15),
.B(n_5),
.Y(n_17)
);

AOI22xp5_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_13),
.B1(n_7),
.B2(n_5),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_15),
.Y(n_19)
);

AOI31xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_14),
.A3(n_4),
.B(n_6),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_6),
.B1(n_19),
.B2(n_16),
.C(n_14),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_20),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_18),
.B2(n_6),
.Y(n_23)
);


endmodule