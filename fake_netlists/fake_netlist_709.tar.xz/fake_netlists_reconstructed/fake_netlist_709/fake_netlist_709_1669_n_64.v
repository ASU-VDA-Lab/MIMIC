module fake_netlist_709_1669_n_64 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_64);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_64;

wire n_54;
wire n_24;
wire n_50;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_17;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_31;
wire n_23;
wire n_41;
wire n_46;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_19;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_0),
.Y(n_17)
);

INVxp67_ASAP7_75t_SL g18 ( 
.A(n_1),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_11),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_14),
.Y(n_20)
);

INVx2_ASAP7_75t_L g21 ( 
.A(n_8),
.Y(n_21)
);

AND2x2_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_5),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_2),
.Y(n_23)
);

BUFx2_ASAP7_75t_L g24 ( 
.A(n_1),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_16),
.Y(n_25)
);

NOR2xp67_ASAP7_75t_L g26 ( 
.A(n_3),
.B(n_9),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_10),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_15),
.Y(n_28)
);

INVx3_ASAP7_75t_L g29 ( 
.A(n_10),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_12),
.Y(n_30)
);

HB1xp67_ASAP7_75t_L g31 ( 
.A(n_7),
.Y(n_31)
);

AOI33xp33_ASAP7_75t_L g32 ( 
.A1(n_25),
.A2(n_28),
.A3(n_21),
.B1(n_20),
.B2(n_22),
.B3(n_24),
.Y(n_32)
);

O2A1O1Ixp33_ASAP7_75t_SL g33 ( 
.A1(n_28),
.A2(n_3),
.B(n_2),
.C(n_0),
.Y(n_33)
);

O2A1O1Ixp33_ASAP7_75t_L g34 ( 
.A1(n_25),
.A2(n_6),
.B(n_5),
.C(n_4),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_20),
.Y(n_35)
);

O2A1O1Ixp33_ASAP7_75t_L g36 ( 
.A1(n_25),
.A2(n_11),
.B(n_6),
.C(n_4),
.Y(n_36)
);

O2A1O1Ixp5_ASAP7_75t_L g37 ( 
.A1(n_29),
.A2(n_16),
.B(n_21),
.C(n_20),
.Y(n_37)
);

AOI21xp5_ASAP7_75t_L g38 ( 
.A1(n_31),
.A2(n_21),
.B(n_29),
.Y(n_38)
);

O2A1O1Ixp33_ASAP7_75t_L g39 ( 
.A1(n_24),
.A2(n_29),
.B(n_18),
.C(n_22),
.Y(n_39)
);

AND2x4_ASAP7_75t_SL g40 ( 
.A(n_29),
.B(n_27),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_19),
.A2(n_23),
.B1(n_27),
.B2(n_17),
.Y(n_41)
);

O2A1O1Ixp33_ASAP7_75t_L g42 ( 
.A1(n_26),
.A2(n_25),
.B(n_24),
.C(n_29),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_38),
.B(n_30),
.Y(n_43)
);

AND2x2_ASAP7_75t_L g44 ( 
.A(n_32),
.B(n_27),
.Y(n_44)
);

CKINVDCx16_ASAP7_75t_R g45 ( 
.A(n_41),
.Y(n_45)
);

BUFx12f_ASAP7_75t_L g46 ( 
.A(n_39),
.Y(n_46)
);

INVx2_ASAP7_75t_L g47 ( 
.A(n_40),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_L g48 ( 
.A(n_43),
.B(n_42),
.Y(n_48)
);

OR2x2_ASAP7_75t_L g49 ( 
.A(n_45),
.B(n_40),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_47),
.Y(n_50)
);

AND2x2_ASAP7_75t_L g51 ( 
.A(n_44),
.B(n_35),
.Y(n_51)
);

OAI21xp33_ASAP7_75t_L g52 ( 
.A1(n_48),
.A2(n_44),
.B(n_47),
.Y(n_52)
);

AO221x1_ASAP7_75t_L g53 ( 
.A1(n_50),
.A2(n_45),
.B1(n_27),
.B2(n_47),
.C(n_33),
.Y(n_53)
);

INVxp33_ASAP7_75t_L g54 ( 
.A(n_49),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_46),
.Y(n_55)
);

AOI211xp5_ASAP7_75t_L g56 ( 
.A1(n_54),
.A2(n_49),
.B(n_33),
.C(n_36),
.Y(n_56)
);

BUFx2_ASAP7_75t_L g57 ( 
.A(n_55),
.Y(n_57)
);

NAND2x1_ASAP7_75t_L g58 ( 
.A(n_53),
.B(n_51),
.Y(n_58)
);

NOR2x1_ASAP7_75t_L g59 ( 
.A(n_52),
.B(n_34),
.Y(n_59)
);

CKINVDCx5p33_ASAP7_75t_R g60 ( 
.A(n_57),
.Y(n_60)
);

INVx1_ASAP7_75t_L g61 ( 
.A(n_59),
.Y(n_61)
);

INVx1_ASAP7_75t_L g62 ( 
.A(n_58),
.Y(n_62)
);

AOI22x1_ASAP7_75t_L g63 ( 
.A1(n_61),
.A2(n_27),
.B1(n_56),
.B2(n_46),
.Y(n_63)
);

AOI222xp33_ASAP7_75t_L g64 ( 
.A1(n_63),
.A2(n_54),
.B1(n_60),
.B2(n_62),
.C1(n_43),
.C2(n_37),
.Y(n_64)
);


endmodule