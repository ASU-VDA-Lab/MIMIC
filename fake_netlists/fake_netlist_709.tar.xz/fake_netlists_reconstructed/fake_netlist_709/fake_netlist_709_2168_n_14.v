module fake_netlist_709_2168_n_14 (n_4, n_2, n_3, n_1, n_0, n_14);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_14;

wire n_9;
wire n_7;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

AND2x6_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_2),
.Y(n_5)
);

INVx2_ASAP7_75t_L g6 ( 
.A(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_3),
.B(n_4),
.Y(n_7)
);

OA21x2_ASAP7_75t_L g8 ( 
.A1(n_6),
.A2(n_1),
.B(n_0),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_5),
.B(n_0),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_0),
.Y(n_10)
);

OA22x2_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_7),
.B1(n_9),
.B2(n_4),
.Y(n_11)
);

OAI211xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B(n_4),
.C(n_1),
.Y(n_12)
);

NOR3xp33_ASAP7_75t_SL g13 ( 
.A(n_12),
.B(n_2),
.C(n_1),
.Y(n_13)
);

AOI22xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_2),
.B1(n_11),
.B2(n_12),
.Y(n_14)
);


endmodule