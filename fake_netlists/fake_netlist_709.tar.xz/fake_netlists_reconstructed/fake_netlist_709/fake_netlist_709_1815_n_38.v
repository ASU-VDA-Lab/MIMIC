module fake_netlist_709_1815_n_38 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_38);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_38;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_35;
wire n_34;
wire n_16;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_19;
wire n_30;
wire n_25;
wire n_13;
wire n_14;

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_12),
.Y(n_13)
);

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_7),
.Y(n_18)
);

AND3x2_ASAP7_75t_L g19 ( 
.A(n_1),
.B(n_5),
.C(n_4),
.Y(n_19)
);

OAI21xp5_ASAP7_75t_L g20 ( 
.A1(n_15),
.A2(n_3),
.B(n_0),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_17),
.A2(n_6),
.B1(n_4),
.B2(n_1),
.Y(n_21)
);

BUFx3_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_13),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_18),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

OR2x6_ASAP7_75t_L g26 ( 
.A(n_20),
.B(n_14),
.Y(n_26)
);

HB1xp67_ASAP7_75t_L g27 ( 
.A(n_24),
.Y(n_27)
);

AND2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_23),
.Y(n_28)
);

OR2x2_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_21),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

NAND4xp25_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_22),
.C(n_25),
.D(n_19),
.Y(n_31)
);

OAI21xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_26),
.B(n_22),
.Y(n_32)
);

NAND2xp5_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_26),
.Y(n_33)
);

AND2x4_ASAP7_75t_L g34 ( 
.A(n_33),
.B(n_8),
.Y(n_34)
);

CKINVDCx5p33_ASAP7_75t_R g35 ( 
.A(n_32),
.Y(n_35)
);

HB1xp67_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AND2x4_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_9),
.Y(n_37)
);

AOI22xp33_ASAP7_75t_SL g38 ( 
.A1(n_37),
.A2(n_34),
.B1(n_35),
.B2(n_36),
.Y(n_38)
);


endmodule