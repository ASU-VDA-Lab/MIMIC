module fake_netlist_660_690_n_33 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_33);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_33;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_32;

INVx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_13),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_6),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_4),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_SL g24 ( 
.A(n_20),
.B(n_16),
.Y(n_24)
);

OAI21x1_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_20),
.B(n_21),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AND2x4_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_19),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

AOI221xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_18),
.B1(n_21),
.B2(n_22),
.C(n_23),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_SL g30 ( 
.A(n_29),
.B(n_17),
.C(n_20),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_31)
);

AOI222xp33_ASAP7_75t_SL g32 ( 
.A1(n_31),
.A2(n_8),
.B1(n_7),
.B2(n_9),
.C1(n_11),
.C2(n_10),
.Y(n_32)
);

AOI22x1_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_15),
.B1(n_14),
.B2(n_12),
.Y(n_33)
);


endmodule