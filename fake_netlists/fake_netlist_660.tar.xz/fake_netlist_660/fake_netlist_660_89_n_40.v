module fake_netlist_660_89_n_40 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_40);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_40;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_39;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_13;

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_0),
.B(n_9),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_7),
.Y(n_14)
);

AND2x4_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_1),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_10),
.B(n_8),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_7),
.Y(n_18)
);

CKINVDCx8_ASAP7_75t_R g19 ( 
.A(n_4),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_14),
.B(n_18),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_17),
.B(n_0),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_17),
.B(n_1),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_15),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_23),
.Y(n_25)
);

NAND4xp75_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_13),
.C(n_21),
.D(n_16),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_24),
.Y(n_27)
);

OAI33xp33_ASAP7_75t_L g28 ( 
.A1(n_26),
.A2(n_24),
.A3(n_19),
.B1(n_15),
.B2(n_13),
.B3(n_2),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_27),
.B(n_24),
.Y(n_29)
);

OAI22xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_15),
.B1(n_26),
.B2(n_2),
.Y(n_30)
);

INVxp67_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_31),
.B1(n_29),
.B2(n_3),
.Y(n_32)
);

AOI21xp33_ASAP7_75t_SL g33 ( 
.A1(n_30),
.A2(n_4),
.B(n_3),
.Y(n_33)
);

OAI21xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_6),
.B(n_5),
.Y(n_34)
);

HB1xp67_ASAP7_75t_L g35 ( 
.A(n_34),
.Y(n_35)
);

AND2x2_ASAP7_75t_L g36 ( 
.A(n_32),
.B(n_33),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

NOR2xp67_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_5),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

AOI22x1_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_37),
.B1(n_38),
.B2(n_12),
.Y(n_40)
);


endmodule