module fake_netlist_660_2244_n_47 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_20, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_47);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_20;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_47;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_23;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_19),
.Y(n_23)
);

BUFx6f_ASAP7_75t_SL g24 ( 
.A(n_3),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_20),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_4),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_13),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_0),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_10),
.B(n_7),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_14),
.Y(n_31)
);

AOI21xp5_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_2),
.B(n_1),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_24),
.A2(n_21),
.B1(n_17),
.B2(n_16),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_24),
.A2(n_21),
.B1(n_17),
.B2(n_16),
.Y(n_34)
);

BUFx4f_ASAP7_75t_SL g35 ( 
.A(n_33),
.Y(n_35)
);

NAND2xp33_ASAP7_75t_R g36 ( 
.A(n_32),
.B(n_30),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx2_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

OAI21xp5_ASAP7_75t_L g39 ( 
.A1(n_38),
.A2(n_31),
.B(n_28),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_37),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_34),
.B1(n_24),
.B2(n_27),
.C(n_23),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_36),
.B1(n_26),
.B2(n_25),
.Y(n_42)
);

AOI222xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_27),
.B1(n_22),
.B2(n_8),
.C1(n_6),
.C2(n_5),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_42),
.Y(n_44)
);

AND2x2_ASAP7_75t_L g45 ( 
.A(n_44),
.B(n_22),
.Y(n_45)
);

OAI22xp5_ASAP7_75t_L g46 ( 
.A1(n_43),
.A2(n_27),
.B1(n_11),
.B2(n_9),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_45),
.B1(n_15),
.B2(n_12),
.Y(n_47)
);


endmodule