module fake_netlist_660_2841_n_27 (n_9, n_4, n_7, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_27);

input n_9;
input n_4;
input n_7;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_27;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_26;

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_1),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_7),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_8),
.Y(n_16)
);

CKINVDCx16_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

INVx4_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_7),
.B1(n_6),
.B2(n_4),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_6),
.Y(n_20)
);

NOR2x1_ASAP7_75t_L g21 ( 
.A(n_20),
.B(n_18),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_15),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_19),
.B1(n_17),
.B2(n_14),
.Y(n_23)
);

A2O1A1Ixp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_16),
.B(n_2),
.C(n_0),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

AOI22x1_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_9),
.B1(n_5),
.B2(n_3),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_13),
.B1(n_12),
.B2(n_11),
.Y(n_27)
);


endmodule