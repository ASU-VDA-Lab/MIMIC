module fake_netlist_660_1413_n_48 (n_18, n_19, n_1, n_0, n_5, n_10, n_24, n_11, n_15, n_7, n_20, n_23, n_16, n_12, n_3, n_22, n_4, n_17, n_14, n_21, n_2, n_9, n_13, n_8, n_6, n_48);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_24;
input n_11;
input n_15;
input n_7;
input n_20;
input n_23;
input n_16;
input n_12;
input n_3;
input n_22;
input n_4;
input n_17;
input n_14;
input n_21;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_48;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_35;
wire n_28;
wire n_30;
wire n_45;
wire n_39;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_20),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_3),
.Y(n_26)
);

CKINVDCx5p33_ASAP7_75t_R g27 ( 
.A(n_21),
.Y(n_27)
);

CKINVDCx5p33_ASAP7_75t_R g28 ( 
.A(n_22),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_19),
.B(n_16),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_13),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_0),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_1),
.Y(n_32)
);

NAND3xp33_ASAP7_75t_L g33 ( 
.A(n_30),
.B(n_31),
.C(n_26),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_18),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

OAI22xp33_ASAP7_75t_L g37 ( 
.A1(n_35),
.A2(n_28),
.B1(n_27),
.B2(n_25),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_33),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_37),
.Y(n_39)
);

INVxp67_ASAP7_75t_SL g40 ( 
.A(n_38),
.Y(n_40)
);

OAI211xp5_ASAP7_75t_SL g41 ( 
.A1(n_39),
.A2(n_24),
.B(n_18),
.C(n_29),
.Y(n_41)
);

AOI22xp5_ASAP7_75t_L g42 ( 
.A1(n_40),
.A2(n_24),
.B1(n_4),
.B2(n_2),
.Y(n_42)
);

AOI211xp5_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_7),
.B(n_6),
.C(n_5),
.Y(n_43)
);

NAND2xp33_ASAP7_75t_R g44 ( 
.A(n_43),
.B(n_8),
.Y(n_44)
);

XOR2xp5_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_9),
.Y(n_45)
);

NAND3xp33_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_11),
.C(n_10),
.Y(n_46)
);

XNOR2xp5_ASAP7_75t_L g47 ( 
.A(n_45),
.B(n_12),
.Y(n_47)
);

AOI222xp33_ASAP7_75t_L g48 ( 
.A1(n_47),
.A2(n_46),
.B1(n_17),
.B2(n_14),
.C1(n_23),
.C2(n_15),
.Y(n_48)
);


endmodule