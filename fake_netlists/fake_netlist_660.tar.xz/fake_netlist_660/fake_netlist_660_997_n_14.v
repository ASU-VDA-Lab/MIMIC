module fake_netlist_660_997_n_14 (n_3, n_1, n_2, n_0, n_14);

input n_3;
input n_1;
input n_2;
input n_0;

output n_14;

wire n_9;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_10;
wire n_12;
wire n_11;
wire n_8;
wire n_6;

AND2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_0),
.Y(n_4)
);

CKINVDCx5p33_ASAP7_75t_R g5 ( 
.A(n_0),
.Y(n_5)
);

AO21x2_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

OAI21x1_ASAP7_75t_L g7 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.Y(n_7)
);

AND2x2_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_5),
.Y(n_8)
);

OR2x2_ASAP7_75t_L g9 ( 
.A(n_6),
.B(n_5),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_6),
.Y(n_10)
);

AOI222xp33_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_4),
.B1(n_7),
.B2(n_9),
.C1(n_6),
.C2(n_1),
.Y(n_11)
);

OAI22x1_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_2),
.B1(n_3),
.B2(n_7),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_2),
.Y(n_13)
);

XNOR2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_13),
.Y(n_14)
);


endmodule