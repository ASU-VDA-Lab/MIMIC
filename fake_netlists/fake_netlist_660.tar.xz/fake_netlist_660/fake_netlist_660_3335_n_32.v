module fake_netlist_660_3335_n_32 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_32);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_32;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;

AND2x6_ASAP7_75t_L g18 ( 
.A(n_13),
.B(n_2),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_7),
.Y(n_19)
);

HB1xp67_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

INVxp67_ASAP7_75t_L g21 ( 
.A(n_5),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_15),
.Y(n_23)
);

AOI21xp5_ASAP7_75t_L g24 ( 
.A1(n_20),
.A2(n_1),
.B(n_0),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_21),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_19),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_16),
.Y(n_27)
);

O2A1O1Ixp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_24),
.B(n_23),
.C(n_16),
.Y(n_28)
);

OAI221xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_18),
.B1(n_22),
.B2(n_3),
.C(n_6),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_30),
.A2(n_10),
.B1(n_9),
.B2(n_8),
.Y(n_31)
);

OAI31xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_17),
.A3(n_14),
.B(n_11),
.Y(n_32)
);


endmodule