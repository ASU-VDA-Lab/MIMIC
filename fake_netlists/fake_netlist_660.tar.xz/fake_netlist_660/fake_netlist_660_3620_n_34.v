module fake_netlist_660_3620_n_34 (n_9, n_4, n_7, n_17, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_34);

input n_9;
input n_4;
input n_7;
input n_17;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_34;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

BUFx3_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

BUFx10_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_10),
.Y(n_20)
);

CKINVDCx20_ASAP7_75t_R g21 ( 
.A(n_7),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_SL g22 ( 
.A(n_11),
.B(n_3),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_6),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_2),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_19),
.B(n_16),
.Y(n_25)
);

AOI21xp5_ASAP7_75t_L g26 ( 
.A1(n_22),
.A2(n_4),
.B(n_0),
.Y(n_26)
);

BUFx6f_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

BUFx4f_ASAP7_75t_SL g28 ( 
.A(n_26),
.Y(n_28)
);

NOR2xp33_ASAP7_75t_SL g29 ( 
.A(n_27),
.B(n_20),
.Y(n_29)
);

INVx2_ASAP7_75t_SL g30 ( 
.A(n_29),
.Y(n_30)
);

AOI221xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_21),
.B1(n_24),
.B2(n_23),
.C(n_18),
.Y(n_31)
);

OAI311xp33_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_19),
.A3(n_16),
.B1(n_28),
.C1(n_5),
.Y(n_32)
);

OAI22xp5_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_13),
.B1(n_9),
.B2(n_8),
.Y(n_33)
);

AOI22xp5_ASAP7_75t_SL g34 ( 
.A1(n_33),
.A2(n_17),
.B1(n_15),
.B2(n_14),
.Y(n_34)
);


endmodule