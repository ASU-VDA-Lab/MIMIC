module fake_netlist_660_1171_n_57 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_16, n_8, n_15, n_6, n_3, n_57);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_16;
input n_8;
input n_15;
input n_6;
input n_3;

output n_57;

wire n_18;
wire n_36;
wire n_19;
wire n_34;
wire n_38;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_22;
wire n_17;
wire n_39;
wire n_21;
wire n_27;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;

NAND2xp33_ASAP7_75t_SL g17 ( 
.A(n_9),
.B(n_7),
.Y(n_17)
);

BUFx6f_ASAP7_75t_L g18 ( 
.A(n_10),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_11),
.Y(n_19)
);

NOR2xp33_ASAP7_75t_L g20 ( 
.A(n_2),
.B(n_15),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_0),
.Y(n_22)
);

CKINVDCx16_ASAP7_75t_R g23 ( 
.A(n_1),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_8),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_0),
.B(n_4),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_12),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_21),
.Y(n_27)
);

NOR2xp33_ASAP7_75t_L g28 ( 
.A(n_26),
.B(n_1),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_22),
.Y(n_29)
);

AO22x1_ASAP7_75t_L g30 ( 
.A1(n_25),
.A2(n_14),
.B1(n_13),
.B2(n_2),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_18),
.B(n_13),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_SL g33 ( 
.A1(n_31),
.A2(n_23),
.B1(n_20),
.B2(n_24),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

BUFx3_ASAP7_75t_L g35 ( 
.A(n_32),
.Y(n_35)
);

AND2x4_ASAP7_75t_L g36 ( 
.A(n_27),
.B(n_18),
.Y(n_36)
);

AOI221xp5_ASAP7_75t_L g37 ( 
.A1(n_33),
.A2(n_29),
.B1(n_28),
.B2(n_30),
.C(n_27),
.Y(n_37)
);

AOI221xp5_ASAP7_75t_L g38 ( 
.A1(n_34),
.A2(n_28),
.B1(n_20),
.B2(n_17),
.C(n_18),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_L g39 ( 
.A1(n_34),
.A2(n_19),
.B1(n_18),
.B2(n_14),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_39),
.Y(n_40)
);

NAND2xp5_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_35),
.Y(n_41)
);

OR2x2_ASAP7_75t_L g42 ( 
.A(n_38),
.B(n_36),
.Y(n_42)
);

OAI21xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_35),
.B(n_36),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_42),
.Y(n_44)
);

HB1xp67_ASAP7_75t_L g45 ( 
.A(n_40),
.Y(n_45)
);

AOI211xp5_ASAP7_75t_L g46 ( 
.A1(n_42),
.A2(n_36),
.B(n_35),
.C(n_19),
.Y(n_46)
);

OR2x2_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_36),
.Y(n_47)
);

INVx1_ASAP7_75t_L g48 ( 
.A(n_45),
.Y(n_48)
);

AOI22xp5_ASAP7_75t_L g49 ( 
.A1(n_44),
.A2(n_19),
.B1(n_16),
.B2(n_15),
.Y(n_49)
);

HB1xp67_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

INVx2_ASAP7_75t_SL g51 ( 
.A(n_48),
.Y(n_51)
);

A2O1A1Ixp33_ASAP7_75t_L g52 ( 
.A1(n_50),
.A2(n_43),
.B(n_19),
.C(n_16),
.Y(n_52)
);

XOR2xp5_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_47),
.Y(n_53)
);

HB1xp67_ASAP7_75t_L g54 ( 
.A(n_48),
.Y(n_54)
);

AND3x1_ASAP7_75t_L g55 ( 
.A(n_51),
.B(n_6),
.C(n_5),
.Y(n_55)
);

INVx2_ASAP7_75t_SL g56 ( 
.A(n_54),
.Y(n_56)
);

AOI22xp5_ASAP7_75t_L g57 ( 
.A1(n_55),
.A2(n_52),
.B1(n_53),
.B2(n_56),
.Y(n_57)
);


endmodule