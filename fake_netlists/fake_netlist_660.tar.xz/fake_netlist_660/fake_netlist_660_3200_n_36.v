module fake_netlist_660_3200_n_36 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_36);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_36;

wire n_34;
wire n_25;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_23;
wire n_22;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_33;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_11),
.A2(n_15),
.B1(n_6),
.B2(n_17),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_4),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_1),
.B(n_18),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_0),
.Y(n_25)
);

AND2x2_ASAP7_75t_L g26 ( 
.A(n_7),
.B(n_14),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_22),
.B(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_SL g28 ( 
.A(n_24),
.B(n_14),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_29),
.B(n_20),
.Y(n_30)
);

AND2x2_ASAP7_75t_L g31 ( 
.A(n_30),
.B(n_27),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_L g32 ( 
.A(n_31),
.B(n_28),
.Y(n_32)
);

AOI22xp33_ASAP7_75t_L g33 ( 
.A1(n_32),
.A2(n_31),
.B1(n_21),
.B2(n_23),
.Y(n_33)
);

CKINVDCx5p33_ASAP7_75t_R g34 ( 
.A(n_33),
.Y(n_34)
);

OAI22xp5_ASAP7_75t_SL g35 ( 
.A1(n_34),
.A2(n_5),
.B1(n_3),
.B2(n_2),
.Y(n_35)
);

AOI222xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_9),
.B1(n_8),
.B2(n_10),
.C1(n_13),
.C2(n_12),
.Y(n_36)
);


endmodule