module fake_netlist_660_671_n_63 (n_18, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_63);

input n_18;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_63;

wire n_36;
wire n_59;
wire n_19;
wire n_62;
wire n_34;
wire n_38;
wire n_58;
wire n_51;
wire n_44;
wire n_25;
wire n_40;
wire n_54;
wire n_24;
wire n_35;
wire n_57;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_49;
wire n_53;
wire n_56;
wire n_23;
wire n_48;
wire n_60;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_55;
wire n_52;
wire n_50;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;
wire n_47;
wire n_61;

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_7),
.B(n_10),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_3),
.Y(n_21)
);

NAND2xp5_ASAP7_75t_L g22 ( 
.A(n_13),
.B(n_4),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_17),
.B(n_16),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_15),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_3),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

OAI22xp33_ASAP7_75t_L g28 ( 
.A1(n_20),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_SL g29 ( 
.A(n_27),
.B(n_0),
.Y(n_29)
);

AOI22xp33_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_9),
.B1(n_8),
.B2(n_5),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_21),
.B(n_5),
.Y(n_31)
);

AND2x4_ASAP7_75t_L g32 ( 
.A(n_20),
.B(n_8),
.Y(n_32)
);

INVx5_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

BUFx3_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

AND2x4_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_25),
.Y(n_35)
);

INVx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

NAND2xp5_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_32),
.Y(n_37)
);

NOR2x1_ASAP7_75t_L g38 ( 
.A(n_35),
.B(n_24),
.Y(n_38)
);

INVx2_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

AOI322xp5_ASAP7_75t_L g40 ( 
.A1(n_38),
.A2(n_28),
.A3(n_30),
.B1(n_26),
.B2(n_25),
.C1(n_35),
.C2(n_31),
.Y(n_40)
);

NAND3xp33_ASAP7_75t_L g41 ( 
.A(n_37),
.B(n_33),
.C(n_34),
.Y(n_41)
);

INVx3_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

OAI22xp33_ASAP7_75t_L g43 ( 
.A1(n_41),
.A2(n_34),
.B1(n_33),
.B2(n_35),
.Y(n_43)
);

NOR2xp33_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_35),
.Y(n_44)
);

AND2x4_ASAP7_75t_L g45 ( 
.A(n_41),
.B(n_34),
.Y(n_45)
);

AOI321xp33_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_26),
.A3(n_29),
.B1(n_35),
.B2(n_34),
.C(n_19),
.Y(n_46)
);

AOI211xp5_ASAP7_75t_SL g47 ( 
.A1(n_43),
.A2(n_35),
.B(n_22),
.C(n_23),
.Y(n_47)
);

OAI22xp33_ASAP7_75t_L g48 ( 
.A1(n_42),
.A2(n_33),
.B1(n_45),
.B2(n_35),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_42),
.B(n_33),
.Y(n_49)
);

AO21x1_ASAP7_75t_L g50 ( 
.A1(n_45),
.A2(n_33),
.B(n_9),
.Y(n_50)
);

AOI21xp5_ASAP7_75t_L g51 ( 
.A1(n_48),
.A2(n_42),
.B(n_45),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_49),
.Y(n_52)
);

HB1xp67_ASAP7_75t_L g53 ( 
.A(n_50),
.Y(n_53)
);

OAI22xp5_ASAP7_75t_L g54 ( 
.A1(n_47),
.A2(n_45),
.B1(n_33),
.B2(n_10),
.Y(n_54)
);

AND4x2_ASAP7_75t_L g55 ( 
.A(n_50),
.B(n_17),
.C(n_16),
.D(n_11),
.Y(n_55)
);

OAI22x1_ASAP7_75t_L g56 ( 
.A1(n_53),
.A2(n_55),
.B1(n_52),
.B2(n_51),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_11),
.Y(n_57)
);

OR5x1_ASAP7_75t_L g58 ( 
.A(n_55),
.B(n_18),
.C(n_46),
.D(n_6),
.E(n_12),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_55),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_SL g60 ( 
.A1(n_58),
.A2(n_14),
.B1(n_33),
.B2(n_56),
.Y(n_60)
);

OAI21xp5_ASAP7_75t_L g61 ( 
.A1(n_59),
.A2(n_57),
.B(n_58),
.Y(n_61)
);

AOI22x1_ASAP7_75t_L g62 ( 
.A1(n_56),
.A2(n_33),
.B1(n_59),
.B2(n_47),
.Y(n_62)
);

AOI22x1_ASAP7_75t_L g63 ( 
.A1(n_61),
.A2(n_33),
.B1(n_60),
.B2(n_62),
.Y(n_63)
);


endmodule