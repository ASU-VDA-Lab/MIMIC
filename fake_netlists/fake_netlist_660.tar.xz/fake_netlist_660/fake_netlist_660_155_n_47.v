module fake_netlist_660_155_n_47 (n_18, n_19, n_1, n_0, n_5, n_10, n_11, n_15, n_7, n_16, n_12, n_3, n_4, n_17, n_14, n_2, n_9, n_13, n_8, n_6, n_47);

input n_18;
input n_19;
input n_1;
input n_0;
input n_5;
input n_10;
input n_11;
input n_15;
input n_7;
input n_16;
input n_12;
input n_3;
input n_4;
input n_17;
input n_14;
input n_2;
input n_9;
input n_13;
input n_8;
input n_6;

output n_47;

wire n_36;
wire n_34;
wire n_38;
wire n_44;
wire n_25;
wire n_40;
wire n_24;
wire n_35;
wire n_28;
wire n_30;
wire n_20;
wire n_45;
wire n_23;
wire n_22;
wire n_39;
wire n_27;
wire n_21;
wire n_46;
wire n_42;
wire n_29;
wire n_31;
wire n_41;
wire n_26;
wire n_33;
wire n_32;
wire n_37;
wire n_43;

INVxp33_ASAP7_75t_SL g20 ( 
.A(n_8),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_2),
.B(n_15),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_13),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_17),
.Y(n_24)
);

BUFx2_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

NOR2xp33_ASAP7_75t_R g26 ( 
.A(n_19),
.B(n_1),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_14),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_10),
.B(n_9),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_12),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_6),
.B(n_4),
.Y(n_30)
);

BUFx2_ASAP7_75t_L g31 ( 
.A(n_25),
.Y(n_31)
);

INVx1_ASAP7_75t_L g32 ( 
.A(n_22),
.Y(n_32)
);

INVx3_ASAP7_75t_L g33 ( 
.A(n_23),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_20),
.B1(n_27),
.B2(n_24),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_32),
.B(n_29),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_33),
.Y(n_36)
);

NAND3xp33_ASAP7_75t_L g37 ( 
.A(n_35),
.B(n_28),
.C(n_21),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

HB1xp67_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

NOR3xp33_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_30),
.C(n_26),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_39),
.Y(n_41)
);

INVxp67_ASAP7_75t_SL g42 ( 
.A(n_41),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

CKINVDCx20_ASAP7_75t_R g44 ( 
.A(n_43),
.Y(n_44)
);

NOR4xp25_ASAP7_75t_L g45 ( 
.A(n_42),
.B(n_7),
.C(n_5),
.D(n_0),
.Y(n_45)
);

BUFx2_ASAP7_75t_L g46 ( 
.A(n_44),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_45),
.B1(n_18),
.B2(n_16),
.Y(n_47)
);


endmodule