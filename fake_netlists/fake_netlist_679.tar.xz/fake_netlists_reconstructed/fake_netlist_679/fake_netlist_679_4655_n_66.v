module fake_netlist_679_4655_n_66 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_66);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_66;

wire n_54;
wire n_50;
wire n_24;
wire n_61;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_64;
wire n_40;
wire n_42;
wire n_47;
wire n_58;
wire n_35;
wire n_62;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_63;
wire n_37;
wire n_51;
wire n_23;
wire n_46;
wire n_41;
wire n_31;
wire n_29;
wire n_56;
wire n_60;
wire n_53;
wire n_33;
wire n_65;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

INVx2_ASAP7_75t_L g23 ( 
.A(n_19),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_7),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_1),
.Y(n_25)
);

BUFx2_ASAP7_75t_L g26 ( 
.A(n_16),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_0),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_19),
.B(n_9),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_13),
.Y(n_29)
);

AND2x4_ASAP7_75t_L g30 ( 
.A(n_21),
.B(n_3),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_15),
.Y(n_31)
);

INVxp67_ASAP7_75t_L g32 ( 
.A(n_12),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_6),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_L g34 ( 
.A(n_26),
.B(n_16),
.Y(n_34)
);

AOI22xp33_ASAP7_75t_L g35 ( 
.A1(n_26),
.A2(n_20),
.B1(n_18),
.B2(n_17),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_23),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_23),
.Y(n_37)
);

AND2x4_ASAP7_75t_L g38 ( 
.A(n_30),
.B(n_17),
.Y(n_38)
);

BUFx8_ASAP7_75t_SL g39 ( 
.A(n_38),
.Y(n_39)
);

AND2x2_ASAP7_75t_L g40 ( 
.A(n_36),
.B(n_30),
.Y(n_40)
);

INVx1_ASAP7_75t_SL g41 ( 
.A(n_38),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_41),
.Y(n_42)
);

OR2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_34),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_L g44 ( 
.A(n_40),
.B(n_30),
.Y(n_44)
);

INVx6_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_42),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_44),
.B(n_40),
.Y(n_47)
);

NOR2xp33_ASAP7_75t_L g48 ( 
.A(n_45),
.B(n_39),
.Y(n_48)
);

OAI21xp33_ASAP7_75t_SL g49 ( 
.A1(n_47),
.A2(n_35),
.B(n_40),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_46),
.Y(n_50)
);

AOI21xp33_ASAP7_75t_SL g51 ( 
.A1(n_45),
.A2(n_35),
.B(n_28),
.Y(n_51)
);

INVx1_ASAP7_75t_SL g52 ( 
.A(n_48),
.Y(n_52)
);

AND2x2_ASAP7_75t_L g53 ( 
.A(n_49),
.B(n_37),
.Y(n_53)
);

AOI221xp5_ASAP7_75t_L g54 ( 
.A1(n_51),
.A2(n_33),
.B1(n_27),
.B2(n_25),
.C(n_32),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_50),
.Y(n_55)
);

NAND3x2_ASAP7_75t_L g56 ( 
.A(n_53),
.B(n_50),
.C(n_18),
.Y(n_56)
);

AND2x4_ASAP7_75t_L g57 ( 
.A(n_55),
.B(n_2),
.Y(n_57)
);

NOR3x2_ASAP7_75t_L g58 ( 
.A(n_52),
.B(n_21),
.C(n_20),
.Y(n_58)
);

OAI22xp5_ASAP7_75t_L g59 ( 
.A1(n_54),
.A2(n_31),
.B1(n_24),
.B2(n_29),
.Y(n_59)
);

NAND2xp5_ASAP7_75t_L g60 ( 
.A(n_57),
.B(n_53),
.Y(n_60)
);

AOI21xp5_ASAP7_75t_L g61 ( 
.A1(n_59),
.A2(n_31),
.B(n_24),
.Y(n_61)
);

OAI22xp5_ASAP7_75t_L g62 ( 
.A1(n_56),
.A2(n_31),
.B1(n_29),
.B2(n_4),
.Y(n_62)
);

INVx2_ASAP7_75t_L g63 ( 
.A(n_57),
.Y(n_63)
);

OAI22xp5_ASAP7_75t_L g64 ( 
.A1(n_60),
.A2(n_58),
.B1(n_29),
.B2(n_5),
.Y(n_64)
);

OAI22xp5_ASAP7_75t_L g65 ( 
.A1(n_63),
.A2(n_62),
.B1(n_61),
.B2(n_29),
.Y(n_65)
);

AOI322xp5_ASAP7_75t_L g66 ( 
.A1(n_64),
.A2(n_8),
.A3(n_10),
.B1(n_11),
.B2(n_14),
.C1(n_22),
.C2(n_65),
.Y(n_66)
);


endmodule