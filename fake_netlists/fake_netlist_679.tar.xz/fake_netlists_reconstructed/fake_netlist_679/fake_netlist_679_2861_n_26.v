module fake_netlist_679_2861_n_26 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_26);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_26;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_25;
wire n_19;
wire n_14;
wire n_13;

INVx2_ASAP7_75t_L g13 ( 
.A(n_2),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_10),
.B(n_5),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_3),
.B(n_11),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_9),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_4),
.Y(n_18)
);

NOR2xp67_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_6),
.Y(n_19)
);

AOI21xp5_ASAP7_75t_SL g20 ( 
.A1(n_14),
.A2(n_15),
.B(n_13),
.Y(n_20)
);

AND2x2_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_18),
.Y(n_21)
);

INVx2_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_22),
.B(n_17),
.C(n_20),
.Y(n_23)
);

NAND3x1_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.C(n_6),
.Y(n_24)
);

OAI21xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_1),
.B(n_0),
.Y(n_25)
);

AOI21x1_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_12),
.B(n_8),
.Y(n_26)
);


endmodule