module fake_netlist_679_3788_n_40 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_40);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_40;

wire n_24;
wire n_38;
wire n_21;
wire n_27;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_31;
wire n_23;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_19;
wire n_25;
wire n_39;

INVx2_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_6),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_7),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_5),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_2),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_4),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_17),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_11),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_SL g26 ( 
.A(n_18),
.B(n_0),
.Y(n_26)
);

OAI21xp33_ASAP7_75t_L g27 ( 
.A1(n_22),
.A2(n_24),
.B(n_18),
.Y(n_27)
);

OAI21xp33_ASAP7_75t_L g28 ( 
.A1(n_18),
.A2(n_2),
.B(n_0),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_26),
.Y(n_29)
);

CKINVDCx20_ASAP7_75t_R g30 ( 
.A(n_27),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

OAI21xp33_ASAP7_75t_SL g32 ( 
.A1(n_29),
.A2(n_28),
.B(n_13),
.Y(n_32)
);

OR2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_30),
.Y(n_33)
);

O2A1O1Ixp5_ASAP7_75t_L g34 ( 
.A1(n_31),
.A2(n_23),
.B(n_21),
.C(n_19),
.Y(n_34)
);

AOI22xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_32),
.B1(n_25),
.B2(n_20),
.Y(n_35)
);

AOI211xp5_ASAP7_75t_SL g36 ( 
.A1(n_34),
.A2(n_15),
.B(n_14),
.C(n_13),
.Y(n_36)
);

CKINVDCx5p33_ASAP7_75t_R g37 ( 
.A(n_35),
.Y(n_37)
);

INVx2_ASAP7_75t_SL g38 ( 
.A(n_36),
.Y(n_38)
);

OAI22xp5_ASAP7_75t_SL g39 ( 
.A1(n_38),
.A2(n_17),
.B1(n_16),
.B2(n_1),
.Y(n_39)
);

AOI222xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_8),
.B1(n_9),
.B2(n_10),
.C1(n_12),
.C2(n_37),
.Y(n_40)
);


endmodule