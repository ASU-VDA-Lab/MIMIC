module fake_netlist_679_482_n_321 (n_24, n_2, n_21, n_27, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_35, n_34, n_16, n_26, n_1, n_5, n_37, n_7, n_23, n_31, n_29, n_33, n_8, n_0, n_36, n_4, n_32, n_28, n_3, n_11, n_19, n_30, n_25, n_10, n_13, n_14, n_12, n_321);

input n_24;
input n_2;
input n_21;
input n_27;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_35;
input n_34;
input n_16;
input n_26;
input n_1;
input n_5;
input n_37;
input n_7;
input n_23;
input n_31;
input n_29;
input n_33;
input n_8;
input n_0;
input n_36;
input n_4;
input n_32;
input n_28;
input n_3;
input n_11;
input n_19;
input n_30;
input n_25;
input n_10;
input n_13;
input n_14;
input n_12;

output n_321;

wire n_110;
wire n_148;
wire n_278;
wire n_309;
wire n_175;
wire n_243;
wire n_157;
wire n_308;
wire n_261;
wire n_319;
wire n_314;
wire n_181;
wire n_59;
wire n_246;
wire n_318;
wire n_229;
wire n_131;
wire n_45;
wire n_158;
wire n_130;
wire n_146;
wire n_136;
wire n_313;
wire n_76;
wire n_184;
wire n_109;
wire n_173;
wire n_74;
wire n_160;
wire n_285;
wire n_295;
wire n_94;
wire n_75;
wire n_54;
wire n_291;
wire n_44;
wire n_248;
wire n_203;
wire n_167;
wire n_42;
wire n_106;
wire n_236;
wire n_307;
wire n_100;
wire n_43;
wire n_84;
wire n_240;
wire n_140;
wire n_68;
wire n_169;
wire n_82;
wire n_172;
wire n_193;
wire n_186;
wire n_135;
wire n_122;
wire n_237;
wire n_242;
wire n_133;
wire n_120;
wire n_217;
wire n_205;
wire n_80;
wire n_132;
wire n_138;
wire n_153;
wire n_126;
wire n_253;
wire n_223;
wire n_221;
wire n_206;
wire n_49;
wire n_57;
wire n_239;
wire n_86;
wire n_40;
wire n_66;
wire n_259;
wire n_213;
wire n_71;
wire n_234;
wire n_179;
wire n_121;
wire n_182;
wire n_60;
wire n_89;
wire n_194;
wire n_262;
wire n_48;
wire n_67;
wire n_39;
wire n_113;
wire n_204;
wire n_190;
wire n_62;
wire n_265;
wire n_70;
wire n_168;
wire n_226;
wire n_296;
wire n_144;
wire n_244;
wire n_170;
wire n_55;
wire n_192;
wire n_78;
wire n_303;
wire n_116;
wire n_225;
wire n_263;
wire n_247;
wire n_195;
wire n_143;
wire n_276;
wire n_117;
wire n_152;
wire n_180;
wire n_202;
wire n_214;
wire n_95;
wire n_282;
wire n_306;
wire n_178;
wire n_320;
wire n_297;
wire n_274;
wire n_137;
wire n_257;
wire n_87;
wire n_255;
wire n_290;
wire n_72;
wire n_273;
wire n_232;
wire n_227;
wire n_268;
wire n_151;
wire n_299;
wire n_269;
wire n_300;
wire n_198;
wire n_61;
wire n_99;
wire n_210;
wire n_115;
wire n_301;
wire n_147;
wire n_230;
wire n_102;
wire n_47;
wire n_196;
wire n_260;
wire n_52;
wire n_220;
wire n_189;
wire n_305;
wire n_212;
wire n_256;
wire n_271;
wire n_50;
wire n_156;
wire n_298;
wire n_85;
wire n_288;
wire n_200;
wire n_63;
wire n_231;
wire n_250;
wire n_209;
wire n_176;
wire n_188;
wire n_187;
wire n_208;
wire n_164;
wire n_270;
wire n_281;
wire n_111;
wire n_91;
wire n_127;
wire n_258;
wire n_51;
wire n_316;
wire n_191;
wire n_241;
wire n_289;
wire n_251;
wire n_90;
wire n_228;
wire n_128;
wire n_118;
wire n_280;
wire n_103;
wire n_293;
wire n_222;
wire n_79;
wire n_105;
wire n_215;
wire n_139;
wire n_56;
wire n_107;
wire n_201;
wire n_96;
wire n_233;
wire n_264;
wire n_219;
wire n_171;
wire n_165;
wire n_235;
wire n_267;
wire n_88;
wire n_315;
wire n_119;
wire n_150;
wire n_162;
wire n_252;
wire n_284;
wire n_114;
wire n_211;
wire n_292;
wire n_112;
wire n_197;
wire n_312;
wire n_83;
wire n_124;
wire n_163;
wire n_272;
wire n_64;
wire n_277;
wire n_218;
wire n_58;
wire n_224;
wire n_69;
wire n_101;
wire n_141;
wire n_123;
wire n_249;
wire n_53;
wire n_275;
wire n_304;
wire n_149;
wire n_81;
wire n_161;
wire n_310;
wire n_245;
wire n_207;
wire n_38;
wire n_317;
wire n_174;
wire n_199;
wire n_238;
wire n_266;
wire n_145;
wire n_287;
wire n_177;
wire n_92;
wire n_129;
wire n_77;
wire n_134;
wire n_93;
wire n_97;
wire n_311;
wire n_216;
wire n_98;
wire n_279;
wire n_125;
wire n_154;
wire n_104;
wire n_283;
wire n_294;
wire n_302;
wire n_183;
wire n_155;
wire n_254;
wire n_46;
wire n_73;
wire n_41;
wire n_185;
wire n_159;
wire n_65;
wire n_142;
wire n_166;
wire n_286;
wire n_108;

INVx1_ASAP7_75t_L g38 ( 
.A(n_13),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_6),
.Y(n_39)
);

INVxp33_ASAP7_75t_L g40 ( 
.A(n_16),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_24),
.Y(n_41)
);

INVx1_ASAP7_75t_L g42 ( 
.A(n_2),
.Y(n_42)
);

CKINVDCx20_ASAP7_75t_R g43 ( 
.A(n_22),
.Y(n_43)
);

CKINVDCx5p33_ASAP7_75t_R g44 ( 
.A(n_1),
.Y(n_44)
);

INVx1_ASAP7_75t_L g45 ( 
.A(n_4),
.Y(n_45)
);

INVx1_ASAP7_75t_L g46 ( 
.A(n_29),
.Y(n_46)
);

BUFx3_ASAP7_75t_L g47 ( 
.A(n_26),
.Y(n_47)
);

CKINVDCx16_ASAP7_75t_R g48 ( 
.A(n_16),
.Y(n_48)
);

INVx1_ASAP7_75t_L g49 ( 
.A(n_14),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_6),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_15),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_38),
.Y(n_52)
);

XNOR2xp5_ASAP7_75t_L g53 ( 
.A(n_40),
.B(n_0),
.Y(n_53)
);

CKINVDCx5p33_ASAP7_75t_R g54 ( 
.A(n_48),
.Y(n_54)
);

BUFx6f_ASAP7_75t_L g55 ( 
.A(n_47),
.Y(n_55)
);

INVx2_ASAP7_75t_L g56 ( 
.A(n_41),
.Y(n_56)
);

CKINVDCx5p33_ASAP7_75t_R g57 ( 
.A(n_48),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_38),
.Y(n_58)
);

CKINVDCx5p33_ASAP7_75t_R g59 ( 
.A(n_43),
.Y(n_59)
);

INVxp67_ASAP7_75t_L g60 ( 
.A(n_39),
.Y(n_60)
);

OAI22x1_ASAP7_75t_L g61 ( 
.A1(n_53),
.A2(n_58),
.B1(n_60),
.B2(n_39),
.Y(n_61)
);

INVx2_ASAP7_75t_SL g62 ( 
.A(n_55),
.Y(n_62)
);

INVx1_ASAP7_75t_L g63 ( 
.A(n_56),
.Y(n_63)
);

AOI22xp33_ASAP7_75t_L g64 ( 
.A1(n_58),
.A2(n_49),
.B1(n_45),
.B2(n_42),
.Y(n_64)
);

INVx2_ASAP7_75t_L g65 ( 
.A(n_56),
.Y(n_65)
);

INVxp67_ASAP7_75t_L g66 ( 
.A(n_54),
.Y(n_66)
);

INVx1_ASAP7_75t_L g67 ( 
.A(n_56),
.Y(n_67)
);

INVx3_ASAP7_75t_L g68 ( 
.A(n_56),
.Y(n_68)
);

INVx3_ASAP7_75t_L g69 ( 
.A(n_55),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_52),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_52),
.Y(n_71)
);

INVxp67_ASAP7_75t_L g72 ( 
.A(n_54),
.Y(n_72)
);

INVx2_ASAP7_75t_L g73 ( 
.A(n_55),
.Y(n_73)
);

NAND3x1_ASAP7_75t_L g74 ( 
.A(n_53),
.B(n_45),
.C(n_42),
.Y(n_74)
);

BUFx4f_ASAP7_75t_L g75 ( 
.A(n_55),
.Y(n_75)
);

NAND2xp5_ASAP7_75t_L g76 ( 
.A(n_55),
.B(n_41),
.Y(n_76)
);

AND2x4_ASAP7_75t_L g77 ( 
.A(n_55),
.B(n_49),
.Y(n_77)
);

INVx5_ASAP7_75t_L g78 ( 
.A(n_69),
.Y(n_78)
);

NOR2xp33_ASAP7_75t_L g79 ( 
.A(n_66),
.B(n_57),
.Y(n_79)
);

OAI21xp5_ASAP7_75t_L g80 ( 
.A1(n_75),
.A2(n_60),
.B(n_46),
.Y(n_80)
);

NAND2xp5_ASAP7_75t_L g81 ( 
.A(n_63),
.B(n_67),
.Y(n_81)
);

INVx1_ASAP7_75t_L g82 ( 
.A(n_63),
.Y(n_82)
);

NAND2xp5_ASAP7_75t_L g83 ( 
.A(n_63),
.B(n_55),
.Y(n_83)
);

NAND2xp5_ASAP7_75t_L g84 ( 
.A(n_67),
.B(n_55),
.Y(n_84)
);

INVx1_ASAP7_75t_L g85 ( 
.A(n_67),
.Y(n_85)
);

INVx6_ASAP7_75t_L g86 ( 
.A(n_77),
.Y(n_86)
);

INVx2_ASAP7_75t_L g87 ( 
.A(n_65),
.Y(n_87)
);

BUFx2_ASAP7_75t_L g88 ( 
.A(n_66),
.Y(n_88)
);

INVxp67_ASAP7_75t_SL g89 ( 
.A(n_69),
.Y(n_89)
);

INVx11_ASAP7_75t_L g90 ( 
.A(n_72),
.Y(n_90)
);

INVx1_ASAP7_75t_L g91 ( 
.A(n_70),
.Y(n_91)
);

NOR3xp33_ASAP7_75t_SL g92 ( 
.A(n_70),
.B(n_57),
.C(n_44),
.Y(n_92)
);

BUFx6f_ASAP7_75t_L g93 ( 
.A(n_65),
.Y(n_93)
);

BUFx2_ASAP7_75t_L g94 ( 
.A(n_72),
.Y(n_94)
);

CKINVDCx8_ASAP7_75t_R g95 ( 
.A(n_77),
.Y(n_95)
);

BUFx12f_ASAP7_75t_L g96 ( 
.A(n_77),
.Y(n_96)
);

INVx6_ASAP7_75t_L g97 ( 
.A(n_77),
.Y(n_97)
);

INVx1_ASAP7_75t_L g98 ( 
.A(n_70),
.Y(n_98)
);

NAND2xp5_ASAP7_75t_L g99 ( 
.A(n_91),
.B(n_98),
.Y(n_99)
);

AOI22x1_ASAP7_75t_L g100 ( 
.A1(n_91),
.A2(n_71),
.B1(n_61),
.B2(n_65),
.Y(n_100)
);

OAI21xp33_ASAP7_75t_L g101 ( 
.A1(n_98),
.A2(n_64),
.B(n_71),
.Y(n_101)
);

INVx5_ASAP7_75t_L g102 ( 
.A(n_93),
.Y(n_102)
);

AOI22xp33_ASAP7_75t_L g103 ( 
.A1(n_80),
.A2(n_64),
.B1(n_61),
.B2(n_77),
.Y(n_103)
);

INVx2_ASAP7_75t_L g104 ( 
.A(n_87),
.Y(n_104)
);

OAI22xp33_ASAP7_75t_L g105 ( 
.A1(n_80),
.A2(n_61),
.B1(n_51),
.B2(n_50),
.Y(n_105)
);

INVx4_ASAP7_75t_L g106 ( 
.A(n_96),
.Y(n_106)
);

AND2x4_ASAP7_75t_L g107 ( 
.A(n_92),
.B(n_77),
.Y(n_107)
);

BUFx3_ASAP7_75t_L g108 ( 
.A(n_96),
.Y(n_108)
);

INVx1_ASAP7_75t_SL g109 ( 
.A(n_88),
.Y(n_109)
);

CKINVDCx6p67_ASAP7_75t_R g110 ( 
.A(n_96),
.Y(n_110)
);

INVx1_ASAP7_75t_L g111 ( 
.A(n_82),
.Y(n_111)
);

NAND2xp5_ASAP7_75t_SL g112 ( 
.A(n_93),
.B(n_75),
.Y(n_112)
);

INVx1_ASAP7_75t_L g113 ( 
.A(n_82),
.Y(n_113)
);

NAND2xp5_ASAP7_75t_SL g114 ( 
.A(n_93),
.B(n_75),
.Y(n_114)
);

NAND2xp5_ASAP7_75t_L g115 ( 
.A(n_103),
.B(n_79),
.Y(n_115)
);

AOI22xp5_ASAP7_75t_L g116 ( 
.A1(n_105),
.A2(n_97),
.B1(n_86),
.B2(n_88),
.Y(n_116)
);

OAI22xp33_ASAP7_75t_L g117 ( 
.A1(n_105),
.A2(n_94),
.B1(n_59),
.B2(n_95),
.Y(n_117)
);

OAI22xp5_ASAP7_75t_L g118 ( 
.A1(n_103),
.A2(n_95),
.B1(n_97),
.B2(n_86),
.Y(n_118)
);

INVx1_ASAP7_75t_L g119 ( 
.A(n_111),
.Y(n_119)
);

INVx1_ASAP7_75t_L g120 ( 
.A(n_111),
.Y(n_120)
);

NAND2xp5_ASAP7_75t_L g121 ( 
.A(n_101),
.B(n_94),
.Y(n_121)
);

CKINVDCx5p33_ASAP7_75t_R g122 ( 
.A(n_109),
.Y(n_122)
);

AND2x4_ASAP7_75t_L g123 ( 
.A(n_106),
.B(n_89),
.Y(n_123)
);

AOI221xp5_ASAP7_75t_L g124 ( 
.A1(n_109),
.A2(n_53),
.B1(n_51),
.B2(n_50),
.C(n_71),
.Y(n_124)
);

INVx1_ASAP7_75t_L g125 ( 
.A(n_113),
.Y(n_125)
);

AOI211xp5_ASAP7_75t_L g126 ( 
.A1(n_117),
.A2(n_101),
.B(n_46),
.C(n_74),
.Y(n_126)
);

INVx1_ASAP7_75t_L g127 ( 
.A(n_119),
.Y(n_127)
);

OAI211xp5_ASAP7_75t_L g128 ( 
.A1(n_124),
.A2(n_116),
.B(n_115),
.C(n_100),
.Y(n_128)
);

NAND2xp5_ASAP7_75t_L g129 ( 
.A(n_121),
.B(n_100),
.Y(n_129)
);

OR2x2_ASAP7_75t_L g130 ( 
.A(n_122),
.B(n_110),
.Y(n_130)
);

INVx3_ASAP7_75t_L g131 ( 
.A(n_119),
.Y(n_131)
);

NAND2xp5_ASAP7_75t_L g132 ( 
.A(n_123),
.B(n_100),
.Y(n_132)
);

NAND2xp5_ASAP7_75t_L g133 ( 
.A(n_123),
.B(n_107),
.Y(n_133)
);

AOI22xp33_ASAP7_75t_L g134 ( 
.A1(n_118),
.A2(n_107),
.B1(n_97),
.B2(n_86),
.Y(n_134)
);

OAI221xp5_ASAP7_75t_L g135 ( 
.A1(n_122),
.A2(n_108),
.B1(n_106),
.B2(n_86),
.C(n_97),
.Y(n_135)
);

OAI31xp33_ASAP7_75t_SL g136 ( 
.A1(n_128),
.A2(n_125),
.A3(n_120),
.B(n_113),
.Y(n_136)
);

INVx2_ASAP7_75t_L g137 ( 
.A(n_131),
.Y(n_137)
);

BUFx2_ASAP7_75t_L g138 ( 
.A(n_133),
.Y(n_138)
);

OAI211xp5_ASAP7_75t_L g139 ( 
.A1(n_126),
.A2(n_99),
.B(n_74),
.C(n_106),
.Y(n_139)
);

INVx1_ASAP7_75t_L g140 ( 
.A(n_127),
.Y(n_140)
);

AND2x2_ASAP7_75t_L g141 ( 
.A(n_131),
.B(n_107),
.Y(n_141)
);

HB1xp67_ASAP7_75t_L g142 ( 
.A(n_131),
.Y(n_142)
);

INVx1_ASAP7_75t_L g143 ( 
.A(n_127),
.Y(n_143)
);

AOI22xp33_ASAP7_75t_SL g144 ( 
.A1(n_126),
.A2(n_74),
.B1(n_108),
.B2(n_106),
.Y(n_144)
);

AOI22xp33_ASAP7_75t_L g145 ( 
.A1(n_129),
.A2(n_107),
.B1(n_106),
.B2(n_108),
.Y(n_145)
);

INVx4_ASAP7_75t_L g146 ( 
.A(n_130),
.Y(n_146)
);

AOI22xp33_ASAP7_75t_L g147 ( 
.A1(n_134),
.A2(n_107),
.B1(n_123),
.B2(n_108),
.Y(n_147)
);

AOI22xp33_ASAP7_75t_L g148 ( 
.A1(n_132),
.A2(n_99),
.B1(n_110),
.B2(n_86),
.Y(n_148)
);

INVxp67_ASAP7_75t_L g149 ( 
.A(n_130),
.Y(n_149)
);

NAND3xp33_ASAP7_75t_L g150 ( 
.A(n_135),
.B(n_85),
.C(n_81),
.Y(n_150)
);

AND2x2_ASAP7_75t_L g151 ( 
.A(n_131),
.B(n_104),
.Y(n_151)
);

NAND2xp5_ASAP7_75t_L g152 ( 
.A(n_128),
.B(n_85),
.Y(n_152)
);

NAND3xp33_ASAP7_75t_L g153 ( 
.A(n_136),
.B(n_47),
.C(n_76),
.Y(n_153)
);

NAND2x1p5_ASAP7_75t_L g154 ( 
.A(n_137),
.B(n_102),
.Y(n_154)
);

OR2x2_ASAP7_75t_L g155 ( 
.A(n_146),
.B(n_76),
.Y(n_155)
);

AND2x4_ASAP7_75t_L g156 ( 
.A(n_137),
.B(n_104),
.Y(n_156)
);

NAND2xp5_ASAP7_75t_L g157 ( 
.A(n_149),
.B(n_110),
.Y(n_157)
);

INVx2_ASAP7_75t_L g158 ( 
.A(n_137),
.Y(n_158)
);

OAI221xp5_ASAP7_75t_L g159 ( 
.A1(n_144),
.A2(n_97),
.B1(n_81),
.B2(n_90),
.C(n_83),
.Y(n_159)
);

INVx1_ASAP7_75t_L g160 ( 
.A(n_140),
.Y(n_160)
);

OR2x2_ASAP7_75t_L g161 ( 
.A(n_146),
.B(n_83),
.Y(n_161)
);

NOR2xp33_ASAP7_75t_L g162 ( 
.A(n_149),
.B(n_90),
.Y(n_162)
);

NOR2xp33_ASAP7_75t_L g163 ( 
.A(n_146),
.B(n_0),
.Y(n_163)
);

NAND3xp33_ASAP7_75t_L g164 ( 
.A(n_136),
.B(n_68),
.C(n_65),
.Y(n_164)
);

AND2x2_ASAP7_75t_L g165 ( 
.A(n_140),
.B(n_68),
.Y(n_165)
);

NAND4xp25_ASAP7_75t_L g166 ( 
.A(n_144),
.B(n_68),
.C(n_84),
.D(n_104),
.Y(n_166)
);

AND2x2_ASAP7_75t_L g167 ( 
.A(n_143),
.B(n_68),
.Y(n_167)
);

AND2x2_ASAP7_75t_L g168 ( 
.A(n_143),
.B(n_68),
.Y(n_168)
);

OAI31xp33_ASAP7_75t_L g169 ( 
.A1(n_139),
.A2(n_112),
.A3(n_114),
.B(n_104),
.Y(n_169)
);

NOR2xp33_ASAP7_75t_L g170 ( 
.A(n_146),
.B(n_1),
.Y(n_170)
);

NOR2xp33_ASAP7_75t_L g171 ( 
.A(n_146),
.B(n_139),
.Y(n_171)
);

HB1xp67_ASAP7_75t_L g172 ( 
.A(n_142),
.Y(n_172)
);

OAI221xp5_ASAP7_75t_L g173 ( 
.A1(n_147),
.A2(n_84),
.B1(n_112),
.B2(n_114),
.C(n_87),
.Y(n_173)
);

OR2x2_ASAP7_75t_L g174 ( 
.A(n_138),
.B(n_87),
.Y(n_174)
);

HB1xp67_ASAP7_75t_L g175 ( 
.A(n_142),
.Y(n_175)
);

OR2x2_ASAP7_75t_L g176 ( 
.A(n_138),
.B(n_73),
.Y(n_176)
);

INVx1_ASAP7_75t_L g177 ( 
.A(n_152),
.Y(n_177)
);

AND2x2_ASAP7_75t_L g178 ( 
.A(n_141),
.B(n_73),
.Y(n_178)
);

INVx1_ASAP7_75t_SL g179 ( 
.A(n_141),
.Y(n_179)
);

BUFx2_ASAP7_75t_L g180 ( 
.A(n_141),
.Y(n_180)
);

NAND2xp5_ASAP7_75t_L g181 ( 
.A(n_177),
.B(n_152),
.Y(n_181)
);

INVx1_ASAP7_75t_L g182 ( 
.A(n_160),
.Y(n_182)
);

AND2x4_ASAP7_75t_L g183 ( 
.A(n_160),
.B(n_151),
.Y(n_183)
);

INVx1_ASAP7_75t_L g184 ( 
.A(n_177),
.Y(n_184)
);

NAND2xp5_ASAP7_75t_L g185 ( 
.A(n_172),
.B(n_151),
.Y(n_185)
);

AOI22xp33_ASAP7_75t_L g186 ( 
.A1(n_171),
.A2(n_145),
.B1(n_148),
.B2(n_150),
.Y(n_186)
);

INVx1_ASAP7_75t_L g187 ( 
.A(n_158),
.Y(n_187)
);

NAND2xp5_ASAP7_75t_L g188 ( 
.A(n_175),
.B(n_151),
.Y(n_188)
);

INVx1_ASAP7_75t_L g189 ( 
.A(n_158),
.Y(n_189)
);

INVx1_ASAP7_75t_L g190 ( 
.A(n_180),
.Y(n_190)
);

AOI22xp5_ASAP7_75t_L g191 ( 
.A1(n_162),
.A2(n_145),
.B1(n_148),
.B2(n_150),
.Y(n_191)
);

OR2x2_ASAP7_75t_L g192 ( 
.A(n_180),
.B(n_73),
.Y(n_192)
);

INVx1_ASAP7_75t_L g193 ( 
.A(n_165),
.Y(n_193)
);

AND2x2_ASAP7_75t_L g194 ( 
.A(n_179),
.B(n_2),
.Y(n_194)
);

HB1xp67_ASAP7_75t_L g195 ( 
.A(n_155),
.Y(n_195)
);

NOR2xp33_ASAP7_75t_R g196 ( 
.A(n_157),
.B(n_21),
.Y(n_196)
);

INVx2_ASAP7_75t_L g197 ( 
.A(n_167),
.Y(n_197)
);

OR2x2_ASAP7_75t_L g198 ( 
.A(n_155),
.B(n_73),
.Y(n_198)
);

NAND3xp33_ASAP7_75t_SL g199 ( 
.A(n_163),
.B(n_170),
.C(n_153),
.Y(n_199)
);

INVx1_ASAP7_75t_SL g200 ( 
.A(n_174),
.Y(n_200)
);

NAND3xp33_ASAP7_75t_L g201 ( 
.A(n_153),
.B(n_69),
.C(n_93),
.Y(n_201)
);

NAND2xp5_ASAP7_75t_SL g202 ( 
.A(n_161),
.B(n_93),
.Y(n_202)
);

INVx1_ASAP7_75t_L g203 ( 
.A(n_165),
.Y(n_203)
);

AND2x2_ASAP7_75t_L g204 ( 
.A(n_178),
.B(n_168),
.Y(n_204)
);

AOI21xp5_ASAP7_75t_L g205 ( 
.A1(n_166),
.A2(n_102),
.B(n_75),
.Y(n_205)
);

OR2x2_ASAP7_75t_L g206 ( 
.A(n_176),
.B(n_69),
.Y(n_206)
);

AND2x2_ASAP7_75t_L g207 ( 
.A(n_178),
.B(n_168),
.Y(n_207)
);

NOR4xp25_ASAP7_75t_SL g208 ( 
.A(n_159),
.B(n_5),
.C(n_4),
.D(n_3),
.Y(n_208)
);

HB1xp67_ASAP7_75t_L g209 ( 
.A(n_161),
.Y(n_209)
);

NAND2xp5_ASAP7_75t_L g210 ( 
.A(n_167),
.B(n_3),
.Y(n_210)
);

INVx1_ASAP7_75t_L g211 ( 
.A(n_174),
.Y(n_211)
);

INVx1_ASAP7_75t_L g212 ( 
.A(n_176),
.Y(n_212)
);

INVx1_ASAP7_75t_L g213 ( 
.A(n_156),
.Y(n_213)
);

OR2x6_ASAP7_75t_L g214 ( 
.A(n_156),
.B(n_93),
.Y(n_214)
);

AND2x2_ASAP7_75t_L g215 ( 
.A(n_156),
.B(n_5),
.Y(n_215)
);

NOR2xp33_ASAP7_75t_R g216 ( 
.A(n_156),
.B(n_23),
.Y(n_216)
);

INVx1_ASAP7_75t_L g217 ( 
.A(n_164),
.Y(n_217)
);

NAND2xp5_ASAP7_75t_L g218 ( 
.A(n_195),
.B(n_169),
.Y(n_218)
);

INVx1_ASAP7_75t_L g219 ( 
.A(n_182),
.Y(n_219)
);

NAND2xp5_ASAP7_75t_L g220 ( 
.A(n_207),
.B(n_164),
.Y(n_220)
);

INVx2_ASAP7_75t_L g221 ( 
.A(n_182),
.Y(n_221)
);

OAI22xp5_ASAP7_75t_L g222 ( 
.A1(n_186),
.A2(n_154),
.B1(n_173),
.B2(n_102),
.Y(n_222)
);

INVx2_ASAP7_75t_SL g223 ( 
.A(n_183),
.Y(n_223)
);

AND2x2_ASAP7_75t_L g224 ( 
.A(n_207),
.B(n_154),
.Y(n_224)
);

AND2x2_ASAP7_75t_L g225 ( 
.A(n_204),
.B(n_184),
.Y(n_225)
);

AND2x2_ASAP7_75t_L g226 ( 
.A(n_204),
.B(n_154),
.Y(n_226)
);

OAI22x1_ASAP7_75t_L g227 ( 
.A1(n_191),
.A2(n_9),
.B1(n_8),
.B2(n_7),
.Y(n_227)
);

AOI221xp5_ASAP7_75t_L g228 ( 
.A1(n_199),
.A2(n_8),
.B1(n_7),
.B2(n_9),
.C(n_10),
.Y(n_228)
);

AO22x1_ASAP7_75t_L g229 ( 
.A1(n_194),
.A2(n_12),
.B1(n_11),
.B2(n_10),
.Y(n_229)
);

AOI222xp33_ASAP7_75t_L g230 ( 
.A1(n_217),
.A2(n_12),
.B1(n_11),
.B2(n_13),
.C1(n_15),
.C2(n_14),
.Y(n_230)
);

INVx1_ASAP7_75t_L g231 ( 
.A(n_184),
.Y(n_231)
);

NAND2xp5_ASAP7_75t_L g232 ( 
.A(n_200),
.B(n_17),
.Y(n_232)
);

NAND2xp5_ASAP7_75t_L g233 ( 
.A(n_193),
.B(n_17),
.Y(n_233)
);

INVx1_ASAP7_75t_SL g234 ( 
.A(n_194),
.Y(n_234)
);

INVx1_ASAP7_75t_L g235 ( 
.A(n_190),
.Y(n_235)
);

INVx1_ASAP7_75t_L g236 ( 
.A(n_187),
.Y(n_236)
);

OR2x2_ASAP7_75t_L g237 ( 
.A(n_209),
.B(n_18),
.Y(n_237)
);

AND3x2_ASAP7_75t_L g238 ( 
.A(n_215),
.B(n_19),
.C(n_18),
.Y(n_238)
);

OR2x2_ASAP7_75t_L g239 ( 
.A(n_197),
.B(n_19),
.Y(n_239)
);

INVx1_ASAP7_75t_L g240 ( 
.A(n_187),
.Y(n_240)
);

INVx1_ASAP7_75t_L g241 ( 
.A(n_189),
.Y(n_241)
);

AOI22xp5_ASAP7_75t_L g242 ( 
.A1(n_203),
.A2(n_69),
.B1(n_62),
.B2(n_102),
.Y(n_242)
);

NAND2xp5_ASAP7_75t_L g243 ( 
.A(n_212),
.B(n_20),
.Y(n_243)
);

INVx1_ASAP7_75t_L g244 ( 
.A(n_211),
.Y(n_244)
);

OAI22xp33_ASAP7_75t_L g245 ( 
.A1(n_201),
.A2(n_20),
.B1(n_62),
.B2(n_75),
.Y(n_245)
);

OR2x2_ASAP7_75t_L g246 ( 
.A(n_197),
.B(n_62),
.Y(n_246)
);

INVx2_ASAP7_75t_L g247 ( 
.A(n_183),
.Y(n_247)
);

NOR2xp33_ASAP7_75t_L g248 ( 
.A(n_210),
.B(n_25),
.Y(n_248)
);

INVx1_ASAP7_75t_L g249 ( 
.A(n_185),
.Y(n_249)
);

NAND3xp33_ASAP7_75t_L g250 ( 
.A(n_208),
.B(n_181),
.C(n_206),
.Y(n_250)
);

AOI22xp5_ASAP7_75t_L g251 ( 
.A1(n_215),
.A2(n_102),
.B1(n_78),
.B2(n_27),
.Y(n_251)
);

AND2x2_ASAP7_75t_L g252 ( 
.A(n_183),
.B(n_213),
.Y(n_252)
);

AOI21xp5_ASAP7_75t_L g253 ( 
.A1(n_205),
.A2(n_102),
.B(n_78),
.Y(n_253)
);

INVx1_ASAP7_75t_L g254 ( 
.A(n_188),
.Y(n_254)
);

OAI22xp5_ASAP7_75t_L g255 ( 
.A1(n_214),
.A2(n_102),
.B1(n_78),
.B2(n_28),
.Y(n_255)
);

NOR3xp33_ASAP7_75t_SL g256 ( 
.A(n_250),
.B(n_202),
.C(n_196),
.Y(n_256)
);

NOR4xp25_ASAP7_75t_SL g257 ( 
.A(n_228),
.B(n_202),
.C(n_216),
.D(n_192),
.Y(n_257)
);

NAND2xp5_ASAP7_75t_L g258 ( 
.A(n_249),
.B(n_198),
.Y(n_258)
);

AND2x2_ASAP7_75t_L g259 ( 
.A(n_225),
.B(n_214),
.Y(n_259)
);

NAND2xp5_ASAP7_75t_L g260 ( 
.A(n_254),
.B(n_198),
.Y(n_260)
);

AND2x2_ASAP7_75t_L g261 ( 
.A(n_225),
.B(n_214),
.Y(n_261)
);

OAI21xp5_ASAP7_75t_SL g262 ( 
.A1(n_230),
.A2(n_206),
.B(n_192),
.Y(n_262)
);

AOI21xp5_ASAP7_75t_L g263 ( 
.A1(n_245),
.A2(n_214),
.B(n_102),
.Y(n_263)
);

INVx4_ASAP7_75t_L g264 ( 
.A(n_238),
.Y(n_264)
);

CKINVDCx20_ASAP7_75t_L g265 ( 
.A(n_238),
.Y(n_265)
);

INVx1_ASAP7_75t_L g266 ( 
.A(n_219),
.Y(n_266)
);

NOR2xp33_ASAP7_75t_L g267 ( 
.A(n_234),
.B(n_30),
.Y(n_267)
);

NAND2xp5_ASAP7_75t_L g268 ( 
.A(n_235),
.B(n_31),
.Y(n_268)
);

NAND2xp5_ASAP7_75t_SL g269 ( 
.A(n_218),
.B(n_102),
.Y(n_269)
);

NAND3xp33_ASAP7_75t_L g270 ( 
.A(n_248),
.B(n_78),
.C(n_32),
.Y(n_270)
);

AND2x2_ASAP7_75t_L g271 ( 
.A(n_247),
.B(n_33),
.Y(n_271)
);

AOI22xp5_ASAP7_75t_L g272 ( 
.A1(n_227),
.A2(n_78),
.B1(n_35),
.B2(n_34),
.Y(n_272)
);

INVx1_ASAP7_75t_L g273 ( 
.A(n_221),
.Y(n_273)
);

INVxp67_ASAP7_75t_L g274 ( 
.A(n_232),
.Y(n_274)
);

OR2x2_ASAP7_75t_L g275 ( 
.A(n_247),
.B(n_36),
.Y(n_275)
);

NOR2xp33_ASAP7_75t_R g276 ( 
.A(n_220),
.B(n_223),
.Y(n_276)
);

INVx1_ASAP7_75t_L g277 ( 
.A(n_231),
.Y(n_277)
);

INVx2_ASAP7_75t_L g278 ( 
.A(n_236),
.Y(n_278)
);

NOR2xp33_ASAP7_75t_R g279 ( 
.A(n_223),
.B(n_37),
.Y(n_279)
);

XNOR2xp5_ASAP7_75t_L g280 ( 
.A(n_229),
.B(n_78),
.Y(n_280)
);

INVxp67_ASAP7_75t_SL g281 ( 
.A(n_240),
.Y(n_281)
);

NAND2xp5_ASAP7_75t_L g282 ( 
.A(n_244),
.B(n_78),
.Y(n_282)
);

INVx1_ASAP7_75t_L g283 ( 
.A(n_266),
.Y(n_283)
);

INVx1_ASAP7_75t_L g284 ( 
.A(n_277),
.Y(n_284)
);

NAND2xp5_ASAP7_75t_SL g285 ( 
.A(n_264),
.B(n_239),
.Y(n_285)
);

INVx1_ASAP7_75t_L g286 ( 
.A(n_278),
.Y(n_286)
);

OAI211xp5_ASAP7_75t_L g287 ( 
.A1(n_264),
.A2(n_257),
.B(n_272),
.C(n_263),
.Y(n_287)
);

XOR2xp5_ASAP7_75t_L g288 ( 
.A(n_275),
.B(n_237),
.Y(n_288)
);

XOR2x2_ASAP7_75t_L g289 ( 
.A(n_264),
.B(n_248),
.Y(n_289)
);

INVx2_ASAP7_75t_SL g290 ( 
.A(n_261),
.Y(n_290)
);

AOI31xp33_ASAP7_75t_SL g291 ( 
.A1(n_265),
.A2(n_233),
.A3(n_243),
.B(n_227),
.Y(n_291)
);

NAND3x1_ASAP7_75t_SL g292 ( 
.A(n_265),
.B(n_226),
.C(n_224),
.Y(n_292)
);

AOI21xp5_ASAP7_75t_L g293 ( 
.A1(n_269),
.A2(n_253),
.B(n_245),
.Y(n_293)
);

OAI31xp33_ASAP7_75t_L g294 ( 
.A1(n_270),
.A2(n_222),
.A3(n_255),
.B(n_224),
.Y(n_294)
);

NAND2xp5_ASAP7_75t_L g295 ( 
.A(n_282),
.B(n_241),
.Y(n_295)
);

INVx1_ASAP7_75t_SL g296 ( 
.A(n_276),
.Y(n_296)
);

NAND2xp5_ASAP7_75t_L g297 ( 
.A(n_258),
.B(n_226),
.Y(n_297)
);

OAI21xp5_ASAP7_75t_L g298 ( 
.A1(n_256),
.A2(n_251),
.B(n_252),
.Y(n_298)
);

AOI22xp5_ASAP7_75t_L g299 ( 
.A1(n_269),
.A2(n_242),
.B1(n_246),
.B2(n_262),
.Y(n_299)
);

NAND3xp33_ASAP7_75t_L g300 ( 
.A(n_287),
.B(n_274),
.C(n_260),
.Y(n_300)
);

NAND2xp5_ASAP7_75t_L g301 ( 
.A(n_283),
.B(n_281),
.Y(n_301)
);

INVx1_ASAP7_75t_SL g302 ( 
.A(n_296),
.Y(n_302)
);

NOR2xp33_ASAP7_75t_R g303 ( 
.A(n_291),
.B(n_280),
.Y(n_303)
);

AOI22xp33_ASAP7_75t_L g304 ( 
.A1(n_289),
.A2(n_276),
.B1(n_267),
.B2(n_279),
.Y(n_304)
);

NOR2x1_ASAP7_75t_L g305 ( 
.A(n_287),
.B(n_273),
.Y(n_305)
);

AOI22xp5_ASAP7_75t_L g306 ( 
.A1(n_299),
.A2(n_261),
.B1(n_259),
.B2(n_268),
.Y(n_306)
);

INVx2_ASAP7_75t_L g307 ( 
.A(n_286),
.Y(n_307)
);

NAND4xp75_ASAP7_75t_L g308 ( 
.A(n_298),
.B(n_285),
.C(n_294),
.D(n_293),
.Y(n_308)
);

A2O1A1Ixp33_ASAP7_75t_L g309 ( 
.A1(n_305),
.A2(n_293),
.B(n_295),
.C(n_284),
.Y(n_309)
);

XNOR2xp5_ASAP7_75t_L g310 ( 
.A(n_308),
.B(n_288),
.Y(n_310)
);

NAND5xp2_ASAP7_75t_L g311 ( 
.A(n_304),
.B(n_292),
.C(n_259),
.D(n_271),
.E(n_297),
.Y(n_311)
);

NAND4xp25_ASAP7_75t_L g312 ( 
.A(n_300),
.B(n_302),
.C(n_306),
.D(n_301),
.Y(n_312)
);

AOI21xp33_ASAP7_75t_SL g313 ( 
.A1(n_303),
.A2(n_290),
.B(n_292),
.Y(n_313)
);

CKINVDCx20_ASAP7_75t_R g314 ( 
.A(n_310),
.Y(n_314)
);

INVx1_ASAP7_75t_SL g315 ( 
.A(n_312),
.Y(n_315)
);

AND2x4_ASAP7_75t_L g316 ( 
.A(n_309),
.B(n_301),
.Y(n_316)
);

NAND4xp25_ASAP7_75t_L g317 ( 
.A(n_315),
.B(n_311),
.C(n_313),
.D(n_307),
.Y(n_317)
);

INVx1_ASAP7_75t_L g318 ( 
.A(n_317),
.Y(n_318)
);

INVx1_ASAP7_75t_L g319 ( 
.A(n_318),
.Y(n_319)
);

AOI22xp33_ASAP7_75t_L g320 ( 
.A1(n_319),
.A2(n_316),
.B1(n_314),
.B2(n_279),
.Y(n_320)
);

AOI21xp5_ASAP7_75t_L g321 ( 
.A1(n_320),
.A2(n_316),
.B(n_271),
.Y(n_321)
);


endmodule