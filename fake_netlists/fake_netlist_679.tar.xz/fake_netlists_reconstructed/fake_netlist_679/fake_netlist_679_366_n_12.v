module fake_netlist_679_366_n_12 (n_3, n_0, n_2, n_1, n_12);

input n_3;
input n_0;
input n_2;
input n_1;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

AOI22xp33_ASAP7_75t_L g4 ( 
.A1(n_1),
.A2(n_2),
.B1(n_0),
.B2(n_3),
.Y(n_4)
);

AOI22xp33_ASAP7_75t_L g5 ( 
.A1(n_0),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_5)
);

OA21x2_ASAP7_75t_L g6 ( 
.A1(n_5),
.A2(n_1),
.B(n_4),
.Y(n_6)
);

AND2x4_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NAND4xp25_ASAP7_75t_L g10 ( 
.A(n_9),
.B(n_6),
.C(n_7),
.D(n_4),
.Y(n_10)
);

NAND2xp5_ASAP7_75t_L g11 ( 
.A(n_10),
.B(n_7),
.Y(n_11)
);

AOI22xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_6),
.B1(n_7),
.B2(n_8),
.Y(n_12)
);


endmodule