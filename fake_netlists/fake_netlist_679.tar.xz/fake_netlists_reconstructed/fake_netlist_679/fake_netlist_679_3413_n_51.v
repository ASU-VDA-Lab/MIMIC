module fake_netlist_679_3413_n_51 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_51);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_51;

wire n_24;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_21;
wire n_27;
wire n_40;
wire n_42;
wire n_22;
wire n_18;
wire n_47;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_43;
wire n_37;
wire n_23;
wire n_31;
wire n_46;
wire n_41;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_49;
wire n_19;
wire n_39;

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_0),
.B(n_9),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_6),
.Y(n_19)
);

BUFx6f_ASAP7_75t_L g20 ( 
.A(n_4),
.Y(n_20)
);

OAI22xp5_ASAP7_75t_L g21 ( 
.A1(n_5),
.A2(n_15),
.B1(n_4),
.B2(n_2),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_1),
.Y(n_22)
);

INVx2_ASAP7_75t_SL g23 ( 
.A(n_14),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_16),
.Y(n_24)
);

INVx3_ASAP7_75t_L g25 ( 
.A(n_11),
.Y(n_25)
);

NOR2x1p5_ASAP7_75t_L g26 ( 
.A(n_22),
.B(n_1),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_23),
.B(n_5),
.Y(n_27)
);

AND2x4_ASAP7_75t_L g28 ( 
.A(n_20),
.B(n_16),
.Y(n_28)
);

INVx4_ASAP7_75t_L g29 ( 
.A(n_25),
.Y(n_29)
);

OAI21x1_ASAP7_75t_L g30 ( 
.A1(n_27),
.A2(n_25),
.B(n_18),
.Y(n_30)
);

INVx3_ASAP7_75t_L g31 ( 
.A(n_28),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_L g32 ( 
.A1(n_27),
.A2(n_24),
.B1(n_20),
.B2(n_21),
.Y(n_32)
);

BUFx3_ASAP7_75t_L g33 ( 
.A(n_30),
.Y(n_33)
);

AND2x2_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_29),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_31),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

INVx1_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_35),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_SL g39 ( 
.A(n_36),
.B(n_32),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

INVx1_ASAP7_75t_L g41 ( 
.A(n_38),
.Y(n_41)
);

INVxp67_ASAP7_75t_L g42 ( 
.A(n_39),
.Y(n_42)
);

NAND2xp5_ASAP7_75t_L g43 ( 
.A(n_42),
.B(n_38),
.Y(n_43)
);

OAI222xp33_ASAP7_75t_L g44 ( 
.A1(n_40),
.A2(n_23),
.B1(n_28),
.B2(n_19),
.C1(n_25),
.C2(n_29),
.Y(n_44)
);

NOR3xp33_ASAP7_75t_SL g45 ( 
.A(n_41),
.B(n_26),
.C(n_17),
.Y(n_45)
);

AO21x2_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_33),
.B(n_20),
.Y(n_46)
);

INVx1_ASAP7_75t_L g47 ( 
.A(n_43),
.Y(n_47)
);

AOI21xp5_ASAP7_75t_SL g48 ( 
.A1(n_45),
.A2(n_33),
.B(n_20),
.Y(n_48)
);

AOI21xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_17),
.B(n_3),
.Y(n_49)
);

AOI22xp5_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_10),
.B1(n_8),
.B2(n_7),
.Y(n_50)
);

AOI322xp5_ASAP7_75t_L g51 ( 
.A1(n_50),
.A2(n_12),
.A3(n_13),
.B1(n_46),
.B2(n_48),
.C1(n_49),
.C2(n_45),
.Y(n_51)
);


endmodule