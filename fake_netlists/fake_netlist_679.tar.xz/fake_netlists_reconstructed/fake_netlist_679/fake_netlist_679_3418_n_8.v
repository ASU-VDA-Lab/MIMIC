module fake_netlist_679_3418_n_8 (n_4, n_2, n_3, n_1, n_5, n_0, n_8);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_8;

wire n_7;
wire n_6;

OR2x2_ASAP7_75t_L g6 ( 
.A(n_2),
.B(n_1),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_3),
.B(n_0),
.Y(n_7)
);

NOR4xp25_ASAP7_75t_L g8 ( 
.A(n_6),
.B(n_7),
.C(n_5),
.D(n_4),
.Y(n_8)
);


endmodule