module fake_netlist_679_2681_n_38 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_38);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_38;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_37;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

INVx1_ASAP7_75t_L g17 ( 
.A(n_6),
.Y(n_17)
);

NOR2xp67_ASAP7_75t_L g18 ( 
.A(n_14),
.B(n_5),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_15),
.Y(n_23)
);

AOI22xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_16),
.B1(n_15),
.B2(n_0),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_21),
.Y(n_25)
);

INVx5_ASAP7_75t_L g26 ( 
.A(n_22),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_23),
.Y(n_27)
);

OAI22xp5_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_19),
.B1(n_17),
.B2(n_20),
.Y(n_28)
);

BUFx6f_ASAP7_75t_L g29 ( 
.A(n_27),
.Y(n_29)
);

HB1xp67_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_30),
.Y(n_31)
);

AOI321xp33_ASAP7_75t_R g32 ( 
.A1(n_30),
.A2(n_24),
.A3(n_28),
.B1(n_18),
.B2(n_29),
.C(n_1),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_31),
.Y(n_33)
);

NOR2xp33_ASAP7_75t_R g34 ( 
.A(n_32),
.B(n_3),
.Y(n_34)
);

XNOR2xp5_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_4),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_34),
.Y(n_36)
);

BUFx2_ASAP7_75t_L g37 ( 
.A(n_36),
.Y(n_37)
);

AOI322xp5_ASAP7_75t_L g38 ( 
.A1(n_37),
.A2(n_35),
.A3(n_10),
.B1(n_8),
.B2(n_7),
.C1(n_12),
.C2(n_11),
.Y(n_38)
);


endmodule