module fake_netlist_679_2553_n_18 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_5, n_0, n_6, n_18);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_5;
input n_0;
input n_6;

output n_18;

wire n_17;
wire n_15;
wire n_11;
wire n_16;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

BUFx10_ASAP7_75t_L g10 ( 
.A(n_9),
.Y(n_10)
);

OAI22xp33_ASAP7_75t_L g11 ( 
.A1(n_5),
.A2(n_6),
.B1(n_1),
.B2(n_7),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_3),
.B(n_7),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

AOI221x1_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_12),
.B1(n_11),
.B2(n_4),
.C(n_6),
.Y(n_16)
);

INVx2_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AOI221xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_4),
.B1(n_8),
.B2(n_0),
.C(n_2),
.Y(n_18)
);


endmodule