module fake_netlist_679_4923_n_18 (n_4, n_2, n_3, n_1, n_0, n_18);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_18;

wire n_9;
wire n_17;
wire n_7;
wire n_15;
wire n_14;
wire n_11;
wire n_16;
wire n_8;
wire n_10;
wire n_13;
wire n_5;
wire n_6;
wire n_12;

BUFx2_ASAP7_75t_L g5 ( 
.A(n_0),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_0),
.B(n_3),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_5),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AND2x2_ASAP7_75t_L g10 ( 
.A(n_8),
.B(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

NAND2xp33_ASAP7_75t_SL g12 ( 
.A(n_10),
.B(n_9),
.Y(n_12)
);

OAI21xp33_ASAP7_75t_SL g13 ( 
.A1(n_10),
.A2(n_7),
.B(n_11),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_L g14 ( 
.A1(n_13),
.A2(n_11),
.B(n_1),
.C(n_2),
.Y(n_14)
);

O2A1O1Ixp33_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_1),
.B(n_4),
.C(n_2),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_14),
.Y(n_17)
);

AOI22xp33_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_1),
.B1(n_4),
.B2(n_17),
.Y(n_18)
);


endmodule