module fake_netlist_679_3392_n_30 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_30);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_30;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_29;
wire n_28;
wire n_25;
wire n_19;
wire n_14;

AND2x2_ASAP7_75t_L g14 ( 
.A(n_7),
.B(n_9),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_11),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_8),
.B(n_0),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_1),
.B(n_10),
.Y(n_17)
);

AND2x2_ASAP7_75t_L g18 ( 
.A(n_7),
.B(n_3),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_2),
.Y(n_19)
);

BUFx3_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_15),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_18),
.B1(n_14),
.B2(n_15),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

NAND3xp33_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_21),
.C(n_16),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

NAND2x1_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_17),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI322xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_23),
.A3(n_6),
.B1(n_5),
.B2(n_4),
.C1(n_13),
.C2(n_12),
.Y(n_30)
);


endmodule