module fake_netlist_679_97_n_30 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_30);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_30;

wire n_24;
wire n_21;
wire n_27;
wire n_22;
wire n_18;
wire n_20;
wire n_26;
wire n_23;
wire n_29;
wire n_28;
wire n_25;
wire n_19;

INVx1_ASAP7_75t_L g18 ( 
.A(n_6),
.Y(n_18)
);

BUFx6f_ASAP7_75t_L g19 ( 
.A(n_10),
.Y(n_19)
);

CKINVDCx5p33_ASAP7_75t_R g20 ( 
.A(n_11),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_8),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

OAI22xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_21),
.B1(n_20),
.B2(n_19),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_15),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_24)
);

AND2x2_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_3),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_25),
.Y(n_26)
);

AOI22xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_7),
.B1(n_5),
.B2(n_4),
.Y(n_27)
);

OR2x2_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_9),
.Y(n_28)
);

HB1xp67_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

AOI222xp33_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_13),
.B1(n_12),
.B2(n_14),
.C1(n_17),
.C2(n_16),
.Y(n_30)
);


endmodule