module fake_netlist_679_3315_n_37 (n_9, n_17, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_37);

input n_9;
input n_17;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_37;

wire n_24;
wire n_21;
wire n_27;
wire n_22;
wire n_18;
wire n_20;
wire n_35;
wire n_34;
wire n_26;
wire n_23;
wire n_31;
wire n_29;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

INVx2_ASAP7_75t_L g18 ( 
.A(n_2),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_0),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_7),
.B(n_8),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_12),
.B(n_14),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

NAND2x1p5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_4),
.Y(n_24)
);

INVx4_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

BUFx4f_ASAP7_75t_L g26 ( 
.A(n_24),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_25),
.B(n_18),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_27),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

CKINVDCx5p33_ASAP7_75t_R g30 ( 
.A(n_29),
.Y(n_30)
);

INVx1_ASAP7_75t_L g31 ( 
.A(n_29),
.Y(n_31)
);

AOI322xp5_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_23),
.A3(n_21),
.B1(n_20),
.B2(n_26),
.C1(n_25),
.C2(n_5),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_10),
.B1(n_9),
.B2(n_6),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_11),
.Y(n_34)
);

NAND3xp33_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_15),
.C(n_13),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_35),
.B1(n_17),
.B2(n_16),
.Y(n_37)
);


endmodule