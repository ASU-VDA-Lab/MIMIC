module fake_netlist_679_5007_n_60 (n_24, n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_23, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_60);

input n_24;
input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_23;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_60;

wire n_54;
wire n_50;
wire n_44;
wire n_45;
wire n_38;
wire n_27;
wire n_40;
wire n_42;
wire n_47;
wire n_58;
wire n_35;
wire n_34;
wire n_52;
wire n_26;
wire n_43;
wire n_37;
wire n_51;
wire n_31;
wire n_41;
wire n_46;
wire n_29;
wire n_56;
wire n_53;
wire n_33;
wire n_36;
wire n_32;
wire n_28;
wire n_30;
wire n_25;
wire n_48;
wire n_59;
wire n_49;
wire n_57;
wire n_39;
wire n_55;

OAI22xp33_ASAP7_75t_SL g25 ( 
.A1(n_16),
.A2(n_1),
.B1(n_11),
.B2(n_17),
.Y(n_25)
);

INVx3_ASAP7_75t_L g26 ( 
.A(n_15),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_7),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_8),
.Y(n_28)
);

INVx2_ASAP7_75t_L g29 ( 
.A(n_12),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_23),
.Y(n_30)
);

INVx2_ASAP7_75t_L g31 ( 
.A(n_0),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_21),
.Y(n_32)
);

CKINVDCx11_ASAP7_75t_R g33 ( 
.A(n_5),
.Y(n_33)
);

HB1xp67_ASAP7_75t_L g34 ( 
.A(n_4),
.Y(n_34)
);

NOR2xp33_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_16),
.Y(n_35)
);

NAND2xp5_ASAP7_75t_L g36 ( 
.A(n_34),
.B(n_17),
.Y(n_36)
);

INVx2_ASAP7_75t_L g37 ( 
.A(n_30),
.Y(n_37)
);

OAI22xp5_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_21),
.B1(n_20),
.B2(n_18),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_28),
.Y(n_39)
);

AOI21xp5_ASAP7_75t_L g40 ( 
.A1(n_36),
.A2(n_31),
.B(n_27),
.Y(n_40)
);

AOI21xp5_ASAP7_75t_L g41 ( 
.A1(n_35),
.A2(n_31),
.B(n_29),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_39),
.B(n_33),
.Y(n_42)
);

AND2x2_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_40),
.Y(n_43)
);

INVx2_ASAP7_75t_L g44 ( 
.A(n_39),
.Y(n_44)
);

NAND2x1_ASAP7_75t_SL g45 ( 
.A(n_42),
.B(n_26),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_44),
.B(n_25),
.Y(n_46)
);

OAI211xp5_ASAP7_75t_L g47 ( 
.A1(n_46),
.A2(n_38),
.B(n_44),
.C(n_33),
.Y(n_47)
);

OAI21xp5_ASAP7_75t_L g48 ( 
.A1(n_45),
.A2(n_43),
.B(n_26),
.Y(n_48)
);

OAI21xp5_ASAP7_75t_SL g49 ( 
.A1(n_47),
.A2(n_20),
.B(n_18),
.Y(n_49)
);

OAI21xp33_ASAP7_75t_L g50 ( 
.A1(n_48),
.A2(n_23),
.B(n_22),
.Y(n_50)
);

AOI222xp33_ASAP7_75t_L g51 ( 
.A1(n_47),
.A2(n_24),
.B1(n_22),
.B2(n_6),
.C1(n_3),
.C2(n_2),
.Y(n_51)
);

NAND2xp5_ASAP7_75t_L g52 ( 
.A(n_49),
.B(n_50),
.Y(n_52)
);

A2O1A1Ixp33_ASAP7_75t_L g53 ( 
.A1(n_51),
.A2(n_24),
.B(n_10),
.C(n_9),
.Y(n_53)
);

NAND3xp33_ASAP7_75t_L g54 ( 
.A(n_51),
.B(n_14),
.C(n_13),
.Y(n_54)
);

BUFx3_ASAP7_75t_L g55 ( 
.A(n_52),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_53),
.Y(n_56)
);

AND2x2_ASAP7_75t_L g57 ( 
.A(n_54),
.B(n_19),
.Y(n_57)
);

NOR2xp33_ASAP7_75t_SL g58 ( 
.A(n_57),
.B(n_55),
.Y(n_58)
);

AOI22xp5_ASAP7_75t_L g59 ( 
.A1(n_58),
.A2(n_56),
.B1(n_57),
.B2(n_55),
.Y(n_59)
);

OR2x6_ASAP7_75t_L g60 ( 
.A(n_59),
.B(n_55),
.Y(n_60)
);


endmodule