module fake_netlist_679_1852_n_5 (n_0, n_2, n_1, n_5);

input n_0;
input n_2;
input n_1;

output n_5;

wire n_4;
wire n_3;

INVx2_ASAP7_75t_L g3 ( 
.A(n_2),
.Y(n_3)
);

AO21x2_ASAP7_75t_L g4 ( 
.A1(n_2),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

NOR3xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_1),
.C(n_4),
.Y(n_5)
);


endmodule