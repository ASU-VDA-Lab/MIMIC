module fake_netlist_679_4132_n_10 (n_3, n_0, n_2, n_1, n_10);

input n_3;
input n_0;
input n_2;
input n_1;

output n_10;

wire n_9;
wire n_4;
wire n_7;
wire n_8;
wire n_5;
wire n_6;

NAND2xp5_ASAP7_75t_L g4 ( 
.A(n_0),
.B(n_2),
.Y(n_4)
);

NAND2xp33_ASAP7_75t_SL g5 ( 
.A(n_1),
.B(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

NOR4xp25_ASAP7_75t_SL g8 ( 
.A(n_7),
.B(n_5),
.C(n_1),
.D(n_0),
.Y(n_8)
);

AOI22xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_1),
.B1(n_0),
.B2(n_3),
.Y(n_9)
);

AOI21xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_8),
.B(n_3),
.Y(n_10)
);


endmodule