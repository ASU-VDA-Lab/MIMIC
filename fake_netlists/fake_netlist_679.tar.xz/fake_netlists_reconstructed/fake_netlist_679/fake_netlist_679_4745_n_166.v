module fake_netlist_679_4745_n_166 (n_2, n_21, n_17, n_6, n_9, n_22, n_18, n_15, n_20, n_16, n_1, n_5, n_7, n_8, n_0, n_4, n_3, n_11, n_19, n_10, n_13, n_14, n_12, n_166);

input n_2;
input n_21;
input n_17;
input n_6;
input n_9;
input n_22;
input n_18;
input n_15;
input n_20;
input n_16;
input n_1;
input n_5;
input n_7;
input n_8;
input n_0;
input n_4;
input n_3;
input n_11;
input n_19;
input n_10;
input n_13;
input n_14;
input n_12;

output n_166;

wire n_24;
wire n_61;
wire n_99;
wire n_115;
wire n_110;
wire n_148;
wire n_27;
wire n_86;
wire n_147;
wire n_102;
wire n_40;
wire n_66;
wire n_165;
wire n_88;
wire n_47;
wire n_119;
wire n_35;
wire n_52;
wire n_71;
wire n_150;
wire n_162;
wire n_157;
wire n_121;
wire n_60;
wire n_33;
wire n_89;
wire n_114;
wire n_30;
wire n_112;
wire n_59;
wire n_48;
wire n_67;
wire n_39;
wire n_50;
wire n_83;
wire n_113;
wire n_131;
wire n_45;
wire n_124;
wire n_158;
wire n_163;
wire n_130;
wire n_156;
wire n_64;
wire n_146;
wire n_85;
wire n_136;
wire n_58;
wire n_62;
wire n_76;
wire n_63;
wire n_70;
wire n_69;
wire n_101;
wire n_141;
wire n_123;
wire n_53;
wire n_109;
wire n_74;
wire n_160;
wire n_144;
wire n_28;
wire n_164;
wire n_94;
wire n_149;
wire n_81;
wire n_75;
wire n_161;
wire n_55;
wire n_111;
wire n_54;
wire n_78;
wire n_44;
wire n_38;
wire n_91;
wire n_42;
wire n_106;
wire n_116;
wire n_127;
wire n_34;
wire n_100;
wire n_26;
wire n_145;
wire n_43;
wire n_84;
wire n_37;
wire n_51;
wire n_23;
wire n_68;
wire n_140;
wire n_92;
wire n_129;
wire n_90;
wire n_143;
wire n_32;
wire n_77;
wire n_82;
wire n_117;
wire n_134;
wire n_152;
wire n_128;
wire n_93;
wire n_97;
wire n_118;
wire n_95;
wire n_98;
wire n_103;
wire n_135;
wire n_125;
wire n_122;
wire n_79;
wire n_154;
wire n_104;
wire n_105;
wire n_139;
wire n_133;
wire n_155;
wire n_120;
wire n_137;
wire n_46;
wire n_31;
wire n_73;
wire n_41;
wire n_87;
wire n_29;
wire n_56;
wire n_159;
wire n_72;
wire n_65;
wire n_80;
wire n_107;
wire n_132;
wire n_138;
wire n_151;
wire n_153;
wire n_36;
wire n_142;
wire n_126;
wire n_25;
wire n_49;
wire n_57;
wire n_96;
wire n_108;

CKINVDCx20_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_3),
.Y(n_24)
);

CKINVDCx20_ASAP7_75t_R g25 ( 
.A(n_5),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_9),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_22),
.Y(n_27)
);

CKINVDCx20_ASAP7_75t_R g28 ( 
.A(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_6),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_11),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_5),
.Y(n_31)
);

INVxp67_ASAP7_75t_SL g32 ( 
.A(n_1),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_9),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_SL g34 ( 
.A(n_24),
.B(n_31),
.Y(n_34)
);

BUFx10_ASAP7_75t_L g35 ( 
.A(n_26),
.Y(n_35)
);

INVx1_ASAP7_75t_L g36 ( 
.A(n_26),
.Y(n_36)
);

NOR2xp33_ASAP7_75t_SL g37 ( 
.A(n_23),
.B(n_25),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_SL g38 ( 
.A(n_27),
.B(n_0),
.Y(n_38)
);

NAND2xp5_ASAP7_75t_L g39 ( 
.A(n_32),
.B(n_0),
.Y(n_39)
);

INVx2_ASAP7_75t_L g40 ( 
.A(n_27),
.Y(n_40)
);

INVx2_ASAP7_75t_L g41 ( 
.A(n_29),
.Y(n_41)
);

INVx2_ASAP7_75t_SL g42 ( 
.A(n_35),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_36),
.Y(n_43)
);

AOI22xp5_ASAP7_75t_L g44 ( 
.A1(n_37),
.A2(n_28),
.B1(n_25),
.B2(n_23),
.Y(n_44)
);

NAND2xp5_ASAP7_75t_SL g45 ( 
.A(n_37),
.B(n_29),
.Y(n_45)
);

BUFx8_ASAP7_75t_L g46 ( 
.A(n_36),
.Y(n_46)
);

INVxp67_ASAP7_75t_L g47 ( 
.A(n_34),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_40),
.B(n_30),
.Y(n_48)
);

AOI22xp33_ASAP7_75t_L g49 ( 
.A1(n_35),
.A2(n_33),
.B1(n_30),
.B2(n_32),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_40),
.Y(n_50)
);

OAI22xp5_ASAP7_75t_L g51 ( 
.A1(n_49),
.A2(n_39),
.B1(n_28),
.B2(n_33),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_43),
.Y(n_52)
);

CKINVDCx5p33_ASAP7_75t_R g53 ( 
.A(n_44),
.Y(n_53)
);

INVx2_ASAP7_75t_L g54 ( 
.A(n_50),
.Y(n_54)
);

NAND2xp5_ASAP7_75t_L g55 ( 
.A(n_43),
.B(n_41),
.Y(n_55)
);

OAI22xp5_ASAP7_75t_L g56 ( 
.A1(n_44),
.A2(n_38),
.B1(n_41),
.B2(n_35),
.Y(n_56)
);

OAI21x1_ASAP7_75t_L g57 ( 
.A1(n_48),
.A2(n_35),
.B(n_1),
.Y(n_57)
);

INVxp67_ASAP7_75t_SL g58 ( 
.A(n_48),
.Y(n_58)
);

NAND3xp33_ASAP7_75t_L g59 ( 
.A(n_45),
.B(n_3),
.C(n_2),
.Y(n_59)
);

OAI22xp5_ASAP7_75t_L g60 ( 
.A1(n_47),
.A2(n_6),
.B1(n_4),
.B2(n_2),
.Y(n_60)
);

AOI21x1_ASAP7_75t_L g61 ( 
.A1(n_50),
.A2(n_7),
.B(n_4),
.Y(n_61)
);

AOI21x1_ASAP7_75t_SL g62 ( 
.A1(n_55),
.A2(n_42),
.B(n_46),
.Y(n_62)
);

NOR2xp67_ASAP7_75t_L g63 ( 
.A(n_54),
.B(n_47),
.Y(n_63)
);

O2A1O1Ixp33_ASAP7_75t_L g64 ( 
.A1(n_51),
.A2(n_42),
.B(n_46),
.C(n_8),
.Y(n_64)
);

NAND2xp5_ASAP7_75t_SL g65 ( 
.A(n_56),
.B(n_46),
.Y(n_65)
);

BUFx3_ASAP7_75t_L g66 ( 
.A(n_52),
.Y(n_66)
);

OR2x2_ASAP7_75t_L g67 ( 
.A(n_56),
.B(n_8),
.Y(n_67)
);

INVx1_ASAP7_75t_L g68 ( 
.A(n_52),
.Y(n_68)
);

OR2x2_ASAP7_75t_L g69 ( 
.A(n_53),
.B(n_10),
.Y(n_69)
);

OAI22xp5_ASAP7_75t_L g70 ( 
.A1(n_58),
.A2(n_46),
.B1(n_11),
.B2(n_10),
.Y(n_70)
);

INVx1_ASAP7_75t_L g71 ( 
.A(n_54),
.Y(n_71)
);

NAND2xp5_ASAP7_75t_L g72 ( 
.A(n_68),
.B(n_58),
.Y(n_72)
);

AND2x4_ASAP7_75t_L g73 ( 
.A(n_66),
.B(n_59),
.Y(n_73)
);

AND2x2_ASAP7_75t_L g74 ( 
.A(n_67),
.B(n_51),
.Y(n_74)
);

INVx1_ASAP7_75t_L g75 ( 
.A(n_68),
.Y(n_75)
);

AND2x2_ASAP7_75t_L g76 ( 
.A(n_67),
.B(n_55),
.Y(n_76)
);

INVx3_ASAP7_75t_L g77 ( 
.A(n_66),
.Y(n_77)
);

AND2x2_ASAP7_75t_L g78 ( 
.A(n_66),
.B(n_57),
.Y(n_78)
);

INVx1_ASAP7_75t_L g79 ( 
.A(n_71),
.Y(n_79)
);

INVx3_ASAP7_75t_L g80 ( 
.A(n_77),
.Y(n_80)
);

INVx1_ASAP7_75t_L g81 ( 
.A(n_75),
.Y(n_81)
);

HB1xp67_ASAP7_75t_L g82 ( 
.A(n_77),
.Y(n_82)
);

INVx1_ASAP7_75t_L g83 ( 
.A(n_75),
.Y(n_83)
);

INVx2_ASAP7_75t_L g84 ( 
.A(n_79),
.Y(n_84)
);

INVxp67_ASAP7_75t_SL g85 ( 
.A(n_77),
.Y(n_85)
);

NAND2xp5_ASAP7_75t_L g86 ( 
.A(n_75),
.B(n_71),
.Y(n_86)
);

OAI31xp33_ASAP7_75t_L g87 ( 
.A1(n_86),
.A2(n_74),
.A3(n_65),
.B(n_60),
.Y(n_87)
);

OR2x2_ASAP7_75t_L g88 ( 
.A(n_84),
.B(n_74),
.Y(n_88)
);

AND2x2_ASAP7_75t_L g89 ( 
.A(n_84),
.B(n_74),
.Y(n_89)
);

NAND2x1p5_ASAP7_75t_L g90 ( 
.A(n_80),
.B(n_77),
.Y(n_90)
);

AND2x2_ASAP7_75t_L g91 ( 
.A(n_84),
.B(n_74),
.Y(n_91)
);

AND2x2_ASAP7_75t_L g92 ( 
.A(n_84),
.B(n_74),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_84),
.Y(n_93)
);

OR2x2_ASAP7_75t_L g94 ( 
.A(n_86),
.B(n_76),
.Y(n_94)
);

AOI322xp5_ASAP7_75t_L g95 ( 
.A1(n_91),
.A2(n_76),
.A3(n_60),
.B1(n_73),
.B2(n_69),
.C1(n_75),
.C2(n_81),
.Y(n_95)
);

INVxp67_ASAP7_75t_L g96 ( 
.A(n_91),
.Y(n_96)
);

AND2x2_ASAP7_75t_L g97 ( 
.A(n_91),
.B(n_78),
.Y(n_97)
);

NAND2xp5_ASAP7_75t_L g98 ( 
.A(n_94),
.B(n_89),
.Y(n_98)
);

OA21x2_ASAP7_75t_L g99 ( 
.A1(n_93),
.A2(n_57),
.B(n_81),
.Y(n_99)
);

AND2x2_ASAP7_75t_L g100 ( 
.A(n_92),
.B(n_89),
.Y(n_100)
);

OAI33xp33_ASAP7_75t_L g101 ( 
.A1(n_94),
.A2(n_70),
.A3(n_69),
.B1(n_64),
.B2(n_83),
.B3(n_81),
.Y(n_101)
);

INVx1_ASAP7_75t_L g102 ( 
.A(n_93),
.Y(n_102)
);

INVx1_ASAP7_75t_L g103 ( 
.A(n_88),
.Y(n_103)
);

INVx1_ASAP7_75t_L g104 ( 
.A(n_88),
.Y(n_104)
);

NAND2xp5_ASAP7_75t_L g105 ( 
.A(n_92),
.B(n_76),
.Y(n_105)
);

OAI31xp33_ASAP7_75t_L g106 ( 
.A1(n_87),
.A2(n_59),
.A3(n_76),
.B(n_73),
.Y(n_106)
);

NOR2xp33_ASAP7_75t_L g107 ( 
.A(n_105),
.B(n_76),
.Y(n_107)
);

OAI22xp33_ASAP7_75t_L g108 ( 
.A1(n_105),
.A2(n_87),
.B1(n_86),
.B2(n_72),
.Y(n_108)
);

AOI21xp5_ASAP7_75t_L g109 ( 
.A1(n_106),
.A2(n_85),
.B(n_72),
.Y(n_109)
);

AOI211xp5_ASAP7_75t_L g110 ( 
.A1(n_106),
.A2(n_63),
.B(n_57),
.C(n_73),
.Y(n_110)
);

NAND2xp5_ASAP7_75t_L g111 ( 
.A(n_100),
.B(n_83),
.Y(n_111)
);

AOI21xp33_ASAP7_75t_SL g112 ( 
.A1(n_103),
.A2(n_13),
.B(n_12),
.Y(n_112)
);

NAND2xp5_ASAP7_75t_L g113 ( 
.A(n_100),
.B(n_83),
.Y(n_113)
);

AOI221xp5_ASAP7_75t_L g114 ( 
.A1(n_101),
.A2(n_73),
.B1(n_78),
.B2(n_79),
.C(n_82),
.Y(n_114)
);

NAND3xp33_ASAP7_75t_L g115 ( 
.A(n_95),
.B(n_63),
.C(n_73),
.Y(n_115)
);

NAND2xp33_ASAP7_75t_L g116 ( 
.A(n_102),
.B(n_72),
.Y(n_116)
);

NAND4xp25_ASAP7_75t_L g117 ( 
.A(n_95),
.B(n_102),
.C(n_73),
.D(n_78),
.Y(n_117)
);

NAND4xp25_ASAP7_75t_L g118 ( 
.A(n_103),
.B(n_73),
.C(n_78),
.D(n_72),
.Y(n_118)
);

OAI21xp5_ASAP7_75t_L g119 ( 
.A1(n_99),
.A2(n_78),
.B(n_73),
.Y(n_119)
);

NAND2xp5_ASAP7_75t_L g120 ( 
.A(n_100),
.B(n_73),
.Y(n_120)
);

AOI211xp5_ASAP7_75t_L g121 ( 
.A1(n_101),
.A2(n_54),
.B(n_79),
.C(n_12),
.Y(n_121)
);

OAI21xp33_ASAP7_75t_SL g122 ( 
.A1(n_98),
.A2(n_85),
.B(n_104),
.Y(n_122)
);

INVxp67_ASAP7_75t_SL g123 ( 
.A(n_116),
.Y(n_123)
);

INVx1_ASAP7_75t_L g124 ( 
.A(n_113),
.Y(n_124)
);

INVx2_ASAP7_75t_L g125 ( 
.A(n_111),
.Y(n_125)
);

INVx1_ASAP7_75t_L g126 ( 
.A(n_122),
.Y(n_126)
);

AND2x2_ASAP7_75t_L g127 ( 
.A(n_119),
.B(n_97),
.Y(n_127)
);

HB1xp67_ASAP7_75t_L g128 ( 
.A(n_120),
.Y(n_128)
);

AOI21xp33_ASAP7_75t_SL g129 ( 
.A1(n_108),
.A2(n_14),
.B(n_13),
.Y(n_129)
);

INVx1_ASAP7_75t_L g130 ( 
.A(n_110),
.Y(n_130)
);

NAND2xp5_ASAP7_75t_L g131 ( 
.A(n_108),
.B(n_104),
.Y(n_131)
);

NAND2xp5_ASAP7_75t_L g132 ( 
.A(n_121),
.B(n_96),
.Y(n_132)
);

HB1xp67_ASAP7_75t_L g133 ( 
.A(n_118),
.Y(n_133)
);

NAND2xp5_ASAP7_75t_SL g134 ( 
.A(n_112),
.B(n_107),
.Y(n_134)
);

INVx1_ASAP7_75t_L g135 ( 
.A(n_109),
.Y(n_135)
);

INVxp67_ASAP7_75t_L g136 ( 
.A(n_114),
.Y(n_136)
);

NOR3xp33_ASAP7_75t_L g137 ( 
.A(n_115),
.B(n_61),
.C(n_98),
.Y(n_137)
);

NOR2x1_ASAP7_75t_L g138 ( 
.A(n_117),
.B(n_99),
.Y(n_138)
);

NAND4xp75_ASAP7_75t_L g139 ( 
.A(n_130),
.B(n_97),
.C(n_99),
.D(n_79),
.Y(n_139)
);

NOR4xp75_ASAP7_75t_L g140 ( 
.A(n_134),
.B(n_132),
.C(n_131),
.D(n_127),
.Y(n_140)
);

BUFx2_ASAP7_75t_L g141 ( 
.A(n_125),
.Y(n_141)
);

AOI21xp5_ASAP7_75t_L g142 ( 
.A1(n_136),
.A2(n_82),
.B(n_96),
.Y(n_142)
);

NAND4xp75_ASAP7_75t_L g143 ( 
.A(n_130),
.B(n_97),
.C(n_99),
.D(n_62),
.Y(n_143)
);

INVx2_ASAP7_75t_L g144 ( 
.A(n_125),
.Y(n_144)
);

NAND4xp25_ASAP7_75t_L g145 ( 
.A(n_129),
.B(n_16),
.C(n_15),
.D(n_14),
.Y(n_145)
);

INVxp67_ASAP7_75t_L g146 ( 
.A(n_126),
.Y(n_146)
);

NAND4xp75_ASAP7_75t_L g147 ( 
.A(n_132),
.B(n_99),
.C(n_16),
.D(n_15),
.Y(n_147)
);

AOI22xp33_ASAP7_75t_SL g148 ( 
.A1(n_133),
.A2(n_80),
.B1(n_77),
.B2(n_17),
.Y(n_148)
);

AND2x2_ASAP7_75t_L g149 ( 
.A(n_125),
.B(n_128),
.Y(n_149)
);

NAND2xp5_ASAP7_75t_L g150 ( 
.A(n_124),
.B(n_17),
.Y(n_150)
);

OAI22xp5_ASAP7_75t_L g151 ( 
.A1(n_147),
.A2(n_136),
.B1(n_138),
.B2(n_129),
.Y(n_151)
);

OAI22xp33_ASAP7_75t_L g152 ( 
.A1(n_145),
.A2(n_123),
.B1(n_138),
.B2(n_131),
.Y(n_152)
);

AOI322xp5_ASAP7_75t_L g153 ( 
.A1(n_148),
.A2(n_135),
.A3(n_126),
.B1(n_137),
.B2(n_127),
.C1(n_124),
.C2(n_18),
.Y(n_153)
);

INVx2_ASAP7_75t_L g154 ( 
.A(n_144),
.Y(n_154)
);

NOR3xp33_ASAP7_75t_L g155 ( 
.A(n_150),
.B(n_148),
.C(n_143),
.Y(n_155)
);

AOI221xp5_ASAP7_75t_L g156 ( 
.A1(n_146),
.A2(n_135),
.B1(n_137),
.B2(n_18),
.C(n_19),
.Y(n_156)
);

AOI322xp5_ASAP7_75t_L g157 ( 
.A1(n_146),
.A2(n_20),
.A3(n_19),
.B1(n_21),
.B2(n_22),
.C1(n_61),
.C2(n_77),
.Y(n_157)
);

AOI22xp5_ASAP7_75t_L g158 ( 
.A1(n_139),
.A2(n_80),
.B1(n_77),
.B2(n_90),
.Y(n_158)
);

OAI22xp5_ASAP7_75t_L g159 ( 
.A1(n_151),
.A2(n_142),
.B1(n_140),
.B2(n_144),
.Y(n_159)
);

AOI21xp5_ASAP7_75t_SL g160 ( 
.A1(n_156),
.A2(n_149),
.B(n_141),
.Y(n_160)
);

OAI22xp5_ASAP7_75t_L g161 ( 
.A1(n_152),
.A2(n_90),
.B1(n_80),
.B2(n_77),
.Y(n_161)
);

XNOR2xp5_ASAP7_75t_L g162 ( 
.A(n_155),
.B(n_21),
.Y(n_162)
);

AOI21xp5_ASAP7_75t_L g163 ( 
.A1(n_160),
.A2(n_154),
.B(n_158),
.Y(n_163)
);

OAI22xp5_ASAP7_75t_L g164 ( 
.A1(n_161),
.A2(n_153),
.B1(n_157),
.B2(n_90),
.Y(n_164)
);

OAI22xp5_ASAP7_75t_L g165 ( 
.A1(n_163),
.A2(n_159),
.B1(n_162),
.B2(n_80),
.Y(n_165)
);

AOI22xp5_ASAP7_75t_L g166 ( 
.A1(n_165),
.A2(n_164),
.B1(n_80),
.B2(n_77),
.Y(n_166)
);


endmodule