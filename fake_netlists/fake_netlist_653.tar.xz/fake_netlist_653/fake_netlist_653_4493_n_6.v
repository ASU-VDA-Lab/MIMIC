module fake_netlist_653_4493_n_6 (n_1, n_2, n_0, n_6);

input n_1;
input n_2;
input n_0;

output n_6;

wire n_4;
wire n_5;
wire n_3;

OR2x6_ASAP7_75t_L g3 ( 
.A(n_1),
.B(n_2),
.Y(n_3)
);

NOR2x1_ASAP7_75t_L g4 ( 
.A(n_1),
.B(n_0),
.Y(n_4)
);

INVxp67_ASAP7_75t_SL g5 ( 
.A(n_2),
.Y(n_5)
);

NOR3xp33_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.C(n_3),
.Y(n_6)
);


endmodule