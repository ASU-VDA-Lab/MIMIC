module fake_netlist_653_1456_n_20 (n_3, n_1, n_2, n_0, n_20);

input n_3;
input n_1;
input n_2;
input n_0;

output n_20;

wire n_18;
wire n_19;
wire n_5;
wire n_10;
wire n_15;
wire n_11;
wire n_7;
wire n_16;
wire n_12;
wire n_4;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx2_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

INVx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

BUFx6f_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_0),
.Y(n_7)
);

AOI221xp5_ASAP7_75t_L g8 ( 
.A1(n_5),
.A2(n_1),
.B1(n_0),
.B2(n_2),
.C(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_6),
.B(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

AND2x2_ASAP7_75t_L g11 ( 
.A(n_7),
.B(n_6),
.Y(n_11)
);

NOR2xp33_ASAP7_75t_SL g12 ( 
.A(n_10),
.B(n_8),
.Y(n_12)
);

NOR2x1_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_9),
.Y(n_13)
);

AOI211xp5_ASAP7_75t_SL g14 ( 
.A1(n_12),
.A2(n_11),
.B(n_10),
.C(n_0),
.Y(n_14)
);

O2A1O1Ixp5_ASAP7_75t_L g15 ( 
.A1(n_13),
.A2(n_10),
.B(n_11),
.C(n_1),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_14),
.B(n_1),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_14),
.B(n_1),
.Y(n_17)
);

OAI22x1_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_17),
.B1(n_3),
.B2(n_15),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_16),
.B(n_3),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_18),
.B(n_19),
.Y(n_20)
);


endmodule