module fake_netlist_653_3802_n_8 (n_1, n_0, n_8);

input n_1;
input n_0;

output n_8;

wire n_4;
wire n_7;
wire n_2;
wire n_5;
wire n_6;
wire n_3;

NAND2xp5_ASAP7_75t_SL g2 ( 
.A(n_1),
.B(n_0),
.Y(n_2)
);

NAND2xp5_ASAP7_75t_SL g3 ( 
.A(n_1),
.B(n_0),
.Y(n_3)
);

INVx1_ASAP7_75t_L g4 ( 
.A(n_3),
.Y(n_4)
);

AND2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

NOR4xp25_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.C(n_1),
.D(n_0),
.Y(n_6)
);

AOI211xp5_ASAP7_75t_SL g7 ( 
.A1(n_6),
.A2(n_5),
.B(n_1),
.C(n_0),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);


endmodule