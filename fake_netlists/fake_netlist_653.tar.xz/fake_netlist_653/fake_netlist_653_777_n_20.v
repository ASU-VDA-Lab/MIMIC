module fake_netlist_653_777_n_20 (n_3, n_1, n_2, n_0, n_20);

input n_3;
input n_1;
input n_2;
input n_0;

output n_20;

wire n_18;
wire n_19;
wire n_10;
wire n_5;
wire n_11;
wire n_15;
wire n_7;
wire n_16;
wire n_12;
wire n_4;
wire n_17;
wire n_14;
wire n_9;
wire n_13;
wire n_8;
wire n_6;

INVx1_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_3),
.B(n_2),
.Y(n_5)
);

NOR2xp33_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_2),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_SL g7 ( 
.A(n_3),
.B(n_0),
.Y(n_7)
);

OR2x2_ASAP7_75t_L g8 ( 
.A(n_4),
.B(n_0),
.Y(n_8)
);

AND2x2_ASAP7_75t_L g9 ( 
.A(n_4),
.B(n_0),
.Y(n_9)
);

NOR2xp33_ASAP7_75t_L g10 ( 
.A(n_7),
.B(n_1),
.Y(n_10)
);

INVx2_ASAP7_75t_SL g11 ( 
.A(n_9),
.Y(n_11)
);

INVxp67_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

NOR2xp33_ASAP7_75t_L g13 ( 
.A(n_10),
.B(n_6),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_11),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_10),
.Y(n_15)
);

AOI21xp5_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_11),
.B(n_13),
.Y(n_16)
);

OAI211xp5_ASAP7_75t_SL g17 ( 
.A1(n_14),
.A2(n_5),
.B(n_3),
.C(n_2),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

AOI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_1),
.B1(n_12),
.B2(n_18),
.Y(n_20)
);


endmodule