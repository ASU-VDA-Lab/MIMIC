module fake_netlist_653_3132_n_12 (n_4, n_1, n_2, n_0, n_5, n_3, n_12);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_12;

wire n_9;
wire n_7;
wire n_10;
wire n_11;
wire n_8;
wire n_6;

AOI22xp33_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_4),
.B1(n_1),
.B2(n_5),
.Y(n_6)
);

BUFx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

NAND3xp33_ASAP7_75t_L g8 ( 
.A(n_5),
.B(n_0),
.C(n_3),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_0),
.Y(n_10)
);

AOI211xp5_ASAP7_75t_L g11 ( 
.A1(n_9),
.A2(n_8),
.B(n_2),
.C(n_1),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_9),
.B1(n_10),
.B2(n_2),
.Y(n_12)
);


endmodule