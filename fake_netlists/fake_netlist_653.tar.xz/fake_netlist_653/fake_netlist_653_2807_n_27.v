module fake_netlist_653_2807_n_27 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_27);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_27;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_11;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_26;
wire n_9;
wire n_13;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_8),
.Y(n_9)
);

CKINVDCx5p33_ASAP7_75t_R g10 ( 
.A(n_7),
.Y(n_10)
);

BUFx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_13)
);

OAI22xp5_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_4),
.B1(n_2),
.B2(n_0),
.Y(n_14)
);

A2O1A1Ixp33_ASAP7_75t_SL g15 ( 
.A1(n_12),
.A2(n_5),
.B(n_4),
.C(n_2),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

BUFx6f_ASAP7_75t_L g17 ( 
.A(n_15),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_13),
.Y(n_18)
);

NAND2x1_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_5),
.Y(n_19)
);

AND2x4_ASAP7_75t_L g20 ( 
.A(n_16),
.B(n_10),
.Y(n_20)
);

INVx1_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_19),
.Y(n_22)
);

OAI21xp5_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_20),
.B(n_16),
.Y(n_23)
);

NAND2xp5_ASAP7_75t_L g24 ( 
.A(n_22),
.B(n_18),
.Y(n_24)
);

OAI21xp33_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_22),
.B(n_6),
.Y(n_25)
);

INVxp67_ASAP7_75t_SL g26 ( 
.A(n_25),
.Y(n_26)
);

AOI211xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_17),
.B(n_14),
.C(n_23),
.Y(n_27)
);


endmodule