module fake_netlist_653_2683_n_29 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_29);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_29;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_26;
wire n_13;

INVxp67_ASAP7_75t_L g13 ( 
.A(n_4),
.Y(n_13)
);

CKINVDCx5p33_ASAP7_75t_R g14 ( 
.A(n_6),
.Y(n_14)
);

NAND2xp33_ASAP7_75t_L g15 ( 
.A(n_9),
.B(n_10),
.Y(n_15)
);

INVx2_ASAP7_75t_L g16 ( 
.A(n_1),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_0),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_3),
.Y(n_18)
);

NOR3xp33_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_2),
.C(n_1),
.Y(n_19)
);

NOR3xp33_ASAP7_75t_SL g20 ( 
.A(n_17),
.B(n_3),
.C(n_2),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_L g21 ( 
.A(n_13),
.B(n_12),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_R g22 ( 
.A(n_21),
.B(n_14),
.Y(n_22)
);

BUFx3_ASAP7_75t_L g23 ( 
.A(n_20),
.Y(n_23)
);

BUFx3_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_23),
.Y(n_25)
);

AOI32xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_19),
.A3(n_24),
.B1(n_16),
.B2(n_15),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_SL g27 ( 
.A(n_26),
.B(n_22),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_5),
.Y(n_28)
);

AOI22xp5_ASAP7_75t_L g29 ( 
.A1(n_28),
.A2(n_11),
.B1(n_8),
.B2(n_7),
.Y(n_29)
);


endmodule