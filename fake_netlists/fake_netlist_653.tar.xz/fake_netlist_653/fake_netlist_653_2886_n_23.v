module fake_netlist_653_2886_n_23 (n_4, n_7, n_1, n_2, n_0, n_5, n_6, n_3, n_23);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_6;
input n_3;

output n_23;

wire n_18;
wire n_19;
wire n_10;
wire n_15;
wire n_11;
wire n_20;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_9;
wire n_13;
wire n_8;

INVx3_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

CKINVDCx16_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_6),
.Y(n_10)
);

INVx3_ASAP7_75t_L g11 ( 
.A(n_1),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_8),
.Y(n_12)
);

INVxp67_ASAP7_75t_L g13 ( 
.A(n_8),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_9),
.B(n_4),
.Y(n_14)
);

NAND3x1_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_11),
.C(n_10),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_L g16 ( 
.A(n_13),
.B(n_11),
.Y(n_16)
);

OR2x2_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_12),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_15),
.Y(n_18)
);

OAI22xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_3),
.B1(n_2),
.B2(n_0),
.Y(n_19)
);

CKINVDCx6p67_ASAP7_75t_R g20 ( 
.A(n_19),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_20),
.Y(n_21)
);

INVx1_ASAP7_75t_SL g22 ( 
.A(n_21),
.Y(n_22)
);

INVxp67_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);


endmodule