module fake_netlist_653_1303_n_21 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_10, n_8, n_6, n_3, n_21);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_8;
input n_6;
input n_3;

output n_21;

wire n_18;
wire n_19;
wire n_11;
wire n_15;
wire n_20;
wire n_16;
wire n_12;
wire n_17;
wire n_14;
wire n_13;

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

OAI22xp5_ASAP7_75t_L g12 ( 
.A1(n_7),
.A2(n_0),
.B1(n_9),
.B2(n_1),
.Y(n_12)
);

CKINVDCx20_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_6),
.Y(n_14)
);

AOI221x1_ASAP7_75t_L g15 ( 
.A1(n_11),
.A2(n_10),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_15)
);

BUFx2_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI322xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_13),
.A3(n_14),
.B1(n_12),
.B2(n_4),
.C1(n_3),
.C2(n_5),
.Y(n_17)
);

OAI22xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_13),
.B1(n_4),
.B2(n_3),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_R g19 ( 
.A(n_18),
.B(n_5),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_6),
.Y(n_20)
);

OA21x2_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_7),
.B(n_15),
.Y(n_21)
);


endmodule