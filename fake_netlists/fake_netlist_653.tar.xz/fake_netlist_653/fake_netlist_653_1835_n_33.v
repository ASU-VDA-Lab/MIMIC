module fake_netlist_653_1835_n_33 (n_9, n_4, n_7, n_14, n_13, n_1, n_2, n_0, n_5, n_10, n_12, n_11, n_8, n_6, n_3, n_33);

input n_9;
input n_4;
input n_7;
input n_14;
input n_13;
input n_1;
input n_2;
input n_0;
input n_5;
input n_10;
input n_12;
input n_11;
input n_8;
input n_6;
input n_3;

output n_33;

wire n_18;
wire n_19;
wire n_25;
wire n_24;
wire n_28;
wire n_15;
wire n_30;
wire n_20;
wire n_23;
wire n_16;
wire n_22;
wire n_17;
wire n_27;
wire n_21;
wire n_29;
wire n_31;
wire n_26;
wire n_32;

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_3),
.Y(n_15)
);

NAND2xp5_ASAP7_75t_SL g16 ( 
.A(n_11),
.B(n_2),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_10),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_6),
.A2(n_4),
.B(n_1),
.Y(n_18)
);

INVx3_ASAP7_75t_L g19 ( 
.A(n_4),
.Y(n_19)
);

INVx3_ASAP7_75t_L g20 ( 
.A(n_12),
.Y(n_20)
);

INVx3_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_19),
.A2(n_7),
.B1(n_6),
.B2(n_0),
.Y(n_22)
);

NAND3xp33_ASAP7_75t_SL g23 ( 
.A(n_17),
.B(n_7),
.C(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

INVx2_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

INVx1_ASAP7_75t_SL g26 ( 
.A(n_24),
.Y(n_26)
);

NAND3xp33_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.C(n_15),
.Y(n_27)
);

OAI221xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_19),
.B1(n_21),
.B2(n_20),
.C(n_16),
.Y(n_28)
);

CKINVDCx16_ASAP7_75t_R g29 ( 
.A(n_28),
.Y(n_29)
);

CKINVDCx16_ASAP7_75t_R g30 ( 
.A(n_28),
.Y(n_30)
);

OAI22xp5_ASAP7_75t_SL g31 ( 
.A1(n_29),
.A2(n_21),
.B1(n_20),
.B2(n_18),
.Y(n_31)
);

NOR2x1p5_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_8),
.Y(n_32)
);

AOI22xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_32),
.B1(n_13),
.B2(n_9),
.Y(n_33)
);


endmodule