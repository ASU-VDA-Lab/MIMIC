module fake_netlist_653_5732_n_11 (n_1, n_2, n_0, n_11);

input n_1;
input n_2;
input n_0;

output n_11;

wire n_9;
wire n_4;
wire n_7;
wire n_5;
wire n_10;
wire n_8;
wire n_6;
wire n_3;

BUFx10_ASAP7_75t_L g3 ( 
.A(n_1),
.Y(n_3)
);

INVx5_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

OR2x2_ASAP7_75t_L g5 ( 
.A(n_4),
.B(n_2),
.Y(n_5)
);

HB1xp67_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

BUFx2_ASAP7_75t_L g7 ( 
.A(n_6),
.Y(n_7)
);

INVx3_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

OAI222xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B1(n_4),
.B2(n_2),
.C1(n_3),
.C2(n_0),
.Y(n_9)
);

INVx3_ASAP7_75t_SL g10 ( 
.A(n_9),
.Y(n_10)
);

AOI222xp33_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_8),
.B1(n_9),
.B2(n_2),
.C1(n_3),
.C2(n_1),
.Y(n_11)
);


endmodule