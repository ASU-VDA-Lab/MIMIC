module fake_netlist_653_3164_n_13 (n_4, n_1, n_2, n_0, n_5, n_3, n_13);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_13;

wire n_9;
wire n_7;
wire n_12;
wire n_10;
wire n_11;
wire n_8;
wire n_6;

INVx2_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

BUFx6f_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

NAND2xp5_ASAP7_75t_L g8 ( 
.A(n_3),
.B(n_1),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_1),
.B(n_0),
.Y(n_9)
);

AND2x4_ASAP7_75t_L g10 ( 
.A(n_6),
.B(n_0),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_9),
.Y(n_11)
);

O2A1O1Ixp33_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_8),
.B(n_7),
.C(n_2),
.Y(n_12)
);

AOI21xp33_ASAP7_75t_L g13 ( 
.A1(n_12),
.A2(n_10),
.B(n_11),
.Y(n_13)
);


endmodule