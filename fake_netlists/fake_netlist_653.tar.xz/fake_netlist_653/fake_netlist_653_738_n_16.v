module fake_netlist_653_738_n_16 (n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_16);

input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_16;

wire n_14;
wire n_13;
wire n_10;
wire n_12;
wire n_15;
wire n_11;
wire n_9;

BUFx3_ASAP7_75t_L g9 ( 
.A(n_2),
.Y(n_9)
);

HB1xp67_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_1),
.B(n_0),
.Y(n_12)
);

INVxp67_ASAP7_75t_SL g13 ( 
.A(n_10),
.Y(n_13)
);

INVx2_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI22xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_11),
.B1(n_9),
.B2(n_12),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_SL g16 ( 
.A1(n_15),
.A2(n_4),
.B1(n_5),
.B2(n_7),
.C1(n_8),
.C2(n_14),
.Y(n_16)
);


endmodule