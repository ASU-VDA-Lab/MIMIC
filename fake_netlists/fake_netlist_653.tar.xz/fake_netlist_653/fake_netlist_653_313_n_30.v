module fake_netlist_653_313_n_30 (n_9, n_4, n_7, n_1, n_2, n_0, n_5, n_8, n_6, n_3, n_30);

input n_9;
input n_4;
input n_7;
input n_1;
input n_2;
input n_0;
input n_5;
input n_8;
input n_6;
input n_3;

output n_30;

wire n_18;
wire n_19;
wire n_10;
wire n_25;
wire n_24;
wire n_28;
wire n_11;
wire n_15;
wire n_20;
wire n_23;
wire n_16;
wire n_12;
wire n_22;
wire n_17;
wire n_14;
wire n_21;
wire n_27;
wire n_29;
wire n_26;
wire n_13;

BUFx6f_ASAP7_75t_SL g10 ( 
.A(n_4),
.Y(n_10)
);

BUFx3_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_2),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_9),
.Y(n_15)
);

AO21x2_ASAP7_75t_L g16 ( 
.A1(n_4),
.A2(n_8),
.B(n_0),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_14),
.A2(n_6),
.B(n_5),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_12),
.A2(n_7),
.B(n_5),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_12),
.Y(n_19)
);

AO21x1_ASAP7_75t_L g20 ( 
.A1(n_16),
.A2(n_7),
.B(n_10),
.Y(n_20)
);

AO31x2_ASAP7_75t_L g21 ( 
.A1(n_10),
.A2(n_16),
.A3(n_11),
.B(n_13),
.Y(n_21)
);

INVxp67_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

AND2x4_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_11),
.Y(n_23)
);

AND2x2_ASAP7_75t_L g24 ( 
.A(n_19),
.B(n_21),
.Y(n_24)
);

INVxp67_ASAP7_75t_L g25 ( 
.A(n_24),
.Y(n_25)
);

NAND2x1_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_18),
.Y(n_26)
);

NOR4xp25_ASAP7_75t_L g27 ( 
.A(n_25),
.B(n_22),
.C(n_20),
.D(n_21),
.Y(n_27)
);

AND3x4_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_23),
.C(n_15),
.Y(n_28)
);

OAI22xp5_ASAP7_75t_SL g29 ( 
.A1(n_28),
.A2(n_26),
.B1(n_23),
.B2(n_22),
.Y(n_29)
);

AOI21xp5_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_17),
.B(n_22),
.Y(n_30)
);


endmodule