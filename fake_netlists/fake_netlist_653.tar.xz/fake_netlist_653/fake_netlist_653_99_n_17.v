module fake_netlist_653_99_n_17 (n_4, n_1, n_2, n_0, n_5, n_3, n_17);

input n_4;
input n_1;
input n_2;
input n_0;
input n_5;
input n_3;

output n_17;

wire n_9;
wire n_7;
wire n_14;
wire n_13;
wire n_10;
wire n_6;
wire n_16;
wire n_8;
wire n_15;
wire n_11;
wire n_12;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_1),
.B(n_5),
.Y(n_6)
);

INVx3_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

AOI22xp33_ASAP7_75t_L g8 ( 
.A1(n_2),
.A2(n_0),
.B1(n_1),
.B2(n_5),
.Y(n_8)
);

HB1xp67_ASAP7_75t_L g9 ( 
.A(n_0),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_11),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

NOR2x1_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_10),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_9),
.Y(n_15)
);

OA22x2_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_6),
.B1(n_8),
.B2(n_3),
.Y(n_16)
);

AOI221xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_3),
.B1(n_4),
.B2(n_14),
.C(n_15),
.Y(n_17)
);


endmodule