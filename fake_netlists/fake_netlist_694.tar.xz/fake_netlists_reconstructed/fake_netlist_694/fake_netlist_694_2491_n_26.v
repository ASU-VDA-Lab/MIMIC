module fake_netlist_694_2491_n_26 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_26);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_26;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_25;
wire n_19;
wire n_14;

AOI22xp33_ASAP7_75t_L g14 ( 
.A1(n_0),
.A2(n_13),
.B1(n_7),
.B2(n_12),
.Y(n_14)
);

AOI22xp33_ASAP7_75t_L g15 ( 
.A1(n_5),
.A2(n_6),
.B1(n_8),
.B2(n_10),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_3),
.Y(n_16)
);

INVxp67_ASAP7_75t_SL g17 ( 
.A(n_4),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_SL g18 ( 
.A(n_7),
.B(n_1),
.Y(n_18)
);

AO31x2_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_5),
.A3(n_4),
.B(n_1),
.Y(n_19)
);

OAI21x1_ASAP7_75t_L g20 ( 
.A1(n_18),
.A2(n_9),
.B(n_2),
.Y(n_20)
);

AND2x4_ASAP7_75t_L g21 ( 
.A(n_19),
.B(n_16),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_19),
.Y(n_22)
);

NOR3xp33_ASAP7_75t_L g23 ( 
.A(n_22),
.B(n_20),
.C(n_21),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_21),
.B1(n_15),
.B2(n_14),
.C(n_16),
.Y(n_24)
);

NOR3xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_16),
.C(n_19),
.Y(n_25)
);

NAND3xp33_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_6),
.C(n_11),
.Y(n_26)
);


endmodule