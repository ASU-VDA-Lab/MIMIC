module fake_netlist_694_1246_n_16 (n_3, n_0, n_2, n_1, n_16);

input n_3;
input n_0;
input n_2;
input n_1;

output n_16;

wire n_9;
wire n_7;
wire n_4;
wire n_15;
wire n_14;
wire n_11;
wire n_13;
wire n_8;
wire n_10;
wire n_5;
wire n_6;
wire n_12;

OR2x2_ASAP7_75t_L g4 ( 
.A(n_3),
.B(n_1),
.Y(n_4)
);

AND2x2_ASAP7_75t_SL g5 ( 
.A(n_0),
.B(n_1),
.Y(n_5)
);

BUFx10_ASAP7_75t_L g6 ( 
.A(n_5),
.Y(n_6)
);

NAND2x1p5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_1),
.Y(n_7)
);

BUFx6f_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

AOI22xp5_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_6),
.B1(n_4),
.B2(n_1),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

NAND2x1_ASAP7_75t_SL g12 ( 
.A(n_10),
.B(n_6),
.Y(n_12)
);

AOI211xp5_ASAP7_75t_L g13 ( 
.A1(n_11),
.A2(n_8),
.B(n_2),
.C(n_0),
.Y(n_13)
);

XNOR2x1_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_8),
.Y(n_14)
);

INVxp67_ASAP7_75t_L g15 ( 
.A(n_12),
.Y(n_15)
);

AOI222xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_0),
.B1(n_2),
.B2(n_3),
.C1(n_13),
.C2(n_14),
.Y(n_16)
);


endmodule