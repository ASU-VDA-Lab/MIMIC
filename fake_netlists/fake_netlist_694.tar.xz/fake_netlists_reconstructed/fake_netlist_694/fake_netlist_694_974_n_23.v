module fake_netlist_694_974_n_23 (n_9, n_4, n_2, n_7, n_3, n_11, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_23);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_23;

wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_19;
wire n_14;
wire n_13;

AND2x4_ASAP7_75t_L g13 ( 
.A(n_7),
.B(n_1),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_SL g14 ( 
.A(n_10),
.B(n_11),
.Y(n_14)
);

AO22x2_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_4),
.B1(n_8),
.B2(n_7),
.Y(n_15)
);

BUFx6f_ASAP7_75t_L g16 ( 
.A(n_0),
.Y(n_16)
);

INVx3_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

OAI21x1_ASAP7_75t_L g18 ( 
.A1(n_14),
.A2(n_3),
.B(n_2),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

AOI221xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_15),
.B1(n_13),
.B2(n_16),
.C(n_18),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI22xp33_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_9),
.B1(n_6),
.B2(n_5),
.Y(n_23)
);


endmodule