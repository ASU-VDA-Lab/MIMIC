module fake_netlist_694_1758_n_27 (n_9, n_4, n_2, n_7, n_14, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_27);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_27;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_25;
wire n_19;

NAND2xp5_ASAP7_75t_SL g15 ( 
.A(n_13),
.B(n_4),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_9),
.Y(n_16)
);

INVx1_ASAP7_75t_SL g17 ( 
.A(n_8),
.Y(n_17)
);

NAND2xp33_ASAP7_75t_L g18 ( 
.A(n_6),
.B(n_3),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_SL g19 ( 
.A(n_2),
.B(n_0),
.Y(n_19)
);

NAND3xp33_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_7),
.C(n_1),
.Y(n_20)
);

OAI21x1_ASAP7_75t_L g21 ( 
.A1(n_16),
.A2(n_10),
.B(n_5),
.Y(n_21)
);

OR2x2_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_7),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_22),
.Y(n_23)
);

AOI211x1_ASAP7_75t_SL g24 ( 
.A1(n_23),
.A2(n_19),
.B(n_15),
.C(n_21),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

OAI21x1_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_12),
.B(n_11),
.Y(n_26)
);

OAI21xp5_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_17),
.B(n_14),
.Y(n_27)
);


endmodule