module fake_netlist_694_2606_n_26 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_26);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_26;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_25;
wire n_19;
wire n_14;

BUFx6f_ASAP7_75t_L g14 ( 
.A(n_1),
.Y(n_14)
);

BUFx2_ASAP7_75t_L g15 ( 
.A(n_4),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_7),
.Y(n_16)
);

BUFx10_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

OR2x6_ASAP7_75t_SL g18 ( 
.A(n_16),
.B(n_17),
.Y(n_18)
);

NOR2xp33_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_0),
.Y(n_19)
);

BUFx4f_ASAP7_75t_L g20 ( 
.A(n_18),
.Y(n_20)
);

HB1xp67_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

AOI22xp33_ASAP7_75t_L g22 ( 
.A1(n_21),
.A2(n_19),
.B1(n_14),
.B2(n_3),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_8),
.B1(n_6),
.B2(n_5),
.Y(n_23)
);

INVx1_ASAP7_75t_SL g24 ( 
.A(n_23),
.Y(n_24)
);

OAI22xp5_ASAP7_75t_SL g25 ( 
.A1(n_24),
.A2(n_11),
.B1(n_10),
.B2(n_9),
.Y(n_25)
);

OAI21xp5_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_13),
.B(n_12),
.Y(n_26)
);


endmodule