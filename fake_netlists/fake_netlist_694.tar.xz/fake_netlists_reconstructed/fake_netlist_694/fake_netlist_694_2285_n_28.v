module fake_netlist_694_2285_n_28 (n_4, n_2, n_3, n_1, n_0, n_28);

input n_4;
input n_2;
input n_3;
input n_1;
input n_0;

output n_28;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_6;
wire n_9;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_5;
wire n_7;
wire n_23;
wire n_12;
wire n_8;
wire n_11;
wire n_25;
wire n_10;
wire n_19;
wire n_14;
wire n_13;

NOR2xp33_ASAP7_75t_L g5 ( 
.A(n_0),
.B(n_2),
.Y(n_5)
);

INVx1_ASAP7_75t_L g6 ( 
.A(n_0),
.Y(n_6)
);

INVx4_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

CKINVDCx5p33_ASAP7_75t_R g8 ( 
.A(n_1),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_SL g9 ( 
.A(n_2),
.B(n_1),
.Y(n_9)
);

BUFx3_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

AOI21xp5_ASAP7_75t_L g12 ( 
.A1(n_9),
.A2(n_1),
.B(n_0),
.Y(n_12)
);

OAI21x1_ASAP7_75t_L g13 ( 
.A1(n_6),
.A2(n_5),
.B(n_7),
.Y(n_13)
);

INVxp67_ASAP7_75t_SL g14 ( 
.A(n_10),
.Y(n_14)
);

NAND2xp5_ASAP7_75t_L g15 ( 
.A(n_10),
.B(n_7),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

O2A1O1Ixp33_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_12),
.B(n_14),
.C(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_14),
.A2(n_13),
.B1(n_12),
.B2(n_16),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_16),
.Y(n_20)
);

OAI21xp5_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_13),
.B(n_11),
.Y(n_21)
);

INVx3_ASAP7_75t_SL g22 ( 
.A(n_18),
.Y(n_22)
);

NOR3x1_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_13),
.C(n_8),
.Y(n_23)
);

NOR2x1p5_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_17),
.Y(n_24)
);

NOR2x1_ASAP7_75t_L g25 ( 
.A(n_22),
.B(n_2),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_24),
.B(n_22),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_L g27 ( 
.A1(n_25),
.A2(n_3),
.B1(n_4),
.B2(n_23),
.Y(n_27)
);

AOI22xp33_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_4),
.B1(n_26),
.B2(n_22),
.Y(n_28)
);


endmodule