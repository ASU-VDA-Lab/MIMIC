module fake_netlist_694_1974_n_12 (n_3, n_0, n_2, n_1, n_12);

input n_3;
input n_0;
input n_2;
input n_1;

output n_12;

wire n_9;
wire n_4;
wire n_7;
wire n_11;
wire n_8;
wire n_10;
wire n_5;
wire n_6;

INVx2_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

BUFx8_ASAP7_75t_SL g5 ( 
.A(n_3),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B(n_0),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_7),
.Y(n_8)
);

AOI22xp33_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_6),
.B1(n_7),
.B2(n_5),
.Y(n_9)
);

INVx2_ASAP7_75t_SL g10 ( 
.A(n_9),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_SL g11 ( 
.A1(n_10),
.A2(n_3),
.B1(n_2),
.B2(n_1),
.Y(n_11)
);

AOI222xp33_ASAP7_75t_SL g12 ( 
.A1(n_11),
.A2(n_2),
.B1(n_3),
.B2(n_6),
.C1(n_4),
.C2(n_5),
.Y(n_12)
);


endmodule