module fake_netlist_694_1088_n_31 (n_9, n_4, n_2, n_7, n_14, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_31);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_31;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_26;
wire n_23;
wire n_29;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

HB1xp67_ASAP7_75t_L g15 ( 
.A(n_5),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_10),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_4),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_7),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_8),
.Y(n_19)
);

BUFx2_ASAP7_75t_L g20 ( 
.A(n_2),
.Y(n_20)
);

BUFx4f_ASAP7_75t_L g21 ( 
.A(n_20),
.Y(n_21)
);

OAI21xp5_ASAP7_75t_L g22 ( 
.A1(n_15),
.A2(n_17),
.B(n_19),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_18),
.Y(n_23)
);

OAI222xp33_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_16),
.B1(n_17),
.B2(n_22),
.C1(n_7),
.C2(n_6),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_24),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_25),
.B(n_6),
.Y(n_26)
);

INVxp33_ASAP7_75t_L g27 ( 
.A(n_26),
.Y(n_27)
);

AOI21xp33_ASAP7_75t_SL g28 ( 
.A1(n_26),
.A2(n_1),
.B(n_0),
.Y(n_28)
);

NOR3xp33_ASAP7_75t_SL g29 ( 
.A(n_27),
.B(n_9),
.C(n_3),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_L g30 ( 
.A(n_29),
.B(n_28),
.C(n_11),
.Y(n_30)
);

AOI22xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_31)
);


endmodule