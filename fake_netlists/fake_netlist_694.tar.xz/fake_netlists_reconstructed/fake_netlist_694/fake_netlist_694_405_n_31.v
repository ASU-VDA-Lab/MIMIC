module fake_netlist_694_405_n_31 (n_9, n_4, n_2, n_7, n_14, n_15, n_3, n_11, n_13, n_16, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_31);

input n_9;
input n_4;
input n_2;
input n_7;
input n_14;
input n_15;
input n_3;
input n_11;
input n_13;
input n_16;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_31;

wire n_24;
wire n_21;
wire n_27;
wire n_17;
wire n_22;
wire n_18;
wire n_20;
wire n_26;
wire n_23;
wire n_29;
wire n_28;
wire n_30;
wire n_25;
wire n_19;

INVx1_ASAP7_75t_L g17 ( 
.A(n_2),
.Y(n_17)
);

CKINVDCx5p33_ASAP7_75t_R g18 ( 
.A(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_16),
.Y(n_19)
);

NAND2xp5_ASAP7_75t_SL g20 ( 
.A(n_1),
.B(n_6),
.Y(n_20)
);

BUFx2_ASAP7_75t_L g21 ( 
.A(n_11),
.Y(n_21)
);

BUFx6f_ASAP7_75t_L g22 ( 
.A(n_3),
.Y(n_22)
);

NOR2xp33_ASAP7_75t_R g23 ( 
.A(n_18),
.B(n_4),
.Y(n_23)
);

OAI22xp5_ASAP7_75t_SL g24 ( 
.A1(n_19),
.A2(n_16),
.B1(n_6),
.B2(n_5),
.Y(n_24)
);

INVx2_ASAP7_75t_SL g25 ( 
.A(n_23),
.Y(n_25)
);

AOI22xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_21),
.B1(n_20),
.B2(n_24),
.Y(n_26)
);

A2O1A1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_26),
.A2(n_17),
.B(n_22),
.C(n_5),
.Y(n_27)
);

OAI221xp5_ASAP7_75t_L g28 ( 
.A1(n_27),
.A2(n_22),
.B1(n_8),
.B2(n_0),
.C(n_7),
.Y(n_28)
);

BUFx2_ASAP7_75t_L g29 ( 
.A(n_28),
.Y(n_29)
);

OAI22x1_ASAP7_75t_L g30 ( 
.A1(n_29),
.A2(n_22),
.B1(n_10),
.B2(n_9),
.Y(n_30)
);

AOI222xp33_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_22),
.B1(n_14),
.B2(n_12),
.C1(n_15),
.C2(n_13),
.Y(n_31)
);


endmodule