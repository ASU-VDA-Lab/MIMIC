module fake_netlist_694_365_n_18 (n_4, n_2, n_3, n_1, n_5, n_0, n_18);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;

output n_18;

wire n_9;
wire n_17;
wire n_7;
wire n_14;
wire n_15;
wire n_11;
wire n_16;
wire n_12;
wire n_8;
wire n_10;
wire n_6;
wire n_13;

INVx1_ASAP7_75t_L g6 ( 
.A(n_2),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_0),
.Y(n_7)
);

AOI22xp5_ASAP7_75t_L g8 ( 
.A1(n_4),
.A2(n_3),
.B1(n_5),
.B2(n_1),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_6),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_6),
.Y(n_10)
);

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_8),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_10),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_13),
.Y(n_14)
);

OAI21xp33_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_12),
.B(n_11),
.Y(n_15)
);

AND2x2_ASAP7_75t_L g16 ( 
.A(n_15),
.B(n_12),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);


endmodule