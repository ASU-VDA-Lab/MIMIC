module fake_netlist_694_1720_n_20 (n_4, n_2, n_7, n_3, n_1, n_5, n_0, n_6, n_20);

input n_4;
input n_2;
input n_7;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_20;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_8;
wire n_11;
wire n_19;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

OAI21xp33_ASAP7_75t_SL g8 ( 
.A1(n_1),
.A2(n_0),
.B(n_5),
.Y(n_8)
);

BUFx2_ASAP7_75t_L g9 ( 
.A(n_4),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_2),
.Y(n_10)
);

INVx8_ASAP7_75t_L g11 ( 
.A(n_7),
.Y(n_11)
);

OAI21x1_ASAP7_75t_L g12 ( 
.A1(n_10),
.A2(n_5),
.B(n_4),
.Y(n_12)
);

NAND2xp5_ASAP7_75t_SL g13 ( 
.A(n_8),
.B(n_6),
.Y(n_13)
);

AND2x2_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

A2O1A1Ixp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_8),
.B(n_12),
.C(n_11),
.Y(n_16)
);

NOR4xp75_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_11),
.C(n_12),
.D(n_6),
.Y(n_17)
);

BUFx2_ASAP7_75t_L g18 ( 
.A(n_17),
.Y(n_18)
);

OA21x2_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_7),
.B(n_3),
.Y(n_19)
);

AND2x2_ASAP7_75t_L g20 ( 
.A(n_18),
.B(n_19),
.Y(n_20)
);


endmodule