module fake_netlist_694_1637_n_19 (n_4, n_2, n_3, n_1, n_5, n_0, n_6, n_19);

input n_4;
input n_2;
input n_3;
input n_1;
input n_5;
input n_0;
input n_6;

output n_19;

wire n_17;
wire n_9;
wire n_18;
wire n_15;
wire n_16;
wire n_7;
wire n_8;
wire n_11;
wire n_10;
wire n_13;
wire n_14;
wire n_12;

INVx2_ASAP7_75t_SL g7 ( 
.A(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_3),
.Y(n_8)
);

NAND2xp5_ASAP7_75t_L g9 ( 
.A(n_0),
.B(n_1),
.Y(n_9)
);

INVx1_ASAP7_75t_L g10 ( 
.A(n_5),
.Y(n_10)
);

BUFx6f_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

BUFx2_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

NOR2x1p5_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_9),
.Y(n_13)
);

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_12),
.B(n_7),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_13),
.Y(n_15)
);

OAI21xp33_ASAP7_75t_L g16 ( 
.A1(n_15),
.A2(n_14),
.B(n_11),
.Y(n_16)
);

CKINVDCx20_ASAP7_75t_R g17 ( 
.A(n_16),
.Y(n_17)
);

OAI21xp5_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_9),
.B(n_6),
.Y(n_18)
);

AOI21xp33_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_6),
.B(n_2),
.Y(n_19)
);


endmodule