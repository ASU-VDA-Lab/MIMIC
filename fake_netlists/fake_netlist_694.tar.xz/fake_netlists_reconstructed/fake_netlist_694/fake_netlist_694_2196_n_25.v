module fake_netlist_694_2196_n_25 (n_9, n_4, n_2, n_7, n_3, n_11, n_13, n_8, n_1, n_10, n_5, n_0, n_6, n_12, n_25);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_11;
input n_13;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;
input n_12;

output n_25;

wire n_24;
wire n_21;
wire n_17;
wire n_22;
wire n_18;
wire n_15;
wire n_20;
wire n_16;
wire n_23;
wire n_19;
wire n_14;

CKINVDCx20_ASAP7_75t_R g14 ( 
.A(n_5),
.Y(n_14)
);

CKINVDCx5p33_ASAP7_75t_R g15 ( 
.A(n_1),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_2),
.Y(n_16)
);

CKINVDCx5p33_ASAP7_75t_R g17 ( 
.A(n_4),
.Y(n_17)
);

NAND2xp5_ASAP7_75t_L g18 ( 
.A(n_15),
.B(n_6),
.Y(n_18)
);

AOI21xp5_ASAP7_75t_L g19 ( 
.A1(n_18),
.A2(n_17),
.B(n_14),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_19),
.Y(n_20)
);

AOI22xp5_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_16),
.B1(n_7),
.B2(n_6),
.Y(n_21)
);

OAI211xp5_ASAP7_75t_SL g22 ( 
.A1(n_21),
.A2(n_7),
.B(n_3),
.C(n_0),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_SL g23 ( 
.A1(n_22),
.A2(n_10),
.B(n_9),
.C(n_8),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_23),
.Y(n_24)
);

OAI211xp5_ASAP7_75t_L g25 ( 
.A1(n_24),
.A2(n_13),
.B(n_12),
.C(n_11),
.Y(n_25)
);


endmodule