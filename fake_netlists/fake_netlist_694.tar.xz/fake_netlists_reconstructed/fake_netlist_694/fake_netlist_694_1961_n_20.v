module fake_netlist_694_1961_n_20 (n_9, n_4, n_2, n_7, n_3, n_8, n_1, n_10, n_5, n_0, n_6, n_20);

input n_9;
input n_4;
input n_2;
input n_7;
input n_3;
input n_8;
input n_1;
input n_10;
input n_5;
input n_0;
input n_6;

output n_20;

wire n_17;
wire n_18;
wire n_15;
wire n_16;
wire n_12;
wire n_11;
wire n_19;
wire n_14;
wire n_13;

BUFx2_ASAP7_75t_L g11 ( 
.A(n_3),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_5),
.Y(n_14)
);

OAI21xp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_1),
.B(n_0),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

AOI322xp5_ASAP7_75t_L g17 ( 
.A1(n_16),
.A2(n_12),
.A3(n_11),
.B1(n_14),
.B2(n_13),
.C1(n_0),
.C2(n_1),
.Y(n_17)
);

OAI222xp33_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_14),
.B1(n_11),
.B2(n_13),
.C1(n_6),
.C2(n_4),
.Y(n_18)
);

NAND4xp25_ASAP7_75t_L g19 ( 
.A(n_18),
.B(n_7),
.C(n_6),
.D(n_4),
.Y(n_19)
);

AOI222xp33_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_18),
.B1(n_7),
.B2(n_10),
.C1(n_8),
.C2(n_2),
.Y(n_20)
);


endmodule