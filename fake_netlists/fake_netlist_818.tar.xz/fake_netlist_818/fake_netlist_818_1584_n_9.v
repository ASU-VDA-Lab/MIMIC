module fake_netlist_818_1584_n_9 (n_2, n_0, n_3, n_1, n_9);

input n_2;
input n_0;
input n_3;
input n_1;

output n_9;

wire n_6;
wire n_4;
wire n_7;
wire n_5;
wire n_8;

OA21x2_ASAP7_75t_L g4 ( 
.A1(n_3),
.A2(n_1),
.B(n_0),
.Y(n_4)
);

BUFx2_ASAP7_75t_L g5 ( 
.A(n_2),
.Y(n_5)
);

NAND3xp33_ASAP7_75t_L g6 ( 
.A(n_0),
.B(n_2),
.C(n_1),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_4),
.B(n_8),
.Y(n_9)
);


endmodule