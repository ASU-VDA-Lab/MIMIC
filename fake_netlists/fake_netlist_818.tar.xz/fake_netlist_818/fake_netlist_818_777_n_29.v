module fake_netlist_818_777_n_29 (n_6, n_4, n_7, n_2, n_5, n_3, n_9, n_0, n_8, n_1, n_29);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_0;
input n_8;
input n_1;

output n_29;

wire n_25;
wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_28;
wire n_26;
wire n_24;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_21;
wire n_16;
wire n_11;
wire n_27;

INVx2_ASAP7_75t_L g10 ( 
.A(n_8),
.Y(n_10)
);

CKINVDCx5p33_ASAP7_75t_R g11 ( 
.A(n_8),
.Y(n_11)
);

INVx2_ASAP7_75t_L g12 ( 
.A(n_7),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_1),
.Y(n_13)
);

HB1xp67_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

AOI21xp5_ASAP7_75t_L g15 ( 
.A1(n_12),
.A2(n_1),
.B(n_0),
.Y(n_15)
);

OAI21xp33_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_1),
.B(n_0),
.Y(n_16)
);

NAND2xp33_ASAP7_75t_SL g17 ( 
.A(n_16),
.B(n_14),
.Y(n_17)
);

OAI22xp5_ASAP7_75t_L g18 ( 
.A1(n_15),
.A2(n_13),
.B1(n_11),
.B2(n_10),
.Y(n_18)
);

INVx2_ASAP7_75t_L g19 ( 
.A(n_18),
.Y(n_19)
);

NAND2x1p5_ASAP7_75t_L g20 ( 
.A(n_17),
.B(n_0),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_19),
.B(n_2),
.Y(n_21)
);

NAND4xp25_ASAP7_75t_L g22 ( 
.A(n_20),
.B(n_4),
.C(n_3),
.D(n_2),
.Y(n_22)
);

OAI211xp5_ASAP7_75t_SL g23 ( 
.A1(n_21),
.A2(n_20),
.B(n_3),
.C(n_2),
.Y(n_23)
);

AOI221xp5_ASAP7_75t_L g24 ( 
.A1(n_22),
.A2(n_5),
.B1(n_4),
.B2(n_6),
.C(n_7),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_4),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_23),
.Y(n_26)
);

OAI22xp5_ASAP7_75t_SL g27 ( 
.A1(n_26),
.A2(n_7),
.B1(n_6),
.B2(n_5),
.Y(n_27)
);

AO22x2_ASAP7_75t_L g28 ( 
.A1(n_25),
.A2(n_6),
.B1(n_5),
.B2(n_9),
.Y(n_28)
);

AOI22xp33_ASAP7_75t_L g29 ( 
.A1(n_27),
.A2(n_28),
.B1(n_22),
.B2(n_24),
.Y(n_29)
);


endmodule