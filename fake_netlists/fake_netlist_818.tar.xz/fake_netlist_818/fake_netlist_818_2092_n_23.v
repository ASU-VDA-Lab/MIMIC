module fake_netlist_818_2092_n_23 (n_6, n_4, n_7, n_2, n_5, n_3, n_0, n_8, n_1, n_23);

input n_6;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_0;
input n_8;
input n_1;

output n_23;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_9;
wire n_19;
wire n_12;
wire n_18;
wire n_10;
wire n_16;
wire n_21;
wire n_11;

CKINVDCx5p33_ASAP7_75t_R g9 ( 
.A(n_5),
.Y(n_9)
);

CKINVDCx20_ASAP7_75t_R g10 ( 
.A(n_8),
.Y(n_10)
);

CKINVDCx20_ASAP7_75t_R g11 ( 
.A(n_7),
.Y(n_11)
);

CKINVDCx5p33_ASAP7_75t_R g12 ( 
.A(n_1),
.Y(n_12)
);

O2A1O1Ixp33_ASAP7_75t_L g13 ( 
.A1(n_10),
.A2(n_4),
.B(n_3),
.C(n_0),
.Y(n_13)
);

AOI21xp5_ASAP7_75t_L g14 ( 
.A1(n_9),
.A2(n_3),
.B(n_0),
.Y(n_14)
);

OR2x2_ASAP7_75t_L g15 ( 
.A(n_12),
.B(n_0),
.Y(n_15)
);

O2A1O1Ixp5_ASAP7_75t_L g16 ( 
.A1(n_14),
.A2(n_15),
.B(n_13),
.C(n_12),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

AO21x1_ASAP7_75t_L g18 ( 
.A1(n_17),
.A2(n_16),
.B(n_4),
.Y(n_18)
);

INVx1_ASAP7_75t_L g19 ( 
.A(n_17),
.Y(n_19)
);

AO221x1_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_11),
.B1(n_6),
.B2(n_4),
.C(n_5),
.Y(n_20)
);

NAND2xp5_ASAP7_75t_SL g21 ( 
.A(n_20),
.B(n_18),
.Y(n_21)
);

HB1xp67_ASAP7_75t_L g22 ( 
.A(n_21),
.Y(n_22)
);

AOI22xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_8),
.B1(n_7),
.B2(n_2),
.Y(n_23)
);


endmodule