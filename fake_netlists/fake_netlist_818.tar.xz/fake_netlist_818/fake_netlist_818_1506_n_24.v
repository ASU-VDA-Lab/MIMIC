module fake_netlist_818_1506_n_24 (n_6, n_10, n_4, n_7, n_2, n_5, n_3, n_9, n_11, n_0, n_8, n_1, n_24);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_5;
input n_3;
input n_9;
input n_11;
input n_0;
input n_8;
input n_1;

output n_24;

wire n_20;
wire n_15;
wire n_13;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_19;
wire n_12;
wire n_18;
wire n_16;
wire n_21;

NAND2xp5_ASAP7_75t_L g12 ( 
.A(n_1),
.B(n_9),
.Y(n_12)
);

INVx1_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AO21x2_ASAP7_75t_L g14 ( 
.A1(n_7),
.A2(n_5),
.B(n_6),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_1),
.B(n_5),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_6),
.Y(n_16)
);

OAI21x1_ASAP7_75t_L g17 ( 
.A1(n_13),
.A2(n_3),
.B(n_2),
.Y(n_17)
);

AOI211x1_ASAP7_75t_L g18 ( 
.A1(n_16),
.A2(n_10),
.B(n_8),
.C(n_0),
.Y(n_18)
);

AOI22xp33_ASAP7_75t_L g19 ( 
.A1(n_17),
.A2(n_16),
.B1(n_14),
.B2(n_15),
.Y(n_19)
);

AND2x4_ASAP7_75t_SL g20 ( 
.A(n_19),
.B(n_15),
.Y(n_20)
);

OAI21xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_12),
.B(n_17),
.Y(n_21)
);

NAND3xp33_ASAP7_75t_L g22 ( 
.A(n_21),
.B(n_18),
.C(n_14),
.Y(n_22)
);

AO22x1_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_14),
.B1(n_4),
.B2(n_0),
.Y(n_23)
);

AOI22x1_ASAP7_75t_L g24 ( 
.A1(n_23),
.A2(n_4),
.B1(n_7),
.B2(n_13),
.Y(n_24)
);


endmodule