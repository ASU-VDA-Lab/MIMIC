module fake_netlist_818_2950_n_14 (n_2, n_0, n_3, n_1, n_14);

input n_2;
input n_0;
input n_3;
input n_1;

output n_14;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_13;
wire n_5;
wire n_9;
wire n_11;
wire n_12;
wire n_8;

INVx1_ASAP7_75t_L g4 ( 
.A(n_2),
.Y(n_4)
);

NAND2xp5_ASAP7_75t_SL g5 ( 
.A(n_3),
.B(n_1),
.Y(n_5)
);

INVx3_ASAP7_75t_L g6 ( 
.A(n_4),
.Y(n_6)
);

O2A1O1Ixp33_ASAP7_75t_SL g7 ( 
.A1(n_4),
.A2(n_2),
.B(n_1),
.C(n_0),
.Y(n_7)
);

HB1xp67_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

AOI221x1_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_6),
.B1(n_7),
.B2(n_5),
.C(n_0),
.Y(n_10)
);

OAI221xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_6),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_11)
);

HB1xp67_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

BUFx8_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

AOI22xp33_ASAP7_75t_R g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_3),
.B2(n_6),
.Y(n_14)
);


endmodule