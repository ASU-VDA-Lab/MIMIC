module fake_netlist_818_713_n_12 (n_2, n_0, n_3, n_1, n_12);

input n_2;
input n_0;
input n_3;
input n_1;

output n_12;

wire n_6;
wire n_10;
wire n_4;
wire n_7;
wire n_5;
wire n_9;
wire n_11;
wire n_8;

INVx3_ASAP7_75t_L g4 ( 
.A(n_0),
.Y(n_4)
);

BUFx6f_ASAP7_75t_L g5 ( 
.A(n_3),
.Y(n_5)
);

AOI22xp5_ASAP7_75t_L g6 ( 
.A1(n_4),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_6)
);

NAND3xp33_ASAP7_75t_L g7 ( 
.A(n_4),
.B(n_1),
.C(n_2),
.Y(n_7)
);

NAND3xp33_ASAP7_75t_L g8 ( 
.A(n_7),
.B(n_5),
.C(n_4),
.Y(n_8)
);

AOI21xp5_ASAP7_75t_L g9 ( 
.A1(n_8),
.A2(n_5),
.B(n_6),
.Y(n_9)
);

OAI221xp5_ASAP7_75t_SL g10 ( 
.A1(n_9),
.A2(n_1),
.B1(n_3),
.B2(n_5),
.C(n_6),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

CKINVDCx20_ASAP7_75t_R g12 ( 
.A(n_11),
.Y(n_12)
);


endmodule