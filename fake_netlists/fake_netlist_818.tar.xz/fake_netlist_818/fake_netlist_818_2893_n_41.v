module fake_netlist_818_2893_n_41 (n_6, n_10, n_4, n_7, n_2, n_13, n_5, n_3, n_9, n_11, n_12, n_0, n_8, n_1, n_41);

input n_6;
input n_10;
input n_4;
input n_7;
input n_2;
input n_13;
input n_5;
input n_3;
input n_9;
input n_11;
input n_12;
input n_0;
input n_8;
input n_1;

output n_41;

wire n_25;
wire n_20;
wire n_15;
wire n_36;
wire n_17;
wire n_14;
wire n_22;
wire n_23;
wire n_34;
wire n_40;
wire n_28;
wire n_39;
wire n_31;
wire n_32;
wire n_26;
wire n_24;
wire n_37;
wire n_19;
wire n_33;
wire n_29;
wire n_30;
wire n_18;
wire n_16;
wire n_21;
wire n_35;
wire n_38;
wire n_27;

NAND2xp5_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_9),
.Y(n_14)
);

CKINVDCx20_ASAP7_75t_R g15 ( 
.A(n_10),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_3),
.Y(n_16)
);

NOR2xp33_ASAP7_75t_R g17 ( 
.A(n_7),
.B(n_5),
.Y(n_17)
);

INVx2_ASAP7_75t_L g18 ( 
.A(n_1),
.Y(n_18)
);

AND3x2_ASAP7_75t_L g19 ( 
.A(n_3),
.B(n_11),
.C(n_12),
.Y(n_19)
);

INVx2_ASAP7_75t_L g20 ( 
.A(n_10),
.Y(n_20)
);

NAND2xp33_ASAP7_75t_R g21 ( 
.A(n_5),
.B(n_1),
.Y(n_21)
);

A2O1A1Ixp33_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_4),
.B(n_2),
.C(n_0),
.Y(n_22)
);

NAND2xp5_ASAP7_75t_L g23 ( 
.A(n_16),
.B(n_0),
.Y(n_23)
);

OAI21x1_ASAP7_75t_SL g24 ( 
.A1(n_20),
.A2(n_4),
.B(n_2),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_20),
.Y(n_25)
);

OR2x2_ASAP7_75t_L g26 ( 
.A(n_23),
.B(n_16),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_25),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_25),
.B(n_18),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_22),
.Y(n_29)
);

AND2x2_ASAP7_75t_L g30 ( 
.A(n_26),
.B(n_18),
.Y(n_30)
);

AOI211xp5_ASAP7_75t_L g31 ( 
.A1(n_29),
.A2(n_17),
.B(n_28),
.C(n_14),
.Y(n_31)
);

OAI22xp33_ASAP7_75t_L g32 ( 
.A1(n_30),
.A2(n_15),
.B1(n_21),
.B2(n_27),
.Y(n_32)
);

OAI221xp5_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_30),
.B1(n_24),
.B2(n_19),
.C(n_6),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_32),
.B(n_24),
.Y(n_34)
);

OAI221xp5_ASAP7_75t_L g35 ( 
.A1(n_31),
.A2(n_7),
.B1(n_6),
.B2(n_8),
.C(n_9),
.Y(n_35)
);

BUFx2_ASAP7_75t_L g36 ( 
.A(n_34),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_35),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_33),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

CKINVDCx20_ASAP7_75t_R g40 ( 
.A(n_37),
.Y(n_40)
);

AOI221xp5_ASAP7_75t_SL g41 ( 
.A1(n_39),
.A2(n_38),
.B1(n_35),
.B2(n_40),
.C(n_34),
.Y(n_41)
);


endmodule