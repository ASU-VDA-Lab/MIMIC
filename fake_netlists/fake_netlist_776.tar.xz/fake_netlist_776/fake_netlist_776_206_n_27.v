module fake_netlist_776_206_n_27 (n_1, n_7, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_27);

input n_1;
input n_7;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_27;

wire n_20;
wire n_17;
wire n_12;
wire n_25;
wire n_24;
wire n_26;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_23;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_SL g10 ( 
.A(n_7),
.Y(n_10)
);

INVx1_ASAP7_75t_L g11 ( 
.A(n_8),
.Y(n_11)
);

INVx4_ASAP7_75t_L g12 ( 
.A(n_5),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_9),
.Y(n_13)
);

INVx3_ASAP7_75t_L g14 ( 
.A(n_3),
.Y(n_14)
);

INVx1_ASAP7_75t_L g15 ( 
.A(n_11),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_14),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_11),
.A2(n_6),
.B(n_4),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_15),
.Y(n_18)
);

OR2x2_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_10),
.Y(n_19)
);

NOR2x2_ASAP7_75t_L g20 ( 
.A(n_19),
.B(n_17),
.Y(n_20)
);

NOR3x1_ASAP7_75t_L g21 ( 
.A(n_18),
.B(n_10),
.C(n_4),
.Y(n_21)
);

AOI221xp5_ASAP7_75t_L g22 ( 
.A1(n_20),
.A2(n_16),
.B1(n_13),
.B2(n_14),
.C(n_12),
.Y(n_22)
);

NAND4xp25_ASAP7_75t_L g23 ( 
.A(n_21),
.B(n_16),
.C(n_13),
.D(n_14),
.Y(n_23)
);

NOR3x1_ASAP7_75t_L g24 ( 
.A(n_23),
.B(n_7),
.C(n_6),
.Y(n_24)
);

HB1xp67_ASAP7_75t_L g25 ( 
.A(n_22),
.Y(n_25)
);

AOI221xp5_ASAP7_75t_L g26 ( 
.A1(n_24),
.A2(n_12),
.B1(n_2),
.B2(n_0),
.C(n_1),
.Y(n_26)
);

NAND2xp5_ASAP7_75t_L g27 ( 
.A(n_26),
.B(n_25),
.Y(n_27)
);


endmodule