module fake_netlist_776_1196_n_45 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_45);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_45;

wire n_37;
wire n_44;
wire n_20;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_43;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_21;
wire n_41;
wire n_32;
wire n_22;

INVx1_ASAP7_75t_L g20 ( 
.A(n_13),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_6),
.Y(n_21)
);

INVx1_ASAP7_75t_L g22 ( 
.A(n_11),
.Y(n_22)
);

AND2x2_ASAP7_75t_L g23 ( 
.A(n_10),
.B(n_9),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_15),
.Y(n_24)
);

INVx1_ASAP7_75t_L g25 ( 
.A(n_19),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_3),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_8),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_7),
.B(n_16),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_24),
.B(n_16),
.Y(n_29)
);

NOR3xp33_ASAP7_75t_SL g30 ( 
.A(n_25),
.B(n_19),
.C(n_18),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_20),
.Y(n_31)
);

AOI22xp33_ASAP7_75t_L g32 ( 
.A1(n_29),
.A2(n_24),
.B1(n_23),
.B2(n_28),
.Y(n_32)
);

NAND2xp33_ASAP7_75t_SL g33 ( 
.A(n_30),
.B(n_26),
.Y(n_33)
);

AOI22xp33_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_31),
.B1(n_27),
.B2(n_22),
.Y(n_34)
);

AND2x2_ASAP7_75t_L g35 ( 
.A(n_33),
.B(n_31),
.Y(n_35)
);

OR2x2_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_26),
.Y(n_36)
);

HB1xp67_ASAP7_75t_L g37 ( 
.A(n_34),
.Y(n_37)
);

NAND2xp5_ASAP7_75t_L g38 ( 
.A(n_37),
.B(n_21),
.Y(n_38)
);

NOR2xp33_ASAP7_75t_SL g39 ( 
.A(n_36),
.B(n_18),
.Y(n_39)
);

AOI22xp33_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_2),
.B1(n_1),
.B2(n_0),
.Y(n_40)
);

NOR2xp33_ASAP7_75t_R g41 ( 
.A(n_38),
.B(n_4),
.Y(n_41)
);

INVx1_ASAP7_75t_SL g42 ( 
.A(n_41),
.Y(n_42)
);

BUFx2_ASAP7_75t_L g43 ( 
.A(n_40),
.Y(n_43)
);

NAND4xp25_ASAP7_75t_SL g44 ( 
.A(n_42),
.B(n_14),
.C(n_12),
.D(n_5),
.Y(n_44)
);

AOI22xp5_ASAP7_75t_SL g45 ( 
.A1(n_44),
.A2(n_17),
.B1(n_43),
.B2(n_42),
.Y(n_45)
);


endmodule