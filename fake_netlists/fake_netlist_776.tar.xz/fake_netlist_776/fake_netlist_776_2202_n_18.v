module fake_netlist_776_2202_n_18 (n_1, n_0, n_5, n_3, n_2, n_4, n_18);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_18;

wire n_7;
wire n_10;
wire n_15;
wire n_11;
wire n_16;
wire n_6;
wire n_14;
wire n_8;
wire n_17;
wire n_12;
wire n_13;
wire n_9;

NAND2xp5_ASAP7_75t_L g6 ( 
.A(n_5),
.B(n_4),
.Y(n_6)
);

INVx2_ASAP7_75t_L g7 ( 
.A(n_2),
.Y(n_7)
);

INVxp33_ASAP7_75t_L g8 ( 
.A(n_1),
.Y(n_8)
);

AOI31xp67_ASAP7_75t_L g9 ( 
.A1(n_7),
.A2(n_5),
.A3(n_3),
.B(n_0),
.Y(n_9)
);

INVx5_ASAP7_75t_L g10 ( 
.A(n_7),
.Y(n_10)
);

BUFx3_ASAP7_75t_L g11 ( 
.A(n_10),
.Y(n_11)
);

INVxp67_ASAP7_75t_L g12 ( 
.A(n_10),
.Y(n_12)
);

INVx2_ASAP7_75t_L g13 ( 
.A(n_11),
.Y(n_13)
);

NAND2xp33_ASAP7_75t_L g14 ( 
.A(n_13),
.B(n_6),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_14),
.Y(n_15)
);

CKINVDCx5p33_ASAP7_75t_R g16 ( 
.A(n_14),
.Y(n_16)
);

OAI21xp5_ASAP7_75t_L g17 ( 
.A1(n_15),
.A2(n_9),
.B(n_8),
.Y(n_17)
);

NAND3xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.C(n_12),
.Y(n_18)
);


endmodule