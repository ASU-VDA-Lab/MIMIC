module fake_netlist_776_1060_n_63 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_63);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_63;

wire n_37;
wire n_45;
wire n_44;
wire n_55;
wire n_47;
wire n_52;
wire n_29;
wire n_36;
wire n_62;
wire n_50;
wire n_58;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_24;
wire n_26;
wire n_42;
wire n_49;
wire n_48;
wire n_43;
wire n_56;
wire n_38;
wire n_54;
wire n_61;
wire n_60;
wire n_23;
wire n_57;
wire n_28;
wire n_30;
wire n_59;
wire n_53;
wire n_41;
wire n_21;
wire n_51;
wire n_32;
wire n_22;

BUFx6f_ASAP7_75t_L g21 ( 
.A(n_9),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_18),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_7),
.Y(n_23)
);

INVx2_ASAP7_75t_L g24 ( 
.A(n_19),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_0),
.B(n_14),
.Y(n_25)
);

INVx2_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

INVx3_ASAP7_75t_L g27 ( 
.A(n_2),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_5),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_4),
.B(n_19),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_15),
.Y(n_30)
);

NAND2x1p5_ASAP7_75t_L g31 ( 
.A(n_22),
.B(n_1),
.Y(n_31)
);

NOR3xp33_ASAP7_75t_SL g32 ( 
.A(n_29),
.B(n_2),
.C(n_0),
.Y(n_32)
);

INVxp67_ASAP7_75t_L g33 ( 
.A(n_24),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_22),
.B(n_3),
.Y(n_34)
);

OR2x2_ASAP7_75t_L g35 ( 
.A(n_27),
.B(n_3),
.Y(n_35)
);

OAI21x1_ASAP7_75t_L g36 ( 
.A1(n_31),
.A2(n_34),
.B(n_35),
.Y(n_36)
);

OAI21x1_ASAP7_75t_L g37 ( 
.A1(n_31),
.A2(n_29),
.B(n_25),
.Y(n_37)
);

AO31x2_ASAP7_75t_L g38 ( 
.A1(n_32),
.A2(n_26),
.A3(n_28),
.B(n_30),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_36),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_37),
.Y(n_40)
);

AND2x2_ASAP7_75t_L g41 ( 
.A(n_38),
.B(n_33),
.Y(n_41)
);

AND2x2_ASAP7_75t_L g42 ( 
.A(n_41),
.B(n_37),
.Y(n_42)
);

INVx1_ASAP7_75t_L g43 ( 
.A(n_39),
.Y(n_43)
);

NAND2xp5_ASAP7_75t_SL g44 ( 
.A(n_41),
.B(n_25),
.Y(n_44)
);

INVx2_ASAP7_75t_L g45 ( 
.A(n_43),
.Y(n_45)
);

OAI21xp33_ASAP7_75t_L g46 ( 
.A1(n_44),
.A2(n_26),
.B(n_27),
.Y(n_46)
);

AOI22xp5_ASAP7_75t_L g47 ( 
.A1(n_42),
.A2(n_40),
.B1(n_23),
.B2(n_21),
.Y(n_47)
);

NAND2xp5_ASAP7_75t_L g48 ( 
.A(n_42),
.B(n_38),
.Y(n_48)
);

AOI21xp5_ASAP7_75t_L g49 ( 
.A1(n_46),
.A2(n_40),
.B(n_43),
.Y(n_49)
);

AOI321xp33_ASAP7_75t_L g50 ( 
.A1(n_47),
.A2(n_38),
.A3(n_20),
.B1(n_16),
.B2(n_17),
.C(n_21),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_45),
.Y(n_51)
);

INVx2_ASAP7_75t_L g52 ( 
.A(n_48),
.Y(n_52)
);

NOR4xp25_ASAP7_75t_L g53 ( 
.A(n_50),
.B(n_38),
.C(n_17),
.D(n_16),
.Y(n_53)
);

INVxp67_ASAP7_75t_L g54 ( 
.A(n_51),
.Y(n_54)
);

INVx1_ASAP7_75t_L g55 ( 
.A(n_49),
.Y(n_55)
);

INVx1_ASAP7_75t_L g56 ( 
.A(n_52),
.Y(n_56)
);

OAI22xp5_ASAP7_75t_SL g57 ( 
.A1(n_49),
.A2(n_21),
.B1(n_20),
.B2(n_6),
.Y(n_57)
);

HB1xp67_ASAP7_75t_L g58 ( 
.A(n_56),
.Y(n_58)
);

NOR3xp33_ASAP7_75t_SL g59 ( 
.A(n_57),
.B(n_10),
.C(n_8),
.Y(n_59)
);

INVx1_ASAP7_75t_L g60 ( 
.A(n_55),
.Y(n_60)
);

OR3x1_ASAP7_75t_L g61 ( 
.A(n_60),
.B(n_53),
.C(n_55),
.Y(n_61)
);

OAI22x1_ASAP7_75t_L g62 ( 
.A1(n_58),
.A2(n_54),
.B1(n_21),
.B2(n_11),
.Y(n_62)
);

AOI222xp33_ASAP7_75t_L g63 ( 
.A1(n_62),
.A2(n_12),
.B1(n_13),
.B2(n_59),
.C1(n_60),
.C2(n_61),
.Y(n_63)
);


endmodule