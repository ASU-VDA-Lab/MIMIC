module fake_netlist_776_2359_n_12 (n_1, n_2, n_0, n_12);

input n_1;
input n_2;
input n_0;

output n_12;

wire n_7;
wire n_10;
wire n_11;
wire n_5;
wire n_6;
wire n_3;
wire n_8;
wire n_4;
wire n_9;

INVx2_ASAP7_75t_SL g3 ( 
.A(n_2),
.Y(n_3)
);

INVx1_ASAP7_75t_SL g4 ( 
.A(n_0),
.Y(n_4)
);

OAI21x1_ASAP7_75t_L g5 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_5)
);

OAI21x1_ASAP7_75t_L g6 ( 
.A1(n_3),
.A2(n_2),
.B(n_0),
.Y(n_6)
);

AND2x2_ASAP7_75t_L g7 ( 
.A(n_5),
.B(n_4),
.Y(n_7)
);

INVx2_ASAP7_75t_L g8 ( 
.A(n_6),
.Y(n_8)
);

INVx1_ASAP7_75t_L g9 ( 
.A(n_7),
.Y(n_9)
);

OA22x2_ASAP7_75t_L g10 ( 
.A1(n_9),
.A2(n_4),
.B1(n_6),
.B2(n_8),
.Y(n_10)
);

OAI22xp5_ASAP7_75t_L g11 ( 
.A1(n_10),
.A2(n_9),
.B1(n_8),
.B2(n_1),
.Y(n_11)
);

AOI22xp5_ASAP7_75t_L g12 ( 
.A1(n_11),
.A2(n_1),
.B1(n_2),
.B2(n_9),
.Y(n_12)
);


endmodule