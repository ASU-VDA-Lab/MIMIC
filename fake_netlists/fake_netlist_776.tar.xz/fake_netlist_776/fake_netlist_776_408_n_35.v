module fake_netlist_776_408_n_35 (n_1, n_7, n_10, n_15, n_0, n_11, n_5, n_16, n_6, n_14, n_3, n_17, n_9, n_2, n_12, n_13, n_4, n_8, n_35);

input n_1;
input n_7;
input n_10;
input n_15;
input n_0;
input n_11;
input n_5;
input n_16;
input n_6;
input n_14;
input n_3;
input n_17;
input n_9;
input n_2;
input n_12;
input n_13;
input n_4;
input n_8;

output n_35;

wire n_20;
wire n_29;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_33;
wire n_26;
wire n_24;
wire n_18;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

NOR2xp33_ASAP7_75t_R g18 ( 
.A(n_15),
.B(n_10),
.Y(n_18)
);

CKINVDCx5p33_ASAP7_75t_R g19 ( 
.A(n_9),
.Y(n_19)
);

CKINVDCx20_ASAP7_75t_R g20 ( 
.A(n_2),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_15),
.Y(n_21)
);

CKINVDCx20_ASAP7_75t_R g22 ( 
.A(n_12),
.Y(n_22)
);

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_3),
.Y(n_23)
);

INVxp33_ASAP7_75t_SL g24 ( 
.A(n_0),
.Y(n_24)
);

AND2x4_ASAP7_75t_L g25 ( 
.A(n_21),
.B(n_1),
.Y(n_25)
);

HB1xp67_ASAP7_75t_L g26 ( 
.A(n_18),
.Y(n_26)
);

INVx2_ASAP7_75t_L g27 ( 
.A(n_19),
.Y(n_27)
);

NAND2xp5_ASAP7_75t_L g28 ( 
.A(n_27),
.B(n_23),
.Y(n_28)
);

AND2x2_ASAP7_75t_L g29 ( 
.A(n_26),
.B(n_20),
.Y(n_29)
);

BUFx2_ASAP7_75t_L g30 ( 
.A(n_29),
.Y(n_30)
);

AOI22xp5_ASAP7_75t_L g31 ( 
.A1(n_30),
.A2(n_28),
.B1(n_22),
.B2(n_25),
.Y(n_31)
);

AOI221x1_ASAP7_75t_L g32 ( 
.A1(n_31),
.A2(n_24),
.B1(n_18),
.B2(n_4),
.C(n_5),
.Y(n_32)
);

BUFx2_ASAP7_75t_L g33 ( 
.A(n_32),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_33),
.A2(n_8),
.B1(n_7),
.B2(n_6),
.Y(n_34)
);

AOI222xp33_ASAP7_75t_L g35 ( 
.A1(n_34),
.A2(n_13),
.B1(n_11),
.B2(n_14),
.C1(n_17),
.C2(n_16),
.Y(n_35)
);


endmodule