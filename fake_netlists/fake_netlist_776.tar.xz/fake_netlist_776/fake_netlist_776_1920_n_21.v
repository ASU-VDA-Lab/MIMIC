module fake_netlist_776_1920_n_21 (n_1, n_7, n_10, n_0, n_5, n_6, n_3, n_9, n_2, n_4, n_8, n_21);

input n_1;
input n_7;
input n_10;
input n_0;
input n_5;
input n_6;
input n_3;
input n_9;
input n_2;
input n_4;
input n_8;

output n_21;

wire n_20;
wire n_17;
wire n_12;
wire n_13;
wire n_18;
wire n_15;
wire n_11;
wire n_16;
wire n_19;
wire n_14;

INVx1_ASAP7_75t_L g11 ( 
.A(n_0),
.Y(n_11)
);

BUFx10_ASAP7_75t_L g12 ( 
.A(n_4),
.Y(n_12)
);

CKINVDCx5p33_ASAP7_75t_R g13 ( 
.A(n_7),
.Y(n_13)
);

A2O1A1Ixp33_ASAP7_75t_L g14 ( 
.A1(n_11),
.A2(n_3),
.B(n_2),
.C(n_1),
.Y(n_14)
);

AND2x2_ASAP7_75t_L g15 ( 
.A(n_14),
.B(n_12),
.Y(n_15)
);

INVx1_ASAP7_75t_L g16 ( 
.A(n_15),
.Y(n_16)
);

NAND2xp5_ASAP7_75t_L g17 ( 
.A(n_16),
.B(n_15),
.Y(n_17)
);

NOR2xp33_ASAP7_75t_L g18 ( 
.A(n_17),
.B(n_16),
.Y(n_18)
);

CKINVDCx16_ASAP7_75t_R g19 ( 
.A(n_18),
.Y(n_19)
);

OAI22xp5_ASAP7_75t_L g20 ( 
.A1(n_19),
.A2(n_13),
.B1(n_12),
.B2(n_3),
.Y(n_20)
);

AOI222xp33_ASAP7_75t_L g21 ( 
.A1(n_20),
.A2(n_6),
.B1(n_5),
.B2(n_10),
.C1(n_9),
.C2(n_8),
.Y(n_21)
);


endmodule