module fake_netlist_776_1352_n_40 (n_0, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_3, n_14, n_40);

input n_0;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_3;
input n_14;

output n_40;

wire n_37;
wire n_20;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_24;
wire n_26;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_19;
wire n_21;
wire n_32;
wire n_22;

INVx2_ASAP7_75t_L g19 ( 
.A(n_8),
.Y(n_19)
);

INVx1_ASAP7_75t_L g20 ( 
.A(n_5),
.Y(n_20)
);

CKINVDCx5p33_ASAP7_75t_R g21 ( 
.A(n_14),
.Y(n_21)
);

INVx3_ASAP7_75t_L g22 ( 
.A(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_1),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_11),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_14),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_0),
.Y(n_26)
);

O2A1O1Ixp33_ASAP7_75t_L g27 ( 
.A1(n_22),
.A2(n_16),
.B(n_15),
.C(n_13),
.Y(n_27)
);

AND2x2_ASAP7_75t_SL g28 ( 
.A(n_22),
.B(n_13),
.Y(n_28)
);

NOR3xp33_ASAP7_75t_SL g29 ( 
.A(n_21),
.B(n_25),
.C(n_20),
.Y(n_29)
);

INVx2_ASAP7_75t_L g30 ( 
.A(n_28),
.Y(n_30)
);

O2A1O1Ixp33_ASAP7_75t_SL g31 ( 
.A1(n_27),
.A2(n_23),
.B(n_19),
.C(n_15),
.Y(n_31)
);

OR2x2_ASAP7_75t_L g32 ( 
.A(n_30),
.B(n_19),
.Y(n_32)
);

AND2x2_ASAP7_75t_L g33 ( 
.A(n_31),
.B(n_28),
.Y(n_33)
);

OAI22xp5_ASAP7_75t_L g34 ( 
.A1(n_32),
.A2(n_29),
.B1(n_23),
.B2(n_24),
.Y(n_34)
);

OAI21xp5_ASAP7_75t_L g35 ( 
.A1(n_33),
.A2(n_26),
.B(n_2),
.Y(n_35)
);

AOI221xp5_ASAP7_75t_L g36 ( 
.A1(n_34),
.A2(n_4),
.B1(n_3),
.B2(n_6),
.C(n_7),
.Y(n_36)
);

INVx1_ASAP7_75t_SL g37 ( 
.A(n_35),
.Y(n_37)
);

NOR4xp75_ASAP7_75t_L g38 ( 
.A(n_36),
.B(n_37),
.C(n_10),
.D(n_9),
.Y(n_38)
);

INVx1_ASAP7_75t_L g39 ( 
.A(n_38),
.Y(n_39)
);

AOI22xp5_ASAP7_75t_L g40 ( 
.A1(n_39),
.A2(n_18),
.B1(n_17),
.B2(n_12),
.Y(n_40)
);


endmodule