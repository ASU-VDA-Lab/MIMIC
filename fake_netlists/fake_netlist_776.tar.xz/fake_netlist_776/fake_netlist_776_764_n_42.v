module fake_netlist_776_764_n_42 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_14, n_42);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_14;

output n_42;

wire n_37;
wire n_29;
wire n_36;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_26;
wire n_24;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_41;
wire n_32;
wire n_22;

AOI22xp5_ASAP7_75t_L g22 ( 
.A1(n_9),
.A2(n_4),
.B1(n_1),
.B2(n_17),
.Y(n_22)
);

INVx1_ASAP7_75t_L g23 ( 
.A(n_5),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_18),
.Y(n_24)
);

NAND2xp5_ASAP7_75t_L g25 ( 
.A(n_0),
.B(n_3),
.Y(n_25)
);

CKINVDCx5p33_ASAP7_75t_R g26 ( 
.A(n_12),
.Y(n_26)
);

CKINVDCx20_ASAP7_75t_R g27 ( 
.A(n_6),
.Y(n_27)
);

INVx1_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

INVx1_ASAP7_75t_L g29 ( 
.A(n_8),
.Y(n_29)
);

OAI21xp5_ASAP7_75t_L g30 ( 
.A1(n_23),
.A2(n_15),
.B(n_14),
.Y(n_30)
);

NAND2xp5_ASAP7_75t_L g31 ( 
.A(n_28),
.B(n_14),
.Y(n_31)
);

NAND2xp5_ASAP7_75t_SL g32 ( 
.A(n_26),
.B(n_15),
.Y(n_32)
);

AO31x2_ASAP7_75t_L g33 ( 
.A1(n_31),
.A2(n_29),
.A3(n_25),
.B(n_16),
.Y(n_33)
);

INVx1_ASAP7_75t_L g34 ( 
.A(n_32),
.Y(n_34)
);

NAND2xp5_ASAP7_75t_L g35 ( 
.A(n_34),
.B(n_30),
.Y(n_35)
);

AOI32xp33_ASAP7_75t_L g36 ( 
.A1(n_35),
.A2(n_27),
.A3(n_26),
.B1(n_24),
.B2(n_33),
.Y(n_36)
);

A2O1A1Ixp33_ASAP7_75t_L g37 ( 
.A1(n_36),
.A2(n_22),
.B(n_27),
.C(n_33),
.Y(n_37)
);

OAI21xp5_ASAP7_75t_L g38 ( 
.A1(n_36),
.A2(n_33),
.B(n_16),
.Y(n_38)
);

AND2x4_ASAP7_75t_L g39 ( 
.A(n_37),
.B(n_33),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_L g40 ( 
.A(n_38),
.B(n_19),
.Y(n_40)
);

OAI22xp5_ASAP7_75t_L g41 ( 
.A1(n_40),
.A2(n_39),
.B1(n_21),
.B2(n_19),
.Y(n_41)
);

AOI222xp33_ASAP7_75t_L g42 ( 
.A1(n_41),
.A2(n_7),
.B1(n_2),
.B2(n_10),
.C1(n_13),
.C2(n_11),
.Y(n_42)
);


endmodule