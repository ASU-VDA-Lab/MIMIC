module fake_netlist_776_2263_n_26 (n_1, n_0, n_5, n_3, n_2, n_4, n_26);

input n_1;
input n_0;
input n_5;
input n_3;
input n_2;
input n_4;

output n_26;

wire n_20;
wire n_6;
wire n_17;
wire n_12;
wire n_25;
wire n_24;
wire n_13;
wire n_18;
wire n_15;
wire n_16;
wire n_11;
wire n_23;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_19;
wire n_21;
wire n_22;
wire n_14;

INVx2_ASAP7_75t_L g6 ( 
.A(n_3),
.Y(n_6)
);

NAND2xp5_ASAP7_75t_L g7 ( 
.A(n_2),
.B(n_5),
.Y(n_7)
);

INVx2_ASAP7_75t_SL g8 ( 
.A(n_4),
.Y(n_8)
);

INVx2_ASAP7_75t_L g9 ( 
.A(n_5),
.Y(n_9)
);

AO22x2_ASAP7_75t_L g10 ( 
.A1(n_8),
.A2(n_1),
.B1(n_2),
.B2(n_0),
.Y(n_10)
);

AOI21xp5_ASAP7_75t_L g11 ( 
.A1(n_7),
.A2(n_1),
.B(n_0),
.Y(n_11)
);

INVx1_ASAP7_75t_L g12 ( 
.A(n_6),
.Y(n_12)
);

AOI21xp5_ASAP7_75t_L g13 ( 
.A1(n_7),
.A2(n_1),
.B(n_3),
.Y(n_13)
);

INVx1_ASAP7_75t_L g14 ( 
.A(n_12),
.Y(n_14)
);

BUFx3_ASAP7_75t_L g15 ( 
.A(n_10),
.Y(n_15)
);

BUFx3_ASAP7_75t_L g16 ( 
.A(n_10),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_14),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_14),
.Y(n_18)
);

NAND2xp5_ASAP7_75t_L g19 ( 
.A(n_15),
.B(n_13),
.Y(n_19)
);

AOI221xp5_ASAP7_75t_L g20 ( 
.A1(n_17),
.A2(n_15),
.B1(n_16),
.B2(n_9),
.C(n_11),
.Y(n_20)
);

A2O1A1Ixp33_ASAP7_75t_L g21 ( 
.A1(n_19),
.A2(n_16),
.B(n_15),
.C(n_4),
.Y(n_21)
);

NOR2xp33_ASAP7_75t_SL g22 ( 
.A(n_18),
.B(n_15),
.Y(n_22)
);

AOI21xp5_ASAP7_75t_L g23 ( 
.A1(n_22),
.A2(n_20),
.B(n_21),
.Y(n_23)
);

CKINVDCx5p33_ASAP7_75t_R g24 ( 
.A(n_22),
.Y(n_24)
);

NOR2xp33_ASAP7_75t_L g25 ( 
.A(n_24),
.B(n_16),
.Y(n_25)
);

OAI21xp33_ASAP7_75t_L g26 ( 
.A1(n_25),
.A2(n_24),
.B(n_23),
.Y(n_26)
);


endmodule