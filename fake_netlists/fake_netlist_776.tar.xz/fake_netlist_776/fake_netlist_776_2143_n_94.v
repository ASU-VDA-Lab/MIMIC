module fake_netlist_776_2143_n_94 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_3, n_14, n_94);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_3;
input n_14;

output n_94;

wire n_37;
wire n_55;
wire n_36;
wire n_63;
wire n_65;
wire n_35;
wire n_25;
wire n_40;
wire n_73;
wire n_42;
wire n_24;
wire n_48;
wire n_43;
wire n_68;
wire n_67;
wire n_54;
wire n_30;
wire n_59;
wire n_53;
wire n_79;
wire n_74;
wire n_85;
wire n_51;
wire n_89;
wire n_22;
wire n_45;
wire n_83;
wire n_62;
wire n_75;
wire n_31;
wire n_76;
wire n_88;
wire n_84;
wire n_28;
wire n_21;
wire n_90;
wire n_82;
wire n_86;
wire n_64;
wire n_29;
wire n_92;
wire n_91;
wire n_70;
wire n_69;
wire n_71;
wire n_26;
wire n_49;
wire n_56;
wire n_61;
wire n_78;
wire n_23;
wire n_32;
wire n_47;
wire n_44;
wire n_52;
wire n_77;
wire n_50;
wire n_58;
wire n_66;
wire n_27;
wire n_34;
wire n_39;
wire n_46;
wire n_33;
wire n_81;
wire n_38;
wire n_80;
wire n_87;
wire n_60;
wire n_57;
wire n_93;
wire n_41;
wire n_72;

INVx2_ASAP7_75t_L g21 ( 
.A(n_14),
.Y(n_21)
);

CKINVDCx5p33_ASAP7_75t_R g22 ( 
.A(n_16),
.Y(n_22)
);

INVx2_ASAP7_75t_L g23 ( 
.A(n_17),
.Y(n_23)
);

AND2x4_ASAP7_75t_L g24 ( 
.A(n_20),
.B(n_10),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_18),
.Y(n_25)
);

NAND2xp5_ASAP7_75t_L g26 ( 
.A(n_6),
.B(n_11),
.Y(n_26)
);

AND2x2_ASAP7_75t_L g27 ( 
.A(n_12),
.B(n_9),
.Y(n_27)
);

INVx2_ASAP7_75t_L g28 ( 
.A(n_20),
.Y(n_28)
);

NAND2xp5_ASAP7_75t_L g29 ( 
.A(n_4),
.B(n_16),
.Y(n_29)
);

INVx1_ASAP7_75t_L g30 ( 
.A(n_18),
.Y(n_30)
);

CKINVDCx5p33_ASAP7_75t_R g31 ( 
.A(n_3),
.Y(n_31)
);

CKINVDCx5p33_ASAP7_75t_R g32 ( 
.A(n_15),
.Y(n_32)
);

INVx1_ASAP7_75t_L g33 ( 
.A(n_0),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_19),
.B(n_1),
.Y(n_34)
);

INVx2_ASAP7_75t_L g35 ( 
.A(n_17),
.Y(n_35)
);

CKINVDCx5p33_ASAP7_75t_R g36 ( 
.A(n_8),
.Y(n_36)
);

AOI22xp33_ASAP7_75t_L g37 ( 
.A1(n_23),
.A2(n_19),
.B1(n_5),
.B2(n_2),
.Y(n_37)
);

INVx3_ASAP7_75t_L g38 ( 
.A(n_23),
.Y(n_38)
);

BUFx3_ASAP7_75t_L g39 ( 
.A(n_33),
.Y(n_39)
);

INVx1_ASAP7_75t_L g40 ( 
.A(n_30),
.Y(n_40)
);

BUFx6f_ASAP7_75t_L g41 ( 
.A(n_21),
.Y(n_41)
);

INVx3_ASAP7_75t_L g42 ( 
.A(n_28),
.Y(n_42)
);

AND2x4_ASAP7_75t_L g43 ( 
.A(n_28),
.B(n_35),
.Y(n_43)
);

INVx1_ASAP7_75t_L g44 ( 
.A(n_35),
.Y(n_44)
);

NOR2xp33_ASAP7_75t_R g45 ( 
.A(n_31),
.B(n_7),
.Y(n_45)
);

NAND2xp5_ASAP7_75t_L g46 ( 
.A(n_21),
.B(n_13),
.Y(n_46)
);

NAND2xp5_ASAP7_75t_L g47 ( 
.A(n_32),
.B(n_36),
.Y(n_47)
);

HB1xp67_ASAP7_75t_L g48 ( 
.A(n_22),
.Y(n_48)
);

NAND2xp5_ASAP7_75t_L g49 ( 
.A(n_25),
.B(n_24),
.Y(n_49)
);

INVx1_ASAP7_75t_L g50 ( 
.A(n_29),
.Y(n_50)
);

INVx1_ASAP7_75t_L g51 ( 
.A(n_40),
.Y(n_51)
);

INVx1_ASAP7_75t_L g52 ( 
.A(n_41),
.Y(n_52)
);

INVx2_ASAP7_75t_L g53 ( 
.A(n_41),
.Y(n_53)
);

NAND2xp5_ASAP7_75t_L g54 ( 
.A(n_50),
.B(n_24),
.Y(n_54)
);

INVx2_ASAP7_75t_L g55 ( 
.A(n_41),
.Y(n_55)
);

AOI22xp33_ASAP7_75t_L g56 ( 
.A1(n_50),
.A2(n_24),
.B1(n_27),
.B2(n_34),
.Y(n_56)
);

BUFx6f_ASAP7_75t_L g57 ( 
.A(n_41),
.Y(n_57)
);

AOI22xp33_ASAP7_75t_SL g58 ( 
.A1(n_43),
.A2(n_26),
.B1(n_49),
.B2(n_38),
.Y(n_58)
);

INVx1_ASAP7_75t_L g59 ( 
.A(n_41),
.Y(n_59)
);

NOR2xp33_ASAP7_75t_L g60 ( 
.A(n_47),
.B(n_48),
.Y(n_60)
);

OAI22xp5_ASAP7_75t_L g61 ( 
.A1(n_56),
.A2(n_37),
.B1(n_46),
.B2(n_39),
.Y(n_61)
);

AND2x4_ASAP7_75t_L g62 ( 
.A(n_51),
.B(n_43),
.Y(n_62)
);

OAI31xp33_ASAP7_75t_L g63 ( 
.A1(n_60),
.A2(n_39),
.A3(n_43),
.B(n_44),
.Y(n_63)
);

OAI21x1_ASAP7_75t_L g64 ( 
.A1(n_54),
.A2(n_42),
.B(n_38),
.Y(n_64)
);

NOR2xp33_ASAP7_75t_R g65 ( 
.A(n_54),
.B(n_38),
.Y(n_65)
);

INVx1_ASAP7_75t_L g66 ( 
.A(n_52),
.Y(n_66)
);

INVxp67_ASAP7_75t_L g67 ( 
.A(n_57),
.Y(n_67)
);

AND2x2_ASAP7_75t_L g68 ( 
.A(n_62),
.B(n_58),
.Y(n_68)
);

NOR2xp33_ASAP7_75t_L g69 ( 
.A(n_61),
.B(n_58),
.Y(n_69)
);

INVx1_ASAP7_75t_L g70 ( 
.A(n_66),
.Y(n_70)
);

AND2x2_ASAP7_75t_SL g71 ( 
.A(n_62),
.B(n_53),
.Y(n_71)
);

INVx2_ASAP7_75t_L g72 ( 
.A(n_64),
.Y(n_72)
);

AOI32xp33_ASAP7_75t_L g73 ( 
.A1(n_62),
.A2(n_42),
.A3(n_59),
.B1(n_55),
.B2(n_45),
.Y(n_73)
);

INVx1_ASAP7_75t_L g74 ( 
.A(n_70),
.Y(n_74)
);

AOI22xp33_ASAP7_75t_L g75 ( 
.A1(n_69),
.A2(n_63),
.B1(n_65),
.B2(n_67),
.Y(n_75)
);

NAND3xp33_ASAP7_75t_L g76 ( 
.A(n_73),
.B(n_57),
.C(n_42),
.Y(n_76)
);

INVx1_ASAP7_75t_L g77 ( 
.A(n_70),
.Y(n_77)
);

NAND2xp5_ASAP7_75t_L g78 ( 
.A(n_68),
.B(n_65),
.Y(n_78)
);

INVx1_ASAP7_75t_SL g79 ( 
.A(n_78),
.Y(n_79)
);

INVx1_ASAP7_75t_L g80 ( 
.A(n_74),
.Y(n_80)
);

CKINVDCx20_ASAP7_75t_R g81 ( 
.A(n_77),
.Y(n_81)
);

BUFx2_ASAP7_75t_L g82 ( 
.A(n_74),
.Y(n_82)
);

NAND3xp33_ASAP7_75t_L g83 ( 
.A(n_75),
.B(n_71),
.C(n_72),
.Y(n_83)
);

XNOR2xp5_ASAP7_75t_L g84 ( 
.A(n_76),
.B(n_57),
.Y(n_84)
);

HB1xp67_ASAP7_75t_L g85 ( 
.A(n_82),
.Y(n_85)
);

INVx1_ASAP7_75t_SL g86 ( 
.A(n_81),
.Y(n_86)
);

CKINVDCx5p33_ASAP7_75t_R g87 ( 
.A(n_81),
.Y(n_87)
);

INVx1_ASAP7_75t_L g88 ( 
.A(n_80),
.Y(n_88)
);

NAND4xp25_ASAP7_75t_L g89 ( 
.A(n_79),
.B(n_69),
.C(n_40),
.D(n_60),
.Y(n_89)
);

BUFx2_ASAP7_75t_L g90 ( 
.A(n_85),
.Y(n_90)
);

BUFx3_ASAP7_75t_L g91 ( 
.A(n_88),
.Y(n_91)
);

NAND3x2_ASAP7_75t_L g92 ( 
.A(n_89),
.B(n_84),
.C(n_83),
.Y(n_92)
);

INVx1_ASAP7_75t_L g93 ( 
.A(n_86),
.Y(n_93)
);

OAI221xp5_ASAP7_75t_R g94 ( 
.A1(n_92),
.A2(n_87),
.B1(n_91),
.B2(n_90),
.C(n_93),
.Y(n_94)
);


endmodule