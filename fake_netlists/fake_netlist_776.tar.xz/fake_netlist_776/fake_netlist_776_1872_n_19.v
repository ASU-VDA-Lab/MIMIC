module fake_netlist_776_1872_n_19 (n_1, n_0, n_3, n_2, n_4, n_19);

input n_1;
input n_0;
input n_3;
input n_2;
input n_4;

output n_19;

wire n_6;
wire n_17;
wire n_12;
wire n_5;
wire n_18;
wire n_13;
wire n_15;
wire n_11;
wire n_16;
wire n_9;
wire n_8;
wire n_7;
wire n_10;
wire n_14;

CKINVDCx20_ASAP7_75t_R g5 ( 
.A(n_0),
.Y(n_5)
);

CKINVDCx5p33_ASAP7_75t_R g6 ( 
.A(n_2),
.Y(n_6)
);

CKINVDCx20_ASAP7_75t_R g7 ( 
.A(n_2),
.Y(n_7)
);

INVx1_ASAP7_75t_L g8 ( 
.A(n_4),
.Y(n_8)
);

BUFx6f_ASAP7_75t_L g9 ( 
.A(n_8),
.Y(n_9)
);

NAND2xp5_ASAP7_75t_SL g10 ( 
.A(n_6),
.B(n_0),
.Y(n_10)
);

NOR2xp33_ASAP7_75t_L g11 ( 
.A(n_9),
.B(n_8),
.Y(n_11)
);

AND2x4_ASAP7_75t_L g12 ( 
.A(n_9),
.B(n_5),
.Y(n_12)
);

AND2x2_ASAP7_75t_L g13 ( 
.A(n_11),
.B(n_9),
.Y(n_13)
);

OAI221xp5_ASAP7_75t_SL g14 ( 
.A1(n_13),
.A2(n_12),
.B1(n_7),
.B2(n_10),
.C(n_1),
.Y(n_14)
);

O2A1O1Ixp5_ASAP7_75t_L g15 ( 
.A1(n_14),
.A2(n_13),
.B(n_12),
.C(n_1),
.Y(n_15)
);

CKINVDCx20_ASAP7_75t_R g16 ( 
.A(n_15),
.Y(n_16)
);

INVx1_ASAP7_75t_L g17 ( 
.A(n_16),
.Y(n_17)
);

INVx1_ASAP7_75t_L g18 ( 
.A(n_16),
.Y(n_18)
);

AOI22xp5_ASAP7_75t_SL g19 ( 
.A1(n_18),
.A2(n_3),
.B1(n_4),
.B2(n_17),
.Y(n_19)
);


endmodule