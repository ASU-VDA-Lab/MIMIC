module fake_netlist_776_37_n_46 (n_0, n_20, n_6, n_17, n_2, n_12, n_1, n_5, n_18, n_13, n_15, n_11, n_16, n_4, n_9, n_8, n_7, n_10, n_19, n_21, n_3, n_22, n_14, n_46);

input n_0;
input n_20;
input n_6;
input n_17;
input n_2;
input n_12;
input n_1;
input n_5;
input n_18;
input n_13;
input n_15;
input n_11;
input n_16;
input n_4;
input n_9;
input n_8;
input n_7;
input n_10;
input n_19;
input n_21;
input n_3;
input n_22;
input n_14;

output n_46;

wire n_37;
wire n_45;
wire n_44;
wire n_36;
wire n_29;
wire n_35;
wire n_25;
wire n_31;
wire n_40;
wire n_27;
wire n_34;
wire n_39;
wire n_33;
wire n_26;
wire n_24;
wire n_42;
wire n_43;
wire n_38;
wire n_23;
wire n_28;
wire n_30;
wire n_41;
wire n_32;

CKINVDCx5p33_ASAP7_75t_R g23 ( 
.A(n_18),
.Y(n_23)
);

CKINVDCx20_ASAP7_75t_R g24 ( 
.A(n_8),
.Y(n_24)
);

CKINVDCx5p33_ASAP7_75t_R g25 ( 
.A(n_6),
.Y(n_25)
);

INVx1_ASAP7_75t_L g26 ( 
.A(n_0),
.Y(n_26)
);

INVx1_ASAP7_75t_L g27 ( 
.A(n_5),
.Y(n_27)
);

INVxp67_ASAP7_75t_L g28 ( 
.A(n_11),
.Y(n_28)
);

CKINVDCx20_ASAP7_75t_R g29 ( 
.A(n_9),
.Y(n_29)
);

NOR2xp33_ASAP7_75t_R g30 ( 
.A(n_1),
.B(n_4),
.Y(n_30)
);

BUFx6f_ASAP7_75t_L g31 ( 
.A(n_26),
.Y(n_31)
);

OAI22xp5_ASAP7_75t_SL g32 ( 
.A1(n_23),
.A2(n_19),
.B1(n_18),
.B2(n_2),
.Y(n_32)
);

OR2x6_ASAP7_75t_L g33 ( 
.A(n_27),
.B(n_19),
.Y(n_33)
);

NAND2xp5_ASAP7_75t_L g34 ( 
.A(n_31),
.B(n_28),
.Y(n_34)
);

BUFx2_ASAP7_75t_L g35 ( 
.A(n_31),
.Y(n_35)
);

NAND2x1_ASAP7_75t_L g36 ( 
.A(n_35),
.B(n_33),
.Y(n_36)
);

OR2x2_ASAP7_75t_L g37 ( 
.A(n_34),
.B(n_32),
.Y(n_37)
);

INVx1_ASAP7_75t_L g38 ( 
.A(n_37),
.Y(n_38)
);

OAI322xp33_ASAP7_75t_L g39 ( 
.A1(n_36),
.A2(n_24),
.A3(n_29),
.B1(n_25),
.B2(n_30),
.C1(n_3),
.C2(n_7),
.Y(n_39)
);

NAND2xp5_ASAP7_75t_SL g40 ( 
.A(n_38),
.B(n_10),
.Y(n_40)
);

OAI22xp33_ASAP7_75t_L g41 ( 
.A1(n_39),
.A2(n_14),
.B1(n_13),
.B2(n_12),
.Y(n_41)
);

CKINVDCx5p33_ASAP7_75t_R g42 ( 
.A(n_40),
.Y(n_42)
);

AND2x4_ASAP7_75t_L g43 ( 
.A(n_41),
.B(n_15),
.Y(n_43)
);

OAI22x1_ASAP7_75t_L g44 ( 
.A1(n_42),
.A2(n_43),
.B1(n_17),
.B2(n_16),
.Y(n_44)
);

OR2x2_ASAP7_75t_L g45 ( 
.A(n_43),
.B(n_20),
.Y(n_45)
);

AOI22xp33_ASAP7_75t_SL g46 ( 
.A1(n_45),
.A2(n_21),
.B1(n_22),
.B2(n_44),
.Y(n_46)
);


endmodule